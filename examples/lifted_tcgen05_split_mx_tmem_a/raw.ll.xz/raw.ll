; ModuleID = "tcgen05_split_mx_tmem_a_sm100a_cuda13"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [3104 x i8], align 16
define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P2_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0080"
BB_0080:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_02a0", label %"BB_0090"
BB_0090:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"UR7:UR6_r0" = trunc i64 %"ldc_const" to i32
  %"UR7:UR6_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR7:UR6_r1" = trunc i64 %"UR7:UR6_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".21" = xor i32 %"imad", -1
  %".22" = xor i32 508, -1
  %".23" = xor i32 0, -1
  %".24" = and i32 %"imad", 508
  %".25" = and i32 %".24", %".23"
  %".26" = and i32 %"imad", 508
  %".27" = and i32 %".26", 0
  %".28" = or i32 %".25", %".27"
  %"iadd3_o1_64" = zext i32 %".28" to i64
  %"iadd3_o2_64" = zext i32 %"UR7:UR6_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P38_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR7:UR6_r1"
  %"imad_cin_trunc" = trunc i32 %"P38_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R383:R363_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R383:R363_addr_ptr"
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".29" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".30" = zext i32 %"iadd3_n2" to i64
  %".31" = zext i32 24 to i64
  %".32" = shl i64 %".29", %".31"
  %".33" = and i64 %".32", 4294967295
  %".34" = add i64 %".33", %".30"
  %".35" = trunc i64 %".34" to i32
  %"viadd" = add i32 %"imad", %".35"
  br label %"BB_0140"
BB_0140:
  %"phi" = phi  i32 [%"tid_x", %"BB_0090"], [%"viadd.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"viadd", %"BB_0090"], [%"viadd.2", %"BB_0180"]
  %"isetrp_cmp1.1" = icmp uge i32 %"phi", 128
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P73_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".37" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".37" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P73_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0140", label %"BB_0190"
BB_0190:
  %".41" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".42" = bitcast i8* %".41" to i64*
  %"ldc_const.1" = load i64, i64* %".42"
  %"R5:R4_r0" = trunc i64 %"ldc_const.1" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"viadd.3" = add i32 %"imad", %".16"
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad.2" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P87_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R5:R4_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P87_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0210"
BB_0210:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_0190"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.3" = phi  i32 [%"iadd3_trunc.1", %"BB_0190"], [%"iadd3_trunc.2", %"BB_0290"]
  %"phi.4" = phi  i32 [%"tid_x", %"BB_0190"], [%"viadd.4", %"BB_0290"]
  %"phi.5" = phi  i32 [%"viadd.3", %"BB_0190"], [%"viadd.5", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R34:R380_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R34:R380_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.4", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.4" = add i32 %"phi.4", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P72_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P72_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.5", 16777215
  %".44" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".44" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.5", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.6" = phi  i32 [0, %"BB_0080"], [%"UR7:UR6_r1", %"BB_0290"]
  %"phi.7" = phi  i32 [0, %"BB_0080"], [%".35", %"BB_0290"]
  %"isetrp_cmp1.3" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P61_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P94_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"vote_pred_trunc" = trunc i32 %"P61_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P83_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P83_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 2048
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".50" = zext i32 %"iadd3_n2.2" to i64
  %".51" = zext i32 0 to i64
  %".52" = shl i64 %".51", 32
  %"shf_concat" = or i64 %".50", %".52"
  %"shf_shift_64" = zext i32 11 to i64
  %".53" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".53" to i32
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat.1" = or i64 %".54", %".56"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".57" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".57" to i32
  %".58" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".59" = zext i32 %"iadd3_n2.1" to i64
  %".60" = zext i32 24 to i64
  %".61" = shl i64 %".58", %".60"
  %".62" = and i64 %".61", 4294967295
  %".63" = add i64 %".62", %".59"
  %".64" = trunc i64 %".63" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000300"], [%"phi.6", %"BB_0300"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"phi.10" = phi  i32 [%".64", %"BB_80000300"], [%"phi.7", %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P61_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P37_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.10", 16777215
  %".69" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".69" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".70" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".70" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P94_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_slot_winoff" = and i32 3080, 16777215
  %".74" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".75" = ptrtoint i8 addrspace(3)* %".74" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".75", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P8_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 1
  %".79" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".80" = zext i32 64 to i64
  %".81" = zext i32 24 to i64
  %".82" = shl i64 %".79", %".81"
  %".83" = and i64 %".82", 4294967295
  %".84" = add i64 %".83", %".80"
  %".85" = trunc i64 %".84" to i32
  %"tmem_alloc_winoff" = and i32 3080, 16777215
  %".86" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".87" = bitcast i8 addrspace(3)* %".86" to i32 addrspace(3)*
  %".88" = load i32, i32 addrspace(3)* %".87"
  %".89" = lshr i32 %".88", 5
  %"P43_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".89"
  %"bra_cond_trunc" = trunc i32 %"P43_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_winoff.1" = and i32 3080, 16777215
  %".91" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".92" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  %".93" = load i32, i32 addrspace(3)* %".92"
  %".94" = lshr i32 %".93", 5
  %"P45_to_i32" = zext i1 1 to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".94"
  %"bra_cond_trunc.1" = trunc i32 %"P45_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.11" = phi  i32 [%"imad.6", %"BB_03c0"], [%"imad.7", %"BB_0440"]
  %".96" = zext i32 %"imad.5" to i64
  %".97" = zext i32 0 to i64
  %".98" = shl i64 %".97", 32
  %"shf_concat.2" = or i64 %".96", %".98"
  %"shf_shift_64.2" = zext i32 %"phi.11" to i64
  %".99" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".99" to i32
  %"imad_tmp.7" = mul i32 %"phi.11", 32
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".85", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".100" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".100" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".85", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".101" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".102" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".102" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.12" = phi  i32 [%"P8_to_i32", %"BB_04a0"], [%"P8_to_i32", %"BB_03b0"], [%"P2_to_i32", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0520"
BB_0520:
  %"cond_trunc.7" = trunc i32 %"P94_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0b50", label %"BB_0530"
BB_0530:
  %"allocation_slot_winoff.1" = and i32 3084, 16777215
  %".107" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.1"
  %".108" = ptrtoint i8 addrspace(3)* %".107" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".108", i32 32) convergent
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P47_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0550"
BB_0550:
  %"cond_trunc.8" = trunc i32 %"P47_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0690", label %"BB_0560"
BB_0560:
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", 1
  %".112" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".113" = zext i32 64 to i64
  %".114" = zext i32 24 to i64
  %".115" = shl i64 %".112", %".114"
  %".116" = and i64 %".115", 4294967295
  %".117" = add i64 %".116", %".113"
  %".118" = trunc i64 %".117" to i32
  %"tmem_alloc_winoff.2" = and i32 3084, 16777215
  %".119" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.2"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P46_to_i32" = zext i1 1 to i32
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.9", %".122"
  %"bra_cond_trunc.2" = trunc i32 %"P46_to_i32" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  br i1 %"bra_cond_to_i1.2", label %"BB_0640", label %"BB_05e0"
BB_05e0:
  %"tmem_alloc_winoff.3" = and i32 3084, 16777215
  %".124" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.3"
  %".125" = bitcast i8 addrspace(3)* %".124" to i32 addrspace(3)*
  %".126" = load i32, i32 addrspace(3)* %".125"
  %".127" = lshr i32 %".126", 5
  %"P16_to_i32" = zext i1 1 to i32
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.10", %".127"
  %"bra_cond_trunc.3" = trunc i32 %"P16_to_i32" to i1
  %"bra_cond_not.1" = xor i1 %"bra_cond_trunc.3", -1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_not.1" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  br i1 %"bra_cond_to_i1.3", label %"BB_05e0", label %"BB_0640"
BB_0640:
  %"phi.13" = phi  i32 [%"imad.10", %"BB_0560"], [%"imad.11", %"BB_05e0"]
  %".129" = zext i32 %"imad.9" to i64
  %".130" = zext i32 0 to i64
  %".131" = shl i64 %".130", 32
  %"shf_concat.3" = or i64 %".129", %".131"
  %"shf_shift_64.3" = zext i32 %"phi.13" to i64
  %".132" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".132" to i32
  %"imad_tmp.11" = mul i32 %"phi.13", 32
  %"imad.12" = add i32 %"imad_tmp.11", 0
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".118", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".133" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".133" to i32 addrspace(3)*
  %"atoms_or.2" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.2", i32 %"shf_result.3" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".118", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".134" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".134" to i32 addrspace(3)*
  %"atoms_or.3" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.3", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add.1" = add i32 %".16", 2060
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".135" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".135" to i32 addrspace(3)*
  store volatile i32 %"imad.12", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0690"
BB_0690:
  %"allocation_slot_winoff.2" = and i32 3088, 16777215
  %".138" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.2"
  %".139" = ptrtoint i8 addrspace(3)* %".138" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".139", i32 64) convergent
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P57_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_06c0"
BB_06c0:
  %"cond_trunc.9" = trunc i32 %"P57_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0820", label %"BB_06d0"
BB_06d0:
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", 3
  %".143" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".144" = zext i32 64 to i64
  %".145" = zext i32 24 to i64
  %".146" = shl i64 %".143", %".145"
  %".147" = and i64 %".146", 4294967295
  %".148" = add i64 %".147", %".144"
  %".149" = trunc i64 %".148" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", 1
  %"tmem_alloc_winoff.4" = and i32 3088, 16777215
  %".150" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.4"
  %".151" = bitcast i8 addrspace(3)* %".150" to i32 addrspace(3)*
  %".152" = load i32, i32 addrspace(3)* %".151"
  %".153" = lshr i32 %".152", 5
  %"P33_to_i32" = zext i1 1 to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.14", %".153"
  %"bra_cond_trunc.4" = trunc i32 %"P33_to_i32" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  br i1 %"bra_cond_to_i1.4", label %"BB_07c0", label %"BB_0760"
BB_0760:
  %"tmem_alloc_winoff.5" = and i32 3088, 16777215
  %".155" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.5"
  %".156" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  %".157" = load i32, i32 addrspace(3)* %".156"
  %".158" = lshr i32 %".157", 5
  %"P34_to_i32" = zext i1 1 to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.15", %".158"
  %"bra_cond_trunc.5" = trunc i32 %"P34_to_i32" to i1
  %"bra_cond_not.2" = xor i1 %"bra_cond_trunc.5", -1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_not.2" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  br i1 %"bra_cond_to_i1.5", label %"BB_0760", label %"BB_07c0"
BB_07c0:
  %"phi.14" = phi  i32 [%"imad.15", %"BB_06d0"], [%"imad.16", %"BB_0760"]
  %".160" = zext i32 %"imad.13" to i64
  %".161" = zext i32 0 to i64
  %".162" = shl i64 %".161", 32
  %"shf_concat.4" = or i64 %".160", %".162"
  %"shf_shift_64.4" = zext i32 %"phi.14" to i64
  %".163" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".163" to i32
  %".164" = zext i32 %"imad.14" to i64
  %".165" = zext i32 0 to i64
  %".166" = shl i64 %".165", 32
  %"shf_concat.5" = or i64 %".164", %".166"
  %"shf_shift_64.5" = zext i32 %"phi.14" to i64
  %".167" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".167" to i32
  %"imad_tmp.16" = mul i32 %"phi.14", 32
  %"imad.17" = add i32 %"imad_tmp.16", 0
  %"atoms_addr_memaddr_offset_add.4" = add i32 %".149", 20
  %"atoms_shared_addr_winoff.4" = and i32 %"atoms_addr_memaddr_offset_add.4", 16777215
  %".168" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.4"
  %"atoms_ptr.4" = bitcast i8 addrspace(3)* %".168" to i32 addrspace(3)*
  %"atoms_or.4" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.4", i32 %"shf_result.4" monotonic
  %"atoms_addr_memaddr_offset_add.5" = add i32 %".149", 24
  %"atoms_shared_addr_winoff.5" = and i32 %"atoms_addr_memaddr_offset_add.5", 16777215
  %".169" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.5"
  %"atoms_ptr.5" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  %"atoms_or.5" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.5", i32 %"shf_result.5" monotonic
  %"sts_addr_memaddr_offset_add.2" = add i32 %".16", 2064
  %"sts_shared_addr_winoff.4" = and i32 %"sts_addr_memaddr_offset_add.2", 16777215
  %".170" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".170" to i32 addrspace(3)*
  store volatile i32 %"imad.17", i32 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_0820"
BB_0820:
  %"allocation_slot_winoff.3" = and i32 3092, 16777215
  %".173" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.3"
  %".174" = ptrtoint i8 addrspace(3)* %".173" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".174", i32 128) convergent
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P68_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0850"
BB_0850:
  %"cond_trunc.10" = trunc i32 %"P68_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_09b0", label %"BB_0860"
BB_0860:
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.17", 15
  %".178" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".179" = zext i32 64 to i64
  %".180" = zext i32 24 to i64
  %".181" = shl i64 %".178", %".180"
  %".182" = and i64 %".181", 4294967295
  %".183" = add i64 %".182", %".179"
  %".184" = trunc i64 %".183" to i32
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.18", 1
  %"tmem_alloc_winoff.6" = and i32 3092, 16777215
  %".185" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.6"
  %".186" = bitcast i8 addrspace(3)* %".185" to i32 addrspace(3)*
  %".187" = load i32, i32 addrspace(3)* %".186"
  %".188" = lshr i32 %".187", 5
  %"P36_to_i32" = zext i1 1 to i32
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.19", %".188"
  %"bra_cond_trunc.6" = trunc i32 %"P36_to_i32" to i1
  %"bra_cond_to_i32.6" = zext i1 %"bra_cond_trunc.6" to i32
  %"bra_cond_to_i1.6" = icmp ne i32 %"bra_cond_to_i32.6", 0
  br i1 %"bra_cond_to_i1.6", label %"BB_0950", label %"BB_08f0"
BB_08f0:
  %"tmem_alloc_winoff.7" = and i32 3092, 16777215
  %".190" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.7"
  %".191" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %".192" = load i32, i32 addrspace(3)* %".191"
  %".193" = lshr i32 %".192", 5
  %"P40_to_i32" = zext i1 1 to i32
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.20", %".193"
  %"bra_cond_trunc.7" = trunc i32 %"P40_to_i32" to i1
  %"bra_cond_not.3" = xor i1 %"bra_cond_trunc.7", -1
  %"bra_cond_to_i32.7" = zext i1 %"bra_cond_not.3" to i32
  %"bra_cond_to_i1.7" = icmp ne i32 %"bra_cond_to_i32.7", 0
  br i1 %"bra_cond_to_i1.7", label %"BB_08f0", label %"BB_0950"
BB_0950:
  %"phi.15" = phi  i32 [%"imad.20", %"BB_0860"], [%"imad.21", %"BB_08f0"]
  %".195" = zext i32 %"imad.18" to i64
  %".196" = zext i32 0 to i64
  %".197" = shl i64 %".196", 32
  %"shf_concat.6" = or i64 %".195", %".197"
  %"shf_shift_64.6" = zext i32 %"phi.15" to i64
  %".198" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".198" to i32
  %".199" = zext i32 %"imad.19" to i64
  %".200" = zext i32 0 to i64
  %".201" = shl i64 %".200", 32
  %"shf_concat.7" = or i64 %".199", %".201"
  %"shf_shift_64.7" = zext i32 %"phi.15" to i64
  %".202" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".202" to i32
  %"imad_tmp.21" = mul i32 %"phi.15", 32
  %"imad.22" = add i32 %"imad_tmp.21", 0
  %"atoms_addr_memaddr_offset_add.6" = add i32 %".184", 20
  %"atoms_shared_addr_winoff.6" = and i32 %"atoms_addr_memaddr_offset_add.6", 16777215
  %".203" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.6"
  %"atoms_ptr.6" = bitcast i8 addrspace(3)* %".203" to i32 addrspace(3)*
  %"atoms_or.6" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.6", i32 %"shf_result.6" monotonic
  %"atoms_addr_memaddr_offset_add.7" = add i32 %".184", 24
  %"atoms_shared_addr_winoff.7" = and i32 %"atoms_addr_memaddr_offset_add.7", 16777215
  %".204" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.7"
  %"atoms_ptr.7" = bitcast i8 addrspace(3)* %".204" to i32 addrspace(3)*
  %"atoms_or.7" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.7", i32 %"shf_result.7" monotonic
  %"sts_addr_memaddr_offset_add.3" = add i32 %".16", 2068
  %"sts_shared_addr_winoff.5" = and i32 %"sts_addr_memaddr_offset_add.3", 16777215
  %".205" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".205" to i32 addrspace(3)*
  store volatile i32 %"imad.22", i32 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_09b0"
BB_09b0:
  %"allocation_slot_winoff.4" = and i32 3096, 16777215
  %".208" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.4"
  %".209" = ptrtoint i8 addrspace(3)* %".208" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".209", i32 256) convergent
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P80_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.11" = trunc i32 %"P80_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0b50", label %"BB_09f0"
BB_09f0:
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.22", 255
  %".213" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".214" = zext i32 64 to i64
  %".215" = zext i32 24 to i64
  %".216" = shl i64 %".213", %".215"
  %".217" = and i64 %".216", 4294967295
  %".218" = add i64 %".217", %".214"
  %".219" = trunc i64 %".218" to i32
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.23", 1
  %"tmem_alloc_winoff.8" = and i32 3096, 16777215
  %".220" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.8"
  %".221" = bitcast i8 addrspace(3)* %".220" to i32 addrspace(3)*
  %".222" = load i32, i32 addrspace(3)* %".221"
  %".223" = lshr i32 %".222", 5
  %"P41_to_i32" = zext i1 1 to i32
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.24", %".223"
  %"bra_cond_trunc.8" = trunc i32 %"P41_to_i32" to i1
  %"bra_cond_to_i32.8" = zext i1 %"bra_cond_trunc.8" to i32
  %"bra_cond_to_i1.8" = icmp ne i32 %"bra_cond_to_i32.8", 0
  br i1 %"bra_cond_to_i1.8", label %"BB_0ae0", label %"BB_0a80"
BB_0a80:
  %"tmem_alloc_winoff.9" = and i32 3096, 16777215
  %".225" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.9"
  %".226" = bitcast i8 addrspace(3)* %".225" to i32 addrspace(3)*
  %".227" = load i32, i32 addrspace(3)* %".226"
  %".228" = lshr i32 %".227", 5
  %"P42_to_i32" = zext i1 1 to i32
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.25", %".228"
  %"bra_cond_trunc.9" = trunc i32 %"P42_to_i32" to i1
  %"bra_cond_not.4" = xor i1 %"bra_cond_trunc.9", -1
  %"bra_cond_to_i32.9" = zext i1 %"bra_cond_not.4" to i32
  %"bra_cond_to_i1.9" = icmp ne i32 %"bra_cond_to_i32.9", 0
  br i1 %"bra_cond_to_i1.9", label %"BB_0a80", label %"BB_0ae0"
BB_0ae0:
  %"phi.16" = phi  i32 [%"imad.25", %"BB_09f0"], [%"imad.26", %"BB_0a80"]
  %".230" = zext i32 %"imad.23" to i64
  %".231" = zext i32 0 to i64
  %".232" = shl i64 %".231", 32
  %"shf_concat.8" = or i64 %".230", %".232"
  %"shf_shift_64.8" = zext i32 %"phi.16" to i64
  %".233" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".233" to i32
  %".234" = zext i32 %"imad.24" to i64
  %".235" = zext i32 0 to i64
  %".236" = shl i64 %".235", 32
  %"shf_concat.9" = or i64 %".234", %".236"
  %"shf_shift_64.9" = zext i32 %"phi.16" to i64
  %".237" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".237" to i32
  %"imad_tmp.26" = mul i32 %"phi.16", 32
  %"imad.27" = add i32 %"imad_tmp.26", 0
  %"atoms_addr_memaddr_offset_add.8" = add i32 %".219", 20
  %"atoms_shared_addr_winoff.8" = and i32 %"atoms_addr_memaddr_offset_add.8", 16777215
  %".238" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.8"
  %"atoms_ptr.8" = bitcast i8 addrspace(3)* %".238" to i32 addrspace(3)*
  %"atoms_or.8" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.8", i32 %"shf_result.8" monotonic
  %"atoms_addr_memaddr_offset_add.9" = add i32 %".219", 24
  %"atoms_shared_addr_winoff.9" = and i32 %"atoms_addr_memaddr_offset_add.9", 16777215
  %".239" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.9"
  %"atoms_ptr.9" = bitcast i8 addrspace(3)* %".239" to i32 addrspace(3)*
  %"atoms_or.9" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.9", i32 %"shf_result.9" monotonic
  %"sts_addr_memaddr_offset_add.4" = add i32 %".16", 2072
  %"sts_shared_addr_winoff.6" = and i32 %"sts_addr_memaddr_offset_add.4", 16777215
  %".240" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".240" to i32 addrspace(3)*
  store volatile i32 %"imad.27", i32 addrspace(3)* %"sts_shared_addr_cast.6"
  br label %"BB_0b50"
BB_0b50:
  %"phi.17" = phi  i32 [%"P80_to_i32", %"BB_0ae0"], [%"P80_to_i32", %"BB_09e0"], [%"phi.12", %"BB_0520"]
  %".243" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".244" = bitcast i8* %".243" to i64*
  %"ldc_const.2" = load i64, i64* %".244"
  %"R27:R26_r0" = trunc i64 %"ldc_const.2" to i32
  %"R27:R26_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R27:R26_r1" = trunc i64 %"R27:R26_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.27" = mul i32 %"tid_x", 18
  %"imad.28" = add i32 %"imad_tmp.27", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R27:R26_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R27:R26_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.28" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.29" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R27:R26_r0.1" = trunc i64 %"imad.29" to i32
  %"R27:R26_r1_shift.1" = lshr i64 %"imad.29", 32
  %"R27:R26_r1.1" = trunc i64 %"R27:R26_r1_shift.1" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".245" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".245" to i64 addrspace(3)*
  %"lds" = load volatile i64, i64 addrspace(3)* %"lds_shared_addr_cast"
  %"R13:R12_r0" = trunc i64 %"lds" to i32
  %"R13:R12_r1_shift" = lshr i64 %"lds", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R309:R305_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R309:R305_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R309:R305_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R309:R305_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R309:R305_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R309:R305_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R309:R305_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R309:R305_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.7"
  %"imad_tmp.28" = mul i32 %"tid_x", 65536
  %"imad.30" = add i32 %"imad_tmp.28", 0
  %".246" = xor i32 %"imad.30", -1
  %".247" = xor i32 65011712, -1
  %".248" = xor i32 0, -1
  %".249" = and i32 %"imad.30", 65011712
  %".250" = and i32 %".249", %".248"
  %".251" = and i32 %"imad.30", 65011712
  %".252" = and i32 %".251", 0
  %".253" = or i32 %".250", %".252"
  %"imad_tmp.29" = mul i32 %"R13:R12_r1", 1
  %"imad.31" = add i32 %"imad_tmp.29", %".253"
  %"sttm_memaddr_offset_add" = add i32 %"imad.31", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.31", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R309:R305_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R309:R305_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R309:R305_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R309:R305_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R309:R305_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R309:R305_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R309:R305_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R309:R305_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.15"
  %"imad_addend_neg" = sub i32 0, %"R13:R12_r0"
  %"imad_tmp.30" = mul i32 %"R13:R12_r1", 1
  %"imad.32" = add i32 %"imad_tmp.30", %"imad_addend_neg"
  %"imad_tmp.31" = mul i32 %".253", 1
  %"imad.33" = add i32 %"imad_tmp.31", %"R13:R12_r0"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.31", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.31", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0dd0"
BB_0dd0:
  %"cond_trunc.12" = trunc i32 %"P61_to_i32" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_1140", label %"BB_0de0"
BB_0de0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".263" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".263" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".264" = zext i32 0 to i64
  %".265" = zext i32 %".16" to i64
  %".266" = shl i64 %".265", 32
  %"shf_concat.10" = or i64 %".264", %".266"
  %"shf_shift_64.10" = zext i32 4 to i64
  %".267" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi" = lshr i64 %".267", 32
  %"shf_result.10" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".268" = xor i32 %"plop3_a_bit", 1
  %".269" = xor i32 %"plop3_b_bit", 1
  %".270" = xor i32 %"plop3_c_bit", 1
  %".271" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".272" = and i32 %".271", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".272", 0
  %"P54_to_i32" = zext i1 %"plop3_pred" to i32
  %".273" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".274" = zext i32 %"iadd3_n2.3" to i64
  %".275" = zext i32 24 to i64
  %".276" = shl i64 %".273", %".275"
  %".277" = and i64 %".276", 4294967295
  %".278" = add i64 %".277", %".274"
  %".279" = trunc i64 %".278" to i32
  %".280" = xor i32 %"shf_result.10", -1
  %".281" = xor i32 16376, -1
  %".282" = xor i32 0, -1
  %".283" = and i32 %"shf_result.10", 16376
  %".284" = and i32 %".283", %".282"
  %".285" = and i32 %"shf_result.10", 16376
  %".286" = and i32 %".285", 0
  %".287" = or i32 %".284", %".286"
  %".288" = zext i32 0 to i64
  %".289" = zext i32 %".279" to i64
  %".290" = shl i64 %".289", 32
  %"shf_concat.11" = or i64 %".288", %".290"
  %"shf_shift_64.11" = zext i32 4 to i64
  %".291" = lshr i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_hi.1" = lshr i64 %".291", 32
  %"shf_result.11" = trunc i64 %"shf_hi.1" to i32
  %".292" = xor i32 %".287", -1
  %".293" = xor i32 524288, -1
  %".294" = xor i32 0, -1
  %".295" = and i32 %".292", 524288
  %".296" = and i32 %".295", %".294"
  %".297" = and i32 %".292", 524288
  %".298" = and i32 %".297", 0
  %".299" = or i32 %".296", %".298"
  %".300" = and i32 %".287", %".293"
  %".301" = and i32 %".300", %".294"
  %".302" = or i32 %".299", %".301"
  %".303" = and i32 %".287", %".293"
  %".304" = and i32 %".303", 0
  %".305" = or i32 %".302", %".304"
  %".306" = and i32 %".287", 524288
  %".307" = and i32 %".306", %".294"
  %".308" = or i32 %".305", %".307"
  %".309" = and i32 %".287", 524288
  %".310" = and i32 %".309", 0
  %".311" = or i32 %".308", %".310"
  %".312" = xor i32 %"shf_result.11", -1
  %".313" = xor i32 16376, -1
  %".314" = xor i32 0, -1
  %".315" = and i32 %"shf_result.11", 16376
  %".316" = and i32 %".315", %".314"
  %".317" = and i32 %"shf_result.11", 16376
  %".318" = and i32 %".317", 0
  %".319" = or i32 %".316", %".318"
  %".320" = xor i32 %".319", -1
  %".321" = xor i32 524288, -1
  %".322" = xor i32 0, -1
  %".323" = and i32 %".320", 524288
  %".324" = and i32 %".323", %".322"
  %".325" = and i32 %".320", 524288
  %".326" = and i32 %".325", 0
  %".327" = or i32 %".324", %".326"
  %".328" = and i32 %".319", %".321"
  %".329" = and i32 %".328", %".322"
  %".330" = or i32 %".327", %".329"
  %".331" = and i32 %".319", %".321"
  %".332" = and i32 %".331", 0
  %".333" = or i32 %".330", %".332"
  %".334" = and i32 %".319", 524288
  %".335" = and i32 %".334", %".322"
  %".336" = or i32 %".333", %".335"
  %".337" = and i32 %".319", 524288
  %".338" = and i32 %".337", 0
  %".339" = or i32 %".336", %".338"
  %"iadd3_n1.4" = add i32 %"imad.32", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", %"lds.1"
  br label %"BB_0ef0"
BB_0ef0:
  %"phi.18" = phi  i32 [%"phi.17", %"BB_0de0"], [%"P11_to_i32", %"BB_0f20"]
  %"phi.19" = phi  i32 [%"P54_to_i32", %"BB_0de0"], [%"phi.21", %"BB_0f20"]
  %"cond_trunc.13" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000ef0", label %"BB_0f00"
BB_80000ef0:
  %"elect_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"election.5" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.5")
  %"elect_p.5" = extractvalue {i32, i1} %"election.5", 1
  %"P17_to_i32" = zext i1 %"elect_p.5" to i32
  br label %"BB_0f00"
BB_0f00:
  %"phi.20" = phi  i32 [%"P17_to_i32", %"BB_80000ef0"], [%"phi.18", %"BB_0ef0"]
  %"mma_b_r0_ext" = zext i32 %".339" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".343" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".344" = sub i64 %".343", 0
  %".345" = lshr i64 %".344", 4
  %".346" = add i64 %"mma_b_packed_1", %".345"
  %".347" = and i64 %".346", 16383
  %".348" = and i64 %"mma_b_packed_1", -16384
  %".349" = or i64 %".348", %".347"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.4", i64 %".349", i32 134746256, i32 %"mma_arg_zext")
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000f10", label %"BB_0f20"
BB_80000f10:
  %"lop3_a_trunc" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".353" = xor i32 %"plop3_a_bit.1", 1
  %".354" = xor i32 %"plop3_b_bit.1", 1
  %".355" = xor i32 %"plop3_c_bit.1", 1
  %".356" = and i32 %".353", %"plop3_b_bit.1"
  %".357" = and i32 %".356", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".357", 0
  %"P79_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0f20"
BB_0f20:
  %"phi.21" = phi  i32 [%"P79_to_i32", %"BB_80000f10"], [%"phi.19", %"BB_0f10"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".359" = xor i32 %"plop3_a_bit.2", 1
  %".360" = xor i32 %"plop3_b_bit.2", 1
  %".361" = xor i32 %"plop3_c_bit.2", 1
  %".362" = and i32 %".359", %"plop3_b_bit.2"
  %".363" = and i32 %".362", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".363", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.10" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.10" = zext i1 %"bra_cond_trunc.10" to i32
  %"bra_cond_to_i1.10" = icmp ne i32 %"bra_cond_to_i32.10", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.10")
  br i1 %"branch_any", label %"BB_0ef0", label %"BB_0f40"
BB_0f40:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".365" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".365" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".366" = xor i32 %"plop3_a_bit.3", 1
  %".367" = xor i32 %"plop3_b_bit.3", 1
  %".368" = xor i32 %"plop3_c_bit.3", 1
  %".369" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".370" = and i32 %".369", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".370", 0
  %"P103_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"iadd3_n1.5" = add i32 %"imad.32", %"lds.2"
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"iadd3_n2.5", 16
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"iadd3_n2.5", 4
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  br label %"BB_0fc0"
BB_0fc0:
  %"phi.22" = phi  i32 [%"P11_to_i32", %"BB_0f40"], [%"P15_to_i32", %"BB_0ff0"]
  %"phi.23" = phi  i32 [%"P103_to_i32", %"BB_0f40"], [%"phi.25", %"BB_0ff0"]
  %"cond_trunc.15" = trunc i32 %"phi.23" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000fc0", label %"BB_0fd0"
BB_80000fc0:
  %"elect_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"election.6" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.6")
  %"elect_p.6" = extractvalue {i32, i1} %"election.6", 1
  %"P13_to_i32" = zext i1 %"elect_p.6" to i32
  br label %"BB_0fd0"
BB_0fd0:
  %"phi.24" = phi  i32 [%"P13_to_i32", %"BB_80000fc0"], [%"phi.22", %"BB_0fc0"]
  %"mma_b_r0_ext.1" = zext i32 %".311" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".374" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".375" = sub i64 %".374", 0
  %".376" = lshr i64 %".375", 4
  %".377" = add i64 %"mma_b_packed_1.1", %".376"
  %".378" = and i64 %".377", 16383
  %".379" = and i64 %"mma_b_packed_1.1", -16384
  %".380" = or i64 %".379", %".378"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.6", i64 %".380", i32 679743664, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.7")
  br label %"BB_0fe0"
BB_0fe0:
  %"cond_trunc.16" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000fe0", label %"BB_0ff0"
BB_80000fe0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.24" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".384" = xor i32 %"plop3_a_bit.4", 1
  %".385" = xor i32 %"plop3_b_bit.4", 1
  %".386" = xor i32 %"plop3_c_bit.4", 1
  %".387" = and i32 %".384", %"plop3_b_bit.4"
  %".388" = and i32 %".387", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".388", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0ff0"
BB_0ff0:
  %"phi.25" = phi  i32 [%"P9_to_i32", %"BB_80000fe0"], [%"phi.23", %"BB_0fe0"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".390" = xor i32 %"plop3_a_bit.5", 1
  %".391" = xor i32 %"plop3_b_bit.5", 1
  %".392" = xor i32 %"plop3_c_bit.5", 1
  %".393" = and i32 %".390", %"plop3_b_bit.5"
  %".394" = and i32 %".393", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".394", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.11" = trunc i32 %"phi.25" to i1
  %"bra_cond_to_i32.11" = zext i1 %"bra_cond_trunc.11" to i32
  %"bra_cond_to_i1.11" = icmp ne i32 %"bra_cond_to_i32.11", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.11")
  br i1 %"branch_any.1", label %"BB_0fc0", label %"BB_1010"
BB_1010:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".396" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".397" = xor i32 %"plop3_a_bit.6", 1
  %".398" = xor i32 %"plop3_b_bit.6", 1
  %".399" = xor i32 %"plop3_c_bit.6", 1
  %".400" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".401" = and i32 %".400", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".401", 0
  %"P35_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"iadd3_n1.8" = add i32 %"imad.32", %"lds.3"
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"iadd3_n2.8", 16
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"iadd3_n1.10" = add i32 %"iadd3_n2.8", 4
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  br label %"BB_1070"
BB_1070:
  %"phi.26" = phi  i32 [%"P15_to_i32", %"BB_1010"], [%"P21_to_i32", %"BB_10a0"]
  %"phi.27" = phi  i32 [%"P35_to_i32", %"BB_1010"], [%"phi.29", %"BB_10a0"]
  %"cond_trunc.17" = trunc i32 %"phi.27" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001070", label %"BB_1080"
BB_80001070:
  %"elect_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"election.7" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.7")
  %"elect_p.7" = extractvalue {i32, i1} %"election.7", 1
  %"P19_to_i32" = zext i1 %"elect_p.7" to i32
  br label %"BB_1080"
BB_1080:
  %"phi.28" = phi  i32 [%"P19_to_i32", %"BB_80001070"], [%"phi.26", %"BB_1070"]
  %"mma_b_r0_ext.2" = zext i32 %".311" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".405" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".406" = sub i64 %".405", 0
  %".407" = lshr i64 %".406", 4
  %".408" = add i64 %"mma_b_packed_1.2", %".407"
  %".409" = and i64 %".408", 16383
  %".410" = and i64 %"mma_b_packed_1.2", -16384
  %".411" = or i64 %".410", %".409"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.9", i64 %".411", i32 679743664, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.8", i32 %"iadd3_n2.10")
  br label %"BB_1090"
BB_1090:
  %"cond_trunc.18" = trunc i32 %"phi.28" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80001090", label %"BB_10a0"
BB_80001090:
  %"lop3_a_trunc.2" = trunc i32 %"phi.28" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".415" = xor i32 %"plop3_a_bit.7", 1
  %".416" = xor i32 %"plop3_b_bit.7", 1
  %".417" = xor i32 %"plop3_c_bit.7", 1
  %".418" = and i32 %".415", %"plop3_b_bit.7"
  %".419" = and i32 %".418", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".419", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_10a0"
BB_10a0:
  %"phi.29" = phi  i32 [%"P44_to_i32", %"BB_80001090"], [%"phi.27", %"BB_1090"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".421" = xor i32 %"plop3_a_bit.8", 1
  %".422" = xor i32 %"plop3_b_bit.8", 1
  %".423" = xor i32 %"plop3_c_bit.8", 1
  %".424" = and i32 %".421", %"plop3_b_bit.8"
  %".425" = and i32 %".424", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".425", 0
  %"P21_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.12" = trunc i32 %"phi.29" to i1
  %"bra_cond_to_i32.12" = zext i1 %"bra_cond_trunc.12" to i32
  %"bra_cond_to_i1.12" = icmp ne i32 %"bra_cond_to_i32.12", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.12")
  br i1 %"branch_any.2", label %"BB_1070", label %"BB_10c0"
BB_10c0:
  %"iadd3_n1.11" = add i32 1024, 2048
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".427" = xor i32 %"plop3_a_bit.9", 1
  %".428" = xor i32 %"plop3_b_bit.9", 1
  %".429" = xor i32 %"plop3_c_bit.9", 1
  %".430" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".431" = and i32 %".430", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".431", 0
  %"P49_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".432" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".433" = zext i32 %"iadd3_n2.11" to i64
  %".434" = zext i32 24 to i64
  %".435" = shl i64 %".432", %".434"
  %".436" = and i64 %".435", 4294967295
  %".437" = add i64 %".436", %".433"
  %".438" = trunc i64 %".437" to i32
  br label %"BB_10f0"
BB_10f0:
  %"phi.30" = phi  i32 [%"P21_to_i32", %"BB_10c0"], [%"P27_to_i32", %"BB_1120"]
  %"phi.31" = phi  i32 [%"P49_to_i32", %"BB_10c0"], [%"phi.33", %"BB_1120"]
  %"cond_trunc.19" = trunc i32 %"phi.31" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_800010f0", label %"BB_1100"
BB_800010f0:
  %"elect_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"election.8" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.8")
  %"elect_p.8" = extractvalue {i32, i1} %"election.8", 1
  %"P25_to_i32" = zext i1 %"elect_p.8" to i32
  br label %"BB_1100"
BB_1100:
  %"phi.32" = phi  i32 [%"P25_to_i32", %"BB_800010f0"], [%"phi.30", %"BB_10f0"]
  %"utcbar_local_winoff" = and i32 %".438", 16777215
  %".442" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".443" = ptrtoint i8 addrspace(3)* %".442" to i32
  %".444" = lshr i32 %".438", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".443", i32 %".444")
  br label %"BB_1110"
BB_1110:
  %"cond_trunc.20" = trunc i32 %"phi.32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80001110", label %"BB_1120"
BB_80001110:
  %"lop3_a_trunc.3" = trunc i32 %"phi.32" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".448" = xor i32 %"plop3_a_bit.10", 1
  %".449" = xor i32 %"plop3_b_bit.10", 1
  %".450" = xor i32 %"plop3_c_bit.10", 1
  %".451" = and i32 %".448", %"plop3_b_bit.10"
  %".452" = and i32 %".451", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".452", 0
  %"P52_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_1120"
BB_1120:
  %"phi.33" = phi  i32 [%"P52_to_i32", %"BB_80001110"], [%"phi.31", %"BB_1110"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".454" = xor i32 %"plop3_a_bit.11", 1
  %".455" = xor i32 %"plop3_b_bit.11", 1
  %".456" = xor i32 %"plop3_c_bit.11", 1
  %".457" = and i32 %".454", %"plop3_b_bit.11"
  %".458" = and i32 %".457", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".458", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.13" = trunc i32 %"phi.33" to i1
  %"bra_cond_to_i32.13" = zext i1 %"bra_cond_trunc.13" to i32
  %"bra_cond_to_i1.13" = icmp ne i32 %"bra_cond_to_i32.13", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.13")
  br i1 %"branch_any.3", label %"BB_10f0", label %"BB_1140"
BB_1140:
  %"isetrp_cmp1.5" = icmp uge i32 %"tid_x", 32
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"lop3_a_cast_zext.12" = zext i1 1 to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".460" = xor i32 %"plop3_a_bit.12", 1
  %".461" = xor i32 %"plop3_b_bit.12", 1
  %".462" = xor i32 %"plop3_c_bit.12", 1
  %".463" = and i32 %"plop3_a_bit.12", %"plop3_b_bit.12"
  %".464" = and i32 %".463", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".464", 0
  %"P55_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_1180"
BB_1180:
  %"cond_trunc.21" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_15c0", label %"BB_1190"
BB_1190:
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".467" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".468" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".469" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".470" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldg_addr_r0_ext.18" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9220
  %"R309:R305_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.16"
  %"ldg_addr_r0_ext.19" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.19" = or i64 0, %"ldg_addr_r0_ext.19"
  %"ldg_addr_r1_ext.19" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.19" = shl i64 %"ldg_addr_r1_ext.19", 32
  %"ldg_addr_packed_1.19" = or i64 %"ldg_addr_packed_0.19", %"ldg_addr_r1_shift.19"
  %"ldg_addr_memaddr_offset_add.18" = add i64 %"ldg_addr_packed_1.19", 9216
  %"R309:R305_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  %"ldg.19" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.17"
  %"ldg_addr_r0_ext.20" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.20" = or i64 0, %"ldg_addr_r0_ext.20"
  %"ldg_addr_r1_ext.20" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.20" = shl i64 %"ldg_addr_r1_ext.20", 32
  %"ldg_addr_packed_1.20" = or i64 %"ldg_addr_packed_0.20", %"ldg_addr_r1_shift.20"
  %"ldg_addr_memaddr_offset_add.19" = add i64 %"ldg_addr_packed_1.20", 9224
  %"R309:R305_addr_ptr.18" = inttoptr i64 %"ldg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  %"ldg.20" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.18"
  %"ldg_addr_r0_ext.21" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.21" = or i64 0, %"ldg_addr_r0_ext.21"
  %"ldg_addr_r1_ext.21" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.21" = shl i64 %"ldg_addr_r1_ext.21", 32
  %"ldg_addr_packed_1.21" = or i64 %"ldg_addr_packed_0.21", %"ldg_addr_r1_shift.21"
  %"ldg_addr_memaddr_offset_add.20" = add i64 %"ldg_addr_packed_1.21", 9228
  %"R309:R305_addr_ptr.19" = inttoptr i64 %"ldg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  %"ldg.21" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.19"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.31", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".471" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".472" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".473" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".474" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"ldg_addr_r0_ext.22" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.22" = or i64 0, %"ldg_addr_r0_ext.22"
  %"ldg_addr_r1_ext.22" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.22" = shl i64 %"ldg_addr_r1_ext.22", 32
  %"ldg_addr_packed_1.22" = or i64 %"ldg_addr_packed_0.22", %"ldg_addr_r1_shift.22"
  %"ldg_addr_memaddr_offset_add.21" = add i64 %"ldg_addr_packed_1.22", 9232
  %"R309:R305_addr_ptr.20" = inttoptr i64 %"ldg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  %"ldg.22" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.20"
  %"ldg_addr_r0_ext.23" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.23" = or i64 0, %"ldg_addr_r0_ext.23"
  %"ldg_addr_r1_ext.23" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.23" = shl i64 %"ldg_addr_r1_ext.23", 32
  %"ldg_addr_packed_1.23" = or i64 %"ldg_addr_packed_0.23", %"ldg_addr_r1_shift.23"
  %"ldg_addr_memaddr_offset_add.22" = add i64 %"ldg_addr_packed_1.23", 9236
  %"R309:R305_addr_ptr.21" = inttoptr i64 %"ldg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  %"ldg.23" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.21"
  %"ldg_addr_r0_ext.24" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.24" = or i64 0, %"ldg_addr_r0_ext.24"
  %"ldg_addr_r1_ext.24" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.24" = shl i64 %"ldg_addr_r1_ext.24", 32
  %"ldg_addr_packed_1.24" = or i64 %"ldg_addr_packed_0.24", %"ldg_addr_r1_shift.24"
  %"ldg_addr_memaddr_offset_add.23" = add i64 %"ldg_addr_packed_1.24", 9240
  %"R309:R305_addr_ptr.22" = inttoptr i64 %"ldg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  %"ldg.24" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.22"
  %"ldg_addr_r0_ext.25" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.25" = or i64 0, %"ldg_addr_r0_ext.25"
  %"ldg_addr_r1_ext.25" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.25" = shl i64 %"ldg_addr_r1_ext.25", 32
  %"ldg_addr_packed_1.25" = or i64 %"ldg_addr_packed_0.25", %"ldg_addr_r1_shift.25"
  %"ldg_addr_memaddr_offset_add.24" = add i64 %"ldg_addr_packed_1.25", 9244
  %"R309:R305_addr_ptr.23" = inttoptr i64 %"ldg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  %"ldg.25" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.23"
  %"isetrp_cmp1.6" = icmp ne i32 %".468", %"ldg.18"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".475" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".476" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".477" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".478" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"ldg_addr_r0_ext.26" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.26" = or i64 0, %"ldg_addr_r0_ext.26"
  %"ldg_addr_r1_ext.26" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.26" = shl i64 %"ldg_addr_r1_ext.26", 32
  %"ldg_addr_packed_1.26" = or i64 %"ldg_addr_packed_0.26", %"ldg_addr_r1_shift.26"
  %"ldg_addr_memaddr_offset_add.25" = add i64 %"ldg_addr_packed_1.26", 9216
  %"R309:R305_addr_ptr.24" = inttoptr i64 %"ldg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  %"ldg.26" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.24"
  %"isetrp_src_trunc" = trunc i32 %"P56_to_i32" to i1
  %"isetrp_src_not" = xor i1 %"isetrp_src_trunc", -1
  %"isetrp_cmp1.7" = icmp eq i32 %".467", %"ldg.19"
  %"isetrp_src_to_i32.7" = zext i1 %"isetrp_src_not" to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"ldg_addr_r0_ext.27" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.27" = or i64 0, %"ldg_addr_r0_ext.27"
  %"ldg_addr_r1_ext.27" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.27" = shl i64 %"ldg_addr_r1_ext.27", 32
  %"ldg_addr_packed_1.27" = or i64 %"ldg_addr_packed_0.27", %"ldg_addr_r1_shift.27"
  %"ldg_addr_memaddr_offset_add.26" = add i64 %"ldg_addr_packed_1.27", 9220
  %"R309:R305_addr_ptr.25" = inttoptr i64 %"ldg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  %"ldg.27" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.25"
  %"isetrp_src_trunc.1" = trunc i32 %"P58_to_i32" to i1
  %"isetrp_cmp1.8" = icmp eq i32 %".469", %"ldg.20"
  %"isetrp_src_to_i32.8" = zext i1 %"isetrp_src_trunc.1" to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P59_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldg_addr_r0_ext.28" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.28" = or i64 0, %"ldg_addr_r0_ext.28"
  %"ldg_addr_r1_ext.28" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.28" = shl i64 %"ldg_addr_r1_ext.28", 32
  %"ldg_addr_packed_1.28" = or i64 %"ldg_addr_packed_0.28", %"ldg_addr_r1_shift.28"
  %"ldg_addr_memaddr_offset_add.27" = add i64 %"ldg_addr_packed_1.28", 9224
  %"R309:R305_addr_ptr.26" = inttoptr i64 %"ldg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  %"ldg.28" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.26"
  %"isetrp_src_trunc.2" = trunc i32 %"P59_to_i32" to i1
  %"isetrp_cmp1.9" = icmp eq i32 %".470", %"ldg.21"
  %"isetrp_src_to_i32.9" = zext i1 %"isetrp_src_trunc.2" to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P60_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldg_addr_r0_ext.29" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.29" = or i64 0, %"ldg_addr_r0_ext.29"
  %"ldg_addr_r1_ext.29" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.29" = shl i64 %"ldg_addr_r1_ext.29", 32
  %"ldg_addr_packed_1.29" = or i64 %"ldg_addr_packed_0.29", %"ldg_addr_r1_shift.29"
  %"ldg_addr_memaddr_offset_add.28" = add i64 %"ldg_addr_packed_1.29", 9228
  %"R309:R305_addr_ptr.27" = inttoptr i64 %"ldg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  %"ldg.29" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.27"
  %"isetrp_src_trunc.3" = trunc i32 %"P60_to_i32" to i1
  %"isetrp_cmp1.10" = icmp eq i32 %".471", %"ldg.22"
  %"isetrp_src_to_i32.10" = zext i1 %"isetrp_src_trunc.3" to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P62_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.31", 4
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".479" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".480" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".481" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".482" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"ldg_addr_r0_ext.30" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.30" = or i64 0, %"ldg_addr_r0_ext.30"
  %"ldg_addr_r1_ext.30" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.30" = shl i64 %"ldg_addr_r1_ext.30", 32
  %"ldg_addr_packed_1.30" = or i64 %"ldg_addr_packed_0.30", %"ldg_addr_r1_shift.30"
  %"ldg_addr_memaddr_offset_add.29" = add i64 %"ldg_addr_packed_1.30", 9232
  %"R309:R305_addr_ptr.28" = inttoptr i64 %"ldg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  %"ldg.30" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.28"
  %"ldg_addr_r0_ext.31" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.31" = or i64 0, %"ldg_addr_r0_ext.31"
  %"ldg_addr_r1_ext.31" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.31" = shl i64 %"ldg_addr_r1_ext.31", 32
  %"ldg_addr_packed_1.31" = or i64 %"ldg_addr_packed_0.31", %"ldg_addr_r1_shift.31"
  %"ldg_addr_memaddr_offset_add.30" = add i64 %"ldg_addr_packed_1.31", 9236
  %"R309:R305_addr_ptr.29" = inttoptr i64 %"ldg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  %"ldg.31" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.29"
  %"isetrp_src_trunc.4" = trunc i32 %"P62_to_i32" to i1
  %"isetrp_cmp1.11" = icmp eq i32 %".472", %"ldg.23"
  %"isetrp_src_to_i32.11" = zext i1 %"isetrp_src_trunc.4" to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P63_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"ldg_addr_r0_ext.32" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.32" = or i64 0, %"ldg_addr_r0_ext.32"
  %"ldg_addr_r1_ext.32" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.32" = shl i64 %"ldg_addr_r1_ext.32", 32
  %"ldg_addr_packed_1.32" = or i64 %"ldg_addr_packed_0.32", %"ldg_addr_r1_shift.32"
  %"ldg_addr_memaddr_offset_add.31" = add i64 %"ldg_addr_packed_1.32", 9244
  %"R309:R305_addr_ptr.30" = inttoptr i64 %"ldg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  %"ldg.32" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.30"
  %"isetrp_src_trunc.5" = trunc i32 %"P63_to_i32" to i1
  %"isetrp_cmp1.12" = icmp eq i32 %".473", %"ldg.24"
  %"isetrp_src_to_i32.12" = zext i1 %"isetrp_src_trunc.5" to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P64_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"ldg_addr_r0_ext.33" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.33" = or i64 0, %"ldg_addr_r0_ext.33"
  %"ldg_addr_r1_ext.33" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.33" = shl i64 %"ldg_addr_r1_ext.33", 32
  %"ldg_addr_packed_1.33" = or i64 %"ldg_addr_packed_0.33", %"ldg_addr_r1_shift.33"
  %"ldg_addr_memaddr_offset_add.32" = add i64 %"ldg_addr_packed_1.33", 9240
  %"R309:R305_addr_ptr.31" = inttoptr i64 %"ldg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  %"ldg.33" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.31"
  %"isetrp_src_trunc.6" = trunc i32 %"P64_to_i32" to i1
  %"isetrp_cmp1.13" = icmp eq i32 %".474", %"ldg.25"
  %"isetrp_src_to_i32.13" = zext i1 %"isetrp_src_trunc.6" to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P65_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".483" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".484" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".485" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".486" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"ldg_addr_r0_ext.34" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.34" = or i64 0, %"ldg_addr_r0_ext.34"
  %"ldg_addr_r1_ext.34" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.34" = shl i64 %"ldg_addr_r1_ext.34", 32
  %"ldg_addr_packed_1.34" = or i64 %"ldg_addr_packed_0.34", %"ldg_addr_r1_shift.34"
  %"ldg_addr_memaddr_offset_add.33" = add i64 %"ldg_addr_packed_1.34", 9220
  %"R309:R305_addr_ptr.32" = inttoptr i64 %"ldg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  %"ldg.34" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.32"
  %"isetrp_src_trunc.7" = trunc i32 %"P65_to_i32" to i1
  %"isetrp_cmp1.14" = icmp eq i32 %".475", %"ldg.26"
  %"isetrp_src_to_i32.14" = zext i1 %"isetrp_src_trunc.7" to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P67_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"ldg_addr_r0_ext.35" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.35" = or i64 0, %"ldg_addr_r0_ext.35"
  %"ldg_addr_r1_ext.35" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.35" = shl i64 %"ldg_addr_r1_ext.35", 32
  %"ldg_addr_packed_1.35" = or i64 %"ldg_addr_packed_0.35", %"ldg_addr_r1_shift.35"
  %"ldg_addr_memaddr_offset_add.34" = add i64 %"ldg_addr_packed_1.35", 9216
  %"R309:R305_addr_ptr.33" = inttoptr i64 %"ldg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  %"ldg.35" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.33"
  %"isetrp_src_trunc.8" = trunc i32 %"P67_to_i32" to i1
  %"isetrp_cmp1.15" = icmp eq i32 %".476", %"ldg.27"
  %"isetrp_src_to_i32.15" = zext i1 %"isetrp_src_trunc.8" to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P69_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  %"isetrp_src_trunc.9" = trunc i32 %"P69_to_i32" to i1
  %"isetrp_cmp1.16" = icmp eq i32 %".477", %"ldg.28"
  %"isetrp_src_to_i32.16" = zext i1 %"isetrp_src_trunc.9" to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P70_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"ldg_addr_r0_ext.36" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.36" = or i64 0, %"ldg_addr_r0_ext.36"
  %"ldg_addr_r1_ext.36" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.36" = shl i64 %"ldg_addr_r1_ext.36", 32
  %"ldg_addr_packed_1.36" = or i64 %"ldg_addr_packed_0.36", %"ldg_addr_r1_shift.36"
  %"ldg_addr_memaddr_offset_add.35" = add i64 %"ldg_addr_packed_1.36", 9224
  %"R309:R305_addr_ptr.34" = inttoptr i64 %"ldg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  %"ldg.36" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.34"
  %"isetrp_src_trunc.10" = trunc i32 %"P70_to_i32" to i1
  %"isetrp_cmp1.17" = icmp eq i32 %".478", %"ldg.29"
  %"isetrp_src_to_i32.17" = zext i1 %"isetrp_src_trunc.10" to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P71_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"ldg_addr_r0_ext.37" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.37" = or i64 0, %"ldg_addr_r0_ext.37"
  %"ldg_addr_r1_ext.37" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.37" = shl i64 %"ldg_addr_r1_ext.37", 32
  %"ldg_addr_packed_1.37" = or i64 %"ldg_addr_packed_0.37", %"ldg_addr_r1_shift.37"
  %"ldg_addr_memaddr_offset_add.36" = add i64 %"ldg_addr_packed_1.37", 9228
  %"R309:R305_addr_ptr.35" = inttoptr i64 %"ldg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  %"ldg.37" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.35"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.31", 4
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".487" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".488" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".489" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".490" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"isetrp_src_trunc.11" = trunc i32 %"P71_to_i32" to i1
  %"isetrp_cmp1.18" = icmp eq i32 %".479", %"ldg.30"
  %"isetrp_src_to_i32.18" = zext i1 %"isetrp_src_trunc.11" to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P74_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  %"ldg_addr_r0_ext.38" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.38" = or i64 0, %"ldg_addr_r0_ext.38"
  %"ldg_addr_r1_ext.38" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.38" = shl i64 %"ldg_addr_r1_ext.38", 32
  %"ldg_addr_packed_1.38" = or i64 %"ldg_addr_packed_0.38", %"ldg_addr_r1_shift.38"
  %"ldg_addr_memaddr_offset_add.37" = add i64 %"ldg_addr_packed_1.38", 9232
  %"R309:R305_addr_ptr.36" = inttoptr i64 %"ldg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  %"ldg.38" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.36"
  %"ldg_addr_r0_ext.39" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.39" = or i64 0, %"ldg_addr_r0_ext.39"
  %"ldg_addr_r1_ext.39" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.39" = shl i64 %"ldg_addr_r1_ext.39", 32
  %"ldg_addr_packed_1.39" = or i64 %"ldg_addr_packed_0.39", %"ldg_addr_r1_shift.39"
  %"ldg_addr_memaddr_offset_add.38" = add i64 %"ldg_addr_packed_1.39", 9236
  %"R309:R305_addr_ptr.37" = inttoptr i64 %"ldg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  %"ldg.39" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.37"
  %"isetrp_src_trunc.12" = trunc i32 %"P74_to_i32" to i1
  %"isetrp_cmp1.19" = icmp eq i32 %".480", %"ldg.31"
  %"isetrp_src_to_i32.19" = zext i1 %"isetrp_src_trunc.12" to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P75_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"ldg_addr_r0_ext.40" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.40" = or i64 0, %"ldg_addr_r0_ext.40"
  %"ldg_addr_r1_ext.40" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.40" = shl i64 %"ldg_addr_r1_ext.40", 32
  %"ldg_addr_packed_1.40" = or i64 %"ldg_addr_packed_0.40", %"ldg_addr_r1_shift.40"
  %"ldg_addr_memaddr_offset_add.39" = add i64 %"ldg_addr_packed_1.40", 9240
  %"R309:R305_addr_ptr.38" = inttoptr i64 %"ldg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  %"ldg.40" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.38"
  %"ldg_addr_r0_ext.41" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.41" = or i64 0, %"ldg_addr_r0_ext.41"
  %"ldg_addr_r1_ext.41" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.41" = shl i64 %"ldg_addr_r1_ext.41", 32
  %"ldg_addr_packed_1.41" = or i64 %"ldg_addr_packed_0.41", %"ldg_addr_r1_shift.41"
  %"ldg_addr_memaddr_offset_add.40" = add i64 %"ldg_addr_packed_1.41", 9244
  %"R309:R305_addr_ptr.39" = inttoptr i64 %"ldg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  %"ldg.41" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.39"
  %"isetrp_src_trunc.13" = trunc i32 %"P75_to_i32" to i1
  %"isetrp_cmp1.20" = icmp eq i32 %".481", %"ldg.33"
  %"isetrp_src_to_i32.20" = zext i1 %"isetrp_src_trunc.13" to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P76_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  %"isetrp_src_trunc.14" = trunc i32 %"P76_to_i32" to i1
  %"isetrp_cmp1.21" = icmp eq i32 %".482", %"ldg.32"
  %"isetrp_src_to_i32.21" = zext i1 %"isetrp_src_trunc.14" to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P77_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %"isetrp_src_trunc.15" = trunc i32 %"P77_to_i32" to i1
  %"isetrp_cmp1.22" = icmp eq i32 %".483", %"ldg.35"
  %"isetrp_src_to_i32.22" = zext i1 %"isetrp_src_trunc.15" to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P78_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"isetrp_src_trunc.16" = trunc i32 %"P78_to_i32" to i1
  %"isetrp_cmp1.23" = icmp eq i32 %".484", %"ldg.34"
  %"isetrp_src_to_i32.23" = zext i1 %"isetrp_src_trunc.16" to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P81_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"isetrp_src_trunc.17" = trunc i32 %"P81_to_i32" to i1
  %"isetrp_cmp1.24" = icmp eq i32 %".485", %"ldg.36"
  %"isetrp_src_to_i32.24" = zext i1 %"isetrp_src_trunc.17" to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P82_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %"isetrp_src_trunc.18" = trunc i32 %"P82_to_i32" to i1
  %"isetrp_cmp1.25" = icmp eq i32 %".486", %"ldg.37"
  %"isetrp_src_to_i32.25" = zext i1 %"isetrp_src_trunc.18" to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P84_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  %"isetrp_src_trunc.19" = trunc i32 %"P84_to_i32" to i1
  %"isetrp_cmp1.26" = icmp eq i32 %".487", %"ldg.38"
  %"isetrp_src_to_i32.26" = zext i1 %"isetrp_src_trunc.19" to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P85_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"isetrp_src_trunc.20" = trunc i32 %"P85_to_i32" to i1
  %"isetrp_cmp1.27" = icmp eq i32 %".488", %"ldg.39"
  %"isetrp_src_to_i32.27" = zext i1 %"isetrp_src_trunc.20" to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P86_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %"isetrp_src_trunc.21" = trunc i32 %"P86_to_i32" to i1
  %"isetrp_cmp1.28" = icmp eq i32 %".489", %"ldg.40"
  %"isetrp_src_to_i32.28" = zext i1 %"isetrp_src_trunc.21" to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P88_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"isetrp_src_trunc.22" = trunc i32 %"P88_to_i32" to i1
  %"isetrp_cmp1.29" = icmp eq i32 %".490", %"ldg.41"
  %"isetrp_src_to_i32.29" = zext i1 %"isetrp_src_trunc.22" to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = and i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P89_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  br label %"BB_15c0"
BB_15c0:
  %"phi.34" = phi  i32 [%"P89_to_i32", %"BB_1190"], [%"P55_to_i32", %"BB_1180"]
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.12" = add i32 1024, 2048
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", 0
  %".492" = zext i32 0 to i64
  %".493" = zext i32 0 to i64
  %".494" = shl i64 %".493", 32
  %"shf_concat.12" = or i64 %".492", %".494"
  %"shf_shift_64.12" = zext i32 31 to i64
  %".495" = shl i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_result.12" = trunc i64 %".495" to i32
  %".496" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".497" = zext i32 %"iadd3_n2.12" to i64
  %".498" = zext i32 24 to i64
  %".499" = shl i64 %".496", %".498"
  %".500" = and i64 %".499", 4294967295
  %".501" = add i64 %".500", %".497"
  %".502" = trunc i64 %".501" to i32
  %"mbar_shared_winoff.1" = and i32 %".502", 16777215
  %".503" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".503" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.12", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P31_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_1620"
BB_1620:
  %"cond_trunc.22" = trunc i32 %"P31_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.22", -1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_2760", label %"BB_1630"
BB_2760:
  %"mbar_shared_winoff.2" = and i32 %".502", 16777215
  %".506" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".506" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.12", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P32_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_2770"
BB_2770:
  %"cond_trunc.23" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.23", -1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_2760", label %"BB_1630"
BB_1630:
  %".509" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".510" = bitcast i8* %".509" to i64*
  %"ldc_const.3" = load i64, i64* %".510"
  %"R19:R18_r0" = trunc i64 %"ldc_const.3" to i32
  %"R19:R18_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"imad_tmp.32" = mul i32 %"tid_x", 40
  %"imad.34" = add i32 %"imad_tmp.32", 0
  %"imad_tmp.33" = mul i32 %"imad.32", 1
  %"imad.35" = add i32 %"imad_tmp.33", %"imad.33"
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.33")
  %".511" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".512" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".513" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".514" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.33", 4
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".515" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".516" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".517" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".518" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.34" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.36" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R19:R18_r0.1" = trunc i64 %"imad.36" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"imad.36", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R118:R65_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".511", i32 addrspace(1)* %"R118:R65_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R118:R65_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".512", i32 addrspace(1)* %"R118:R65_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R118:R65_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".513", i32 addrspace(1)* %"R118:R65_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R118:R65_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".514", i32 addrspace(1)* %"R118:R65_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R118:R65_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".515", i32 addrspace(1)* %"R118:R65_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.33", 8
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".524" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".525" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".526" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".527" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R118:R65_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".516", i32 addrspace(1)* %"R118:R65_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R118:R65_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".517", i32 addrspace(1)* %"R118:R65_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R118:R65_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".518", i32 addrspace(1)* %"R118:R65_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.33", 12
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".531" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".532" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".533" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".534" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R118:R65_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".524", i32 addrspace(1)* %"R118:R65_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R118:R65_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".525", i32 addrspace(1)* %"R118:R65_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R118:R65_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".526", i32 addrspace(1)* %"R118:R65_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R118:R65_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".527", i32 addrspace(1)* %"R118:R65_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R118:R65_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".531", i32 addrspace(1)* %"R118:R65_addr_ptr.12"
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".540" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".541" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".542" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".543" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R118:R65_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".532", i32 addrspace(1)* %"R118:R65_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R118:R65_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".533", i32 addrspace(1)* %"R118:R65_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R118:R65_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".534", i32 addrspace(1)* %"R118:R65_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.35", 4
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".547" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".548" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".549" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".550" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R118:R65_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".540", i32 addrspace(1)* %"R118:R65_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R118:R65_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".541", i32 addrspace(1)* %"R118:R65_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R118:R65_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".542", i32 addrspace(1)* %"R118:R65_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R118:R65_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".543", i32 addrspace(1)* %"R118:R65_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R118:R65_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".547", i32 addrspace(1)* %"R118:R65_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.33", 16
  %"ldtm.12" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".556" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 0
  %".557" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 1
  %".558" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 2
  %".559" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R118:R65_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".548", i32 addrspace(1)* %"R118:R65_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R118:R65_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".549", i32 addrspace(1)* %"R118:R65_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R118:R65_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".550", i32 addrspace(1)* %"R118:R65_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.33", 20
  %"ldtm.13" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".563" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 0
  %".564" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 1
  %".565" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 2
  %".566" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R118:R65_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".556", i32 addrspace(1)* %"R118:R65_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R118:R65_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".557", i32 addrspace(1)* %"R118:R65_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R118:R65_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".558", i32 addrspace(1)* %"R118:R65_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R118:R65_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".559", i32 addrspace(1)* %"R118:R65_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R118:R65_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".563", i32 addrspace(1)* %"R118:R65_addr_ptr.28"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.33", 24
  %"ldtm.14" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".572" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 0
  %".573" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 1
  %".574" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 2
  %".575" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 3
  %"stg_addr_r0_ext.29" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R118:R65_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".564", i32 addrspace(1)* %"R118:R65_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R118:R65_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".565", i32 addrspace(1)* %"R118:R65_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R118:R65_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".566", i32 addrspace(1)* %"R118:R65_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.33", 28
  %"ldtm.15" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".579" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 0
  %".580" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 1
  %".581" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 2
  %".582" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 3
  %"stg_addr_r0_ext.32" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 128
  %"R118:R65_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".572", i32 addrspace(1)* %"R118:R65_addr_ptr.32"
  %"stg_addr_r0_ext.33" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 132
  %"R118:R65_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".573", i32 addrspace(1)* %"R118:R65_addr_ptr.33"
  %"stg_addr_r0_ext.34" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 136
  %"R118:R65_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".574", i32 addrspace(1)* %"R118:R65_addr_ptr.34"
  %"stg_addr_r0_ext.35" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 140
  %"R118:R65_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".575", i32 addrspace(1)* %"R118:R65_addr_ptr.35"
  %"stg_addr_r0_ext.36" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 144
  %"R118:R65_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".579", i32 addrspace(1)* %"R118:R65_addr_ptr.36"
  %"stg_addr_r0_ext.37" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 148
  %"R118:R65_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".580", i32 addrspace(1)* %"R118:R65_addr_ptr.37"
  %"stg_addr_r0_ext.38" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 152
  %"R118:R65_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".581", i32 addrspace(1)* %"R118:R65_addr_ptr.38"
  %"stg_addr_r0_ext.39" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 156
  %"R118:R65_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".582", i32 addrspace(1)* %"R118:R65_addr_ptr.39"
  br label %"BB_1ab0"
BB_1ab0:
  %"cond_trunc.24" = trunc i32 %"phi.34" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_1af0", label %"BB_1ac0"
BB_1ac0:
  %"ldg_addr_r0_ext.42" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.42" = or i64 0, %"ldg_addr_r0_ext.42"
  %"ldg_addr_r1_ext.42" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.42" = shl i64 %"ldg_addr_r1_ext.42", 32
  %"ldg_addr_packed_1.42" = or i64 %"ldg_addr_packed_0.42", %"ldg_addr_r1_shift.42"
  %"ldg_addr_memaddr_offset_add.41" = add i64 %"ldg_addr_packed_1.42", 9216
  %"R309:R305_addr_ptr.40" = inttoptr i64 %"ldg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  %"ldg.42" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.40"
  %".593" = xor i32 0, -1
  %".594" = xor i32 %"ldg.42", -1
  %".595" = xor i32 0, -1
  %".596" = and i32 %".593", %".594"
  %".597" = and i32 %".596", %".595"
  %".598" = and i32 %".593", %".594"
  %".599" = and i32 %".598", 0
  %".600" = or i32 %".597", %".599"
  %".601" = and i32 0, %".594"
  %".602" = and i32 %".601", %".595"
  %".603" = or i32 %".600", %".602"
  %".604" = and i32 0, %".594"
  %".605" = and i32 %".604", 0
  %".606" = or i32 %".603", %".605"
  %"stg_addr_r0_ext.40" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 64
  %"R118:R65_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".606", i32 addrspace(1)* %"R118:R65_addr_ptr.40"
  br label %"BB_1af0"
BB_1af0:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_1b20"
BB_1b20:
  %"cond_trunc.25" = trunc i32 %"P94_to_i32" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80001b20", label %"BB_1b30"
BB_1b30:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".611" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".611" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.34" = mul i32 0, 0
  %"imad.37" = add i32 %"imad_tmp.34", 1
  %".612" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".613" = zext i32 64 to i64
  %".614" = zext i32 24 to i64
  %".615" = shl i64 %".612", %".614"
  %".616" = and i64 %".615", 4294967295
  %".617" = add i64 %".616", %".613"
  %".618" = trunc i64 %".617" to i32
  %"lds_addr_memaddr_offset_add.5" = add i32 %".618", 20
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".619" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".619" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".620" = xor i32 %"lds.4", -1
  %".621" = xor i32 65535, -1
  %".622" = xor i32 0, -1
  %".623" = and i32 %"lds.4", 65535
  %".624" = and i32 %".623", %".622"
  %".625" = and i32 %"lds.4", 65535
  %".626" = and i32 %".625", 0
  %".627" = or i32 %".624", %".626"
  %".628" = zext i32 0 to i64
  %".629" = zext i32 %".627" to i64
  %".630" = shl i64 %".629", 32
  %"shf_concat.13" = or i64 %".628", %".630"
  %"shf_shift_64.13" = zext i32 5 to i64
  %".631" = lshr i64 %"shf_concat.13", %"shf_shift_64.13"
  %"shf_hi.2" = lshr i64 %".631", 32
  %"shf_result.13" = trunc i64 %"shf_hi.2" to i32
  %".632" = zext i32 %"imad.37" to i64
  %".633" = zext i32 0 to i64
  %".634" = shl i64 %".633", 32
  %"shf_concat.14" = or i64 %".632", %".634"
  %"shf_shift_64.14" = zext i32 %"shf_result.13" to i64
  %".635" = shl i64 %"shf_concat.14", %"shf_shift_64.14"
  %"shf_result.14" = trunc i64 %".635" to i32
  %".636" = xor i32 %"lds.5", -1
  %".637" = xor i32 %"shf_result.14", -1
  %".638" = xor i32 0, -1
  %".639" = and i32 %"lds.5", %"shf_result.14"
  %".640" = and i32 %".639", %".638"
  %".641" = and i32 %"lds.5", %"shf_result.14"
  %".642" = and i32 %".641", 0
  %".643" = or i32 %".640", %".642"
  %"isetrp_cmp1.30" = icmp ne i32 %".643", %"shf_result.14"
  %"isetrp_src_to_i32.30" = zext i1 1 to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = and i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P91_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  br label %"BB_1be0"
BB_1be0:
  %"cond_trunc.26" = trunc i32 %"P91_to_i32" to i1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_trunc.26" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_1d40_27c0", label %"BB_1bf0"
BB_1bf0:
  %"lds_addr_memaddr_offset_add.6" = add i32 %".618", 24
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".646" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".646" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %".647" = xor i32 %"lds.6", -1
  %".648" = xor i32 %"shf_result.14", -1
  %".649" = xor i32 0, -1
  %".650" = and i32 %"lds.6", %"shf_result.14"
  %".651" = and i32 %".650", %".649"
  %".652" = and i32 %"lds.6", %"shf_result.14"
  %".653" = and i32 %".652", 0
  %".654" = or i32 %".651", %".653"
  %"isetrp_cmp1.31" = icmp ne i32 %".654", %"shf_result.14"
  %"isetrp_src_to_i32.31" = zext i1 1 to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P95_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  br label %"BB_1c20"
BB_1c20:
  %"cond_trunc.27" = trunc i32 %"P95_to_i32" to i1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_trunc.27" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_1d10_2790", label %"BB_1c30"
BB_1c30:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".657" = xor i32 0, -1
  %".658" = xor i32 %"shf_result.14", -1
  %".659" = xor i32 0, -1
  %".660" = and i32 %".657", %".658"
  %".661" = and i32 %".660", %".659"
  %".662" = and i32 %".657", %".658"
  %".663" = and i32 %".662", 0
  %".664" = or i32 %".661", %".663"
  %".665" = and i32 0, %".658"
  %".666" = and i32 %".665", %".659"
  %".667" = or i32 %".664", %".666"
  %".668" = and i32 0, %".658"
  %".669" = and i32 %".668", 0
  %".670" = or i32 %".667", %".669"
  %"imad_tmp.35" = mul i32 0, 0
  %"imad.38" = add i32 %"imad_tmp.35", %".670"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.38", i32 %"redux_mask")
  %".671" = xor i32 %".670", -1
  %".672" = call i32 @"llvm.cttz.i32"(i32 %".671", i1 0)
  %".673" = shl i32 %".672", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".673") convergent
  %"isetrp_cmp1.32" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.32" = zext i1 1 to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P96_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %"imad_tmp.36" = mul i32 0, 0
  %"imad.39" = add i32 %"imad_tmp.36", %"redux_sync_and"
  br label %"BB_1cd0"
BB_1cd0:
  %"cond_trunc.28" = trunc i32 %"P96_to_i32" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_80001cd0", label %"BB_1d50"
BB_80001cd0:
  %"atoms_addr_memaddr_offset_add.10" = add i32 %".618", 20
  %"atoms_shared_addr_winoff.10" = and i32 %"atoms_addr_memaddr_offset_add.10", 16777215
  %".677" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.10"
  %"atoms_ptr.10" = bitcast i8 addrspace(3)* %".677" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.10", i32 %"imad.39" monotonic
  %"atoms_addr_memaddr_offset_add.11" = add i32 %".618", 24
  %"atoms_shared_addr_winoff.11" = and i32 %"atoms_addr_memaddr_offset_add.11", 16777215
  %".678" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.11"
  %"atoms_ptr.11" = bitcast i8 addrspace(3)* %".678" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.11", i32 %"imad.39" monotonic
  br label %"BB_1d50"
BB_1d10_2790:
  call void @"llvm.trap"()
  br label %"BB_1d50"
BB_1d40_27c0:
  call void @"llvm.trap"()
  br label %"BB_1d50"
BB_1d50:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.7" = add i32 %".16", 2060
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.7", 16777215
  %".682" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".682" to i32 addrspace(3)*
  %"lds.7" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.7"
  %"imad_tmp.37" = mul i32 0, 0
  %"imad.40" = add i32 %"imad_tmp.37", 1
  %".683" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".684" = zext i32 64 to i64
  %".685" = zext i32 24 to i64
  %".686" = shl i64 %".683", %".685"
  %".687" = and i64 %".686", 4294967295
  %".688" = add i64 %".687", %".684"
  %".689" = trunc i64 %".688" to i32
  %"lds_addr_memaddr_offset_add.8" = add i32 %".689", 20
  %"lds_shared_addr_winoff.8" = and i32 %"lds_addr_memaddr_offset_add.8", 16777215
  %".690" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.8"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".690" to i32 addrspace(3)*
  %"lds.8" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.8"
  %".691" = xor i32 %"lds.7", -1
  %".692" = xor i32 65535, -1
  %".693" = xor i32 0, -1
  %".694" = and i32 %"lds.7", 65535
  %".695" = and i32 %".694", %".693"
  %".696" = and i32 %"lds.7", 65535
  %".697" = and i32 %".696", 0
  %".698" = or i32 %".695", %".697"
  %".699" = zext i32 0 to i64
  %".700" = zext i32 %".698" to i64
  %".701" = shl i64 %".700", 32
  %"shf_concat.15" = or i64 %".699", %".701"
  %"shf_shift_64.15" = zext i32 5 to i64
  %".702" = lshr i64 %"shf_concat.15", %"shf_shift_64.15"
  %"shf_hi.3" = lshr i64 %".702", 32
  %"shf_result.15" = trunc i64 %"shf_hi.3" to i32
  %".703" = zext i32 %"imad.40" to i64
  %".704" = zext i32 0 to i64
  %".705" = shl i64 %".704", 32
  %"shf_concat.16" = or i64 %".703", %".705"
  %"shf_shift_64.16" = zext i32 %"shf_result.15" to i64
  %".706" = shl i64 %"shf_concat.16", %"shf_shift_64.16"
  %"shf_result.16" = trunc i64 %".706" to i32
  %".707" = xor i32 %"lds.8", -1
  %".708" = xor i32 %"shf_result.16", -1
  %".709" = xor i32 0, -1
  %".710" = and i32 %"lds.8", %"shf_result.16"
  %".711" = and i32 %".710", %".709"
  %".712" = and i32 %"lds.8", %"shf_result.16"
  %".713" = and i32 %".712", 0
  %".714" = or i32 %".711", %".713"
  %"isetrp_cmp1.33" = icmp ne i32 %".714", %"shf_result.16"
  %"isetrp_src_to_i32.33" = zext i1 1 to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P97_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  br label %"BB_1e20"
BB_1e20:
  %"cond_trunc.29" = trunc i32 %"P97_to_i32" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_1f80_27c0", label %"BB_1e30"
BB_1e30:
  %"lds_addr_memaddr_offset_add.9" = add i32 %".689", 24
  %"lds_shared_addr_winoff.9" = and i32 %"lds_addr_memaddr_offset_add.9", 16777215
  %".717" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.9"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".717" to i32 addrspace(3)*
  %"lds.9" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.9"
  %".718" = xor i32 %"lds.9", -1
  %".719" = xor i32 %"shf_result.16", -1
  %".720" = xor i32 0, -1
  %".721" = and i32 %"lds.9", %"shf_result.16"
  %".722" = and i32 %".721", %".720"
  %".723" = and i32 %"lds.9", %"shf_result.16"
  %".724" = and i32 %".723", 0
  %".725" = or i32 %".722", %".724"
  %"isetrp_cmp1.34" = icmp ne i32 %".725", %"shf_result.16"
  %"isetrp_src_to_i32.34" = zext i1 1 to i32
  %"isetrp_src_to_i1.34" = icmp ne i32 %"isetrp_src_to_i32.34", 0
  %"isetrp_cmp2.34" = and i1 %"isetrp_cmp1.34", %"isetrp_src_to_i1.34"
  %"P98_to_i32" = zext i1 %"isetrp_cmp2.34" to i32
  br label %"BB_1e60"
BB_1e60:
  %"cond_trunc.30" = trunc i32 %"P98_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_1f50_2790", label %"BB_1e70"
BB_1e70:
  %"activemask.1" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.1" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.1" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.1", i1 0)
  %"flo.1" = sub i32 31, %"flo_clz.1"
  %".728" = xor i32 0, -1
  %".729" = xor i32 %"shf_result.16", -1
  %".730" = xor i32 0, -1
  %".731" = and i32 %".728", %".729"
  %".732" = and i32 %".731", %".730"
  %".733" = and i32 %".728", %".729"
  %".734" = and i32 %".733", 0
  %".735" = or i32 %".732", %".734"
  %".736" = and i32 0, %".729"
  %".737" = and i32 %".736", %".730"
  %".738" = or i32 %".735", %".737"
  %".739" = and i32 0, %".729"
  %".740" = and i32 %".739", 0
  %".741" = or i32 %".738", %".740"
  %"imad_tmp.38" = mul i32 0, 0
  %"imad.41" = add i32 %"imad_tmp.38", %".741"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.41", i32 %"redux_mask.1")
  %".742" = xor i32 %".741", -1
  %".743" = call i32 @"llvm.cttz.i32"(i32 %".742", i1 0)
  %".744" = shl i32 %".743", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".744") convergent
  %"isetrp_cmp1.35" = icmp eq i32 %"laneid.1", %"flo.1"
  %"isetrp_src_to_i32.35" = zext i1 1 to i32
  %"isetrp_src_to_i1.35" = icmp ne i32 %"isetrp_src_to_i32.35", 0
  %"isetrp_cmp2.35" = and i1 %"isetrp_cmp1.35", %"isetrp_src_to_i1.35"
  %"P99_to_i32" = zext i1 %"isetrp_cmp2.35" to i32
  %"imad_tmp.39" = mul i32 0, 0
  %"imad.42" = add i32 %"imad_tmp.39", %"redux_sync_and.1"
  br label %"BB_1f10"
BB_1f10:
  %"cond_trunc.31" = trunc i32 %"P99_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_80001f10", label %"BB_1f90"
BB_80001f10:
  %"atoms_addr_memaddr_offset_add.12" = add i32 %".689", 20
  %"atoms_shared_addr_winoff.12" = and i32 %"atoms_addr_memaddr_offset_add.12", 16777215
  %".748" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.12"
  %"atoms_ptr.12" = bitcast i8 addrspace(3)* %".748" to i32 addrspace(3)*
  %"atoms_and.2" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.12", i32 %"imad.42" monotonic
  %"atoms_addr_memaddr_offset_add.13" = add i32 %".689", 24
  %"atoms_shared_addr_winoff.13" = and i32 %"atoms_addr_memaddr_offset_add.13", 16777215
  %".749" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.13"
  %"atoms_ptr.13" = bitcast i8 addrspace(3)* %".749" to i32 addrspace(3)*
  %"atoms_and.3" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.13", i32 %"imad.42" monotonic
  br label %"BB_1f90"
BB_1f50_2790:
  call void @"llvm.trap"()
  br label %"BB_1f90"
BB_1f80_27c0:
  call void @"llvm.trap"()
  br label %"BB_1f90"
BB_1f90:
  %"s2ur_cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.10" = add i32 %".16", 2064
  %"lds_shared_addr_winoff.10" = and i32 %"lds_addr_memaddr_offset_add.10", 16777215
  %".753" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.10"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".753" to i32 addrspace(3)*
  %"lds.10" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.10"
  %"imad_tmp.40" = mul i32 0, 0
  %"imad.43" = add i32 %"imad_tmp.40", 3
  %".754" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".755" = zext i32 64 to i64
  %".756" = zext i32 24 to i64
  %".757" = shl i64 %".754", %".756"
  %".758" = and i64 %".757", 4294967295
  %".759" = add i64 %".758", %".755"
  %".760" = trunc i64 %".759" to i32
  %"lds_addr_memaddr_offset_add.11" = add i32 %".760", 20
  %"lds_shared_addr_winoff.11" = and i32 %"lds_addr_memaddr_offset_add.11", 16777215
  %".761" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.11"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".761" to i32 addrspace(3)*
  %"lds.11" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.11"
  %".762" = xor i32 %"lds.10", -1
  %".763" = xor i32 65535, -1
  %".764" = xor i32 0, -1
  %".765" = and i32 %"lds.10", 65535
  %".766" = and i32 %".765", %".764"
  %".767" = and i32 %"lds.10", 65535
  %".768" = and i32 %".767", 0
  %".769" = or i32 %".766", %".768"
  %".770" = zext i32 0 to i64
  %".771" = zext i32 %".769" to i64
  %".772" = shl i64 %".771", 32
  %"shf_concat.17" = or i64 %".770", %".772"
  %"shf_shift_64.17" = zext i32 5 to i64
  %".773" = lshr i64 %"shf_concat.17", %"shf_shift_64.17"
  %"shf_hi.4" = lshr i64 %".773", 32
  %"shf_result.17" = trunc i64 %"shf_hi.4" to i32
  %".774" = zext i32 %"imad.43" to i64
  %".775" = zext i32 0 to i64
  %".776" = shl i64 %".775", 32
  %"shf_concat.18" = or i64 %".774", %".776"
  %"shf_shift_64.18" = zext i32 %"shf_result.17" to i64
  %".777" = shl i64 %"shf_concat.18", %"shf_shift_64.18"
  %"shf_result.18" = trunc i64 %".777" to i32
  %".778" = xor i32 %"lds.11", -1
  %".779" = xor i32 %"shf_result.18", -1
  %".780" = xor i32 0, -1
  %".781" = and i32 %"lds.11", %"shf_result.18"
  %".782" = and i32 %".781", %".780"
  %".783" = and i32 %"lds.11", %"shf_result.18"
  %".784" = and i32 %".783", 0
  %".785" = or i32 %".782", %".784"
  %"isetrp_cmp1.36" = icmp ne i32 %".785", %"shf_result.18"
  %"isetrp_src_to_i32.36" = zext i1 1 to i32
  %"isetrp_src_to_i1.36" = icmp ne i32 %"isetrp_src_to_i32.36", 0
  %"isetrp_cmp2.36" = and i1 %"isetrp_cmp1.36", %"isetrp_src_to_i1.36"
  %"P100_to_i32" = zext i1 %"isetrp_cmp2.36" to i32
  %"imad_tmp.41" = mul i32 0, 0
  %"imad.44" = add i32 %"imad_tmp.41", 1
  %".786" = zext i32 %"imad.44" to i64
  %".787" = zext i32 0 to i64
  %".788" = shl i64 %".787", 32
  %"shf_concat.19" = or i64 %".786", %".788"
  %"shf_shift_64.19" = zext i32 %"shf_result.17" to i64
  %".789" = shl i64 %"shf_concat.19", %"shf_shift_64.19"
  %"shf_result.19" = trunc i64 %".789" to i32
  br label %"BB_2080"
BB_2080:
  %"cond_trunc.32" = trunc i32 %"P100_to_i32" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_2210_27c0", label %"BB_2090"
BB_2090:
  %"lds_addr_memaddr_offset_add.12" = add i32 %".760", 24
  %"lds_shared_addr_winoff.12" = and i32 %"lds_addr_memaddr_offset_add.12", 16777215
  %".792" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.12"
  %"lds_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".792" to i32 addrspace(3)*
  %"lds.12" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.12"
  %".793" = xor i32 %"lds.12", -1
  %".794" = xor i32 %"shf_result.19", -1
  %".795" = xor i32 0, -1
  %".796" = and i32 %"lds.12", %"shf_result.19"
  %".797" = and i32 %".796", %".795"
  %".798" = and i32 %"lds.12", %"shf_result.19"
  %".799" = and i32 %".798", 0
  %".800" = or i32 %".797", %".799"
  %"isetrp_cmp1.37" = icmp ne i32 %".800", %"shf_result.19"
  %"isetrp_src_to_i32.37" = zext i1 1 to i32
  %"isetrp_src_to_i1.37" = icmp ne i32 %"isetrp_src_to_i32.37", 0
  %"isetrp_cmp2.37" = and i1 %"isetrp_cmp1.37", %"isetrp_src_to_i1.37"
  %"P102_to_i32" = zext i1 %"isetrp_cmp2.37" to i32
  br label %"BB_20c0"
BB_20c0:
  %"cond_trunc.33" = trunc i32 %"P102_to_i32" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_21e0_2790", label %"BB_20d0"
BB_20d0:
  %"activemask.2" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.2" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".803" = xor i32 0, -1
  %".804" = xor i32 %"shf_result.19", -1
  %".805" = xor i32 0, -1
  %".806" = and i32 %".803", %".804"
  %".807" = and i32 %".806", %".805"
  %".808" = and i32 %".803", %".804"
  %".809" = and i32 %".808", 0
  %".810" = or i32 %".807", %".809"
  %".811" = and i32 0, %".804"
  %".812" = and i32 %".811", %".805"
  %".813" = or i32 %".810", %".812"
  %".814" = and i32 0, %".804"
  %".815" = and i32 %".814", 0
  %".816" = or i32 %".813", %".815"
  %"flo_clz.2" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.2", i1 0)
  %"flo.2" = sub i32 31, %"flo_clz.2"
  %"redux_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.2" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".816", i32 %"redux_mask.2")
  %".817" = xor i32 0, -1
  %".818" = xor i32 %"shf_result.18", -1
  %".819" = xor i32 0, -1
  %".820" = and i32 %".817", %".818"
  %".821" = and i32 %".820", %".819"
  %".822" = and i32 %".817", %".818"
  %".823" = and i32 %".822", 0
  %".824" = or i32 %".821", %".823"
  %".825" = and i32 0, %".818"
  %".826" = and i32 %".825", %".819"
  %".827" = or i32 %".824", %".826"
  %".828" = and i32 0, %".818"
  %".829" = and i32 %".828", 0
  %".830" = or i32 %".827", %".829"
  %"imad_tmp.42" = mul i32 0, 0
  %"imad.45" = add i32 %"imad_tmp.42", %".830"
  %"redux_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.3" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.45", i32 %"redux_mask.3")
  %".831" = xor i32 %".830", -1
  %".832" = call i32 @"llvm.cttz.i32"(i32 %".831", i1 0)
  %".833" = shl i32 %".832", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".833") convergent
  %"imad_tmp.43" = mul i32 0, 0
  %"imad.46" = add i32 %"imad_tmp.43", %"redux_sync_and.2"
  %"isetrp_cmp1.38" = icmp eq i32 %"laneid.2", %"flo.2"
  %"isetrp_src_to_i32.38" = zext i1 1 to i32
  %"isetrp_src_to_i1.38" = icmp ne i32 %"isetrp_src_to_i32.38", 0
  %"isetrp_cmp2.38" = and i1 %"isetrp_cmp1.38", %"isetrp_src_to_i1.38"
  %"P104_to_i32" = zext i1 %"isetrp_cmp2.38" to i32
  %"imad_tmp.44" = mul i32 0, 0
  %"imad.47" = add i32 %"imad_tmp.44", %"redux_sync_and.3"
  br label %"BB_21a0"
BB_21a0:
  %"cond_trunc.34" = trunc i32 %"P104_to_i32" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_800021a0", label %"BB_2220"
BB_800021a0:
  %"atoms_addr_memaddr_offset_add.14" = add i32 %".760", 20
  %"atoms_shared_addr_winoff.14" = and i32 %"atoms_addr_memaddr_offset_add.14", 16777215
  %".837" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.14"
  %"atoms_ptr.14" = bitcast i8 addrspace(3)* %".837" to i32 addrspace(3)*
  %"atoms_and.4" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.14", i32 %"imad.47" monotonic
  %"atoms_addr_memaddr_offset_add.15" = add i32 %".760", 24
  %"atoms_shared_addr_winoff.15" = and i32 %"atoms_addr_memaddr_offset_add.15", 16777215
  %".838" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.15"
  %"atoms_ptr.15" = bitcast i8 addrspace(3)* %".838" to i32 addrspace(3)*
  %"atoms_and.5" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.15", i32 %"imad.46" monotonic
  br label %"BB_2220"
BB_21e0_2790:
  call void @"llvm.trap"()
  br label %"BB_2220"
BB_2210_27c0:
  call void @"llvm.trap"()
  br label %"BB_2220"
BB_2220:
  %"s2ur_cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.13" = add i32 %".16", 2068
  %"lds_shared_addr_winoff.13" = and i32 %"lds_addr_memaddr_offset_add.13", 16777215
  %".842" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.13"
  %"lds_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".842" to i32 addrspace(3)*
  %"lds.13" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.13"
  %"imad_tmp.45" = mul i32 0, 0
  %"imad.48" = add i32 %"imad_tmp.45", 15
  %".843" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".844" = zext i32 64 to i64
  %".845" = zext i32 24 to i64
  %".846" = shl i64 %".843", %".845"
  %".847" = and i64 %".846", 4294967295
  %".848" = add i64 %".847", %".844"
  %".849" = trunc i64 %".848" to i32
  %"lds_addr_memaddr_offset_add.14" = add i32 %".849", 20
  %"lds_shared_addr_winoff.14" = and i32 %"lds_addr_memaddr_offset_add.14", 16777215
  %".850" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.14"
  %"lds_shared_addr_cast.14" = bitcast i8 addrspace(3)* %".850" to i32 addrspace(3)*
  %"lds.14" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.14"
  %".851" = xor i32 %"lds.13", -1
  %".852" = xor i32 65535, -1
  %".853" = xor i32 0, -1
  %".854" = and i32 %"lds.13", 65535
  %".855" = and i32 %".854", %".853"
  %".856" = and i32 %"lds.13", 65535
  %".857" = and i32 %".856", 0
  %".858" = or i32 %".855", %".857"
  %".859" = zext i32 0 to i64
  %".860" = zext i32 %".858" to i64
  %".861" = shl i64 %".860", 32
  %"shf_concat.20" = or i64 %".859", %".861"
  %"shf_shift_64.20" = zext i32 5 to i64
  %".862" = lshr i64 %"shf_concat.20", %"shf_shift_64.20"
  %"shf_hi.5" = lshr i64 %".862", 32
  %"shf_result.20" = trunc i64 %"shf_hi.5" to i32
  %".863" = zext i32 %"imad.48" to i64
  %".864" = zext i32 0 to i64
  %".865" = shl i64 %".864", 32
  %"shf_concat.21" = or i64 %".863", %".865"
  %"shf_shift_64.21" = zext i32 %"shf_result.20" to i64
  %".866" = shl i64 %"shf_concat.21", %"shf_shift_64.21"
  %"shf_result.21" = trunc i64 %".866" to i32
  %".867" = xor i32 %"lds.14", -1
  %".868" = xor i32 %"shf_result.21", -1
  %".869" = xor i32 0, -1
  %".870" = and i32 %"lds.14", %"shf_result.21"
  %".871" = and i32 %".870", %".869"
  %".872" = and i32 %"lds.14", %"shf_result.21"
  %".873" = and i32 %".872", 0
  %".874" = or i32 %".871", %".873"
  %"isetrp_cmp1.39" = icmp ne i32 %".874", %"shf_result.21"
  %"isetrp_src_to_i32.39" = zext i1 1 to i32
  %"isetrp_src_to_i1.39" = icmp ne i32 %"isetrp_src_to_i32.39", 0
  %"isetrp_cmp2.39" = and i1 %"isetrp_cmp1.39", %"isetrp_src_to_i1.39"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.39" to i32
  %"imad_tmp.46" = mul i32 0, 0
  %"imad.49" = add i32 %"imad_tmp.46", 1
  %".875" = zext i32 %"imad.49" to i64
  %".876" = zext i32 0 to i64
  %".877" = shl i64 %".876", 32
  %"shf_concat.22" = or i64 %".875", %".877"
  %"shf_shift_64.22" = zext i32 %"shf_result.20" to i64
  %".878" = shl i64 %"shf_concat.22", %"shf_shift_64.22"
  %"shf_result.22" = trunc i64 %".878" to i32
  br label %"BB_2310"
BB_2310:
  %"cond_trunc.35" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_24a0_27c0", label %"BB_2320"
BB_2320:
  %"lds_addr_memaddr_offset_add.15" = add i32 %".849", 24
  %"lds_shared_addr_winoff.15" = and i32 %"lds_addr_memaddr_offset_add.15", 16777215
  %".881" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.15"
  %"lds_shared_addr_cast.15" = bitcast i8 addrspace(3)* %".881" to i32 addrspace(3)*
  %"lds.15" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.15"
  %".882" = xor i32 %"lds.15", -1
  %".883" = xor i32 %"shf_result.22", -1
  %".884" = xor i32 0, -1
  %".885" = and i32 %"lds.15", %"shf_result.22"
  %".886" = and i32 %".885", %".884"
  %".887" = and i32 %"lds.15", %"shf_result.22"
  %".888" = and i32 %".887", 0
  %".889" = or i32 %".886", %".888"
  %"isetrp_cmp1.40" = icmp ne i32 %".889", %"shf_result.22"
  %"isetrp_src_to_i32.40" = zext i1 1 to i32
  %"isetrp_src_to_i1.40" = icmp ne i32 %"isetrp_src_to_i32.40", 0
  %"isetrp_cmp2.40" = and i1 %"isetrp_cmp1.40", %"isetrp_src_to_i1.40"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.40" to i32
  br label %"BB_2350"
BB_2350:
  %"cond_trunc.36" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_2470_2790", label %"BB_2360"
BB_2360:
  %"activemask.3" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.3" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".892" = xor i32 0, -1
  %".893" = xor i32 %"shf_result.22", -1
  %".894" = xor i32 0, -1
  %".895" = and i32 %".892", %".893"
  %".896" = and i32 %".895", %".894"
  %".897" = and i32 %".892", %".893"
  %".898" = and i32 %".897", 0
  %".899" = or i32 %".896", %".898"
  %".900" = and i32 0, %".893"
  %".901" = and i32 %".900", %".894"
  %".902" = or i32 %".899", %".901"
  %".903" = and i32 0, %".893"
  %".904" = and i32 %".903", 0
  %".905" = or i32 %".902", %".904"
  %"flo_clz.3" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.3", i1 0)
  %"flo.3" = sub i32 31, %"flo_clz.3"
  %"redux_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.4" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".905", i32 %"redux_mask.4")
  %".906" = xor i32 0, -1
  %".907" = xor i32 %"shf_result.21", -1
  %".908" = xor i32 0, -1
  %".909" = and i32 %".906", %".907"
  %".910" = and i32 %".909", %".908"
  %".911" = and i32 %".906", %".907"
  %".912" = and i32 %".911", 0
  %".913" = or i32 %".910", %".912"
  %".914" = and i32 0, %".907"
  %".915" = and i32 %".914", %".908"
  %".916" = or i32 %".913", %".915"
  %".917" = and i32 0, %".907"
  %".918" = and i32 %".917", 0
  %".919" = or i32 %".916", %".918"
  %"imad_tmp.47" = mul i32 0, 0
  %"imad.50" = add i32 %"imad_tmp.47", %".919"
  %"redux_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.5" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.50", i32 %"redux_mask.5")
  %".920" = xor i32 %".919", -1
  %".921" = call i32 @"llvm.cttz.i32"(i32 %".920", i1 0)
  %".922" = shl i32 %".921", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".922") convergent
  %"imad_tmp.48" = mul i32 0, 0
  %"imad.51" = add i32 %"imad_tmp.48", %"redux_sync_and.4"
  %"isetrp_cmp1.41" = icmp eq i32 %"laneid.3", %"flo.3"
  %"isetrp_src_to_i32.41" = zext i1 1 to i32
  %"isetrp_src_to_i1.41" = icmp ne i32 %"isetrp_src_to_i32.41", 0
  %"isetrp_cmp2.41" = and i1 %"isetrp_cmp1.41", %"isetrp_src_to_i1.41"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.41" to i32
  %"imad_tmp.49" = mul i32 0, 0
  %"imad.52" = add i32 %"imad_tmp.49", %"redux_sync_and.5"
  br label %"BB_2430"
BB_2430:
  %"cond_trunc.37" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_80002430", label %"BB_24b0"
BB_80002430:
  %"atoms_addr_memaddr_offset_add.16" = add i32 %".849", 20
  %"atoms_shared_addr_winoff.16" = and i32 %"atoms_addr_memaddr_offset_add.16", 16777215
  %".926" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.16"
  %"atoms_ptr.16" = bitcast i8 addrspace(3)* %".926" to i32 addrspace(3)*
  %"atoms_and.6" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.16", i32 %"imad.52" monotonic
  %"atoms_addr_memaddr_offset_add.17" = add i32 %".849", 24
  %"atoms_shared_addr_winoff.17" = and i32 %"atoms_addr_memaddr_offset_add.17", 16777215
  %".927" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.17"
  %"atoms_ptr.17" = bitcast i8 addrspace(3)* %".927" to i32 addrspace(3)*
  %"atoms_and.7" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.17", i32 %"imad.51" monotonic
  br label %"BB_24b0"
BB_2470_2790:
  call void @"llvm.trap"()
  br label %"BB_24b0"
BB_24a0_27c0:
  call void @"llvm.trap"()
  br label %"BB_24b0"
BB_24b0:
  %"s2ur_cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.16" = add i32 %".16", 2072
  %"lds_shared_addr_winoff.16" = and i32 %"lds_addr_memaddr_offset_add.16", 16777215
  %".931" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.16"
  %"lds_shared_addr_cast.16" = bitcast i8 addrspace(3)* %".931" to i32 addrspace(3)*
  %"lds.16" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.16"
  %"imad_tmp.50" = mul i32 0, 0
  %"imad.53" = add i32 %"imad_tmp.50", 255
  %".932" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".933" = zext i32 64 to i64
  %".934" = zext i32 24 to i64
  %".935" = shl i64 %".932", %".934"
  %".936" = and i64 %".935", 4294967295
  %".937" = add i64 %".936", %".933"
  %".938" = trunc i64 %".937" to i32
  %"lds_addr_memaddr_offset_add.17" = add i32 %".938", 20
  %"lds_shared_addr_winoff.17" = and i32 %"lds_addr_memaddr_offset_add.17", 16777215
  %".939" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.17"
  %"lds_shared_addr_cast.17" = bitcast i8 addrspace(3)* %".939" to i32 addrspace(3)*
  %"lds.17" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.17"
  %".940" = xor i32 %"lds.16", -1
  %".941" = xor i32 65535, -1
  %".942" = xor i32 0, -1
  %".943" = and i32 %"lds.16", 65535
  %".944" = and i32 %".943", %".942"
  %".945" = and i32 %"lds.16", 65535
  %".946" = and i32 %".945", 0
  %".947" = or i32 %".944", %".946"
  %".948" = zext i32 0 to i64
  %".949" = zext i32 %".947" to i64
  %".950" = shl i64 %".949", 32
  %"shf_concat.23" = or i64 %".948", %".950"
  %"shf_shift_64.23" = zext i32 5 to i64
  %".951" = lshr i64 %"shf_concat.23", %"shf_shift_64.23"
  %"shf_hi.6" = lshr i64 %".951", 32
  %"shf_result.23" = trunc i64 %"shf_hi.6" to i32
  %".952" = zext i32 %"imad.53" to i64
  %".953" = zext i32 0 to i64
  %".954" = shl i64 %".953", 32
  %"shf_concat.24" = or i64 %".952", %".954"
  %"shf_shift_64.24" = zext i32 %"shf_result.23" to i64
  %".955" = shl i64 %"shf_concat.24", %"shf_shift_64.24"
  %"shf_result.24" = trunc i64 %".955" to i32
  %".956" = xor i32 %"lds.17", -1
  %".957" = xor i32 %"shf_result.24", -1
  %".958" = xor i32 0, -1
  %".959" = and i32 %"lds.17", %"shf_result.24"
  %".960" = and i32 %".959", %".958"
  %".961" = and i32 %"lds.17", %"shf_result.24"
  %".962" = and i32 %".961", 0
  %".963" = or i32 %".960", %".962"
  %"isetrp_cmp1.42" = icmp ne i32 %".963", %"shf_result.24"
  %"isetrp_src_to_i32.42" = zext i1 1 to i32
  %"isetrp_src_to_i1.42" = icmp ne i32 %"isetrp_src_to_i32.42", 0
  %"isetrp_cmp2.42" = and i1 %"isetrp_cmp1.42", %"isetrp_src_to_i1.42"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.42" to i32
  %"imad_tmp.51" = mul i32 0, 0
  %"imad.54" = add i32 %"imad_tmp.51", 1
  %".964" = zext i32 %"imad.54" to i64
  %".965" = zext i32 0 to i64
  %".966" = shl i64 %".965", 32
  %"shf_concat.25" = or i64 %".964", %".966"
  %"shf_shift_64.25" = zext i32 %"shf_result.23" to i64
  %".967" = shl i64 %"shf_concat.25", %"shf_shift_64.25"
  %"shf_result.25" = trunc i64 %".967" to i32
  br label %"BB_25a0"
BB_25a0:
  %"cond_trunc.38" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_2730_27c0", label %"BB_25b0"
BB_25b0:
  %"lds_addr_memaddr_offset_add.18" = add i32 %".938", 24
  %"lds_shared_addr_winoff.18" = and i32 %"lds_addr_memaddr_offset_add.18", 16777215
  %".970" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.18"
  %"lds_shared_addr_cast.18" = bitcast i8 addrspace(3)* %".970" to i32 addrspace(3)*
  %"lds.18" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.18"
  %".971" = xor i32 %"lds.18", -1
  %".972" = xor i32 %"shf_result.25", -1
  %".973" = xor i32 0, -1
  %".974" = and i32 %"lds.18", %"shf_result.25"
  %".975" = and i32 %".974", %".973"
  %".976" = and i32 %"lds.18", %"shf_result.25"
  %".977" = and i32 %".976", 0
  %".978" = or i32 %".975", %".977"
  %"isetrp_cmp1.43" = icmp ne i32 %".978", %"shf_result.25"
  %"isetrp_src_to_i32.43" = zext i1 1 to i32
  %"isetrp_src_to_i1.43" = icmp ne i32 %"isetrp_src_to_i32.43", 0
  %"isetrp_cmp2.43" = and i1 %"isetrp_cmp1.43", %"isetrp_src_to_i1.43"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.43" to i32
  br label %"BB_25e0"
BB_25e0:
  %"cond_trunc.39" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_trunc.39" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_2700_2790", label %"BB_25f0"
BB_25f0:
  %"activemask.4" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.4" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".981" = xor i32 0, -1
  %".982" = xor i32 %"shf_result.25", -1
  %".983" = xor i32 0, -1
  %".984" = and i32 %".981", %".982"
  %".985" = and i32 %".984", %".983"
  %".986" = and i32 %".981", %".982"
  %".987" = and i32 %".986", 0
  %".988" = or i32 %".985", %".987"
  %".989" = and i32 0, %".982"
  %".990" = and i32 %".989", %".983"
  %".991" = or i32 %".988", %".990"
  %".992" = and i32 0, %".982"
  %".993" = and i32 %".992", 0
  %".994" = or i32 %".991", %".993"
  %"flo_clz.4" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.4", i1 0)
  %"flo.4" = sub i32 31, %"flo_clz.4"
  %"redux_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.6" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".994", i32 %"redux_mask.6")
  %".995" = xor i32 0, -1
  %".996" = xor i32 %"shf_result.24", -1
  %".997" = xor i32 0, -1
  %".998" = and i32 %".995", %".996"
  %".999" = and i32 %".998", %".997"
  %".1000" = and i32 %".995", %".996"
  %".1001" = and i32 %".1000", 0
  %".1002" = or i32 %".999", %".1001"
  %".1003" = and i32 0, %".996"
  %".1004" = and i32 %".1003", %".997"
  %".1005" = or i32 %".1002", %".1004"
  %".1006" = and i32 0, %".996"
  %".1007" = and i32 %".1006", 0
  %".1008" = or i32 %".1005", %".1007"
  %"imad_tmp.52" = mul i32 0, 0
  %"imad.55" = add i32 %"imad_tmp.52", %".1008"
  %"redux_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.7" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.55", i32 %"redux_mask.7")
  %".1009" = xor i32 %".1008", -1
  %".1010" = call i32 @"llvm.cttz.i32"(i32 %".1009", i1 0)
  %".1011" = shl i32 %".1010", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 256;", "r,~{memory}"(i32 %".1011") convergent
  %"imad_tmp.53" = mul i32 0, 0
  %"imad.56" = add i32 %"imad_tmp.53", %"redux_sync_and.6"
  %"isetrp_cmp1.44" = icmp eq i32 %"laneid.4", %"flo.4"
  %"isetrp_src_to_i32.44" = zext i1 1 to i32
  %"isetrp_src_to_i1.44" = icmp ne i32 %"isetrp_src_to_i32.44", 0
  %"isetrp_cmp2.44" = and i1 %"isetrp_cmp1.44", %"isetrp_src_to_i1.44"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.44" to i32
  %"imad_tmp.54" = mul i32 0, 0
  %"imad.57" = add i32 %"imad_tmp.54", %"redux_sync_and.7"
  br label %"BB_26c0"
BB_26c0:
  %"cond_trunc.40" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_trunc.40" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_800026c0", label %"BB_2740"
BB_800026c0:
  %"atoms_addr_memaddr_offset_add.18" = add i32 %".938", 20
  %"atoms_shared_addr_winoff.18" = and i32 %"atoms_addr_memaddr_offset_add.18", 16777215
  %".1015" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.18"
  %"atoms_ptr.18" = bitcast i8 addrspace(3)* %".1015" to i32 addrspace(3)*
  %"atoms_and.8" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.18", i32 %"imad.57" monotonic
  %"atoms_addr_memaddr_offset_add.19" = add i32 %".938", 24
  %"atoms_shared_addr_winoff.19" = and i32 %"atoms_addr_memaddr_offset_add.19", 16777215
  %".1016" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.19"
  %"atoms_ptr.19" = bitcast i8 addrspace(3)* %".1016" to i32 addrspace(3)*
  %"atoms_and.9" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.19", i32 %"imad.56" monotonic
  br label %"BB_2740"
BB_2700_2790:
  call void @"llvm.trap"()
  br label %"BB_2740"
BB_2730_27c0:
  call void @"llvm.trap"()
  br label %"BB_2740"
BB_2740:
  ret void
BB_80001b20:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P2_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0080"
BB_0080:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_02a0", label %"BB_0090"
BB_0090:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"UR7:UR6_r0" = trunc i64 %"ldc_const" to i32
  %"UR7:UR6_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR7:UR6_r1" = trunc i64 %"UR7:UR6_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".21" = xor i32 %"imad", -1
  %".22" = xor i32 508, -1
  %".23" = xor i32 0, -1
  %".24" = and i32 %"imad", 508
  %".25" = and i32 %".24", %".23"
  %".26" = and i32 %"imad", 508
  %".27" = and i32 %".26", 0
  %".28" = or i32 %".25", %".27"
  %"iadd3_o1_64" = zext i32 %".28" to i64
  %"iadd3_o2_64" = zext i32 %"UR7:UR6_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P38_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR7:UR6_r1"
  %"imad_cin_trunc" = trunc i32 %"P38_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R383:R363_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R383:R363_addr_ptr"
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".29" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".30" = zext i32 %"iadd3_n2" to i64
  %".31" = zext i32 24 to i64
  %".32" = shl i64 %".29", %".31"
  %".33" = and i64 %".32", 4294967295
  %".34" = add i64 %".33", %".30"
  %".35" = trunc i64 %".34" to i32
  %"viadd" = add i32 %"imad", %".35"
  br label %"BB_0140"
BB_0140:
  %"phi" = phi  i32 [%"tid_x", %"BB_0090"], [%"viadd.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"viadd", %"BB_0090"], [%"viadd.2", %"BB_0180"]
  %"isetrp_cmp1.1" = icmp uge i32 %"phi", 128
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P73_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".37" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".37" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P73_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0140", label %"BB_0190"
BB_0190:
  %".41" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".42" = bitcast i8* %".41" to i64*
  %"ldc_const.1" = load i64, i64* %".42"
  %"R5:R4_r0" = trunc i64 %"ldc_const.1" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"viadd.3" = add i32 %"imad", %".16"
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad.2" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P87_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R5:R4_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P87_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0210"
BB_0210:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_0190"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.3" = phi  i32 [%"iadd3_trunc.1", %"BB_0190"], [%"iadd3_trunc.2", %"BB_0290"]
  %"phi.4" = phi  i32 [%"tid_x", %"BB_0190"], [%"viadd.4", %"BB_0290"]
  %"phi.5" = phi  i32 [%"viadd.3", %"BB_0190"], [%"viadd.5", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R34:R380_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R34:R380_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.4", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.4" = add i32 %"phi.4", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P72_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P72_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.5", 16777215
  %".44" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".44" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.5", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.6" = phi  i32 [0, %"BB_0080"], [%"UR7:UR6_r1", %"BB_0290"]
  %"phi.7" = phi  i32 [0, %"BB_0080"], [%".35", %"BB_0290"]
  %"isetrp_cmp1.3" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P61_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P94_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"vote_pred_trunc" = trunc i32 %"P61_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P83_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P83_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 2048
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".50" = zext i32 %"iadd3_n2.2" to i64
  %".51" = zext i32 0 to i64
  %".52" = shl i64 %".51", 32
  %"shf_concat" = or i64 %".50", %".52"
  %"shf_shift_64" = zext i32 11 to i64
  %".53" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".53" to i32
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat.1" = or i64 %".54", %".56"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".57" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".57" to i32
  %".58" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".59" = zext i32 %"iadd3_n2.1" to i64
  %".60" = zext i32 24 to i64
  %".61" = shl i64 %".58", %".60"
  %".62" = and i64 %".61", 4294967295
  %".63" = add i64 %".62", %".59"
  %".64" = trunc i64 %".63" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000300"], [%"phi.6", %"BB_0300"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"phi.10" = phi  i32 [%".64", %"BB_80000300"], [%"phi.7", %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P61_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P37_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.10", 16777215
  %".69" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".69" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".70" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".70" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P94_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_slot_winoff" = and i32 3080, 16777215
  %".74" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".75" = ptrtoint i8 addrspace(3)* %".74" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".75", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P8_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 1
  %".79" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".80" = zext i32 64 to i64
  %".81" = zext i32 24 to i64
  %".82" = shl i64 %".79", %".81"
  %".83" = and i64 %".82", 4294967295
  %".84" = add i64 %".83", %".80"
  %".85" = trunc i64 %".84" to i32
  %"tmem_alloc_winoff" = and i32 3080, 16777215
  %".86" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".87" = bitcast i8 addrspace(3)* %".86" to i32 addrspace(3)*
  %".88" = load i32, i32 addrspace(3)* %".87"
  %".89" = lshr i32 %".88", 5
  %"P43_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".89"
  %"bra_cond_trunc" = trunc i32 %"P43_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_winoff.1" = and i32 3080, 16777215
  %".91" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".92" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  %".93" = load i32, i32 addrspace(3)* %".92"
  %".94" = lshr i32 %".93", 5
  %"P45_to_i32" = zext i1 1 to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".94"
  %"bra_cond_trunc.1" = trunc i32 %"P45_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.11" = phi  i32 [%"imad.6", %"BB_03c0"], [%"imad.7", %"BB_0440"]
  %".96" = zext i32 %"imad.5" to i64
  %".97" = zext i32 0 to i64
  %".98" = shl i64 %".97", 32
  %"shf_concat.2" = or i64 %".96", %".98"
  %"shf_shift_64.2" = zext i32 %"phi.11" to i64
  %".99" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".99" to i32
  %"imad_tmp.7" = mul i32 %"phi.11", 32
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".85", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".100" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".100" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".85", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".101" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".102" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".102" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.12" = phi  i32 [%"P8_to_i32", %"BB_04a0"], [%"P8_to_i32", %"BB_03b0"], [%"P2_to_i32", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0520"
BB_0520:
  %"cond_trunc.7" = trunc i32 %"P94_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0b50", label %"BB_0530"
BB_0530:
  %"allocation_slot_winoff.1" = and i32 3084, 16777215
  %".107" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.1"
  %".108" = ptrtoint i8 addrspace(3)* %".107" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".108", i32 32) convergent
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P47_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0550"
BB_0550:
  %"cond_trunc.8" = trunc i32 %"P47_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0690", label %"BB_0560"
BB_0560:
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", 1
  %".112" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".113" = zext i32 64 to i64
  %".114" = zext i32 24 to i64
  %".115" = shl i64 %".112", %".114"
  %".116" = and i64 %".115", 4294967295
  %".117" = add i64 %".116", %".113"
  %".118" = trunc i64 %".117" to i32
  %"tmem_alloc_winoff.2" = and i32 3084, 16777215
  %".119" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.2"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P46_to_i32" = zext i1 1 to i32
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.9", %".122"
  %"bra_cond_trunc.2" = trunc i32 %"P46_to_i32" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  br i1 %"bra_cond_to_i1.2", label %"BB_0640", label %"BB_05e0"
BB_05e0:
  %"tmem_alloc_winoff.3" = and i32 3084, 16777215
  %".124" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.3"
  %".125" = bitcast i8 addrspace(3)* %".124" to i32 addrspace(3)*
  %".126" = load i32, i32 addrspace(3)* %".125"
  %".127" = lshr i32 %".126", 5
  %"P16_to_i32" = zext i1 1 to i32
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.10", %".127"
  %"bra_cond_trunc.3" = trunc i32 %"P16_to_i32" to i1
  %"bra_cond_not.1" = xor i1 %"bra_cond_trunc.3", -1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_not.1" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  br i1 %"bra_cond_to_i1.3", label %"BB_05e0", label %"BB_0640"
BB_0640:
  %"phi.13" = phi  i32 [%"imad.10", %"BB_0560"], [%"imad.11", %"BB_05e0"]
  %".129" = zext i32 %"imad.9" to i64
  %".130" = zext i32 0 to i64
  %".131" = shl i64 %".130", 32
  %"shf_concat.3" = or i64 %".129", %".131"
  %"shf_shift_64.3" = zext i32 %"phi.13" to i64
  %".132" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".132" to i32
  %"imad_tmp.11" = mul i32 %"phi.13", 32
  %"imad.12" = add i32 %"imad_tmp.11", 0
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".118", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".133" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".133" to i32 addrspace(3)*
  %"atoms_or.2" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.2", i32 %"shf_result.3" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".118", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".134" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".134" to i32 addrspace(3)*
  %"atoms_or.3" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.3", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add.1" = add i32 %".16", 2060
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".135" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".135" to i32 addrspace(3)*
  store volatile i32 %"imad.12", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0690"
BB_0690:
  %"allocation_slot_winoff.2" = and i32 3088, 16777215
  %".138" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.2"
  %".139" = ptrtoint i8 addrspace(3)* %".138" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".139", i32 64) convergent
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P57_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_06c0"
BB_06c0:
  %"cond_trunc.9" = trunc i32 %"P57_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0820", label %"BB_06d0"
BB_06d0:
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", 3
  %".143" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".144" = zext i32 64 to i64
  %".145" = zext i32 24 to i64
  %".146" = shl i64 %".143", %".145"
  %".147" = and i64 %".146", 4294967295
  %".148" = add i64 %".147", %".144"
  %".149" = trunc i64 %".148" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", 1
  %"tmem_alloc_winoff.4" = and i32 3088, 16777215
  %".150" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.4"
  %".151" = bitcast i8 addrspace(3)* %".150" to i32 addrspace(3)*
  %".152" = load i32, i32 addrspace(3)* %".151"
  %".153" = lshr i32 %".152", 5
  %"P33_to_i32" = zext i1 1 to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.14", %".153"
  %"bra_cond_trunc.4" = trunc i32 %"P33_to_i32" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  br i1 %"bra_cond_to_i1.4", label %"BB_07c0", label %"BB_0760"
BB_0760:
  %"tmem_alloc_winoff.5" = and i32 3088, 16777215
  %".155" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.5"
  %".156" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  %".157" = load i32, i32 addrspace(3)* %".156"
  %".158" = lshr i32 %".157", 5
  %"P34_to_i32" = zext i1 1 to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.15", %".158"
  %"bra_cond_trunc.5" = trunc i32 %"P34_to_i32" to i1
  %"bra_cond_not.2" = xor i1 %"bra_cond_trunc.5", -1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_not.2" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  br i1 %"bra_cond_to_i1.5", label %"BB_0760", label %"BB_07c0"
BB_07c0:
  %"phi.14" = phi  i32 [%"imad.15", %"BB_06d0"], [%"imad.16", %"BB_0760"]
  %".160" = zext i32 %"imad.13" to i64
  %".161" = zext i32 0 to i64
  %".162" = shl i64 %".161", 32
  %"shf_concat.4" = or i64 %".160", %".162"
  %"shf_shift_64.4" = zext i32 %"phi.14" to i64
  %".163" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".163" to i32
  %".164" = zext i32 %"imad.14" to i64
  %".165" = zext i32 0 to i64
  %".166" = shl i64 %".165", 32
  %"shf_concat.5" = or i64 %".164", %".166"
  %"shf_shift_64.5" = zext i32 %"phi.14" to i64
  %".167" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".167" to i32
  %"imad_tmp.16" = mul i32 %"phi.14", 32
  %"imad.17" = add i32 %"imad_tmp.16", 0
  %"atoms_addr_memaddr_offset_add.4" = add i32 %".149", 20
  %"atoms_shared_addr_winoff.4" = and i32 %"atoms_addr_memaddr_offset_add.4", 16777215
  %".168" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.4"
  %"atoms_ptr.4" = bitcast i8 addrspace(3)* %".168" to i32 addrspace(3)*
  %"atoms_or.4" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.4", i32 %"shf_result.4" monotonic
  %"atoms_addr_memaddr_offset_add.5" = add i32 %".149", 24
  %"atoms_shared_addr_winoff.5" = and i32 %"atoms_addr_memaddr_offset_add.5", 16777215
  %".169" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.5"
  %"atoms_ptr.5" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  %"atoms_or.5" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.5", i32 %"shf_result.5" monotonic
  %"sts_addr_memaddr_offset_add.2" = add i32 %".16", 2064
  %"sts_shared_addr_winoff.4" = and i32 %"sts_addr_memaddr_offset_add.2", 16777215
  %".170" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".170" to i32 addrspace(3)*
  store volatile i32 %"imad.17", i32 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_0820"
BB_0820:
  %"allocation_slot_winoff.3" = and i32 3092, 16777215
  %".173" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.3"
  %".174" = ptrtoint i8 addrspace(3)* %".173" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".174", i32 128) convergent
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P68_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0850"
BB_0850:
  %"cond_trunc.10" = trunc i32 %"P68_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_09b0", label %"BB_0860"
BB_0860:
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.17", 15
  %".178" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".179" = zext i32 64 to i64
  %".180" = zext i32 24 to i64
  %".181" = shl i64 %".178", %".180"
  %".182" = and i64 %".181", 4294967295
  %".183" = add i64 %".182", %".179"
  %".184" = trunc i64 %".183" to i32
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.18", 1
  %"tmem_alloc_winoff.6" = and i32 3092, 16777215
  %".185" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.6"
  %".186" = bitcast i8 addrspace(3)* %".185" to i32 addrspace(3)*
  %".187" = load i32, i32 addrspace(3)* %".186"
  %".188" = lshr i32 %".187", 5
  %"P36_to_i32" = zext i1 1 to i32
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.19", %".188"
  %"bra_cond_trunc.6" = trunc i32 %"P36_to_i32" to i1
  %"bra_cond_to_i32.6" = zext i1 %"bra_cond_trunc.6" to i32
  %"bra_cond_to_i1.6" = icmp ne i32 %"bra_cond_to_i32.6", 0
  br i1 %"bra_cond_to_i1.6", label %"BB_0950", label %"BB_08f0"
BB_08f0:
  %"tmem_alloc_winoff.7" = and i32 3092, 16777215
  %".190" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.7"
  %".191" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %".192" = load i32, i32 addrspace(3)* %".191"
  %".193" = lshr i32 %".192", 5
  %"P40_to_i32" = zext i1 1 to i32
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.20", %".193"
  %"bra_cond_trunc.7" = trunc i32 %"P40_to_i32" to i1
  %"bra_cond_not.3" = xor i1 %"bra_cond_trunc.7", -1
  %"bra_cond_to_i32.7" = zext i1 %"bra_cond_not.3" to i32
  %"bra_cond_to_i1.7" = icmp ne i32 %"bra_cond_to_i32.7", 0
  br i1 %"bra_cond_to_i1.7", label %"BB_08f0", label %"BB_0950"
BB_0950:
  %"phi.15" = phi  i32 [%"imad.20", %"BB_0860"], [%"imad.21", %"BB_08f0"]
  %".195" = zext i32 %"imad.18" to i64
  %".196" = zext i32 0 to i64
  %".197" = shl i64 %".196", 32
  %"shf_concat.6" = or i64 %".195", %".197"
  %"shf_shift_64.6" = zext i32 %"phi.15" to i64
  %".198" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".198" to i32
  %".199" = zext i32 %"imad.19" to i64
  %".200" = zext i32 0 to i64
  %".201" = shl i64 %".200", 32
  %"shf_concat.7" = or i64 %".199", %".201"
  %"shf_shift_64.7" = zext i32 %"phi.15" to i64
  %".202" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".202" to i32
  %"imad_tmp.21" = mul i32 %"phi.15", 32
  %"imad.22" = add i32 %"imad_tmp.21", 0
  %"atoms_addr_memaddr_offset_add.6" = add i32 %".184", 20
  %"atoms_shared_addr_winoff.6" = and i32 %"atoms_addr_memaddr_offset_add.6", 16777215
  %".203" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.6"
  %"atoms_ptr.6" = bitcast i8 addrspace(3)* %".203" to i32 addrspace(3)*
  %"atoms_or.6" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.6", i32 %"shf_result.6" monotonic
  %"atoms_addr_memaddr_offset_add.7" = add i32 %".184", 24
  %"atoms_shared_addr_winoff.7" = and i32 %"atoms_addr_memaddr_offset_add.7", 16777215
  %".204" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.7"
  %"atoms_ptr.7" = bitcast i8 addrspace(3)* %".204" to i32 addrspace(3)*
  %"atoms_or.7" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.7", i32 %"shf_result.7" monotonic
  %"sts_addr_memaddr_offset_add.3" = add i32 %".16", 2068
  %"sts_shared_addr_winoff.5" = and i32 %"sts_addr_memaddr_offset_add.3", 16777215
  %".205" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".205" to i32 addrspace(3)*
  store volatile i32 %"imad.22", i32 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_09b0"
BB_09b0:
  %"allocation_slot_winoff.4" = and i32 3096, 16777215
  %".208" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.4"
  %".209" = ptrtoint i8 addrspace(3)* %".208" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".209", i32 256) convergent
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P80_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.11" = trunc i32 %"P80_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0b50", label %"BB_09f0"
BB_09f0:
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.22", 255
  %".213" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".214" = zext i32 64 to i64
  %".215" = zext i32 24 to i64
  %".216" = shl i64 %".213", %".215"
  %".217" = and i64 %".216", 4294967295
  %".218" = add i64 %".217", %".214"
  %".219" = trunc i64 %".218" to i32
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.23", 1
  %"tmem_alloc_winoff.8" = and i32 3096, 16777215
  %".220" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.8"
  %".221" = bitcast i8 addrspace(3)* %".220" to i32 addrspace(3)*
  %".222" = load i32, i32 addrspace(3)* %".221"
  %".223" = lshr i32 %".222", 5
  %"P41_to_i32" = zext i1 1 to i32
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.24", %".223"
  %"bra_cond_trunc.8" = trunc i32 %"P41_to_i32" to i1
  %"bra_cond_to_i32.8" = zext i1 %"bra_cond_trunc.8" to i32
  %"bra_cond_to_i1.8" = icmp ne i32 %"bra_cond_to_i32.8", 0
  br i1 %"bra_cond_to_i1.8", label %"BB_0ae0", label %"BB_0a80"
BB_0a80:
  %"tmem_alloc_winoff.9" = and i32 3096, 16777215
  %".225" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.9"
  %".226" = bitcast i8 addrspace(3)* %".225" to i32 addrspace(3)*
  %".227" = load i32, i32 addrspace(3)* %".226"
  %".228" = lshr i32 %".227", 5
  %"P42_to_i32" = zext i1 1 to i32
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.25", %".228"
  %"bra_cond_trunc.9" = trunc i32 %"P42_to_i32" to i1
  %"bra_cond_not.4" = xor i1 %"bra_cond_trunc.9", -1
  %"bra_cond_to_i32.9" = zext i1 %"bra_cond_not.4" to i32
  %"bra_cond_to_i1.9" = icmp ne i32 %"bra_cond_to_i32.9", 0
  br i1 %"bra_cond_to_i1.9", label %"BB_0a80", label %"BB_0ae0"
BB_0ae0:
  %"phi.16" = phi  i32 [%"imad.25", %"BB_09f0"], [%"imad.26", %"BB_0a80"]
  %".230" = zext i32 %"imad.23" to i64
  %".231" = zext i32 0 to i64
  %".232" = shl i64 %".231", 32
  %"shf_concat.8" = or i64 %".230", %".232"
  %"shf_shift_64.8" = zext i32 %"phi.16" to i64
  %".233" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".233" to i32
  %".234" = zext i32 %"imad.24" to i64
  %".235" = zext i32 0 to i64
  %".236" = shl i64 %".235", 32
  %"shf_concat.9" = or i64 %".234", %".236"
  %"shf_shift_64.9" = zext i32 %"phi.16" to i64
  %".237" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".237" to i32
  %"imad_tmp.26" = mul i32 %"phi.16", 32
  %"imad.27" = add i32 %"imad_tmp.26", 0
  %"atoms_addr_memaddr_offset_add.8" = add i32 %".219", 20
  %"atoms_shared_addr_winoff.8" = and i32 %"atoms_addr_memaddr_offset_add.8", 16777215
  %".238" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.8"
  %"atoms_ptr.8" = bitcast i8 addrspace(3)* %".238" to i32 addrspace(3)*
  %"atoms_or.8" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.8", i32 %"shf_result.8" monotonic
  %"atoms_addr_memaddr_offset_add.9" = add i32 %".219", 24
  %"atoms_shared_addr_winoff.9" = and i32 %"atoms_addr_memaddr_offset_add.9", 16777215
  %".239" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.9"
  %"atoms_ptr.9" = bitcast i8 addrspace(3)* %".239" to i32 addrspace(3)*
  %"atoms_or.9" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.9", i32 %"shf_result.9" monotonic
  %"sts_addr_memaddr_offset_add.4" = add i32 %".16", 2072
  %"sts_shared_addr_winoff.6" = and i32 %"sts_addr_memaddr_offset_add.4", 16777215
  %".240" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".240" to i32 addrspace(3)*
  store volatile i32 %"imad.27", i32 addrspace(3)* %"sts_shared_addr_cast.6"
  br label %"BB_0b50"
BB_0b50:
  %"phi.17" = phi  i32 [%"P80_to_i32", %"BB_0ae0"], [%"P80_to_i32", %"BB_09e0"], [%"phi.12", %"BB_0520"]
  %".243" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".244" = bitcast i8* %".243" to i64*
  %"ldc_const.2" = load i64, i64* %".244"
  %"R27:R26_r0" = trunc i64 %"ldc_const.2" to i32
  %"R27:R26_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R27:R26_r1" = trunc i64 %"R27:R26_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.27" = mul i32 %"tid_x", 18
  %"imad.28" = add i32 %"imad_tmp.27", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R27:R26_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R27:R26_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.28" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.29" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R27:R26_r0.1" = trunc i64 %"imad.29" to i32
  %"R27:R26_r1_shift.1" = lshr i64 %"imad.29", 32
  %"R27:R26_r1.1" = trunc i64 %"R27:R26_r1_shift.1" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".245" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".245" to i64 addrspace(3)*
  %"lds" = load volatile i64, i64 addrspace(3)* %"lds_shared_addr_cast"
  %"R13:R12_r0" = trunc i64 %"lds" to i32
  %"R13:R12_r1_shift" = lshr i64 %"lds", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R309:R305_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R309:R305_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R309:R305_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R309:R305_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R309:R305_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R309:R305_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R309:R305_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R309:R305_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.7"
  %"imad_tmp.28" = mul i32 %"tid_x", 65536
  %"imad.30" = add i32 %"imad_tmp.28", 0
  %".246" = xor i32 %"imad.30", -1
  %".247" = xor i32 65011712, -1
  %".248" = xor i32 0, -1
  %".249" = and i32 %"imad.30", 65011712
  %".250" = and i32 %".249", %".248"
  %".251" = and i32 %"imad.30", 65011712
  %".252" = and i32 %".251", 0
  %".253" = or i32 %".250", %".252"
  %"imad_tmp.29" = mul i32 %"R13:R12_r1", 1
  %"imad.31" = add i32 %"imad_tmp.29", %".253"
  %"sttm_memaddr_offset_add" = add i32 %"imad.31", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.31", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R309:R305_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R309:R305_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R309:R305_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R309:R305_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R309:R305_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R309:R305_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R309:R305_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R309:R305_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.15"
  %"imad_addend_neg" = sub i32 0, %"R13:R12_r0"
  %"imad_tmp.30" = mul i32 %"R13:R12_r1", 1
  %"imad.32" = add i32 %"imad_tmp.30", %"imad_addend_neg"
  %"imad_tmp.31" = mul i32 %".253", 1
  %"imad.33" = add i32 %"imad_tmp.31", %"R13:R12_r0"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.31", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.31", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0dd0"
BB_0dd0:
  %"cond_trunc.12" = trunc i32 %"P61_to_i32" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_1140", label %"BB_0de0"
BB_0de0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".263" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".263" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".264" = zext i32 0 to i64
  %".265" = zext i32 %".16" to i64
  %".266" = shl i64 %".265", 32
  %"shf_concat.10" = or i64 %".264", %".266"
  %"shf_shift_64.10" = zext i32 4 to i64
  %".267" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi" = lshr i64 %".267", 32
  %"shf_result.10" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".268" = xor i32 %"plop3_a_bit", 1
  %".269" = xor i32 %"plop3_b_bit", 1
  %".270" = xor i32 %"plop3_c_bit", 1
  %".271" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".272" = and i32 %".271", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".272", 0
  %"P54_to_i32" = zext i1 %"plop3_pred" to i32
  %".273" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".274" = zext i32 %"iadd3_n2.3" to i64
  %".275" = zext i32 24 to i64
  %".276" = shl i64 %".273", %".275"
  %".277" = and i64 %".276", 4294967295
  %".278" = add i64 %".277", %".274"
  %".279" = trunc i64 %".278" to i32
  %".280" = xor i32 %"shf_result.10", -1
  %".281" = xor i32 16376, -1
  %".282" = xor i32 0, -1
  %".283" = and i32 %"shf_result.10", 16376
  %".284" = and i32 %".283", %".282"
  %".285" = and i32 %"shf_result.10", 16376
  %".286" = and i32 %".285", 0
  %".287" = or i32 %".284", %".286"
  %".288" = zext i32 0 to i64
  %".289" = zext i32 %".279" to i64
  %".290" = shl i64 %".289", 32
  %"shf_concat.11" = or i64 %".288", %".290"
  %"shf_shift_64.11" = zext i32 4 to i64
  %".291" = lshr i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_hi.1" = lshr i64 %".291", 32
  %"shf_result.11" = trunc i64 %"shf_hi.1" to i32
  %".292" = xor i32 %".287", -1
  %".293" = xor i32 524288, -1
  %".294" = xor i32 0, -1
  %".295" = and i32 %".292", 524288
  %".296" = and i32 %".295", %".294"
  %".297" = and i32 %".292", 524288
  %".298" = and i32 %".297", 0
  %".299" = or i32 %".296", %".298"
  %".300" = and i32 %".287", %".293"
  %".301" = and i32 %".300", %".294"
  %".302" = or i32 %".299", %".301"
  %".303" = and i32 %".287", %".293"
  %".304" = and i32 %".303", 0
  %".305" = or i32 %".302", %".304"
  %".306" = and i32 %".287", 524288
  %".307" = and i32 %".306", %".294"
  %".308" = or i32 %".305", %".307"
  %".309" = and i32 %".287", 524288
  %".310" = and i32 %".309", 0
  %".311" = or i32 %".308", %".310"
  %".312" = xor i32 %"shf_result.11", -1
  %".313" = xor i32 16376, -1
  %".314" = xor i32 0, -1
  %".315" = and i32 %"shf_result.11", 16376
  %".316" = and i32 %".315", %".314"
  %".317" = and i32 %"shf_result.11", 16376
  %".318" = and i32 %".317", 0
  %".319" = or i32 %".316", %".318"
  %".320" = xor i32 %".319", -1
  %".321" = xor i32 524288, -1
  %".322" = xor i32 0, -1
  %".323" = and i32 %".320", 524288
  %".324" = and i32 %".323", %".322"
  %".325" = and i32 %".320", 524288
  %".326" = and i32 %".325", 0
  %".327" = or i32 %".324", %".326"
  %".328" = and i32 %".319", %".321"
  %".329" = and i32 %".328", %".322"
  %".330" = or i32 %".327", %".329"
  %".331" = and i32 %".319", %".321"
  %".332" = and i32 %".331", 0
  %".333" = or i32 %".330", %".332"
  %".334" = and i32 %".319", 524288
  %".335" = and i32 %".334", %".322"
  %".336" = or i32 %".333", %".335"
  %".337" = and i32 %".319", 524288
  %".338" = and i32 %".337", 0
  %".339" = or i32 %".336", %".338"
  %"iadd3_n1.4" = add i32 %"imad.32", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", %"lds.1"
  br label %"BB_0ef0"
BB_0ef0:
  %"phi.18" = phi  i32 [%"phi.17", %"BB_0de0"], [%"P11_to_i32", %"BB_0f20"]
  %"phi.19" = phi  i32 [%"P54_to_i32", %"BB_0de0"], [%"phi.21", %"BB_0f20"]
  %"cond_trunc.13" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000ef0", label %"BB_0f00"
BB_80000ef0:
  %"elect_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"election.5" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.5")
  %"elect_p.5" = extractvalue {i32, i1} %"election.5", 1
  %"P17_to_i32" = zext i1 %"elect_p.5" to i32
  br label %"BB_0f00"
BB_0f00:
  %"phi.20" = phi  i32 [%"P17_to_i32", %"BB_80000ef0"], [%"phi.18", %"BB_0ef0"]
  %"mma_b_r0_ext" = zext i32 %".339" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".343" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".344" = sub i64 %".343", 0
  %".345" = lshr i64 %".344", 4
  %".346" = add i64 %"mma_b_packed_1", %".345"
  %".347" = and i64 %".346", 16383
  %".348" = and i64 %"mma_b_packed_1", -16384
  %".349" = or i64 %".348", %".347"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.4", i64 %".349", i32 134747536, i32 %"mma_arg_zext")
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000f10", label %"BB_0f20"
BB_80000f10:
  %"lop3_a_trunc" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".353" = xor i32 %"plop3_a_bit.1", 1
  %".354" = xor i32 %"plop3_b_bit.1", 1
  %".355" = xor i32 %"plop3_c_bit.1", 1
  %".356" = and i32 %".353", %"plop3_b_bit.1"
  %".357" = and i32 %".356", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".357", 0
  %"P79_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0f20"
BB_0f20:
  %"phi.21" = phi  i32 [%"P79_to_i32", %"BB_80000f10"], [%"phi.19", %"BB_0f10"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".359" = xor i32 %"plop3_a_bit.2", 1
  %".360" = xor i32 %"plop3_b_bit.2", 1
  %".361" = xor i32 %"plop3_c_bit.2", 1
  %".362" = and i32 %".359", %"plop3_b_bit.2"
  %".363" = and i32 %".362", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".363", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.10" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.10" = zext i1 %"bra_cond_trunc.10" to i32
  %"bra_cond_to_i1.10" = icmp ne i32 %"bra_cond_to_i32.10", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.10")
  br i1 %"branch_any", label %"BB_0ef0", label %"BB_0f40"
BB_0f40:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".365" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".365" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".366" = xor i32 %"plop3_a_bit.3", 1
  %".367" = xor i32 %"plop3_b_bit.3", 1
  %".368" = xor i32 %"plop3_c_bit.3", 1
  %".369" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".370" = and i32 %".369", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".370", 0
  %"P103_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"iadd3_n1.5" = add i32 %"imad.32", %"lds.2"
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"iadd3_n2.5", 16
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"iadd3_n2.5", 4
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  br label %"BB_0fc0"
BB_0fc0:
  %"phi.22" = phi  i32 [%"P11_to_i32", %"BB_0f40"], [%"P15_to_i32", %"BB_0ff0"]
  %"phi.23" = phi  i32 [%"P103_to_i32", %"BB_0f40"], [%"phi.25", %"BB_0ff0"]
  %"cond_trunc.15" = trunc i32 %"phi.23" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000fc0", label %"BB_0fd0"
BB_80000fc0:
  %"elect_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"election.6" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.6")
  %"elect_p.6" = extractvalue {i32, i1} %"election.6", 1
  %"P13_to_i32" = zext i1 %"elect_p.6" to i32
  br label %"BB_0fd0"
BB_0fd0:
  %"phi.24" = phi  i32 [%"P13_to_i32", %"BB_80000fc0"], [%"phi.22", %"BB_0fc0"]
  %"mma_b_r0_ext.1" = zext i32 %".311" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".374" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".375" = sub i64 %".374", 0
  %".376" = lshr i64 %".375", 4
  %".377" = add i64 %"mma_b_packed_1.1", %".376"
  %".378" = and i64 %".377", 16383
  %".379" = and i64 %"mma_b_packed_1.1", -16384
  %".380" = or i64 %".379", %".378"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.6", i64 %".380", i32 679744944, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.7")
  br label %"BB_0fe0"
BB_0fe0:
  %"cond_trunc.16" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000fe0", label %"BB_0ff0"
BB_80000fe0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.24" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".384" = xor i32 %"plop3_a_bit.4", 1
  %".385" = xor i32 %"plop3_b_bit.4", 1
  %".386" = xor i32 %"plop3_c_bit.4", 1
  %".387" = and i32 %".384", %"plop3_b_bit.4"
  %".388" = and i32 %".387", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".388", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0ff0"
BB_0ff0:
  %"phi.25" = phi  i32 [%"P9_to_i32", %"BB_80000fe0"], [%"phi.23", %"BB_0fe0"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".390" = xor i32 %"plop3_a_bit.5", 1
  %".391" = xor i32 %"plop3_b_bit.5", 1
  %".392" = xor i32 %"plop3_c_bit.5", 1
  %".393" = and i32 %".390", %"plop3_b_bit.5"
  %".394" = and i32 %".393", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".394", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.11" = trunc i32 %"phi.25" to i1
  %"bra_cond_to_i32.11" = zext i1 %"bra_cond_trunc.11" to i32
  %"bra_cond_to_i1.11" = icmp ne i32 %"bra_cond_to_i32.11", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.11")
  br i1 %"branch_any.1", label %"BB_0fc0", label %"BB_1010"
BB_1010:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".396" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".397" = xor i32 %"plop3_a_bit.6", 1
  %".398" = xor i32 %"plop3_b_bit.6", 1
  %".399" = xor i32 %"plop3_c_bit.6", 1
  %".400" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".401" = and i32 %".400", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".401", 0
  %"P35_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"iadd3_n1.8" = add i32 %"imad.32", %"lds.3"
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"iadd3_n2.8", 16
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"iadd3_n1.10" = add i32 %"iadd3_n2.8", 4
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  br label %"BB_1070"
BB_1070:
  %"phi.26" = phi  i32 [%"P15_to_i32", %"BB_1010"], [%"P21_to_i32", %"BB_10a0"]
  %"phi.27" = phi  i32 [%"P35_to_i32", %"BB_1010"], [%"phi.29", %"BB_10a0"]
  %"cond_trunc.17" = trunc i32 %"phi.27" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001070", label %"BB_1080"
BB_80001070:
  %"elect_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"election.7" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.7")
  %"elect_p.7" = extractvalue {i32, i1} %"election.7", 1
  %"P19_to_i32" = zext i1 %"elect_p.7" to i32
  br label %"BB_1080"
BB_1080:
  %"phi.28" = phi  i32 [%"P19_to_i32", %"BB_80001070"], [%"phi.26", %"BB_1070"]
  %"mma_b_r0_ext.2" = zext i32 %".311" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".405" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".406" = sub i64 %".405", 0
  %".407" = lshr i64 %".406", 4
  %".408" = add i64 %"mma_b_packed_1.2", %".407"
  %".409" = and i64 %".408", 16383
  %".410" = and i64 %"mma_b_packed_1.2", -16384
  %".411" = or i64 %".410", %".409"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.9", i64 %".411", i32 679744944, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.8", i32 %"iadd3_n2.10")
  br label %"BB_1090"
BB_1090:
  %"cond_trunc.18" = trunc i32 %"phi.28" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80001090", label %"BB_10a0"
BB_80001090:
  %"lop3_a_trunc.2" = trunc i32 %"phi.28" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".415" = xor i32 %"plop3_a_bit.7", 1
  %".416" = xor i32 %"plop3_b_bit.7", 1
  %".417" = xor i32 %"plop3_c_bit.7", 1
  %".418" = and i32 %".415", %"plop3_b_bit.7"
  %".419" = and i32 %".418", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".419", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_10a0"
BB_10a0:
  %"phi.29" = phi  i32 [%"P44_to_i32", %"BB_80001090"], [%"phi.27", %"BB_1090"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".421" = xor i32 %"plop3_a_bit.8", 1
  %".422" = xor i32 %"plop3_b_bit.8", 1
  %".423" = xor i32 %"plop3_c_bit.8", 1
  %".424" = and i32 %".421", %"plop3_b_bit.8"
  %".425" = and i32 %".424", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".425", 0
  %"P21_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.12" = trunc i32 %"phi.29" to i1
  %"bra_cond_to_i32.12" = zext i1 %"bra_cond_trunc.12" to i32
  %"bra_cond_to_i1.12" = icmp ne i32 %"bra_cond_to_i32.12", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.12")
  br i1 %"branch_any.2", label %"BB_1070", label %"BB_10c0"
BB_10c0:
  %"iadd3_n1.11" = add i32 1024, 2048
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".427" = xor i32 %"plop3_a_bit.9", 1
  %".428" = xor i32 %"plop3_b_bit.9", 1
  %".429" = xor i32 %"plop3_c_bit.9", 1
  %".430" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".431" = and i32 %".430", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".431", 0
  %"P49_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".432" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".433" = zext i32 %"iadd3_n2.11" to i64
  %".434" = zext i32 24 to i64
  %".435" = shl i64 %".432", %".434"
  %".436" = and i64 %".435", 4294967295
  %".437" = add i64 %".436", %".433"
  %".438" = trunc i64 %".437" to i32
  br label %"BB_10f0"
BB_10f0:
  %"phi.30" = phi  i32 [%"P21_to_i32", %"BB_10c0"], [%"P27_to_i32", %"BB_1120"]
  %"phi.31" = phi  i32 [%"P49_to_i32", %"BB_10c0"], [%"phi.33", %"BB_1120"]
  %"cond_trunc.19" = trunc i32 %"phi.31" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_800010f0", label %"BB_1100"
BB_800010f0:
  %"elect_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"election.8" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.8")
  %"elect_p.8" = extractvalue {i32, i1} %"election.8", 1
  %"P25_to_i32" = zext i1 %"elect_p.8" to i32
  br label %"BB_1100"
BB_1100:
  %"phi.32" = phi  i32 [%"P25_to_i32", %"BB_800010f0"], [%"phi.30", %"BB_10f0"]
  %"utcbar_local_winoff" = and i32 %".438", 16777215
  %".442" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".443" = ptrtoint i8 addrspace(3)* %".442" to i32
  %".444" = lshr i32 %".438", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".443", i32 %".444")
  br label %"BB_1110"
BB_1110:
  %"cond_trunc.20" = trunc i32 %"phi.32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80001110", label %"BB_1120"
BB_80001110:
  %"lop3_a_trunc.3" = trunc i32 %"phi.32" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".448" = xor i32 %"plop3_a_bit.10", 1
  %".449" = xor i32 %"plop3_b_bit.10", 1
  %".450" = xor i32 %"plop3_c_bit.10", 1
  %".451" = and i32 %".448", %"plop3_b_bit.10"
  %".452" = and i32 %".451", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".452", 0
  %"P52_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_1120"
BB_1120:
  %"phi.33" = phi  i32 [%"P52_to_i32", %"BB_80001110"], [%"phi.31", %"BB_1110"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".454" = xor i32 %"plop3_a_bit.11", 1
  %".455" = xor i32 %"plop3_b_bit.11", 1
  %".456" = xor i32 %"plop3_c_bit.11", 1
  %".457" = and i32 %".454", %"plop3_b_bit.11"
  %".458" = and i32 %".457", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".458", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.13" = trunc i32 %"phi.33" to i1
  %"bra_cond_to_i32.13" = zext i1 %"bra_cond_trunc.13" to i32
  %"bra_cond_to_i1.13" = icmp ne i32 %"bra_cond_to_i32.13", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.13")
  br i1 %"branch_any.3", label %"BB_10f0", label %"BB_1140"
BB_1140:
  %"isetrp_cmp1.5" = icmp uge i32 %"tid_x", 32
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"lop3_a_cast_zext.12" = zext i1 1 to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".460" = xor i32 %"plop3_a_bit.12", 1
  %".461" = xor i32 %"plop3_b_bit.12", 1
  %".462" = xor i32 %"plop3_c_bit.12", 1
  %".463" = and i32 %"plop3_a_bit.12", %"plop3_b_bit.12"
  %".464" = and i32 %".463", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".464", 0
  %"P55_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_1180"
BB_1180:
  %"cond_trunc.21" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_15c0", label %"BB_1190"
BB_1190:
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".467" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".468" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".469" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".470" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldg_addr_r0_ext.18" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9220
  %"R309:R305_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.16"
  %"ldg_addr_r0_ext.19" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.19" = or i64 0, %"ldg_addr_r0_ext.19"
  %"ldg_addr_r1_ext.19" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.19" = shl i64 %"ldg_addr_r1_ext.19", 32
  %"ldg_addr_packed_1.19" = or i64 %"ldg_addr_packed_0.19", %"ldg_addr_r1_shift.19"
  %"ldg_addr_memaddr_offset_add.18" = add i64 %"ldg_addr_packed_1.19", 9216
  %"R309:R305_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  %"ldg.19" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.17"
  %"ldg_addr_r0_ext.20" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.20" = or i64 0, %"ldg_addr_r0_ext.20"
  %"ldg_addr_r1_ext.20" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.20" = shl i64 %"ldg_addr_r1_ext.20", 32
  %"ldg_addr_packed_1.20" = or i64 %"ldg_addr_packed_0.20", %"ldg_addr_r1_shift.20"
  %"ldg_addr_memaddr_offset_add.19" = add i64 %"ldg_addr_packed_1.20", 9224
  %"R309:R305_addr_ptr.18" = inttoptr i64 %"ldg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  %"ldg.20" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.18"
  %"ldg_addr_r0_ext.21" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.21" = or i64 0, %"ldg_addr_r0_ext.21"
  %"ldg_addr_r1_ext.21" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.21" = shl i64 %"ldg_addr_r1_ext.21", 32
  %"ldg_addr_packed_1.21" = or i64 %"ldg_addr_packed_0.21", %"ldg_addr_r1_shift.21"
  %"ldg_addr_memaddr_offset_add.20" = add i64 %"ldg_addr_packed_1.21", 9228
  %"R309:R305_addr_ptr.19" = inttoptr i64 %"ldg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  %"ldg.21" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.19"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.31", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".471" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".472" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".473" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".474" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"ldg_addr_r0_ext.22" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.22" = or i64 0, %"ldg_addr_r0_ext.22"
  %"ldg_addr_r1_ext.22" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.22" = shl i64 %"ldg_addr_r1_ext.22", 32
  %"ldg_addr_packed_1.22" = or i64 %"ldg_addr_packed_0.22", %"ldg_addr_r1_shift.22"
  %"ldg_addr_memaddr_offset_add.21" = add i64 %"ldg_addr_packed_1.22", 9232
  %"R309:R305_addr_ptr.20" = inttoptr i64 %"ldg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  %"ldg.22" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.20"
  %"ldg_addr_r0_ext.23" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.23" = or i64 0, %"ldg_addr_r0_ext.23"
  %"ldg_addr_r1_ext.23" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.23" = shl i64 %"ldg_addr_r1_ext.23", 32
  %"ldg_addr_packed_1.23" = or i64 %"ldg_addr_packed_0.23", %"ldg_addr_r1_shift.23"
  %"ldg_addr_memaddr_offset_add.22" = add i64 %"ldg_addr_packed_1.23", 9236
  %"R309:R305_addr_ptr.21" = inttoptr i64 %"ldg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  %"ldg.23" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.21"
  %"ldg_addr_r0_ext.24" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.24" = or i64 0, %"ldg_addr_r0_ext.24"
  %"ldg_addr_r1_ext.24" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.24" = shl i64 %"ldg_addr_r1_ext.24", 32
  %"ldg_addr_packed_1.24" = or i64 %"ldg_addr_packed_0.24", %"ldg_addr_r1_shift.24"
  %"ldg_addr_memaddr_offset_add.23" = add i64 %"ldg_addr_packed_1.24", 9240
  %"R309:R305_addr_ptr.22" = inttoptr i64 %"ldg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  %"ldg.24" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.22"
  %"ldg_addr_r0_ext.25" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.25" = or i64 0, %"ldg_addr_r0_ext.25"
  %"ldg_addr_r1_ext.25" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.25" = shl i64 %"ldg_addr_r1_ext.25", 32
  %"ldg_addr_packed_1.25" = or i64 %"ldg_addr_packed_0.25", %"ldg_addr_r1_shift.25"
  %"ldg_addr_memaddr_offset_add.24" = add i64 %"ldg_addr_packed_1.25", 9244
  %"R309:R305_addr_ptr.23" = inttoptr i64 %"ldg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  %"ldg.25" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.23"
  %"isetrp_cmp1.6" = icmp ne i32 %".468", %"ldg.18"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".475" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".476" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".477" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".478" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"ldg_addr_r0_ext.26" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.26" = or i64 0, %"ldg_addr_r0_ext.26"
  %"ldg_addr_r1_ext.26" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.26" = shl i64 %"ldg_addr_r1_ext.26", 32
  %"ldg_addr_packed_1.26" = or i64 %"ldg_addr_packed_0.26", %"ldg_addr_r1_shift.26"
  %"ldg_addr_memaddr_offset_add.25" = add i64 %"ldg_addr_packed_1.26", 9216
  %"R309:R305_addr_ptr.24" = inttoptr i64 %"ldg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  %"ldg.26" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.24"
  %"isetrp_src_trunc" = trunc i32 %"P56_to_i32" to i1
  %"isetrp_src_not" = xor i1 %"isetrp_src_trunc", -1
  %"isetrp_cmp1.7" = icmp eq i32 %".467", %"ldg.19"
  %"isetrp_src_to_i32.7" = zext i1 %"isetrp_src_not" to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"ldg_addr_r0_ext.27" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.27" = or i64 0, %"ldg_addr_r0_ext.27"
  %"ldg_addr_r1_ext.27" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.27" = shl i64 %"ldg_addr_r1_ext.27", 32
  %"ldg_addr_packed_1.27" = or i64 %"ldg_addr_packed_0.27", %"ldg_addr_r1_shift.27"
  %"ldg_addr_memaddr_offset_add.26" = add i64 %"ldg_addr_packed_1.27", 9220
  %"R309:R305_addr_ptr.25" = inttoptr i64 %"ldg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  %"ldg.27" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.25"
  %"isetrp_src_trunc.1" = trunc i32 %"P58_to_i32" to i1
  %"isetrp_cmp1.8" = icmp eq i32 %".469", %"ldg.20"
  %"isetrp_src_to_i32.8" = zext i1 %"isetrp_src_trunc.1" to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P59_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldg_addr_r0_ext.28" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.28" = or i64 0, %"ldg_addr_r0_ext.28"
  %"ldg_addr_r1_ext.28" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.28" = shl i64 %"ldg_addr_r1_ext.28", 32
  %"ldg_addr_packed_1.28" = or i64 %"ldg_addr_packed_0.28", %"ldg_addr_r1_shift.28"
  %"ldg_addr_memaddr_offset_add.27" = add i64 %"ldg_addr_packed_1.28", 9224
  %"R309:R305_addr_ptr.26" = inttoptr i64 %"ldg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  %"ldg.28" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.26"
  %"isetrp_src_trunc.2" = trunc i32 %"P59_to_i32" to i1
  %"isetrp_cmp1.9" = icmp eq i32 %".470", %"ldg.21"
  %"isetrp_src_to_i32.9" = zext i1 %"isetrp_src_trunc.2" to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P60_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldg_addr_r0_ext.29" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.29" = or i64 0, %"ldg_addr_r0_ext.29"
  %"ldg_addr_r1_ext.29" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.29" = shl i64 %"ldg_addr_r1_ext.29", 32
  %"ldg_addr_packed_1.29" = or i64 %"ldg_addr_packed_0.29", %"ldg_addr_r1_shift.29"
  %"ldg_addr_memaddr_offset_add.28" = add i64 %"ldg_addr_packed_1.29", 9228
  %"R309:R305_addr_ptr.27" = inttoptr i64 %"ldg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  %"ldg.29" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.27"
  %"isetrp_src_trunc.3" = trunc i32 %"P60_to_i32" to i1
  %"isetrp_cmp1.10" = icmp eq i32 %".471", %"ldg.22"
  %"isetrp_src_to_i32.10" = zext i1 %"isetrp_src_trunc.3" to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P62_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.31", 4
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".479" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".480" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".481" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".482" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"ldg_addr_r0_ext.30" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.30" = or i64 0, %"ldg_addr_r0_ext.30"
  %"ldg_addr_r1_ext.30" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.30" = shl i64 %"ldg_addr_r1_ext.30", 32
  %"ldg_addr_packed_1.30" = or i64 %"ldg_addr_packed_0.30", %"ldg_addr_r1_shift.30"
  %"ldg_addr_memaddr_offset_add.29" = add i64 %"ldg_addr_packed_1.30", 9232
  %"R309:R305_addr_ptr.28" = inttoptr i64 %"ldg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  %"ldg.30" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.28"
  %"ldg_addr_r0_ext.31" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.31" = or i64 0, %"ldg_addr_r0_ext.31"
  %"ldg_addr_r1_ext.31" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.31" = shl i64 %"ldg_addr_r1_ext.31", 32
  %"ldg_addr_packed_1.31" = or i64 %"ldg_addr_packed_0.31", %"ldg_addr_r1_shift.31"
  %"ldg_addr_memaddr_offset_add.30" = add i64 %"ldg_addr_packed_1.31", 9236
  %"R309:R305_addr_ptr.29" = inttoptr i64 %"ldg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  %"ldg.31" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.29"
  %"isetrp_src_trunc.4" = trunc i32 %"P62_to_i32" to i1
  %"isetrp_cmp1.11" = icmp eq i32 %".472", %"ldg.23"
  %"isetrp_src_to_i32.11" = zext i1 %"isetrp_src_trunc.4" to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P63_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"ldg_addr_r0_ext.32" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.32" = or i64 0, %"ldg_addr_r0_ext.32"
  %"ldg_addr_r1_ext.32" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.32" = shl i64 %"ldg_addr_r1_ext.32", 32
  %"ldg_addr_packed_1.32" = or i64 %"ldg_addr_packed_0.32", %"ldg_addr_r1_shift.32"
  %"ldg_addr_memaddr_offset_add.31" = add i64 %"ldg_addr_packed_1.32", 9244
  %"R309:R305_addr_ptr.30" = inttoptr i64 %"ldg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  %"ldg.32" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.30"
  %"isetrp_src_trunc.5" = trunc i32 %"P63_to_i32" to i1
  %"isetrp_cmp1.12" = icmp eq i32 %".473", %"ldg.24"
  %"isetrp_src_to_i32.12" = zext i1 %"isetrp_src_trunc.5" to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P64_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"ldg_addr_r0_ext.33" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.33" = or i64 0, %"ldg_addr_r0_ext.33"
  %"ldg_addr_r1_ext.33" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.33" = shl i64 %"ldg_addr_r1_ext.33", 32
  %"ldg_addr_packed_1.33" = or i64 %"ldg_addr_packed_0.33", %"ldg_addr_r1_shift.33"
  %"ldg_addr_memaddr_offset_add.32" = add i64 %"ldg_addr_packed_1.33", 9240
  %"R309:R305_addr_ptr.31" = inttoptr i64 %"ldg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  %"ldg.33" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.31"
  %"isetrp_src_trunc.6" = trunc i32 %"P64_to_i32" to i1
  %"isetrp_cmp1.13" = icmp eq i32 %".474", %"ldg.25"
  %"isetrp_src_to_i32.13" = zext i1 %"isetrp_src_trunc.6" to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P65_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".483" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".484" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".485" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".486" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"ldg_addr_r0_ext.34" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.34" = or i64 0, %"ldg_addr_r0_ext.34"
  %"ldg_addr_r1_ext.34" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.34" = shl i64 %"ldg_addr_r1_ext.34", 32
  %"ldg_addr_packed_1.34" = or i64 %"ldg_addr_packed_0.34", %"ldg_addr_r1_shift.34"
  %"ldg_addr_memaddr_offset_add.33" = add i64 %"ldg_addr_packed_1.34", 9220
  %"R309:R305_addr_ptr.32" = inttoptr i64 %"ldg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  %"ldg.34" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.32"
  %"isetrp_src_trunc.7" = trunc i32 %"P65_to_i32" to i1
  %"isetrp_cmp1.14" = icmp eq i32 %".475", %"ldg.26"
  %"isetrp_src_to_i32.14" = zext i1 %"isetrp_src_trunc.7" to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P67_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"ldg_addr_r0_ext.35" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.35" = or i64 0, %"ldg_addr_r0_ext.35"
  %"ldg_addr_r1_ext.35" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.35" = shl i64 %"ldg_addr_r1_ext.35", 32
  %"ldg_addr_packed_1.35" = or i64 %"ldg_addr_packed_0.35", %"ldg_addr_r1_shift.35"
  %"ldg_addr_memaddr_offset_add.34" = add i64 %"ldg_addr_packed_1.35", 9216
  %"R309:R305_addr_ptr.33" = inttoptr i64 %"ldg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  %"ldg.35" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.33"
  %"isetrp_src_trunc.8" = trunc i32 %"P67_to_i32" to i1
  %"isetrp_cmp1.15" = icmp eq i32 %".476", %"ldg.27"
  %"isetrp_src_to_i32.15" = zext i1 %"isetrp_src_trunc.8" to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P69_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  %"isetrp_src_trunc.9" = trunc i32 %"P69_to_i32" to i1
  %"isetrp_cmp1.16" = icmp eq i32 %".477", %"ldg.28"
  %"isetrp_src_to_i32.16" = zext i1 %"isetrp_src_trunc.9" to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P70_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"ldg_addr_r0_ext.36" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.36" = or i64 0, %"ldg_addr_r0_ext.36"
  %"ldg_addr_r1_ext.36" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.36" = shl i64 %"ldg_addr_r1_ext.36", 32
  %"ldg_addr_packed_1.36" = or i64 %"ldg_addr_packed_0.36", %"ldg_addr_r1_shift.36"
  %"ldg_addr_memaddr_offset_add.35" = add i64 %"ldg_addr_packed_1.36", 9224
  %"R309:R305_addr_ptr.34" = inttoptr i64 %"ldg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  %"ldg.36" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.34"
  %"isetrp_src_trunc.10" = trunc i32 %"P70_to_i32" to i1
  %"isetrp_cmp1.17" = icmp eq i32 %".478", %"ldg.29"
  %"isetrp_src_to_i32.17" = zext i1 %"isetrp_src_trunc.10" to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P71_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"ldg_addr_r0_ext.37" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.37" = or i64 0, %"ldg_addr_r0_ext.37"
  %"ldg_addr_r1_ext.37" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.37" = shl i64 %"ldg_addr_r1_ext.37", 32
  %"ldg_addr_packed_1.37" = or i64 %"ldg_addr_packed_0.37", %"ldg_addr_r1_shift.37"
  %"ldg_addr_memaddr_offset_add.36" = add i64 %"ldg_addr_packed_1.37", 9228
  %"R309:R305_addr_ptr.35" = inttoptr i64 %"ldg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  %"ldg.37" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.35"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.31", 4
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".487" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".488" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".489" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".490" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"isetrp_src_trunc.11" = trunc i32 %"P71_to_i32" to i1
  %"isetrp_cmp1.18" = icmp eq i32 %".479", %"ldg.30"
  %"isetrp_src_to_i32.18" = zext i1 %"isetrp_src_trunc.11" to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P74_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  %"ldg_addr_r0_ext.38" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.38" = or i64 0, %"ldg_addr_r0_ext.38"
  %"ldg_addr_r1_ext.38" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.38" = shl i64 %"ldg_addr_r1_ext.38", 32
  %"ldg_addr_packed_1.38" = or i64 %"ldg_addr_packed_0.38", %"ldg_addr_r1_shift.38"
  %"ldg_addr_memaddr_offset_add.37" = add i64 %"ldg_addr_packed_1.38", 9232
  %"R309:R305_addr_ptr.36" = inttoptr i64 %"ldg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  %"ldg.38" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.36"
  %"ldg_addr_r0_ext.39" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.39" = or i64 0, %"ldg_addr_r0_ext.39"
  %"ldg_addr_r1_ext.39" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.39" = shl i64 %"ldg_addr_r1_ext.39", 32
  %"ldg_addr_packed_1.39" = or i64 %"ldg_addr_packed_0.39", %"ldg_addr_r1_shift.39"
  %"ldg_addr_memaddr_offset_add.38" = add i64 %"ldg_addr_packed_1.39", 9236
  %"R309:R305_addr_ptr.37" = inttoptr i64 %"ldg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  %"ldg.39" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.37"
  %"isetrp_src_trunc.12" = trunc i32 %"P74_to_i32" to i1
  %"isetrp_cmp1.19" = icmp eq i32 %".480", %"ldg.31"
  %"isetrp_src_to_i32.19" = zext i1 %"isetrp_src_trunc.12" to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P75_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"ldg_addr_r0_ext.40" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.40" = or i64 0, %"ldg_addr_r0_ext.40"
  %"ldg_addr_r1_ext.40" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.40" = shl i64 %"ldg_addr_r1_ext.40", 32
  %"ldg_addr_packed_1.40" = or i64 %"ldg_addr_packed_0.40", %"ldg_addr_r1_shift.40"
  %"ldg_addr_memaddr_offset_add.39" = add i64 %"ldg_addr_packed_1.40", 9240
  %"R309:R305_addr_ptr.38" = inttoptr i64 %"ldg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  %"ldg.40" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.38"
  %"ldg_addr_r0_ext.41" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.41" = or i64 0, %"ldg_addr_r0_ext.41"
  %"ldg_addr_r1_ext.41" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.41" = shl i64 %"ldg_addr_r1_ext.41", 32
  %"ldg_addr_packed_1.41" = or i64 %"ldg_addr_packed_0.41", %"ldg_addr_r1_shift.41"
  %"ldg_addr_memaddr_offset_add.40" = add i64 %"ldg_addr_packed_1.41", 9244
  %"R309:R305_addr_ptr.39" = inttoptr i64 %"ldg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  %"ldg.41" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.39"
  %"isetrp_src_trunc.13" = trunc i32 %"P75_to_i32" to i1
  %"isetrp_cmp1.20" = icmp eq i32 %".481", %"ldg.33"
  %"isetrp_src_to_i32.20" = zext i1 %"isetrp_src_trunc.13" to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P76_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  %"isetrp_src_trunc.14" = trunc i32 %"P76_to_i32" to i1
  %"isetrp_cmp1.21" = icmp eq i32 %".482", %"ldg.32"
  %"isetrp_src_to_i32.21" = zext i1 %"isetrp_src_trunc.14" to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P77_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %"isetrp_src_trunc.15" = trunc i32 %"P77_to_i32" to i1
  %"isetrp_cmp1.22" = icmp eq i32 %".483", %"ldg.35"
  %"isetrp_src_to_i32.22" = zext i1 %"isetrp_src_trunc.15" to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P78_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"isetrp_src_trunc.16" = trunc i32 %"P78_to_i32" to i1
  %"isetrp_cmp1.23" = icmp eq i32 %".484", %"ldg.34"
  %"isetrp_src_to_i32.23" = zext i1 %"isetrp_src_trunc.16" to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P81_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"isetrp_src_trunc.17" = trunc i32 %"P81_to_i32" to i1
  %"isetrp_cmp1.24" = icmp eq i32 %".485", %"ldg.36"
  %"isetrp_src_to_i32.24" = zext i1 %"isetrp_src_trunc.17" to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P82_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %"isetrp_src_trunc.18" = trunc i32 %"P82_to_i32" to i1
  %"isetrp_cmp1.25" = icmp eq i32 %".486", %"ldg.37"
  %"isetrp_src_to_i32.25" = zext i1 %"isetrp_src_trunc.18" to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P84_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  %"isetrp_src_trunc.19" = trunc i32 %"P84_to_i32" to i1
  %"isetrp_cmp1.26" = icmp eq i32 %".487", %"ldg.38"
  %"isetrp_src_to_i32.26" = zext i1 %"isetrp_src_trunc.19" to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P85_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"isetrp_src_trunc.20" = trunc i32 %"P85_to_i32" to i1
  %"isetrp_cmp1.27" = icmp eq i32 %".488", %"ldg.39"
  %"isetrp_src_to_i32.27" = zext i1 %"isetrp_src_trunc.20" to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P86_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %"isetrp_src_trunc.21" = trunc i32 %"P86_to_i32" to i1
  %"isetrp_cmp1.28" = icmp eq i32 %".489", %"ldg.40"
  %"isetrp_src_to_i32.28" = zext i1 %"isetrp_src_trunc.21" to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P88_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"isetrp_src_trunc.22" = trunc i32 %"P88_to_i32" to i1
  %"isetrp_cmp1.29" = icmp eq i32 %".490", %"ldg.41"
  %"isetrp_src_to_i32.29" = zext i1 %"isetrp_src_trunc.22" to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = and i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P89_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  br label %"BB_15c0"
BB_15c0:
  %"phi.34" = phi  i32 [%"P89_to_i32", %"BB_1190"], [%"P55_to_i32", %"BB_1180"]
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.12" = add i32 1024, 2048
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", 0
  %".492" = zext i32 0 to i64
  %".493" = zext i32 0 to i64
  %".494" = shl i64 %".493", 32
  %"shf_concat.12" = or i64 %".492", %".494"
  %"shf_shift_64.12" = zext i32 31 to i64
  %".495" = shl i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_result.12" = trunc i64 %".495" to i32
  %".496" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".497" = zext i32 %"iadd3_n2.12" to i64
  %".498" = zext i32 24 to i64
  %".499" = shl i64 %".496", %".498"
  %".500" = and i64 %".499", 4294967295
  %".501" = add i64 %".500", %".497"
  %".502" = trunc i64 %".501" to i32
  %"mbar_shared_winoff.1" = and i32 %".502", 16777215
  %".503" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".503" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.12", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P31_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_1620"
BB_1620:
  %"cond_trunc.22" = trunc i32 %"P31_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.22", -1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_2760", label %"BB_1630"
BB_2760:
  %"mbar_shared_winoff.2" = and i32 %".502", 16777215
  %".506" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".506" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.12", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P32_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_2770"
BB_2770:
  %"cond_trunc.23" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.23", -1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_2760", label %"BB_1630"
BB_1630:
  %".509" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".510" = bitcast i8* %".509" to i64*
  %"ldc_const.3" = load i64, i64* %".510"
  %"R19:R18_r0" = trunc i64 %"ldc_const.3" to i32
  %"R19:R18_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"imad_tmp.32" = mul i32 %"tid_x", 40
  %"imad.34" = add i32 %"imad_tmp.32", 0
  %"imad_tmp.33" = mul i32 %"imad.32", 1
  %"imad.35" = add i32 %"imad_tmp.33", %"imad.33"
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.33")
  %".511" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".512" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".513" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".514" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.33", 4
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".515" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".516" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".517" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".518" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.34" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.36" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R19:R18_r0.1" = trunc i64 %"imad.36" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"imad.36", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R118:R65_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".511", i32 addrspace(1)* %"R118:R65_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R118:R65_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".512", i32 addrspace(1)* %"R118:R65_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R118:R65_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".513", i32 addrspace(1)* %"R118:R65_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R118:R65_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".514", i32 addrspace(1)* %"R118:R65_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R118:R65_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".515", i32 addrspace(1)* %"R118:R65_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.33", 8
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".524" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".525" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".526" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".527" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R118:R65_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".516", i32 addrspace(1)* %"R118:R65_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R118:R65_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".517", i32 addrspace(1)* %"R118:R65_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R118:R65_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".518", i32 addrspace(1)* %"R118:R65_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.33", 12
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".531" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".532" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".533" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".534" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R118:R65_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".524", i32 addrspace(1)* %"R118:R65_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R118:R65_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".525", i32 addrspace(1)* %"R118:R65_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R118:R65_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".526", i32 addrspace(1)* %"R118:R65_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R118:R65_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".527", i32 addrspace(1)* %"R118:R65_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R118:R65_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".531", i32 addrspace(1)* %"R118:R65_addr_ptr.12"
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.31")
  %".540" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".541" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".542" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".543" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R118:R65_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".532", i32 addrspace(1)* %"R118:R65_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R118:R65_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".533", i32 addrspace(1)* %"R118:R65_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R118:R65_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".534", i32 addrspace(1)* %"R118:R65_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.35", 4
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".547" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".548" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".549" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".550" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R118:R65_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".540", i32 addrspace(1)* %"R118:R65_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R118:R65_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".541", i32 addrspace(1)* %"R118:R65_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R118:R65_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".542", i32 addrspace(1)* %"R118:R65_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R118:R65_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".543", i32 addrspace(1)* %"R118:R65_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R118:R65_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".547", i32 addrspace(1)* %"R118:R65_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.33", 16
  %"ldtm.12" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".556" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 0
  %".557" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 1
  %".558" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 2
  %".559" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R118:R65_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".548", i32 addrspace(1)* %"R118:R65_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R118:R65_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".549", i32 addrspace(1)* %"R118:R65_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R118:R65_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".550", i32 addrspace(1)* %"R118:R65_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.33", 20
  %"ldtm.13" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".563" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 0
  %".564" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 1
  %".565" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 2
  %".566" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R118:R65_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".556", i32 addrspace(1)* %"R118:R65_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R118:R65_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".557", i32 addrspace(1)* %"R118:R65_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R118:R65_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".558", i32 addrspace(1)* %"R118:R65_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R118:R65_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".559", i32 addrspace(1)* %"R118:R65_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R118:R65_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".563", i32 addrspace(1)* %"R118:R65_addr_ptr.28"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.33", 24
  %"ldtm.14" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".572" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 0
  %".573" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 1
  %".574" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 2
  %".575" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 3
  %"stg_addr_r0_ext.29" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R118:R65_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".564", i32 addrspace(1)* %"R118:R65_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R118:R65_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".565", i32 addrspace(1)* %"R118:R65_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R118:R65_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".566", i32 addrspace(1)* %"R118:R65_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.33", 28
  %"ldtm.15" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".579" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 0
  %".580" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 1
  %".581" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 2
  %".582" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 3
  %"stg_addr_r0_ext.32" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 128
  %"R118:R65_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".572", i32 addrspace(1)* %"R118:R65_addr_ptr.32"
  %"stg_addr_r0_ext.33" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 132
  %"R118:R65_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".573", i32 addrspace(1)* %"R118:R65_addr_ptr.33"
  %"stg_addr_r0_ext.34" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 136
  %"R118:R65_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".574", i32 addrspace(1)* %"R118:R65_addr_ptr.34"
  %"stg_addr_r0_ext.35" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 140
  %"R118:R65_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".575", i32 addrspace(1)* %"R118:R65_addr_ptr.35"
  %"stg_addr_r0_ext.36" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 144
  %"R118:R65_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".579", i32 addrspace(1)* %"R118:R65_addr_ptr.36"
  %"stg_addr_r0_ext.37" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 148
  %"R118:R65_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".580", i32 addrspace(1)* %"R118:R65_addr_ptr.37"
  %"stg_addr_r0_ext.38" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 152
  %"R118:R65_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".581", i32 addrspace(1)* %"R118:R65_addr_ptr.38"
  %"stg_addr_r0_ext.39" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 156
  %"R118:R65_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".582", i32 addrspace(1)* %"R118:R65_addr_ptr.39"
  br label %"BB_1ab0"
BB_1ab0:
  %"cond_trunc.24" = trunc i32 %"phi.34" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_1af0", label %"BB_1ac0"
BB_1ac0:
  %"ldg_addr_r0_ext.42" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.42" = or i64 0, %"ldg_addr_r0_ext.42"
  %"ldg_addr_r1_ext.42" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.42" = shl i64 %"ldg_addr_r1_ext.42", 32
  %"ldg_addr_packed_1.42" = or i64 %"ldg_addr_packed_0.42", %"ldg_addr_r1_shift.42"
  %"ldg_addr_memaddr_offset_add.41" = add i64 %"ldg_addr_packed_1.42", 9216
  %"R309:R305_addr_ptr.40" = inttoptr i64 %"ldg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  %"ldg.42" = load i32, i32 addrspace(1)* %"R309:R305_addr_ptr.40"
  %".593" = xor i32 0, -1
  %".594" = xor i32 %"ldg.42", -1
  %".595" = xor i32 0, -1
  %".596" = and i32 %".593", %".594"
  %".597" = and i32 %".596", %".595"
  %".598" = and i32 %".593", %".594"
  %".599" = and i32 %".598", 0
  %".600" = or i32 %".597", %".599"
  %".601" = and i32 0, %".594"
  %".602" = and i32 %".601", %".595"
  %".603" = or i32 %".600", %".602"
  %".604" = and i32 0, %".594"
  %".605" = and i32 %".604", 0
  %".606" = or i32 %".603", %".605"
  %"stg_addr_r0_ext.40" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 64
  %"R118:R65_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".606", i32 addrspace(1)* %"R118:R65_addr_ptr.40"
  br label %"BB_1af0"
BB_1af0:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_1b20"
BB_1b20:
  %"cond_trunc.25" = trunc i32 %"P94_to_i32" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80001b20", label %"BB_1b30"
BB_1b30:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".611" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".611" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.34" = mul i32 0, 0
  %"imad.37" = add i32 %"imad_tmp.34", 1
  %".612" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".613" = zext i32 64 to i64
  %".614" = zext i32 24 to i64
  %".615" = shl i64 %".612", %".614"
  %".616" = and i64 %".615", 4294967295
  %".617" = add i64 %".616", %".613"
  %".618" = trunc i64 %".617" to i32
  %"lds_addr_memaddr_offset_add.5" = add i32 %".618", 20
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".619" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".619" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".620" = xor i32 %"lds.4", -1
  %".621" = xor i32 65535, -1
  %".622" = xor i32 0, -1
  %".623" = and i32 %"lds.4", 65535
  %".624" = and i32 %".623", %".622"
  %".625" = and i32 %"lds.4", 65535
  %".626" = and i32 %".625", 0
  %".627" = or i32 %".624", %".626"
  %".628" = zext i32 0 to i64
  %".629" = zext i32 %".627" to i64
  %".630" = shl i64 %".629", 32
  %"shf_concat.13" = or i64 %".628", %".630"
  %"shf_shift_64.13" = zext i32 5 to i64
  %".631" = lshr i64 %"shf_concat.13", %"shf_shift_64.13"
  %"shf_hi.2" = lshr i64 %".631", 32
  %"shf_result.13" = trunc i64 %"shf_hi.2" to i32
  %".632" = zext i32 %"imad.37" to i64
  %".633" = zext i32 0 to i64
  %".634" = shl i64 %".633", 32
  %"shf_concat.14" = or i64 %".632", %".634"
  %"shf_shift_64.14" = zext i32 %"shf_result.13" to i64
  %".635" = shl i64 %"shf_concat.14", %"shf_shift_64.14"
  %"shf_result.14" = trunc i64 %".635" to i32
  %".636" = xor i32 %"lds.5", -1
  %".637" = xor i32 %"shf_result.14", -1
  %".638" = xor i32 0, -1
  %".639" = and i32 %"lds.5", %"shf_result.14"
  %".640" = and i32 %".639", %".638"
  %".641" = and i32 %"lds.5", %"shf_result.14"
  %".642" = and i32 %".641", 0
  %".643" = or i32 %".640", %".642"
  %"isetrp_cmp1.30" = icmp ne i32 %".643", %"shf_result.14"
  %"isetrp_src_to_i32.30" = zext i1 1 to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = and i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P91_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  br label %"BB_1be0"
BB_1be0:
  %"cond_trunc.26" = trunc i32 %"P91_to_i32" to i1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_trunc.26" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_1d40_27c0", label %"BB_1bf0"
BB_1bf0:
  %"lds_addr_memaddr_offset_add.6" = add i32 %".618", 24
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".646" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".646" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %".647" = xor i32 %"lds.6", -1
  %".648" = xor i32 %"shf_result.14", -1
  %".649" = xor i32 0, -1
  %".650" = and i32 %"lds.6", %"shf_result.14"
  %".651" = and i32 %".650", %".649"
  %".652" = and i32 %"lds.6", %"shf_result.14"
  %".653" = and i32 %".652", 0
  %".654" = or i32 %".651", %".653"
  %"isetrp_cmp1.31" = icmp ne i32 %".654", %"shf_result.14"
  %"isetrp_src_to_i32.31" = zext i1 1 to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P95_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  br label %"BB_1c20"
BB_1c20:
  %"cond_trunc.27" = trunc i32 %"P95_to_i32" to i1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_trunc.27" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_1d10_2790", label %"BB_1c30"
BB_1c30:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".657" = xor i32 0, -1
  %".658" = xor i32 %"shf_result.14", -1
  %".659" = xor i32 0, -1
  %".660" = and i32 %".657", %".658"
  %".661" = and i32 %".660", %".659"
  %".662" = and i32 %".657", %".658"
  %".663" = and i32 %".662", 0
  %".664" = or i32 %".661", %".663"
  %".665" = and i32 0, %".658"
  %".666" = and i32 %".665", %".659"
  %".667" = or i32 %".664", %".666"
  %".668" = and i32 0, %".658"
  %".669" = and i32 %".668", 0
  %".670" = or i32 %".667", %".669"
  %"imad_tmp.35" = mul i32 0, 0
  %"imad.38" = add i32 %"imad_tmp.35", %".670"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.38", i32 %"redux_mask")
  %".671" = xor i32 %".670", -1
  %".672" = call i32 @"llvm.cttz.i32"(i32 %".671", i1 0)
  %".673" = shl i32 %".672", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".673") convergent
  %"isetrp_cmp1.32" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.32" = zext i1 1 to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P96_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %"imad_tmp.36" = mul i32 0, 0
  %"imad.39" = add i32 %"imad_tmp.36", %"redux_sync_and"
  br label %"BB_1cd0"
BB_1cd0:
  %"cond_trunc.28" = trunc i32 %"P96_to_i32" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_80001cd0", label %"BB_1d50"
BB_80001cd0:
  %"atoms_addr_memaddr_offset_add.10" = add i32 %".618", 20
  %"atoms_shared_addr_winoff.10" = and i32 %"atoms_addr_memaddr_offset_add.10", 16777215
  %".677" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.10"
  %"atoms_ptr.10" = bitcast i8 addrspace(3)* %".677" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.10", i32 %"imad.39" monotonic
  %"atoms_addr_memaddr_offset_add.11" = add i32 %".618", 24
  %"atoms_shared_addr_winoff.11" = and i32 %"atoms_addr_memaddr_offset_add.11", 16777215
  %".678" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.11"
  %"atoms_ptr.11" = bitcast i8 addrspace(3)* %".678" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.11", i32 %"imad.39" monotonic
  br label %"BB_1d50"
BB_1d10_2790:
  call void @"llvm.trap"()
  br label %"BB_1d50"
BB_1d40_27c0:
  call void @"llvm.trap"()
  br label %"BB_1d50"
BB_1d50:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.7" = add i32 %".16", 2060
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.7", 16777215
  %".682" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".682" to i32 addrspace(3)*
  %"lds.7" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.7"
  %"imad_tmp.37" = mul i32 0, 0
  %"imad.40" = add i32 %"imad_tmp.37", 1
  %".683" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".684" = zext i32 64 to i64
  %".685" = zext i32 24 to i64
  %".686" = shl i64 %".683", %".685"
  %".687" = and i64 %".686", 4294967295
  %".688" = add i64 %".687", %".684"
  %".689" = trunc i64 %".688" to i32
  %"lds_addr_memaddr_offset_add.8" = add i32 %".689", 20
  %"lds_shared_addr_winoff.8" = and i32 %"lds_addr_memaddr_offset_add.8", 16777215
  %".690" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.8"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".690" to i32 addrspace(3)*
  %"lds.8" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.8"
  %".691" = xor i32 %"lds.7", -1
  %".692" = xor i32 65535, -1
  %".693" = xor i32 0, -1
  %".694" = and i32 %"lds.7", 65535
  %".695" = and i32 %".694", %".693"
  %".696" = and i32 %"lds.7", 65535
  %".697" = and i32 %".696", 0
  %".698" = or i32 %".695", %".697"
  %".699" = zext i32 0 to i64
  %".700" = zext i32 %".698" to i64
  %".701" = shl i64 %".700", 32
  %"shf_concat.15" = or i64 %".699", %".701"
  %"shf_shift_64.15" = zext i32 5 to i64
  %".702" = lshr i64 %"shf_concat.15", %"shf_shift_64.15"
  %"shf_hi.3" = lshr i64 %".702", 32
  %"shf_result.15" = trunc i64 %"shf_hi.3" to i32
  %".703" = zext i32 %"imad.40" to i64
  %".704" = zext i32 0 to i64
  %".705" = shl i64 %".704", 32
  %"shf_concat.16" = or i64 %".703", %".705"
  %"shf_shift_64.16" = zext i32 %"shf_result.15" to i64
  %".706" = shl i64 %"shf_concat.16", %"shf_shift_64.16"
  %"shf_result.16" = trunc i64 %".706" to i32
  %".707" = xor i32 %"lds.8", -1
  %".708" = xor i32 %"shf_result.16", -1
  %".709" = xor i32 0, -1
  %".710" = and i32 %"lds.8", %"shf_result.16"
  %".711" = and i32 %".710", %".709"
  %".712" = and i32 %"lds.8", %"shf_result.16"
  %".713" = and i32 %".712", 0
  %".714" = or i32 %".711", %".713"
  %"isetrp_cmp1.33" = icmp ne i32 %".714", %"shf_result.16"
  %"isetrp_src_to_i32.33" = zext i1 1 to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P97_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  br label %"BB_1e20"
BB_1e20:
  %"cond_trunc.29" = trunc i32 %"P97_to_i32" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_1f80_27c0", label %"BB_1e30"
BB_1e30:
  %"lds_addr_memaddr_offset_add.9" = add i32 %".689", 24
  %"lds_shared_addr_winoff.9" = and i32 %"lds_addr_memaddr_offset_add.9", 16777215
  %".717" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.9"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".717" to i32 addrspace(3)*
  %"lds.9" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.9"
  %".718" = xor i32 %"lds.9", -1
  %".719" = xor i32 %"shf_result.16", -1
  %".720" = xor i32 0, -1
  %".721" = and i32 %"lds.9", %"shf_result.16"
  %".722" = and i32 %".721", %".720"
  %".723" = and i32 %"lds.9", %"shf_result.16"
  %".724" = and i32 %".723", 0
  %".725" = or i32 %".722", %".724"
  %"isetrp_cmp1.34" = icmp ne i32 %".725", %"shf_result.16"
  %"isetrp_src_to_i32.34" = zext i1 1 to i32
  %"isetrp_src_to_i1.34" = icmp ne i32 %"isetrp_src_to_i32.34", 0
  %"isetrp_cmp2.34" = and i1 %"isetrp_cmp1.34", %"isetrp_src_to_i1.34"
  %"P98_to_i32" = zext i1 %"isetrp_cmp2.34" to i32
  br label %"BB_1e60"
BB_1e60:
  %"cond_trunc.30" = trunc i32 %"P98_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_1f50_2790", label %"BB_1e70"
BB_1e70:
  %"activemask.1" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.1" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.1" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.1", i1 0)
  %"flo.1" = sub i32 31, %"flo_clz.1"
  %".728" = xor i32 0, -1
  %".729" = xor i32 %"shf_result.16", -1
  %".730" = xor i32 0, -1
  %".731" = and i32 %".728", %".729"
  %".732" = and i32 %".731", %".730"
  %".733" = and i32 %".728", %".729"
  %".734" = and i32 %".733", 0
  %".735" = or i32 %".732", %".734"
  %".736" = and i32 0, %".729"
  %".737" = and i32 %".736", %".730"
  %".738" = or i32 %".735", %".737"
  %".739" = and i32 0, %".729"
  %".740" = and i32 %".739", 0
  %".741" = or i32 %".738", %".740"
  %"imad_tmp.38" = mul i32 0, 0
  %"imad.41" = add i32 %"imad_tmp.38", %".741"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.41", i32 %"redux_mask.1")
  %".742" = xor i32 %".741", -1
  %".743" = call i32 @"llvm.cttz.i32"(i32 %".742", i1 0)
  %".744" = shl i32 %".743", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".744") convergent
  %"isetrp_cmp1.35" = icmp eq i32 %"laneid.1", %"flo.1"
  %"isetrp_src_to_i32.35" = zext i1 1 to i32
  %"isetrp_src_to_i1.35" = icmp ne i32 %"isetrp_src_to_i32.35", 0
  %"isetrp_cmp2.35" = and i1 %"isetrp_cmp1.35", %"isetrp_src_to_i1.35"
  %"P99_to_i32" = zext i1 %"isetrp_cmp2.35" to i32
  %"imad_tmp.39" = mul i32 0, 0
  %"imad.42" = add i32 %"imad_tmp.39", %"redux_sync_and.1"
  br label %"BB_1f10"
BB_1f10:
  %"cond_trunc.31" = trunc i32 %"P99_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_80001f10", label %"BB_1f90"
BB_80001f10:
  %"atoms_addr_memaddr_offset_add.12" = add i32 %".689", 20
  %"atoms_shared_addr_winoff.12" = and i32 %"atoms_addr_memaddr_offset_add.12", 16777215
  %".748" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.12"
  %"atoms_ptr.12" = bitcast i8 addrspace(3)* %".748" to i32 addrspace(3)*
  %"atoms_and.2" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.12", i32 %"imad.42" monotonic
  %"atoms_addr_memaddr_offset_add.13" = add i32 %".689", 24
  %"atoms_shared_addr_winoff.13" = and i32 %"atoms_addr_memaddr_offset_add.13", 16777215
  %".749" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.13"
  %"atoms_ptr.13" = bitcast i8 addrspace(3)* %".749" to i32 addrspace(3)*
  %"atoms_and.3" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.13", i32 %"imad.42" monotonic
  br label %"BB_1f90"
BB_1f50_2790:
  call void @"llvm.trap"()
  br label %"BB_1f90"
BB_1f80_27c0:
  call void @"llvm.trap"()
  br label %"BB_1f90"
BB_1f90:
  %"s2ur_cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.10" = add i32 %".16", 2064
  %"lds_shared_addr_winoff.10" = and i32 %"lds_addr_memaddr_offset_add.10", 16777215
  %".753" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.10"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".753" to i32 addrspace(3)*
  %"lds.10" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.10"
  %"imad_tmp.40" = mul i32 0, 0
  %"imad.43" = add i32 %"imad_tmp.40", 3
  %".754" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".755" = zext i32 64 to i64
  %".756" = zext i32 24 to i64
  %".757" = shl i64 %".754", %".756"
  %".758" = and i64 %".757", 4294967295
  %".759" = add i64 %".758", %".755"
  %".760" = trunc i64 %".759" to i32
  %"lds_addr_memaddr_offset_add.11" = add i32 %".760", 20
  %"lds_shared_addr_winoff.11" = and i32 %"lds_addr_memaddr_offset_add.11", 16777215
  %".761" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.11"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".761" to i32 addrspace(3)*
  %"lds.11" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.11"
  %".762" = xor i32 %"lds.10", -1
  %".763" = xor i32 65535, -1
  %".764" = xor i32 0, -1
  %".765" = and i32 %"lds.10", 65535
  %".766" = and i32 %".765", %".764"
  %".767" = and i32 %"lds.10", 65535
  %".768" = and i32 %".767", 0
  %".769" = or i32 %".766", %".768"
  %".770" = zext i32 0 to i64
  %".771" = zext i32 %".769" to i64
  %".772" = shl i64 %".771", 32
  %"shf_concat.17" = or i64 %".770", %".772"
  %"shf_shift_64.17" = zext i32 5 to i64
  %".773" = lshr i64 %"shf_concat.17", %"shf_shift_64.17"
  %"shf_hi.4" = lshr i64 %".773", 32
  %"shf_result.17" = trunc i64 %"shf_hi.4" to i32
  %".774" = zext i32 %"imad.43" to i64
  %".775" = zext i32 0 to i64
  %".776" = shl i64 %".775", 32
  %"shf_concat.18" = or i64 %".774", %".776"
  %"shf_shift_64.18" = zext i32 %"shf_result.17" to i64
  %".777" = shl i64 %"shf_concat.18", %"shf_shift_64.18"
  %"shf_result.18" = trunc i64 %".777" to i32
  %".778" = xor i32 %"lds.11", -1
  %".779" = xor i32 %"shf_result.18", -1
  %".780" = xor i32 0, -1
  %".781" = and i32 %"lds.11", %"shf_result.18"
  %".782" = and i32 %".781", %".780"
  %".783" = and i32 %"lds.11", %"shf_result.18"
  %".784" = and i32 %".783", 0
  %".785" = or i32 %".782", %".784"
  %"isetrp_cmp1.36" = icmp ne i32 %".785", %"shf_result.18"
  %"isetrp_src_to_i32.36" = zext i1 1 to i32
  %"isetrp_src_to_i1.36" = icmp ne i32 %"isetrp_src_to_i32.36", 0
  %"isetrp_cmp2.36" = and i1 %"isetrp_cmp1.36", %"isetrp_src_to_i1.36"
  %"P100_to_i32" = zext i1 %"isetrp_cmp2.36" to i32
  %"imad_tmp.41" = mul i32 0, 0
  %"imad.44" = add i32 %"imad_tmp.41", 1
  %".786" = zext i32 %"imad.44" to i64
  %".787" = zext i32 0 to i64
  %".788" = shl i64 %".787", 32
  %"shf_concat.19" = or i64 %".786", %".788"
  %"shf_shift_64.19" = zext i32 %"shf_result.17" to i64
  %".789" = shl i64 %"shf_concat.19", %"shf_shift_64.19"
  %"shf_result.19" = trunc i64 %".789" to i32
  br label %"BB_2080"
BB_2080:
  %"cond_trunc.32" = trunc i32 %"P100_to_i32" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_2210_27c0", label %"BB_2090"
BB_2090:
  %"lds_addr_memaddr_offset_add.12" = add i32 %".760", 24
  %"lds_shared_addr_winoff.12" = and i32 %"lds_addr_memaddr_offset_add.12", 16777215
  %".792" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.12"
  %"lds_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".792" to i32 addrspace(3)*
  %"lds.12" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.12"
  %".793" = xor i32 %"lds.12", -1
  %".794" = xor i32 %"shf_result.19", -1
  %".795" = xor i32 0, -1
  %".796" = and i32 %"lds.12", %"shf_result.19"
  %".797" = and i32 %".796", %".795"
  %".798" = and i32 %"lds.12", %"shf_result.19"
  %".799" = and i32 %".798", 0
  %".800" = or i32 %".797", %".799"
  %"isetrp_cmp1.37" = icmp ne i32 %".800", %"shf_result.19"
  %"isetrp_src_to_i32.37" = zext i1 1 to i32
  %"isetrp_src_to_i1.37" = icmp ne i32 %"isetrp_src_to_i32.37", 0
  %"isetrp_cmp2.37" = and i1 %"isetrp_cmp1.37", %"isetrp_src_to_i1.37"
  %"P102_to_i32" = zext i1 %"isetrp_cmp2.37" to i32
  br label %"BB_20c0"
BB_20c0:
  %"cond_trunc.33" = trunc i32 %"P102_to_i32" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_21e0_2790", label %"BB_20d0"
BB_20d0:
  %"activemask.2" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.2" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".803" = xor i32 0, -1
  %".804" = xor i32 %"shf_result.19", -1
  %".805" = xor i32 0, -1
  %".806" = and i32 %".803", %".804"
  %".807" = and i32 %".806", %".805"
  %".808" = and i32 %".803", %".804"
  %".809" = and i32 %".808", 0
  %".810" = or i32 %".807", %".809"
  %".811" = and i32 0, %".804"
  %".812" = and i32 %".811", %".805"
  %".813" = or i32 %".810", %".812"
  %".814" = and i32 0, %".804"
  %".815" = and i32 %".814", 0
  %".816" = or i32 %".813", %".815"
  %"flo_clz.2" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.2", i1 0)
  %"flo.2" = sub i32 31, %"flo_clz.2"
  %"redux_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.2" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".816", i32 %"redux_mask.2")
  %".817" = xor i32 0, -1
  %".818" = xor i32 %"shf_result.18", -1
  %".819" = xor i32 0, -1
  %".820" = and i32 %".817", %".818"
  %".821" = and i32 %".820", %".819"
  %".822" = and i32 %".817", %".818"
  %".823" = and i32 %".822", 0
  %".824" = or i32 %".821", %".823"
  %".825" = and i32 0, %".818"
  %".826" = and i32 %".825", %".819"
  %".827" = or i32 %".824", %".826"
  %".828" = and i32 0, %".818"
  %".829" = and i32 %".828", 0
  %".830" = or i32 %".827", %".829"
  %"imad_tmp.42" = mul i32 0, 0
  %"imad.45" = add i32 %"imad_tmp.42", %".830"
  %"redux_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.3" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.45", i32 %"redux_mask.3")
  %".831" = xor i32 %".830", -1
  %".832" = call i32 @"llvm.cttz.i32"(i32 %".831", i1 0)
  %".833" = shl i32 %".832", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".833") convergent
  %"imad_tmp.43" = mul i32 0, 0
  %"imad.46" = add i32 %"imad_tmp.43", %"redux_sync_and.2"
  %"isetrp_cmp1.38" = icmp eq i32 %"laneid.2", %"flo.2"
  %"isetrp_src_to_i32.38" = zext i1 1 to i32
  %"isetrp_src_to_i1.38" = icmp ne i32 %"isetrp_src_to_i32.38", 0
  %"isetrp_cmp2.38" = and i1 %"isetrp_cmp1.38", %"isetrp_src_to_i1.38"
  %"P104_to_i32" = zext i1 %"isetrp_cmp2.38" to i32
  %"imad_tmp.44" = mul i32 0, 0
  %"imad.47" = add i32 %"imad_tmp.44", %"redux_sync_and.3"
  br label %"BB_21a0"
BB_21a0:
  %"cond_trunc.34" = trunc i32 %"P104_to_i32" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_800021a0", label %"BB_2220"
BB_800021a0:
  %"atoms_addr_memaddr_offset_add.14" = add i32 %".760", 20
  %"atoms_shared_addr_winoff.14" = and i32 %"atoms_addr_memaddr_offset_add.14", 16777215
  %".837" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.14"
  %"atoms_ptr.14" = bitcast i8 addrspace(3)* %".837" to i32 addrspace(3)*
  %"atoms_and.4" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.14", i32 %"imad.47" monotonic
  %"atoms_addr_memaddr_offset_add.15" = add i32 %".760", 24
  %"atoms_shared_addr_winoff.15" = and i32 %"atoms_addr_memaddr_offset_add.15", 16777215
  %".838" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.15"
  %"atoms_ptr.15" = bitcast i8 addrspace(3)* %".838" to i32 addrspace(3)*
  %"atoms_and.5" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.15", i32 %"imad.46" monotonic
  br label %"BB_2220"
BB_21e0_2790:
  call void @"llvm.trap"()
  br label %"BB_2220"
BB_2210_27c0:
  call void @"llvm.trap"()
  br label %"BB_2220"
BB_2220:
  %"s2ur_cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.13" = add i32 %".16", 2068
  %"lds_shared_addr_winoff.13" = and i32 %"lds_addr_memaddr_offset_add.13", 16777215
  %".842" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.13"
  %"lds_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".842" to i32 addrspace(3)*
  %"lds.13" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.13"
  %"imad_tmp.45" = mul i32 0, 0
  %"imad.48" = add i32 %"imad_tmp.45", 15
  %".843" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".844" = zext i32 64 to i64
  %".845" = zext i32 24 to i64
  %".846" = shl i64 %".843", %".845"
  %".847" = and i64 %".846", 4294967295
  %".848" = add i64 %".847", %".844"
  %".849" = trunc i64 %".848" to i32
  %"lds_addr_memaddr_offset_add.14" = add i32 %".849", 20
  %"lds_shared_addr_winoff.14" = and i32 %"lds_addr_memaddr_offset_add.14", 16777215
  %".850" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.14"
  %"lds_shared_addr_cast.14" = bitcast i8 addrspace(3)* %".850" to i32 addrspace(3)*
  %"lds.14" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.14"
  %".851" = xor i32 %"lds.13", -1
  %".852" = xor i32 65535, -1
  %".853" = xor i32 0, -1
  %".854" = and i32 %"lds.13", 65535
  %".855" = and i32 %".854", %".853"
  %".856" = and i32 %"lds.13", 65535
  %".857" = and i32 %".856", 0
  %".858" = or i32 %".855", %".857"
  %".859" = zext i32 0 to i64
  %".860" = zext i32 %".858" to i64
  %".861" = shl i64 %".860", 32
  %"shf_concat.20" = or i64 %".859", %".861"
  %"shf_shift_64.20" = zext i32 5 to i64
  %".862" = lshr i64 %"shf_concat.20", %"shf_shift_64.20"
  %"shf_hi.5" = lshr i64 %".862", 32
  %"shf_result.20" = trunc i64 %"shf_hi.5" to i32
  %".863" = zext i32 %"imad.48" to i64
  %".864" = zext i32 0 to i64
  %".865" = shl i64 %".864", 32
  %"shf_concat.21" = or i64 %".863", %".865"
  %"shf_shift_64.21" = zext i32 %"shf_result.20" to i64
  %".866" = shl i64 %"shf_concat.21", %"shf_shift_64.21"
  %"shf_result.21" = trunc i64 %".866" to i32
  %".867" = xor i32 %"lds.14", -1
  %".868" = xor i32 %"shf_result.21", -1
  %".869" = xor i32 0, -1
  %".870" = and i32 %"lds.14", %"shf_result.21"
  %".871" = and i32 %".870", %".869"
  %".872" = and i32 %"lds.14", %"shf_result.21"
  %".873" = and i32 %".872", 0
  %".874" = or i32 %".871", %".873"
  %"isetrp_cmp1.39" = icmp ne i32 %".874", %"shf_result.21"
  %"isetrp_src_to_i32.39" = zext i1 1 to i32
  %"isetrp_src_to_i1.39" = icmp ne i32 %"isetrp_src_to_i32.39", 0
  %"isetrp_cmp2.39" = and i1 %"isetrp_cmp1.39", %"isetrp_src_to_i1.39"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.39" to i32
  %"imad_tmp.46" = mul i32 0, 0
  %"imad.49" = add i32 %"imad_tmp.46", 1
  %".875" = zext i32 %"imad.49" to i64
  %".876" = zext i32 0 to i64
  %".877" = shl i64 %".876", 32
  %"shf_concat.22" = or i64 %".875", %".877"
  %"shf_shift_64.22" = zext i32 %"shf_result.20" to i64
  %".878" = shl i64 %"shf_concat.22", %"shf_shift_64.22"
  %"shf_result.22" = trunc i64 %".878" to i32
  br label %"BB_2310"
BB_2310:
  %"cond_trunc.35" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_24a0_27c0", label %"BB_2320"
BB_2320:
  %"lds_addr_memaddr_offset_add.15" = add i32 %".849", 24
  %"lds_shared_addr_winoff.15" = and i32 %"lds_addr_memaddr_offset_add.15", 16777215
  %".881" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.15"
  %"lds_shared_addr_cast.15" = bitcast i8 addrspace(3)* %".881" to i32 addrspace(3)*
  %"lds.15" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.15"
  %".882" = xor i32 %"lds.15", -1
  %".883" = xor i32 %"shf_result.22", -1
  %".884" = xor i32 0, -1
  %".885" = and i32 %"lds.15", %"shf_result.22"
  %".886" = and i32 %".885", %".884"
  %".887" = and i32 %"lds.15", %"shf_result.22"
  %".888" = and i32 %".887", 0
  %".889" = or i32 %".886", %".888"
  %"isetrp_cmp1.40" = icmp ne i32 %".889", %"shf_result.22"
  %"isetrp_src_to_i32.40" = zext i1 1 to i32
  %"isetrp_src_to_i1.40" = icmp ne i32 %"isetrp_src_to_i32.40", 0
  %"isetrp_cmp2.40" = and i1 %"isetrp_cmp1.40", %"isetrp_src_to_i1.40"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.40" to i32
  br label %"BB_2350"
BB_2350:
  %"cond_trunc.36" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_2470_2790", label %"BB_2360"
BB_2360:
  %"activemask.3" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.3" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".892" = xor i32 0, -1
  %".893" = xor i32 %"shf_result.22", -1
  %".894" = xor i32 0, -1
  %".895" = and i32 %".892", %".893"
  %".896" = and i32 %".895", %".894"
  %".897" = and i32 %".892", %".893"
  %".898" = and i32 %".897", 0
  %".899" = or i32 %".896", %".898"
  %".900" = and i32 0, %".893"
  %".901" = and i32 %".900", %".894"
  %".902" = or i32 %".899", %".901"
  %".903" = and i32 0, %".893"
  %".904" = and i32 %".903", 0
  %".905" = or i32 %".902", %".904"
  %"flo_clz.3" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.3", i1 0)
  %"flo.3" = sub i32 31, %"flo_clz.3"
  %"redux_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.4" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".905", i32 %"redux_mask.4")
  %".906" = xor i32 0, -1
  %".907" = xor i32 %"shf_result.21", -1
  %".908" = xor i32 0, -1
  %".909" = and i32 %".906", %".907"
  %".910" = and i32 %".909", %".908"
  %".911" = and i32 %".906", %".907"
  %".912" = and i32 %".911", 0
  %".913" = or i32 %".910", %".912"
  %".914" = and i32 0, %".907"
  %".915" = and i32 %".914", %".908"
  %".916" = or i32 %".913", %".915"
  %".917" = and i32 0, %".907"
  %".918" = and i32 %".917", 0
  %".919" = or i32 %".916", %".918"
  %"imad_tmp.47" = mul i32 0, 0
  %"imad.50" = add i32 %"imad_tmp.47", %".919"
  %"redux_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.5" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.50", i32 %"redux_mask.5")
  %".920" = xor i32 %".919", -1
  %".921" = call i32 @"llvm.cttz.i32"(i32 %".920", i1 0)
  %".922" = shl i32 %".921", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".922") convergent
  %"imad_tmp.48" = mul i32 0, 0
  %"imad.51" = add i32 %"imad_tmp.48", %"redux_sync_and.4"
  %"isetrp_cmp1.41" = icmp eq i32 %"laneid.3", %"flo.3"
  %"isetrp_src_to_i32.41" = zext i1 1 to i32
  %"isetrp_src_to_i1.41" = icmp ne i32 %"isetrp_src_to_i32.41", 0
  %"isetrp_cmp2.41" = and i1 %"isetrp_cmp1.41", %"isetrp_src_to_i1.41"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.41" to i32
  %"imad_tmp.49" = mul i32 0, 0
  %"imad.52" = add i32 %"imad_tmp.49", %"redux_sync_and.5"
  br label %"BB_2430"
BB_2430:
  %"cond_trunc.37" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_80002430", label %"BB_24b0"
BB_80002430:
  %"atoms_addr_memaddr_offset_add.16" = add i32 %".849", 20
  %"atoms_shared_addr_winoff.16" = and i32 %"atoms_addr_memaddr_offset_add.16", 16777215
  %".926" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.16"
  %"atoms_ptr.16" = bitcast i8 addrspace(3)* %".926" to i32 addrspace(3)*
  %"atoms_and.6" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.16", i32 %"imad.52" monotonic
  %"atoms_addr_memaddr_offset_add.17" = add i32 %".849", 24
  %"atoms_shared_addr_winoff.17" = and i32 %"atoms_addr_memaddr_offset_add.17", 16777215
  %".927" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.17"
  %"atoms_ptr.17" = bitcast i8 addrspace(3)* %".927" to i32 addrspace(3)*
  %"atoms_and.7" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.17", i32 %"imad.51" monotonic
  br label %"BB_24b0"
BB_2470_2790:
  call void @"llvm.trap"()
  br label %"BB_24b0"
BB_24a0_27c0:
  call void @"llvm.trap"()
  br label %"BB_24b0"
BB_24b0:
  %"s2ur_cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.16" = add i32 %".16", 2072
  %"lds_shared_addr_winoff.16" = and i32 %"lds_addr_memaddr_offset_add.16", 16777215
  %".931" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.16"
  %"lds_shared_addr_cast.16" = bitcast i8 addrspace(3)* %".931" to i32 addrspace(3)*
  %"lds.16" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.16"
  %"imad_tmp.50" = mul i32 0, 0
  %"imad.53" = add i32 %"imad_tmp.50", 255
  %".932" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".933" = zext i32 64 to i64
  %".934" = zext i32 24 to i64
  %".935" = shl i64 %".932", %".934"
  %".936" = and i64 %".935", 4294967295
  %".937" = add i64 %".936", %".933"
  %".938" = trunc i64 %".937" to i32
  %"lds_addr_memaddr_offset_add.17" = add i32 %".938", 20
  %"lds_shared_addr_winoff.17" = and i32 %"lds_addr_memaddr_offset_add.17", 16777215
  %".939" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.17"
  %"lds_shared_addr_cast.17" = bitcast i8 addrspace(3)* %".939" to i32 addrspace(3)*
  %"lds.17" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.17"
  %".940" = xor i32 %"lds.16", -1
  %".941" = xor i32 65535, -1
  %".942" = xor i32 0, -1
  %".943" = and i32 %"lds.16", 65535
  %".944" = and i32 %".943", %".942"
  %".945" = and i32 %"lds.16", 65535
  %".946" = and i32 %".945", 0
  %".947" = or i32 %".944", %".946"
  %".948" = zext i32 0 to i64
  %".949" = zext i32 %".947" to i64
  %".950" = shl i64 %".949", 32
  %"shf_concat.23" = or i64 %".948", %".950"
  %"shf_shift_64.23" = zext i32 5 to i64
  %".951" = lshr i64 %"shf_concat.23", %"shf_shift_64.23"
  %"shf_hi.6" = lshr i64 %".951", 32
  %"shf_result.23" = trunc i64 %"shf_hi.6" to i32
  %".952" = zext i32 %"imad.53" to i64
  %".953" = zext i32 0 to i64
  %".954" = shl i64 %".953", 32
  %"shf_concat.24" = or i64 %".952", %".954"
  %"shf_shift_64.24" = zext i32 %"shf_result.23" to i64
  %".955" = shl i64 %"shf_concat.24", %"shf_shift_64.24"
  %"shf_result.24" = trunc i64 %".955" to i32
  %".956" = xor i32 %"lds.17", -1
  %".957" = xor i32 %"shf_result.24", -1
  %".958" = xor i32 0, -1
  %".959" = and i32 %"lds.17", %"shf_result.24"
  %".960" = and i32 %".959", %".958"
  %".961" = and i32 %"lds.17", %"shf_result.24"
  %".962" = and i32 %".961", 0
  %".963" = or i32 %".960", %".962"
  %"isetrp_cmp1.42" = icmp ne i32 %".963", %"shf_result.24"
  %"isetrp_src_to_i32.42" = zext i1 1 to i32
  %"isetrp_src_to_i1.42" = icmp ne i32 %"isetrp_src_to_i32.42", 0
  %"isetrp_cmp2.42" = and i1 %"isetrp_cmp1.42", %"isetrp_src_to_i1.42"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.42" to i32
  %"imad_tmp.51" = mul i32 0, 0
  %"imad.54" = add i32 %"imad_tmp.51", 1
  %".964" = zext i32 %"imad.54" to i64
  %".965" = zext i32 0 to i64
  %".966" = shl i64 %".965", 32
  %"shf_concat.25" = or i64 %".964", %".966"
  %"shf_shift_64.25" = zext i32 %"shf_result.23" to i64
  %".967" = shl i64 %"shf_concat.25", %"shf_shift_64.25"
  %"shf_result.25" = trunc i64 %".967" to i32
  br label %"BB_25a0"
BB_25a0:
  %"cond_trunc.38" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_2730_27c0", label %"BB_25b0"
BB_25b0:
  %"lds_addr_memaddr_offset_add.18" = add i32 %".938", 24
  %"lds_shared_addr_winoff.18" = and i32 %"lds_addr_memaddr_offset_add.18", 16777215
  %".970" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.18"
  %"lds_shared_addr_cast.18" = bitcast i8 addrspace(3)* %".970" to i32 addrspace(3)*
  %"lds.18" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.18"
  %".971" = xor i32 %"lds.18", -1
  %".972" = xor i32 %"shf_result.25", -1
  %".973" = xor i32 0, -1
  %".974" = and i32 %"lds.18", %"shf_result.25"
  %".975" = and i32 %".974", %".973"
  %".976" = and i32 %"lds.18", %"shf_result.25"
  %".977" = and i32 %".976", 0
  %".978" = or i32 %".975", %".977"
  %"isetrp_cmp1.43" = icmp ne i32 %".978", %"shf_result.25"
  %"isetrp_src_to_i32.43" = zext i1 1 to i32
  %"isetrp_src_to_i1.43" = icmp ne i32 %"isetrp_src_to_i32.43", 0
  %"isetrp_cmp2.43" = and i1 %"isetrp_cmp1.43", %"isetrp_src_to_i1.43"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.43" to i32
  br label %"BB_25e0"
BB_25e0:
  %"cond_trunc.39" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_trunc.39" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_2700_2790", label %"BB_25f0"
BB_25f0:
  %"activemask.4" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.4" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".981" = xor i32 0, -1
  %".982" = xor i32 %"shf_result.25", -1
  %".983" = xor i32 0, -1
  %".984" = and i32 %".981", %".982"
  %".985" = and i32 %".984", %".983"
  %".986" = and i32 %".981", %".982"
  %".987" = and i32 %".986", 0
  %".988" = or i32 %".985", %".987"
  %".989" = and i32 0, %".982"
  %".990" = and i32 %".989", %".983"
  %".991" = or i32 %".988", %".990"
  %".992" = and i32 0, %".982"
  %".993" = and i32 %".992", 0
  %".994" = or i32 %".991", %".993"
  %"flo_clz.4" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.4", i1 0)
  %"flo.4" = sub i32 31, %"flo_clz.4"
  %"redux_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.6" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".994", i32 %"redux_mask.6")
  %".995" = xor i32 0, -1
  %".996" = xor i32 %"shf_result.24", -1
  %".997" = xor i32 0, -1
  %".998" = and i32 %".995", %".996"
  %".999" = and i32 %".998", %".997"
  %".1000" = and i32 %".995", %".996"
  %".1001" = and i32 %".1000", 0
  %".1002" = or i32 %".999", %".1001"
  %".1003" = and i32 0, %".996"
  %".1004" = and i32 %".1003", %".997"
  %".1005" = or i32 %".1002", %".1004"
  %".1006" = and i32 0, %".996"
  %".1007" = and i32 %".1006", 0
  %".1008" = or i32 %".1005", %".1007"
  %"imad_tmp.52" = mul i32 0, 0
  %"imad.55" = add i32 %"imad_tmp.52", %".1008"
  %"redux_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.7" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.55", i32 %"redux_mask.7")
  %".1009" = xor i32 %".1008", -1
  %".1010" = call i32 @"llvm.cttz.i32"(i32 %".1009", i1 0)
  %".1011" = shl i32 %".1010", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 256;", "r,~{memory}"(i32 %".1011") convergent
  %"imad_tmp.53" = mul i32 0, 0
  %"imad.56" = add i32 %"imad_tmp.53", %"redux_sync_and.6"
  %"isetrp_cmp1.44" = icmp eq i32 %"laneid.4", %"flo.4"
  %"isetrp_src_to_i32.44" = zext i1 1 to i32
  %"isetrp_src_to_i1.44" = icmp ne i32 %"isetrp_src_to_i32.44", 0
  %"isetrp_cmp2.44" = and i1 %"isetrp_cmp1.44", %"isetrp_src_to_i1.44"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.44" to i32
  %"imad_tmp.54" = mul i32 0, 0
  %"imad.57" = add i32 %"imad_tmp.54", %"redux_sync_and.7"
  br label %"BB_26c0"
BB_26c0:
  %"cond_trunc.40" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_trunc.40" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_800026c0", label %"BB_2740"
BB_800026c0:
  %"atoms_addr_memaddr_offset_add.18" = add i32 %".938", 20
  %"atoms_shared_addr_winoff.18" = and i32 %"atoms_addr_memaddr_offset_add.18", 16777215
  %".1015" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.18"
  %"atoms_ptr.18" = bitcast i8 addrspace(3)* %".1015" to i32 addrspace(3)*
  %"atoms_and.8" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.18", i32 %"imad.57" monotonic
  %"atoms_addr_memaddr_offset_add.19" = add i32 %".938", 24
  %"atoms_shared_addr_winoff.19" = and i32 %"atoms_addr_memaddr_offset_add.19", 16777215
  %".1016" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.19"
  %"atoms_ptr.19" = bitcast i8 addrspace(3)* %".1016" to i32 addrspace(3)*
  %"atoms_and.9" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.19", i32 %"imad.56" monotonic
  br label %"BB_2740"
BB_2700_2790:
  call void @"llvm.trap"()
  br label %"BB_2740"
BB_2730_27c0:
  call void @"llvm.trap"()
  br label %"BB_2740"
BB_2740:
  ret void
BB_80001b20:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
