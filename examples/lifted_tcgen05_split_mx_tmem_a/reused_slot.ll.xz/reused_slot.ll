; ModuleID = "split_mx_reused_slot_sm100a_cuda13"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [3104 x i8], align 16
define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P38_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0080"
BB_0080:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_02a0", label %"BB_0090"
BB_0090:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"UR11:UR10_r0" = trunc i64 %"ldc_const" to i32
  %"UR11:UR10_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR11:UR10_r1" = trunc i64 %"UR11:UR10_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".21" = xor i32 %"imad", -1
  %".22" = xor i32 508, -1
  %".23" = xor i32 0, -1
  %".24" = and i32 %"imad", 508
  %".25" = and i32 %".24", %".23"
  %".26" = and i32 %"imad", 508
  %".27" = and i32 %".26", 0
  %".28" = or i32 %".25", %".27"
  %"iadd3_o1_64" = zext i32 %".28" to i64
  %"iadd3_o2_64" = zext i32 %"UR11:UR10_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P57_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR11:UR10_r1"
  %"imad_cin_trunc" = trunc i32 %"P57_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R17:R411_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R17:R411_addr_ptr"
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".29" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".30" = zext i32 %"iadd3_n2" to i64
  %".31" = zext i32 24 to i64
  %".32" = shl i64 %".29", %".31"
  %".33" = and i64 %".32", 4294967295
  %".34" = add i64 %".33", %".30"
  %".35" = trunc i64 %".34" to i32
  %"viadd" = add i32 %"imad", %".35"
  br label %"BB_0140"
BB_0140:
  %"phi" = phi  i32 [%"tid_x", %"BB_0090"], [%"viadd.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"viadd", %"BB_0090"], [%"viadd.2", %"BB_0180"]
  %"isetrp_cmp1.1" = icmp uge i32 %"phi", 128
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P97_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".37" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".37" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P97_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0140", label %"BB_0190"
BB_0190:
  %".41" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".42" = bitcast i8* %".41" to i64*
  %"ldc_const.1" = load i64, i64* %".42"
  %"R5:R4_r0" = trunc i64 %"ldc_const.1" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"viadd.3" = add i32 %"imad", %".16"
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad.2" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P109_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R5:R4_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P109_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0210"
BB_0210:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_0190"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.3" = phi  i32 [%"iadd3_trunc.1", %"BB_0190"], [%"iadd3_trunc.2", %"BB_0290"]
  %"phi.4" = phi  i32 [%"tid_x", %"BB_0190"], [%"viadd.4", %"BB_0290"]
  %"phi.5" = phi  i32 [%"viadd.3", %"BB_0190"], [%"viadd.5", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R60:R14_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R60:R14_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.4", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P17_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.4" = add i32 %"phi.4", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P36_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P36_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.5", 16777215
  %".44" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".44" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.5", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P17_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"isetrp_cmp1.3" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"vote_pred_trunc" = trunc i32 %"P35_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P52_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02f0"
BB_02f0:
  %"cond_trunc.3" = trunc i32 %"P52_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002f0", label %"BB_0340"
BB_800002f0:
  %"iadd3_n1.1" = add i32 1024, 2048
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".50" = zext i32 %"iadd3_n2.2" to i64
  %".51" = zext i32 0 to i64
  %".52" = shl i64 %".51", 32
  %"shf_concat" = or i64 %".50", %".52"
  %"shf_shift_64" = zext i32 11 to i64
  %".53" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".53" to i32
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat.1" = or i64 %".54", %".56"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".57" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".57" to i32
  %".58" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".59" = zext i32 %"iadd3_n2.1" to i64
  %".60" = zext i32 24 to i64
  %".61" = shl i64 %".58", %".60"
  %".62" = and i64 %".61", 4294967295
  %".63" = add i64 %".62", %".59"
  %".64" = trunc i64 %".63" to i32
  br label %"BB_0340"
BB_0340:
  %"phi.6" = phi  i32 [%".64", %"BB_800002f0"], [0, %"BB_02f0"]
  %"phi.7" = phi  i32 [%"shf_result", %"BB_800002f0"], [1024, %"BB_02f0"]
  %"phi.8" = phi  i32 [%"shf_result.1", %"BB_800002f0"], [1, %"BB_02f0"]
  %"vote_pred_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P61_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P79_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P61_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.6", 16777215
  %".69" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".69" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.7" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".70" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".70" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P79_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_08b0", label %"BB_0390"
BB_0390:
  %"allocation_slot_winoff" = and i32 3080, 16777215
  %".74" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".75" = ptrtoint i8 addrspace(3)* %".74" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".75", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P92_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P92_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_04f0", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 1
  %".79" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".80" = zext i32 64 to i64
  %".81" = zext i32 24 to i64
  %".82" = shl i64 %".79", %".81"
  %".83" = and i64 %".82", 4294967295
  %".84" = add i64 %".83", %".80"
  %".85" = trunc i64 %".84" to i32
  %"tmem_alloc_winoff" = and i32 3080, 16777215
  %".86" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".87" = bitcast i8 addrspace(3)* %".86" to i32 addrspace(3)*
  %".88" = load i32, i32 addrspace(3)* %".87"
  %".89" = lshr i32 %".88", 5
  %"P68_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".89"
  %"bra_cond_trunc" = trunc i32 %"P68_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_winoff.1" = and i32 3080, 16777215
  %".91" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".92" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  %".93" = load i32, i32 addrspace(3)* %".92"
  %".94" = lshr i32 %".93", 5
  %"P71_to_i32" = zext i1 1 to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".94"
  %"bra_cond_trunc.1" = trunc i32 %"P71_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.9" = phi  i32 [%"imad.6", %"BB_03c0"], [%"imad.7", %"BB_0440"]
  %".96" = zext i32 %"imad.5" to i64
  %".97" = zext i32 0 to i64
  %".98" = shl i64 %".97", 32
  %"shf_concat.2" = or i64 %".96", %".98"
  %"shf_shift_64.2" = zext i32 %"phi.9" to i64
  %".99" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".99" to i32
  %"imad_tmp.7" = mul i32 %"phi.9", 32
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".85", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".100" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".100" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".85", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".101" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".102" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".102" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_04f0"
BB_04f0:
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".105" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", 1
  %".106" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".107" = zext i32 64 to i64
  %".108" = zext i32 24 to i64
  %".109" = shl i64 %".106", %".108"
  %".110" = and i64 %".109", 4294967295
  %".111" = add i64 %".110", %".107"
  %".112" = trunc i64 %".111" to i32
  %"lds_addr_memaddr_offset_add.1" = add i32 %".112", 20
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".113" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".113" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".114" = xor i32 %"lds", -1
  %".115" = xor i32 65535, -1
  %".116" = xor i32 0, -1
  %".117" = and i32 %"lds", 65535
  %".118" = and i32 %".117", %".116"
  %".119" = and i32 %"lds", 65535
  %".120" = and i32 %".119", 0
  %".121" = or i32 %".118", %".120"
  %".122" = zext i32 0 to i64
  %".123" = zext i32 %".121" to i64
  %".124" = shl i64 %".123", 32
  %"shf_concat.3" = or i64 %".122", %".124"
  %"shf_shift_64.3" = zext i32 5 to i64
  %".125" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".125", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".126" = zext i32 %"imad.9" to i64
  %".127" = zext i32 0 to i64
  %".128" = shl i64 %".127", 32
  %"shf_concat.4" = or i64 %".126", %".128"
  %"shf_shift_64.4" = zext i32 %"shf_result.3" to i64
  %".129" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".129" to i32
  %".130" = xor i32 %"lds.1", -1
  %".131" = xor i32 %"shf_result.4", -1
  %".132" = xor i32 0, -1
  %".133" = and i32 %"lds.1", %"shf_result.4"
  %".134" = and i32 %".133", %".132"
  %".135" = and i32 %"lds.1", %"shf_result.4"
  %".136" = and i32 %".135", 0
  %".137" = or i32 %".134", %".136"
  %"isetrp_cmp1.5" = icmp ne i32 %".137", %"shf_result.4"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P103_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_05b0"
BB_05b0:
  %"cond_trunc.7" = trunc i32 %"P103_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0710_2c00", label %"BB_05c0"
BB_05c0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".112", 24
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".140" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".140" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %".141" = xor i32 %"lds.2", -1
  %".142" = xor i32 %"shf_result.4", -1
  %".143" = xor i32 0, -1
  %".144" = and i32 %"lds.2", %"shf_result.4"
  %".145" = and i32 %".144", %".143"
  %".146" = and i32 %"lds.2", %"shf_result.4"
  %".147" = and i32 %".146", 0
  %".148" = or i32 %".145", %".147"
  %"isetrp_cmp1.6" = icmp ne i32 %".148", %"shf_result.4"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_05f0"
BB_05f0:
  %"cond_trunc.8" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_06e0_2bd0", label %"BB_0600"
BB_0600:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".151" = xor i32 0, -1
  %".152" = xor i32 %"shf_result.4", -1
  %".153" = xor i32 0, -1
  %".154" = and i32 %".151", %".152"
  %".155" = and i32 %".154", %".153"
  %".156" = and i32 %".151", %".152"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 0, %".152"
  %".160" = and i32 %".159", %".153"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 0, %".152"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.9", %".164"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.10", i32 %"redux_mask")
  %".165" = xor i32 %".164", -1
  %".166" = call i32 @"llvm.cttz.i32"(i32 %".165", i1 0)
  %".167" = shl i32 %".166", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".167") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.10", %"redux_sync_and"
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.9" = trunc i32 %"P56_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800006a0", label %"BB_0720"
BB_800006a0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".112", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".171" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".171" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.11" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".112", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".172" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".172" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.11" monotonic
  br label %"BB_0720"
BB_06e0_2bd0:
  call void @"llvm.trap"()
  br label %"BB_0720"
BB_0710_2c00:
  call void @"llvm.trap"()
  br label %"BB_0720"
BB_0720:
  %"allocation_slot_winoff.1" = and i32 3080, 16777215
  %".176" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.1"
  %".177" = ptrtoint i8 addrspace(3)* %".176" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".177", i32 32) convergent
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P28_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0750"
BB_0750:
  %"cond_trunc.10" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_08b0", label %"BB_0760"
BB_0760:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.11", 1
  %".181" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".182" = zext i32 64 to i64
  %".183" = zext i32 24 to i64
  %".184" = shl i64 %".181", %".183"
  %".185" = and i64 %".184", 4294967295
  %".186" = add i64 %".185", %".182"
  %".187" = trunc i64 %".186" to i32
  %"tmem_alloc_winoff.2" = and i32 3080, 16777215
  %".188" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.2"
  %".189" = bitcast i8 addrspace(3)* %".188" to i32 addrspace(3)*
  %".190" = load i32, i32 addrspace(3)* %".189"
  %".191" = lshr i32 %".190", 5
  %"P73_to_i32" = zext i1 1 to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", %".191"
  %"bra_cond_trunc.2" = trunc i32 %"P73_to_i32" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  br i1 %"bra_cond_to_i1.2", label %"BB_0850", label %"BB_07f0"
BB_07f0:
  %"tmem_alloc_winoff.3" = and i32 3080, 16777215
  %".193" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.3"
  %".194" = bitcast i8 addrspace(3)* %".193" to i32 addrspace(3)*
  %".195" = load i32, i32 addrspace(3)* %".194"
  %".196" = lshr i32 %".195", 5
  %"P54_to_i32" = zext i1 1 to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", %".196"
  %"bra_cond_trunc.3" = trunc i32 %"P54_to_i32" to i1
  %"bra_cond_not.1" = xor i1 %"bra_cond_trunc.3", -1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_not.1" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  br i1 %"bra_cond_to_i1.3", label %"BB_07f0", label %"BB_0850"
BB_0850:
  %"phi.10" = phi  i32 [%"imad.13", %"BB_0760"], [%"imad.14", %"BB_07f0"]
  %".198" = zext i32 %"imad.12" to i64
  %".199" = zext i32 0 to i64
  %".200" = shl i64 %".199", 32
  %"shf_concat.5" = or i64 %".198", %".200"
  %"shf_shift_64.5" = zext i32 %"phi.10" to i64
  %".201" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".201" to i32
  %"imad_tmp.14" = mul i32 %"phi.10", 32
  %"imad.15" = add i32 %"imad_tmp.14", 0
  %"atoms_addr_memaddr_offset_add.4" = add i32 %".187", 20
  %"atoms_shared_addr_winoff.4" = and i32 %"atoms_addr_memaddr_offset_add.4", 16777215
  %".202" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.4"
  %"atoms_ptr.4" = bitcast i8 addrspace(3)* %".202" to i32 addrspace(3)*
  %"atoms_or.2" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.4", i32 %"shf_result.5" monotonic
  %"atoms_addr_memaddr_offset_add.5" = add i32 %".187", 24
  %"atoms_shared_addr_winoff.5" = and i32 %"atoms_addr_memaddr_offset_add.5", 16777215
  %".203" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.5"
  %"atoms_ptr.5" = bitcast i8 addrspace(3)* %".203" to i32 addrspace(3)*
  %"atoms_or.3" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.5", i32 %"shf_result.5" monotonic
  %"sts_addr_memaddr_offset_add.1" = add i32 %".16", 2056
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".204" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".204" to i32 addrspace(3)*
  store volatile i32 %"imad.15", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_08b0"
BB_08b0:
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_08e0"
BB_08e0:
  %"cond_trunc.11" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0f50", label %"BB_08f0"
BB_08f0:
  %"allocation_slot_winoff.2" = and i32 3084, 16777215
  %".209" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.2"
  %".210" = ptrtoint i8 addrspace(3)* %".209" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".210", i32 32) convergent
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P53_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0910"
BB_0910:
  %"cond_trunc.12" = trunc i32 %"P53_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0a60", label %"BB_0920"
BB_0920:
  %"s2ur_cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.15", 1
  %".214" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".215" = zext i32 64 to i64
  %".216" = zext i32 24 to i64
  %".217" = shl i64 %".214", %".216"
  %".218" = and i64 %".217", 4294967295
  %".219" = add i64 %".218", %".215"
  %".220" = trunc i64 %".219" to i32
  %"tmem_alloc_winoff.4" = and i32 3084, 16777215
  %".221" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.4"
  %".222" = bitcast i8 addrspace(3)* %".221" to i32 addrspace(3)*
  %".223" = load i32, i32 addrspace(3)* %".222"
  %".224" = lshr i32 %".223", 5
  %"P55_to_i32" = zext i1 1 to i32
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.16", %".224"
  %"bra_cond_trunc.4" = trunc i32 %"P55_to_i32" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  br i1 %"bra_cond_to_i1.4", label %"BB_0a10", label %"BB_09b0"
BB_09b0:
  %"tmem_alloc_winoff.5" = and i32 3084, 16777215
  %".226" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.5"
  %".227" = bitcast i8 addrspace(3)* %".226" to i32 addrspace(3)*
  %".228" = load i32, i32 addrspace(3)* %".227"
  %".229" = lshr i32 %".228", 5
  %"P58_to_i32" = zext i1 1 to i32
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.17", %".229"
  %"bra_cond_trunc.5" = trunc i32 %"P58_to_i32" to i1
  %"bra_cond_not.2" = xor i1 %"bra_cond_trunc.5", -1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_not.2" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  br i1 %"bra_cond_to_i1.5", label %"BB_09b0", label %"BB_0a10"
BB_0a10:
  %"phi.11" = phi  i32 [%"imad.17", %"BB_0920"], [%"imad.18", %"BB_09b0"]
  %".231" = zext i32 %"imad.16" to i64
  %".232" = zext i32 0 to i64
  %".233" = shl i64 %".232", 32
  %"shf_concat.6" = or i64 %".231", %".233"
  %"shf_shift_64.6" = zext i32 %"phi.11" to i64
  %".234" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".234" to i32
  %"imad_tmp.18" = mul i32 %"phi.11", 32
  %"imad.19" = add i32 %"imad_tmp.18", 0
  %"atoms_addr_memaddr_offset_add.6" = add i32 %".220", 20
  %"atoms_shared_addr_winoff.6" = and i32 %"atoms_addr_memaddr_offset_add.6", 16777215
  %".235" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.6"
  %"atoms_ptr.6" = bitcast i8 addrspace(3)* %".235" to i32 addrspace(3)*
  %"atoms_or.4" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.6", i32 %"shf_result.6" monotonic
  %"atoms_addr_memaddr_offset_add.7" = add i32 %".220", 24
  %"atoms_shared_addr_winoff.7" = and i32 %"atoms_addr_memaddr_offset_add.7", 16777215
  %".236" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.7"
  %"atoms_ptr.7" = bitcast i8 addrspace(3)* %".236" to i32 addrspace(3)*
  %"atoms_or.5" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.7", i32 %"shf_result.6" monotonic
  %"sts_addr_memaddr_offset_add.2" = add i32 %".16", 2060
  %"sts_shared_addr_winoff.4" = and i32 %"sts_addr_memaddr_offset_add.2", 16777215
  %".237" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".237" to i32 addrspace(3)*
  store volatile i32 %"imad.19", i32 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_0a60"
BB_0a60:
  %"allocation_slot_winoff.3" = and i32 3088, 16777215
  %".240" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.3"
  %".241" = ptrtoint i8 addrspace(3)* %".240" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".241", i32 64) convergent
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P32_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0a90"
BB_0a90:
  %"cond_trunc.13" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0c00", label %"BB_0aa0"
BB_0aa0:
  %"s2ur_cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.19", 3
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.20", 1
  %".245" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".246" = zext i32 64 to i64
  %".247" = zext i32 24 to i64
  %".248" = shl i64 %".245", %".247"
  %".249" = and i64 %".248", 4294967295
  %".250" = add i64 %".249", %".246"
  %".251" = trunc i64 %".250" to i32
  %"tmem_alloc_winoff.6" = and i32 3088, 16777215
  %".252" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.6"
  %".253" = bitcast i8 addrspace(3)* %".252" to i32 addrspace(3)*
  %".254" = load i32, i32 addrspace(3)* %".253"
  %".255" = lshr i32 %".254", 5
  %"P59_to_i32" = zext i1 1 to i32
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.21", %".255"
  %"bra_cond_trunc.6" = trunc i32 %"P59_to_i32" to i1
  %"bra_cond_to_i32.6" = zext i1 %"bra_cond_trunc.6" to i32
  %"bra_cond_to_i1.6" = icmp ne i32 %"bra_cond_to_i32.6", 0
  br i1 %"bra_cond_to_i1.6", label %"BB_0ba0", label %"BB_0b40"
BB_0b40:
  %"tmem_alloc_winoff.7" = and i32 3088, 16777215
  %".257" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.7"
  %".258" = bitcast i8 addrspace(3)* %".257" to i32 addrspace(3)*
  %".259" = load i32, i32 addrspace(3)* %".258"
  %".260" = lshr i32 %".259", 5
  %"P62_to_i32" = zext i1 1 to i32
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.22", %".260"
  %"bra_cond_trunc.7" = trunc i32 %"P62_to_i32" to i1
  %"bra_cond_not.3" = xor i1 %"bra_cond_trunc.7", -1
  %"bra_cond_to_i32.7" = zext i1 %"bra_cond_not.3" to i32
  %"bra_cond_to_i1.7" = icmp ne i32 %"bra_cond_to_i32.7", 0
  br i1 %"bra_cond_to_i1.7", label %"BB_0b40", label %"BB_0ba0"
BB_0ba0:
  %"phi.12" = phi  i32 [%"imad.22", %"BB_0aa0"], [%"imad.23", %"BB_0b40"]
  %".262" = zext i32 %"imad.20" to i64
  %".263" = zext i32 0 to i64
  %".264" = shl i64 %".263", 32
  %"shf_concat.7" = or i64 %".262", %".264"
  %"shf_shift_64.7" = zext i32 %"phi.12" to i64
  %".265" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".265" to i32
  %".266" = zext i32 %"imad.21" to i64
  %".267" = zext i32 0 to i64
  %".268" = shl i64 %".267", 32
  %"shf_concat.8" = or i64 %".266", %".268"
  %"shf_shift_64.8" = zext i32 %"phi.12" to i64
  %".269" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".269" to i32
  %"imad_tmp.23" = mul i32 %"phi.12", 32
  %"imad.24" = add i32 %"imad_tmp.23", 0
  %"atoms_addr_memaddr_offset_add.8" = add i32 %".251", 20
  %"atoms_shared_addr_winoff.8" = and i32 %"atoms_addr_memaddr_offset_add.8", 16777215
  %".270" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.8"
  %"atoms_ptr.8" = bitcast i8 addrspace(3)* %".270" to i32 addrspace(3)*
  %"atoms_or.6" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.8", i32 %"shf_result.7" monotonic
  %"atoms_addr_memaddr_offset_add.9" = add i32 %".251", 24
  %"atoms_shared_addr_winoff.9" = and i32 %"atoms_addr_memaddr_offset_add.9", 16777215
  %".271" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.9"
  %"atoms_ptr.9" = bitcast i8 addrspace(3)* %".271" to i32 addrspace(3)*
  %"atoms_or.7" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.9", i32 %"shf_result.8" monotonic
  %"sts_addr_memaddr_offset_add.3" = add i32 %".16", 2064
  %"sts_shared_addr_winoff.5" = and i32 %"sts_addr_memaddr_offset_add.3", 16777215
  %".272" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".272" to i32 addrspace(3)*
  store volatile i32 %"imad.24", i32 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_0c00"
BB_0c00:
  %"allocation_slot_winoff.4" = and i32 3092, 16777215
  %".275" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.4"
  %".276" = ptrtoint i8 addrspace(3)* %".275" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".276", i32 128) convergent
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P63_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0c30"
BB_0c30:
  %"cond_trunc.14" = trunc i32 %"P63_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0da0", label %"BB_0c40"
BB_0c40:
  %"s2ur_cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.24", 15
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.25", 1
  %".280" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".281" = zext i32 64 to i64
  %".282" = zext i32 24 to i64
  %".283" = shl i64 %".280", %".282"
  %".284" = and i64 %".283", 4294967295
  %".285" = add i64 %".284", %".281"
  %".286" = trunc i64 %".285" to i32
  %"tmem_alloc_winoff.8" = and i32 3092, 16777215
  %".287" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.8"
  %".288" = bitcast i8 addrspace(3)* %".287" to i32 addrspace(3)*
  %".289" = load i32, i32 addrspace(3)* %".288"
  %".290" = lshr i32 %".289", 5
  %"P64_to_i32" = zext i1 1 to i32
  %"imad_tmp.26" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.26", %".290"
  %"bra_cond_trunc.8" = trunc i32 %"P64_to_i32" to i1
  %"bra_cond_to_i32.8" = zext i1 %"bra_cond_trunc.8" to i32
  %"bra_cond_to_i1.8" = icmp ne i32 %"bra_cond_to_i32.8", 0
  br i1 %"bra_cond_to_i1.8", label %"BB_0d40", label %"BB_0ce0"
BB_0ce0:
  %"tmem_alloc_winoff.9" = and i32 3092, 16777215
  %".292" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.9"
  %".293" = bitcast i8 addrspace(3)* %".292" to i32 addrspace(3)*
  %".294" = load i32, i32 addrspace(3)* %".293"
  %".295" = lshr i32 %".294", 5
  %"P65_to_i32" = zext i1 1 to i32
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.28" = add i32 %"imad_tmp.27", %".295"
  %"bra_cond_trunc.9" = trunc i32 %"P65_to_i32" to i1
  %"bra_cond_not.4" = xor i1 %"bra_cond_trunc.9", -1
  %"bra_cond_to_i32.9" = zext i1 %"bra_cond_not.4" to i32
  %"bra_cond_to_i1.9" = icmp ne i32 %"bra_cond_to_i32.9", 0
  br i1 %"bra_cond_to_i1.9", label %"BB_0ce0", label %"BB_0d40"
BB_0d40:
  %"phi.13" = phi  i32 [%"imad.27", %"BB_0c40"], [%"imad.28", %"BB_0ce0"]
  %".297" = zext i32 %"imad.25" to i64
  %".298" = zext i32 0 to i64
  %".299" = shl i64 %".298", 32
  %"shf_concat.9" = or i64 %".297", %".299"
  %"shf_shift_64.9" = zext i32 %"phi.13" to i64
  %".300" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".300" to i32
  %".301" = zext i32 %"imad.26" to i64
  %".302" = zext i32 0 to i64
  %".303" = shl i64 %".302", 32
  %"shf_concat.10" = or i64 %".301", %".303"
  %"shf_shift_64.10" = zext i32 %"phi.13" to i64
  %".304" = shl i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_result.10" = trunc i64 %".304" to i32
  %"imad_tmp.28" = mul i32 %"phi.13", 32
  %"imad.29" = add i32 %"imad_tmp.28", 0
  %"atoms_addr_memaddr_offset_add.10" = add i32 %".286", 20
  %"atoms_shared_addr_winoff.10" = and i32 %"atoms_addr_memaddr_offset_add.10", 16777215
  %".305" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.10"
  %"atoms_ptr.10" = bitcast i8 addrspace(3)* %".305" to i32 addrspace(3)*
  %"atoms_or.8" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.10", i32 %"shf_result.9" monotonic
  %"atoms_addr_memaddr_offset_add.11" = add i32 %".286", 24
  %"atoms_shared_addr_winoff.11" = and i32 %"atoms_addr_memaddr_offset_add.11", 16777215
  %".306" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.11"
  %"atoms_ptr.11" = bitcast i8 addrspace(3)* %".306" to i32 addrspace(3)*
  %"atoms_or.9" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.11", i32 %"shf_result.10" monotonic
  %"sts_addr_memaddr_offset_add.4" = add i32 %".16", 2068
  %"sts_shared_addr_winoff.6" = and i32 %"sts_addr_memaddr_offset_add.4", 16777215
  %".307" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".307" to i32 addrspace(3)*
  store volatile i32 %"imad.29", i32 addrspace(3)* %"sts_shared_addr_cast.6"
  br label %"BB_0da0"
BB_0da0:
  %"allocation_slot_winoff.5" = and i32 3096, 16777215
  %".310" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.5"
  %".311" = ptrtoint i8 addrspace(3)* %".310" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".311", i32 256) convergent
  %"elect_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"election.5" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.5")
  %"elect_p.5" = extractvalue {i32, i1} %"election.5", 1
  %"P70_to_i32" = zext i1 %"elect_p.5" to i32
  br label %"BB_0dd0"
BB_0dd0:
  %"cond_trunc.15" = trunc i32 %"P70_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0f50", label %"BB_0de0"
BB_0de0:
  %"s2ur_cluster_ctarank.5" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.29", 255
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.30", 1
  %".315" = zext i32 %"s2ur_cluster_ctarank.5" to i64
  %".316" = zext i32 64 to i64
  %".317" = zext i32 24 to i64
  %".318" = shl i64 %".315", %".317"
  %".319" = and i64 %".318", 4294967295
  %".320" = add i64 %".319", %".316"
  %".321" = trunc i64 %".320" to i32
  %"tmem_alloc_winoff.10" = and i32 3096, 16777215
  %".322" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.10"
  %".323" = bitcast i8 addrspace(3)* %".322" to i32 addrspace(3)*
  %".324" = load i32, i32 addrspace(3)* %".323"
  %".325" = lshr i32 %".324", 5
  %"P66_to_i32" = zext i1 1 to i32
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.31", %".325"
  %"bra_cond_trunc.10" = trunc i32 %"P66_to_i32" to i1
  %"bra_cond_to_i32.10" = zext i1 %"bra_cond_trunc.10" to i32
  %"bra_cond_to_i1.10" = icmp ne i32 %"bra_cond_to_i32.10", 0
  br i1 %"bra_cond_to_i1.10", label %"BB_0ee0", label %"BB_0e80"
BB_0e80:
  %"tmem_alloc_winoff.11" = and i32 3096, 16777215
  %".327" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.11"
  %".328" = bitcast i8 addrspace(3)* %".327" to i32 addrspace(3)*
  %".329" = load i32, i32 addrspace(3)* %".328"
  %".330" = lshr i32 %".329", 5
  %"P69_to_i32" = zext i1 1 to i32
  %"imad_tmp.32" = mul i32 0, 0
  %"imad.33" = add i32 %"imad_tmp.32", %".330"
  %"bra_cond_trunc.11" = trunc i32 %"P69_to_i32" to i1
  %"bra_cond_not.5" = xor i1 %"bra_cond_trunc.11", -1
  %"bra_cond_to_i32.11" = zext i1 %"bra_cond_not.5" to i32
  %"bra_cond_to_i1.11" = icmp ne i32 %"bra_cond_to_i32.11", 0
  br i1 %"bra_cond_to_i1.11", label %"BB_0e80", label %"BB_0ee0"
BB_0ee0:
  %"phi.14" = phi  i32 [%"imad.32", %"BB_0de0"], [%"imad.33", %"BB_0e80"]
  %".332" = zext i32 %"imad.30" to i64
  %".333" = zext i32 0 to i64
  %".334" = shl i64 %".333", 32
  %"shf_concat.11" = or i64 %".332", %".334"
  %"shf_shift_64.11" = zext i32 %"phi.14" to i64
  %".335" = shl i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_result.11" = trunc i64 %".335" to i32
  %".336" = zext i32 %"imad.31" to i64
  %".337" = zext i32 0 to i64
  %".338" = shl i64 %".337", 32
  %"shf_concat.12" = or i64 %".336", %".338"
  %"shf_shift_64.12" = zext i32 %"phi.14" to i64
  %".339" = shl i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_result.12" = trunc i64 %".339" to i32
  %"imad_tmp.33" = mul i32 %"phi.14", 32
  %"imad.34" = add i32 %"imad_tmp.33", 0
  %"atoms_addr_memaddr_offset_add.12" = add i32 %".321", 20
  %"atoms_shared_addr_winoff.12" = and i32 %"atoms_addr_memaddr_offset_add.12", 16777215
  %".340" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.12"
  %"atoms_ptr.12" = bitcast i8 addrspace(3)* %".340" to i32 addrspace(3)*
  %"atoms_or.10" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.12", i32 %"shf_result.11" monotonic
  %"atoms_addr_memaddr_offset_add.13" = add i32 %".321", 24
  %"atoms_shared_addr_winoff.13" = and i32 %"atoms_addr_memaddr_offset_add.13", 16777215
  %".341" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.13"
  %"atoms_ptr.13" = bitcast i8 addrspace(3)* %".341" to i32 addrspace(3)*
  %"atoms_or.11" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.13", i32 %"shf_result.12" monotonic
  %"sts_addr_memaddr_offset_add.5" = add i32 %".16", 2072
  %"sts_shared_addr_winoff.7" = and i32 %"sts_addr_memaddr_offset_add.5", 16777215
  %".342" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.7"
  %"sts_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".342" to i32 addrspace(3)*
  store volatile i32 %"imad.34", i32 addrspace(3)* %"sts_shared_addr_cast.7"
  br label %"BB_0f50"
BB_0f50:
  %"isetrp_cmp1.9" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P74_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %".345" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".346" = bitcast i8* %".345" to i64*
  %"ldc_const.2" = load i64, i64* %".346"
  %"R27:R26_r0" = trunc i64 %"ldc_const.2" to i32
  %"R27:R26_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R27:R26_r1" = trunc i64 %"R27:R26_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.34" = mul i32 %"tid_x", 18
  %"imad.35" = add i32 %"imad_tmp.34", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R27:R26_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R27:R26_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.35" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.36" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R27:R26_r0.1" = trunc i64 %"imad.36" to i32
  %"R27:R26_r1_shift.1" = lshr i64 %"imad.36", 32
  %"R27:R26_r1.1" = trunc i64 %"R27:R26_r1_shift.1" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".347" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".347" to i64 addrspace(3)*
  %"lds.3" = load volatile i64, i64 addrspace(3)* %"lds_shared_addr_cast.3"
  %"R13:R12_r0" = trunc i64 %"lds.3" to i32
  %"R13:R12_r1_shift" = lshr i64 %"lds.3", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R358:R354_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R358:R354_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R358:R354_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R358:R354_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R358:R354_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R358:R354_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R358:R354_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R358:R354_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.7"
  %"imad_tmp.35" = mul i32 %"tid_x", 65536
  %"imad.37" = add i32 %"imad_tmp.35", 0
  %".348" = xor i32 %"imad.37", -1
  %".349" = xor i32 65011712, -1
  %".350" = xor i32 0, -1
  %".351" = and i32 %"imad.37", 65011712
  %".352" = and i32 %".351", %".350"
  %".353" = and i32 %"imad.37", 65011712
  %".354" = and i32 %".353", 0
  %".355" = or i32 %".352", %".354"
  %"imad_tmp.36" = mul i32 %"R13:R12_r1", 1
  %"imad.38" = add i32 %"imad_tmp.36", %".355"
  %"sttm_memaddr_offset_add" = add i32 %"imad.38", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.38", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R358:R354_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R358:R354_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R358:R354_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R358:R354_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R358:R354_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R358:R354_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R358:R354_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R358:R354_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.15"
  %"imad_addend_neg" = sub i32 0, %"R13:R12_r0"
  %"imad_tmp.37" = mul i32 %"R13:R12_r1", 1
  %"imad.39" = add i32 %"imad_tmp.37", %"imad_addend_neg"
  %"imad_tmp.38" = mul i32 %".355", 1
  %"imad.40" = add i32 %"imad_tmp.38", %"R13:R12_r0"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.38", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.38", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_11f0"
BB_11f0:
  %"cond_trunc.16" = trunc i32 %"P74_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1570", label %"BB_1200"
BB_1200:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".365" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".365" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"s2ur_cluster_ctarank.6" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".366" = zext i32 0 to i64
  %".367" = zext i32 %".16" to i64
  %".368" = shl i64 %".367", 32
  %"shf_concat.13" = or i64 %".366", %".368"
  %"shf_shift_64.13" = zext i32 4 to i64
  %".369" = lshr i64 %"shf_concat.13", %"shf_shift_64.13"
  %"shf_hi.1" = lshr i64 %".369", 32
  %"shf_result.13" = trunc i64 %"shf_hi.1" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".370" = xor i32 %"plop3_a_bit", 1
  %".371" = xor i32 %"plop3_b_bit", 1
  %".372" = xor i32 %"plop3_c_bit", 1
  %".373" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".374" = and i32 %".373", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".374", 0
  %"P75_to_i32" = zext i1 %"plop3_pred" to i32
  %".375" = xor i32 %"shf_result.13", -1
  %".376" = xor i32 16376, -1
  %".377" = xor i32 0, -1
  %".378" = and i32 %"shf_result.13", 16376
  %".379" = and i32 %".378", %".377"
  %".380" = and i32 %"shf_result.13", 16376
  %".381" = and i32 %".380", 0
  %".382" = or i32 %".379", %".381"
  %".383" = xor i32 %".382", -1
  %".384" = xor i32 524288, -1
  %".385" = xor i32 0, -1
  %".386" = and i32 %".383", 524288
  %".387" = and i32 %".386", %".385"
  %".388" = and i32 %".383", 524288
  %".389" = and i32 %".388", 0
  %".390" = or i32 %".387", %".389"
  %".391" = and i32 %".382", %".384"
  %".392" = and i32 %".391", %".385"
  %".393" = or i32 %".390", %".392"
  %".394" = and i32 %".382", %".384"
  %".395" = and i32 %".394", 0
  %".396" = or i32 %".393", %".395"
  %".397" = and i32 %".382", 524288
  %".398" = and i32 %".397", %".385"
  %".399" = or i32 %".396", %".398"
  %".400" = and i32 %".382", 524288
  %".401" = and i32 %".400", 0
  %".402" = or i32 %".399", %".401"
  %".403" = zext i32 %"s2ur_cluster_ctarank.6" to i64
  %".404" = zext i32 %"iadd3_n2.3" to i64
  %".405" = zext i32 24 to i64
  %".406" = shl i64 %".403", %".405"
  %".407" = and i64 %".406", 4294967295
  %".408" = add i64 %".407", %".404"
  %".409" = trunc i64 %".408" to i32
  %".410" = zext i32 0 to i64
  %".411" = zext i32 %".409" to i64
  %".412" = shl i64 %".411", 32
  %"shf_concat.14" = or i64 %".410", %".412"
  %"shf_shift_64.14" = zext i32 4 to i64
  %".413" = lshr i64 %"shf_concat.14", %"shf_shift_64.14"
  %"shf_hi.2" = lshr i64 %".413", 32
  %"shf_result.14" = trunc i64 %"shf_hi.2" to i32
  %".414" = xor i32 %"shf_result.14", -1
  %".415" = xor i32 16376, -1
  %".416" = xor i32 0, -1
  %".417" = and i32 %"shf_result.14", 16376
  %".418" = and i32 %".417", %".416"
  %".419" = and i32 %"shf_result.14", 16376
  %".420" = and i32 %".419", 0
  %".421" = or i32 %".418", %".420"
  %".422" = xor i32 %".421", -1
  %".423" = xor i32 524288, -1
  %".424" = xor i32 0, -1
  %".425" = and i32 %".422", 524288
  %".426" = and i32 %".425", %".424"
  %".427" = and i32 %".422", 524288
  %".428" = and i32 %".427", 0
  %".429" = or i32 %".426", %".428"
  %".430" = and i32 %".421", %".423"
  %".431" = and i32 %".430", %".424"
  %".432" = or i32 %".429", %".431"
  %".433" = and i32 %".421", %".423"
  %".434" = and i32 %".433", 0
  %".435" = or i32 %".432", %".434"
  %".436" = and i32 %".421", 524288
  %".437" = and i32 %".436", %".424"
  %".438" = or i32 %".435", %".437"
  %".439" = and i32 %".421", 524288
  %".440" = and i32 %".439", 0
  %".441" = or i32 %".438", %".440"
  %"iadd3_n1.4" = add i32 %"imad.39", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", %"lds.4"
  br label %"BB_1320"
BB_1320:
  %"phi.15" = phi  i32 [%"P38_to_i32", %"BB_1200"], [%"P24_to_i32", %"BB_1350"]
  %"phi.16" = phi  i32 [%"P75_to_i32", %"BB_1200"], [%"phi.18", %"BB_1350"]
  %"cond_trunc.17" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001320", label %"BB_1330"
BB_80001320:
  %"elect_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"election.6" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.6")
  %"elect_p.6" = extractvalue {i32, i1} %"election.6", 1
  %"P91_to_i32" = zext i1 %"elect_p.6" to i32
  br label %"BB_1330"
BB_1330:
  %"phi.17" = phi  i32 [%"P91_to_i32", %"BB_80001320"], [%"phi.15", %"BB_1320"]
  %"mma_b_r0_ext" = zext i32 %".441" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".445" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".446" = sub i64 %".445", 0
  %".447" = lshr i64 %".446", 4
  %".448" = add i64 %"mma_b_packed_1", %".447"
  %".449" = and i64 %".448", 16383
  %".450" = and i64 %"mma_b_packed_1", -16384
  %".451" = or i64 %".450", %".449"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.4", i32 %"iadd3_n2.4", i64 %".451", i32 134746256, i32 %"mma_arg_zext")
  br label %"BB_1340"
BB_1340:
  %"cond_trunc.18" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80001340", label %"BB_1350"
BB_80001340:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".455" = xor i32 %"plop3_a_bit.1", 1
  %".456" = xor i32 %"plop3_b_bit.1", 1
  %".457" = xor i32 %"plop3_c_bit.1", 1
  %".458" = and i32 %".455", %"plop3_b_bit.1"
  %".459" = and i32 %".458", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".459", 0
  %"P77_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_1350"
BB_1350:
  %"phi.18" = phi  i32 [%"P77_to_i32", %"BB_80001340"], [%"phi.16", %"BB_1340"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".461" = xor i32 %"plop3_a_bit.2", 1
  %".462" = xor i32 %"plop3_b_bit.2", 1
  %".463" = xor i32 %"plop3_c_bit.2", 1
  %".464" = and i32 %".461", %"plop3_b_bit.2"
  %".465" = and i32 %".464", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".465", 0
  %"P24_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.12" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.12" = zext i1 %"bra_cond_trunc.12" to i32
  %"bra_cond_to_i1.12" = icmp ne i32 %"bra_cond_to_i32.12", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.12")
  br i1 %"branch_any", label %"BB_1320", label %"BB_1370"
BB_1370:
  %"lds_addr_memaddr_offset_add.5" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".467" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".467" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".468" = xor i32 %"plop3_a_bit.3", 1
  %".469" = xor i32 %"plop3_b_bit.3", 1
  %".470" = xor i32 %"plop3_c_bit.3", 1
  %".471" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".472" = and i32 %".471", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".472", 0
  %"P82_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"iadd3_n1.5" = add i32 %"imad.39", %"lds.5"
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"iadd3_n2.5", 16
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"iadd3_n2.5", 4
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  br label %"BB_13f0"
BB_13f0:
  %"phi.19" = phi  i32 [%"P24_to_i32", %"BB_1370"], [%"P50_to_i32", %"BB_1420"]
  %"phi.20" = phi  i32 [%"P82_to_i32", %"BB_1370"], [%"phi.22", %"BB_1420"]
  %"cond_trunc.19" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_800013f0", label %"BB_1400"
BB_800013f0:
  %"elect_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"election.7" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.7")
  %"elect_p.7" = extractvalue {i32, i1} %"election.7", 1
  %"P48_to_i32" = zext i1 %"elect_p.7" to i32
  br label %"BB_1400"
BB_1400:
  %"phi.21" = phi  i32 [%"P48_to_i32", %"BB_800013f0"], [%"phi.19", %"BB_13f0"]
  %"mma_b_r0_ext.1" = zext i32 %".402" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".476" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".477" = sub i64 %".476", 0
  %".478" = lshr i64 %".477", 4
  %".479" = add i64 %"mma_b_packed_1.1", %".478"
  %".480" = and i64 %".479", 16383
  %".481" = and i64 %"mma_b_packed_1.1", -16384
  %".482" = or i64 %".481", %".480"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.5", i32 %"iadd3_n2.6", i64 %".482", i32 679743664, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.7")
  br label %"BB_1410"
BB_1410:
  %"cond_trunc.20" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80001410", label %"BB_1420"
BB_80001410:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".486" = xor i32 %"plop3_a_bit.4", 1
  %".487" = xor i32 %"plop3_b_bit.4", 1
  %".488" = xor i32 %"plop3_c_bit.4", 1
  %".489" = and i32 %".486", %"plop3_b_bit.4"
  %".490" = and i32 %".489", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".490", 0
  %"P84_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_1420"
BB_1420:
  %"phi.22" = phi  i32 [%"P84_to_i32", %"BB_80001410"], [%"phi.20", %"BB_1410"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".492" = xor i32 %"plop3_a_bit.5", 1
  %".493" = xor i32 %"plop3_b_bit.5", 1
  %".494" = xor i32 %"plop3_c_bit.5", 1
  %".495" = and i32 %".492", %"plop3_b_bit.5"
  %".496" = and i32 %".495", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".496", 0
  %"P50_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.13" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.13" = zext i1 %"bra_cond_trunc.13" to i32
  %"bra_cond_to_i1.13" = icmp ne i32 %"bra_cond_to_i32.13", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.13")
  br i1 %"branch_any.1", label %"BB_13f0", label %"BB_1440"
BB_1440:
  %"lds_addr_memaddr_offset_add.6" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".498" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".498" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".499" = xor i32 %"plop3_a_bit.6", 1
  %".500" = xor i32 %"plop3_b_bit.6", 1
  %".501" = xor i32 %"plop3_c_bit.6", 1
  %".502" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".503" = and i32 %".502", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".503", 0
  %"P86_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"iadd3_n1.8" = add i32 %"imad.39", %"lds.6"
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"iadd3_n2.8", 16
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"iadd3_n1.10" = add i32 %"iadd3_n2.8", 4
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  br label %"BB_14a0"
BB_14a0:
  %"phi.23" = phi  i32 [%"P50_to_i32", %"BB_1440"], [%"P43_to_i32", %"BB_14d0"]
  %"phi.24" = phi  i32 [%"P86_to_i32", %"BB_1440"], [%"phi.26", %"BB_14d0"]
  %"cond_trunc.21" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_800014a0", label %"BB_14b0"
BB_800014a0:
  %"elect_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"election.8" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.8")
  %"elect_p.8" = extractvalue {i32, i1} %"election.8", 1
  %"P41_to_i32" = zext i1 %"elect_p.8" to i32
  br label %"BB_14b0"
BB_14b0:
  %"phi.25" = phi  i32 [%"P41_to_i32", %"BB_800014a0"], [%"phi.23", %"BB_14a0"]
  %"mma_b_r0_ext.2" = zext i32 %".402" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".507" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".508" = sub i64 %".507", 0
  %".509" = lshr i64 %".508", 4
  %".510" = add i64 %"mma_b_packed_1.2", %".509"
  %".511" = and i64 %".510", 16383
  %".512" = and i64 %"mma_b_packed_1.2", -16384
  %".513" = or i64 %".512", %".511"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.6", i32 %"iadd3_n2.9", i64 %".513", i32 679743664, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.8", i32 %"iadd3_n2.10")
  br label %"BB_14c0"
BB_14c0:
  %"cond_trunc.22" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_800014c0", label %"BB_14d0"
BB_800014c0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".517" = xor i32 %"plop3_a_bit.7", 1
  %".518" = xor i32 %"plop3_b_bit.7", 1
  %".519" = xor i32 %"plop3_c_bit.7", 1
  %".520" = and i32 %".517", %"plop3_b_bit.7"
  %".521" = and i32 %".520", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".521", 0
  %"P88_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_14d0"
BB_14d0:
  %"phi.26" = phi  i32 [%"P88_to_i32", %"BB_800014c0"], [%"phi.24", %"BB_14c0"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".523" = xor i32 %"plop3_a_bit.8", 1
  %".524" = xor i32 %"plop3_b_bit.8", 1
  %".525" = xor i32 %"plop3_c_bit.8", 1
  %".526" = and i32 %".523", %"plop3_b_bit.8"
  %".527" = and i32 %".526", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".527", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.14" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.14" = zext i1 %"bra_cond_trunc.14" to i32
  %"bra_cond_to_i1.14" = icmp ne i32 %"bra_cond_to_i32.14", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.14")
  br i1 %"branch_any.2", label %"BB_14a0", label %"BB_14f0"
BB_14f0:
  %"iadd3_n1.11" = add i32 1024, 2048
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".529" = xor i32 %"plop3_a_bit.9", 1
  %".530" = xor i32 %"plop3_b_bit.9", 1
  %".531" = xor i32 %"plop3_c_bit.9", 1
  %".532" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".533" = and i32 %".532", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".533", 0
  %"P93_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".534" = zext i32 %"s2ur_cluster_ctarank.6" to i64
  %".535" = zext i32 %"iadd3_n2.11" to i64
  %".536" = zext i32 24 to i64
  %".537" = shl i64 %".534", %".536"
  %".538" = and i64 %".537", 4294967295
  %".539" = add i64 %".538", %".535"
  %".540" = trunc i64 %".539" to i32
  br label %"BB_1520"
BB_1520:
  %"phi.27" = phi  i32 [%"P43_to_i32", %"BB_14f0"], [%"P60_to_i32", %"BB_1550"]
  %"phi.28" = phi  i32 [%"P93_to_i32", %"BB_14f0"], [%"phi.30", %"BB_1550"]
  %"cond_trunc.23" = trunc i32 %"phi.28" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80001520", label %"BB_1530"
BB_80001520:
  %"elect_mask.9" = call i32 @"llvm.nvvm.activemask"()
  %"election.9" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.9")
  %"elect_p.9" = extractvalue {i32, i1} %"election.9", 1
  %"P46_to_i32" = zext i1 %"elect_p.9" to i32
  br label %"BB_1530"
BB_1530:
  %"phi.29" = phi  i32 [%"P46_to_i32", %"BB_80001520"], [%"phi.27", %"BB_1520"]
  %"utcbar_local_winoff" = and i32 %".540", 16777215
  %".544" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".545" = ptrtoint i8 addrspace(3)* %".544" to i32
  %".546" = lshr i32 %".540", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".545", i32 %".546")
  br label %"BB_1540"
BB_1540:
  %"cond_trunc.24" = trunc i32 %"phi.29" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80001540", label %"BB_1550"
BB_80001540:
  %"lop3_a_trunc.3" = trunc i32 %"phi.29" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".550" = xor i32 %"plop3_a_bit.10", 1
  %".551" = xor i32 %"plop3_b_bit.10", 1
  %".552" = xor i32 %"plop3_c_bit.10", 1
  %".553" = and i32 %".550", %"plop3_b_bit.10"
  %".554" = and i32 %".553", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".554", 0
  %"P95_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_1550"
BB_1550:
  %"phi.30" = phi  i32 [%"P95_to_i32", %"BB_80001540"], [%"phi.28", %"BB_1540"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".556" = xor i32 %"plop3_a_bit.11", 1
  %".557" = xor i32 %"plop3_b_bit.11", 1
  %".558" = xor i32 %"plop3_c_bit.11", 1
  %".559" = and i32 %".556", %"plop3_b_bit.11"
  %".560" = and i32 %".559", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".560", 0
  %"P60_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.15" = trunc i32 %"phi.30" to i1
  %"bra_cond_to_i32.15" = zext i1 %"bra_cond_trunc.15" to i32
  %"bra_cond_to_i1.15" = icmp ne i32 %"bra_cond_to_i32.15", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.15")
  br i1 %"branch_any.3", label %"BB_1520", label %"BB_1570"
BB_1570:
  %"isetrp_cmp1.10" = icmp uge i32 %"tid_x", 32
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P72_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"lop3_a_cast_zext.12" = zext i1 1 to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".562" = xor i32 %"plop3_a_bit.12", 1
  %".563" = xor i32 %"plop3_b_bit.12", 1
  %".564" = xor i32 %"plop3_c_bit.12", 1
  %".565" = and i32 %"plop3_a_bit.12", %"plop3_b_bit.12"
  %".566" = and i32 %".565", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".566", 0
  %"P98_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_15b0"
BB_15b0:
  %"cond_trunc.25" = trunc i32 %"P72_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.25", -1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_19f0", label %"BB_15c0"
BB_15c0:
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".569" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".570" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".571" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".572" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldg_addr_r0_ext.18" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9220
  %"R358:R354_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.16"
  %"ldg_addr_r0_ext.19" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.19" = or i64 0, %"ldg_addr_r0_ext.19"
  %"ldg_addr_r1_ext.19" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.19" = shl i64 %"ldg_addr_r1_ext.19", 32
  %"ldg_addr_packed_1.19" = or i64 %"ldg_addr_packed_0.19", %"ldg_addr_r1_shift.19"
  %"ldg_addr_memaddr_offset_add.18" = add i64 %"ldg_addr_packed_1.19", 9216
  %"R358:R354_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  %"ldg.19" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.17"
  %"ldg_addr_r0_ext.20" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.20" = or i64 0, %"ldg_addr_r0_ext.20"
  %"ldg_addr_r1_ext.20" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.20" = shl i64 %"ldg_addr_r1_ext.20", 32
  %"ldg_addr_packed_1.20" = or i64 %"ldg_addr_packed_0.20", %"ldg_addr_r1_shift.20"
  %"ldg_addr_memaddr_offset_add.19" = add i64 %"ldg_addr_packed_1.20", 9224
  %"R358:R354_addr_ptr.18" = inttoptr i64 %"ldg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  %"ldg.20" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.18"
  %"ldg_addr_r0_ext.21" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.21" = or i64 0, %"ldg_addr_r0_ext.21"
  %"ldg_addr_r1_ext.21" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.21" = shl i64 %"ldg_addr_r1_ext.21", 32
  %"ldg_addr_packed_1.21" = or i64 %"ldg_addr_packed_0.21", %"ldg_addr_r1_shift.21"
  %"ldg_addr_memaddr_offset_add.20" = add i64 %"ldg_addr_packed_1.21", 9228
  %"R358:R354_addr_ptr.19" = inttoptr i64 %"ldg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  %"ldg.21" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.19"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.38", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".573" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".574" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".575" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".576" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"ldg_addr_r0_ext.22" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.22" = or i64 0, %"ldg_addr_r0_ext.22"
  %"ldg_addr_r1_ext.22" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.22" = shl i64 %"ldg_addr_r1_ext.22", 32
  %"ldg_addr_packed_1.22" = or i64 %"ldg_addr_packed_0.22", %"ldg_addr_r1_shift.22"
  %"ldg_addr_memaddr_offset_add.21" = add i64 %"ldg_addr_packed_1.22", 9232
  %"R358:R354_addr_ptr.20" = inttoptr i64 %"ldg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  %"ldg.22" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.20"
  %"ldg_addr_r0_ext.23" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.23" = or i64 0, %"ldg_addr_r0_ext.23"
  %"ldg_addr_r1_ext.23" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.23" = shl i64 %"ldg_addr_r1_ext.23", 32
  %"ldg_addr_packed_1.23" = or i64 %"ldg_addr_packed_0.23", %"ldg_addr_r1_shift.23"
  %"ldg_addr_memaddr_offset_add.22" = add i64 %"ldg_addr_packed_1.23", 9236
  %"R358:R354_addr_ptr.21" = inttoptr i64 %"ldg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  %"ldg.23" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.21"
  %"ldg_addr_r0_ext.24" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.24" = or i64 0, %"ldg_addr_r0_ext.24"
  %"ldg_addr_r1_ext.24" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.24" = shl i64 %"ldg_addr_r1_ext.24", 32
  %"ldg_addr_packed_1.24" = or i64 %"ldg_addr_packed_0.24", %"ldg_addr_r1_shift.24"
  %"ldg_addr_memaddr_offset_add.23" = add i64 %"ldg_addr_packed_1.24", 9240
  %"R358:R354_addr_ptr.22" = inttoptr i64 %"ldg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  %"ldg.24" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.22"
  %"ldg_addr_r0_ext.25" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.25" = or i64 0, %"ldg_addr_r0_ext.25"
  %"ldg_addr_r1_ext.25" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.25" = shl i64 %"ldg_addr_r1_ext.25", 32
  %"ldg_addr_packed_1.25" = or i64 %"ldg_addr_packed_0.25", %"ldg_addr_r1_shift.25"
  %"ldg_addr_memaddr_offset_add.24" = add i64 %"ldg_addr_packed_1.25", 9244
  %"R358:R354_addr_ptr.23" = inttoptr i64 %"ldg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  %"ldg.25" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.23"
  %"isetrp_cmp1.11" = icmp ne i32 %".570", %"ldg.18"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P99_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".577" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".578" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".579" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".580" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"ldg_addr_r0_ext.26" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.26" = or i64 0, %"ldg_addr_r0_ext.26"
  %"ldg_addr_r1_ext.26" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.26" = shl i64 %"ldg_addr_r1_ext.26", 32
  %"ldg_addr_packed_1.26" = or i64 %"ldg_addr_packed_0.26", %"ldg_addr_r1_shift.26"
  %"ldg_addr_memaddr_offset_add.25" = add i64 %"ldg_addr_packed_1.26", 9216
  %"R358:R354_addr_ptr.24" = inttoptr i64 %"ldg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  %"ldg.26" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.24"
  %"isetrp_src_trunc" = trunc i32 %"P99_to_i32" to i1
  %"isetrp_src_not" = xor i1 %"isetrp_src_trunc", -1
  %"isetrp_cmp1.12" = icmp eq i32 %".569", %"ldg.19"
  %"isetrp_src_to_i32.12" = zext i1 %"isetrp_src_not" to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P101_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"ldg_addr_r0_ext.27" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.27" = or i64 0, %"ldg_addr_r0_ext.27"
  %"ldg_addr_r1_ext.27" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.27" = shl i64 %"ldg_addr_r1_ext.27", 32
  %"ldg_addr_packed_1.27" = or i64 %"ldg_addr_packed_0.27", %"ldg_addr_r1_shift.27"
  %"ldg_addr_memaddr_offset_add.26" = add i64 %"ldg_addr_packed_1.27", 9220
  %"R358:R354_addr_ptr.25" = inttoptr i64 %"ldg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  %"ldg.27" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.25"
  %"isetrp_src_trunc.1" = trunc i32 %"P101_to_i32" to i1
  %"isetrp_cmp1.13" = icmp eq i32 %".571", %"ldg.20"
  %"isetrp_src_to_i32.13" = zext i1 %"isetrp_src_trunc.1" to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P102_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"ldg_addr_r0_ext.28" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.28" = or i64 0, %"ldg_addr_r0_ext.28"
  %"ldg_addr_r1_ext.28" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.28" = shl i64 %"ldg_addr_r1_ext.28", 32
  %"ldg_addr_packed_1.28" = or i64 %"ldg_addr_packed_0.28", %"ldg_addr_r1_shift.28"
  %"ldg_addr_memaddr_offset_add.27" = add i64 %"ldg_addr_packed_1.28", 9224
  %"R358:R354_addr_ptr.26" = inttoptr i64 %"ldg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  %"ldg.28" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.26"
  %"isetrp_src_trunc.2" = trunc i32 %"P102_to_i32" to i1
  %"isetrp_cmp1.14" = icmp eq i32 %".572", %"ldg.21"
  %"isetrp_src_to_i32.14" = zext i1 %"isetrp_src_trunc.2" to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P104_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"ldg_addr_r0_ext.29" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.29" = or i64 0, %"ldg_addr_r0_ext.29"
  %"ldg_addr_r1_ext.29" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.29" = shl i64 %"ldg_addr_r1_ext.29", 32
  %"ldg_addr_packed_1.29" = or i64 %"ldg_addr_packed_0.29", %"ldg_addr_r1_shift.29"
  %"ldg_addr_memaddr_offset_add.28" = add i64 %"ldg_addr_packed_1.29", 9228
  %"R358:R354_addr_ptr.27" = inttoptr i64 %"ldg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  %"ldg.29" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.27"
  %"isetrp_src_trunc.3" = trunc i32 %"P104_to_i32" to i1
  %"isetrp_cmp1.15" = icmp eq i32 %".573", %"ldg.22"
  %"isetrp_src_to_i32.15" = zext i1 %"isetrp_src_trunc.3" to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P105_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.38", 4
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".581" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".582" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".583" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".584" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"ldg_addr_r0_ext.30" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.30" = or i64 0, %"ldg_addr_r0_ext.30"
  %"ldg_addr_r1_ext.30" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.30" = shl i64 %"ldg_addr_r1_ext.30", 32
  %"ldg_addr_packed_1.30" = or i64 %"ldg_addr_packed_0.30", %"ldg_addr_r1_shift.30"
  %"ldg_addr_memaddr_offset_add.29" = add i64 %"ldg_addr_packed_1.30", 9232
  %"R358:R354_addr_ptr.28" = inttoptr i64 %"ldg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  %"ldg.30" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.28"
  %"ldg_addr_r0_ext.31" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.31" = or i64 0, %"ldg_addr_r0_ext.31"
  %"ldg_addr_r1_ext.31" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.31" = shl i64 %"ldg_addr_r1_ext.31", 32
  %"ldg_addr_packed_1.31" = or i64 %"ldg_addr_packed_0.31", %"ldg_addr_r1_shift.31"
  %"ldg_addr_memaddr_offset_add.30" = add i64 %"ldg_addr_packed_1.31", 9236
  %"R358:R354_addr_ptr.29" = inttoptr i64 %"ldg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  %"ldg.31" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.29"
  %"isetrp_src_trunc.4" = trunc i32 %"P105_to_i32" to i1
  %"isetrp_cmp1.16" = icmp eq i32 %".574", %"ldg.23"
  %"isetrp_src_to_i32.16" = zext i1 %"isetrp_src_trunc.4" to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P106_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"ldg_addr_r0_ext.32" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.32" = or i64 0, %"ldg_addr_r0_ext.32"
  %"ldg_addr_r1_ext.32" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.32" = shl i64 %"ldg_addr_r1_ext.32", 32
  %"ldg_addr_packed_1.32" = or i64 %"ldg_addr_packed_0.32", %"ldg_addr_r1_shift.32"
  %"ldg_addr_memaddr_offset_add.31" = add i64 %"ldg_addr_packed_1.32", 9244
  %"R358:R354_addr_ptr.30" = inttoptr i64 %"ldg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  %"ldg.32" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.30"
  %"isetrp_src_trunc.5" = trunc i32 %"P106_to_i32" to i1
  %"isetrp_cmp1.17" = icmp eq i32 %".575", %"ldg.24"
  %"isetrp_src_to_i32.17" = zext i1 %"isetrp_src_trunc.5" to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P107_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"ldg_addr_r0_ext.33" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.33" = or i64 0, %"ldg_addr_r0_ext.33"
  %"ldg_addr_r1_ext.33" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.33" = shl i64 %"ldg_addr_r1_ext.33", 32
  %"ldg_addr_packed_1.33" = or i64 %"ldg_addr_packed_0.33", %"ldg_addr_r1_shift.33"
  %"ldg_addr_memaddr_offset_add.32" = add i64 %"ldg_addr_packed_1.33", 9240
  %"R358:R354_addr_ptr.31" = inttoptr i64 %"ldg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  %"ldg.33" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.31"
  %"isetrp_src_trunc.6" = trunc i32 %"P107_to_i32" to i1
  %"isetrp_cmp1.18" = icmp eq i32 %".576", %"ldg.25"
  %"isetrp_src_to_i32.18" = zext i1 %"isetrp_src_trunc.6" to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P108_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".585" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".586" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".587" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".588" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"ldg_addr_r0_ext.34" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.34" = or i64 0, %"ldg_addr_r0_ext.34"
  %"ldg_addr_r1_ext.34" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.34" = shl i64 %"ldg_addr_r1_ext.34", 32
  %"ldg_addr_packed_1.34" = or i64 %"ldg_addr_packed_0.34", %"ldg_addr_r1_shift.34"
  %"ldg_addr_memaddr_offset_add.33" = add i64 %"ldg_addr_packed_1.34", 9220
  %"R358:R354_addr_ptr.32" = inttoptr i64 %"ldg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  %"ldg.34" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.32"
  %"isetrp_src_trunc.7" = trunc i32 %"P108_to_i32" to i1
  %"isetrp_cmp1.19" = icmp eq i32 %".577", %"ldg.26"
  %"isetrp_src_to_i32.19" = zext i1 %"isetrp_src_trunc.7" to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P110_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"ldg_addr_r0_ext.35" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.35" = or i64 0, %"ldg_addr_r0_ext.35"
  %"ldg_addr_r1_ext.35" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.35" = shl i64 %"ldg_addr_r1_ext.35", 32
  %"ldg_addr_packed_1.35" = or i64 %"ldg_addr_packed_0.35", %"ldg_addr_r1_shift.35"
  %"ldg_addr_memaddr_offset_add.34" = add i64 %"ldg_addr_packed_1.35", 9216
  %"R358:R354_addr_ptr.33" = inttoptr i64 %"ldg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  %"ldg.35" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.33"
  %"isetrp_src_trunc.8" = trunc i32 %"P110_to_i32" to i1
  %"isetrp_cmp1.20" = icmp eq i32 %".578", %"ldg.27"
  %"isetrp_src_to_i32.20" = zext i1 %"isetrp_src_trunc.8" to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  %"isetrp_src_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"isetrp_cmp1.21" = icmp eq i32 %".579", %"ldg.28"
  %"isetrp_src_to_i32.21" = zext i1 %"isetrp_src_trunc.9" to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %"ldg_addr_r0_ext.36" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.36" = or i64 0, %"ldg_addr_r0_ext.36"
  %"ldg_addr_r1_ext.36" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.36" = shl i64 %"ldg_addr_r1_ext.36", 32
  %"ldg_addr_packed_1.36" = or i64 %"ldg_addr_packed_0.36", %"ldg_addr_r1_shift.36"
  %"ldg_addr_memaddr_offset_add.35" = add i64 %"ldg_addr_packed_1.36", 9224
  %"R358:R354_addr_ptr.34" = inttoptr i64 %"ldg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  %"ldg.36" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.34"
  %"isetrp_src_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"isetrp_cmp1.22" = icmp eq i32 %".580", %"ldg.29"
  %"isetrp_src_to_i32.22" = zext i1 %"isetrp_src_trunc.10" to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"ldg_addr_r0_ext.37" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.37" = or i64 0, %"ldg_addr_r0_ext.37"
  %"ldg_addr_r1_ext.37" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.37" = shl i64 %"ldg_addr_r1_ext.37", 32
  %"ldg_addr_packed_1.37" = or i64 %"ldg_addr_packed_0.37", %"ldg_addr_r1_shift.37"
  %"ldg_addr_memaddr_offset_add.36" = add i64 %"ldg_addr_packed_1.37", 9228
  %"R358:R354_addr_ptr.35" = inttoptr i64 %"ldg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  %"ldg.37" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.35"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.38", 4
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".589" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".590" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".591" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".592" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"isetrp_src_trunc.11" = trunc i32 %"P6_to_i32" to i1
  %"isetrp_cmp1.23" = icmp eq i32 %".581", %"ldg.30"
  %"isetrp_src_to_i32.23" = zext i1 %"isetrp_src_trunc.11" to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"ldg_addr_r0_ext.38" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.38" = or i64 0, %"ldg_addr_r0_ext.38"
  %"ldg_addr_r1_ext.38" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.38" = shl i64 %"ldg_addr_r1_ext.38", 32
  %"ldg_addr_packed_1.38" = or i64 %"ldg_addr_packed_0.38", %"ldg_addr_r1_shift.38"
  %"ldg_addr_memaddr_offset_add.37" = add i64 %"ldg_addr_packed_1.38", 9232
  %"R358:R354_addr_ptr.36" = inttoptr i64 %"ldg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  %"ldg.38" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.36"
  %"ldg_addr_r0_ext.39" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.39" = or i64 0, %"ldg_addr_r0_ext.39"
  %"ldg_addr_r1_ext.39" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.39" = shl i64 %"ldg_addr_r1_ext.39", 32
  %"ldg_addr_packed_1.39" = or i64 %"ldg_addr_packed_0.39", %"ldg_addr_r1_shift.39"
  %"ldg_addr_memaddr_offset_add.38" = add i64 %"ldg_addr_packed_1.39", 9236
  %"R358:R354_addr_ptr.37" = inttoptr i64 %"ldg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  %"ldg.39" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.37"
  %"isetrp_src_trunc.12" = trunc i32 %"P8_to_i32" to i1
  %"isetrp_cmp1.24" = icmp eq i32 %".582", %"ldg.31"
  %"isetrp_src_to_i32.24" = zext i1 %"isetrp_src_trunc.12" to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %"ldg_addr_r0_ext.40" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.40" = or i64 0, %"ldg_addr_r0_ext.40"
  %"ldg_addr_r1_ext.40" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.40" = shl i64 %"ldg_addr_r1_ext.40", 32
  %"ldg_addr_packed_1.40" = or i64 %"ldg_addr_packed_0.40", %"ldg_addr_r1_shift.40"
  %"ldg_addr_memaddr_offset_add.39" = add i64 %"ldg_addr_packed_1.40", 9240
  %"R358:R354_addr_ptr.38" = inttoptr i64 %"ldg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  %"ldg.40" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.38"
  %"ldg_addr_r0_ext.41" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.41" = or i64 0, %"ldg_addr_r0_ext.41"
  %"ldg_addr_r1_ext.41" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.41" = shl i64 %"ldg_addr_r1_ext.41", 32
  %"ldg_addr_packed_1.41" = or i64 %"ldg_addr_packed_0.41", %"ldg_addr_r1_shift.41"
  %"ldg_addr_memaddr_offset_add.40" = add i64 %"ldg_addr_packed_1.41", 9244
  %"R358:R354_addr_ptr.39" = inttoptr i64 %"ldg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  %"ldg.41" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.39"
  %"isetrp_src_trunc.13" = trunc i32 %"P9_to_i32" to i1
  %"isetrp_cmp1.25" = icmp eq i32 %".583", %"ldg.33"
  %"isetrp_src_to_i32.25" = zext i1 %"isetrp_src_trunc.13" to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  %"isetrp_src_trunc.14" = trunc i32 %"P10_to_i32" to i1
  %"isetrp_cmp1.26" = icmp eq i32 %".584", %"ldg.32"
  %"isetrp_src_to_i32.26" = zext i1 %"isetrp_src_trunc.14" to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"isetrp_src_trunc.15" = trunc i32 %"P11_to_i32" to i1
  %"isetrp_cmp1.27" = icmp eq i32 %".585", %"ldg.35"
  %"isetrp_src_to_i32.27" = zext i1 %"isetrp_src_trunc.15" to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %"isetrp_src_trunc.16" = trunc i32 %"P12_to_i32" to i1
  %"isetrp_cmp1.28" = icmp eq i32 %".586", %"ldg.34"
  %"isetrp_src_to_i32.28" = zext i1 %"isetrp_src_trunc.16" to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"isetrp_src_trunc.17" = trunc i32 %"P14_to_i32" to i1
  %"isetrp_cmp1.29" = icmp eq i32 %".587", %"ldg.36"
  %"isetrp_src_to_i32.29" = zext i1 %"isetrp_src_trunc.17" to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = and i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  %"isetrp_src_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"isetrp_cmp1.30" = icmp eq i32 %".588", %"ldg.37"
  %"isetrp_src_to_i32.30" = zext i1 %"isetrp_src_trunc.18" to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = and i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  %"isetrp_src_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"isetrp_cmp1.31" = icmp eq i32 %".589", %"ldg.38"
  %"isetrp_src_to_i32.31" = zext i1 %"isetrp_src_trunc.19" to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  %"isetrp_src_trunc.20" = trunc i32 %"P45_to_i32" to i1
  %"isetrp_cmp1.32" = icmp eq i32 %".590", %"ldg.39"
  %"isetrp_src_to_i32.32" = zext i1 %"isetrp_src_trunc.20" to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P67_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %"isetrp_src_trunc.21" = trunc i32 %"P67_to_i32" to i1
  %"isetrp_cmp1.33" = icmp eq i32 %".591", %"ldg.40"
  %"isetrp_src_to_i32.33" = zext i1 %"isetrp_src_trunc.21" to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P78_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  %"isetrp_src_trunc.22" = trunc i32 %"P78_to_i32" to i1
  %"isetrp_cmp1.34" = icmp eq i32 %".592", %"ldg.41"
  %"isetrp_src_to_i32.34" = zext i1 %"isetrp_src_trunc.22" to i32
  %"isetrp_src_to_i1.34" = icmp ne i32 %"isetrp_src_to_i32.34", 0
  %"isetrp_cmp2.34" = and i1 %"isetrp_cmp1.34", %"isetrp_src_to_i1.34"
  %"P89_to_i32" = zext i1 %"isetrp_cmp2.34" to i32
  br label %"BB_19f0"
BB_19f0:
  %"phi.31" = phi  i32 [%"P89_to_i32", %"BB_15c0"], [%"P98_to_i32", %"BB_15b0"]
  %"s2ur_cluster_ctarank.7" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.12" = add i32 1024, 2048
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", 0
  %".594" = zext i32 0 to i64
  %".595" = zext i32 0 to i64
  %".596" = shl i64 %".595", 32
  %"shf_concat.15" = or i64 %".594", %".596"
  %"shf_shift_64.15" = zext i32 31 to i64
  %".597" = shl i64 %"shf_concat.15", %"shf_shift_64.15"
  %"shf_result.15" = trunc i64 %".597" to i32
  %".598" = zext i32 %"s2ur_cluster_ctarank.7" to i64
  %".599" = zext i32 %"iadd3_n2.12" to i64
  %".600" = zext i32 24 to i64
  %".601" = shl i64 %".598", %".600"
  %".602" = and i64 %".601", 4294967295
  %".603" = add i64 %".602", %".599"
  %".604" = trunc i64 %".603" to i32
  %"mbar_shared_winoff.1" = and i32 %".604", 16777215
  %".605" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".605" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.15", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P80_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_1a60"
BB_1a60:
  %"cond_trunc.26" = trunc i32 %"P80_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.26", -1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_2ba0", label %"BB_1a70"
BB_2ba0:
  %"mbar_shared_winoff.2" = and i32 %".604", 16777215
  %".608" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".608" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.15", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P4_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_2bb0"
BB_2bb0:
  %"cond_trunc.27" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_2ba0", label %"BB_1a70"
BB_1a70:
  %".611" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".612" = bitcast i8* %".611" to i64*
  %"ldc_const.3" = load i64, i64* %".612"
  %"R19:R18_r0" = trunc i64 %"ldc_const.3" to i32
  %"R19:R18_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"imad_tmp.39" = mul i32 %"tid_x", 40
  %"imad.41" = add i32 %"imad_tmp.39", 0
  %"imad_tmp.40" = mul i32 %"imad.39", 1
  %"imad.42" = add i32 %"imad_tmp.40", %"imad.40"
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.40")
  %".613" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".614" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".615" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".616" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.40", 4
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".617" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".618" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".619" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".620" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.41" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.43" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R19:R18_r0.1" = trunc i64 %"imad.43" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"imad.43", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R226:R160_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".613", i32 addrspace(1)* %"R226:R160_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R226:R160_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".614", i32 addrspace(1)* %"R226:R160_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R226:R160_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".615", i32 addrspace(1)* %"R226:R160_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R226:R160_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".616", i32 addrspace(1)* %"R226:R160_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R226:R160_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".617", i32 addrspace(1)* %"R226:R160_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.40", 8
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".626" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".627" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".628" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".629" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R226:R160_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".618", i32 addrspace(1)* %"R226:R160_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R226:R160_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".619", i32 addrspace(1)* %"R226:R160_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R226:R160_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".620", i32 addrspace(1)* %"R226:R160_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.40", 12
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".633" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".634" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".635" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".636" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R226:R160_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".626", i32 addrspace(1)* %"R226:R160_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R226:R160_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".627", i32 addrspace(1)* %"R226:R160_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R226:R160_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".628", i32 addrspace(1)* %"R226:R160_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R226:R160_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".629", i32 addrspace(1)* %"R226:R160_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R226:R160_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".633", i32 addrspace(1)* %"R226:R160_addr_ptr.12"
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".642" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".643" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".644" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".645" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R226:R160_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".634", i32 addrspace(1)* %"R226:R160_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R226:R160_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".635", i32 addrspace(1)* %"R226:R160_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R226:R160_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".636", i32 addrspace(1)* %"R226:R160_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.42", 4
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".649" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".650" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".651" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".652" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R226:R160_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".642", i32 addrspace(1)* %"R226:R160_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R226:R160_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".643", i32 addrspace(1)* %"R226:R160_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R226:R160_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".644", i32 addrspace(1)* %"R226:R160_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R226:R160_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".645", i32 addrspace(1)* %"R226:R160_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R226:R160_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".649", i32 addrspace(1)* %"R226:R160_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.40", 16
  %"ldtm.12" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".658" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 0
  %".659" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 1
  %".660" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 2
  %".661" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R226:R160_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".650", i32 addrspace(1)* %"R226:R160_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R226:R160_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".651", i32 addrspace(1)* %"R226:R160_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R226:R160_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".652", i32 addrspace(1)* %"R226:R160_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.40", 20
  %"ldtm.13" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".665" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 0
  %".666" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 1
  %".667" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 2
  %".668" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R226:R160_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".658", i32 addrspace(1)* %"R226:R160_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R226:R160_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".659", i32 addrspace(1)* %"R226:R160_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R226:R160_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".660", i32 addrspace(1)* %"R226:R160_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R226:R160_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".661", i32 addrspace(1)* %"R226:R160_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R226:R160_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".665", i32 addrspace(1)* %"R226:R160_addr_ptr.28"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.40", 24
  %"ldtm.14" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".674" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 0
  %".675" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 1
  %".676" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 2
  %".677" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 3
  %"stg_addr_r0_ext.29" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R226:R160_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".666", i32 addrspace(1)* %"R226:R160_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R226:R160_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".667", i32 addrspace(1)* %"R226:R160_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R226:R160_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".668", i32 addrspace(1)* %"R226:R160_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.40", 28
  %"ldtm.15" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".681" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 0
  %".682" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 1
  %".683" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 2
  %".684" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 3
  %"stg_addr_r0_ext.32" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 128
  %"R226:R160_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".674", i32 addrspace(1)* %"R226:R160_addr_ptr.32"
  %"stg_addr_r0_ext.33" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 132
  %"R226:R160_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".675", i32 addrspace(1)* %"R226:R160_addr_ptr.33"
  %"stg_addr_r0_ext.34" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 136
  %"R226:R160_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".676", i32 addrspace(1)* %"R226:R160_addr_ptr.34"
  %"stg_addr_r0_ext.35" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 140
  %"R226:R160_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".677", i32 addrspace(1)* %"R226:R160_addr_ptr.35"
  %"stg_addr_r0_ext.36" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 144
  %"R226:R160_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".681", i32 addrspace(1)* %"R226:R160_addr_ptr.36"
  %"stg_addr_r0_ext.37" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 148
  %"R226:R160_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".682", i32 addrspace(1)* %"R226:R160_addr_ptr.37"
  %"stg_addr_r0_ext.38" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 152
  %"R226:R160_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".683", i32 addrspace(1)* %"R226:R160_addr_ptr.38"
  %"stg_addr_r0_ext.39" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 156
  %"R226:R160_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".684", i32 addrspace(1)* %"R226:R160_addr_ptr.39"
  br label %"BB_1ef0"
BB_1ef0:
  %"cond_trunc.28" = trunc i32 %"phi.31" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_1f30", label %"BB_1f00"
BB_1f00:
  %"ldg_addr_r0_ext.42" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.42" = or i64 0, %"ldg_addr_r0_ext.42"
  %"ldg_addr_r1_ext.42" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.42" = shl i64 %"ldg_addr_r1_ext.42", 32
  %"ldg_addr_packed_1.42" = or i64 %"ldg_addr_packed_0.42", %"ldg_addr_r1_shift.42"
  %"ldg_addr_memaddr_offset_add.41" = add i64 %"ldg_addr_packed_1.42", 9216
  %"R358:R354_addr_ptr.40" = inttoptr i64 %"ldg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  %"ldg.42" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.40"
  %".695" = xor i32 0, -1
  %".696" = xor i32 %"ldg.42", -1
  %".697" = xor i32 0, -1
  %".698" = and i32 %".695", %".696"
  %".699" = and i32 %".698", %".697"
  %".700" = and i32 %".695", %".696"
  %".701" = and i32 %".700", 0
  %".702" = or i32 %".699", %".701"
  %".703" = and i32 0, %".696"
  %".704" = and i32 %".703", %".697"
  %".705" = or i32 %".702", %".704"
  %".706" = and i32 0, %".696"
  %".707" = and i32 %".706", 0
  %".708" = or i32 %".705", %".707"
  %"stg_addr_r0_ext.40" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 64
  %"R226:R160_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".708", i32 addrspace(1)* %"R226:R160_addr_ptr.40"
  br label %"BB_1f30"
BB_1f30:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_1f60"
BB_1f60:
  %"cond_trunc.29" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_80001f60", label %"BB_1f70"
BB_1f70:
  %"lds_addr_memaddr_offset_add.7" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.7", 16777215
  %".713" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".713" to i32 addrspace(3)*
  %"lds.7" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.7"
  %"imad_tmp.41" = mul i32 0, 0
  %"imad.44" = add i32 %"imad_tmp.41", 1
  %".714" = zext i32 %"s2ur_cluster_ctarank.7" to i64
  %".715" = zext i32 64 to i64
  %".716" = zext i32 24 to i64
  %".717" = shl i64 %".714", %".716"
  %".718" = and i64 %".717", 4294967295
  %".719" = add i64 %".718", %".715"
  %".720" = trunc i64 %".719" to i32
  %"lds_addr_memaddr_offset_add.8" = add i32 %".720", 20
  %"lds_shared_addr_winoff.8" = and i32 %"lds_addr_memaddr_offset_add.8", 16777215
  %".721" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.8"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".721" to i32 addrspace(3)*
  %"lds.8" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.8"
  %".722" = xor i32 %"lds.7", -1
  %".723" = xor i32 65535, -1
  %".724" = xor i32 0, -1
  %".725" = and i32 %"lds.7", 65535
  %".726" = and i32 %".725", %".724"
  %".727" = and i32 %"lds.7", 65535
  %".728" = and i32 %".727", 0
  %".729" = or i32 %".726", %".728"
  %".730" = zext i32 0 to i64
  %".731" = zext i32 %".729" to i64
  %".732" = shl i64 %".731", 32
  %"shf_concat.16" = or i64 %".730", %".732"
  %"shf_shift_64.16" = zext i32 5 to i64
  %".733" = lshr i64 %"shf_concat.16", %"shf_shift_64.16"
  %"shf_hi.3" = lshr i64 %".733", 32
  %"shf_result.16" = trunc i64 %"shf_hi.3" to i32
  %".734" = zext i32 %"imad.44" to i64
  %".735" = zext i32 0 to i64
  %".736" = shl i64 %".735", 32
  %"shf_concat.17" = or i64 %".734", %".736"
  %"shf_shift_64.17" = zext i32 %"shf_result.16" to i64
  %".737" = shl i64 %"shf_concat.17", %"shf_shift_64.17"
  %"shf_result.17" = trunc i64 %".737" to i32
  %".738" = xor i32 %"lds.8", -1
  %".739" = xor i32 %"shf_result.17", -1
  %".740" = xor i32 0, -1
  %".741" = and i32 %"lds.8", %"shf_result.17"
  %".742" = and i32 %".741", %".740"
  %".743" = and i32 %"lds.8", %"shf_result.17"
  %".744" = and i32 %".743", 0
  %".745" = or i32 %".742", %".744"
  %"isetrp_cmp1.35" = icmp ne i32 %".745", %"shf_result.17"
  %"isetrp_src_to_i32.35" = zext i1 1 to i32
  %"isetrp_src_to_i1.35" = icmp ne i32 %"isetrp_src_to_i32.35", 0
  %"isetrp_cmp2.35" = and i1 %"isetrp_cmp1.35", %"isetrp_src_to_i1.35"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.35" to i32
  br label %"BB_2020"
BB_2020:
  %"cond_trunc.30" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_2180_2c00", label %"BB_2030"
BB_2030:
  %"lds_addr_memaddr_offset_add.9" = add i32 %".720", 24
  %"lds_shared_addr_winoff.9" = and i32 %"lds_addr_memaddr_offset_add.9", 16777215
  %".748" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.9"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".748" to i32 addrspace(3)*
  %"lds.9" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.9"
  %".749" = xor i32 %"lds.9", -1
  %".750" = xor i32 %"shf_result.17", -1
  %".751" = xor i32 0, -1
  %".752" = and i32 %"lds.9", %"shf_result.17"
  %".753" = and i32 %".752", %".751"
  %".754" = and i32 %"lds.9", %"shf_result.17"
  %".755" = and i32 %".754", 0
  %".756" = or i32 %".753", %".755"
  %"isetrp_cmp1.36" = icmp ne i32 %".756", %"shf_result.17"
  %"isetrp_src_to_i32.36" = zext i1 1 to i32
  %"isetrp_src_to_i1.36" = icmp ne i32 %"isetrp_src_to_i32.36", 0
  %"isetrp_cmp2.36" = and i1 %"isetrp_cmp1.36", %"isetrp_src_to_i1.36"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.36" to i32
  br label %"BB_2060"
BB_2060:
  %"cond_trunc.31" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_2150_2bd0", label %"BB_2070"
BB_2070:
  %"activemask.1" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.1" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.1" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.1", i1 0)
  %"flo.1" = sub i32 31, %"flo_clz.1"
  %".759" = xor i32 0, -1
  %".760" = xor i32 %"shf_result.17", -1
  %".761" = xor i32 0, -1
  %".762" = and i32 %".759", %".760"
  %".763" = and i32 %".762", %".761"
  %".764" = and i32 %".759", %".760"
  %".765" = and i32 %".764", 0
  %".766" = or i32 %".763", %".765"
  %".767" = and i32 0, %".760"
  %".768" = and i32 %".767", %".761"
  %".769" = or i32 %".766", %".768"
  %".770" = and i32 0, %".760"
  %".771" = and i32 %".770", 0
  %".772" = or i32 %".769", %".771"
  %"imad_tmp.42" = mul i32 0, 0
  %"imad.45" = add i32 %"imad_tmp.42", %".772"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.45", i32 %"redux_mask.1")
  %".773" = xor i32 %".772", -1
  %".774" = call i32 @"llvm.cttz.i32"(i32 %".773", i1 0)
  %".775" = shl i32 %".774", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".775") convergent
  %"isetrp_cmp1.37" = icmp eq i32 %"laneid.1", %"flo.1"
  %"isetrp_src_to_i32.37" = zext i1 1 to i32
  %"isetrp_src_to_i1.37" = icmp ne i32 %"isetrp_src_to_i32.37", 0
  %"isetrp_cmp2.37" = and i1 %"isetrp_cmp1.37", %"isetrp_src_to_i1.37"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.37" to i32
  %"imad_tmp.43" = mul i32 0, 0
  %"imad.46" = add i32 %"imad_tmp.43", %"redux_sync_and.1"
  br label %"BB_2110"
BB_2110:
  %"cond_trunc.32" = trunc i32 %"P16_to_i32" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_80002110", label %"BB_2190"
BB_80002110:
  %"atoms_addr_memaddr_offset_add.14" = add i32 %".720", 20
  %"atoms_shared_addr_winoff.14" = and i32 %"atoms_addr_memaddr_offset_add.14", 16777215
  %".779" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.14"
  %"atoms_ptr.14" = bitcast i8 addrspace(3)* %".779" to i32 addrspace(3)*
  %"atoms_and.2" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.14", i32 %"imad.46" monotonic
  %"atoms_addr_memaddr_offset_add.15" = add i32 %".720", 24
  %"atoms_shared_addr_winoff.15" = and i32 %"atoms_addr_memaddr_offset_add.15", 16777215
  %".780" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.15"
  %"atoms_ptr.15" = bitcast i8 addrspace(3)* %".780" to i32 addrspace(3)*
  %"atoms_and.3" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.15", i32 %"imad.46" monotonic
  br label %"BB_2190"
BB_2150_2bd0:
  call void @"llvm.trap"()
  br label %"BB_2190"
BB_2180_2c00:
  call void @"llvm.trap"()
  br label %"BB_2190"
BB_2190:
  %"s2ur_cluster_ctarank.8" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.10" = add i32 %".16", 2060
  %"lds_shared_addr_winoff.10" = and i32 %"lds_addr_memaddr_offset_add.10", 16777215
  %".784" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.10"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".784" to i32 addrspace(3)*
  %"lds.10" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.10"
  %"imad_tmp.44" = mul i32 0, 0
  %"imad.47" = add i32 %"imad_tmp.44", 1
  %".785" = zext i32 %"s2ur_cluster_ctarank.8" to i64
  %".786" = zext i32 64 to i64
  %".787" = zext i32 24 to i64
  %".788" = shl i64 %".785", %".787"
  %".789" = and i64 %".788", 4294967295
  %".790" = add i64 %".789", %".786"
  %".791" = trunc i64 %".790" to i32
  %"lds_addr_memaddr_offset_add.11" = add i32 %".791", 20
  %"lds_shared_addr_winoff.11" = and i32 %"lds_addr_memaddr_offset_add.11", 16777215
  %".792" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.11"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".792" to i32 addrspace(3)*
  %"lds.11" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.11"
  %".793" = xor i32 %"lds.10", -1
  %".794" = xor i32 65535, -1
  %".795" = xor i32 0, -1
  %".796" = and i32 %"lds.10", 65535
  %".797" = and i32 %".796", %".795"
  %".798" = and i32 %"lds.10", 65535
  %".799" = and i32 %".798", 0
  %".800" = or i32 %".797", %".799"
  %".801" = zext i32 0 to i64
  %".802" = zext i32 %".800" to i64
  %".803" = shl i64 %".802", 32
  %"shf_concat.18" = or i64 %".801", %".803"
  %"shf_shift_64.18" = zext i32 5 to i64
  %".804" = lshr i64 %"shf_concat.18", %"shf_shift_64.18"
  %"shf_hi.4" = lshr i64 %".804", 32
  %"shf_result.18" = trunc i64 %"shf_hi.4" to i32
  %".805" = zext i32 %"imad.47" to i64
  %".806" = zext i32 0 to i64
  %".807" = shl i64 %".806", 32
  %"shf_concat.19" = or i64 %".805", %".807"
  %"shf_shift_64.19" = zext i32 %"shf_result.18" to i64
  %".808" = shl i64 %"shf_concat.19", %"shf_shift_64.19"
  %"shf_result.19" = trunc i64 %".808" to i32
  %".809" = xor i32 %"lds.11", -1
  %".810" = xor i32 %"shf_result.19", -1
  %".811" = xor i32 0, -1
  %".812" = and i32 %"lds.11", %"shf_result.19"
  %".813" = and i32 %".812", %".811"
  %".814" = and i32 %"lds.11", %"shf_result.19"
  %".815" = and i32 %".814", 0
  %".816" = or i32 %".813", %".815"
  %"isetrp_cmp1.38" = icmp ne i32 %".816", %"shf_result.19"
  %"isetrp_src_to_i32.38" = zext i1 1 to i32
  %"isetrp_src_to_i1.38" = icmp ne i32 %"isetrp_src_to_i32.38", 0
  %"isetrp_cmp2.38" = and i1 %"isetrp_cmp1.38", %"isetrp_src_to_i1.38"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.38" to i32
  br label %"BB_2260"
BB_2260:
  %"cond_trunc.33" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_23c0_2c00", label %"BB_2270"
BB_2270:
  %"lds_addr_memaddr_offset_add.12" = add i32 %".791", 24
  %"lds_shared_addr_winoff.12" = and i32 %"lds_addr_memaddr_offset_add.12", 16777215
  %".819" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.12"
  %"lds_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".819" to i32 addrspace(3)*
  %"lds.12" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.12"
  %".820" = xor i32 %"lds.12", -1
  %".821" = xor i32 %"shf_result.19", -1
  %".822" = xor i32 0, -1
  %".823" = and i32 %"lds.12", %"shf_result.19"
  %".824" = and i32 %".823", %".822"
  %".825" = and i32 %"lds.12", %"shf_result.19"
  %".826" = and i32 %".825", 0
  %".827" = or i32 %".824", %".826"
  %"isetrp_cmp1.39" = icmp ne i32 %".827", %"shf_result.19"
  %"isetrp_src_to_i32.39" = zext i1 1 to i32
  %"isetrp_src_to_i1.39" = icmp ne i32 %"isetrp_src_to_i32.39", 0
  %"isetrp_cmp2.39" = and i1 %"isetrp_cmp1.39", %"isetrp_src_to_i1.39"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.39" to i32
  br label %"BB_22a0"
BB_22a0:
  %"cond_trunc.34" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_2390_2bd0", label %"BB_22b0"
BB_22b0:
  %"activemask.2" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.2" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.2" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.2", i1 0)
  %"flo.2" = sub i32 31, %"flo_clz.2"
  %".830" = xor i32 0, -1
  %".831" = xor i32 %"shf_result.19", -1
  %".832" = xor i32 0, -1
  %".833" = and i32 %".830", %".831"
  %".834" = and i32 %".833", %".832"
  %".835" = and i32 %".830", %".831"
  %".836" = and i32 %".835", 0
  %".837" = or i32 %".834", %".836"
  %".838" = and i32 0, %".831"
  %".839" = and i32 %".838", %".832"
  %".840" = or i32 %".837", %".839"
  %".841" = and i32 0, %".831"
  %".842" = and i32 %".841", 0
  %".843" = or i32 %".840", %".842"
  %"imad_tmp.45" = mul i32 0, 0
  %"imad.48" = add i32 %"imad_tmp.45", %".843"
  %"redux_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.2" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.48", i32 %"redux_mask.2")
  %".844" = xor i32 %".843", -1
  %".845" = call i32 @"llvm.cttz.i32"(i32 %".844", i1 0)
  %".846" = shl i32 %".845", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".846") convergent
  %"isetrp_cmp1.40" = icmp eq i32 %"laneid.2", %"flo.2"
  %"isetrp_src_to_i32.40" = zext i1 1 to i32
  %"isetrp_src_to_i1.40" = icmp ne i32 %"isetrp_src_to_i32.40", 0
  %"isetrp_cmp2.40" = and i1 %"isetrp_cmp1.40", %"isetrp_src_to_i1.40"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.40" to i32
  %"imad_tmp.46" = mul i32 0, 0
  %"imad.49" = add i32 %"imad_tmp.46", %"redux_sync_and.2"
  br label %"BB_2350"
BB_2350:
  %"cond_trunc.35" = trunc i32 %"P20_to_i32" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_80002350", label %"BB_23d0"
BB_80002350:
  %"atoms_addr_memaddr_offset_add.16" = add i32 %".791", 20
  %"atoms_shared_addr_winoff.16" = and i32 %"atoms_addr_memaddr_offset_add.16", 16777215
  %".850" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.16"
  %"atoms_ptr.16" = bitcast i8 addrspace(3)* %".850" to i32 addrspace(3)*
  %"atoms_and.4" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.16", i32 %"imad.49" monotonic
  %"atoms_addr_memaddr_offset_add.17" = add i32 %".791", 24
  %"atoms_shared_addr_winoff.17" = and i32 %"atoms_addr_memaddr_offset_add.17", 16777215
  %".851" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.17"
  %"atoms_ptr.17" = bitcast i8 addrspace(3)* %".851" to i32 addrspace(3)*
  %"atoms_and.5" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.17", i32 %"imad.49" monotonic
  br label %"BB_23d0"
BB_2390_2bd0:
  call void @"llvm.trap"()
  br label %"BB_23d0"
BB_23c0_2c00:
  call void @"llvm.trap"()
  br label %"BB_23d0"
BB_23d0:
  %"s2ur_cluster_ctarank.9" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.13" = add i32 %".16", 2064
  %"lds_shared_addr_winoff.13" = and i32 %"lds_addr_memaddr_offset_add.13", 16777215
  %".855" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.13"
  %"lds_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".855" to i32 addrspace(3)*
  %"lds.13" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.13"
  %"imad_tmp.47" = mul i32 0, 0
  %"imad.50" = add i32 %"imad_tmp.47", 3
  %".856" = zext i32 %"s2ur_cluster_ctarank.9" to i64
  %".857" = zext i32 64 to i64
  %".858" = zext i32 24 to i64
  %".859" = shl i64 %".856", %".858"
  %".860" = and i64 %".859", 4294967295
  %".861" = add i64 %".860", %".857"
  %".862" = trunc i64 %".861" to i32
  %"lds_addr_memaddr_offset_add.14" = add i32 %".862", 20
  %"lds_shared_addr_winoff.14" = and i32 %"lds_addr_memaddr_offset_add.14", 16777215
  %".863" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.14"
  %"lds_shared_addr_cast.14" = bitcast i8 addrspace(3)* %".863" to i32 addrspace(3)*
  %"lds.14" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.14"
  %".864" = xor i32 %"lds.13", -1
  %".865" = xor i32 65535, -1
  %".866" = xor i32 0, -1
  %".867" = and i32 %"lds.13", 65535
  %".868" = and i32 %".867", %".866"
  %".869" = and i32 %"lds.13", 65535
  %".870" = and i32 %".869", 0
  %".871" = or i32 %".868", %".870"
  %".872" = zext i32 0 to i64
  %".873" = zext i32 %".871" to i64
  %".874" = shl i64 %".873", 32
  %"shf_concat.20" = or i64 %".872", %".874"
  %"shf_shift_64.20" = zext i32 5 to i64
  %".875" = lshr i64 %"shf_concat.20", %"shf_shift_64.20"
  %"shf_hi.5" = lshr i64 %".875", 32
  %"shf_result.20" = trunc i64 %"shf_hi.5" to i32
  %".876" = zext i32 %"imad.50" to i64
  %".877" = zext i32 0 to i64
  %".878" = shl i64 %".877", 32
  %"shf_concat.21" = or i64 %".876", %".878"
  %"shf_shift_64.21" = zext i32 %"shf_result.20" to i64
  %".879" = shl i64 %"shf_concat.21", %"shf_shift_64.21"
  %"shf_result.21" = trunc i64 %".879" to i32
  %".880" = xor i32 %"lds.14", -1
  %".881" = xor i32 %"shf_result.21", -1
  %".882" = xor i32 0, -1
  %".883" = and i32 %"lds.14", %"shf_result.21"
  %".884" = and i32 %".883", %".882"
  %".885" = and i32 %"lds.14", %"shf_result.21"
  %".886" = and i32 %".885", 0
  %".887" = or i32 %".884", %".886"
  %"isetrp_cmp1.41" = icmp ne i32 %".887", %"shf_result.21"
  %"isetrp_src_to_i32.41" = zext i1 1 to i32
  %"isetrp_src_to_i1.41" = icmp ne i32 %"isetrp_src_to_i32.41", 0
  %"isetrp_cmp2.41" = and i1 %"isetrp_cmp1.41", %"isetrp_src_to_i1.41"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.41" to i32
  %"imad_tmp.48" = mul i32 0, 0
  %"imad.51" = add i32 %"imad_tmp.48", 1
  %".888" = zext i32 %"imad.51" to i64
  %".889" = zext i32 0 to i64
  %".890" = shl i64 %".889", 32
  %"shf_concat.22" = or i64 %".888", %".890"
  %"shf_shift_64.22" = zext i32 %"shf_result.20" to i64
  %".891" = shl i64 %"shf_concat.22", %"shf_shift_64.22"
  %"shf_result.22" = trunc i64 %".891" to i32
  br label %"BB_24c0"
BB_24c0:
  %"cond_trunc.36" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_2650_2c00", label %"BB_24d0"
BB_24d0:
  %"lds_addr_memaddr_offset_add.15" = add i32 %".862", 24
  %"lds_shared_addr_winoff.15" = and i32 %"lds_addr_memaddr_offset_add.15", 16777215
  %".894" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.15"
  %"lds_shared_addr_cast.15" = bitcast i8 addrspace(3)* %".894" to i32 addrspace(3)*
  %"lds.15" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.15"
  %".895" = xor i32 %"lds.15", -1
  %".896" = xor i32 %"shf_result.22", -1
  %".897" = xor i32 0, -1
  %".898" = and i32 %"lds.15", %"shf_result.22"
  %".899" = and i32 %".898", %".897"
  %".900" = and i32 %"lds.15", %"shf_result.22"
  %".901" = and i32 %".900", 0
  %".902" = or i32 %".899", %".901"
  %"isetrp_cmp1.42" = icmp ne i32 %".902", %"shf_result.22"
  %"isetrp_src_to_i32.42" = zext i1 1 to i32
  %"isetrp_src_to_i1.42" = icmp ne i32 %"isetrp_src_to_i32.42", 0
  %"isetrp_cmp2.42" = and i1 %"isetrp_cmp1.42", %"isetrp_src_to_i1.42"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.42" to i32
  br label %"BB_2500"
BB_2500:
  %"cond_trunc.37" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_2620_2bd0", label %"BB_2510"
BB_2510:
  %"activemask.3" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.3" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".905" = xor i32 0, -1
  %".906" = xor i32 %"shf_result.22", -1
  %".907" = xor i32 0, -1
  %".908" = and i32 %".905", %".906"
  %".909" = and i32 %".908", %".907"
  %".910" = and i32 %".905", %".906"
  %".911" = and i32 %".910", 0
  %".912" = or i32 %".909", %".911"
  %".913" = and i32 0, %".906"
  %".914" = and i32 %".913", %".907"
  %".915" = or i32 %".912", %".914"
  %".916" = and i32 0, %".906"
  %".917" = and i32 %".916", 0
  %".918" = or i32 %".915", %".917"
  %"flo_clz.3" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.3", i1 0)
  %"flo.3" = sub i32 31, %"flo_clz.3"
  %"redux_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.3" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".918", i32 %"redux_mask.3")
  %".919" = xor i32 0, -1
  %".920" = xor i32 %"shf_result.21", -1
  %".921" = xor i32 0, -1
  %".922" = and i32 %".919", %".920"
  %".923" = and i32 %".922", %".921"
  %".924" = and i32 %".919", %".920"
  %".925" = and i32 %".924", 0
  %".926" = or i32 %".923", %".925"
  %".927" = and i32 0, %".920"
  %".928" = and i32 %".927", %".921"
  %".929" = or i32 %".926", %".928"
  %".930" = and i32 0, %".920"
  %".931" = and i32 %".930", 0
  %".932" = or i32 %".929", %".931"
  %"imad_tmp.49" = mul i32 0, 0
  %"imad.52" = add i32 %"imad_tmp.49", %".932"
  %"redux_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.4" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.52", i32 %"redux_mask.4")
  %".933" = xor i32 %".932", -1
  %".934" = call i32 @"llvm.cttz.i32"(i32 %".933", i1 0)
  %".935" = shl i32 %".934", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".935") convergent
  %"imad_tmp.50" = mul i32 0, 0
  %"imad.53" = add i32 %"imad_tmp.50", %"redux_sync_and.3"
  %"isetrp_cmp1.43" = icmp eq i32 %"laneid.3", %"flo.3"
  %"isetrp_src_to_i32.43" = zext i1 1 to i32
  %"isetrp_src_to_i1.43" = icmp ne i32 %"isetrp_src_to_i32.43", 0
  %"isetrp_cmp2.43" = and i1 %"isetrp_cmp1.43", %"isetrp_src_to_i1.43"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.43" to i32
  %"imad_tmp.51" = mul i32 0, 0
  %"imad.54" = add i32 %"imad_tmp.51", %"redux_sync_and.4"
  br label %"BB_25e0"
BB_25e0:
  %"cond_trunc.38" = trunc i32 %"P25_to_i32" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_800025e0", label %"BB_2660"
BB_800025e0:
  %"atoms_addr_memaddr_offset_add.18" = add i32 %".862", 20
  %"atoms_shared_addr_winoff.18" = and i32 %"atoms_addr_memaddr_offset_add.18", 16777215
  %".939" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.18"
  %"atoms_ptr.18" = bitcast i8 addrspace(3)* %".939" to i32 addrspace(3)*
  %"atoms_and.6" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.18", i32 %"imad.54" monotonic
  %"atoms_addr_memaddr_offset_add.19" = add i32 %".862", 24
  %"atoms_shared_addr_winoff.19" = and i32 %"atoms_addr_memaddr_offset_add.19", 16777215
  %".940" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.19"
  %"atoms_ptr.19" = bitcast i8 addrspace(3)* %".940" to i32 addrspace(3)*
  %"atoms_and.7" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.19", i32 %"imad.53" monotonic
  br label %"BB_2660"
BB_2620_2bd0:
  call void @"llvm.trap"()
  br label %"BB_2660"
BB_2650_2c00:
  call void @"llvm.trap"()
  br label %"BB_2660"
BB_2660:
  %"s2ur_cluster_ctarank.10" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.16" = add i32 %".16", 2068
  %"lds_shared_addr_winoff.16" = and i32 %"lds_addr_memaddr_offset_add.16", 16777215
  %".944" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.16"
  %"lds_shared_addr_cast.16" = bitcast i8 addrspace(3)* %".944" to i32 addrspace(3)*
  %"lds.16" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.16"
  %"imad_tmp.52" = mul i32 0, 0
  %"imad.55" = add i32 %"imad_tmp.52", 15
  %".945" = zext i32 %"s2ur_cluster_ctarank.10" to i64
  %".946" = zext i32 64 to i64
  %".947" = zext i32 24 to i64
  %".948" = shl i64 %".945", %".947"
  %".949" = and i64 %".948", 4294967295
  %".950" = add i64 %".949", %".946"
  %".951" = trunc i64 %".950" to i32
  %"lds_addr_memaddr_offset_add.17" = add i32 %".951", 20
  %"lds_shared_addr_winoff.17" = and i32 %"lds_addr_memaddr_offset_add.17", 16777215
  %".952" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.17"
  %"lds_shared_addr_cast.17" = bitcast i8 addrspace(3)* %".952" to i32 addrspace(3)*
  %"lds.17" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.17"
  %".953" = xor i32 %"lds.16", -1
  %".954" = xor i32 65535, -1
  %".955" = xor i32 0, -1
  %".956" = and i32 %"lds.16", 65535
  %".957" = and i32 %".956", %".955"
  %".958" = and i32 %"lds.16", 65535
  %".959" = and i32 %".958", 0
  %".960" = or i32 %".957", %".959"
  %".961" = zext i32 0 to i64
  %".962" = zext i32 %".960" to i64
  %".963" = shl i64 %".962", 32
  %"shf_concat.23" = or i64 %".961", %".963"
  %"shf_shift_64.23" = zext i32 5 to i64
  %".964" = lshr i64 %"shf_concat.23", %"shf_shift_64.23"
  %"shf_hi.6" = lshr i64 %".964", 32
  %"shf_result.23" = trunc i64 %"shf_hi.6" to i32
  %".965" = zext i32 %"imad.55" to i64
  %".966" = zext i32 0 to i64
  %".967" = shl i64 %".966", 32
  %"shf_concat.24" = or i64 %".965", %".967"
  %"shf_shift_64.24" = zext i32 %"shf_result.23" to i64
  %".968" = shl i64 %"shf_concat.24", %"shf_shift_64.24"
  %"shf_result.24" = trunc i64 %".968" to i32
  %".969" = xor i32 %"lds.17", -1
  %".970" = xor i32 %"shf_result.24", -1
  %".971" = xor i32 0, -1
  %".972" = and i32 %"lds.17", %"shf_result.24"
  %".973" = and i32 %".972", %".971"
  %".974" = and i32 %"lds.17", %"shf_result.24"
  %".975" = and i32 %".974", 0
  %".976" = or i32 %".973", %".975"
  %"isetrp_cmp1.44" = icmp ne i32 %".976", %"shf_result.24"
  %"isetrp_src_to_i32.44" = zext i1 1 to i32
  %"isetrp_src_to_i1.44" = icmp ne i32 %"isetrp_src_to_i32.44", 0
  %"isetrp_cmp2.44" = and i1 %"isetrp_cmp1.44", %"isetrp_src_to_i1.44"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2.44" to i32
  %"imad_tmp.53" = mul i32 0, 0
  %"imad.56" = add i32 %"imad_tmp.53", 1
  %".977" = zext i32 %"imad.56" to i64
  %".978" = zext i32 0 to i64
  %".979" = shl i64 %".978", 32
  %"shf_concat.25" = or i64 %".977", %".979"
  %"shf_shift_64.25" = zext i32 %"shf_result.23" to i64
  %".980" = shl i64 %"shf_concat.25", %"shf_shift_64.25"
  %"shf_result.25" = trunc i64 %".980" to i32
  br label %"BB_2750"
BB_2750:
  %"cond_trunc.39" = trunc i32 %"P26_to_i32" to i1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_trunc.39" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_28e0_2c00", label %"BB_2760"
BB_2760:
  %"lds_addr_memaddr_offset_add.18" = add i32 %".951", 24
  %"lds_shared_addr_winoff.18" = and i32 %"lds_addr_memaddr_offset_add.18", 16777215
  %".983" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.18"
  %"lds_shared_addr_cast.18" = bitcast i8 addrspace(3)* %".983" to i32 addrspace(3)*
  %"lds.18" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.18"
  %".984" = xor i32 %"lds.18", -1
  %".985" = xor i32 %"shf_result.25", -1
  %".986" = xor i32 0, -1
  %".987" = and i32 %"lds.18", %"shf_result.25"
  %".988" = and i32 %".987", %".986"
  %".989" = and i32 %"lds.18", %"shf_result.25"
  %".990" = and i32 %".989", 0
  %".991" = or i32 %".988", %".990"
  %"isetrp_cmp1.45" = icmp ne i32 %".991", %"shf_result.25"
  %"isetrp_src_to_i32.45" = zext i1 1 to i32
  %"isetrp_src_to_i1.45" = icmp ne i32 %"isetrp_src_to_i32.45", 0
  %"isetrp_cmp2.45" = and i1 %"isetrp_cmp1.45", %"isetrp_src_to_i1.45"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.45" to i32
  br label %"BB_2790"
BB_2790:
  %"cond_trunc.40" = trunc i32 %"P27_to_i32" to i1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_trunc.40" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_28b0_2bd0", label %"BB_27a0"
BB_27a0:
  %"activemask.4" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.4" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".994" = xor i32 0, -1
  %".995" = xor i32 %"shf_result.25", -1
  %".996" = xor i32 0, -1
  %".997" = and i32 %".994", %".995"
  %".998" = and i32 %".997", %".996"
  %".999" = and i32 %".994", %".995"
  %".1000" = and i32 %".999", 0
  %".1001" = or i32 %".998", %".1000"
  %".1002" = and i32 0, %".995"
  %".1003" = and i32 %".1002", %".996"
  %".1004" = or i32 %".1001", %".1003"
  %".1005" = and i32 0, %".995"
  %".1006" = and i32 %".1005", 0
  %".1007" = or i32 %".1004", %".1006"
  %"flo_clz.4" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.4", i1 0)
  %"flo.4" = sub i32 31, %"flo_clz.4"
  %"redux_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.5" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".1007", i32 %"redux_mask.5")
  %".1008" = xor i32 0, -1
  %".1009" = xor i32 %"shf_result.24", -1
  %".1010" = xor i32 0, -1
  %".1011" = and i32 %".1008", %".1009"
  %".1012" = and i32 %".1011", %".1010"
  %".1013" = and i32 %".1008", %".1009"
  %".1014" = and i32 %".1013", 0
  %".1015" = or i32 %".1012", %".1014"
  %".1016" = and i32 0, %".1009"
  %".1017" = and i32 %".1016", %".1010"
  %".1018" = or i32 %".1015", %".1017"
  %".1019" = and i32 0, %".1009"
  %".1020" = and i32 %".1019", 0
  %".1021" = or i32 %".1018", %".1020"
  %"imad_tmp.54" = mul i32 0, 0
  %"imad.57" = add i32 %"imad_tmp.54", %".1021"
  %"redux_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.6" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.57", i32 %"redux_mask.6")
  %".1022" = xor i32 %".1021", -1
  %".1023" = call i32 @"llvm.cttz.i32"(i32 %".1022", i1 0)
  %".1024" = shl i32 %".1023", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".1024") convergent
  %"imad_tmp.55" = mul i32 0, 0
  %"imad.58" = add i32 %"imad_tmp.55", %"redux_sync_and.5"
  %"isetrp_cmp1.46" = icmp eq i32 %"laneid.4", %"flo.4"
  %"isetrp_src_to_i32.46" = zext i1 1 to i32
  %"isetrp_src_to_i1.46" = icmp ne i32 %"isetrp_src_to_i32.46", 0
  %"isetrp_cmp2.46" = and i1 %"isetrp_cmp1.46", %"isetrp_src_to_i1.46"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.46" to i32
  %"imad_tmp.56" = mul i32 0, 0
  %"imad.59" = add i32 %"imad_tmp.56", %"redux_sync_and.6"
  br label %"BB_2870"
BB_2870:
  %"cond_trunc.41" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.41" = zext i1 %"cond_trunc.41" to i32
  %"pbra_cond_to_i1.41" = icmp ne i32 %"pbra_cond_to_i32.41", 0
  br i1 %"pbra_cond_to_i1.41", label %"BB_80002870", label %"BB_28f0"
BB_80002870:
  %"atoms_addr_memaddr_offset_add.20" = add i32 %".951", 20
  %"atoms_shared_addr_winoff.20" = and i32 %"atoms_addr_memaddr_offset_add.20", 16777215
  %".1028" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.20"
  %"atoms_ptr.20" = bitcast i8 addrspace(3)* %".1028" to i32 addrspace(3)*
  %"atoms_and.8" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.20", i32 %"imad.59" monotonic
  %"atoms_addr_memaddr_offset_add.21" = add i32 %".951", 24
  %"atoms_shared_addr_winoff.21" = and i32 %"atoms_addr_memaddr_offset_add.21", 16777215
  %".1029" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.21"
  %"atoms_ptr.21" = bitcast i8 addrspace(3)* %".1029" to i32 addrspace(3)*
  %"atoms_and.9" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.21", i32 %"imad.58" monotonic
  br label %"BB_28f0"
BB_28b0_2bd0:
  call void @"llvm.trap"()
  br label %"BB_28f0"
BB_28e0_2c00:
  call void @"llvm.trap"()
  br label %"BB_28f0"
BB_28f0:
  %"s2ur_cluster_ctarank.11" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.19" = add i32 %".16", 2072
  %"lds_shared_addr_winoff.19" = and i32 %"lds_addr_memaddr_offset_add.19", 16777215
  %".1033" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.19"
  %"lds_shared_addr_cast.19" = bitcast i8 addrspace(3)* %".1033" to i32 addrspace(3)*
  %"lds.19" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.19"
  %"imad_tmp.57" = mul i32 0, 0
  %"imad.60" = add i32 %"imad_tmp.57", 255
  %".1034" = zext i32 %"s2ur_cluster_ctarank.11" to i64
  %".1035" = zext i32 64 to i64
  %".1036" = zext i32 24 to i64
  %".1037" = shl i64 %".1034", %".1036"
  %".1038" = and i64 %".1037", 4294967295
  %".1039" = add i64 %".1038", %".1035"
  %".1040" = trunc i64 %".1039" to i32
  %"lds_addr_memaddr_offset_add.20" = add i32 %".1040", 20
  %"lds_shared_addr_winoff.20" = and i32 %"lds_addr_memaddr_offset_add.20", 16777215
  %".1041" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.20"
  %"lds_shared_addr_cast.20" = bitcast i8 addrspace(3)* %".1041" to i32 addrspace(3)*
  %"lds.20" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.20"
  %".1042" = xor i32 %"lds.19", -1
  %".1043" = xor i32 65535, -1
  %".1044" = xor i32 0, -1
  %".1045" = and i32 %"lds.19", 65535
  %".1046" = and i32 %".1045", %".1044"
  %".1047" = and i32 %"lds.19", 65535
  %".1048" = and i32 %".1047", 0
  %".1049" = or i32 %".1046", %".1048"
  %".1050" = zext i32 0 to i64
  %".1051" = zext i32 %".1049" to i64
  %".1052" = shl i64 %".1051", 32
  %"shf_concat.26" = or i64 %".1050", %".1052"
  %"shf_shift_64.26" = zext i32 5 to i64
  %".1053" = lshr i64 %"shf_concat.26", %"shf_shift_64.26"
  %"shf_hi.7" = lshr i64 %".1053", 32
  %"shf_result.26" = trunc i64 %"shf_hi.7" to i32
  %".1054" = zext i32 %"imad.60" to i64
  %".1055" = zext i32 0 to i64
  %".1056" = shl i64 %".1055", 32
  %"shf_concat.27" = or i64 %".1054", %".1056"
  %"shf_shift_64.27" = zext i32 %"shf_result.26" to i64
  %".1057" = shl i64 %"shf_concat.27", %"shf_shift_64.27"
  %"shf_result.27" = trunc i64 %".1057" to i32
  %".1058" = xor i32 %"lds.20", -1
  %".1059" = xor i32 %"shf_result.27", -1
  %".1060" = xor i32 0, -1
  %".1061" = and i32 %"lds.20", %"shf_result.27"
  %".1062" = and i32 %".1061", %".1060"
  %".1063" = and i32 %"lds.20", %"shf_result.27"
  %".1064" = and i32 %".1063", 0
  %".1065" = or i32 %".1062", %".1064"
  %"isetrp_cmp1.47" = icmp ne i32 %".1065", %"shf_result.27"
  %"isetrp_src_to_i32.47" = zext i1 1 to i32
  %"isetrp_src_to_i1.47" = icmp ne i32 %"isetrp_src_to_i32.47", 0
  %"isetrp_cmp2.47" = and i1 %"isetrp_cmp1.47", %"isetrp_src_to_i1.47"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.47" to i32
  %"imad_tmp.58" = mul i32 0, 0
  %"imad.61" = add i32 %"imad_tmp.58", 1
  %".1066" = zext i32 %"imad.61" to i64
  %".1067" = zext i32 0 to i64
  %".1068" = shl i64 %".1067", 32
  %"shf_concat.28" = or i64 %".1066", %".1068"
  %"shf_shift_64.28" = zext i32 %"shf_result.26" to i64
  %".1069" = shl i64 %"shf_concat.28", %"shf_shift_64.28"
  %"shf_result.28" = trunc i64 %".1069" to i32
  br label %"BB_29e0"
BB_29e0:
  %"cond_trunc.42" = trunc i32 %"P30_to_i32" to i1
  %"pbra_cond_to_i32.42" = zext i1 %"cond_trunc.42" to i32
  %"pbra_cond_to_i1.42" = icmp ne i32 %"pbra_cond_to_i32.42", 0
  br i1 %"pbra_cond_to_i1.42", label %"BB_2b70_2c00", label %"BB_29f0"
BB_29f0:
  %"lds_addr_memaddr_offset_add.21" = add i32 %".1040", 24
  %"lds_shared_addr_winoff.21" = and i32 %"lds_addr_memaddr_offset_add.21", 16777215
  %".1072" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.21"
  %"lds_shared_addr_cast.21" = bitcast i8 addrspace(3)* %".1072" to i32 addrspace(3)*
  %"lds.21" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.21"
  %".1073" = xor i32 %"lds.21", -1
  %".1074" = xor i32 %"shf_result.28", -1
  %".1075" = xor i32 0, -1
  %".1076" = and i32 %"lds.21", %"shf_result.28"
  %".1077" = and i32 %".1076", %".1075"
  %".1078" = and i32 %"lds.21", %"shf_result.28"
  %".1079" = and i32 %".1078", 0
  %".1080" = or i32 %".1077", %".1079"
  %"isetrp_cmp1.48" = icmp ne i32 %".1080", %"shf_result.28"
  %"isetrp_src_to_i32.48" = zext i1 1 to i32
  %"isetrp_src_to_i1.48" = icmp ne i32 %"isetrp_src_to_i32.48", 0
  %"isetrp_cmp2.48" = and i1 %"isetrp_cmp1.48", %"isetrp_src_to_i1.48"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.48" to i32
  br label %"BB_2a20"
BB_2a20:
  %"cond_trunc.43" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.43" = zext i1 %"cond_trunc.43" to i32
  %"pbra_cond_to_i1.43" = icmp ne i32 %"pbra_cond_to_i32.43", 0
  br i1 %"pbra_cond_to_i1.43", label %"BB_2b40_2bd0", label %"BB_2a30"
BB_2a30:
  %"activemask.5" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.5" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".1083" = xor i32 0, -1
  %".1084" = xor i32 %"shf_result.28", -1
  %".1085" = xor i32 0, -1
  %".1086" = and i32 %".1083", %".1084"
  %".1087" = and i32 %".1086", %".1085"
  %".1088" = and i32 %".1083", %".1084"
  %".1089" = and i32 %".1088", 0
  %".1090" = or i32 %".1087", %".1089"
  %".1091" = and i32 0, %".1084"
  %".1092" = and i32 %".1091", %".1085"
  %".1093" = or i32 %".1090", %".1092"
  %".1094" = and i32 0, %".1084"
  %".1095" = and i32 %".1094", 0
  %".1096" = or i32 %".1093", %".1095"
  %"flo_clz.5" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.5", i1 0)
  %"flo.5" = sub i32 31, %"flo_clz.5"
  %"redux_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.7" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".1096", i32 %"redux_mask.7")
  %".1097" = xor i32 0, -1
  %".1098" = xor i32 %"shf_result.27", -1
  %".1099" = xor i32 0, -1
  %".1100" = and i32 %".1097", %".1098"
  %".1101" = and i32 %".1100", %".1099"
  %".1102" = and i32 %".1097", %".1098"
  %".1103" = and i32 %".1102", 0
  %".1104" = or i32 %".1101", %".1103"
  %".1105" = and i32 0, %".1098"
  %".1106" = and i32 %".1105", %".1099"
  %".1107" = or i32 %".1104", %".1106"
  %".1108" = and i32 0, %".1098"
  %".1109" = and i32 %".1108", 0
  %".1110" = or i32 %".1107", %".1109"
  %"imad_tmp.59" = mul i32 0, 0
  %"imad.62" = add i32 %"imad_tmp.59", %".1110"
  %"redux_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.8" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.62", i32 %"redux_mask.8")
  %".1111" = xor i32 %".1110", -1
  %".1112" = call i32 @"llvm.cttz.i32"(i32 %".1111", i1 0)
  %".1113" = shl i32 %".1112", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 256;", "r,~{memory}"(i32 %".1113") convergent
  %"imad_tmp.60" = mul i32 0, 0
  %"imad.63" = add i32 %"imad_tmp.60", %"redux_sync_and.7"
  %"isetrp_cmp1.49" = icmp eq i32 %"laneid.5", %"flo.5"
  %"isetrp_src_to_i32.49" = zext i1 1 to i32
  %"isetrp_src_to_i1.49" = icmp ne i32 %"isetrp_src_to_i32.49", 0
  %"isetrp_cmp2.49" = and i1 %"isetrp_cmp1.49", %"isetrp_src_to_i1.49"
  %"P33_to_i32" = zext i1 %"isetrp_cmp2.49" to i32
  %"imad_tmp.61" = mul i32 0, 0
  %"imad.64" = add i32 %"imad_tmp.61", %"redux_sync_and.8"
  br label %"BB_2b00"
BB_2b00:
  %"cond_trunc.44" = trunc i32 %"P33_to_i32" to i1
  %"pbra_cond_to_i32.44" = zext i1 %"cond_trunc.44" to i32
  %"pbra_cond_to_i1.44" = icmp ne i32 %"pbra_cond_to_i32.44", 0
  br i1 %"pbra_cond_to_i1.44", label %"BB_80002b00", label %"BB_2b80"
BB_80002b00:
  %"atoms_addr_memaddr_offset_add.22" = add i32 %".1040", 20
  %"atoms_shared_addr_winoff.22" = and i32 %"atoms_addr_memaddr_offset_add.22", 16777215
  %".1117" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.22"
  %"atoms_ptr.22" = bitcast i8 addrspace(3)* %".1117" to i32 addrspace(3)*
  %"atoms_and.10" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.22", i32 %"imad.64" monotonic
  %"atoms_addr_memaddr_offset_add.23" = add i32 %".1040", 24
  %"atoms_shared_addr_winoff.23" = and i32 %"atoms_addr_memaddr_offset_add.23", 16777215
  %".1118" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.23"
  %"atoms_ptr.23" = bitcast i8 addrspace(3)* %".1118" to i32 addrspace(3)*
  %"atoms_and.11" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.23", i32 %"imad.63" monotonic
  br label %"BB_2b80"
BB_2b40_2bd0:
  call void @"llvm.trap"()
  br label %"BB_2b80"
BB_2b70_2c00:
  call void @"llvm.trap"()
  br label %"BB_2b80"
BB_2b80:
  ret void
BB_80001f60:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P38_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0080"
BB_0080:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_02a0", label %"BB_0090"
BB_0090:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"UR11:UR10_r0" = trunc i64 %"ldc_const" to i32
  %"UR11:UR10_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR11:UR10_r1" = trunc i64 %"UR11:UR10_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".21" = xor i32 %"imad", -1
  %".22" = xor i32 508, -1
  %".23" = xor i32 0, -1
  %".24" = and i32 %"imad", 508
  %".25" = and i32 %".24", %".23"
  %".26" = and i32 %"imad", 508
  %".27" = and i32 %".26", 0
  %".28" = or i32 %".25", %".27"
  %"iadd3_o1_64" = zext i32 %".28" to i64
  %"iadd3_o2_64" = zext i32 %"UR11:UR10_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P57_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR11:UR10_r1"
  %"imad_cin_trunc" = trunc i32 %"P57_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R17:R411_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R17:R411_addr_ptr"
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".29" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".30" = zext i32 %"iadd3_n2" to i64
  %".31" = zext i32 24 to i64
  %".32" = shl i64 %".29", %".31"
  %".33" = and i64 %".32", 4294967295
  %".34" = add i64 %".33", %".30"
  %".35" = trunc i64 %".34" to i32
  %"viadd" = add i32 %"imad", %".35"
  br label %"BB_0140"
BB_0140:
  %"phi" = phi  i32 [%"tid_x", %"BB_0090"], [%"viadd.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"viadd", %"BB_0090"], [%"viadd.2", %"BB_0180"]
  %"isetrp_cmp1.1" = icmp uge i32 %"phi", 128
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P97_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".37" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".37" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P97_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0140", label %"BB_0190"
BB_0190:
  %".41" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".42" = bitcast i8* %".41" to i64*
  %"ldc_const.1" = load i64, i64* %".42"
  %"R5:R4_r0" = trunc i64 %"ldc_const.1" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"viadd.3" = add i32 %"imad", %".16"
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad.2" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P109_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R5:R4_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P109_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0210"
BB_0210:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_0190"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.3" = phi  i32 [%"iadd3_trunc.1", %"BB_0190"], [%"iadd3_trunc.2", %"BB_0290"]
  %"phi.4" = phi  i32 [%"tid_x", %"BB_0190"], [%"viadd.4", %"BB_0290"]
  %"phi.5" = phi  i32 [%"viadd.3", %"BB_0190"], [%"viadd.5", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R60:R14_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R60:R14_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.4", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P17_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.4" = add i32 %"phi.4", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P36_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P36_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.5", 16777215
  %".44" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".44" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.5", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P17_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"isetrp_cmp1.3" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"vote_pred_trunc" = trunc i32 %"P35_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P52_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02f0"
BB_02f0:
  %"cond_trunc.3" = trunc i32 %"P52_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002f0", label %"BB_0340"
BB_800002f0:
  %"iadd3_n1.1" = add i32 1024, 2048
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".50" = zext i32 %"iadd3_n2.2" to i64
  %".51" = zext i32 0 to i64
  %".52" = shl i64 %".51", 32
  %"shf_concat" = or i64 %".50", %".52"
  %"shf_shift_64" = zext i32 11 to i64
  %".53" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".53" to i32
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat.1" = or i64 %".54", %".56"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".57" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".57" to i32
  %".58" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".59" = zext i32 %"iadd3_n2.1" to i64
  %".60" = zext i32 24 to i64
  %".61" = shl i64 %".58", %".60"
  %".62" = and i64 %".61", 4294967295
  %".63" = add i64 %".62", %".59"
  %".64" = trunc i64 %".63" to i32
  br label %"BB_0340"
BB_0340:
  %"phi.6" = phi  i32 [%".64", %"BB_800002f0"], [0, %"BB_02f0"]
  %"phi.7" = phi  i32 [%"shf_result", %"BB_800002f0"], [1024, %"BB_02f0"]
  %"phi.8" = phi  i32 [%"shf_result.1", %"BB_800002f0"], [1, %"BB_02f0"]
  %"vote_pred_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P61_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P79_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P61_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.6", 16777215
  %".69" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".69" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.7" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".70" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".70" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P79_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_08b0", label %"BB_0390"
BB_0390:
  %"allocation_slot_winoff" = and i32 3080, 16777215
  %".74" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".75" = ptrtoint i8 addrspace(3)* %".74" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".75", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P92_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P92_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_04f0", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 1
  %".79" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".80" = zext i32 64 to i64
  %".81" = zext i32 24 to i64
  %".82" = shl i64 %".79", %".81"
  %".83" = and i64 %".82", 4294967295
  %".84" = add i64 %".83", %".80"
  %".85" = trunc i64 %".84" to i32
  %"tmem_alloc_winoff" = and i32 3080, 16777215
  %".86" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".87" = bitcast i8 addrspace(3)* %".86" to i32 addrspace(3)*
  %".88" = load i32, i32 addrspace(3)* %".87"
  %".89" = lshr i32 %".88", 5
  %"P68_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".89"
  %"bra_cond_trunc" = trunc i32 %"P68_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_winoff.1" = and i32 3080, 16777215
  %".91" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".92" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  %".93" = load i32, i32 addrspace(3)* %".92"
  %".94" = lshr i32 %".93", 5
  %"P71_to_i32" = zext i1 1 to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".94"
  %"bra_cond_trunc.1" = trunc i32 %"P71_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.9" = phi  i32 [%"imad.6", %"BB_03c0"], [%"imad.7", %"BB_0440"]
  %".96" = zext i32 %"imad.5" to i64
  %".97" = zext i32 0 to i64
  %".98" = shl i64 %".97", 32
  %"shf_concat.2" = or i64 %".96", %".98"
  %"shf_shift_64.2" = zext i32 %"phi.9" to i64
  %".99" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".99" to i32
  %"imad_tmp.7" = mul i32 %"phi.9", 32
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".85", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".100" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".100" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".85", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".101" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".102" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".102" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_04f0"
BB_04f0:
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 2056
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".105" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", 1
  %".106" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".107" = zext i32 64 to i64
  %".108" = zext i32 24 to i64
  %".109" = shl i64 %".106", %".108"
  %".110" = and i64 %".109", 4294967295
  %".111" = add i64 %".110", %".107"
  %".112" = trunc i64 %".111" to i32
  %"lds_addr_memaddr_offset_add.1" = add i32 %".112", 20
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".113" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".113" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".114" = xor i32 %"lds", -1
  %".115" = xor i32 65535, -1
  %".116" = xor i32 0, -1
  %".117" = and i32 %"lds", 65535
  %".118" = and i32 %".117", %".116"
  %".119" = and i32 %"lds", 65535
  %".120" = and i32 %".119", 0
  %".121" = or i32 %".118", %".120"
  %".122" = zext i32 0 to i64
  %".123" = zext i32 %".121" to i64
  %".124" = shl i64 %".123", 32
  %"shf_concat.3" = or i64 %".122", %".124"
  %"shf_shift_64.3" = zext i32 5 to i64
  %".125" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".125", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".126" = zext i32 %"imad.9" to i64
  %".127" = zext i32 0 to i64
  %".128" = shl i64 %".127", 32
  %"shf_concat.4" = or i64 %".126", %".128"
  %"shf_shift_64.4" = zext i32 %"shf_result.3" to i64
  %".129" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".129" to i32
  %".130" = xor i32 %"lds.1", -1
  %".131" = xor i32 %"shf_result.4", -1
  %".132" = xor i32 0, -1
  %".133" = and i32 %"lds.1", %"shf_result.4"
  %".134" = and i32 %".133", %".132"
  %".135" = and i32 %"lds.1", %"shf_result.4"
  %".136" = and i32 %".135", 0
  %".137" = or i32 %".134", %".136"
  %"isetrp_cmp1.5" = icmp ne i32 %".137", %"shf_result.4"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P103_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_05b0"
BB_05b0:
  %"cond_trunc.7" = trunc i32 %"P103_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0710_2c00", label %"BB_05c0"
BB_05c0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".112", 24
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".140" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".140" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %".141" = xor i32 %"lds.2", -1
  %".142" = xor i32 %"shf_result.4", -1
  %".143" = xor i32 0, -1
  %".144" = and i32 %"lds.2", %"shf_result.4"
  %".145" = and i32 %".144", %".143"
  %".146" = and i32 %"lds.2", %"shf_result.4"
  %".147" = and i32 %".146", 0
  %".148" = or i32 %".145", %".147"
  %"isetrp_cmp1.6" = icmp ne i32 %".148", %"shf_result.4"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_05f0"
BB_05f0:
  %"cond_trunc.8" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_06e0_2bd0", label %"BB_0600"
BB_0600:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".151" = xor i32 0, -1
  %".152" = xor i32 %"shf_result.4", -1
  %".153" = xor i32 0, -1
  %".154" = and i32 %".151", %".152"
  %".155" = and i32 %".154", %".153"
  %".156" = and i32 %".151", %".152"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 0, %".152"
  %".160" = and i32 %".159", %".153"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 0, %".152"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.9", %".164"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.10", i32 %"redux_mask")
  %".165" = xor i32 %".164", -1
  %".166" = call i32 @"llvm.cttz.i32"(i32 %".165", i1 0)
  %".167" = shl i32 %".166", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".167") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.10", %"redux_sync_and"
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.9" = trunc i32 %"P56_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800006a0", label %"BB_0720"
BB_800006a0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".112", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".171" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".171" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.11" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".112", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".172" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".172" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.11" monotonic
  br label %"BB_0720"
BB_06e0_2bd0:
  call void @"llvm.trap"()
  br label %"BB_0720"
BB_0710_2c00:
  call void @"llvm.trap"()
  br label %"BB_0720"
BB_0720:
  %"allocation_slot_winoff.1" = and i32 3080, 16777215
  %".176" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.1"
  %".177" = ptrtoint i8 addrspace(3)* %".176" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".177", i32 32) convergent
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P28_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0750"
BB_0750:
  %"cond_trunc.10" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_08b0", label %"BB_0760"
BB_0760:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.11", 1
  %".181" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".182" = zext i32 64 to i64
  %".183" = zext i32 24 to i64
  %".184" = shl i64 %".181", %".183"
  %".185" = and i64 %".184", 4294967295
  %".186" = add i64 %".185", %".182"
  %".187" = trunc i64 %".186" to i32
  %"tmem_alloc_winoff.2" = and i32 3080, 16777215
  %".188" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.2"
  %".189" = bitcast i8 addrspace(3)* %".188" to i32 addrspace(3)*
  %".190" = load i32, i32 addrspace(3)* %".189"
  %".191" = lshr i32 %".190", 5
  %"P73_to_i32" = zext i1 1 to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", %".191"
  %"bra_cond_trunc.2" = trunc i32 %"P73_to_i32" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  br i1 %"bra_cond_to_i1.2", label %"BB_0850", label %"BB_07f0"
BB_07f0:
  %"tmem_alloc_winoff.3" = and i32 3080, 16777215
  %".193" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.3"
  %".194" = bitcast i8 addrspace(3)* %".193" to i32 addrspace(3)*
  %".195" = load i32, i32 addrspace(3)* %".194"
  %".196" = lshr i32 %".195", 5
  %"P54_to_i32" = zext i1 1 to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", %".196"
  %"bra_cond_trunc.3" = trunc i32 %"P54_to_i32" to i1
  %"bra_cond_not.1" = xor i1 %"bra_cond_trunc.3", -1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_not.1" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  br i1 %"bra_cond_to_i1.3", label %"BB_07f0", label %"BB_0850"
BB_0850:
  %"phi.10" = phi  i32 [%"imad.13", %"BB_0760"], [%"imad.14", %"BB_07f0"]
  %".198" = zext i32 %"imad.12" to i64
  %".199" = zext i32 0 to i64
  %".200" = shl i64 %".199", 32
  %"shf_concat.5" = or i64 %".198", %".200"
  %"shf_shift_64.5" = zext i32 %"phi.10" to i64
  %".201" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".201" to i32
  %"imad_tmp.14" = mul i32 %"phi.10", 32
  %"imad.15" = add i32 %"imad_tmp.14", 0
  %"atoms_addr_memaddr_offset_add.4" = add i32 %".187", 20
  %"atoms_shared_addr_winoff.4" = and i32 %"atoms_addr_memaddr_offset_add.4", 16777215
  %".202" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.4"
  %"atoms_ptr.4" = bitcast i8 addrspace(3)* %".202" to i32 addrspace(3)*
  %"atoms_or.2" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.4", i32 %"shf_result.5" monotonic
  %"atoms_addr_memaddr_offset_add.5" = add i32 %".187", 24
  %"atoms_shared_addr_winoff.5" = and i32 %"atoms_addr_memaddr_offset_add.5", 16777215
  %".203" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.5"
  %"atoms_ptr.5" = bitcast i8 addrspace(3)* %".203" to i32 addrspace(3)*
  %"atoms_or.3" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.5", i32 %"shf_result.5" monotonic
  %"sts_addr_memaddr_offset_add.1" = add i32 %".16", 2056
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".204" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".204" to i32 addrspace(3)*
  store volatile i32 %"imad.15", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_08b0"
BB_08b0:
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_08e0"
BB_08e0:
  %"cond_trunc.11" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0f50", label %"BB_08f0"
BB_08f0:
  %"allocation_slot_winoff.2" = and i32 3084, 16777215
  %".209" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.2"
  %".210" = ptrtoint i8 addrspace(3)* %".209" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".210", i32 32) convergent
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P53_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0910"
BB_0910:
  %"cond_trunc.12" = trunc i32 %"P53_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0a60", label %"BB_0920"
BB_0920:
  %"s2ur_cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.15", 1
  %".214" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".215" = zext i32 64 to i64
  %".216" = zext i32 24 to i64
  %".217" = shl i64 %".214", %".216"
  %".218" = and i64 %".217", 4294967295
  %".219" = add i64 %".218", %".215"
  %".220" = trunc i64 %".219" to i32
  %"tmem_alloc_winoff.4" = and i32 3084, 16777215
  %".221" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.4"
  %".222" = bitcast i8 addrspace(3)* %".221" to i32 addrspace(3)*
  %".223" = load i32, i32 addrspace(3)* %".222"
  %".224" = lshr i32 %".223", 5
  %"P55_to_i32" = zext i1 1 to i32
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.16", %".224"
  %"bra_cond_trunc.4" = trunc i32 %"P55_to_i32" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  br i1 %"bra_cond_to_i1.4", label %"BB_0a10", label %"BB_09b0"
BB_09b0:
  %"tmem_alloc_winoff.5" = and i32 3084, 16777215
  %".226" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.5"
  %".227" = bitcast i8 addrspace(3)* %".226" to i32 addrspace(3)*
  %".228" = load i32, i32 addrspace(3)* %".227"
  %".229" = lshr i32 %".228", 5
  %"P58_to_i32" = zext i1 1 to i32
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.17", %".229"
  %"bra_cond_trunc.5" = trunc i32 %"P58_to_i32" to i1
  %"bra_cond_not.2" = xor i1 %"bra_cond_trunc.5", -1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_not.2" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  br i1 %"bra_cond_to_i1.5", label %"BB_09b0", label %"BB_0a10"
BB_0a10:
  %"phi.11" = phi  i32 [%"imad.17", %"BB_0920"], [%"imad.18", %"BB_09b0"]
  %".231" = zext i32 %"imad.16" to i64
  %".232" = zext i32 0 to i64
  %".233" = shl i64 %".232", 32
  %"shf_concat.6" = or i64 %".231", %".233"
  %"shf_shift_64.6" = zext i32 %"phi.11" to i64
  %".234" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".234" to i32
  %"imad_tmp.18" = mul i32 %"phi.11", 32
  %"imad.19" = add i32 %"imad_tmp.18", 0
  %"atoms_addr_memaddr_offset_add.6" = add i32 %".220", 20
  %"atoms_shared_addr_winoff.6" = and i32 %"atoms_addr_memaddr_offset_add.6", 16777215
  %".235" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.6"
  %"atoms_ptr.6" = bitcast i8 addrspace(3)* %".235" to i32 addrspace(3)*
  %"atoms_or.4" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.6", i32 %"shf_result.6" monotonic
  %"atoms_addr_memaddr_offset_add.7" = add i32 %".220", 24
  %"atoms_shared_addr_winoff.7" = and i32 %"atoms_addr_memaddr_offset_add.7", 16777215
  %".236" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.7"
  %"atoms_ptr.7" = bitcast i8 addrspace(3)* %".236" to i32 addrspace(3)*
  %"atoms_or.5" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.7", i32 %"shf_result.6" monotonic
  %"sts_addr_memaddr_offset_add.2" = add i32 %".16", 2060
  %"sts_shared_addr_winoff.4" = and i32 %"sts_addr_memaddr_offset_add.2", 16777215
  %".237" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".237" to i32 addrspace(3)*
  store volatile i32 %"imad.19", i32 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_0a60"
BB_0a60:
  %"allocation_slot_winoff.3" = and i32 3088, 16777215
  %".240" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.3"
  %".241" = ptrtoint i8 addrspace(3)* %".240" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".241", i32 64) convergent
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P32_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0a90"
BB_0a90:
  %"cond_trunc.13" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0c00", label %"BB_0aa0"
BB_0aa0:
  %"s2ur_cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.19", 3
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.20", 1
  %".245" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".246" = zext i32 64 to i64
  %".247" = zext i32 24 to i64
  %".248" = shl i64 %".245", %".247"
  %".249" = and i64 %".248", 4294967295
  %".250" = add i64 %".249", %".246"
  %".251" = trunc i64 %".250" to i32
  %"tmem_alloc_winoff.6" = and i32 3088, 16777215
  %".252" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.6"
  %".253" = bitcast i8 addrspace(3)* %".252" to i32 addrspace(3)*
  %".254" = load i32, i32 addrspace(3)* %".253"
  %".255" = lshr i32 %".254", 5
  %"P59_to_i32" = zext i1 1 to i32
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.21", %".255"
  %"bra_cond_trunc.6" = trunc i32 %"P59_to_i32" to i1
  %"bra_cond_to_i32.6" = zext i1 %"bra_cond_trunc.6" to i32
  %"bra_cond_to_i1.6" = icmp ne i32 %"bra_cond_to_i32.6", 0
  br i1 %"bra_cond_to_i1.6", label %"BB_0ba0", label %"BB_0b40"
BB_0b40:
  %"tmem_alloc_winoff.7" = and i32 3088, 16777215
  %".257" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.7"
  %".258" = bitcast i8 addrspace(3)* %".257" to i32 addrspace(3)*
  %".259" = load i32, i32 addrspace(3)* %".258"
  %".260" = lshr i32 %".259", 5
  %"P62_to_i32" = zext i1 1 to i32
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.22", %".260"
  %"bra_cond_trunc.7" = trunc i32 %"P62_to_i32" to i1
  %"bra_cond_not.3" = xor i1 %"bra_cond_trunc.7", -1
  %"bra_cond_to_i32.7" = zext i1 %"bra_cond_not.3" to i32
  %"bra_cond_to_i1.7" = icmp ne i32 %"bra_cond_to_i32.7", 0
  br i1 %"bra_cond_to_i1.7", label %"BB_0b40", label %"BB_0ba0"
BB_0ba0:
  %"phi.12" = phi  i32 [%"imad.22", %"BB_0aa0"], [%"imad.23", %"BB_0b40"]
  %".262" = zext i32 %"imad.20" to i64
  %".263" = zext i32 0 to i64
  %".264" = shl i64 %".263", 32
  %"shf_concat.7" = or i64 %".262", %".264"
  %"shf_shift_64.7" = zext i32 %"phi.12" to i64
  %".265" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".265" to i32
  %".266" = zext i32 %"imad.21" to i64
  %".267" = zext i32 0 to i64
  %".268" = shl i64 %".267", 32
  %"shf_concat.8" = or i64 %".266", %".268"
  %"shf_shift_64.8" = zext i32 %"phi.12" to i64
  %".269" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".269" to i32
  %"imad_tmp.23" = mul i32 %"phi.12", 32
  %"imad.24" = add i32 %"imad_tmp.23", 0
  %"atoms_addr_memaddr_offset_add.8" = add i32 %".251", 20
  %"atoms_shared_addr_winoff.8" = and i32 %"atoms_addr_memaddr_offset_add.8", 16777215
  %".270" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.8"
  %"atoms_ptr.8" = bitcast i8 addrspace(3)* %".270" to i32 addrspace(3)*
  %"atoms_or.6" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.8", i32 %"shf_result.7" monotonic
  %"atoms_addr_memaddr_offset_add.9" = add i32 %".251", 24
  %"atoms_shared_addr_winoff.9" = and i32 %"atoms_addr_memaddr_offset_add.9", 16777215
  %".271" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.9"
  %"atoms_ptr.9" = bitcast i8 addrspace(3)* %".271" to i32 addrspace(3)*
  %"atoms_or.7" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.9", i32 %"shf_result.8" monotonic
  %"sts_addr_memaddr_offset_add.3" = add i32 %".16", 2064
  %"sts_shared_addr_winoff.5" = and i32 %"sts_addr_memaddr_offset_add.3", 16777215
  %".272" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".272" to i32 addrspace(3)*
  store volatile i32 %"imad.24", i32 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_0c00"
BB_0c00:
  %"allocation_slot_winoff.4" = and i32 3092, 16777215
  %".275" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.4"
  %".276" = ptrtoint i8 addrspace(3)* %".275" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".276", i32 128) convergent
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P63_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0c30"
BB_0c30:
  %"cond_trunc.14" = trunc i32 %"P63_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0da0", label %"BB_0c40"
BB_0c40:
  %"s2ur_cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.24", 15
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.25", 1
  %".280" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".281" = zext i32 64 to i64
  %".282" = zext i32 24 to i64
  %".283" = shl i64 %".280", %".282"
  %".284" = and i64 %".283", 4294967295
  %".285" = add i64 %".284", %".281"
  %".286" = trunc i64 %".285" to i32
  %"tmem_alloc_winoff.8" = and i32 3092, 16777215
  %".287" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.8"
  %".288" = bitcast i8 addrspace(3)* %".287" to i32 addrspace(3)*
  %".289" = load i32, i32 addrspace(3)* %".288"
  %".290" = lshr i32 %".289", 5
  %"P64_to_i32" = zext i1 1 to i32
  %"imad_tmp.26" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.26", %".290"
  %"bra_cond_trunc.8" = trunc i32 %"P64_to_i32" to i1
  %"bra_cond_to_i32.8" = zext i1 %"bra_cond_trunc.8" to i32
  %"bra_cond_to_i1.8" = icmp ne i32 %"bra_cond_to_i32.8", 0
  br i1 %"bra_cond_to_i1.8", label %"BB_0d40", label %"BB_0ce0"
BB_0ce0:
  %"tmem_alloc_winoff.9" = and i32 3092, 16777215
  %".292" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.9"
  %".293" = bitcast i8 addrspace(3)* %".292" to i32 addrspace(3)*
  %".294" = load i32, i32 addrspace(3)* %".293"
  %".295" = lshr i32 %".294", 5
  %"P65_to_i32" = zext i1 1 to i32
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.28" = add i32 %"imad_tmp.27", %".295"
  %"bra_cond_trunc.9" = trunc i32 %"P65_to_i32" to i1
  %"bra_cond_not.4" = xor i1 %"bra_cond_trunc.9", -1
  %"bra_cond_to_i32.9" = zext i1 %"bra_cond_not.4" to i32
  %"bra_cond_to_i1.9" = icmp ne i32 %"bra_cond_to_i32.9", 0
  br i1 %"bra_cond_to_i1.9", label %"BB_0ce0", label %"BB_0d40"
BB_0d40:
  %"phi.13" = phi  i32 [%"imad.27", %"BB_0c40"], [%"imad.28", %"BB_0ce0"]
  %".297" = zext i32 %"imad.25" to i64
  %".298" = zext i32 0 to i64
  %".299" = shl i64 %".298", 32
  %"shf_concat.9" = or i64 %".297", %".299"
  %"shf_shift_64.9" = zext i32 %"phi.13" to i64
  %".300" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".300" to i32
  %".301" = zext i32 %"imad.26" to i64
  %".302" = zext i32 0 to i64
  %".303" = shl i64 %".302", 32
  %"shf_concat.10" = or i64 %".301", %".303"
  %"shf_shift_64.10" = zext i32 %"phi.13" to i64
  %".304" = shl i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_result.10" = trunc i64 %".304" to i32
  %"imad_tmp.28" = mul i32 %"phi.13", 32
  %"imad.29" = add i32 %"imad_tmp.28", 0
  %"atoms_addr_memaddr_offset_add.10" = add i32 %".286", 20
  %"atoms_shared_addr_winoff.10" = and i32 %"atoms_addr_memaddr_offset_add.10", 16777215
  %".305" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.10"
  %"atoms_ptr.10" = bitcast i8 addrspace(3)* %".305" to i32 addrspace(3)*
  %"atoms_or.8" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.10", i32 %"shf_result.9" monotonic
  %"atoms_addr_memaddr_offset_add.11" = add i32 %".286", 24
  %"atoms_shared_addr_winoff.11" = and i32 %"atoms_addr_memaddr_offset_add.11", 16777215
  %".306" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.11"
  %"atoms_ptr.11" = bitcast i8 addrspace(3)* %".306" to i32 addrspace(3)*
  %"atoms_or.9" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.11", i32 %"shf_result.10" monotonic
  %"sts_addr_memaddr_offset_add.4" = add i32 %".16", 2068
  %"sts_shared_addr_winoff.6" = and i32 %"sts_addr_memaddr_offset_add.4", 16777215
  %".307" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".307" to i32 addrspace(3)*
  store volatile i32 %"imad.29", i32 addrspace(3)* %"sts_shared_addr_cast.6"
  br label %"BB_0da0"
BB_0da0:
  %"allocation_slot_winoff.5" = and i32 3096, 16777215
  %".310" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.5"
  %".311" = ptrtoint i8 addrspace(3)* %".310" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".311", i32 256) convergent
  %"elect_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"election.5" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.5")
  %"elect_p.5" = extractvalue {i32, i1} %"election.5", 1
  %"P70_to_i32" = zext i1 %"elect_p.5" to i32
  br label %"BB_0dd0"
BB_0dd0:
  %"cond_trunc.15" = trunc i32 %"P70_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0f50", label %"BB_0de0"
BB_0de0:
  %"s2ur_cluster_ctarank.5" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.29", 255
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.30", 1
  %".315" = zext i32 %"s2ur_cluster_ctarank.5" to i64
  %".316" = zext i32 64 to i64
  %".317" = zext i32 24 to i64
  %".318" = shl i64 %".315", %".317"
  %".319" = and i64 %".318", 4294967295
  %".320" = add i64 %".319", %".316"
  %".321" = trunc i64 %".320" to i32
  %"tmem_alloc_winoff.10" = and i32 3096, 16777215
  %".322" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.10"
  %".323" = bitcast i8 addrspace(3)* %".322" to i32 addrspace(3)*
  %".324" = load i32, i32 addrspace(3)* %".323"
  %".325" = lshr i32 %".324", 5
  %"P66_to_i32" = zext i1 1 to i32
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.31", %".325"
  %"bra_cond_trunc.10" = trunc i32 %"P66_to_i32" to i1
  %"bra_cond_to_i32.10" = zext i1 %"bra_cond_trunc.10" to i32
  %"bra_cond_to_i1.10" = icmp ne i32 %"bra_cond_to_i32.10", 0
  br i1 %"bra_cond_to_i1.10", label %"BB_0ee0", label %"BB_0e80"
BB_0e80:
  %"tmem_alloc_winoff.11" = and i32 3096, 16777215
  %".327" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.11"
  %".328" = bitcast i8 addrspace(3)* %".327" to i32 addrspace(3)*
  %".329" = load i32, i32 addrspace(3)* %".328"
  %".330" = lshr i32 %".329", 5
  %"P69_to_i32" = zext i1 1 to i32
  %"imad_tmp.32" = mul i32 0, 0
  %"imad.33" = add i32 %"imad_tmp.32", %".330"
  %"bra_cond_trunc.11" = trunc i32 %"P69_to_i32" to i1
  %"bra_cond_not.5" = xor i1 %"bra_cond_trunc.11", -1
  %"bra_cond_to_i32.11" = zext i1 %"bra_cond_not.5" to i32
  %"bra_cond_to_i1.11" = icmp ne i32 %"bra_cond_to_i32.11", 0
  br i1 %"bra_cond_to_i1.11", label %"BB_0e80", label %"BB_0ee0"
BB_0ee0:
  %"phi.14" = phi  i32 [%"imad.32", %"BB_0de0"], [%"imad.33", %"BB_0e80"]
  %".332" = zext i32 %"imad.30" to i64
  %".333" = zext i32 0 to i64
  %".334" = shl i64 %".333", 32
  %"shf_concat.11" = or i64 %".332", %".334"
  %"shf_shift_64.11" = zext i32 %"phi.14" to i64
  %".335" = shl i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_result.11" = trunc i64 %".335" to i32
  %".336" = zext i32 %"imad.31" to i64
  %".337" = zext i32 0 to i64
  %".338" = shl i64 %".337", 32
  %"shf_concat.12" = or i64 %".336", %".338"
  %"shf_shift_64.12" = zext i32 %"phi.14" to i64
  %".339" = shl i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_result.12" = trunc i64 %".339" to i32
  %"imad_tmp.33" = mul i32 %"phi.14", 32
  %"imad.34" = add i32 %"imad_tmp.33", 0
  %"atoms_addr_memaddr_offset_add.12" = add i32 %".321", 20
  %"atoms_shared_addr_winoff.12" = and i32 %"atoms_addr_memaddr_offset_add.12", 16777215
  %".340" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.12"
  %"atoms_ptr.12" = bitcast i8 addrspace(3)* %".340" to i32 addrspace(3)*
  %"atoms_or.10" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.12", i32 %"shf_result.11" monotonic
  %"atoms_addr_memaddr_offset_add.13" = add i32 %".321", 24
  %"atoms_shared_addr_winoff.13" = and i32 %"atoms_addr_memaddr_offset_add.13", 16777215
  %".341" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.13"
  %"atoms_ptr.13" = bitcast i8 addrspace(3)* %".341" to i32 addrspace(3)*
  %"atoms_or.11" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.13", i32 %"shf_result.12" monotonic
  %"sts_addr_memaddr_offset_add.5" = add i32 %".16", 2072
  %"sts_shared_addr_winoff.7" = and i32 %"sts_addr_memaddr_offset_add.5", 16777215
  %".342" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.7"
  %"sts_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".342" to i32 addrspace(3)*
  store volatile i32 %"imad.34", i32 addrspace(3)* %"sts_shared_addr_cast.7"
  br label %"BB_0f50"
BB_0f50:
  %"isetrp_cmp1.9" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P74_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %".345" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".346" = bitcast i8* %".345" to i64*
  %"ldc_const.2" = load i64, i64* %".346"
  %"R27:R26_r0" = trunc i64 %"ldc_const.2" to i32
  %"R27:R26_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R27:R26_r1" = trunc i64 %"R27:R26_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.34" = mul i32 %"tid_x", 18
  %"imad.35" = add i32 %"imad_tmp.34", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R27:R26_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R27:R26_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.35" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.36" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R27:R26_r0.1" = trunc i64 %"imad.36" to i32
  %"R27:R26_r1_shift.1" = lshr i64 %"imad.36", 32
  %"R27:R26_r1.1" = trunc i64 %"R27:R26_r1_shift.1" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".347" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".347" to i64 addrspace(3)*
  %"lds.3" = load volatile i64, i64 addrspace(3)* %"lds_shared_addr_cast.3"
  %"R13:R12_r0" = trunc i64 %"lds.3" to i32
  %"R13:R12_r1_shift" = lshr i64 %"lds.3", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R358:R354_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R358:R354_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R358:R354_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R358:R354_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R358:R354_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R358:R354_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R358:R354_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R358:R354_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.7"
  %"imad_tmp.35" = mul i32 %"tid_x", 65536
  %"imad.37" = add i32 %"imad_tmp.35", 0
  %".348" = xor i32 %"imad.37", -1
  %".349" = xor i32 65011712, -1
  %".350" = xor i32 0, -1
  %".351" = and i32 %"imad.37", 65011712
  %".352" = and i32 %".351", %".350"
  %".353" = and i32 %"imad.37", 65011712
  %".354" = and i32 %".353", 0
  %".355" = or i32 %".352", %".354"
  %"imad_tmp.36" = mul i32 %"R13:R12_r1", 1
  %"imad.38" = add i32 %"imad_tmp.36", %".355"
  %"sttm_memaddr_offset_add" = add i32 %"imad.38", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.38", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R358:R354_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R358:R354_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R358:R354_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R358:R354_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R358:R354_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R358:R354_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R358:R354_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R358:R354_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.15"
  %"imad_addend_neg" = sub i32 0, %"R13:R12_r0"
  %"imad_tmp.37" = mul i32 %"R13:R12_r1", 1
  %"imad.39" = add i32 %"imad_tmp.37", %"imad_addend_neg"
  %"imad_tmp.38" = mul i32 %".355", 1
  %"imad.40" = add i32 %"imad_tmp.38", %"R13:R12_r0"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.38", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.38", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_11f0"
BB_11f0:
  %"cond_trunc.16" = trunc i32 %"P74_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1570", label %"BB_1200"
BB_1200:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".365" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".365" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"s2ur_cluster_ctarank.6" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".366" = zext i32 0 to i64
  %".367" = zext i32 %".16" to i64
  %".368" = shl i64 %".367", 32
  %"shf_concat.13" = or i64 %".366", %".368"
  %"shf_shift_64.13" = zext i32 4 to i64
  %".369" = lshr i64 %"shf_concat.13", %"shf_shift_64.13"
  %"shf_hi.1" = lshr i64 %".369", 32
  %"shf_result.13" = trunc i64 %"shf_hi.1" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".370" = xor i32 %"plop3_a_bit", 1
  %".371" = xor i32 %"plop3_b_bit", 1
  %".372" = xor i32 %"plop3_c_bit", 1
  %".373" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".374" = and i32 %".373", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".374", 0
  %"P75_to_i32" = zext i1 %"plop3_pred" to i32
  %".375" = xor i32 %"shf_result.13", -1
  %".376" = xor i32 16376, -1
  %".377" = xor i32 0, -1
  %".378" = and i32 %"shf_result.13", 16376
  %".379" = and i32 %".378", %".377"
  %".380" = and i32 %"shf_result.13", 16376
  %".381" = and i32 %".380", 0
  %".382" = or i32 %".379", %".381"
  %".383" = xor i32 %".382", -1
  %".384" = xor i32 524288, -1
  %".385" = xor i32 0, -1
  %".386" = and i32 %".383", 524288
  %".387" = and i32 %".386", %".385"
  %".388" = and i32 %".383", 524288
  %".389" = and i32 %".388", 0
  %".390" = or i32 %".387", %".389"
  %".391" = and i32 %".382", %".384"
  %".392" = and i32 %".391", %".385"
  %".393" = or i32 %".390", %".392"
  %".394" = and i32 %".382", %".384"
  %".395" = and i32 %".394", 0
  %".396" = or i32 %".393", %".395"
  %".397" = and i32 %".382", 524288
  %".398" = and i32 %".397", %".385"
  %".399" = or i32 %".396", %".398"
  %".400" = and i32 %".382", 524288
  %".401" = and i32 %".400", 0
  %".402" = or i32 %".399", %".401"
  %".403" = zext i32 %"s2ur_cluster_ctarank.6" to i64
  %".404" = zext i32 %"iadd3_n2.3" to i64
  %".405" = zext i32 24 to i64
  %".406" = shl i64 %".403", %".405"
  %".407" = and i64 %".406", 4294967295
  %".408" = add i64 %".407", %".404"
  %".409" = trunc i64 %".408" to i32
  %".410" = zext i32 0 to i64
  %".411" = zext i32 %".409" to i64
  %".412" = shl i64 %".411", 32
  %"shf_concat.14" = or i64 %".410", %".412"
  %"shf_shift_64.14" = zext i32 4 to i64
  %".413" = lshr i64 %"shf_concat.14", %"shf_shift_64.14"
  %"shf_hi.2" = lshr i64 %".413", 32
  %"shf_result.14" = trunc i64 %"shf_hi.2" to i32
  %".414" = xor i32 %"shf_result.14", -1
  %".415" = xor i32 16376, -1
  %".416" = xor i32 0, -1
  %".417" = and i32 %"shf_result.14", 16376
  %".418" = and i32 %".417", %".416"
  %".419" = and i32 %"shf_result.14", 16376
  %".420" = and i32 %".419", 0
  %".421" = or i32 %".418", %".420"
  %".422" = xor i32 %".421", -1
  %".423" = xor i32 524288, -1
  %".424" = xor i32 0, -1
  %".425" = and i32 %".422", 524288
  %".426" = and i32 %".425", %".424"
  %".427" = and i32 %".422", 524288
  %".428" = and i32 %".427", 0
  %".429" = or i32 %".426", %".428"
  %".430" = and i32 %".421", %".423"
  %".431" = and i32 %".430", %".424"
  %".432" = or i32 %".429", %".431"
  %".433" = and i32 %".421", %".423"
  %".434" = and i32 %".433", 0
  %".435" = or i32 %".432", %".434"
  %".436" = and i32 %".421", 524288
  %".437" = and i32 %".436", %".424"
  %".438" = or i32 %".435", %".437"
  %".439" = and i32 %".421", 524288
  %".440" = and i32 %".439", 0
  %".441" = or i32 %".438", %".440"
  %"iadd3_n1.4" = add i32 %"imad.39", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", %"lds.4"
  br label %"BB_1320"
BB_1320:
  %"phi.15" = phi  i32 [%"P38_to_i32", %"BB_1200"], [%"P24_to_i32", %"BB_1350"]
  %"phi.16" = phi  i32 [%"P75_to_i32", %"BB_1200"], [%"phi.18", %"BB_1350"]
  %"cond_trunc.17" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001320", label %"BB_1330"
BB_80001320:
  %"elect_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"election.6" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.6")
  %"elect_p.6" = extractvalue {i32, i1} %"election.6", 1
  %"P91_to_i32" = zext i1 %"elect_p.6" to i32
  br label %"BB_1330"
BB_1330:
  %"phi.17" = phi  i32 [%"P91_to_i32", %"BB_80001320"], [%"phi.15", %"BB_1320"]
  %"mma_b_r0_ext" = zext i32 %".441" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".445" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".446" = sub i64 %".445", 0
  %".447" = lshr i64 %".446", 4
  %".448" = add i64 %"mma_b_packed_1", %".447"
  %".449" = and i64 %".448", 16383
  %".450" = and i64 %"mma_b_packed_1", -16384
  %".451" = or i64 %".450", %".449"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.4", i32 %"iadd3_n2.4", i64 %".451", i32 134747536, i32 %"mma_arg_zext")
  br label %"BB_1340"
BB_1340:
  %"cond_trunc.18" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80001340", label %"BB_1350"
BB_80001340:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".455" = xor i32 %"plop3_a_bit.1", 1
  %".456" = xor i32 %"plop3_b_bit.1", 1
  %".457" = xor i32 %"plop3_c_bit.1", 1
  %".458" = and i32 %".455", %"plop3_b_bit.1"
  %".459" = and i32 %".458", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".459", 0
  %"P77_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_1350"
BB_1350:
  %"phi.18" = phi  i32 [%"P77_to_i32", %"BB_80001340"], [%"phi.16", %"BB_1340"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".461" = xor i32 %"plop3_a_bit.2", 1
  %".462" = xor i32 %"plop3_b_bit.2", 1
  %".463" = xor i32 %"plop3_c_bit.2", 1
  %".464" = and i32 %".461", %"plop3_b_bit.2"
  %".465" = and i32 %".464", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".465", 0
  %"P24_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.12" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.12" = zext i1 %"bra_cond_trunc.12" to i32
  %"bra_cond_to_i1.12" = icmp ne i32 %"bra_cond_to_i32.12", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.12")
  br i1 %"branch_any", label %"BB_1320", label %"BB_1370"
BB_1370:
  %"lds_addr_memaddr_offset_add.5" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".467" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".467" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".468" = xor i32 %"plop3_a_bit.3", 1
  %".469" = xor i32 %"plop3_b_bit.3", 1
  %".470" = xor i32 %"plop3_c_bit.3", 1
  %".471" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".472" = and i32 %".471", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".472", 0
  %"P82_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"iadd3_n1.5" = add i32 %"imad.39", %"lds.5"
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"iadd3_n2.5", 16
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"iadd3_n2.5", 4
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  br label %"BB_13f0"
BB_13f0:
  %"phi.19" = phi  i32 [%"P24_to_i32", %"BB_1370"], [%"P50_to_i32", %"BB_1420"]
  %"phi.20" = phi  i32 [%"P82_to_i32", %"BB_1370"], [%"phi.22", %"BB_1420"]
  %"cond_trunc.19" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_800013f0", label %"BB_1400"
BB_800013f0:
  %"elect_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"election.7" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.7")
  %"elect_p.7" = extractvalue {i32, i1} %"election.7", 1
  %"P48_to_i32" = zext i1 %"elect_p.7" to i32
  br label %"BB_1400"
BB_1400:
  %"phi.21" = phi  i32 [%"P48_to_i32", %"BB_800013f0"], [%"phi.19", %"BB_13f0"]
  %"mma_b_r0_ext.1" = zext i32 %".402" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".476" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".477" = sub i64 %".476", 0
  %".478" = lshr i64 %".477", 4
  %".479" = add i64 %"mma_b_packed_1.1", %".478"
  %".480" = and i64 %".479", 16383
  %".481" = and i64 %"mma_b_packed_1.1", -16384
  %".482" = or i64 %".481", %".480"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.5", i32 %"iadd3_n2.6", i64 %".482", i32 679744944, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.7")
  br label %"BB_1410"
BB_1410:
  %"cond_trunc.20" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80001410", label %"BB_1420"
BB_80001410:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".486" = xor i32 %"plop3_a_bit.4", 1
  %".487" = xor i32 %"plop3_b_bit.4", 1
  %".488" = xor i32 %"plop3_c_bit.4", 1
  %".489" = and i32 %".486", %"plop3_b_bit.4"
  %".490" = and i32 %".489", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".490", 0
  %"P84_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_1420"
BB_1420:
  %"phi.22" = phi  i32 [%"P84_to_i32", %"BB_80001410"], [%"phi.20", %"BB_1410"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".492" = xor i32 %"plop3_a_bit.5", 1
  %".493" = xor i32 %"plop3_b_bit.5", 1
  %".494" = xor i32 %"plop3_c_bit.5", 1
  %".495" = and i32 %".492", %"plop3_b_bit.5"
  %".496" = and i32 %".495", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".496", 0
  %"P50_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.13" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.13" = zext i1 %"bra_cond_trunc.13" to i32
  %"bra_cond_to_i1.13" = icmp ne i32 %"bra_cond_to_i32.13", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.13")
  br i1 %"branch_any.1", label %"BB_13f0", label %"BB_1440"
BB_1440:
  %"lds_addr_memaddr_offset_add.6" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".498" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".498" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".499" = xor i32 %"plop3_a_bit.6", 1
  %".500" = xor i32 %"plop3_b_bit.6", 1
  %".501" = xor i32 %"plop3_c_bit.6", 1
  %".502" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".503" = and i32 %".502", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".503", 0
  %"P86_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"iadd3_n1.8" = add i32 %"imad.39", %"lds.6"
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"iadd3_n2.8", 16
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"iadd3_n1.10" = add i32 %"iadd3_n2.8", 4
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  br label %"BB_14a0"
BB_14a0:
  %"phi.23" = phi  i32 [%"P50_to_i32", %"BB_1440"], [%"P43_to_i32", %"BB_14d0"]
  %"phi.24" = phi  i32 [%"P86_to_i32", %"BB_1440"], [%"phi.26", %"BB_14d0"]
  %"cond_trunc.21" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_800014a0", label %"BB_14b0"
BB_800014a0:
  %"elect_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"election.8" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.8")
  %"elect_p.8" = extractvalue {i32, i1} %"election.8", 1
  %"P41_to_i32" = zext i1 %"elect_p.8" to i32
  br label %"BB_14b0"
BB_14b0:
  %"phi.25" = phi  i32 [%"P41_to_i32", %"BB_800014a0"], [%"phi.23", %"BB_14a0"]
  %"mma_b_r0_ext.2" = zext i32 %".402" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".507" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".508" = sub i64 %".507", 0
  %".509" = lshr i64 %".508", 4
  %".510" = add i64 %"mma_b_packed_1.2", %".509"
  %".511" = and i64 %".510", 16383
  %".512" = and i64 %"mma_b_packed_1.2", -16384
  %".513" = or i64 %".512", %".511"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.6", i32 %"iadd3_n2.9", i64 %".513", i32 679744944, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.8", i32 %"iadd3_n2.10")
  br label %"BB_14c0"
BB_14c0:
  %"cond_trunc.22" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_800014c0", label %"BB_14d0"
BB_800014c0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".517" = xor i32 %"plop3_a_bit.7", 1
  %".518" = xor i32 %"plop3_b_bit.7", 1
  %".519" = xor i32 %"plop3_c_bit.7", 1
  %".520" = and i32 %".517", %"plop3_b_bit.7"
  %".521" = and i32 %".520", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".521", 0
  %"P88_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_14d0"
BB_14d0:
  %"phi.26" = phi  i32 [%"P88_to_i32", %"BB_800014c0"], [%"phi.24", %"BB_14c0"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".523" = xor i32 %"plop3_a_bit.8", 1
  %".524" = xor i32 %"plop3_b_bit.8", 1
  %".525" = xor i32 %"plop3_c_bit.8", 1
  %".526" = and i32 %".523", %"plop3_b_bit.8"
  %".527" = and i32 %".526", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".527", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.14" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.14" = zext i1 %"bra_cond_trunc.14" to i32
  %"bra_cond_to_i1.14" = icmp ne i32 %"bra_cond_to_i32.14", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.14")
  br i1 %"branch_any.2", label %"BB_14a0", label %"BB_14f0"
BB_14f0:
  %"iadd3_n1.11" = add i32 1024, 2048
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".529" = xor i32 %"plop3_a_bit.9", 1
  %".530" = xor i32 %"plop3_b_bit.9", 1
  %".531" = xor i32 %"plop3_c_bit.9", 1
  %".532" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".533" = and i32 %".532", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".533", 0
  %"P93_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".534" = zext i32 %"s2ur_cluster_ctarank.6" to i64
  %".535" = zext i32 %"iadd3_n2.11" to i64
  %".536" = zext i32 24 to i64
  %".537" = shl i64 %".534", %".536"
  %".538" = and i64 %".537", 4294967295
  %".539" = add i64 %".538", %".535"
  %".540" = trunc i64 %".539" to i32
  br label %"BB_1520"
BB_1520:
  %"phi.27" = phi  i32 [%"P43_to_i32", %"BB_14f0"], [%"P60_to_i32", %"BB_1550"]
  %"phi.28" = phi  i32 [%"P93_to_i32", %"BB_14f0"], [%"phi.30", %"BB_1550"]
  %"cond_trunc.23" = trunc i32 %"phi.28" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80001520", label %"BB_1530"
BB_80001520:
  %"elect_mask.9" = call i32 @"llvm.nvvm.activemask"()
  %"election.9" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.9")
  %"elect_p.9" = extractvalue {i32, i1} %"election.9", 1
  %"P46_to_i32" = zext i1 %"elect_p.9" to i32
  br label %"BB_1530"
BB_1530:
  %"phi.29" = phi  i32 [%"P46_to_i32", %"BB_80001520"], [%"phi.27", %"BB_1520"]
  %"utcbar_local_winoff" = and i32 %".540", 16777215
  %".544" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".545" = ptrtoint i8 addrspace(3)* %".544" to i32
  %".546" = lshr i32 %".540", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".545", i32 %".546")
  br label %"BB_1540"
BB_1540:
  %"cond_trunc.24" = trunc i32 %"phi.29" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80001540", label %"BB_1550"
BB_80001540:
  %"lop3_a_trunc.3" = trunc i32 %"phi.29" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".550" = xor i32 %"plop3_a_bit.10", 1
  %".551" = xor i32 %"plop3_b_bit.10", 1
  %".552" = xor i32 %"plop3_c_bit.10", 1
  %".553" = and i32 %".550", %"plop3_b_bit.10"
  %".554" = and i32 %".553", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".554", 0
  %"P95_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_1550"
BB_1550:
  %"phi.30" = phi  i32 [%"P95_to_i32", %"BB_80001540"], [%"phi.28", %"BB_1540"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".556" = xor i32 %"plop3_a_bit.11", 1
  %".557" = xor i32 %"plop3_b_bit.11", 1
  %".558" = xor i32 %"plop3_c_bit.11", 1
  %".559" = and i32 %".556", %"plop3_b_bit.11"
  %".560" = and i32 %".559", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".560", 0
  %"P60_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.15" = trunc i32 %"phi.30" to i1
  %"bra_cond_to_i32.15" = zext i1 %"bra_cond_trunc.15" to i32
  %"bra_cond_to_i1.15" = icmp ne i32 %"bra_cond_to_i32.15", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.15")
  br i1 %"branch_any.3", label %"BB_1520", label %"BB_1570"
BB_1570:
  %"isetrp_cmp1.10" = icmp uge i32 %"tid_x", 32
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P72_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"lop3_a_cast_zext.12" = zext i1 1 to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".562" = xor i32 %"plop3_a_bit.12", 1
  %".563" = xor i32 %"plop3_b_bit.12", 1
  %".564" = xor i32 %"plop3_c_bit.12", 1
  %".565" = and i32 %"plop3_a_bit.12", %"plop3_b_bit.12"
  %".566" = and i32 %".565", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".566", 0
  %"P98_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_15b0"
BB_15b0:
  %"cond_trunc.25" = trunc i32 %"P72_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.25", -1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_19f0", label %"BB_15c0"
BB_15c0:
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".569" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".570" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".571" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".572" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldg_addr_r0_ext.18" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9220
  %"R358:R354_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.16"
  %"ldg_addr_r0_ext.19" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.19" = or i64 0, %"ldg_addr_r0_ext.19"
  %"ldg_addr_r1_ext.19" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.19" = shl i64 %"ldg_addr_r1_ext.19", 32
  %"ldg_addr_packed_1.19" = or i64 %"ldg_addr_packed_0.19", %"ldg_addr_r1_shift.19"
  %"ldg_addr_memaddr_offset_add.18" = add i64 %"ldg_addr_packed_1.19", 9216
  %"R358:R354_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  %"ldg.19" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.17"
  %"ldg_addr_r0_ext.20" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.20" = or i64 0, %"ldg_addr_r0_ext.20"
  %"ldg_addr_r1_ext.20" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.20" = shl i64 %"ldg_addr_r1_ext.20", 32
  %"ldg_addr_packed_1.20" = or i64 %"ldg_addr_packed_0.20", %"ldg_addr_r1_shift.20"
  %"ldg_addr_memaddr_offset_add.19" = add i64 %"ldg_addr_packed_1.20", 9224
  %"R358:R354_addr_ptr.18" = inttoptr i64 %"ldg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  %"ldg.20" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.18"
  %"ldg_addr_r0_ext.21" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.21" = or i64 0, %"ldg_addr_r0_ext.21"
  %"ldg_addr_r1_ext.21" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.21" = shl i64 %"ldg_addr_r1_ext.21", 32
  %"ldg_addr_packed_1.21" = or i64 %"ldg_addr_packed_0.21", %"ldg_addr_r1_shift.21"
  %"ldg_addr_memaddr_offset_add.20" = add i64 %"ldg_addr_packed_1.21", 9228
  %"R358:R354_addr_ptr.19" = inttoptr i64 %"ldg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  %"ldg.21" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.19"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.38", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".573" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".574" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".575" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".576" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"ldg_addr_r0_ext.22" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.22" = or i64 0, %"ldg_addr_r0_ext.22"
  %"ldg_addr_r1_ext.22" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.22" = shl i64 %"ldg_addr_r1_ext.22", 32
  %"ldg_addr_packed_1.22" = or i64 %"ldg_addr_packed_0.22", %"ldg_addr_r1_shift.22"
  %"ldg_addr_memaddr_offset_add.21" = add i64 %"ldg_addr_packed_1.22", 9232
  %"R358:R354_addr_ptr.20" = inttoptr i64 %"ldg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  %"ldg.22" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.20"
  %"ldg_addr_r0_ext.23" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.23" = or i64 0, %"ldg_addr_r0_ext.23"
  %"ldg_addr_r1_ext.23" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.23" = shl i64 %"ldg_addr_r1_ext.23", 32
  %"ldg_addr_packed_1.23" = or i64 %"ldg_addr_packed_0.23", %"ldg_addr_r1_shift.23"
  %"ldg_addr_memaddr_offset_add.22" = add i64 %"ldg_addr_packed_1.23", 9236
  %"R358:R354_addr_ptr.21" = inttoptr i64 %"ldg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  %"ldg.23" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.21"
  %"ldg_addr_r0_ext.24" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.24" = or i64 0, %"ldg_addr_r0_ext.24"
  %"ldg_addr_r1_ext.24" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.24" = shl i64 %"ldg_addr_r1_ext.24", 32
  %"ldg_addr_packed_1.24" = or i64 %"ldg_addr_packed_0.24", %"ldg_addr_r1_shift.24"
  %"ldg_addr_memaddr_offset_add.23" = add i64 %"ldg_addr_packed_1.24", 9240
  %"R358:R354_addr_ptr.22" = inttoptr i64 %"ldg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  %"ldg.24" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.22"
  %"ldg_addr_r0_ext.25" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.25" = or i64 0, %"ldg_addr_r0_ext.25"
  %"ldg_addr_r1_ext.25" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.25" = shl i64 %"ldg_addr_r1_ext.25", 32
  %"ldg_addr_packed_1.25" = or i64 %"ldg_addr_packed_0.25", %"ldg_addr_r1_shift.25"
  %"ldg_addr_memaddr_offset_add.24" = add i64 %"ldg_addr_packed_1.25", 9244
  %"R358:R354_addr_ptr.23" = inttoptr i64 %"ldg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  %"ldg.25" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.23"
  %"isetrp_cmp1.11" = icmp ne i32 %".570", %"ldg.18"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P99_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".577" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".578" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".579" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".580" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"ldg_addr_r0_ext.26" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.26" = or i64 0, %"ldg_addr_r0_ext.26"
  %"ldg_addr_r1_ext.26" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.26" = shl i64 %"ldg_addr_r1_ext.26", 32
  %"ldg_addr_packed_1.26" = or i64 %"ldg_addr_packed_0.26", %"ldg_addr_r1_shift.26"
  %"ldg_addr_memaddr_offset_add.25" = add i64 %"ldg_addr_packed_1.26", 9216
  %"R358:R354_addr_ptr.24" = inttoptr i64 %"ldg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  %"ldg.26" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.24"
  %"isetrp_src_trunc" = trunc i32 %"P99_to_i32" to i1
  %"isetrp_src_not" = xor i1 %"isetrp_src_trunc", -1
  %"isetrp_cmp1.12" = icmp eq i32 %".569", %"ldg.19"
  %"isetrp_src_to_i32.12" = zext i1 %"isetrp_src_not" to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P101_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"ldg_addr_r0_ext.27" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.27" = or i64 0, %"ldg_addr_r0_ext.27"
  %"ldg_addr_r1_ext.27" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.27" = shl i64 %"ldg_addr_r1_ext.27", 32
  %"ldg_addr_packed_1.27" = or i64 %"ldg_addr_packed_0.27", %"ldg_addr_r1_shift.27"
  %"ldg_addr_memaddr_offset_add.26" = add i64 %"ldg_addr_packed_1.27", 9220
  %"R358:R354_addr_ptr.25" = inttoptr i64 %"ldg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  %"ldg.27" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.25"
  %"isetrp_src_trunc.1" = trunc i32 %"P101_to_i32" to i1
  %"isetrp_cmp1.13" = icmp eq i32 %".571", %"ldg.20"
  %"isetrp_src_to_i32.13" = zext i1 %"isetrp_src_trunc.1" to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P102_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"ldg_addr_r0_ext.28" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.28" = or i64 0, %"ldg_addr_r0_ext.28"
  %"ldg_addr_r1_ext.28" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.28" = shl i64 %"ldg_addr_r1_ext.28", 32
  %"ldg_addr_packed_1.28" = or i64 %"ldg_addr_packed_0.28", %"ldg_addr_r1_shift.28"
  %"ldg_addr_memaddr_offset_add.27" = add i64 %"ldg_addr_packed_1.28", 9224
  %"R358:R354_addr_ptr.26" = inttoptr i64 %"ldg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  %"ldg.28" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.26"
  %"isetrp_src_trunc.2" = trunc i32 %"P102_to_i32" to i1
  %"isetrp_cmp1.14" = icmp eq i32 %".572", %"ldg.21"
  %"isetrp_src_to_i32.14" = zext i1 %"isetrp_src_trunc.2" to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P104_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"ldg_addr_r0_ext.29" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.29" = or i64 0, %"ldg_addr_r0_ext.29"
  %"ldg_addr_r1_ext.29" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.29" = shl i64 %"ldg_addr_r1_ext.29", 32
  %"ldg_addr_packed_1.29" = or i64 %"ldg_addr_packed_0.29", %"ldg_addr_r1_shift.29"
  %"ldg_addr_memaddr_offset_add.28" = add i64 %"ldg_addr_packed_1.29", 9228
  %"R358:R354_addr_ptr.27" = inttoptr i64 %"ldg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  %"ldg.29" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.27"
  %"isetrp_src_trunc.3" = trunc i32 %"P104_to_i32" to i1
  %"isetrp_cmp1.15" = icmp eq i32 %".573", %"ldg.22"
  %"isetrp_src_to_i32.15" = zext i1 %"isetrp_src_trunc.3" to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P105_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.38", 4
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".581" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".582" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".583" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".584" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"ldg_addr_r0_ext.30" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.30" = or i64 0, %"ldg_addr_r0_ext.30"
  %"ldg_addr_r1_ext.30" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.30" = shl i64 %"ldg_addr_r1_ext.30", 32
  %"ldg_addr_packed_1.30" = or i64 %"ldg_addr_packed_0.30", %"ldg_addr_r1_shift.30"
  %"ldg_addr_memaddr_offset_add.29" = add i64 %"ldg_addr_packed_1.30", 9232
  %"R358:R354_addr_ptr.28" = inttoptr i64 %"ldg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  %"ldg.30" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.28"
  %"ldg_addr_r0_ext.31" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.31" = or i64 0, %"ldg_addr_r0_ext.31"
  %"ldg_addr_r1_ext.31" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.31" = shl i64 %"ldg_addr_r1_ext.31", 32
  %"ldg_addr_packed_1.31" = or i64 %"ldg_addr_packed_0.31", %"ldg_addr_r1_shift.31"
  %"ldg_addr_memaddr_offset_add.30" = add i64 %"ldg_addr_packed_1.31", 9236
  %"R358:R354_addr_ptr.29" = inttoptr i64 %"ldg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  %"ldg.31" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.29"
  %"isetrp_src_trunc.4" = trunc i32 %"P105_to_i32" to i1
  %"isetrp_cmp1.16" = icmp eq i32 %".574", %"ldg.23"
  %"isetrp_src_to_i32.16" = zext i1 %"isetrp_src_trunc.4" to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P106_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"ldg_addr_r0_ext.32" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.32" = or i64 0, %"ldg_addr_r0_ext.32"
  %"ldg_addr_r1_ext.32" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.32" = shl i64 %"ldg_addr_r1_ext.32", 32
  %"ldg_addr_packed_1.32" = or i64 %"ldg_addr_packed_0.32", %"ldg_addr_r1_shift.32"
  %"ldg_addr_memaddr_offset_add.31" = add i64 %"ldg_addr_packed_1.32", 9244
  %"R358:R354_addr_ptr.30" = inttoptr i64 %"ldg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  %"ldg.32" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.30"
  %"isetrp_src_trunc.5" = trunc i32 %"P106_to_i32" to i1
  %"isetrp_cmp1.17" = icmp eq i32 %".575", %"ldg.24"
  %"isetrp_src_to_i32.17" = zext i1 %"isetrp_src_trunc.5" to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P107_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"ldg_addr_r0_ext.33" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.33" = or i64 0, %"ldg_addr_r0_ext.33"
  %"ldg_addr_r1_ext.33" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.33" = shl i64 %"ldg_addr_r1_ext.33", 32
  %"ldg_addr_packed_1.33" = or i64 %"ldg_addr_packed_0.33", %"ldg_addr_r1_shift.33"
  %"ldg_addr_memaddr_offset_add.32" = add i64 %"ldg_addr_packed_1.33", 9240
  %"R358:R354_addr_ptr.31" = inttoptr i64 %"ldg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  %"ldg.33" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.31"
  %"isetrp_src_trunc.6" = trunc i32 %"P107_to_i32" to i1
  %"isetrp_cmp1.18" = icmp eq i32 %".576", %"ldg.25"
  %"isetrp_src_to_i32.18" = zext i1 %"isetrp_src_trunc.6" to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P108_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".585" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".586" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".587" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".588" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"ldg_addr_r0_ext.34" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.34" = or i64 0, %"ldg_addr_r0_ext.34"
  %"ldg_addr_r1_ext.34" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.34" = shl i64 %"ldg_addr_r1_ext.34", 32
  %"ldg_addr_packed_1.34" = or i64 %"ldg_addr_packed_0.34", %"ldg_addr_r1_shift.34"
  %"ldg_addr_memaddr_offset_add.33" = add i64 %"ldg_addr_packed_1.34", 9220
  %"R358:R354_addr_ptr.32" = inttoptr i64 %"ldg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  %"ldg.34" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.32"
  %"isetrp_src_trunc.7" = trunc i32 %"P108_to_i32" to i1
  %"isetrp_cmp1.19" = icmp eq i32 %".577", %"ldg.26"
  %"isetrp_src_to_i32.19" = zext i1 %"isetrp_src_trunc.7" to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P110_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"ldg_addr_r0_ext.35" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.35" = or i64 0, %"ldg_addr_r0_ext.35"
  %"ldg_addr_r1_ext.35" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.35" = shl i64 %"ldg_addr_r1_ext.35", 32
  %"ldg_addr_packed_1.35" = or i64 %"ldg_addr_packed_0.35", %"ldg_addr_r1_shift.35"
  %"ldg_addr_memaddr_offset_add.34" = add i64 %"ldg_addr_packed_1.35", 9216
  %"R358:R354_addr_ptr.33" = inttoptr i64 %"ldg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  %"ldg.35" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.33"
  %"isetrp_src_trunc.8" = trunc i32 %"P110_to_i32" to i1
  %"isetrp_cmp1.20" = icmp eq i32 %".578", %"ldg.27"
  %"isetrp_src_to_i32.20" = zext i1 %"isetrp_src_trunc.8" to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  %"isetrp_src_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"isetrp_cmp1.21" = icmp eq i32 %".579", %"ldg.28"
  %"isetrp_src_to_i32.21" = zext i1 %"isetrp_src_trunc.9" to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %"ldg_addr_r0_ext.36" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.36" = or i64 0, %"ldg_addr_r0_ext.36"
  %"ldg_addr_r1_ext.36" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.36" = shl i64 %"ldg_addr_r1_ext.36", 32
  %"ldg_addr_packed_1.36" = or i64 %"ldg_addr_packed_0.36", %"ldg_addr_r1_shift.36"
  %"ldg_addr_memaddr_offset_add.35" = add i64 %"ldg_addr_packed_1.36", 9224
  %"R358:R354_addr_ptr.34" = inttoptr i64 %"ldg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  %"ldg.36" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.34"
  %"isetrp_src_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"isetrp_cmp1.22" = icmp eq i32 %".580", %"ldg.29"
  %"isetrp_src_to_i32.22" = zext i1 %"isetrp_src_trunc.10" to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"ldg_addr_r0_ext.37" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.37" = or i64 0, %"ldg_addr_r0_ext.37"
  %"ldg_addr_r1_ext.37" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.37" = shl i64 %"ldg_addr_r1_ext.37", 32
  %"ldg_addr_packed_1.37" = or i64 %"ldg_addr_packed_0.37", %"ldg_addr_r1_shift.37"
  %"ldg_addr_memaddr_offset_add.36" = add i64 %"ldg_addr_packed_1.37", 9228
  %"R358:R354_addr_ptr.35" = inttoptr i64 %"ldg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  %"ldg.37" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.35"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.38", 4
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".589" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".590" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".591" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".592" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"isetrp_src_trunc.11" = trunc i32 %"P6_to_i32" to i1
  %"isetrp_cmp1.23" = icmp eq i32 %".581", %"ldg.30"
  %"isetrp_src_to_i32.23" = zext i1 %"isetrp_src_trunc.11" to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"ldg_addr_r0_ext.38" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.38" = or i64 0, %"ldg_addr_r0_ext.38"
  %"ldg_addr_r1_ext.38" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.38" = shl i64 %"ldg_addr_r1_ext.38", 32
  %"ldg_addr_packed_1.38" = or i64 %"ldg_addr_packed_0.38", %"ldg_addr_r1_shift.38"
  %"ldg_addr_memaddr_offset_add.37" = add i64 %"ldg_addr_packed_1.38", 9232
  %"R358:R354_addr_ptr.36" = inttoptr i64 %"ldg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  %"ldg.38" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.36"
  %"ldg_addr_r0_ext.39" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.39" = or i64 0, %"ldg_addr_r0_ext.39"
  %"ldg_addr_r1_ext.39" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.39" = shl i64 %"ldg_addr_r1_ext.39", 32
  %"ldg_addr_packed_1.39" = or i64 %"ldg_addr_packed_0.39", %"ldg_addr_r1_shift.39"
  %"ldg_addr_memaddr_offset_add.38" = add i64 %"ldg_addr_packed_1.39", 9236
  %"R358:R354_addr_ptr.37" = inttoptr i64 %"ldg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  %"ldg.39" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.37"
  %"isetrp_src_trunc.12" = trunc i32 %"P8_to_i32" to i1
  %"isetrp_cmp1.24" = icmp eq i32 %".582", %"ldg.31"
  %"isetrp_src_to_i32.24" = zext i1 %"isetrp_src_trunc.12" to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %"ldg_addr_r0_ext.40" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.40" = or i64 0, %"ldg_addr_r0_ext.40"
  %"ldg_addr_r1_ext.40" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.40" = shl i64 %"ldg_addr_r1_ext.40", 32
  %"ldg_addr_packed_1.40" = or i64 %"ldg_addr_packed_0.40", %"ldg_addr_r1_shift.40"
  %"ldg_addr_memaddr_offset_add.39" = add i64 %"ldg_addr_packed_1.40", 9240
  %"R358:R354_addr_ptr.38" = inttoptr i64 %"ldg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  %"ldg.40" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.38"
  %"ldg_addr_r0_ext.41" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.41" = or i64 0, %"ldg_addr_r0_ext.41"
  %"ldg_addr_r1_ext.41" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.41" = shl i64 %"ldg_addr_r1_ext.41", 32
  %"ldg_addr_packed_1.41" = or i64 %"ldg_addr_packed_0.41", %"ldg_addr_r1_shift.41"
  %"ldg_addr_memaddr_offset_add.40" = add i64 %"ldg_addr_packed_1.41", 9244
  %"R358:R354_addr_ptr.39" = inttoptr i64 %"ldg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  %"ldg.41" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.39"
  %"isetrp_src_trunc.13" = trunc i32 %"P9_to_i32" to i1
  %"isetrp_cmp1.25" = icmp eq i32 %".583", %"ldg.33"
  %"isetrp_src_to_i32.25" = zext i1 %"isetrp_src_trunc.13" to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  %"isetrp_src_trunc.14" = trunc i32 %"P10_to_i32" to i1
  %"isetrp_cmp1.26" = icmp eq i32 %".584", %"ldg.32"
  %"isetrp_src_to_i32.26" = zext i1 %"isetrp_src_trunc.14" to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"isetrp_src_trunc.15" = trunc i32 %"P11_to_i32" to i1
  %"isetrp_cmp1.27" = icmp eq i32 %".585", %"ldg.35"
  %"isetrp_src_to_i32.27" = zext i1 %"isetrp_src_trunc.15" to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %"isetrp_src_trunc.16" = trunc i32 %"P12_to_i32" to i1
  %"isetrp_cmp1.28" = icmp eq i32 %".586", %"ldg.34"
  %"isetrp_src_to_i32.28" = zext i1 %"isetrp_src_trunc.16" to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"isetrp_src_trunc.17" = trunc i32 %"P14_to_i32" to i1
  %"isetrp_cmp1.29" = icmp eq i32 %".587", %"ldg.36"
  %"isetrp_src_to_i32.29" = zext i1 %"isetrp_src_trunc.17" to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = and i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  %"isetrp_src_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"isetrp_cmp1.30" = icmp eq i32 %".588", %"ldg.37"
  %"isetrp_src_to_i32.30" = zext i1 %"isetrp_src_trunc.18" to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = and i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  %"isetrp_src_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"isetrp_cmp1.31" = icmp eq i32 %".589", %"ldg.38"
  %"isetrp_src_to_i32.31" = zext i1 %"isetrp_src_trunc.19" to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  %"isetrp_src_trunc.20" = trunc i32 %"P45_to_i32" to i1
  %"isetrp_cmp1.32" = icmp eq i32 %".590", %"ldg.39"
  %"isetrp_src_to_i32.32" = zext i1 %"isetrp_src_trunc.20" to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P67_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %"isetrp_src_trunc.21" = trunc i32 %"P67_to_i32" to i1
  %"isetrp_cmp1.33" = icmp eq i32 %".591", %"ldg.40"
  %"isetrp_src_to_i32.33" = zext i1 %"isetrp_src_trunc.21" to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P78_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  %"isetrp_src_trunc.22" = trunc i32 %"P78_to_i32" to i1
  %"isetrp_cmp1.34" = icmp eq i32 %".592", %"ldg.41"
  %"isetrp_src_to_i32.34" = zext i1 %"isetrp_src_trunc.22" to i32
  %"isetrp_src_to_i1.34" = icmp ne i32 %"isetrp_src_to_i32.34", 0
  %"isetrp_cmp2.34" = and i1 %"isetrp_cmp1.34", %"isetrp_src_to_i1.34"
  %"P89_to_i32" = zext i1 %"isetrp_cmp2.34" to i32
  br label %"BB_19f0"
BB_19f0:
  %"phi.31" = phi  i32 [%"P89_to_i32", %"BB_15c0"], [%"P98_to_i32", %"BB_15b0"]
  %"s2ur_cluster_ctarank.7" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.12" = add i32 1024, 2048
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", 0
  %".594" = zext i32 0 to i64
  %".595" = zext i32 0 to i64
  %".596" = shl i64 %".595", 32
  %"shf_concat.15" = or i64 %".594", %".596"
  %"shf_shift_64.15" = zext i32 31 to i64
  %".597" = shl i64 %"shf_concat.15", %"shf_shift_64.15"
  %"shf_result.15" = trunc i64 %".597" to i32
  %".598" = zext i32 %"s2ur_cluster_ctarank.7" to i64
  %".599" = zext i32 %"iadd3_n2.12" to i64
  %".600" = zext i32 24 to i64
  %".601" = shl i64 %".598", %".600"
  %".602" = and i64 %".601", 4294967295
  %".603" = add i64 %".602", %".599"
  %".604" = trunc i64 %".603" to i32
  %"mbar_shared_winoff.1" = and i32 %".604", 16777215
  %".605" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".605" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.15", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P80_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_1a60"
BB_1a60:
  %"cond_trunc.26" = trunc i32 %"P80_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.26", -1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_2ba0", label %"BB_1a70"
BB_2ba0:
  %"mbar_shared_winoff.2" = and i32 %".604", 16777215
  %".608" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".608" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.15", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P4_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_2bb0"
BB_2bb0:
  %"cond_trunc.27" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_2ba0", label %"BB_1a70"
BB_1a70:
  %".611" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".612" = bitcast i8* %".611" to i64*
  %"ldc_const.3" = load i64, i64* %".612"
  %"R19:R18_r0" = trunc i64 %"ldc_const.3" to i32
  %"R19:R18_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"imad_tmp.39" = mul i32 %"tid_x", 40
  %"imad.41" = add i32 %"imad_tmp.39", 0
  %"imad_tmp.40" = mul i32 %"imad.39", 1
  %"imad.42" = add i32 %"imad_tmp.40", %"imad.40"
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.40")
  %".613" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".614" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".615" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".616" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.40", 4
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".617" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".618" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".619" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".620" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.41" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.43" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R19:R18_r0.1" = trunc i64 %"imad.43" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"imad.43", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R226:R160_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".613", i32 addrspace(1)* %"R226:R160_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R226:R160_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".614", i32 addrspace(1)* %"R226:R160_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R226:R160_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".615", i32 addrspace(1)* %"R226:R160_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R226:R160_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".616", i32 addrspace(1)* %"R226:R160_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R226:R160_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".617", i32 addrspace(1)* %"R226:R160_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.40", 8
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".626" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".627" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".628" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".629" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R226:R160_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".618", i32 addrspace(1)* %"R226:R160_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R226:R160_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".619", i32 addrspace(1)* %"R226:R160_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R226:R160_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".620", i32 addrspace(1)* %"R226:R160_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.40", 12
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".633" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".634" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".635" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".636" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R226:R160_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".626", i32 addrspace(1)* %"R226:R160_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R226:R160_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".627", i32 addrspace(1)* %"R226:R160_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R226:R160_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".628", i32 addrspace(1)* %"R226:R160_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R226:R160_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".629", i32 addrspace(1)* %"R226:R160_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R226:R160_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".633", i32 addrspace(1)* %"R226:R160_addr_ptr.12"
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".642" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".643" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".644" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".645" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R226:R160_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".634", i32 addrspace(1)* %"R226:R160_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R226:R160_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".635", i32 addrspace(1)* %"R226:R160_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R226:R160_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".636", i32 addrspace(1)* %"R226:R160_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.42", 4
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".649" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".650" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".651" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".652" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R226:R160_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".642", i32 addrspace(1)* %"R226:R160_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R226:R160_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".643", i32 addrspace(1)* %"R226:R160_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R226:R160_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".644", i32 addrspace(1)* %"R226:R160_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R226:R160_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".645", i32 addrspace(1)* %"R226:R160_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R226:R160_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".649", i32 addrspace(1)* %"R226:R160_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.40", 16
  %"ldtm.12" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".658" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 0
  %".659" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 1
  %".660" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 2
  %".661" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R226:R160_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".650", i32 addrspace(1)* %"R226:R160_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R226:R160_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".651", i32 addrspace(1)* %"R226:R160_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R226:R160_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".652", i32 addrspace(1)* %"R226:R160_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.40", 20
  %"ldtm.13" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".665" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 0
  %".666" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 1
  %".667" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 2
  %".668" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R226:R160_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".658", i32 addrspace(1)* %"R226:R160_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R226:R160_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".659", i32 addrspace(1)* %"R226:R160_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R226:R160_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".660", i32 addrspace(1)* %"R226:R160_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R226:R160_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".661", i32 addrspace(1)* %"R226:R160_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R226:R160_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".665", i32 addrspace(1)* %"R226:R160_addr_ptr.28"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.40", 24
  %"ldtm.14" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".674" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 0
  %".675" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 1
  %".676" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 2
  %".677" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 3
  %"stg_addr_r0_ext.29" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R226:R160_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".666", i32 addrspace(1)* %"R226:R160_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R226:R160_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".667", i32 addrspace(1)* %"R226:R160_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R226:R160_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".668", i32 addrspace(1)* %"R226:R160_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.40", 28
  %"ldtm.15" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".681" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 0
  %".682" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 1
  %".683" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 2
  %".684" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 3
  %"stg_addr_r0_ext.32" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 128
  %"R226:R160_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".674", i32 addrspace(1)* %"R226:R160_addr_ptr.32"
  %"stg_addr_r0_ext.33" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 132
  %"R226:R160_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".675", i32 addrspace(1)* %"R226:R160_addr_ptr.33"
  %"stg_addr_r0_ext.34" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 136
  %"R226:R160_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".676", i32 addrspace(1)* %"R226:R160_addr_ptr.34"
  %"stg_addr_r0_ext.35" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 140
  %"R226:R160_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".677", i32 addrspace(1)* %"R226:R160_addr_ptr.35"
  %"stg_addr_r0_ext.36" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 144
  %"R226:R160_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".681", i32 addrspace(1)* %"R226:R160_addr_ptr.36"
  %"stg_addr_r0_ext.37" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 148
  %"R226:R160_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".682", i32 addrspace(1)* %"R226:R160_addr_ptr.37"
  %"stg_addr_r0_ext.38" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 152
  %"R226:R160_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".683", i32 addrspace(1)* %"R226:R160_addr_ptr.38"
  %"stg_addr_r0_ext.39" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 156
  %"R226:R160_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".684", i32 addrspace(1)* %"R226:R160_addr_ptr.39"
  br label %"BB_1ef0"
BB_1ef0:
  %"cond_trunc.28" = trunc i32 %"phi.31" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_1f30", label %"BB_1f00"
BB_1f00:
  %"ldg_addr_r0_ext.42" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.42" = or i64 0, %"ldg_addr_r0_ext.42"
  %"ldg_addr_r1_ext.42" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.42" = shl i64 %"ldg_addr_r1_ext.42", 32
  %"ldg_addr_packed_1.42" = or i64 %"ldg_addr_packed_0.42", %"ldg_addr_r1_shift.42"
  %"ldg_addr_memaddr_offset_add.41" = add i64 %"ldg_addr_packed_1.42", 9216
  %"R358:R354_addr_ptr.40" = inttoptr i64 %"ldg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  %"ldg.42" = load i32, i32 addrspace(1)* %"R358:R354_addr_ptr.40"
  %".695" = xor i32 0, -1
  %".696" = xor i32 %"ldg.42", -1
  %".697" = xor i32 0, -1
  %".698" = and i32 %".695", %".696"
  %".699" = and i32 %".698", %".697"
  %".700" = and i32 %".695", %".696"
  %".701" = and i32 %".700", 0
  %".702" = or i32 %".699", %".701"
  %".703" = and i32 0, %".696"
  %".704" = and i32 %".703", %".697"
  %".705" = or i32 %".702", %".704"
  %".706" = and i32 0, %".696"
  %".707" = and i32 %".706", 0
  %".708" = or i32 %".705", %".707"
  %"stg_addr_r0_ext.40" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 64
  %"R226:R160_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".708", i32 addrspace(1)* %"R226:R160_addr_ptr.40"
  br label %"BB_1f30"
BB_1f30:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_1f60"
BB_1f60:
  %"cond_trunc.29" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_80001f60", label %"BB_1f70"
BB_1f70:
  %"lds_addr_memaddr_offset_add.7" = add i32 %".16", 2056
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.7", 16777215
  %".713" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".713" to i32 addrspace(3)*
  %"lds.7" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.7"
  %"imad_tmp.41" = mul i32 0, 0
  %"imad.44" = add i32 %"imad_tmp.41", 1
  %".714" = zext i32 %"s2ur_cluster_ctarank.7" to i64
  %".715" = zext i32 64 to i64
  %".716" = zext i32 24 to i64
  %".717" = shl i64 %".714", %".716"
  %".718" = and i64 %".717", 4294967295
  %".719" = add i64 %".718", %".715"
  %".720" = trunc i64 %".719" to i32
  %"lds_addr_memaddr_offset_add.8" = add i32 %".720", 20
  %"lds_shared_addr_winoff.8" = and i32 %"lds_addr_memaddr_offset_add.8", 16777215
  %".721" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.8"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".721" to i32 addrspace(3)*
  %"lds.8" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.8"
  %".722" = xor i32 %"lds.7", -1
  %".723" = xor i32 65535, -1
  %".724" = xor i32 0, -1
  %".725" = and i32 %"lds.7", 65535
  %".726" = and i32 %".725", %".724"
  %".727" = and i32 %"lds.7", 65535
  %".728" = and i32 %".727", 0
  %".729" = or i32 %".726", %".728"
  %".730" = zext i32 0 to i64
  %".731" = zext i32 %".729" to i64
  %".732" = shl i64 %".731", 32
  %"shf_concat.16" = or i64 %".730", %".732"
  %"shf_shift_64.16" = zext i32 5 to i64
  %".733" = lshr i64 %"shf_concat.16", %"shf_shift_64.16"
  %"shf_hi.3" = lshr i64 %".733", 32
  %"shf_result.16" = trunc i64 %"shf_hi.3" to i32
  %".734" = zext i32 %"imad.44" to i64
  %".735" = zext i32 0 to i64
  %".736" = shl i64 %".735", 32
  %"shf_concat.17" = or i64 %".734", %".736"
  %"shf_shift_64.17" = zext i32 %"shf_result.16" to i64
  %".737" = shl i64 %"shf_concat.17", %"shf_shift_64.17"
  %"shf_result.17" = trunc i64 %".737" to i32
  %".738" = xor i32 %"lds.8", -1
  %".739" = xor i32 %"shf_result.17", -1
  %".740" = xor i32 0, -1
  %".741" = and i32 %"lds.8", %"shf_result.17"
  %".742" = and i32 %".741", %".740"
  %".743" = and i32 %"lds.8", %"shf_result.17"
  %".744" = and i32 %".743", 0
  %".745" = or i32 %".742", %".744"
  %"isetrp_cmp1.35" = icmp ne i32 %".745", %"shf_result.17"
  %"isetrp_src_to_i32.35" = zext i1 1 to i32
  %"isetrp_src_to_i1.35" = icmp ne i32 %"isetrp_src_to_i32.35", 0
  %"isetrp_cmp2.35" = and i1 %"isetrp_cmp1.35", %"isetrp_src_to_i1.35"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.35" to i32
  br label %"BB_2020"
BB_2020:
  %"cond_trunc.30" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_2180_2c00", label %"BB_2030"
BB_2030:
  %"lds_addr_memaddr_offset_add.9" = add i32 %".720", 24
  %"lds_shared_addr_winoff.9" = and i32 %"lds_addr_memaddr_offset_add.9", 16777215
  %".748" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.9"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".748" to i32 addrspace(3)*
  %"lds.9" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.9"
  %".749" = xor i32 %"lds.9", -1
  %".750" = xor i32 %"shf_result.17", -1
  %".751" = xor i32 0, -1
  %".752" = and i32 %"lds.9", %"shf_result.17"
  %".753" = and i32 %".752", %".751"
  %".754" = and i32 %"lds.9", %"shf_result.17"
  %".755" = and i32 %".754", 0
  %".756" = or i32 %".753", %".755"
  %"isetrp_cmp1.36" = icmp ne i32 %".756", %"shf_result.17"
  %"isetrp_src_to_i32.36" = zext i1 1 to i32
  %"isetrp_src_to_i1.36" = icmp ne i32 %"isetrp_src_to_i32.36", 0
  %"isetrp_cmp2.36" = and i1 %"isetrp_cmp1.36", %"isetrp_src_to_i1.36"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.36" to i32
  br label %"BB_2060"
BB_2060:
  %"cond_trunc.31" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_2150_2bd0", label %"BB_2070"
BB_2070:
  %"activemask.1" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.1" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.1" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.1", i1 0)
  %"flo.1" = sub i32 31, %"flo_clz.1"
  %".759" = xor i32 0, -1
  %".760" = xor i32 %"shf_result.17", -1
  %".761" = xor i32 0, -1
  %".762" = and i32 %".759", %".760"
  %".763" = and i32 %".762", %".761"
  %".764" = and i32 %".759", %".760"
  %".765" = and i32 %".764", 0
  %".766" = or i32 %".763", %".765"
  %".767" = and i32 0, %".760"
  %".768" = and i32 %".767", %".761"
  %".769" = or i32 %".766", %".768"
  %".770" = and i32 0, %".760"
  %".771" = and i32 %".770", 0
  %".772" = or i32 %".769", %".771"
  %"imad_tmp.42" = mul i32 0, 0
  %"imad.45" = add i32 %"imad_tmp.42", %".772"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.45", i32 %"redux_mask.1")
  %".773" = xor i32 %".772", -1
  %".774" = call i32 @"llvm.cttz.i32"(i32 %".773", i1 0)
  %".775" = shl i32 %".774", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".775") convergent
  %"isetrp_cmp1.37" = icmp eq i32 %"laneid.1", %"flo.1"
  %"isetrp_src_to_i32.37" = zext i1 1 to i32
  %"isetrp_src_to_i1.37" = icmp ne i32 %"isetrp_src_to_i32.37", 0
  %"isetrp_cmp2.37" = and i1 %"isetrp_cmp1.37", %"isetrp_src_to_i1.37"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.37" to i32
  %"imad_tmp.43" = mul i32 0, 0
  %"imad.46" = add i32 %"imad_tmp.43", %"redux_sync_and.1"
  br label %"BB_2110"
BB_2110:
  %"cond_trunc.32" = trunc i32 %"P16_to_i32" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_80002110", label %"BB_2190"
BB_80002110:
  %"atoms_addr_memaddr_offset_add.14" = add i32 %".720", 20
  %"atoms_shared_addr_winoff.14" = and i32 %"atoms_addr_memaddr_offset_add.14", 16777215
  %".779" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.14"
  %"atoms_ptr.14" = bitcast i8 addrspace(3)* %".779" to i32 addrspace(3)*
  %"atoms_and.2" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.14", i32 %"imad.46" monotonic
  %"atoms_addr_memaddr_offset_add.15" = add i32 %".720", 24
  %"atoms_shared_addr_winoff.15" = and i32 %"atoms_addr_memaddr_offset_add.15", 16777215
  %".780" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.15"
  %"atoms_ptr.15" = bitcast i8 addrspace(3)* %".780" to i32 addrspace(3)*
  %"atoms_and.3" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.15", i32 %"imad.46" monotonic
  br label %"BB_2190"
BB_2150_2bd0:
  call void @"llvm.trap"()
  br label %"BB_2190"
BB_2180_2c00:
  call void @"llvm.trap"()
  br label %"BB_2190"
BB_2190:
  %"s2ur_cluster_ctarank.8" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.10" = add i32 %".16", 2060
  %"lds_shared_addr_winoff.10" = and i32 %"lds_addr_memaddr_offset_add.10", 16777215
  %".784" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.10"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".784" to i32 addrspace(3)*
  %"lds.10" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.10"
  %"imad_tmp.44" = mul i32 0, 0
  %"imad.47" = add i32 %"imad_tmp.44", 1
  %".785" = zext i32 %"s2ur_cluster_ctarank.8" to i64
  %".786" = zext i32 64 to i64
  %".787" = zext i32 24 to i64
  %".788" = shl i64 %".785", %".787"
  %".789" = and i64 %".788", 4294967295
  %".790" = add i64 %".789", %".786"
  %".791" = trunc i64 %".790" to i32
  %"lds_addr_memaddr_offset_add.11" = add i32 %".791", 20
  %"lds_shared_addr_winoff.11" = and i32 %"lds_addr_memaddr_offset_add.11", 16777215
  %".792" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.11"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".792" to i32 addrspace(3)*
  %"lds.11" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.11"
  %".793" = xor i32 %"lds.10", -1
  %".794" = xor i32 65535, -1
  %".795" = xor i32 0, -1
  %".796" = and i32 %"lds.10", 65535
  %".797" = and i32 %".796", %".795"
  %".798" = and i32 %"lds.10", 65535
  %".799" = and i32 %".798", 0
  %".800" = or i32 %".797", %".799"
  %".801" = zext i32 0 to i64
  %".802" = zext i32 %".800" to i64
  %".803" = shl i64 %".802", 32
  %"shf_concat.18" = or i64 %".801", %".803"
  %"shf_shift_64.18" = zext i32 5 to i64
  %".804" = lshr i64 %"shf_concat.18", %"shf_shift_64.18"
  %"shf_hi.4" = lshr i64 %".804", 32
  %"shf_result.18" = trunc i64 %"shf_hi.4" to i32
  %".805" = zext i32 %"imad.47" to i64
  %".806" = zext i32 0 to i64
  %".807" = shl i64 %".806", 32
  %"shf_concat.19" = or i64 %".805", %".807"
  %"shf_shift_64.19" = zext i32 %"shf_result.18" to i64
  %".808" = shl i64 %"shf_concat.19", %"shf_shift_64.19"
  %"shf_result.19" = trunc i64 %".808" to i32
  %".809" = xor i32 %"lds.11", -1
  %".810" = xor i32 %"shf_result.19", -1
  %".811" = xor i32 0, -1
  %".812" = and i32 %"lds.11", %"shf_result.19"
  %".813" = and i32 %".812", %".811"
  %".814" = and i32 %"lds.11", %"shf_result.19"
  %".815" = and i32 %".814", 0
  %".816" = or i32 %".813", %".815"
  %"isetrp_cmp1.38" = icmp ne i32 %".816", %"shf_result.19"
  %"isetrp_src_to_i32.38" = zext i1 1 to i32
  %"isetrp_src_to_i1.38" = icmp ne i32 %"isetrp_src_to_i32.38", 0
  %"isetrp_cmp2.38" = and i1 %"isetrp_cmp1.38", %"isetrp_src_to_i1.38"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.38" to i32
  br label %"BB_2260"
BB_2260:
  %"cond_trunc.33" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_23c0_2c00", label %"BB_2270"
BB_2270:
  %"lds_addr_memaddr_offset_add.12" = add i32 %".791", 24
  %"lds_shared_addr_winoff.12" = and i32 %"lds_addr_memaddr_offset_add.12", 16777215
  %".819" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.12"
  %"lds_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".819" to i32 addrspace(3)*
  %"lds.12" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.12"
  %".820" = xor i32 %"lds.12", -1
  %".821" = xor i32 %"shf_result.19", -1
  %".822" = xor i32 0, -1
  %".823" = and i32 %"lds.12", %"shf_result.19"
  %".824" = and i32 %".823", %".822"
  %".825" = and i32 %"lds.12", %"shf_result.19"
  %".826" = and i32 %".825", 0
  %".827" = or i32 %".824", %".826"
  %"isetrp_cmp1.39" = icmp ne i32 %".827", %"shf_result.19"
  %"isetrp_src_to_i32.39" = zext i1 1 to i32
  %"isetrp_src_to_i1.39" = icmp ne i32 %"isetrp_src_to_i32.39", 0
  %"isetrp_cmp2.39" = and i1 %"isetrp_cmp1.39", %"isetrp_src_to_i1.39"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.39" to i32
  br label %"BB_22a0"
BB_22a0:
  %"cond_trunc.34" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_2390_2bd0", label %"BB_22b0"
BB_22b0:
  %"activemask.2" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.2" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.2" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.2", i1 0)
  %"flo.2" = sub i32 31, %"flo_clz.2"
  %".830" = xor i32 0, -1
  %".831" = xor i32 %"shf_result.19", -1
  %".832" = xor i32 0, -1
  %".833" = and i32 %".830", %".831"
  %".834" = and i32 %".833", %".832"
  %".835" = and i32 %".830", %".831"
  %".836" = and i32 %".835", 0
  %".837" = or i32 %".834", %".836"
  %".838" = and i32 0, %".831"
  %".839" = and i32 %".838", %".832"
  %".840" = or i32 %".837", %".839"
  %".841" = and i32 0, %".831"
  %".842" = and i32 %".841", 0
  %".843" = or i32 %".840", %".842"
  %"imad_tmp.45" = mul i32 0, 0
  %"imad.48" = add i32 %"imad_tmp.45", %".843"
  %"redux_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.2" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.48", i32 %"redux_mask.2")
  %".844" = xor i32 %".843", -1
  %".845" = call i32 @"llvm.cttz.i32"(i32 %".844", i1 0)
  %".846" = shl i32 %".845", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".846") convergent
  %"isetrp_cmp1.40" = icmp eq i32 %"laneid.2", %"flo.2"
  %"isetrp_src_to_i32.40" = zext i1 1 to i32
  %"isetrp_src_to_i1.40" = icmp ne i32 %"isetrp_src_to_i32.40", 0
  %"isetrp_cmp2.40" = and i1 %"isetrp_cmp1.40", %"isetrp_src_to_i1.40"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.40" to i32
  %"imad_tmp.46" = mul i32 0, 0
  %"imad.49" = add i32 %"imad_tmp.46", %"redux_sync_and.2"
  br label %"BB_2350"
BB_2350:
  %"cond_trunc.35" = trunc i32 %"P20_to_i32" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_80002350", label %"BB_23d0"
BB_80002350:
  %"atoms_addr_memaddr_offset_add.16" = add i32 %".791", 20
  %"atoms_shared_addr_winoff.16" = and i32 %"atoms_addr_memaddr_offset_add.16", 16777215
  %".850" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.16"
  %"atoms_ptr.16" = bitcast i8 addrspace(3)* %".850" to i32 addrspace(3)*
  %"atoms_and.4" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.16", i32 %"imad.49" monotonic
  %"atoms_addr_memaddr_offset_add.17" = add i32 %".791", 24
  %"atoms_shared_addr_winoff.17" = and i32 %"atoms_addr_memaddr_offset_add.17", 16777215
  %".851" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.17"
  %"atoms_ptr.17" = bitcast i8 addrspace(3)* %".851" to i32 addrspace(3)*
  %"atoms_and.5" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.17", i32 %"imad.49" monotonic
  br label %"BB_23d0"
BB_2390_2bd0:
  call void @"llvm.trap"()
  br label %"BB_23d0"
BB_23c0_2c00:
  call void @"llvm.trap"()
  br label %"BB_23d0"
BB_23d0:
  %"s2ur_cluster_ctarank.9" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.13" = add i32 %".16", 2064
  %"lds_shared_addr_winoff.13" = and i32 %"lds_addr_memaddr_offset_add.13", 16777215
  %".855" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.13"
  %"lds_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".855" to i32 addrspace(3)*
  %"lds.13" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.13"
  %"imad_tmp.47" = mul i32 0, 0
  %"imad.50" = add i32 %"imad_tmp.47", 3
  %".856" = zext i32 %"s2ur_cluster_ctarank.9" to i64
  %".857" = zext i32 64 to i64
  %".858" = zext i32 24 to i64
  %".859" = shl i64 %".856", %".858"
  %".860" = and i64 %".859", 4294967295
  %".861" = add i64 %".860", %".857"
  %".862" = trunc i64 %".861" to i32
  %"lds_addr_memaddr_offset_add.14" = add i32 %".862", 20
  %"lds_shared_addr_winoff.14" = and i32 %"lds_addr_memaddr_offset_add.14", 16777215
  %".863" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.14"
  %"lds_shared_addr_cast.14" = bitcast i8 addrspace(3)* %".863" to i32 addrspace(3)*
  %"lds.14" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.14"
  %".864" = xor i32 %"lds.13", -1
  %".865" = xor i32 65535, -1
  %".866" = xor i32 0, -1
  %".867" = and i32 %"lds.13", 65535
  %".868" = and i32 %".867", %".866"
  %".869" = and i32 %"lds.13", 65535
  %".870" = and i32 %".869", 0
  %".871" = or i32 %".868", %".870"
  %".872" = zext i32 0 to i64
  %".873" = zext i32 %".871" to i64
  %".874" = shl i64 %".873", 32
  %"shf_concat.20" = or i64 %".872", %".874"
  %"shf_shift_64.20" = zext i32 5 to i64
  %".875" = lshr i64 %"shf_concat.20", %"shf_shift_64.20"
  %"shf_hi.5" = lshr i64 %".875", 32
  %"shf_result.20" = trunc i64 %"shf_hi.5" to i32
  %".876" = zext i32 %"imad.50" to i64
  %".877" = zext i32 0 to i64
  %".878" = shl i64 %".877", 32
  %"shf_concat.21" = or i64 %".876", %".878"
  %"shf_shift_64.21" = zext i32 %"shf_result.20" to i64
  %".879" = shl i64 %"shf_concat.21", %"shf_shift_64.21"
  %"shf_result.21" = trunc i64 %".879" to i32
  %".880" = xor i32 %"lds.14", -1
  %".881" = xor i32 %"shf_result.21", -1
  %".882" = xor i32 0, -1
  %".883" = and i32 %"lds.14", %"shf_result.21"
  %".884" = and i32 %".883", %".882"
  %".885" = and i32 %"lds.14", %"shf_result.21"
  %".886" = and i32 %".885", 0
  %".887" = or i32 %".884", %".886"
  %"isetrp_cmp1.41" = icmp ne i32 %".887", %"shf_result.21"
  %"isetrp_src_to_i32.41" = zext i1 1 to i32
  %"isetrp_src_to_i1.41" = icmp ne i32 %"isetrp_src_to_i32.41", 0
  %"isetrp_cmp2.41" = and i1 %"isetrp_cmp1.41", %"isetrp_src_to_i1.41"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.41" to i32
  %"imad_tmp.48" = mul i32 0, 0
  %"imad.51" = add i32 %"imad_tmp.48", 1
  %".888" = zext i32 %"imad.51" to i64
  %".889" = zext i32 0 to i64
  %".890" = shl i64 %".889", 32
  %"shf_concat.22" = or i64 %".888", %".890"
  %"shf_shift_64.22" = zext i32 %"shf_result.20" to i64
  %".891" = shl i64 %"shf_concat.22", %"shf_shift_64.22"
  %"shf_result.22" = trunc i64 %".891" to i32
  br label %"BB_24c0"
BB_24c0:
  %"cond_trunc.36" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_2650_2c00", label %"BB_24d0"
BB_24d0:
  %"lds_addr_memaddr_offset_add.15" = add i32 %".862", 24
  %"lds_shared_addr_winoff.15" = and i32 %"lds_addr_memaddr_offset_add.15", 16777215
  %".894" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.15"
  %"lds_shared_addr_cast.15" = bitcast i8 addrspace(3)* %".894" to i32 addrspace(3)*
  %"lds.15" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.15"
  %".895" = xor i32 %"lds.15", -1
  %".896" = xor i32 %"shf_result.22", -1
  %".897" = xor i32 0, -1
  %".898" = and i32 %"lds.15", %"shf_result.22"
  %".899" = and i32 %".898", %".897"
  %".900" = and i32 %"lds.15", %"shf_result.22"
  %".901" = and i32 %".900", 0
  %".902" = or i32 %".899", %".901"
  %"isetrp_cmp1.42" = icmp ne i32 %".902", %"shf_result.22"
  %"isetrp_src_to_i32.42" = zext i1 1 to i32
  %"isetrp_src_to_i1.42" = icmp ne i32 %"isetrp_src_to_i32.42", 0
  %"isetrp_cmp2.42" = and i1 %"isetrp_cmp1.42", %"isetrp_src_to_i1.42"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.42" to i32
  br label %"BB_2500"
BB_2500:
  %"cond_trunc.37" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_2620_2bd0", label %"BB_2510"
BB_2510:
  %"activemask.3" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.3" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".905" = xor i32 0, -1
  %".906" = xor i32 %"shf_result.22", -1
  %".907" = xor i32 0, -1
  %".908" = and i32 %".905", %".906"
  %".909" = and i32 %".908", %".907"
  %".910" = and i32 %".905", %".906"
  %".911" = and i32 %".910", 0
  %".912" = or i32 %".909", %".911"
  %".913" = and i32 0, %".906"
  %".914" = and i32 %".913", %".907"
  %".915" = or i32 %".912", %".914"
  %".916" = and i32 0, %".906"
  %".917" = and i32 %".916", 0
  %".918" = or i32 %".915", %".917"
  %"flo_clz.3" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.3", i1 0)
  %"flo.3" = sub i32 31, %"flo_clz.3"
  %"redux_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.3" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".918", i32 %"redux_mask.3")
  %".919" = xor i32 0, -1
  %".920" = xor i32 %"shf_result.21", -1
  %".921" = xor i32 0, -1
  %".922" = and i32 %".919", %".920"
  %".923" = and i32 %".922", %".921"
  %".924" = and i32 %".919", %".920"
  %".925" = and i32 %".924", 0
  %".926" = or i32 %".923", %".925"
  %".927" = and i32 0, %".920"
  %".928" = and i32 %".927", %".921"
  %".929" = or i32 %".926", %".928"
  %".930" = and i32 0, %".920"
  %".931" = and i32 %".930", 0
  %".932" = or i32 %".929", %".931"
  %"imad_tmp.49" = mul i32 0, 0
  %"imad.52" = add i32 %"imad_tmp.49", %".932"
  %"redux_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.4" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.52", i32 %"redux_mask.4")
  %".933" = xor i32 %".932", -1
  %".934" = call i32 @"llvm.cttz.i32"(i32 %".933", i1 0)
  %".935" = shl i32 %".934", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".935") convergent
  %"imad_tmp.50" = mul i32 0, 0
  %"imad.53" = add i32 %"imad_tmp.50", %"redux_sync_and.3"
  %"isetrp_cmp1.43" = icmp eq i32 %"laneid.3", %"flo.3"
  %"isetrp_src_to_i32.43" = zext i1 1 to i32
  %"isetrp_src_to_i1.43" = icmp ne i32 %"isetrp_src_to_i32.43", 0
  %"isetrp_cmp2.43" = and i1 %"isetrp_cmp1.43", %"isetrp_src_to_i1.43"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.43" to i32
  %"imad_tmp.51" = mul i32 0, 0
  %"imad.54" = add i32 %"imad_tmp.51", %"redux_sync_and.4"
  br label %"BB_25e0"
BB_25e0:
  %"cond_trunc.38" = trunc i32 %"P25_to_i32" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_800025e0", label %"BB_2660"
BB_800025e0:
  %"atoms_addr_memaddr_offset_add.18" = add i32 %".862", 20
  %"atoms_shared_addr_winoff.18" = and i32 %"atoms_addr_memaddr_offset_add.18", 16777215
  %".939" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.18"
  %"atoms_ptr.18" = bitcast i8 addrspace(3)* %".939" to i32 addrspace(3)*
  %"atoms_and.6" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.18", i32 %"imad.54" monotonic
  %"atoms_addr_memaddr_offset_add.19" = add i32 %".862", 24
  %"atoms_shared_addr_winoff.19" = and i32 %"atoms_addr_memaddr_offset_add.19", 16777215
  %".940" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.19"
  %"atoms_ptr.19" = bitcast i8 addrspace(3)* %".940" to i32 addrspace(3)*
  %"atoms_and.7" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.19", i32 %"imad.53" monotonic
  br label %"BB_2660"
BB_2620_2bd0:
  call void @"llvm.trap"()
  br label %"BB_2660"
BB_2650_2c00:
  call void @"llvm.trap"()
  br label %"BB_2660"
BB_2660:
  %"s2ur_cluster_ctarank.10" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.16" = add i32 %".16", 2068
  %"lds_shared_addr_winoff.16" = and i32 %"lds_addr_memaddr_offset_add.16", 16777215
  %".944" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.16"
  %"lds_shared_addr_cast.16" = bitcast i8 addrspace(3)* %".944" to i32 addrspace(3)*
  %"lds.16" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.16"
  %"imad_tmp.52" = mul i32 0, 0
  %"imad.55" = add i32 %"imad_tmp.52", 15
  %".945" = zext i32 %"s2ur_cluster_ctarank.10" to i64
  %".946" = zext i32 64 to i64
  %".947" = zext i32 24 to i64
  %".948" = shl i64 %".945", %".947"
  %".949" = and i64 %".948", 4294967295
  %".950" = add i64 %".949", %".946"
  %".951" = trunc i64 %".950" to i32
  %"lds_addr_memaddr_offset_add.17" = add i32 %".951", 20
  %"lds_shared_addr_winoff.17" = and i32 %"lds_addr_memaddr_offset_add.17", 16777215
  %".952" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.17"
  %"lds_shared_addr_cast.17" = bitcast i8 addrspace(3)* %".952" to i32 addrspace(3)*
  %"lds.17" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.17"
  %".953" = xor i32 %"lds.16", -1
  %".954" = xor i32 65535, -1
  %".955" = xor i32 0, -1
  %".956" = and i32 %"lds.16", 65535
  %".957" = and i32 %".956", %".955"
  %".958" = and i32 %"lds.16", 65535
  %".959" = and i32 %".958", 0
  %".960" = or i32 %".957", %".959"
  %".961" = zext i32 0 to i64
  %".962" = zext i32 %".960" to i64
  %".963" = shl i64 %".962", 32
  %"shf_concat.23" = or i64 %".961", %".963"
  %"shf_shift_64.23" = zext i32 5 to i64
  %".964" = lshr i64 %"shf_concat.23", %"shf_shift_64.23"
  %"shf_hi.6" = lshr i64 %".964", 32
  %"shf_result.23" = trunc i64 %"shf_hi.6" to i32
  %".965" = zext i32 %"imad.55" to i64
  %".966" = zext i32 0 to i64
  %".967" = shl i64 %".966", 32
  %"shf_concat.24" = or i64 %".965", %".967"
  %"shf_shift_64.24" = zext i32 %"shf_result.23" to i64
  %".968" = shl i64 %"shf_concat.24", %"shf_shift_64.24"
  %"shf_result.24" = trunc i64 %".968" to i32
  %".969" = xor i32 %"lds.17", -1
  %".970" = xor i32 %"shf_result.24", -1
  %".971" = xor i32 0, -1
  %".972" = and i32 %"lds.17", %"shf_result.24"
  %".973" = and i32 %".972", %".971"
  %".974" = and i32 %"lds.17", %"shf_result.24"
  %".975" = and i32 %".974", 0
  %".976" = or i32 %".973", %".975"
  %"isetrp_cmp1.44" = icmp ne i32 %".976", %"shf_result.24"
  %"isetrp_src_to_i32.44" = zext i1 1 to i32
  %"isetrp_src_to_i1.44" = icmp ne i32 %"isetrp_src_to_i32.44", 0
  %"isetrp_cmp2.44" = and i1 %"isetrp_cmp1.44", %"isetrp_src_to_i1.44"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2.44" to i32
  %"imad_tmp.53" = mul i32 0, 0
  %"imad.56" = add i32 %"imad_tmp.53", 1
  %".977" = zext i32 %"imad.56" to i64
  %".978" = zext i32 0 to i64
  %".979" = shl i64 %".978", 32
  %"shf_concat.25" = or i64 %".977", %".979"
  %"shf_shift_64.25" = zext i32 %"shf_result.23" to i64
  %".980" = shl i64 %"shf_concat.25", %"shf_shift_64.25"
  %"shf_result.25" = trunc i64 %".980" to i32
  br label %"BB_2750"
BB_2750:
  %"cond_trunc.39" = trunc i32 %"P26_to_i32" to i1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_trunc.39" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_28e0_2c00", label %"BB_2760"
BB_2760:
  %"lds_addr_memaddr_offset_add.18" = add i32 %".951", 24
  %"lds_shared_addr_winoff.18" = and i32 %"lds_addr_memaddr_offset_add.18", 16777215
  %".983" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.18"
  %"lds_shared_addr_cast.18" = bitcast i8 addrspace(3)* %".983" to i32 addrspace(3)*
  %"lds.18" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.18"
  %".984" = xor i32 %"lds.18", -1
  %".985" = xor i32 %"shf_result.25", -1
  %".986" = xor i32 0, -1
  %".987" = and i32 %"lds.18", %"shf_result.25"
  %".988" = and i32 %".987", %".986"
  %".989" = and i32 %"lds.18", %"shf_result.25"
  %".990" = and i32 %".989", 0
  %".991" = or i32 %".988", %".990"
  %"isetrp_cmp1.45" = icmp ne i32 %".991", %"shf_result.25"
  %"isetrp_src_to_i32.45" = zext i1 1 to i32
  %"isetrp_src_to_i1.45" = icmp ne i32 %"isetrp_src_to_i32.45", 0
  %"isetrp_cmp2.45" = and i1 %"isetrp_cmp1.45", %"isetrp_src_to_i1.45"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.45" to i32
  br label %"BB_2790"
BB_2790:
  %"cond_trunc.40" = trunc i32 %"P27_to_i32" to i1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_trunc.40" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_28b0_2bd0", label %"BB_27a0"
BB_27a0:
  %"activemask.4" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.4" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".994" = xor i32 0, -1
  %".995" = xor i32 %"shf_result.25", -1
  %".996" = xor i32 0, -1
  %".997" = and i32 %".994", %".995"
  %".998" = and i32 %".997", %".996"
  %".999" = and i32 %".994", %".995"
  %".1000" = and i32 %".999", 0
  %".1001" = or i32 %".998", %".1000"
  %".1002" = and i32 0, %".995"
  %".1003" = and i32 %".1002", %".996"
  %".1004" = or i32 %".1001", %".1003"
  %".1005" = and i32 0, %".995"
  %".1006" = and i32 %".1005", 0
  %".1007" = or i32 %".1004", %".1006"
  %"flo_clz.4" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.4", i1 0)
  %"flo.4" = sub i32 31, %"flo_clz.4"
  %"redux_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.5" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".1007", i32 %"redux_mask.5")
  %".1008" = xor i32 0, -1
  %".1009" = xor i32 %"shf_result.24", -1
  %".1010" = xor i32 0, -1
  %".1011" = and i32 %".1008", %".1009"
  %".1012" = and i32 %".1011", %".1010"
  %".1013" = and i32 %".1008", %".1009"
  %".1014" = and i32 %".1013", 0
  %".1015" = or i32 %".1012", %".1014"
  %".1016" = and i32 0, %".1009"
  %".1017" = and i32 %".1016", %".1010"
  %".1018" = or i32 %".1015", %".1017"
  %".1019" = and i32 0, %".1009"
  %".1020" = and i32 %".1019", 0
  %".1021" = or i32 %".1018", %".1020"
  %"imad_tmp.54" = mul i32 0, 0
  %"imad.57" = add i32 %"imad_tmp.54", %".1021"
  %"redux_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.6" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.57", i32 %"redux_mask.6")
  %".1022" = xor i32 %".1021", -1
  %".1023" = call i32 @"llvm.cttz.i32"(i32 %".1022", i1 0)
  %".1024" = shl i32 %".1023", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".1024") convergent
  %"imad_tmp.55" = mul i32 0, 0
  %"imad.58" = add i32 %"imad_tmp.55", %"redux_sync_and.5"
  %"isetrp_cmp1.46" = icmp eq i32 %"laneid.4", %"flo.4"
  %"isetrp_src_to_i32.46" = zext i1 1 to i32
  %"isetrp_src_to_i1.46" = icmp ne i32 %"isetrp_src_to_i32.46", 0
  %"isetrp_cmp2.46" = and i1 %"isetrp_cmp1.46", %"isetrp_src_to_i1.46"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.46" to i32
  %"imad_tmp.56" = mul i32 0, 0
  %"imad.59" = add i32 %"imad_tmp.56", %"redux_sync_and.6"
  br label %"BB_2870"
BB_2870:
  %"cond_trunc.41" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.41" = zext i1 %"cond_trunc.41" to i32
  %"pbra_cond_to_i1.41" = icmp ne i32 %"pbra_cond_to_i32.41", 0
  br i1 %"pbra_cond_to_i1.41", label %"BB_80002870", label %"BB_28f0"
BB_80002870:
  %"atoms_addr_memaddr_offset_add.20" = add i32 %".951", 20
  %"atoms_shared_addr_winoff.20" = and i32 %"atoms_addr_memaddr_offset_add.20", 16777215
  %".1028" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.20"
  %"atoms_ptr.20" = bitcast i8 addrspace(3)* %".1028" to i32 addrspace(3)*
  %"atoms_and.8" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.20", i32 %"imad.59" monotonic
  %"atoms_addr_memaddr_offset_add.21" = add i32 %".951", 24
  %"atoms_shared_addr_winoff.21" = and i32 %"atoms_addr_memaddr_offset_add.21", 16777215
  %".1029" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.21"
  %"atoms_ptr.21" = bitcast i8 addrspace(3)* %".1029" to i32 addrspace(3)*
  %"atoms_and.9" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.21", i32 %"imad.58" monotonic
  br label %"BB_28f0"
BB_28b0_2bd0:
  call void @"llvm.trap"()
  br label %"BB_28f0"
BB_28e0_2c00:
  call void @"llvm.trap"()
  br label %"BB_28f0"
BB_28f0:
  %"s2ur_cluster_ctarank.11" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"lds_addr_memaddr_offset_add.19" = add i32 %".16", 2072
  %"lds_shared_addr_winoff.19" = and i32 %"lds_addr_memaddr_offset_add.19", 16777215
  %".1033" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.19"
  %"lds_shared_addr_cast.19" = bitcast i8 addrspace(3)* %".1033" to i32 addrspace(3)*
  %"lds.19" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.19"
  %"imad_tmp.57" = mul i32 0, 0
  %"imad.60" = add i32 %"imad_tmp.57", 255
  %".1034" = zext i32 %"s2ur_cluster_ctarank.11" to i64
  %".1035" = zext i32 64 to i64
  %".1036" = zext i32 24 to i64
  %".1037" = shl i64 %".1034", %".1036"
  %".1038" = and i64 %".1037", 4294967295
  %".1039" = add i64 %".1038", %".1035"
  %".1040" = trunc i64 %".1039" to i32
  %"lds_addr_memaddr_offset_add.20" = add i32 %".1040", 20
  %"lds_shared_addr_winoff.20" = and i32 %"lds_addr_memaddr_offset_add.20", 16777215
  %".1041" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.20"
  %"lds_shared_addr_cast.20" = bitcast i8 addrspace(3)* %".1041" to i32 addrspace(3)*
  %"lds.20" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.20"
  %".1042" = xor i32 %"lds.19", -1
  %".1043" = xor i32 65535, -1
  %".1044" = xor i32 0, -1
  %".1045" = and i32 %"lds.19", 65535
  %".1046" = and i32 %".1045", %".1044"
  %".1047" = and i32 %"lds.19", 65535
  %".1048" = and i32 %".1047", 0
  %".1049" = or i32 %".1046", %".1048"
  %".1050" = zext i32 0 to i64
  %".1051" = zext i32 %".1049" to i64
  %".1052" = shl i64 %".1051", 32
  %"shf_concat.26" = or i64 %".1050", %".1052"
  %"shf_shift_64.26" = zext i32 5 to i64
  %".1053" = lshr i64 %"shf_concat.26", %"shf_shift_64.26"
  %"shf_hi.7" = lshr i64 %".1053", 32
  %"shf_result.26" = trunc i64 %"shf_hi.7" to i32
  %".1054" = zext i32 %"imad.60" to i64
  %".1055" = zext i32 0 to i64
  %".1056" = shl i64 %".1055", 32
  %"shf_concat.27" = or i64 %".1054", %".1056"
  %"shf_shift_64.27" = zext i32 %"shf_result.26" to i64
  %".1057" = shl i64 %"shf_concat.27", %"shf_shift_64.27"
  %"shf_result.27" = trunc i64 %".1057" to i32
  %".1058" = xor i32 %"lds.20", -1
  %".1059" = xor i32 %"shf_result.27", -1
  %".1060" = xor i32 0, -1
  %".1061" = and i32 %"lds.20", %"shf_result.27"
  %".1062" = and i32 %".1061", %".1060"
  %".1063" = and i32 %"lds.20", %"shf_result.27"
  %".1064" = and i32 %".1063", 0
  %".1065" = or i32 %".1062", %".1064"
  %"isetrp_cmp1.47" = icmp ne i32 %".1065", %"shf_result.27"
  %"isetrp_src_to_i32.47" = zext i1 1 to i32
  %"isetrp_src_to_i1.47" = icmp ne i32 %"isetrp_src_to_i32.47", 0
  %"isetrp_cmp2.47" = and i1 %"isetrp_cmp1.47", %"isetrp_src_to_i1.47"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.47" to i32
  %"imad_tmp.58" = mul i32 0, 0
  %"imad.61" = add i32 %"imad_tmp.58", 1
  %".1066" = zext i32 %"imad.61" to i64
  %".1067" = zext i32 0 to i64
  %".1068" = shl i64 %".1067", 32
  %"shf_concat.28" = or i64 %".1066", %".1068"
  %"shf_shift_64.28" = zext i32 %"shf_result.26" to i64
  %".1069" = shl i64 %"shf_concat.28", %"shf_shift_64.28"
  %"shf_result.28" = trunc i64 %".1069" to i32
  br label %"BB_29e0"
BB_29e0:
  %"cond_trunc.42" = trunc i32 %"P30_to_i32" to i1
  %"pbra_cond_to_i32.42" = zext i1 %"cond_trunc.42" to i32
  %"pbra_cond_to_i1.42" = icmp ne i32 %"pbra_cond_to_i32.42", 0
  br i1 %"pbra_cond_to_i1.42", label %"BB_2b70_2c00", label %"BB_29f0"
BB_29f0:
  %"lds_addr_memaddr_offset_add.21" = add i32 %".1040", 24
  %"lds_shared_addr_winoff.21" = and i32 %"lds_addr_memaddr_offset_add.21", 16777215
  %".1072" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.21"
  %"lds_shared_addr_cast.21" = bitcast i8 addrspace(3)* %".1072" to i32 addrspace(3)*
  %"lds.21" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.21"
  %".1073" = xor i32 %"lds.21", -1
  %".1074" = xor i32 %"shf_result.28", -1
  %".1075" = xor i32 0, -1
  %".1076" = and i32 %"lds.21", %"shf_result.28"
  %".1077" = and i32 %".1076", %".1075"
  %".1078" = and i32 %"lds.21", %"shf_result.28"
  %".1079" = and i32 %".1078", 0
  %".1080" = or i32 %".1077", %".1079"
  %"isetrp_cmp1.48" = icmp ne i32 %".1080", %"shf_result.28"
  %"isetrp_src_to_i32.48" = zext i1 1 to i32
  %"isetrp_src_to_i1.48" = icmp ne i32 %"isetrp_src_to_i32.48", 0
  %"isetrp_cmp2.48" = and i1 %"isetrp_cmp1.48", %"isetrp_src_to_i1.48"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.48" to i32
  br label %"BB_2a20"
BB_2a20:
  %"cond_trunc.43" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.43" = zext i1 %"cond_trunc.43" to i32
  %"pbra_cond_to_i1.43" = icmp ne i32 %"pbra_cond_to_i32.43", 0
  br i1 %"pbra_cond_to_i1.43", label %"BB_2b40_2bd0", label %"BB_2a30"
BB_2a30:
  %"activemask.5" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.5" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".1083" = xor i32 0, -1
  %".1084" = xor i32 %"shf_result.28", -1
  %".1085" = xor i32 0, -1
  %".1086" = and i32 %".1083", %".1084"
  %".1087" = and i32 %".1086", %".1085"
  %".1088" = and i32 %".1083", %".1084"
  %".1089" = and i32 %".1088", 0
  %".1090" = or i32 %".1087", %".1089"
  %".1091" = and i32 0, %".1084"
  %".1092" = and i32 %".1091", %".1085"
  %".1093" = or i32 %".1090", %".1092"
  %".1094" = and i32 0, %".1084"
  %".1095" = and i32 %".1094", 0
  %".1096" = or i32 %".1093", %".1095"
  %"flo_clz.5" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.5", i1 0)
  %"flo.5" = sub i32 31, %"flo_clz.5"
  %"redux_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.7" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".1096", i32 %"redux_mask.7")
  %".1097" = xor i32 0, -1
  %".1098" = xor i32 %"shf_result.27", -1
  %".1099" = xor i32 0, -1
  %".1100" = and i32 %".1097", %".1098"
  %".1101" = and i32 %".1100", %".1099"
  %".1102" = and i32 %".1097", %".1098"
  %".1103" = and i32 %".1102", 0
  %".1104" = or i32 %".1101", %".1103"
  %".1105" = and i32 0, %".1098"
  %".1106" = and i32 %".1105", %".1099"
  %".1107" = or i32 %".1104", %".1106"
  %".1108" = and i32 0, %".1098"
  %".1109" = and i32 %".1108", 0
  %".1110" = or i32 %".1107", %".1109"
  %"imad_tmp.59" = mul i32 0, 0
  %"imad.62" = add i32 %"imad_tmp.59", %".1110"
  %"redux_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.8" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.62", i32 %"redux_mask.8")
  %".1111" = xor i32 %".1110", -1
  %".1112" = call i32 @"llvm.cttz.i32"(i32 %".1111", i1 0)
  %".1113" = shl i32 %".1112", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 256;", "r,~{memory}"(i32 %".1113") convergent
  %"imad_tmp.60" = mul i32 0, 0
  %"imad.63" = add i32 %"imad_tmp.60", %"redux_sync_and.7"
  %"isetrp_cmp1.49" = icmp eq i32 %"laneid.5", %"flo.5"
  %"isetrp_src_to_i32.49" = zext i1 1 to i32
  %"isetrp_src_to_i1.49" = icmp ne i32 %"isetrp_src_to_i32.49", 0
  %"isetrp_cmp2.49" = and i1 %"isetrp_cmp1.49", %"isetrp_src_to_i1.49"
  %"P33_to_i32" = zext i1 %"isetrp_cmp2.49" to i32
  %"imad_tmp.61" = mul i32 0, 0
  %"imad.64" = add i32 %"imad_tmp.61", %"redux_sync_and.8"
  br label %"BB_2b00"
BB_2b00:
  %"cond_trunc.44" = trunc i32 %"P33_to_i32" to i1
  %"pbra_cond_to_i32.44" = zext i1 %"cond_trunc.44" to i32
  %"pbra_cond_to_i1.44" = icmp ne i32 %"pbra_cond_to_i32.44", 0
  br i1 %"pbra_cond_to_i1.44", label %"BB_80002b00", label %"BB_2b80"
BB_80002b00:
  %"atoms_addr_memaddr_offset_add.22" = add i32 %".1040", 20
  %"atoms_shared_addr_winoff.22" = and i32 %"atoms_addr_memaddr_offset_add.22", 16777215
  %".1117" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.22"
  %"atoms_ptr.22" = bitcast i8 addrspace(3)* %".1117" to i32 addrspace(3)*
  %"atoms_and.10" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.22", i32 %"imad.64" monotonic
  %"atoms_addr_memaddr_offset_add.23" = add i32 %".1040", 24
  %"atoms_shared_addr_winoff.23" = and i32 %"atoms_addr_memaddr_offset_add.23", 16777215
  %".1118" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.23"
  %"atoms_ptr.23" = bitcast i8 addrspace(3)* %".1118" to i32 addrspace(3)*
  %"atoms_and.11" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.23", i32 %"imad.63" monotonic
  br label %"BB_2b80"
BB_2b40_2bd0:
  call void @"llvm.trap"()
  br label %"BB_2b80"
BB_2b70_2c00:
  call void @"llvm.trap"()
  br label %"BB_2b80"
BB_2b80:
  ret void
BB_80001f60:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
