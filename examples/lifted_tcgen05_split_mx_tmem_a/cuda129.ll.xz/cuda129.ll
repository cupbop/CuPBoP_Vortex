; ModuleID = "tcgen05_split_mx_tmem_a_sm100a_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [3104 x i8], align 16
define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"P109_to_i32" = zext i1 0 to i32
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0050"
BB_0050:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0280", label %"BB_0060"
BB_0060:
  %".24" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".25" = bitcast i8* %".24" to i64*
  %"ldc_const" = load i64, i64* %".25"
  %"UR5:UR4_r0" = trunc i64 %"ldc_const" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x.1", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".26" = xor i32 %"imad", -1
  %".27" = xor i32 508, -1
  %".28" = xor i32 0, -1
  %".29" = and i32 %"imad", 508
  %".30" = and i32 %".29", %".28"
  %".31" = and i32 %"imad", 508
  %".32" = and i32 %".31", 0
  %".33" = or i32 %".30", %".32"
  %"iadd3_o1_64" = zext i32 %".33" to i64
  %"iadd3_o2_64" = zext i32 %"UR5:UR4_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P110_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR5:UR4_r1"
  %"imad_cin_trunc" = trunc i32 %"P110_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R50:R11_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R50:R11_addr_ptr"
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".34" = zext i32 %"cluster_ctarank" to i64
  %".35" = zext i32 %"viadd" to i64
  %".36" = zext i32 24 to i64
  %".37" = shl i64 %".34", %".36"
  %".38" = and i64 %".37", 4294967295
  %".39" = add i64 %".38", %".35"
  %".40" = trunc i64 %".39" to i32
  %"imad_tmp.2" = mul i32 %"imad", 1
  %"imad.2" = add i32 %"imad_tmp.2", %".40"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"imad.2", %"BB_0060"], [%"viadd.2", %"BB_0170"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"BB_0060"], [%"viadd.1", %"BB_0170"]
  %"isetrp_cmp1.1" = icmp uge i32 %"phi.1", 128
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P52_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi", 16777215
  %".42" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".42" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 128
  %"viadd.2" = add i32 %"phi", 512
  br label %"BB_0170"
BB_0170:
  %"cond_trunc.1" = trunc i32 %"P52_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0130", label %"BB_0180"
BB_0180:
  %".46" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".47" = bitcast i8* %".46" to i64*
  %"ldc_const.1" = load i64, i64* %".47"
  %"R5:R4_r0" = trunc i64 %"ldc_const.1" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %".48" = zext i32 %"cluster_ctarank" to i64
  %".49" = zext i32 1024 to i64
  %".50" = zext i32 24 to i64
  %".51" = shl i64 %".48", %".50"
  %".52" = and i64 %".51", 4294967295
  %".53" = add i64 %".52", %".49"
  %".54" = trunc i64 %".53" to i32
  %"imad_tmp.3" = mul i32 %"imad", 1
  %"imad.3" = add i32 %"imad_tmp.3", %".54"
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.4" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad.4" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.4", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P63_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %"R5:R4_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P63_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.5", %"imad_cin_ext.1"
  br label %"BB_0200"
BB_0200:
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_0180"], [%"viadd.3", %"BB_0270"]
  %"phi.3" = phi  i32 [%"imad_with_cin.1", %"BB_0180"], [%"imad_with_cin.2", %"BB_0270"]
  %"phi.4" = phi  i32 [%"iadd3_trunc.1", %"BB_0180"], [%"iadd3_trunc.2", %"BB_0270"]
  %"phi.5" = phi  i32 [%"imad.3", %"BB_0180"], [%"viadd.4", %"BB_0270"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R89:R48_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R89:R48_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P86_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.3" = add i32 %"phi.2", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P124_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %"phi.3"
  %"imad_cin_trunc.2" = trunc i32 %"P124_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.6", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.5", 16777215
  %".56" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".56" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.4" = add i32 %"phi.5", 512
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.2" = trunc i32 %"P86_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0200", label %"BB_0280"
BB_0280:
  %"phi.6" = phi  i32 [0, %"BB_0050"], [%"UR5:UR4_r1", %"BB_0270"]
  %"phi.7" = phi  i32 [0, %"BB_0050"], [%"ldg.1", %"BB_0270"]
  %"phi.8" = phi  i32 [0, %"BB_0050"], [%"viadd.4", %"BB_0270"]
  %"phi.9" = phi  i32 [%"P109_to_i32", %"BB_0050"], [%"P124_to_i32", %"BB_0270"]
  %"isetrp_cmp1.3" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P76_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  br label %"BB_02b0"
BB_02b0:
  %"cond_trunc.3" = trunc i32 %"P76_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002b0", label %"BB_02d0"
BB_800002b0:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"cluster_ctarank.1", %"BB_800002b0"], [%"phi.7", %"BB_02b0"]
  %"phi.11" = phi  i32 [1024, %"BB_800002b0"], [%"phi.8", %"BB_02b0"]
  %"vote_pred_trunc" = trunc i32 %"P76_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P9_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P76_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_02f0"
BB_800002e0:
  %"viadd.5" = add i32 %"phi.11", 2048
  br label %"BB_02f0"
BB_02f0:
  %"phi.12" = phi  i32 [%"viadd.5", %"BB_800002e0"], [%"phi.11", %"BB_02e0"]
  %"cond_trunc.5" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800002f0", label %"BB_0320"
BB_800002f0:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".67" = zext i32 %"iadd3_n2" to i64
  %".68" = zext i32 0 to i64
  %".69" = shl i64 %".68", 32
  %"shf_concat" = or i64 %".67", %".69"
  %"shf_shift_64" = zext i32 11 to i64
  %".70" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".70" to i32
  %".71" = zext i32 %"iadd3_n2" to i64
  %".72" = zext i32 0 to i64
  %".73" = shl i64 %".72", 32
  %"shf_concat.1" = or i64 %".71", %".73"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".74" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".74" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.13" = phi  i32 [%"shf_result", %"BB_800002f0"], [%"phi.6", %"BB_02f0"]
  %"phi.14" = phi  i32 [%"shf_result.1", %"BB_800002f0"], [1, %"BB_02f0"]
  %"vote_pred_trunc.1" = trunc i32 %"P76_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P18_to_i32" = zext i1 %"vote_all.1" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.6" = trunc i32 %"P76_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_80000330", label %"BB_0350"
BB_80000330:
  %".78" = zext i32 %"phi.10" to i64
  %".79" = zext i32 %"phi.12" to i64
  %".80" = zext i32 24 to i64
  %".81" = shl i64 %".78", %".80"
  %".82" = and i64 %".81", 4294967295
  %".83" = add i64 %".82", %".79"
  %".84" = trunc i64 %".83" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.15" = phi  i32 [%".84", %"BB_80000330"], [0, %"BB_0330"]
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.7" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.7", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.15", 16777215
  %".89" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".89" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.14" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".90" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".90" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.8" = trunc i32 %"P30_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0680", label %"BB_0390"
BB_0390:
  %"cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".94" = zext i32 %"cluster_ctarank.2" to i64
  %".95" = zext i32 64 to i64
  %".96" = zext i32 24 to i64
  %".97" = shl i64 %".94", %".96"
  %".98" = and i64 %".97", 4294967295
  %".99" = add i64 %".98", %".95"
  %".100" = trunc i64 %".99" to i32
  %"lds_shared_addr_winoff" = and i32 %".100", 16777215
  %".101" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".101"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P117_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0410"
BB_0410:
  %"cond_trunc.9" = trunc i32 %"P117_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0610", label %"BB_0420"
BB_0420:
  %"allocation_slot_winoff" = and i32 3080, 16777215
  %".104" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".105" = ptrtoint i8 addrspace(3)* %".104" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".105", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P34_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0430"
BB_0430:
  %"cond_trunc.10" = trunc i32 %"P34_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0680", label %"BB_0440"
BB_0440:
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", 1
  %"tmem_alloc_winoff" = and i32 3080, 16777215
  %".109" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".110" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %".111" = load i32, i32 addrspace(3)* %".110"
  %".112" = lshr i32 %".111", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P25_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".113" = xor i32 %"plop3_a_bit", 1
  %".114" = xor i32 %"plop3_b_bit", 1
  %".115" = xor i32 %"plop3_c_bit", 1
  %".116" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".117" = and i32 %".116", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".117", 0
  %"P55_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P55_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P66_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", %".112"
  br label %"BB_04c0"
BB_04c0:
  %"cond_trunc.11" = trunc i32 %"P66_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0560", label %"BB_04d0"
BB_04d0:
  %"tmem_alloc_winoff.1" = and i32 3080, 16777215
  %".120" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".121" = bitcast i8 addrspace(3)* %".120" to i32 addrspace(3)*
  %".122" = load i32, i32 addrspace(3)* %".121"
  %".123" = lshr i32 %".122", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".124" = xor i32 %"plop3_a_bit.1", 1
  %".125" = xor i32 %"plop3_b_bit.1", 1
  %".126" = xor i32 %"plop3_c_bit.1", 1
  %".127" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".128" = and i32 %".127", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".128", 0
  %"P88_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P88_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P99_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", %".123"
  br label %"BB_0550"
BB_0550:
  %"cond_trunc.12" = trunc i32 %"P99_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_04d0", label %"BB_0560"
BB_0560:
  %"phi.16" = phi  i32 [%"imad.8", %"BB_04c0"], [%"imad.9", %"BB_0550"]
  %"viadd.6" = add i32 %"phi.16", 16
  %".131" = zext i32 %"imad.7" to i64
  %".132" = zext i32 0 to i64
  %".133" = shl i64 %".132", 32
  %"shf_concat.2" = or i64 %".131", %".133"
  %"shf_shift_64.2" = zext i32 %"phi.16" to i64
  %".134" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".134" to i32
  %"imad_tmp.9" = mul i32 %"phi.16", 32
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %".135" = zext i32 %"imad.7" to i64
  %".136" = zext i32 0 to i64
  %".137" = shl i64 %".136", 32
  %"shf_concat.3" = or i64 %".135", %".137"
  %"shf_shift_64.3" = zext i32 %"viadd.6" to i64
  %".138" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".138" to i32
  %".139" = zext i32 %"cluster_ctarank.2" to i64
  %".140" = zext i32 1024 to i64
  %".141" = zext i32 24 to i64
  %".142" = shl i64 %".139", %".141"
  %".143" = and i64 %".142", 4294967295
  %".144" = add i64 %".143", %".140"
  %".145" = trunc i64 %".144" to i32
  %".146" = zext i32 %"cluster_ctarank.2" to i64
  %".147" = zext i32 80 to i64
  %".148" = zext i32 24 to i64
  %".149" = shl i64 %".146", %".148"
  %".150" = and i64 %".149", 4294967295
  %".151" = add i64 %".150", %".147"
  %".152" = trunc i64 %".151" to i32
  %".153" = xor i32 %"shf_result.3", -1
  %".154" = xor i32 %"shf_result.2", -1
  %".155" = xor i32 0, -1
  %".156" = and i32 %".153", %"shf_result.2"
  %".157" = and i32 %".156", %".155"
  %".158" = and i32 %".153", %"shf_result.2"
  %".159" = and i32 %".158", 0
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %"shf_result.3", %".154"
  %".162" = and i32 %".161", %".155"
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %"shf_result.3", %".154"
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %"shf_result.3", %"shf_result.2"
  %".168" = and i32 %".167", %".155"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %"shf_result.3", %"shf_result.2"
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %"atoms_shared_addr_winoff" = and i32 %".152", 16777215
  %".173" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".173" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".172" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".145", 2056
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".174" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".174" to i32 addrspace(3)*
  store volatile i32 %"imad.10", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0680"
BB_0610:
  %".177" = zext i32 %"cluster_ctarank.2" to i64
  %".178" = zext i32 1024 to i64
  %".179" = zext i32 24 to i64
  %".180" = shl i64 %".177", %".179"
  %".181" = and i64 %".180", 4294967295
  %".182" = add i64 %".181", %".178"
  %".183" = trunc i64 %".182" to i32
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.10", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".183", 2056
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".184" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".184" to i32 addrspace(3)*
  store volatile i32 %"imad.11", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0650_3020"
BB_0650_3020:
  call void @"llvm.trap"()
  br label %"BB_0680"
BB_0680:
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_06c0"
BB_06c0:
  %"cond_trunc.13" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_1260", label %"BB_06d0"
BB_06d0:
  %"cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".190" = zext i32 %"cluster_ctarank.3" to i64
  %".191" = zext i32 64 to i64
  %".192" = zext i32 24 to i64
  %".193" = shl i64 %".190", %".192"
  %".194" = and i64 %".193", 4294967295
  %".195" = add i64 %".194", %".191"
  %".196" = trunc i64 %".195" to i32
  %"lds_shared_addr_winoff.1" = and i32 %".196", 16777215
  %".197" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds.1" = load volatile i8, i8 addrspace(3)* %".197"
  %"lds_zext.1" = zext i8 %"lds.1" to i32
  %"isetrp_cmp1.9" = icmp ne i32 %"lds_zext.1", 0
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0750"
BB_0750:
  %"cond_trunc.14" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0950", label %"BB_0760"
BB_0760:
  %"allocation_slot_winoff.1" = and i32 3084, 16777215
  %".200" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.1"
  %".201" = ptrtoint i8 addrspace(3)* %".200" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".201", i32 32) convergent
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0770"
BB_0770:
  %"cond_trunc.15" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_09a0", label %"BB_0780"
BB_0780:
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.11", 1
  %"tmem_alloc_winoff.2" = and i32 3084, 16777215
  %".205" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.2"
  %".206" = bitcast i8 addrspace(3)* %".205" to i32 addrspace(3)*
  %".207" = load i32, i32 addrspace(3)* %".206"
  %".208" = lshr i32 %".207", 5
  %"P27_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.2" = trunc i32 %"P27_to_i32" to i1
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 %"lop3_c_trunc.2" to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".209" = xor i32 %"plop3_a_bit.2", 1
  %".210" = xor i32 %"plop3_b_bit.2", 1
  %".211" = xor i32 %"plop3_c_bit.2", 1
  %".212" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".213" = and i32 %".212", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".213", 0
  %"P38_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"sel_pred_trunc.2" = trunc i32 %"P38_to_i32" to i1
  %"sel_pred_not.2" = xor i1 %"sel_pred_trunc.2", -1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_not.2" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 0, i32 4294967295
  %"isetrp_cmp1.10" = icmp ne i32 %"sel.2", 0
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", %".208"
  br label %"BB_0800"
BB_0800:
  %"cond_trunc.16" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_08a0", label %"BB_0810"
BB_0810:
  %"tmem_alloc_winoff.3" = and i32 3084, 16777215
  %".216" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.3"
  %".217" = bitcast i8 addrspace(3)* %".216" to i32 addrspace(3)*
  %".218" = load i32, i32 addrspace(3)* %".217"
  %".219" = lshr i32 %".218", 5
  %"P11_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.3" = trunc i32 %"P11_to_i32" to i1
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 %"lop3_c_trunc.3" to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".220" = xor i32 %"plop3_a_bit.3", 1
  %".221" = xor i32 %"plop3_b_bit.3", 1
  %".222" = xor i32 %"plop3_c_bit.3", 1
  %".223" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".224" = and i32 %".223", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".224", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"sel_pred_trunc.3" = trunc i32 %"P40_to_i32" to i1
  %"sel_pred_not.3" = xor i1 %"sel_pred_trunc.3", -1
  %"sel_pred_to_i32.3" = zext i1 %"sel_pred_not.3" to i32
  %"sel_pred_to_i1.3" = icmp ne i32 %"sel_pred_to_i32.3", 0
  %"sel.3" = select  i1 %"sel_pred_to_i1.3", i32 0, i32 4294967295
  %"isetrp_cmp1.11" = icmp ne i32 %"sel.3", 0
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", %".219"
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.17" = trunc i32 %"P41_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0810", label %"BB_08a0"
BB_08a0:
  %"phi.17" = phi  i32 [%"imad.13", %"BB_0800"], [%"imad.14", %"BB_0890"]
  %"viadd.7" = add i32 %"phi.17", 16
  %".227" = zext i32 %"imad.12" to i64
  %".228" = zext i32 0 to i64
  %".229" = shl i64 %".228", 32
  %"shf_concat.4" = or i64 %".227", %".229"
  %"shf_shift_64.4" = zext i32 %"phi.17" to i64
  %".230" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".230" to i32
  %"imad_tmp.14" = mul i32 %"phi.17", 32
  %"imad.15" = add i32 %"imad_tmp.14", 0
  %".231" = zext i32 %"imad.12" to i64
  %".232" = zext i32 0 to i64
  %".233" = shl i64 %".232", 32
  %"shf_concat.5" = or i64 %".231", %".233"
  %"shf_shift_64.5" = zext i32 %"viadd.7" to i64
  %".234" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".234" to i32
  %".235" = zext i32 %"cluster_ctarank.3" to i64
  %".236" = zext i32 80 to i64
  %".237" = zext i32 24 to i64
  %".238" = shl i64 %".235", %".237"
  %".239" = and i64 %".238", 4294967295
  %".240" = add i64 %".239", %".236"
  %".241" = trunc i64 %".240" to i32
  %".242" = xor i32 %"shf_result.5", -1
  %".243" = xor i32 %"shf_result.4", -1
  %".244" = xor i32 0, -1
  %".245" = and i32 %".242", %"shf_result.4"
  %".246" = and i32 %".245", %".244"
  %".247" = and i32 %".242", %"shf_result.4"
  %".248" = and i32 %".247", 0
  %".249" = or i32 %".246", %".248"
  %".250" = and i32 %"shf_result.5", %".243"
  %".251" = and i32 %".250", %".244"
  %".252" = or i32 %".249", %".251"
  %".253" = and i32 %"shf_result.5", %".243"
  %".254" = and i32 %".253", 0
  %".255" = or i32 %".252", %".254"
  %".256" = and i32 %"shf_result.5", %"shf_result.4"
  %".257" = and i32 %".256", %".244"
  %".258" = or i32 %".255", %".257"
  %".259" = and i32 %"shf_result.5", %"shf_result.4"
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = zext i32 %"cluster_ctarank.3" to i64
  %".263" = zext i32 1024 to i64
  %".264" = zext i32 24 to i64
  %".265" = shl i64 %".262", %".264"
  %".266" = and i64 %".265", 4294967295
  %".267" = add i64 %".266", %".263"
  %".268" = trunc i64 %".267" to i32
  %"atoms_shared_addr_winoff.1" = and i32 %".241", 16777215
  %".269" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".269" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %".261" monotonic
  %"sts_addr_memaddr_offset_add.2" = add i32 %".268", 2060
  %"sts_shared_addr_winoff.4" = and i32 %"sts_addr_memaddr_offset_add.2", 16777215
  %".270" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".270" to i32 addrspace(3)*
  store volatile i32 %"imad.15", i32 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_09a0"
BB_0950:
  %".273" = zext i32 %"cluster_ctarank.3" to i64
  %".274" = zext i32 1024 to i64
  %".275" = zext i32 24 to i64
  %".276" = shl i64 %".273", %".275"
  %".277" = and i64 %".276", 4294967295
  %".278" = add i64 %".277", %".274"
  %".279" = trunc i64 %".278" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.15", -1
  %"sts_addr_memaddr_offset_add.3" = add i32 %".279", 2060
  %"sts_shared_addr_winoff.5" = and i32 %"sts_addr_memaddr_offset_add.3", 16777215
  %".280" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".280" to i32 addrspace(3)*
  store volatile i32 %"imad.16", i32 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_0990_3020"
BB_0990_3020:
  call void @"llvm.trap"()
  br label %"BB_09a0"
BB_09a0:
  %"cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".284" = zext i32 %"cluster_ctarank.4" to i64
  %".285" = zext i32 64 to i64
  %".286" = zext i32 24 to i64
  %".287" = shl i64 %".284", %".286"
  %".288" = and i64 %".287", 4294967295
  %".289" = add i64 %".288", %".285"
  %".290" = trunc i64 %".289" to i32
  %"lds_shared_addr_winoff.2" = and i32 %".290", 16777215
  %".291" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds.2" = load volatile i8, i8 addrspace(3)* %".291"
  %"lds_zext.2" = zext i8 %"lds.2" to i32
  %"isetrp_cmp1.12" = icmp ne i32 %"lds_zext.2", 0
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P43_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  br label %"BB_0a20"
BB_0a20:
  %"cond_trunc.18" = trunc i32 %"P43_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0c30", label %"BB_0a30"
BB_0a30:
  %"allocation_slot_winoff.2" = and i32 3088, 16777215
  %".294" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.2"
  %".295" = ptrtoint i8 addrspace(3)* %".294" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".295", i32 64) convergent
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P45_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0a40"
BB_0a40:
  %"cond_trunc.19" = trunc i32 %"P45_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0c80", label %"BB_0a50"
BB_0a50:
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.16", 1
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.17", 3
  %"tmem_alloc_winoff.4" = and i32 3088, 16777215
  %".299" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.4"
  %".300" = bitcast i8 addrspace(3)* %".299" to i32 addrspace(3)*
  %".301" = load i32, i32 addrspace(3)* %".300"
  %".302" = lshr i32 %".301", 5
  %"P12_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.4" = trunc i32 %"P12_to_i32" to i1
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 %"lop3_c_trunc.4" to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".303" = xor i32 %"plop3_a_bit.4", 1
  %".304" = xor i32 %"plop3_b_bit.4", 1
  %".305" = xor i32 %"plop3_c_bit.4", 1
  %".306" = and i32 %"plop3_a_bit.4", %"plop3_b_bit.4"
  %".307" = and i32 %".306", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".307", 0
  %"P47_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"sel_pred_trunc.4" = trunc i32 %"P47_to_i32" to i1
  %"sel_pred_not.4" = xor i1 %"sel_pred_trunc.4", -1
  %"sel_pred_to_i32.4" = zext i1 %"sel_pred_not.4" to i32
  %"sel_pred_to_i1.4" = icmp ne i32 %"sel_pred_to_i32.4", 0
  %"sel.4" = select  i1 %"sel_pred_to_i1.4", i32 0, i32 4294967295
  %"isetrp_cmp1.13" = icmp ne i32 %"sel.4", 0
  %"isetrp_src_to_i32.13" = zext i1 1 to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P48_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.18", %".302"
  br label %"BB_0ae0"
BB_0ae0:
  %"cond_trunc.20" = trunc i32 %"P48_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0b80", label %"BB_0af0"
BB_0af0:
  %"tmem_alloc_winoff.5" = and i32 3088, 16777215
  %".310" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.5"
  %".311" = bitcast i8 addrspace(3)* %".310" to i32 addrspace(3)*
  %".312" = load i32, i32 addrspace(3)* %".311"
  %".313" = lshr i32 %".312", 5
  %"P14_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.5" = trunc i32 %"P14_to_i32" to i1
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 %"lop3_c_trunc.5" to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".314" = xor i32 %"plop3_a_bit.5", 1
  %".315" = xor i32 %"plop3_b_bit.5", 1
  %".316" = xor i32 %"plop3_c_bit.5", 1
  %".317" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".318" = and i32 %".317", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".318", 0
  %"P49_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"sel_pred_trunc.5" = trunc i32 %"P49_to_i32" to i1
  %"sel_pred_not.5" = xor i1 %"sel_pred_trunc.5", -1
  %"sel_pred_to_i32.5" = zext i1 %"sel_pred_not.5" to i32
  %"sel_pred_to_i1.5" = icmp ne i32 %"sel_pred_to_i32.5", 0
  %"sel.5" = select  i1 %"sel_pred_to_i1.5", i32 0, i32 4294967295
  %"isetrp_cmp1.14" = icmp ne i32 %"sel.5", 0
  %"isetrp_src_to_i32.14" = zext i1 1 to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P50_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.19", %".313"
  br label %"BB_0b70"
BB_0b70:
  %"cond_trunc.21" = trunc i32 %"P50_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0af0", label %"BB_0b80"
BB_0b80:
  %"phi.18" = phi  i32 [%"imad.19", %"BB_0ae0"], [%"imad.20", %"BB_0b70"]
  %"viadd.8" = add i32 %"phi.18", 16
  %".321" = zext i32 %"imad.18" to i64
  %".322" = zext i32 0 to i64
  %".323" = shl i64 %".322", 32
  %"shf_concat.6" = or i64 %".321", %".323"
  %"shf_shift_64.6" = zext i32 %"phi.18" to i64
  %".324" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".324" to i32
  %"imad_tmp.20" = mul i32 %"phi.18", 32
  %"imad.21" = add i32 %"imad_tmp.20", 0
  %".325" = zext i32 %"imad.17" to i64
  %".326" = zext i32 0 to i64
  %".327" = shl i64 %".326", 32
  %"shf_concat.7" = or i64 %".325", %".327"
  %"shf_shift_64.7" = zext i32 %"viadd.8" to i64
  %".328" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".328" to i32
  %".329" = zext i32 %"cluster_ctarank.4" to i64
  %".330" = zext i32 80 to i64
  %".331" = zext i32 24 to i64
  %".332" = shl i64 %".329", %".331"
  %".333" = and i64 %".332", 4294967295
  %".334" = add i64 %".333", %".330"
  %".335" = trunc i64 %".334" to i32
  %".336" = xor i32 %"shf_result.7", -1
  %".337" = xor i32 %"shf_result.6", -1
  %".338" = xor i32 0, -1
  %".339" = and i32 %".336", %"shf_result.6"
  %".340" = and i32 %".339", %".338"
  %".341" = and i32 %".336", %"shf_result.6"
  %".342" = and i32 %".341", 0
  %".343" = or i32 %".340", %".342"
  %".344" = and i32 %"shf_result.7", %".337"
  %".345" = and i32 %".344", %".338"
  %".346" = or i32 %".343", %".345"
  %".347" = and i32 %"shf_result.7", %".337"
  %".348" = and i32 %".347", 0
  %".349" = or i32 %".346", %".348"
  %".350" = and i32 %"shf_result.7", %"shf_result.6"
  %".351" = and i32 %".350", %".338"
  %".352" = or i32 %".349", %".351"
  %".353" = and i32 %"shf_result.7", %"shf_result.6"
  %".354" = and i32 %".353", 0
  %".355" = or i32 %".352", %".354"
  %".356" = zext i32 %"cluster_ctarank.4" to i64
  %".357" = zext i32 1024 to i64
  %".358" = zext i32 24 to i64
  %".359" = shl i64 %".356", %".358"
  %".360" = and i64 %".359", 4294967295
  %".361" = add i64 %".360", %".357"
  %".362" = trunc i64 %".361" to i32
  %"atoms_shared_addr_winoff.2" = and i32 %".335", 16777215
  %".363" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".363" to i32 addrspace(3)*
  %"atoms_or.2" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.2", i32 %".355" monotonic
  %"sts_addr_memaddr_offset_add.4" = add i32 %".362", 2064
  %"sts_shared_addr_winoff.6" = and i32 %"sts_addr_memaddr_offset_add.4", 16777215
  %".364" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".364" to i32 addrspace(3)*
  store volatile i32 %"imad.21", i32 addrspace(3)* %"sts_shared_addr_cast.6"
  br label %"BB_0c80"
BB_0c30:
  %".367" = zext i32 %"cluster_ctarank.4" to i64
  %".368" = zext i32 1024 to i64
  %".369" = zext i32 24 to i64
  %".370" = shl i64 %".367", %".369"
  %".371" = and i64 %".370", 4294967295
  %".372" = add i64 %".371", %".368"
  %".373" = trunc i64 %".372" to i32
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.21", -1
  %"sts_addr_memaddr_offset_add.5" = add i32 %".373", 2064
  %"sts_shared_addr_winoff.7" = and i32 %"sts_addr_memaddr_offset_add.5", 16777215
  %".374" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.7"
  %"sts_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".374" to i32 addrspace(3)*
  store volatile i32 %"imad.22", i32 addrspace(3)* %"sts_shared_addr_cast.7"
  br label %"BB_0c70_3020"
BB_0c70_3020:
  call void @"llvm.trap"()
  br label %"BB_0c80"
BB_0c80:
  %"cluster_ctarank.5" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".378" = zext i32 %"cluster_ctarank.5" to i64
  %".379" = zext i32 64 to i64
  %".380" = zext i32 24 to i64
  %".381" = shl i64 %".378", %".380"
  %".382" = and i64 %".381", 4294967295
  %".383" = add i64 %".382", %".379"
  %".384" = trunc i64 %".383" to i32
  %"lds_shared_addr_winoff.3" = and i32 %".384", 16777215
  %".385" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds.3" = load volatile i8, i8 addrspace(3)* %".385"
  %"lds_zext.3" = zext i8 %"lds.3" to i32
  %"isetrp_cmp1.15" = icmp ne i32 %"lds_zext.3", 0
  %"isetrp_src_to_i32.15" = zext i1 1 to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P53_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  br label %"BB_0d00"
BB_0d00:
  %"cond_trunc.22" = trunc i32 %"P53_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0f10", label %"BB_0d10"
BB_0d10:
  %"allocation_slot_winoff.3" = and i32 3092, 16777215
  %".388" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.3"
  %".389" = ptrtoint i8 addrspace(3)* %".388" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".389", i32 128) convergent
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P54_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0d20"
BB_0d20:
  %"cond_trunc.23" = trunc i32 %"P54_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.23", -1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_0f60", label %"BB_0d30"
BB_0d30:
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.22", 1
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.23", 15
  %"tmem_alloc_winoff.6" = and i32 3092, 16777215
  %".393" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.6"
  %".394" = bitcast i8 addrspace(3)* %".393" to i32 addrspace(3)*
  %".395" = load i32, i32 addrspace(3)* %".394"
  %".396" = lshr i32 %".395", 5
  %"P16_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.6" = trunc i32 %"P16_to_i32" to i1
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 %"lop3_c_trunc.6" to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".397" = xor i32 %"plop3_a_bit.6", 1
  %".398" = xor i32 %"plop3_b_bit.6", 1
  %".399" = xor i32 %"plop3_c_bit.6", 1
  %".400" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".401" = and i32 %".400", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".401", 0
  %"P57_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"sel_pred_trunc.6" = trunc i32 %"P57_to_i32" to i1
  %"sel_pred_not.6" = xor i1 %"sel_pred_trunc.6", -1
  %"sel_pred_to_i32.6" = zext i1 %"sel_pred_not.6" to i32
  %"sel_pred_to_i1.6" = icmp ne i32 %"sel_pred_to_i32.6", 0
  %"sel.6" = select  i1 %"sel_pred_to_i1.6", i32 0, i32 4294967295
  %"isetrp_cmp1.16" = icmp ne i32 %"sel.6", 0
  %"isetrp_src_to_i32.16" = zext i1 1 to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.24", %".396"
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.24" = trunc i32 %"P58_to_i32" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_0e60", label %"BB_0dd0"
BB_0dd0:
  %"tmem_alloc_winoff.7" = and i32 3092, 16777215
  %".404" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.7"
  %".405" = bitcast i8 addrspace(3)* %".404" to i32 addrspace(3)*
  %".406" = load i32, i32 addrspace(3)* %".405"
  %".407" = lshr i32 %".406", 5
  %"P19_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.7" = trunc i32 %"P19_to_i32" to i1
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 %"lop3_c_trunc.7" to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".408" = xor i32 %"plop3_a_bit.7", 1
  %".409" = xor i32 %"plop3_b_bit.7", 1
  %".410" = xor i32 %"plop3_c_bit.7", 1
  %".411" = and i32 %"plop3_a_bit.7", %"plop3_b_bit.7"
  %".412" = and i32 %".411", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".412", 0
  %"P59_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"sel_pred_trunc.7" = trunc i32 %"P59_to_i32" to i1
  %"sel_pred_not.7" = xor i1 %"sel_pred_trunc.7", -1
  %"sel_pred_to_i32.7" = zext i1 %"sel_pred_not.7" to i32
  %"sel_pred_to_i1.7" = icmp ne i32 %"sel_pred_to_i32.7", 0
  %"sel.7" = select  i1 %"sel_pred_to_i1.7", i32 0, i32 4294967295
  %"isetrp_cmp1.17" = icmp ne i32 %"sel.7", 0
  %"isetrp_src_to_i32.17" = zext i1 1 to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P61_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.25", %".407"
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.25" = trunc i32 %"P61_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.25", -1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_0dd0", label %"BB_0e60"
BB_0e60:
  %"phi.19" = phi  i32 [%"imad.25", %"BB_0dc0"], [%"imad.26", %"BB_0e50"]
  %"viadd.9" = add i32 %"phi.19", 16
  %".415" = zext i32 %"imad.24" to i64
  %".416" = zext i32 0 to i64
  %".417" = shl i64 %".416", 32
  %"shf_concat.8" = or i64 %".415", %".417"
  %"shf_shift_64.8" = zext i32 %"phi.19" to i64
  %".418" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".418" to i32
  %"imad_tmp.26" = mul i32 %"phi.19", 32
  %"imad.27" = add i32 %"imad_tmp.26", 0
  %".419" = zext i32 %"imad.23" to i64
  %".420" = zext i32 0 to i64
  %".421" = shl i64 %".420", 32
  %"shf_concat.9" = or i64 %".419", %".421"
  %"shf_shift_64.9" = zext i32 %"viadd.9" to i64
  %".422" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".422" to i32
  %".423" = zext i32 %"cluster_ctarank.5" to i64
  %".424" = zext i32 80 to i64
  %".425" = zext i32 24 to i64
  %".426" = shl i64 %".423", %".425"
  %".427" = and i64 %".426", 4294967295
  %".428" = add i64 %".427", %".424"
  %".429" = trunc i64 %".428" to i32
  %".430" = xor i32 %"shf_result.9", -1
  %".431" = xor i32 %"shf_result.8", -1
  %".432" = xor i32 0, -1
  %".433" = and i32 %".430", %"shf_result.8"
  %".434" = and i32 %".433", %".432"
  %".435" = and i32 %".430", %"shf_result.8"
  %".436" = and i32 %".435", 0
  %".437" = or i32 %".434", %".436"
  %".438" = and i32 %"shf_result.9", %".431"
  %".439" = and i32 %".438", %".432"
  %".440" = or i32 %".437", %".439"
  %".441" = and i32 %"shf_result.9", %".431"
  %".442" = and i32 %".441", 0
  %".443" = or i32 %".440", %".442"
  %".444" = and i32 %"shf_result.9", %"shf_result.8"
  %".445" = and i32 %".444", %".432"
  %".446" = or i32 %".443", %".445"
  %".447" = and i32 %"shf_result.9", %"shf_result.8"
  %".448" = and i32 %".447", 0
  %".449" = or i32 %".446", %".448"
  %".450" = zext i32 %"cluster_ctarank.5" to i64
  %".451" = zext i32 1024 to i64
  %".452" = zext i32 24 to i64
  %".453" = shl i64 %".450", %".452"
  %".454" = and i64 %".453", 4294967295
  %".455" = add i64 %".454", %".451"
  %".456" = trunc i64 %".455" to i32
  %"atoms_shared_addr_winoff.3" = and i32 %".429", 16777215
  %".457" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".457" to i32 addrspace(3)*
  %"atoms_or.3" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.3", i32 %".449" monotonic
  %"sts_addr_memaddr_offset_add.6" = add i32 %".456", 2068
  %"sts_shared_addr_winoff.8" = and i32 %"sts_addr_memaddr_offset_add.6", 16777215
  %".458" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.8"
  %"sts_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".458" to i32 addrspace(3)*
  store volatile i32 %"imad.27", i32 addrspace(3)* %"sts_shared_addr_cast.8"
  br label %"BB_0f60"
BB_0f10:
  %".461" = zext i32 %"cluster_ctarank.5" to i64
  %".462" = zext i32 1024 to i64
  %".463" = zext i32 24 to i64
  %".464" = shl i64 %".461", %".463"
  %".465" = and i64 %".464", 4294967295
  %".466" = add i64 %".465", %".462"
  %".467" = trunc i64 %".466" to i32
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.28" = add i32 %"imad_tmp.27", -1
  %"sts_addr_memaddr_offset_add.7" = add i32 %".467", 2068
  %"sts_shared_addr_winoff.9" = and i32 %"sts_addr_memaddr_offset_add.7", 16777215
  %".468" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.9"
  %"sts_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".468" to i32 addrspace(3)*
  store volatile i32 %"imad.28", i32 addrspace(3)* %"sts_shared_addr_cast.9"
  br label %"BB_0f50_3020"
BB_0f50_3020:
  call void @"llvm.trap"()
  br label %"BB_0f60"
BB_0f60:
  %"cluster_ctarank.6" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".472" = zext i32 %"cluster_ctarank.6" to i64
  %".473" = zext i32 64 to i64
  %".474" = zext i32 24 to i64
  %".475" = shl i64 %".472", %".474"
  %".476" = and i64 %".475", 4294967295
  %".477" = add i64 %".476", %".473"
  %".478" = trunc i64 %".477" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".478", 16777215
  %".479" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds.4" = load volatile i8, i8 addrspace(3)* %".479"
  %"lds_zext.4" = zext i8 %"lds.4" to i32
  %"isetrp_cmp1.18" = icmp ne i32 %"lds_zext.4", 0
  %"isetrp_src_to_i32.18" = zext i1 1 to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P62_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  br label %"BB_0fe0"
BB_0fe0:
  %"cond_trunc.26" = trunc i32 %"P62_to_i32" to i1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_trunc.26" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_11f0", label %"BB_0ff0"
BB_0ff0:
  %"allocation_slot_winoff.4" = and i32 3096, 16777215
  %".482" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.4"
  %".483" = ptrtoint i8 addrspace(3)* %".482" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".483", i32 256) convergent
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P64_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_1000"
BB_1000:
  %"cond_trunc.27" = trunc i32 %"P64_to_i32" to i1
  %"cond_not.15" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.15" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_1260", label %"BB_1010"
BB_1010:
  %"imad_tmp.28" = mul i32 0, 0
  %"imad.29" = add i32 %"imad_tmp.28", 1
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.29", 255
  %"tmem_alloc_winoff.8" = and i32 3096, 16777215
  %".487" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.8"
  %".488" = bitcast i8 addrspace(3)* %".487" to i32 addrspace(3)*
  %".489" = load i32, i32 addrspace(3)* %".488"
  %".490" = lshr i32 %".489", 5
  %"P20_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.8" = trunc i32 %"P20_to_i32" to i1
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 %"lop3_c_trunc.8" to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".491" = xor i32 %"plop3_a_bit.8", 1
  %".492" = xor i32 %"plop3_b_bit.8", 1
  %".493" = xor i32 %"plop3_c_bit.8", 1
  %".494" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".495" = and i32 %".494", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".495", 0
  %"P67_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"sel_pred_trunc.8" = trunc i32 %"P67_to_i32" to i1
  %"sel_pred_not.8" = xor i1 %"sel_pred_trunc.8", -1
  %"sel_pred_to_i32.8" = zext i1 %"sel_pred_not.8" to i32
  %"sel_pred_to_i1.8" = icmp ne i32 %"sel_pred_to_i32.8", 0
  %"sel.8" = select  i1 %"sel_pred_to_i1.8", i32 0, i32 4294967295
  %"isetrp_cmp1.19" = icmp ne i32 %"sel.8", 0
  %"isetrp_src_to_i32.19" = zext i1 1 to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P68_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.30", %".490"
  br label %"BB_10a0"
BB_10a0:
  %"cond_trunc.28" = trunc i32 %"P68_to_i32" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_1140", label %"BB_10b0"
BB_10b0:
  %"tmem_alloc_winoff.9" = and i32 3096, 16777215
  %".498" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.9"
  %".499" = bitcast i8 addrspace(3)* %".498" to i32 addrspace(3)*
  %".500" = load i32, i32 addrspace(3)* %".499"
  %".501" = lshr i32 %".500", 5
  %"P21_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.9" = trunc i32 %"P21_to_i32" to i1
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 %"lop3_c_trunc.9" to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".502" = xor i32 %"plop3_a_bit.9", 1
  %".503" = xor i32 %"plop3_b_bit.9", 1
  %".504" = xor i32 %"plop3_c_bit.9", 1
  %".505" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".506" = and i32 %".505", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".506", 0
  %"P70_to_i32" = zext i1 %"plop3_pred.9" to i32
  %"sel_pred_trunc.9" = trunc i32 %"P70_to_i32" to i1
  %"sel_pred_not.9" = xor i1 %"sel_pred_trunc.9", -1
  %"sel_pred_to_i32.9" = zext i1 %"sel_pred_not.9" to i32
  %"sel_pred_to_i1.9" = icmp ne i32 %"sel_pred_to_i32.9", 0
  %"sel.9" = select  i1 %"sel_pred_to_i1.9", i32 0, i32 4294967295
  %"isetrp_cmp1.20" = icmp ne i32 %"sel.9", 0
  %"isetrp_src_to_i32.20" = zext i1 1 to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P71_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.31", %".501"
  br label %"BB_1130"
BB_1130:
  %"cond_trunc.29" = trunc i32 %"P71_to_i32" to i1
  %"cond_not.16" = xor i1 %"cond_trunc.29", -1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_not.16" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_10b0", label %"BB_1140"
BB_1140:
  %"phi.20" = phi  i32 [%"imad.31", %"BB_10a0"], [%"imad.32", %"BB_1130"]
  %"viadd.10" = add i32 %"phi.20", 16
  %".509" = zext i32 %"imad.30" to i64
  %".510" = zext i32 0 to i64
  %".511" = shl i64 %".510", 32
  %"shf_concat.10" = or i64 %".509", %".511"
  %"shf_shift_64.10" = zext i32 %"phi.20" to i64
  %".512" = shl i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_result.10" = trunc i64 %".512" to i32
  %"imad_tmp.32" = mul i32 %"phi.20", 32
  %"imad.33" = add i32 %"imad_tmp.32", 0
  %".513" = zext i32 %"imad.29" to i64
  %".514" = zext i32 0 to i64
  %".515" = shl i64 %".514", 32
  %"shf_concat.11" = or i64 %".513", %".515"
  %"shf_shift_64.11" = zext i32 %"viadd.10" to i64
  %".516" = shl i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_result.11" = trunc i64 %".516" to i32
  %".517" = zext i32 %"cluster_ctarank.6" to i64
  %".518" = zext i32 1024 to i64
  %".519" = zext i32 24 to i64
  %".520" = shl i64 %".517", %".519"
  %".521" = and i64 %".520", 4294967295
  %".522" = add i64 %".521", %".518"
  %".523" = trunc i64 %".522" to i32
  %".524" = zext i32 %"cluster_ctarank.6" to i64
  %".525" = zext i32 80 to i64
  %".526" = zext i32 24 to i64
  %".527" = shl i64 %".524", %".526"
  %".528" = and i64 %".527", 4294967295
  %".529" = add i64 %".528", %".525"
  %".530" = trunc i64 %".529" to i32
  %".531" = xor i32 %"shf_result.11", -1
  %".532" = xor i32 %"shf_result.10", -1
  %".533" = xor i32 0, -1
  %".534" = and i32 %".531", %"shf_result.10"
  %".535" = and i32 %".534", %".533"
  %".536" = and i32 %".531", %"shf_result.10"
  %".537" = and i32 %".536", 0
  %".538" = or i32 %".535", %".537"
  %".539" = and i32 %"shf_result.11", %".532"
  %".540" = and i32 %".539", %".533"
  %".541" = or i32 %".538", %".540"
  %".542" = and i32 %"shf_result.11", %".532"
  %".543" = and i32 %".542", 0
  %".544" = or i32 %".541", %".543"
  %".545" = and i32 %"shf_result.11", %"shf_result.10"
  %".546" = and i32 %".545", %".533"
  %".547" = or i32 %".544", %".546"
  %".548" = and i32 %"shf_result.11", %"shf_result.10"
  %".549" = and i32 %".548", 0
  %".550" = or i32 %".547", %".549"
  %"atoms_shared_addr_winoff.4" = and i32 %".530", 16777215
  %".551" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.4"
  %"atoms_ptr.4" = bitcast i8 addrspace(3)* %".551" to i32 addrspace(3)*
  %"atoms_or.4" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.4", i32 %".550" monotonic
  %"sts_addr_memaddr_offset_add.8" = add i32 %".523", 2072
  %"sts_shared_addr_winoff.10" = and i32 %"sts_addr_memaddr_offset_add.8", 16777215
  %".552" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.10"
  %"sts_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".552" to i32 addrspace(3)*
  store volatile i32 %"imad.33", i32 addrspace(3)* %"sts_shared_addr_cast.10"
  br label %"BB_1260"
BB_11f0:
  %".555" = zext i32 %"cluster_ctarank.6" to i64
  %".556" = zext i32 1024 to i64
  %".557" = zext i32 24 to i64
  %".558" = shl i64 %".555", %".557"
  %".559" = and i64 %".558", 4294967295
  %".560" = add i64 %".559", %".556"
  %".561" = trunc i64 %".560" to i32
  %"imad_tmp.33" = mul i32 0, 0
  %"imad.34" = add i32 %"imad_tmp.33", -1
  %"sts_addr_memaddr_offset_add.9" = add i32 %".561", 2072
  %"sts_shared_addr_winoff.11" = and i32 %"sts_addr_memaddr_offset_add.9", 16777215
  %".562" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.11"
  %"sts_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".562" to i32 addrspace(3)*
  store volatile i32 %"imad.34", i32 addrspace(3)* %"sts_shared_addr_cast.11"
  br label %"BB_1230_3020"
BB_1230_3020:
  call void @"llvm.trap"()
  br label %"BB_1260"
BB_1260:
  %"isetrp_cmp1.21" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.21" = zext i1 1 to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P72_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %".566" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".567" = bitcast i8* %".566" to i64*
  %"ldc_const.2" = load i64, i64* %".567"
  %"R19:R18_r0" = trunc i64 %"ldc_const.2" to i32
  %"R19:R18_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"imad_tmp.34" = mul i32 %"tid_x.1", 18
  %"imad.35" = add i32 %"imad_tmp.34", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.35" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.36" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R19:R18_r0.1" = trunc i64 %"imad.36" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"imad.36", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R77:R45_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R77:R45_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R77:R45_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R77:R45_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R77:R45_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R77:R45_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R77:R45_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R77:R45_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.7"
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.35" = mul i32 %"tid_x.1", 65536
  %"imad.37" = add i32 %"imad_tmp.35", 0
  %".568" = xor i32 %"imad.37", -1
  %".569" = xor i32 65011712, -1
  %".570" = xor i32 0, -1
  %".571" = and i32 %"imad.37", 65011712
  %".572" = and i32 %".571", %".570"
  %".573" = and i32 %"imad.37", 65011712
  %".574" = and i32 %".573", 0
  %".575" = or i32 %".572", %".574"
  %".576" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".577" = zext i32 1024 to i64
  %".578" = zext i32 24 to i64
  %".579" = shl i64 %".576", %".578"
  %".580" = and i64 %".579", 4294967295
  %".581" = add i64 %".580", %".577"
  %".582" = trunc i64 %".581" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".583" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".583" to i64 addrspace(3)*
  %"lds.5" = load volatile i64, i64 addrspace(3)* %"lds_shared_addr_cast"
  %"R13:R12_r0" = trunc i64 %"lds.5" to i32
  %"R13:R12_r1_shift" = lshr i64 %"lds.5", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.36" = mul i32 %"R13:R12_r1", 1
  %"imad.38" = add i32 %"imad_tmp.36", %".575"
  %"sttm_memaddr_offset_add" = add i32 %"imad.38", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.38", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R77:R45_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R77:R45_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R77:R45_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R77:R45_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R77:R45_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R77:R45_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R77:R45_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R77:R45_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.15"
  %"imad_addend_neg" = sub i32 0, %"R13:R12_r0"
  %"imad_tmp.37" = mul i32 %"R13:R12_r1", 1
  %"imad.39" = add i32 %"imad_tmp.37", %"imad_addend_neg"
  %"imad_tmp.38" = mul i32 %".575", 1
  %"imad.40" = add i32 %"imad_tmp.38", %"R13:R12_r0"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.38", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.38", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_1530"
BB_1530:
  %"cond_trunc.30" = trunc i32 %"P72_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_18a0", label %"BB_1540"
BB_1540:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".593" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".593" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.1" = add i32 1024, 1024
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %".594" = zext i32 0 to i64
  %".595" = zext i32 %".582" to i64
  %".596" = shl i64 %".595", 32
  %"shf_concat.12" = or i64 %".594", %".596"
  %"shf_shift_64.12" = zext i32 4 to i64
  %".597" = lshr i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_hi" = lshr i64 %".597", 32
  %"shf_result.12" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".598" = xor i32 %"plop3_a_bit.10", 1
  %".599" = xor i32 %"plop3_b_bit.10", 1
  %".600" = xor i32 %"plop3_c_bit.10", 1
  %".601" = and i32 %"plop3_a_bit.10", %"plop3_b_bit.10"
  %".602" = and i32 %".601", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".602", 0
  %"P74_to_i32" = zext i1 %"plop3_pred.10" to i32
  %".603" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".604" = zext i32 %"iadd3_n2.1" to i64
  %".605" = zext i32 24 to i64
  %".606" = shl i64 %".603", %".605"
  %".607" = and i64 %".606", 4294967295
  %".608" = add i64 %".607", %".604"
  %".609" = trunc i64 %".608" to i32
  %".610" = xor i32 %"shf_result.12", -1
  %".611" = xor i32 16376, -1
  %".612" = xor i32 0, -1
  %".613" = and i32 %"shf_result.12", 16376
  %".614" = and i32 %".613", %".612"
  %".615" = and i32 %"shf_result.12", 16376
  %".616" = and i32 %".615", 0
  %".617" = or i32 %".614", %".616"
  %".618" = zext i32 0 to i64
  %".619" = zext i32 %".609" to i64
  %".620" = shl i64 %".619", 32
  %"shf_concat.13" = or i64 %".618", %".620"
  %"shf_shift_64.13" = zext i32 4 to i64
  %".621" = lshr i64 %"shf_concat.13", %"shf_shift_64.13"
  %"shf_hi.1" = lshr i64 %".621", 32
  %"shf_result.13" = trunc i64 %"shf_hi.1" to i32
  %".622" = xor i32 %".617", -1
  %".623" = xor i32 524288, -1
  %".624" = xor i32 0, -1
  %".625" = and i32 %".622", 524288
  %".626" = and i32 %".625", %".624"
  %".627" = and i32 %".622", 524288
  %".628" = and i32 %".627", 0
  %".629" = or i32 %".626", %".628"
  %".630" = and i32 %".617", %".623"
  %".631" = and i32 %".630", %".624"
  %".632" = or i32 %".629", %".631"
  %".633" = and i32 %".617", %".623"
  %".634" = and i32 %".633", 0
  %".635" = or i32 %".632", %".634"
  %".636" = and i32 %".617", 524288
  %".637" = and i32 %".636", %".624"
  %".638" = or i32 %".635", %".637"
  %".639" = and i32 %".617", 524288
  %".640" = and i32 %".639", 0
  %".641" = or i32 %".638", %".640"
  %".642" = xor i32 %"shf_result.13", -1
  %".643" = xor i32 16376, -1
  %".644" = xor i32 0, -1
  %".645" = and i32 %"shf_result.13", 16376
  %".646" = and i32 %".645", %".644"
  %".647" = and i32 %"shf_result.13", 16376
  %".648" = and i32 %".647", 0
  %".649" = or i32 %".646", %".648"
  %".650" = xor i32 %".649", -1
  %".651" = xor i32 524288, -1
  %".652" = xor i32 0, -1
  %".653" = and i32 %".650", 524288
  %".654" = and i32 %".653", %".652"
  %".655" = and i32 %".650", 524288
  %".656" = and i32 %".655", 0
  %".657" = or i32 %".654", %".656"
  %".658" = and i32 %".649", %".651"
  %".659" = and i32 %".658", %".652"
  %".660" = or i32 %".657", %".659"
  %".661" = and i32 %".649", %".651"
  %".662" = and i32 %".661", 0
  %".663" = or i32 %".660", %".662"
  %".664" = and i32 %".649", 524288
  %".665" = and i32 %".664", %".652"
  %".666" = or i32 %".663", %".665"
  %".667" = and i32 %".649", 524288
  %".668" = and i32 %".667", 0
  %".669" = or i32 %".666", %".668"
  %"iadd3_n1.2" = add i32 %"imad.39", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", %"lds.6"
  br label %"BB_1650"
BB_1650:
  %"phi.21" = phi  i32 [%"phi.9", %"BB_1540"], [%"P5_to_i32", %"BB_1680"]
  %"phi.22" = phi  i32 [%"P74_to_i32", %"BB_1540"], [%"phi.24", %"BB_1680"]
  %"cond_trunc.31" = trunc i32 %"phi.22" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_80001650", label %"BB_1660"
BB_80001650:
  %"elect_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"election.5" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.5")
  %"elect_p.5" = extractvalue {i32, i1} %"election.5", 1
  %"P3_to_i32" = zext i1 %"elect_p.5" to i32
  br label %"BB_1660"
BB_1660:
  %"phi.23" = phi  i32 [%"P3_to_i32", %"BB_80001650"], [%"phi.21", %"BB_1650"]
  %"mma_b_r0_ext" = zext i32 %".669" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".673" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".674" = sub i64 %".673", 0
  %".675" = lshr i64 %".674", 4
  %".676" = add i64 %"mma_b_packed_1", %".675"
  %".677" = and i64 %".676", 16383
  %".678" = and i64 %"mma_b_packed_1", -16384
  %".679" = or i64 %".678", %".677"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.6", i32 %"iadd3_n2.2", i64 %".679", i32 134746256, i32 %"mma_arg_zext")
  br label %"BB_1670"
BB_1670:
  %"cond_trunc.32" = trunc i32 %"phi.23" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_80001670", label %"BB_1680"
BB_80001670:
  %"lop3_a_trunc" = trunc i32 %"phi.23" to i1
  %"lop3_a_cast_zext.11" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".683" = xor i32 %"plop3_a_bit.11", 1
  %".684" = xor i32 %"plop3_b_bit.11", 1
  %".685" = xor i32 %"plop3_c_bit.11", 1
  %".686" = and i32 %".683", %"plop3_b_bit.11"
  %".687" = and i32 %".686", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".687", 0
  %"P78_to_i32" = zext i1 %"plop3_pred.11" to i32
  br label %"BB_1680"
BB_1680:
  %"phi.24" = phi  i32 [%"P78_to_i32", %"BB_80001670"], [%"phi.22", %"BB_1670"]
  %"lop3_a_cast_zext.12" = zext i1 1 to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".689" = xor i32 %"plop3_a_bit.12", 1
  %".690" = xor i32 %"plop3_b_bit.12", 1
  %".691" = xor i32 %"plop3_c_bit.12", 1
  %".692" = and i32 %".689", %"plop3_b_bit.12"
  %".693" = and i32 %".692", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".693", 0
  %"P5_to_i32" = zext i1 %"plop3_pred.12" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.24" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_1650", label %"BB_16a0"
BB_16a0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".695" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".695" to i32 addrspace(3)*
  %"lds.7" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.13" = zext i1 1 to i32
  %"lop3_b_cast_zext.13" = zext i1 1 to i32
  %"lop3_c_cast_zext.13" = zext i1 1 to i32
  %"plop3_a_bit.13" = and i32 %"lop3_a_cast_zext.13", 1
  %"plop3_b_bit.13" = and i32 %"lop3_b_cast_zext.13", 1
  %"plop3_c_bit.13" = and i32 %"lop3_c_cast_zext.13", 1
  %".696" = xor i32 %"plop3_a_bit.13", 1
  %".697" = xor i32 %"plop3_b_bit.13", 1
  %".698" = xor i32 %"plop3_c_bit.13", 1
  %".699" = and i32 %"plop3_a_bit.13", %"plop3_b_bit.13"
  %".700" = and i32 %".699", %"plop3_c_bit.13"
  %"plop3_pred.13" = icmp ne i32 %".700", 0
  %"P80_to_i32" = zext i1 %"plop3_pred.13" to i32
  %"iadd3_n1.3" = add i32 %"imad.39", %"lds.7"
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"iadd3_n2.3", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"iadd3_n2.3", 4
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_1720"
BB_1720:
  %"phi.25" = phi  i32 [%"P5_to_i32", %"BB_16a0"], [%"P113_to_i32", %"BB_1750"]
  %"phi.26" = phi  i32 [%"P80_to_i32", %"BB_16a0"], [%"phi.28", %"BB_1750"]
  %"cond_trunc.33" = trunc i32 %"phi.26" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_80001720", label %"BB_1730"
BB_80001720:
  %"elect_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"election.6" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.6")
  %"elect_p.6" = extractvalue {i32, i1} %"election.6", 1
  %"P7_to_i32" = zext i1 %"elect_p.6" to i32
  br label %"BB_1730"
BB_1730:
  %"phi.27" = phi  i32 [%"P7_to_i32", %"BB_80001720"], [%"phi.25", %"BB_1720"]
  %"mma_b_r0_ext.1" = zext i32 %".641" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".704" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".705" = sub i64 %".704", 0
  %".706" = lshr i64 %".705", 4
  %".707" = add i64 %"mma_b_packed_1.1", %".706"
  %".708" = and i64 %".707", 16383
  %".709" = and i64 %"mma_b_packed_1.1", -16384
  %".710" = or i64 %".709", %".708"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.7", i32 %"iadd3_n2.4", i64 %".710", i32 679743664, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.3", i32 %"iadd3_n2.5")
  br label %"BB_1740"
BB_1740:
  %"cond_trunc.34" = trunc i32 %"phi.27" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_80001740", label %"BB_1750"
BB_80001740:
  %"lop3_a_trunc.1" = trunc i32 %"phi.27" to i1
  %"lop3_a_cast_zext.14" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.14" = zext i1 1 to i32
  %"lop3_c_cast_zext.14" = zext i1 1 to i32
  %"plop3_a_bit.14" = and i32 %"lop3_a_cast_zext.14", 1
  %"plop3_b_bit.14" = and i32 %"lop3_b_cast_zext.14", 1
  %"plop3_c_bit.14" = and i32 %"lop3_c_cast_zext.14", 1
  %".714" = xor i32 %"plop3_a_bit.14", 1
  %".715" = xor i32 %"plop3_b_bit.14", 1
  %".716" = xor i32 %"plop3_c_bit.14", 1
  %".717" = and i32 %".714", %"plop3_b_bit.14"
  %".718" = and i32 %".717", %"plop3_c_bit.14"
  %"plop3_pred.14" = icmp ne i32 %".718", 0
  %"P82_to_i32" = zext i1 %"plop3_pred.14" to i32
  br label %"BB_1750"
BB_1750:
  %"phi.28" = phi  i32 [%"P82_to_i32", %"BB_80001740"], [%"phi.26", %"BB_1740"]
  %"lop3_a_cast_zext.15" = zext i1 1 to i32
  %"lop3_b_cast_zext.15" = zext i1 1 to i32
  %"lop3_c_cast_zext.15" = zext i1 1 to i32
  %"plop3_a_bit.15" = and i32 %"lop3_a_cast_zext.15", 1
  %"plop3_b_bit.15" = and i32 %"lop3_b_cast_zext.15", 1
  %"plop3_c_bit.15" = and i32 %"lop3_c_cast_zext.15", 1
  %".720" = xor i32 %"plop3_a_bit.15", 1
  %".721" = xor i32 %"plop3_b_bit.15", 1
  %".722" = xor i32 %"plop3_c_bit.15", 1
  %".723" = and i32 %".720", %"plop3_b_bit.15"
  %".724" = and i32 %".723", %"plop3_c_bit.15"
  %"plop3_pred.15" = icmp ne i32 %".724", 0
  %"P113_to_i32" = zext i1 %"plop3_pred.15" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.28" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_1720", label %"BB_1770"
BB_1770:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.8" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".726" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.8"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".726" to i32 addrspace(3)*
  %"lds.8" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.16" = zext i1 1 to i32
  %"lop3_b_cast_zext.16" = zext i1 1 to i32
  %"lop3_c_cast_zext.16" = zext i1 1 to i32
  %"plop3_a_bit.16" = and i32 %"lop3_a_cast_zext.16", 1
  %"plop3_b_bit.16" = and i32 %"lop3_b_cast_zext.16", 1
  %"plop3_c_bit.16" = and i32 %"lop3_c_cast_zext.16", 1
  %".727" = xor i32 %"plop3_a_bit.16", 1
  %".728" = xor i32 %"plop3_b_bit.16", 1
  %".729" = xor i32 %"plop3_c_bit.16", 1
  %".730" = and i32 %"plop3_a_bit.16", %"plop3_b_bit.16"
  %".731" = and i32 %".730", %"plop3_c_bit.16"
  %"plop3_pred.16" = icmp ne i32 %".731", 0
  %"P84_to_i32" = zext i1 %"plop3_pred.16" to i32
  %"iadd3_n1.6" = add i32 %"imad.39", %"lds.8"
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"iadd3_n2.6", 16
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"iadd3_n1.8" = add i32 %"iadd3_n2.6", 4
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  br label %"BB_17d0"
BB_17d0:
  %"phi.29" = phi  i32 [%"P113_to_i32", %"BB_1770"], [%"P118_to_i32", %"BB_1800"]
  %"phi.30" = phi  i32 [%"P84_to_i32", %"BB_1770"], [%"phi.32", %"BB_1800"]
  %"cond_trunc.35" = trunc i32 %"phi.30" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_800017d0", label %"BB_17e0"
BB_800017d0:
  %"elect_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"election.7" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.7")
  %"elect_p.7" = extractvalue {i32, i1} %"election.7", 1
  %"P115_to_i32" = zext i1 %"elect_p.7" to i32
  br label %"BB_17e0"
BB_17e0:
  %"phi.31" = phi  i32 [%"P115_to_i32", %"BB_800017d0"], [%"phi.29", %"BB_17d0"]
  %"mma_b_r0_ext.2" = zext i32 %".641" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".735" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".736" = sub i64 %".735", 0
  %".737" = lshr i64 %".736", 4
  %".738" = add i64 %"mma_b_packed_1.2", %".737"
  %".739" = and i64 %".738", 16383
  %".740" = and i64 %"mma_b_packed_1.2", -16384
  %".741" = or i64 %".740", %".739"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.8", i32 %"iadd3_n2.7", i64 %".741", i32 679743664, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.6", i32 %"iadd3_n2.8")
  br label %"BB_17f0"
BB_17f0:
  %"cond_trunc.36" = trunc i32 %"phi.31" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_800017f0", label %"BB_1800"
BB_800017f0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.31" to i1
  %"lop3_a_cast_zext.17" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.17" = zext i1 1 to i32
  %"lop3_c_cast_zext.17" = zext i1 1 to i32
  %"plop3_a_bit.17" = and i32 %"lop3_a_cast_zext.17", 1
  %"plop3_b_bit.17" = and i32 %"lop3_b_cast_zext.17", 1
  %"plop3_c_bit.17" = and i32 %"lop3_c_cast_zext.17", 1
  %".745" = xor i32 %"plop3_a_bit.17", 1
  %".746" = xor i32 %"plop3_b_bit.17", 1
  %".747" = xor i32 %"plop3_c_bit.17", 1
  %".748" = and i32 %".745", %"plop3_b_bit.17"
  %".749" = and i32 %".748", %"plop3_c_bit.17"
  %"plop3_pred.17" = icmp ne i32 %".749", 0
  %"P89_to_i32" = zext i1 %"plop3_pred.17" to i32
  br label %"BB_1800"
BB_1800:
  %"phi.32" = phi  i32 [%"P89_to_i32", %"BB_800017f0"], [%"phi.30", %"BB_17f0"]
  %"lop3_a_cast_zext.18" = zext i1 1 to i32
  %"lop3_b_cast_zext.18" = zext i1 1 to i32
  %"lop3_c_cast_zext.18" = zext i1 1 to i32
  %"plop3_a_bit.18" = and i32 %"lop3_a_cast_zext.18", 1
  %"plop3_b_bit.18" = and i32 %"lop3_b_cast_zext.18", 1
  %"plop3_c_bit.18" = and i32 %"lop3_c_cast_zext.18", 1
  %".751" = xor i32 %"plop3_a_bit.18", 1
  %".752" = xor i32 %"plop3_b_bit.18", 1
  %".753" = xor i32 %"plop3_c_bit.18", 1
  %".754" = and i32 %".751", %"plop3_b_bit.18"
  %".755" = and i32 %".754", %"plop3_c_bit.18"
  %"plop3_pred.18" = icmp ne i32 %".755", 0
  %"P118_to_i32" = zext i1 %"plop3_pred.18" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.32" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_17d0", label %"BB_1820"
BB_1820:
  %"iadd3_n1.9" = add i32 1024, 2048
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"lop3_a_cast_zext.19" = zext i1 1 to i32
  %"lop3_b_cast_zext.19" = zext i1 1 to i32
  %"lop3_c_cast_zext.19" = zext i1 1 to i32
  %"plop3_a_bit.19" = and i32 %"lop3_a_cast_zext.19", 1
  %"plop3_b_bit.19" = and i32 %"lop3_b_cast_zext.19", 1
  %"plop3_c_bit.19" = and i32 %"lop3_c_cast_zext.19", 1
  %".757" = xor i32 %"plop3_a_bit.19", 1
  %".758" = xor i32 %"plop3_b_bit.19", 1
  %".759" = xor i32 %"plop3_c_bit.19", 1
  %".760" = and i32 %"plop3_a_bit.19", %"plop3_b_bit.19"
  %".761" = and i32 %".760", %"plop3_c_bit.19"
  %"plop3_pred.19" = icmp ne i32 %".761", 0
  %"P91_to_i32" = zext i1 %"plop3_pred.19" to i32
  %".762" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".763" = zext i32 %"iadd3_n2.9" to i64
  %".764" = zext i32 24 to i64
  %".765" = shl i64 %".762", %".764"
  %".766" = and i64 %".765", 4294967295
  %".767" = add i64 %".766", %".763"
  %".768" = trunc i64 %".767" to i32
  br label %"BB_1850"
BB_1850:
  %"phi.33" = phi  i32 [%"P118_to_i32", %"BB_1820"], [%"P123_to_i32", %"BB_1880"]
  %"phi.34" = phi  i32 [%"P91_to_i32", %"BB_1820"], [%"phi.36", %"BB_1880"]
  %"cond_trunc.37" = trunc i32 %"phi.34" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_80001850", label %"BB_1860"
BB_80001850:
  %"elect_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"election.8" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.8")
  %"elect_p.8" = extractvalue {i32, i1} %"election.8", 1
  %"P120_to_i32" = zext i1 %"elect_p.8" to i32
  br label %"BB_1860"
BB_1860:
  %"phi.35" = phi  i32 [%"P120_to_i32", %"BB_80001850"], [%"phi.33", %"BB_1850"]
  %"utcbar_local_winoff" = and i32 %".768", 16777215
  %".772" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".773" = ptrtoint i8 addrspace(3)* %".772" to i32
  %".774" = lshr i32 %".768", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".773", i32 %".774")
  br label %"BB_1870"
BB_1870:
  %"cond_trunc.38" = trunc i32 %"phi.35" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_80001870", label %"BB_1880"
BB_80001870:
  %"lop3_a_trunc.3" = trunc i32 %"phi.35" to i1
  %"lop3_a_cast_zext.20" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.20" = zext i1 1 to i32
  %"lop3_c_cast_zext.20" = zext i1 1 to i32
  %"plop3_a_bit.20" = and i32 %"lop3_a_cast_zext.20", 1
  %"plop3_b_bit.20" = and i32 %"lop3_b_cast_zext.20", 1
  %"plop3_c_bit.20" = and i32 %"lop3_c_cast_zext.20", 1
  %".778" = xor i32 %"plop3_a_bit.20", 1
  %".779" = xor i32 %"plop3_b_bit.20", 1
  %".780" = xor i32 %"plop3_c_bit.20", 1
  %".781" = and i32 %".778", %"plop3_b_bit.20"
  %".782" = and i32 %".781", %"plop3_c_bit.20"
  %"plop3_pred.20" = icmp ne i32 %".782", 0
  %"P93_to_i32" = zext i1 %"plop3_pred.20" to i32
  br label %"BB_1880"
BB_1880:
  %"phi.36" = phi  i32 [%"P93_to_i32", %"BB_80001870"], [%"phi.34", %"BB_1870"]
  %"lop3_a_cast_zext.21" = zext i1 1 to i32
  %"lop3_b_cast_zext.21" = zext i1 1 to i32
  %"lop3_c_cast_zext.21" = zext i1 1 to i32
  %"plop3_a_bit.21" = and i32 %"lop3_a_cast_zext.21", 1
  %"plop3_b_bit.21" = and i32 %"lop3_b_cast_zext.21", 1
  %"plop3_c_bit.21" = and i32 %"lop3_c_cast_zext.21", 1
  %".784" = xor i32 %"plop3_a_bit.21", 1
  %".785" = xor i32 %"plop3_b_bit.21", 1
  %".786" = xor i32 %"plop3_c_bit.21", 1
  %".787" = and i32 %".784", %"plop3_b_bit.21"
  %".788" = and i32 %".787", %"plop3_c_bit.21"
  %"plop3_pred.21" = icmp ne i32 %".788", 0
  %"P123_to_i32" = zext i1 %"plop3_pred.21" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.36" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.3", label %"BB_1850", label %"BB_18a0"
BB_18a0:
  %"isetrp_cmp1.22" = icmp uge i32 %"tid_x.1", 32
  %"isetrp_src_to_i32.22" = zext i1 1 to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P125_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"lop3_a_cast_zext.22" = zext i1 1 to i32
  %"lop3_b_cast_zext.22" = zext i1 1 to i32
  %"lop3_c_cast_zext.22" = zext i1 1 to i32
  %"plop3_a_bit.22" = and i32 %"lop3_a_cast_zext.22", 1
  %"plop3_b_bit.22" = and i32 %"lop3_b_cast_zext.22", 1
  %"plop3_c_bit.22" = and i32 %"lop3_c_cast_zext.22", 1
  %".790" = xor i32 %"plop3_a_bit.22", 1
  %".791" = xor i32 %"plop3_b_bit.22", 1
  %".792" = xor i32 %"plop3_c_bit.22", 1
  %".793" = and i32 %"plop3_a_bit.22", %"plop3_b_bit.22"
  %".794" = and i32 %".793", %"plop3_c_bit.22"
  %"plop3_pred.22" = icmp ne i32 %".794", 0
  %"P95_to_i32" = zext i1 %"plop3_pred.22" to i32
  br label %"BB_18d0"
BB_18d0:
  %"cond_trunc.39" = trunc i32 %"P125_to_i32" to i1
  %"cond_not.17" = xor i1 %"cond_trunc.39", -1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_not.17" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_1d20", label %"BB_18e0"
BB_18e0:
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".797" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".798" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".799" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".800" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldg_addr_r0_ext.18" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9220
  %"R77:R45_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.16"
  %"ldg_addr_r0_ext.19" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.19" = or i64 0, %"ldg_addr_r0_ext.19"
  %"ldg_addr_r1_ext.19" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.19" = shl i64 %"ldg_addr_r1_ext.19", 32
  %"ldg_addr_packed_1.19" = or i64 %"ldg_addr_packed_0.19", %"ldg_addr_r1_shift.19"
  %"ldg_addr_memaddr_offset_add.18" = add i64 %"ldg_addr_packed_1.19", 9216
  %"R77:R45_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  %"ldg.19" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.17"
  %"ldg_addr_r0_ext.20" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.20" = or i64 0, %"ldg_addr_r0_ext.20"
  %"ldg_addr_r1_ext.20" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.20" = shl i64 %"ldg_addr_r1_ext.20", 32
  %"ldg_addr_packed_1.20" = or i64 %"ldg_addr_packed_0.20", %"ldg_addr_r1_shift.20"
  %"ldg_addr_memaddr_offset_add.19" = add i64 %"ldg_addr_packed_1.20", 9224
  %"R77:R45_addr_ptr.18" = inttoptr i64 %"ldg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  %"ldg.20" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.18"
  %"ldg_addr_r0_ext.21" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.21" = or i64 0, %"ldg_addr_r0_ext.21"
  %"ldg_addr_r1_ext.21" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.21" = shl i64 %"ldg_addr_r1_ext.21", 32
  %"ldg_addr_packed_1.21" = or i64 %"ldg_addr_packed_0.21", %"ldg_addr_r1_shift.21"
  %"ldg_addr_memaddr_offset_add.20" = add i64 %"ldg_addr_packed_1.21", 9228
  %"R77:R45_addr_ptr.19" = inttoptr i64 %"ldg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  %"ldg.21" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.19"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.38", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".801" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".802" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".803" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".804" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"ldg_addr_r0_ext.22" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.22" = or i64 0, %"ldg_addr_r0_ext.22"
  %"ldg_addr_r1_ext.22" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.22" = shl i64 %"ldg_addr_r1_ext.22", 32
  %"ldg_addr_packed_1.22" = or i64 %"ldg_addr_packed_0.22", %"ldg_addr_r1_shift.22"
  %"ldg_addr_memaddr_offset_add.21" = add i64 %"ldg_addr_packed_1.22", 9232
  %"R77:R45_addr_ptr.20" = inttoptr i64 %"ldg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  %"ldg.22" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.20"
  %"ldg_addr_r0_ext.23" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.23" = or i64 0, %"ldg_addr_r0_ext.23"
  %"ldg_addr_r1_ext.23" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.23" = shl i64 %"ldg_addr_r1_ext.23", 32
  %"ldg_addr_packed_1.23" = or i64 %"ldg_addr_packed_0.23", %"ldg_addr_r1_shift.23"
  %"ldg_addr_memaddr_offset_add.22" = add i64 %"ldg_addr_packed_1.23", 9236
  %"R77:R45_addr_ptr.21" = inttoptr i64 %"ldg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  %"ldg.23" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.21"
  %"ldg_addr_r0_ext.24" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.24" = or i64 0, %"ldg_addr_r0_ext.24"
  %"ldg_addr_r1_ext.24" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.24" = shl i64 %"ldg_addr_r1_ext.24", 32
  %"ldg_addr_packed_1.24" = or i64 %"ldg_addr_packed_0.24", %"ldg_addr_r1_shift.24"
  %"ldg_addr_memaddr_offset_add.23" = add i64 %"ldg_addr_packed_1.24", 9240
  %"R77:R45_addr_ptr.22" = inttoptr i64 %"ldg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  %"ldg.24" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.22"
  %"ldg_addr_r0_ext.25" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.25" = or i64 0, %"ldg_addr_r0_ext.25"
  %"ldg_addr_r1_ext.25" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.25" = shl i64 %"ldg_addr_r1_ext.25", 32
  %"ldg_addr_packed_1.25" = or i64 %"ldg_addr_packed_0.25", %"ldg_addr_r1_shift.25"
  %"ldg_addr_memaddr_offset_add.24" = add i64 %"ldg_addr_packed_1.25", 9244
  %"R77:R45_addr_ptr.23" = inttoptr i64 %"ldg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  %"ldg.25" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.23"
  %"isetrp_cmp1.23" = icmp ne i32 %".798", %"ldg.18"
  %"isetrp_src_to_i32.23" = zext i1 1 to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P96_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".805" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".806" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".807" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".808" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"ldg_addr_r0_ext.26" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.26" = or i64 0, %"ldg_addr_r0_ext.26"
  %"ldg_addr_r1_ext.26" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.26" = shl i64 %"ldg_addr_r1_ext.26", 32
  %"ldg_addr_packed_1.26" = or i64 %"ldg_addr_packed_0.26", %"ldg_addr_r1_shift.26"
  %"ldg_addr_memaddr_offset_add.25" = add i64 %"ldg_addr_packed_1.26", 9216
  %"R77:R45_addr_ptr.24" = inttoptr i64 %"ldg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  %"ldg.26" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.24"
  %"isetrp_src_trunc" = trunc i32 %"P96_to_i32" to i1
  %"isetrp_src_not" = xor i1 %"isetrp_src_trunc", -1
  %"isetrp_cmp1.24" = icmp eq i32 %".797", %"ldg.19"
  %"isetrp_src_to_i32.24" = zext i1 %"isetrp_src_not" to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P111_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %"ldg_addr_r0_ext.27" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.27" = or i64 0, %"ldg_addr_r0_ext.27"
  %"ldg_addr_r1_ext.27" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.27" = shl i64 %"ldg_addr_r1_ext.27", 32
  %"ldg_addr_packed_1.27" = or i64 %"ldg_addr_packed_0.27", %"ldg_addr_r1_shift.27"
  %"ldg_addr_memaddr_offset_add.26" = add i64 %"ldg_addr_packed_1.27", 9220
  %"R77:R45_addr_ptr.25" = inttoptr i64 %"ldg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  %"ldg.27" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.25"
  %"isetrp_src_trunc.1" = trunc i32 %"P111_to_i32" to i1
  %"isetrp_cmp1.25" = icmp eq i32 %".799", %"ldg.20"
  %"isetrp_src_to_i32.25" = zext i1 %"isetrp_src_trunc.1" to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P129_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  %"ldg_addr_r0_ext.28" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.28" = or i64 0, %"ldg_addr_r0_ext.28"
  %"ldg_addr_r1_ext.28" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.28" = shl i64 %"ldg_addr_r1_ext.28", 32
  %"ldg_addr_packed_1.28" = or i64 %"ldg_addr_packed_0.28", %"ldg_addr_r1_shift.28"
  %"ldg_addr_memaddr_offset_add.27" = add i64 %"ldg_addr_packed_1.28", 9224
  %"R77:R45_addr_ptr.26" = inttoptr i64 %"ldg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  %"ldg.28" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.26"
  %"isetrp_src_trunc.2" = trunc i32 %"P129_to_i32" to i1
  %"isetrp_cmp1.26" = icmp eq i32 %".800", %"ldg.21"
  %"isetrp_src_to_i32.26" = zext i1 %"isetrp_src_trunc.2" to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"ldg_addr_r0_ext.29" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.29" = or i64 0, %"ldg_addr_r0_ext.29"
  %"ldg_addr_r1_ext.29" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.29" = shl i64 %"ldg_addr_r1_ext.29", 32
  %"ldg_addr_packed_1.29" = or i64 %"ldg_addr_packed_0.29", %"ldg_addr_r1_shift.29"
  %"ldg_addr_memaddr_offset_add.28" = add i64 %"ldg_addr_packed_1.29", 9228
  %"R77:R45_addr_ptr.27" = inttoptr i64 %"ldg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  %"ldg.29" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.27"
  %"isetrp_src_trunc.3" = trunc i32 %"P10_to_i32" to i1
  %"isetrp_cmp1.27" = icmp eq i32 %".801", %"ldg.22"
  %"isetrp_src_to_i32.27" = zext i1 %"isetrp_src_trunc.3" to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P17_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.38", 4
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".809" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".810" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".811" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".812" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"ldg_addr_r0_ext.30" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.30" = or i64 0, %"ldg_addr_r0_ext.30"
  %"ldg_addr_r1_ext.30" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.30" = shl i64 %"ldg_addr_r1_ext.30", 32
  %"ldg_addr_packed_1.30" = or i64 %"ldg_addr_packed_0.30", %"ldg_addr_r1_shift.30"
  %"ldg_addr_memaddr_offset_add.29" = add i64 %"ldg_addr_packed_1.30", 9232
  %"R77:R45_addr_ptr.28" = inttoptr i64 %"ldg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  %"ldg.30" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.28"
  %"ldg_addr_r0_ext.31" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.31" = or i64 0, %"ldg_addr_r0_ext.31"
  %"ldg_addr_r1_ext.31" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.31" = shl i64 %"ldg_addr_r1_ext.31", 32
  %"ldg_addr_packed_1.31" = or i64 %"ldg_addr_packed_0.31", %"ldg_addr_r1_shift.31"
  %"ldg_addr_memaddr_offset_add.30" = add i64 %"ldg_addr_packed_1.31", 9236
  %"R77:R45_addr_ptr.29" = inttoptr i64 %"ldg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  %"ldg.31" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.29"
  %"isetrp_src_trunc.4" = trunc i32 %"P17_to_i32" to i1
  %"isetrp_cmp1.28" = icmp eq i32 %".802", %"ldg.23"
  %"isetrp_src_to_i32.28" = zext i1 %"isetrp_src_trunc.4" to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"ldg_addr_r0_ext.32" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.32" = or i64 0, %"ldg_addr_r0_ext.32"
  %"ldg_addr_r1_ext.32" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.32" = shl i64 %"ldg_addr_r1_ext.32", 32
  %"ldg_addr_packed_1.32" = or i64 %"ldg_addr_packed_0.32", %"ldg_addr_r1_shift.32"
  %"ldg_addr_memaddr_offset_add.31" = add i64 %"ldg_addr_packed_1.32", 9244
  %"R77:R45_addr_ptr.30" = inttoptr i64 %"ldg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  %"ldg.32" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.30"
  %"isetrp_src_trunc.5" = trunc i32 %"P23_to_i32" to i1
  %"isetrp_cmp1.29" = icmp eq i32 %".803", %"ldg.24"
  %"isetrp_src_to_i32.29" = zext i1 %"isetrp_src_trunc.5" to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = and i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  %"ldg_addr_r0_ext.33" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.33" = or i64 0, %"ldg_addr_r0_ext.33"
  %"ldg_addr_r1_ext.33" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.33" = shl i64 %"ldg_addr_r1_ext.33", 32
  %"ldg_addr_packed_1.33" = or i64 %"ldg_addr_packed_0.33", %"ldg_addr_r1_shift.33"
  %"ldg_addr_memaddr_offset_add.32" = add i64 %"ldg_addr_packed_1.33", 9240
  %"R77:R45_addr_ptr.31" = inttoptr i64 %"ldg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  %"ldg.33" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.31"
  %"isetrp_src_trunc.6" = trunc i32 %"P28_to_i32" to i1
  %"isetrp_cmp1.30" = icmp eq i32 %".804", %"ldg.25"
  %"isetrp_src_to_i32.30" = zext i1 %"isetrp_src_trunc.6" to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = and i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".813" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".814" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".815" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".816" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"isetrp_src_trunc.7" = trunc i32 %"P44_to_i32" to i1
  %"isetrp_cmp1.31" = icmp eq i32 %".805", %"ldg.26"
  %"isetrp_src_to_i32.31" = zext i1 %"isetrp_src_trunc.7" to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P121_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  %"ldg_addr_r0_ext.34" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.34" = or i64 0, %"ldg_addr_r0_ext.34"
  %"ldg_addr_r1_ext.34" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.34" = shl i64 %"ldg_addr_r1_ext.34", 32
  %"ldg_addr_packed_1.34" = or i64 %"ldg_addr_packed_0.34", %"ldg_addr_r1_shift.34"
  %"ldg_addr_memaddr_offset_add.33" = add i64 %"ldg_addr_packed_1.34", 9216
  %"R77:R45_addr_ptr.32" = inttoptr i64 %"ldg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  %"ldg.34" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.32"
  %"isetrp_src_trunc.8" = trunc i32 %"P121_to_i32" to i1
  %"isetrp_cmp1.32" = icmp eq i32 %".806", %"ldg.27"
  %"isetrp_src_to_i32.32" = zext i1 %"isetrp_src_trunc.8" to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %"ldg_addr_r0_ext.35" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.35" = or i64 0, %"ldg_addr_r0_ext.35"
  %"ldg_addr_r1_ext.35" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.35" = shl i64 %"ldg_addr_r1_ext.35", 32
  %"ldg_addr_packed_1.35" = or i64 %"ldg_addr_packed_0.35", %"ldg_addr_r1_shift.35"
  %"ldg_addr_memaddr_offset_add.34" = add i64 %"ldg_addr_packed_1.35", 9220
  %"R77:R45_addr_ptr.33" = inttoptr i64 %"ldg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  %"ldg.35" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.33"
  %"isetrp_src_trunc.9" = trunc i32 %"P42_to_i32" to i1
  %"isetrp_cmp1.33" = icmp eq i32 %".807", %"ldg.28"
  %"isetrp_src_to_i32.33" = zext i1 %"isetrp_src_trunc.9" to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P60_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  %"ldg_addr_r0_ext.36" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.36" = or i64 0, %"ldg_addr_r0_ext.36"
  %"ldg_addr_r1_ext.36" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.36" = shl i64 %"ldg_addr_r1_ext.36", 32
  %"ldg_addr_packed_1.36" = or i64 %"ldg_addr_packed_0.36", %"ldg_addr_r1_shift.36"
  %"ldg_addr_memaddr_offset_add.35" = add i64 %"ldg_addr_packed_1.36", 9224
  %"R77:R45_addr_ptr.34" = inttoptr i64 %"ldg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  %"ldg.36" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.34"
  %"isetrp_src_trunc.10" = trunc i32 %"P60_to_i32" to i1
  %"isetrp_cmp1.34" = icmp eq i32 %".808", %"ldg.29"
  %"isetrp_src_to_i32.34" = zext i1 %"isetrp_src_trunc.10" to i32
  %"isetrp_src_to_i1.34" = icmp ne i32 %"isetrp_src_to_i32.34", 0
  %"isetrp_cmp2.34" = and i1 %"isetrp_cmp1.34", %"isetrp_src_to_i1.34"
  %"P69_to_i32" = zext i1 %"isetrp_cmp2.34" to i32
  %"ldg_addr_r0_ext.37" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.37" = or i64 0, %"ldg_addr_r0_ext.37"
  %"ldg_addr_r1_ext.37" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.37" = shl i64 %"ldg_addr_r1_ext.37", 32
  %"ldg_addr_packed_1.37" = or i64 %"ldg_addr_packed_0.37", %"ldg_addr_r1_shift.37"
  %"ldg_addr_memaddr_offset_add.36" = add i64 %"ldg_addr_packed_1.37", 9228
  %"R77:R45_addr_ptr.35" = inttoptr i64 %"ldg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  %"ldg.37" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.35"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.38", 4
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".817" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".818" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".819" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".820" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"isetrp_src_trunc.11" = trunc i32 %"P69_to_i32" to i1
  %"isetrp_cmp1.35" = icmp eq i32 %".809", %"ldg.30"
  %"isetrp_src_to_i32.35" = zext i1 %"isetrp_src_trunc.11" to i32
  %"isetrp_src_to_i1.35" = icmp ne i32 %"isetrp_src_to_i32.35", 0
  %"isetrp_cmp2.35" = and i1 %"isetrp_cmp1.35", %"isetrp_src_to_i1.35"
  %"P87_to_i32" = zext i1 %"isetrp_cmp2.35" to i32
  %"ldg_addr_r0_ext.38" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.38" = or i64 0, %"ldg_addr_r0_ext.38"
  %"ldg_addr_r1_ext.38" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.38" = shl i64 %"ldg_addr_r1_ext.38", 32
  %"ldg_addr_packed_1.38" = or i64 %"ldg_addr_packed_0.38", %"ldg_addr_r1_shift.38"
  %"ldg_addr_memaddr_offset_add.37" = add i64 %"ldg_addr_packed_1.38", 9232
  %"R77:R45_addr_ptr.36" = inttoptr i64 %"ldg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  %"ldg.38" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.36"
  %"ldg_addr_r0_ext.39" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.39" = or i64 0, %"ldg_addr_r0_ext.39"
  %"ldg_addr_r1_ext.39" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.39" = shl i64 %"ldg_addr_r1_ext.39", 32
  %"ldg_addr_packed_1.39" = or i64 %"ldg_addr_packed_0.39", %"ldg_addr_r1_shift.39"
  %"ldg_addr_memaddr_offset_add.38" = add i64 %"ldg_addr_packed_1.39", 9236
  %"R77:R45_addr_ptr.37" = inttoptr i64 %"ldg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  %"ldg.39" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.37"
  %"isetrp_src_trunc.12" = trunc i32 %"P87_to_i32" to i1
  %"isetrp_cmp1.36" = icmp eq i32 %".810", %"ldg.31"
  %"isetrp_src_to_i32.36" = zext i1 %"isetrp_src_trunc.12" to i32
  %"isetrp_src_to_i1.36" = icmp ne i32 %"isetrp_src_to_i32.36", 0
  %"isetrp_cmp2.36" = and i1 %"isetrp_cmp1.36", %"isetrp_src_to_i1.36"
  %"P97_to_i32" = zext i1 %"isetrp_cmp2.36" to i32
  %"ldg_addr_r0_ext.40" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.40" = or i64 0, %"ldg_addr_r0_ext.40"
  %"ldg_addr_r1_ext.40" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.40" = shl i64 %"ldg_addr_r1_ext.40", 32
  %"ldg_addr_packed_1.40" = or i64 %"ldg_addr_packed_0.40", %"ldg_addr_r1_shift.40"
  %"ldg_addr_memaddr_offset_add.39" = add i64 %"ldg_addr_packed_1.40", 9240
  %"R77:R45_addr_ptr.38" = inttoptr i64 %"ldg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  %"ldg.40" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.38"
  %"ldg_addr_r0_ext.41" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.41" = or i64 0, %"ldg_addr_r0_ext.41"
  %"ldg_addr_r1_ext.41" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.41" = shl i64 %"ldg_addr_r1_ext.41", 32
  %"ldg_addr_packed_1.41" = or i64 %"ldg_addr_packed_0.41", %"ldg_addr_r1_shift.41"
  %"ldg_addr_memaddr_offset_add.40" = add i64 %"ldg_addr_packed_1.41", 9244
  %"R77:R45_addr_ptr.39" = inttoptr i64 %"ldg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  %"ldg.41" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.39"
  %"isetrp_src_trunc.13" = trunc i32 %"P97_to_i32" to i1
  %"isetrp_cmp1.37" = icmp eq i32 %".811", %"ldg.33"
  %"isetrp_src_to_i32.37" = zext i1 %"isetrp_src_trunc.13" to i32
  %"isetrp_src_to_i1.37" = icmp ne i32 %"isetrp_src_to_i32.37", 0
  %"isetrp_cmp2.37" = and i1 %"isetrp_cmp1.37", %"isetrp_src_to_i1.37"
  %"P98_to_i32" = zext i1 %"isetrp_cmp2.37" to i32
  %"isetrp_src_trunc.14" = trunc i32 %"P98_to_i32" to i1
  %"isetrp_cmp1.38" = icmp eq i32 %".812", %"ldg.32"
  %"isetrp_src_to_i32.38" = zext i1 %"isetrp_src_trunc.14" to i32
  %"isetrp_src_to_i1.38" = icmp ne i32 %"isetrp_src_to_i32.38", 0
  %"isetrp_cmp2.38" = and i1 %"isetrp_cmp1.38", %"isetrp_src_to_i1.38"
  %"P101_to_i32" = zext i1 %"isetrp_cmp2.38" to i32
  %"isetrp_src_trunc.15" = trunc i32 %"P101_to_i32" to i1
  %"isetrp_cmp1.39" = icmp eq i32 %".813", %"ldg.34"
  %"isetrp_src_to_i32.39" = zext i1 %"isetrp_src_trunc.15" to i32
  %"isetrp_src_to_i1.39" = icmp ne i32 %"isetrp_src_to_i32.39", 0
  %"isetrp_cmp2.39" = and i1 %"isetrp_cmp1.39", %"isetrp_src_to_i1.39"
  %"P102_to_i32" = zext i1 %"isetrp_cmp2.39" to i32
  %"isetrp_src_trunc.16" = trunc i32 %"P102_to_i32" to i1
  %"isetrp_cmp1.40" = icmp eq i32 %".814", %"ldg.35"
  %"isetrp_src_to_i32.40" = zext i1 %"isetrp_src_trunc.16" to i32
  %"isetrp_src_to_i1.40" = icmp ne i32 %"isetrp_src_to_i32.40", 0
  %"isetrp_cmp2.40" = and i1 %"isetrp_cmp1.40", %"isetrp_src_to_i1.40"
  %"P103_to_i32" = zext i1 %"isetrp_cmp2.40" to i32
  %"isetrp_src_trunc.17" = trunc i32 %"P103_to_i32" to i1
  %"isetrp_cmp1.41" = icmp eq i32 %".815", %"ldg.36"
  %"isetrp_src_to_i32.41" = zext i1 %"isetrp_src_trunc.17" to i32
  %"isetrp_src_to_i1.41" = icmp ne i32 %"isetrp_src_to_i32.41", 0
  %"isetrp_cmp2.41" = and i1 %"isetrp_cmp1.41", %"isetrp_src_to_i1.41"
  %"P104_to_i32" = zext i1 %"isetrp_cmp2.41" to i32
  %"isetrp_src_trunc.18" = trunc i32 %"P104_to_i32" to i1
  %"isetrp_cmp1.42" = icmp eq i32 %".816", %"ldg.37"
  %"isetrp_src_to_i32.42" = zext i1 %"isetrp_src_trunc.18" to i32
  %"isetrp_src_to_i1.42" = icmp ne i32 %"isetrp_src_to_i32.42", 0
  %"isetrp_cmp2.42" = and i1 %"isetrp_cmp1.42", %"isetrp_src_to_i1.42"
  %"P106_to_i32" = zext i1 %"isetrp_cmp2.42" to i32
  %"isetrp_src_trunc.19" = trunc i32 %"P106_to_i32" to i1
  %"isetrp_cmp1.43" = icmp eq i32 %".817", %"ldg.38"
  %"isetrp_src_to_i32.43" = zext i1 %"isetrp_src_trunc.19" to i32
  %"isetrp_src_to_i1.43" = icmp ne i32 %"isetrp_src_to_i32.43", 0
  %"isetrp_cmp2.43" = and i1 %"isetrp_cmp1.43", %"isetrp_src_to_i1.43"
  %"P107_to_i32" = zext i1 %"isetrp_cmp2.43" to i32
  %"isetrp_src_trunc.20" = trunc i32 %"P107_to_i32" to i1
  %"isetrp_cmp1.44" = icmp eq i32 %".818", %"ldg.39"
  %"isetrp_src_to_i32.44" = zext i1 %"isetrp_src_trunc.20" to i32
  %"isetrp_src_to_i1.44" = icmp ne i32 %"isetrp_src_to_i32.44", 0
  %"isetrp_cmp2.44" = and i1 %"isetrp_cmp1.44", %"isetrp_src_to_i1.44"
  %"P108_to_i32" = zext i1 %"isetrp_cmp2.44" to i32
  %"isetrp_src_trunc.21" = trunc i32 %"P108_to_i32" to i1
  %"isetrp_cmp1.45" = icmp eq i32 %".819", %"ldg.40"
  %"isetrp_src_to_i32.45" = zext i1 %"isetrp_src_trunc.21" to i32
  %"isetrp_src_to_i1.45" = icmp ne i32 %"isetrp_src_to_i32.45", 0
  %"isetrp_cmp2.45" = and i1 %"isetrp_cmp1.45", %"isetrp_src_to_i1.45"
  %"P77_to_i32" = zext i1 %"isetrp_cmp2.45" to i32
  %"isetrp_src_trunc.22" = trunc i32 %"P77_to_i32" to i1
  %"isetrp_cmp1.46" = icmp eq i32 %".820", %"ldg.41"
  %"isetrp_src_to_i32.46" = zext i1 %"isetrp_src_trunc.22" to i32
  %"isetrp_src_to_i1.46" = icmp ne i32 %"isetrp_src_to_i32.46", 0
  %"isetrp_cmp2.46" = and i1 %"isetrp_cmp1.46", %"isetrp_src_to_i1.46"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.46" to i32
  br label %"BB_1d20"
BB_1d20:
  %"phi.37" = phi  i32 [%"P35_to_i32", %"BB_18e0"], [%"P95_to_i32", %"BB_18d0"]
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.10" = add i32 1024, 2048
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %".822" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".823" = zext i32 %"iadd3_n2.10" to i64
  %".824" = zext i32 24 to i64
  %".825" = shl i64 %".822", %".824"
  %".826" = and i64 %".825", 4294967295
  %".827" = add i64 %".826", %".823"
  %".828" = trunc i64 %".827" to i32
  %"mbar_shared_winoff.1" = and i32 %".828", 16777215
  %".829" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".829" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P126_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_1d80"
BB_1d80:
  %"cond_trunc.40" = trunc i32 %"P126_to_i32" to i1
  %"cond_not.18" = xor i1 %"cond_trunc.40", -1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_not.18" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_2fc0", label %"BB_1d90"
BB_2fc0:
  %"mbar_shared_winoff.2" = and i32 %".828", 16777215
  %".832" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".832" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P127_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_2fd0"
BB_2fd0:
  %"cond_trunc.41" = trunc i32 %"P127_to_i32" to i1
  %"cond_not.19" = xor i1 %"cond_trunc.41", -1
  %"pbra_cond_to_i32.41" = zext i1 %"cond_not.19" to i32
  %"pbra_cond_to_i1.41" = icmp ne i32 %"pbra_cond_to_i32.41", 0
  br i1 %"pbra_cond_to_i1.41", label %"BB_2fc0", label %"BB_1d90"
BB_1d90:
  %".835" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".836" = bitcast i8* %".835" to i64*
  %"ldc_const.3" = load i64, i64* %".836"
  %"R25:R24_r0" = trunc i64 %"ldc_const.3" to i32
  %"R25:R24_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R25:R24_r1" = trunc i64 %"R25:R24_r1_shift" to i32
  %"imad_tmp.39" = mul i32 %"tid_x.1", 40
  %"imad.41" = add i32 %"imad_tmp.39", 0
  %"imad_tmp.40" = mul i32 %"imad.39", 1
  %"imad.42" = add i32 %"imad_tmp.40", %"imad.40"
  %"isetrp_cmp1.47" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.47" = zext i1 1 to i32
  %"isetrp_src_to_i1.47" = icmp ne i32 %"isetrp_src_to_i32.47", 0
  %"isetrp_cmp2.47" = and i1 %"isetrp_cmp1.47", %"isetrp_src_to_i1.47"
  %"P128_to_i32" = zext i1 %"isetrp_cmp2.47" to i32
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.40")
  %".837" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".838" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".839" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".840" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.40", 4
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".841" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".842" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".843" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".844" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R25:R24_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R25:R24_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.41" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.43" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R25:R24_r0.1" = trunc i64 %"imad.43" to i32
  %"R25:R24_r1_shift.1" = lshr i64 %"imad.43", 32
  %"R25:R24_r1.1" = trunc i64 %"R25:R24_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R405:R397_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".837", i32 addrspace(1)* %"R405:R397_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R405:R397_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".838", i32 addrspace(1)* %"R405:R397_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R405:R397_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".839", i32 addrspace(1)* %"R405:R397_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R405:R397_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".840", i32 addrspace(1)* %"R405:R397_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R405:R397_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".841", i32 addrspace(1)* %"R405:R397_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.40", 8
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".850" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".851" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".852" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".853" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R405:R397_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".842", i32 addrspace(1)* %"R405:R397_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R405:R397_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".843", i32 addrspace(1)* %"R405:R397_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R405:R397_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".844", i32 addrspace(1)* %"R405:R397_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.40", 12
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".857" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".858" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".859" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".860" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R405:R397_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".850", i32 addrspace(1)* %"R405:R397_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R405:R397_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".851", i32 addrspace(1)* %"R405:R397_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R405:R397_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".852", i32 addrspace(1)* %"R405:R397_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R405:R397_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".853", i32 addrspace(1)* %"R405:R397_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R405:R397_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".857", i32 addrspace(1)* %"R405:R397_addr_ptr.12"
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".866" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".867" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".868" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".869" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R405:R397_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".858", i32 addrspace(1)* %"R405:R397_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R405:R397_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".859", i32 addrspace(1)* %"R405:R397_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R405:R397_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".860", i32 addrspace(1)* %"R405:R397_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.42", 4
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".873" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".874" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".875" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".876" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R405:R397_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".866", i32 addrspace(1)* %"R405:R397_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R405:R397_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".867", i32 addrspace(1)* %"R405:R397_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R405:R397_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".868", i32 addrspace(1)* %"R405:R397_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R405:R397_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".869", i32 addrspace(1)* %"R405:R397_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R405:R397_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".873", i32 addrspace(1)* %"R405:R397_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.40", 16
  %"ldtm.12" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".882" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 0
  %".883" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 1
  %".884" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 2
  %".885" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R405:R397_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".874", i32 addrspace(1)* %"R405:R397_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R405:R397_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".875", i32 addrspace(1)* %"R405:R397_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R405:R397_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".876", i32 addrspace(1)* %"R405:R397_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.40", 20
  %"ldtm.13" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".889" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 0
  %".890" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 1
  %".891" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 2
  %".892" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R405:R397_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".882", i32 addrspace(1)* %"R405:R397_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R405:R397_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".883", i32 addrspace(1)* %"R405:R397_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R405:R397_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".884", i32 addrspace(1)* %"R405:R397_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R405:R397_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".885", i32 addrspace(1)* %"R405:R397_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R405:R397_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".889", i32 addrspace(1)* %"R405:R397_addr_ptr.28"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.40", 24
  %"ldtm.14" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".898" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 0
  %".899" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 1
  %".900" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 2
  %".901" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 3
  %"stg_addr_r0_ext.29" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R405:R397_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".890", i32 addrspace(1)* %"R405:R397_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R405:R397_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".891", i32 addrspace(1)* %"R405:R397_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R405:R397_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".892", i32 addrspace(1)* %"R405:R397_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.40", 28
  %"ldtm.15" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".905" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 0
  %".906" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 1
  %".907" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 2
  %".908" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 3
  %"stg_addr_r0_ext.32" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 128
  %"R405:R397_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".898", i32 addrspace(1)* %"R405:R397_addr_ptr.32"
  %"stg_addr_r0_ext.33" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 132
  %"R405:R397_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".899", i32 addrspace(1)* %"R405:R397_addr_ptr.33"
  %"stg_addr_r0_ext.34" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 136
  %"R405:R397_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".900", i32 addrspace(1)* %"R405:R397_addr_ptr.34"
  %"stg_addr_r0_ext.35" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 140
  %"R405:R397_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".901", i32 addrspace(1)* %"R405:R397_addr_ptr.35"
  %"stg_addr_r0_ext.36" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 144
  %"R405:R397_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".905", i32 addrspace(1)* %"R405:R397_addr_ptr.36"
  %"stg_addr_r0_ext.37" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 148
  %"R405:R397_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".906", i32 addrspace(1)* %"R405:R397_addr_ptr.37"
  %"stg_addr_r0_ext.38" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 152
  %"R405:R397_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".907", i32 addrspace(1)* %"R405:R397_addr_ptr.38"
  %"stg_addr_r0_ext.39" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 156
  %"R405:R397_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".908", i32 addrspace(1)* %"R405:R397_addr_ptr.39"
  br label %"BB_2220"
BB_2220:
  %"cond_trunc.42" = trunc i32 %"phi.37" to i1
  %"pbra_cond_to_i32.42" = zext i1 %"cond_trunc.42" to i32
  %"pbra_cond_to_i1.42" = icmp ne i32 %"pbra_cond_to_i32.42", 0
  br i1 %"pbra_cond_to_i1.42", label %"BB_2260", label %"BB_2230"
BB_2230:
  %"ldg_addr_r0_ext.42" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.42" = or i64 0, %"ldg_addr_r0_ext.42"
  %"ldg_addr_r1_ext.42" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.42" = shl i64 %"ldg_addr_r1_ext.42", 32
  %"ldg_addr_packed_1.42" = or i64 %"ldg_addr_packed_0.42", %"ldg_addr_r1_shift.42"
  %"ldg_addr_memaddr_offset_add.41" = add i64 %"ldg_addr_packed_1.42", 9216
  %"R77:R45_addr_ptr.40" = inttoptr i64 %"ldg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  %"ldg.42" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.40"
  %".919" = xor i32 0, -1
  %".920" = xor i32 %"ldg.42", -1
  %".921" = xor i32 0, -1
  %".922" = and i32 %".919", %".920"
  %".923" = and i32 %".922", %".921"
  %".924" = and i32 %".919", %".920"
  %".925" = and i32 %".924", 0
  %".926" = or i32 %".923", %".925"
  %".927" = and i32 0, %".920"
  %".928" = and i32 %".927", %".921"
  %".929" = or i32 %".926", %".928"
  %".930" = and i32 0, %".920"
  %".931" = and i32 %".930", 0
  %".932" = or i32 %".929", %".931"
  %"stg_addr_r0_ext.40" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 64
  %"R405:R397_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".932", i32 addrspace(1)* %"R405:R397_addr_ptr.40"
  br label %"BB_2260"
BB_2260:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_2280"
BB_2280:
  %"cond_trunc.43" = trunc i32 %"P128_to_i32" to i1
  %"pbra_cond_to_i32.43" = zext i1 %"cond_trunc.43" to i32
  %"pbra_cond_to_i1.43" = icmp ne i32 %"pbra_cond_to_i32.43", 0
  br i1 %"pbra_cond_to_i1.43", label %"BB_80002280", label %"BB_2290"
BB_2290:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.9" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".937" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.9"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".937" to i32 addrspace(3)*
  %"lds.9" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.41" = mul i32 0, 0
  %"imad.44" = add i32 %"imad_tmp.41", 1
  %".938" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".939" = zext i32 80 to i64
  %".940" = zext i32 24 to i64
  %".941" = shl i64 %".938", %".940"
  %".942" = and i64 %".941", 4294967295
  %".943" = add i64 %".942", %".939"
  %".944" = trunc i64 %".943" to i32
  %"lds_shared_addr_winoff.10" = and i32 %".944", 16777215
  %".945" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.10"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".945" to i32 addrspace(3)*
  %"lds.10" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".946" = xor i32 %"lds.9", -1
  %".947" = xor i32 65535, -1
  %".948" = xor i32 0, -1
  %".949" = and i32 %"lds.9", 65535
  %".950" = and i32 %".949", %".948"
  %".951" = and i32 %"lds.9", 65535
  %".952" = and i32 %".951", 0
  %".953" = or i32 %".950", %".952"
  %".954" = zext i32 0 to i64
  %".955" = zext i32 %".953" to i64
  %".956" = shl i64 %".955", 32
  %"shf_concat.14" = or i64 %".954", %".956"
  %"shf_shift_64.14" = zext i32 5 to i64
  %".957" = lshr i64 %"shf_concat.14", %"shf_shift_64.14"
  %"shf_hi.2" = lshr i64 %".957", 32
  %"shf_result.14" = trunc i64 %"shf_hi.2" to i32
  %"viadd.11" = add i32 %"shf_result.14", 16
  %".958" = zext i32 %"imad.44" to i64
  %".959" = zext i32 0 to i64
  %".960" = shl i64 %".959", 32
  %"shf_concat.15" = or i64 %".958", %".960"
  %"shf_shift_64.15" = zext i32 %"shf_result.14" to i64
  %".961" = shl i64 %"shf_concat.15", %"shf_shift_64.15"
  %"shf_result.15" = trunc i64 %".961" to i32
  %".962" = zext i32 %"imad.44" to i64
  %".963" = zext i32 0 to i64
  %".964" = shl i64 %".963", 32
  %"shf_concat.16" = or i64 %".962", %".964"
  %"shf_shift_64.16" = zext i32 %"viadd.11" to i64
  %".965" = shl i64 %"shf_concat.16", %"shf_shift_64.16"
  %"shf_result.16" = trunc i64 %".965" to i32
  %".966" = xor i32 %"shf_result.16", -1
  %".967" = xor i32 %"shf_result.15", -1
  %".968" = xor i32 0, -1
  %".969" = and i32 %".966", %"shf_result.15"
  %".970" = and i32 %".969", %".968"
  %".971" = and i32 %".966", %"shf_result.15"
  %".972" = and i32 %".971", 0
  %".973" = or i32 %".970", %".972"
  %".974" = and i32 %"shf_result.16", %".967"
  %".975" = and i32 %".974", %".968"
  %".976" = or i32 %".973", %".975"
  %".977" = and i32 %"shf_result.16", %".967"
  %".978" = and i32 %".977", 0
  %".979" = or i32 %".976", %".978"
  %".980" = and i32 %"shf_result.16", %"shf_result.15"
  %".981" = and i32 %".980", %".968"
  %".982" = or i32 %".979", %".981"
  %".983" = and i32 %"shf_result.16", %"shf_result.15"
  %".984" = and i32 %".983", 0
  %".985" = or i32 %".982", %".984"
  %".986" = xor i32 %".985", -1
  %".987" = xor i32 65535, -1
  %".988" = xor i32 0, -1
  %".989" = and i32 %".985", 65535
  %".990" = and i32 %".989", %".988"
  %".991" = and i32 %".985", 65535
  %".992" = and i32 %".991", 0
  %".993" = or i32 %".990", %".992"
  %".994" = xor i32 %".985", -1
  %".995" = xor i32 65535, -1
  %".996" = xor i32 %"lds.10", -1
  %".997" = and i32 %".985", 65535
  %".998" = and i32 %".997", %"lds.10"
  %"isetrp_cmp1.48" = icmp ne i32 %".998", %".993"
  %"isetrp_src_to_i32.48" = zext i1 1 to i32
  %"isetrp_src_to_i1.48" = icmp ne i32 %"isetrp_src_to_i32.48", 0
  %"isetrp_cmp2.48" = and i1 %"isetrp_cmp1.48", %"isetrp_src_to_i1.48"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.48" to i32
  br label %"BB_2380"
BB_2380:
  %"cond_trunc.44" = trunc i32 %"P56_to_i32" to i1
  %"pbra_cond_to_i32.44" = zext i1 %"cond_trunc.44" to i32
  %"pbra_cond_to_i1.44" = icmp ne i32 %"pbra_cond_to_i32.44", 0
  br i1 %"pbra_cond_to_i1.44", label %"BB_24e0_3050", label %"BB_2390"
BB_2390:
  %".1001" = zext i32 0 to i64
  %".1002" = zext i32 %"lds.10" to i64
  %".1003" = shl i64 %".1002", 32
  %"shf_concat.17" = or i64 %".1001", %".1003"
  %"shf_shift_64.17" = zext i32 16 to i64
  %".1004" = lshr i64 %"shf_concat.17", %"shf_shift_64.17"
  %"shf_hi.3" = lshr i64 %".1004", 32
  %"shf_result.17" = trunc i64 %"shf_hi.3" to i32
  %".1005" = zext i32 0 to i64
  %".1006" = zext i32 %".985" to i64
  %".1007" = shl i64 %".1006", 32
  %"shf_concat.18" = or i64 %".1005", %".1007"
  %"shf_shift_64.18" = zext i32 16 to i64
  %".1008" = lshr i64 %"shf_concat.18", %"shf_shift_64.18"
  %"shf_hi.4" = lshr i64 %".1008", 32
  %"shf_result.18" = trunc i64 %"shf_hi.4" to i32
  %".1009" = xor i32 %"shf_result.17", -1
  %".1010" = xor i32 %"shf_result.18", -1
  %".1011" = xor i32 0, -1
  %".1012" = and i32 %"shf_result.17", %"shf_result.18"
  %".1013" = and i32 %".1012", %".1011"
  %".1014" = and i32 %"shf_result.17", %"shf_result.18"
  %".1015" = and i32 %".1014", 0
  %".1016" = or i32 %".1013", %".1015"
  %"isetrp_cmp1.49" = icmp ne i32 %".1016", %"shf_result.18"
  %"isetrp_src_to_i32.49" = zext i1 1 to i32
  %"isetrp_src_to_i1.49" = icmp ne i32 %"isetrp_src_to_i32.49", 0
  %"isetrp_cmp2.49" = and i1 %"isetrp_cmp1.49", %"isetrp_src_to_i1.49"
  %"P65_to_i32" = zext i1 %"isetrp_cmp2.49" to i32
  br label %"BB_23d0"
BB_23d0:
  %"cond_trunc.45" = trunc i32 %"P65_to_i32" to i1
  %"pbra_cond_to_i32.45" = zext i1 %"cond_trunc.45" to i32
  %"pbra_cond_to_i1.45" = icmp ne i32 %"pbra_cond_to_i32.45", 0
  br i1 %"pbra_cond_to_i1.45", label %"BB_24b0_2ff0", label %"BB_23e0"
BB_23e0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".1019" = xor i32 0, -1
  %".1020" = xor i32 %".985", -1
  %".1021" = xor i32 0, -1
  %".1022" = and i32 %".1019", %".1020"
  %".1023" = and i32 %".1022", %".1021"
  %".1024" = and i32 %".1019", %".1020"
  %".1025" = and i32 %".1024", 0
  %".1026" = or i32 %".1023", %".1025"
  %".1027" = and i32 0, %".1020"
  %".1028" = and i32 %".1027", %".1021"
  %".1029" = or i32 %".1026", %".1028"
  %".1030" = and i32 0, %".1020"
  %".1031" = and i32 %".1030", 0
  %".1032" = or i32 %".1029", %".1031"
  %"imad_tmp.42" = mul i32 0, 0
  %"imad.45" = add i32 %"imad_tmp.42", %".1032"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.45", i32 %"redux_mask")
  %".1033" = xor i32 %".1032", -1
  %".1034" = call i32 @"llvm.cttz.i32"(i32 %".1033", i1 0)
  %".1035" = shl i32 %".1034", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".1035") convergent
  %"isetrp_cmp1.50" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.50" = zext i1 1 to i32
  %"isetrp_src_to_i1.50" = icmp ne i32 %"isetrp_src_to_i32.50", 0
  %"isetrp_cmp2.50" = and i1 %"isetrp_cmp1.50", %"isetrp_src_to_i1.50"
  %"P73_to_i32" = zext i1 %"isetrp_cmp2.50" to i32
  %"imad_tmp.43" = mul i32 0, 0
  %"imad.46" = add i32 %"imad_tmp.43", %"redux_sync_and"
  br label %"BB_2480"
BB_2480:
  %"cond_trunc.46" = trunc i32 %"P73_to_i32" to i1
  %"pbra_cond_to_i32.46" = zext i1 %"cond_trunc.46" to i32
  %"pbra_cond_to_i1.46" = icmp ne i32 %"pbra_cond_to_i32.46", 0
  br i1 %"pbra_cond_to_i1.46", label %"BB_80002480", label %"BB_24f0"
BB_80002480:
  %"atoms_shared_addr_winoff.5" = and i32 %".944", 16777215
  %".1039" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.5"
  %"atoms_ptr.5" = bitcast i8 addrspace(3)* %".1039" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.5", i32 %"imad.46" monotonic
  br label %"BB_24f0"
BB_24b0_2ff0:
  call void @"llvm.trap"()
  br label %"BB_24f0"
BB_24e0_3050:
  call void @"llvm.trap"()
  br label %"BB_24f0"
BB_24f0:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.44" = mul i32 0, 0
  %"imad.47" = add i32 %"imad_tmp.44", 1
  %".1043" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".1044" = zext i32 1024 to i64
  %".1045" = zext i32 24 to i64
  %".1046" = shl i64 %".1043", %".1045"
  %".1047" = and i64 %".1046", 4294967295
  %".1048" = add i64 %".1047", %".1044"
  %".1049" = trunc i64 %".1048" to i32
  %"lds_addr_memaddr_offset_add.5" = add i32 %".1049", 2060
  %"lds_shared_addr_winoff.11" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".1050" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.11"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".1050" to i32 addrspace(3)*
  %"lds.11" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %".1051" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".1052" = zext i32 80 to i64
  %".1053" = zext i32 24 to i64
  %".1054" = shl i64 %".1051", %".1053"
  %".1055" = and i64 %".1054", 4294967295
  %".1056" = add i64 %".1055", %".1052"
  %".1057" = trunc i64 %".1056" to i32
  %"lds_shared_addr_winoff.12" = and i32 %".1057", 16777215
  %".1058" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.12"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".1058" to i32 addrspace(3)*
  %"lds.12" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.7"
  %".1059" = xor i32 %"lds.11", -1
  %".1060" = xor i32 65535, -1
  %".1061" = xor i32 0, -1
  %".1062" = and i32 %"lds.11", 65535
  %".1063" = and i32 %".1062", %".1061"
  %".1064" = and i32 %"lds.11", 65535
  %".1065" = and i32 %".1064", 0
  %".1066" = or i32 %".1063", %".1065"
  %".1067" = zext i32 0 to i64
  %".1068" = zext i32 %".1066" to i64
  %".1069" = shl i64 %".1068", 32
  %"shf_concat.19" = or i64 %".1067", %".1069"
  %"shf_shift_64.19" = zext i32 5 to i64
  %".1070" = lshr i64 %"shf_concat.19", %"shf_shift_64.19"
  %"shf_hi.5" = lshr i64 %".1070", 32
  %"shf_result.19" = trunc i64 %"shf_hi.5" to i32
  %"viadd.12" = add i32 %"shf_result.19", 16
  %".1071" = zext i32 %"imad.47" to i64
  %".1072" = zext i32 0 to i64
  %".1073" = shl i64 %".1072", 32
  %"shf_concat.20" = or i64 %".1071", %".1073"
  %"shf_shift_64.20" = zext i32 %"shf_result.19" to i64
  %".1074" = shl i64 %"shf_concat.20", %"shf_shift_64.20"
  %"shf_result.20" = trunc i64 %".1074" to i32
  %".1075" = zext i32 %"imad.47" to i64
  %".1076" = zext i32 0 to i64
  %".1077" = shl i64 %".1076", 32
  %"shf_concat.21" = or i64 %".1075", %".1077"
  %"shf_shift_64.21" = zext i32 %"viadd.12" to i64
  %".1078" = shl i64 %"shf_concat.21", %"shf_shift_64.21"
  %"shf_result.21" = trunc i64 %".1078" to i32
  %".1079" = xor i32 %"shf_result.21", -1
  %".1080" = xor i32 %"shf_result.20", -1
  %".1081" = xor i32 0, -1
  %".1082" = and i32 %".1079", %"shf_result.20"
  %".1083" = and i32 %".1082", %".1081"
  %".1084" = and i32 %".1079", %"shf_result.20"
  %".1085" = and i32 %".1084", 0
  %".1086" = or i32 %".1083", %".1085"
  %".1087" = and i32 %"shf_result.21", %".1080"
  %".1088" = and i32 %".1087", %".1081"
  %".1089" = or i32 %".1086", %".1088"
  %".1090" = and i32 %"shf_result.21", %".1080"
  %".1091" = and i32 %".1090", 0
  %".1092" = or i32 %".1089", %".1091"
  %".1093" = and i32 %"shf_result.21", %"shf_result.20"
  %".1094" = and i32 %".1093", %".1081"
  %".1095" = or i32 %".1092", %".1094"
  %".1096" = and i32 %"shf_result.21", %"shf_result.20"
  %".1097" = and i32 %".1096", 0
  %".1098" = or i32 %".1095", %".1097"
  %".1099" = xor i32 %".1098", -1
  %".1100" = xor i32 65535, -1
  %".1101" = xor i32 0, -1
  %".1102" = and i32 %".1098", 65535
  %".1103" = and i32 %".1102", %".1101"
  %".1104" = and i32 %".1098", 65535
  %".1105" = and i32 %".1104", 0
  %".1106" = or i32 %".1103", %".1105"
  %".1107" = xor i32 %".1098", -1
  %".1108" = xor i32 65535, -1
  %".1109" = xor i32 %"lds.12", -1
  %".1110" = and i32 %".1098", 65535
  %".1111" = and i32 %".1110", %"lds.12"
  %"isetrp_cmp1.51" = icmp ne i32 %".1111", %".1106"
  %"isetrp_src_to_i32.51" = zext i1 1 to i32
  %"isetrp_src_to_i1.51" = icmp ne i32 %"isetrp_src_to_i32.51", 0
  %"isetrp_cmp2.51" = and i1 %"isetrp_cmp1.51", %"isetrp_src_to_i1.51"
  %"P100_to_i32" = zext i1 %"isetrp_cmp2.51" to i32
  br label %"BB_2620"
BB_2620:
  %"cond_trunc.47" = trunc i32 %"P100_to_i32" to i1
  %"pbra_cond_to_i32.47" = zext i1 %"cond_trunc.47" to i32
  %"pbra_cond_to_i1.47" = icmp ne i32 %"pbra_cond_to_i32.47", 0
  br i1 %"pbra_cond_to_i1.47", label %"BB_2780_3050", label %"BB_2630"
BB_2630:
  %".1114" = zext i32 0 to i64
  %".1115" = zext i32 %"lds.12" to i64
  %".1116" = shl i64 %".1115", 32
  %"shf_concat.22" = or i64 %".1114", %".1116"
  %"shf_shift_64.22" = zext i32 16 to i64
  %".1117" = lshr i64 %"shf_concat.22", %"shf_shift_64.22"
  %"shf_hi.6" = lshr i64 %".1117", 32
  %"shf_result.22" = trunc i64 %"shf_hi.6" to i32
  %".1118" = zext i32 0 to i64
  %".1119" = zext i32 %".1098" to i64
  %".1120" = shl i64 %".1119", 32
  %"shf_concat.23" = or i64 %".1118", %".1120"
  %"shf_shift_64.23" = zext i32 16 to i64
  %".1121" = lshr i64 %"shf_concat.23", %"shf_shift_64.23"
  %"shf_hi.7" = lshr i64 %".1121", 32
  %"shf_result.23" = trunc i64 %"shf_hi.7" to i32
  %".1122" = xor i32 %"shf_result.22", -1
  %".1123" = xor i32 %"shf_result.23", -1
  %".1124" = xor i32 0, -1
  %".1125" = and i32 %"shf_result.22", %"shf_result.23"
  %".1126" = and i32 %".1125", %".1124"
  %".1127" = and i32 %"shf_result.22", %"shf_result.23"
  %".1128" = and i32 %".1127", 0
  %".1129" = or i32 %".1126", %".1128"
  %"isetrp_cmp1.52" = icmp ne i32 %".1129", %"shf_result.23"
  %"isetrp_src_to_i32.52" = zext i1 1 to i32
  %"isetrp_src_to_i1.52" = icmp ne i32 %"isetrp_src_to_i32.52", 0
  %"isetrp_cmp2.52" = and i1 %"isetrp_cmp1.52", %"isetrp_src_to_i1.52"
  %"P51_to_i32" = zext i1 %"isetrp_cmp2.52" to i32
  br label %"BB_2670"
BB_2670:
  %"cond_trunc.48" = trunc i32 %"P51_to_i32" to i1
  %"pbra_cond_to_i32.48" = zext i1 %"cond_trunc.48" to i32
  %"pbra_cond_to_i1.48" = icmp ne i32 %"pbra_cond_to_i32.48", 0
  br i1 %"pbra_cond_to_i1.48", label %"BB_2750_2ff0", label %"BB_2680"
BB_2680:
  %"activemask.1" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.1" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.1" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.1", i1 0)
  %"flo.1" = sub i32 31, %"flo_clz.1"
  %".1132" = xor i32 0, -1
  %".1133" = xor i32 %".1098", -1
  %".1134" = xor i32 0, -1
  %".1135" = and i32 %".1132", %".1133"
  %".1136" = and i32 %".1135", %".1134"
  %".1137" = and i32 %".1132", %".1133"
  %".1138" = and i32 %".1137", 0
  %".1139" = or i32 %".1136", %".1138"
  %".1140" = and i32 0, %".1133"
  %".1141" = and i32 %".1140", %".1134"
  %".1142" = or i32 %".1139", %".1141"
  %".1143" = and i32 0, %".1133"
  %".1144" = and i32 %".1143", 0
  %".1145" = or i32 %".1142", %".1144"
  %"imad_tmp.45" = mul i32 0, 0
  %"imad.48" = add i32 %"imad_tmp.45", %".1145"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.48", i32 %"redux_mask.1")
  %".1146" = xor i32 %".1145", -1
  %".1147" = call i32 @"llvm.cttz.i32"(i32 %".1146", i1 0)
  %".1148" = shl i32 %".1147", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".1148") convergent
  %"isetrp_cmp1.53" = icmp eq i32 %"laneid.1", %"flo.1"
  %"isetrp_src_to_i32.53" = zext i1 1 to i32
  %"isetrp_src_to_i1.53" = icmp ne i32 %"isetrp_src_to_i32.53", 0
  %"isetrp_cmp2.53" = and i1 %"isetrp_cmp1.53", %"isetrp_src_to_i1.53"
  %"P105_to_i32" = zext i1 %"isetrp_cmp2.53" to i32
  %"imad_tmp.46" = mul i32 0, 0
  %"imad.49" = add i32 %"imad_tmp.46", %"redux_sync_and.1"
  br label %"BB_2720"
BB_2720:
  %"cond_trunc.49" = trunc i32 %"P105_to_i32" to i1
  %"pbra_cond_to_i32.49" = zext i1 %"cond_trunc.49" to i32
  %"pbra_cond_to_i1.49" = icmp ne i32 %"pbra_cond_to_i32.49", 0
  br i1 %"pbra_cond_to_i1.49", label %"BB_80002720", label %"BB_2790"
BB_80002720:
  %"atoms_shared_addr_winoff.6" = and i32 %".1057", 16777215
  %".1152" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.6"
  %"atoms_ptr.6" = bitcast i8 addrspace(3)* %".1152" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.6", i32 %"imad.49" monotonic
  br label %"BB_2790"
BB_2750_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2790"
BB_2780_3050:
  call void @"llvm.trap"()
  br label %"BB_2790"
BB_2790:
  %"s2ur_cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.47" = mul i32 0, 0
  %"imad.50" = add i32 %"imad_tmp.47", 3
  %"imad_tmp.48" = mul i32 0, 0
  %"imad.51" = add i32 %"imad_tmp.48", 1
  %".1156" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".1157" = zext i32 1024 to i64
  %".1158" = zext i32 24 to i64
  %".1159" = shl i64 %".1156", %".1158"
  %".1160" = and i64 %".1159", 4294967295
  %".1161" = add i64 %".1160", %".1157"
  %".1162" = trunc i64 %".1161" to i32
  %"lds_addr_memaddr_offset_add.6" = add i32 %".1162", 2064
  %"lds_shared_addr_winoff.13" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".1163" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.13"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".1163" to i32 addrspace(3)*
  %"lds.13" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.8"
  %".1164" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".1165" = zext i32 80 to i64
  %".1166" = zext i32 24 to i64
  %".1167" = shl i64 %".1164", %".1166"
  %".1168" = and i64 %".1167", 4294967295
  %".1169" = add i64 %".1168", %".1165"
  %".1170" = trunc i64 %".1169" to i32
  %"lds_shared_addr_winoff.14" = and i32 %".1170", 16777215
  %".1171" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.14"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".1171" to i32 addrspace(3)*
  %"lds.14" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.9"
  %".1172" = xor i32 %"lds.13", -1
  %".1173" = xor i32 65535, -1
  %".1174" = xor i32 0, -1
  %".1175" = and i32 %"lds.13", 65535
  %".1176" = and i32 %".1175", %".1174"
  %".1177" = and i32 %"lds.13", 65535
  %".1178" = and i32 %".1177", 0
  %".1179" = or i32 %".1176", %".1178"
  %".1180" = zext i32 0 to i64
  %".1181" = zext i32 %".1179" to i64
  %".1182" = shl i64 %".1181", 32
  %"shf_concat.24" = or i64 %".1180", %".1182"
  %"shf_shift_64.24" = zext i32 5 to i64
  %".1183" = lshr i64 %"shf_concat.24", %"shf_shift_64.24"
  %"shf_hi.8" = lshr i64 %".1183", 32
  %"shf_result.24" = trunc i64 %"shf_hi.8" to i32
  %"viadd.13" = add i32 %"shf_result.24", 16
  %".1184" = zext i32 %"imad.50" to i64
  %".1185" = zext i32 0 to i64
  %".1186" = shl i64 %".1185", 32
  %"shf_concat.25" = or i64 %".1184", %".1186"
  %"shf_shift_64.25" = zext i32 %"shf_result.24" to i64
  %".1187" = shl i64 %"shf_concat.25", %"shf_shift_64.25"
  %"shf_result.25" = trunc i64 %".1187" to i32
  %".1188" = zext i32 %"imad.51" to i64
  %".1189" = zext i32 0 to i64
  %".1190" = shl i64 %".1189", 32
  %"shf_concat.26" = or i64 %".1188", %".1190"
  %"shf_shift_64.26" = zext i32 %"viadd.13" to i64
  %".1191" = shl i64 %"shf_concat.26", %"shf_shift_64.26"
  %"shf_result.26" = trunc i64 %".1191" to i32
  %".1192" = xor i32 %"shf_result.26", -1
  %".1193" = xor i32 %"shf_result.25", -1
  %".1194" = xor i32 0, -1
  %".1195" = and i32 %".1192", %"shf_result.25"
  %".1196" = and i32 %".1195", %".1194"
  %".1197" = and i32 %".1192", %"shf_result.25"
  %".1198" = and i32 %".1197", 0
  %".1199" = or i32 %".1196", %".1198"
  %".1200" = and i32 %"shf_result.26", %".1193"
  %".1201" = and i32 %".1200", %".1194"
  %".1202" = or i32 %".1199", %".1201"
  %".1203" = and i32 %"shf_result.26", %".1193"
  %".1204" = and i32 %".1203", 0
  %".1205" = or i32 %".1202", %".1204"
  %".1206" = and i32 %"shf_result.26", %"shf_result.25"
  %".1207" = and i32 %".1206", %".1194"
  %".1208" = or i32 %".1205", %".1207"
  %".1209" = and i32 %"shf_result.26", %"shf_result.25"
  %".1210" = and i32 %".1209", 0
  %".1211" = or i32 %".1208", %".1210"
  %".1212" = xor i32 %".1211", -1
  %".1213" = xor i32 65535, -1
  %".1214" = xor i32 0, -1
  %".1215" = and i32 %".1211", 65535
  %".1216" = and i32 %".1215", %".1214"
  %".1217" = and i32 %".1211", 65535
  %".1218" = and i32 %".1217", 0
  %".1219" = or i32 %".1216", %".1218"
  %".1220" = xor i32 %".1211", -1
  %".1221" = xor i32 65535, -1
  %".1222" = xor i32 %"lds.14", -1
  %".1223" = and i32 %".1211", 65535
  %".1224" = and i32 %".1223", %"lds.14"
  %"isetrp_cmp1.54" = icmp ne i32 %".1224", %".1219"
  %"isetrp_src_to_i32.54" = zext i1 1 to i32
  %"isetrp_src_to_i1.54" = icmp ne i32 %"isetrp_src_to_i32.54", 0
  %"isetrp_cmp2.54" = and i1 %"isetrp_cmp1.54", %"isetrp_src_to_i1.54"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.54" to i32
  br label %"BB_28d0"
BB_28d0:
  %"cond_trunc.50" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.50" = zext i1 %"cond_trunc.50" to i32
  %"pbra_cond_to_i1.50" = icmp ne i32 %"pbra_cond_to_i32.50", 0
  br i1 %"pbra_cond_to_i1.50", label %"BB_2a30_3050", label %"BB_28e0"
BB_28e0:
  %".1227" = zext i32 0 to i64
  %".1228" = zext i32 %"lds.14" to i64
  %".1229" = shl i64 %".1228", 32
  %"shf_concat.27" = or i64 %".1227", %".1229"
  %"shf_shift_64.27" = zext i32 16 to i64
  %".1230" = lshr i64 %"shf_concat.27", %"shf_shift_64.27"
  %"shf_hi.9" = lshr i64 %".1230", 32
  %"shf_result.27" = trunc i64 %"shf_hi.9" to i32
  %".1231" = zext i32 0 to i64
  %".1232" = zext i32 %".1211" to i64
  %".1233" = shl i64 %".1232", 32
  %"shf_concat.28" = or i64 %".1231", %".1233"
  %"shf_shift_64.28" = zext i32 16 to i64
  %".1234" = lshr i64 %"shf_concat.28", %"shf_shift_64.28"
  %"shf_hi.10" = lshr i64 %".1234", 32
  %"shf_result.28" = trunc i64 %"shf_hi.10" to i32
  %".1235" = xor i32 %"shf_result.27", -1
  %".1236" = xor i32 %"shf_result.28", -1
  %".1237" = xor i32 0, -1
  %".1238" = and i32 %"shf_result.27", %"shf_result.28"
  %".1239" = and i32 %".1238", %".1237"
  %".1240" = and i32 %"shf_result.27", %"shf_result.28"
  %".1241" = and i32 %".1240", 0
  %".1242" = or i32 %".1239", %".1241"
  %"isetrp_cmp1.55" = icmp ne i32 %".1242", %"shf_result.28"
  %"isetrp_src_to_i32.55" = zext i1 1 to i32
  %"isetrp_src_to_i1.55" = icmp ne i32 %"isetrp_src_to_i32.55", 0
  %"isetrp_cmp2.55" = and i1 %"isetrp_cmp1.55", %"isetrp_src_to_i1.55"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.55" to i32
  br label %"BB_2920"
BB_2920:
  %"cond_trunc.51" = trunc i32 %"P15_to_i32" to i1
  %"pbra_cond_to_i32.51" = zext i1 %"cond_trunc.51" to i32
  %"pbra_cond_to_i1.51" = icmp ne i32 %"pbra_cond_to_i32.51", 0
  br i1 %"pbra_cond_to_i1.51", label %"BB_2a00_2ff0", label %"BB_2930"
BB_2930:
  %"activemask.2" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.2" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.2" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.2", i1 0)
  %"flo.2" = sub i32 31, %"flo_clz.2"
  %".1245" = xor i32 0, -1
  %".1246" = xor i32 %".1211", -1
  %".1247" = xor i32 0, -1
  %".1248" = and i32 %".1245", %".1246"
  %".1249" = and i32 %".1248", %".1247"
  %".1250" = and i32 %".1245", %".1246"
  %".1251" = and i32 %".1250", 0
  %".1252" = or i32 %".1249", %".1251"
  %".1253" = and i32 0, %".1246"
  %".1254" = and i32 %".1253", %".1247"
  %".1255" = or i32 %".1252", %".1254"
  %".1256" = and i32 0, %".1246"
  %".1257" = and i32 %".1256", 0
  %".1258" = or i32 %".1255", %".1257"
  %"imad_tmp.49" = mul i32 0, 0
  %"imad.52" = add i32 %"imad_tmp.49", %".1258"
  %"redux_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.2" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.52", i32 %"redux_mask.2")
  %".1259" = xor i32 %".1258", -1
  %".1260" = call i32 @"llvm.cttz.i32"(i32 %".1259", i1 0)
  %".1261" = shl i32 %".1260", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".1261") convergent
  %"isetrp_cmp1.56" = icmp eq i32 %"laneid.2", %"flo.2"
  %"isetrp_src_to_i32.56" = zext i1 1 to i32
  %"isetrp_src_to_i1.56" = icmp ne i32 %"isetrp_src_to_i32.56", 0
  %"isetrp_cmp2.56" = and i1 %"isetrp_cmp1.56", %"isetrp_src_to_i1.56"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.56" to i32
  %"imad_tmp.50" = mul i32 0, 0
  %"imad.53" = add i32 %"imad_tmp.50", %"redux_sync_and.2"
  br label %"BB_29d0"
BB_29d0:
  %"cond_trunc.52" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.52" = zext i1 %"cond_trunc.52" to i32
  %"pbra_cond_to_i1.52" = icmp ne i32 %"pbra_cond_to_i32.52", 0
  br i1 %"pbra_cond_to_i1.52", label %"BB_800029d0", label %"BB_2a40"
BB_800029d0:
  %"atoms_shared_addr_winoff.7" = and i32 %".1170", 16777215
  %".1265" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.7"
  %"atoms_ptr.7" = bitcast i8 addrspace(3)* %".1265" to i32 addrspace(3)*
  %"atoms_and.2" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.7", i32 %"imad.53" monotonic
  br label %"BB_2a40"
BB_2a00_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2a40"
BB_2a30_3050:
  call void @"llvm.trap"()
  br label %"BB_2a40"
BB_2a40:
  %"s2ur_cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.51" = mul i32 0, 0
  %"imad.54" = add i32 %"imad_tmp.51", 15
  %"imad_tmp.52" = mul i32 0, 0
  %"imad.55" = add i32 %"imad_tmp.52", 1
  %".1269" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".1270" = zext i32 1024 to i64
  %".1271" = zext i32 24 to i64
  %".1272" = shl i64 %".1269", %".1271"
  %".1273" = and i64 %".1272", 4294967295
  %".1274" = add i64 %".1273", %".1270"
  %".1275" = trunc i64 %".1274" to i32
  %"lds_addr_memaddr_offset_add.7" = add i32 %".1275", 2068
  %"lds_shared_addr_winoff.15" = and i32 %"lds_addr_memaddr_offset_add.7", 16777215
  %".1276" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.15"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".1276" to i32 addrspace(3)*
  %"lds.15" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.10"
  %".1277" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".1278" = zext i32 80 to i64
  %".1279" = zext i32 24 to i64
  %".1280" = shl i64 %".1277", %".1279"
  %".1281" = and i64 %".1280", 4294967295
  %".1282" = add i64 %".1281", %".1278"
  %".1283" = trunc i64 %".1282" to i32
  %"lds_shared_addr_winoff.16" = and i32 %".1283", 16777215
  %".1284" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.16"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".1284" to i32 addrspace(3)*
  %"lds.16" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.11"
  %".1285" = xor i32 %"lds.15", -1
  %".1286" = xor i32 65535, -1
  %".1287" = xor i32 0, -1
  %".1288" = and i32 %"lds.15", 65535
  %".1289" = and i32 %".1288", %".1287"
  %".1290" = and i32 %"lds.15", 65535
  %".1291" = and i32 %".1290", 0
  %".1292" = or i32 %".1289", %".1291"
  %".1293" = zext i32 0 to i64
  %".1294" = zext i32 %".1292" to i64
  %".1295" = shl i64 %".1294", 32
  %"shf_concat.29" = or i64 %".1293", %".1295"
  %"shf_shift_64.29" = zext i32 5 to i64
  %".1296" = lshr i64 %"shf_concat.29", %"shf_shift_64.29"
  %"shf_hi.11" = lshr i64 %".1296", 32
  %"shf_result.29" = trunc i64 %"shf_hi.11" to i32
  %"viadd.14" = add i32 %"shf_result.29", 16
  %".1297" = zext i32 %"imad.54" to i64
  %".1298" = zext i32 0 to i64
  %".1299" = shl i64 %".1298", 32
  %"shf_concat.30" = or i64 %".1297", %".1299"
  %"shf_shift_64.30" = zext i32 %"shf_result.29" to i64
  %".1300" = shl i64 %"shf_concat.30", %"shf_shift_64.30"
  %"shf_result.30" = trunc i64 %".1300" to i32
  %".1301" = zext i32 %"imad.55" to i64
  %".1302" = zext i32 0 to i64
  %".1303" = shl i64 %".1302", 32
  %"shf_concat.31" = or i64 %".1301", %".1303"
  %"shf_shift_64.31" = zext i32 %"viadd.14" to i64
  %".1304" = shl i64 %"shf_concat.31", %"shf_shift_64.31"
  %"shf_result.31" = trunc i64 %".1304" to i32
  %".1305" = xor i32 %"shf_result.31", -1
  %".1306" = xor i32 %"shf_result.30", -1
  %".1307" = xor i32 0, -1
  %".1308" = and i32 %".1305", %"shf_result.30"
  %".1309" = and i32 %".1308", %".1307"
  %".1310" = and i32 %".1305", %"shf_result.30"
  %".1311" = and i32 %".1310", 0
  %".1312" = or i32 %".1309", %".1311"
  %".1313" = and i32 %"shf_result.31", %".1306"
  %".1314" = and i32 %".1313", %".1307"
  %".1315" = or i32 %".1312", %".1314"
  %".1316" = and i32 %"shf_result.31", %".1306"
  %".1317" = and i32 %".1316", 0
  %".1318" = or i32 %".1315", %".1317"
  %".1319" = and i32 %"shf_result.31", %"shf_result.30"
  %".1320" = and i32 %".1319", %".1307"
  %".1321" = or i32 %".1318", %".1320"
  %".1322" = and i32 %"shf_result.31", %"shf_result.30"
  %".1323" = and i32 %".1322", 0
  %".1324" = or i32 %".1321", %".1323"
  %".1325" = xor i32 %".1324", -1
  %".1326" = xor i32 65535, -1
  %".1327" = xor i32 0, -1
  %".1328" = and i32 %".1324", 65535
  %".1329" = and i32 %".1328", %".1327"
  %".1330" = and i32 %".1324", 65535
  %".1331" = and i32 %".1330", 0
  %".1332" = or i32 %".1329", %".1331"
  %".1333" = xor i32 %".1324", -1
  %".1334" = xor i32 65535, -1
  %".1335" = xor i32 %"lds.16", -1
  %".1336" = and i32 %".1324", 65535
  %".1337" = and i32 %".1336", %"lds.16"
  %"isetrp_cmp1.57" = icmp ne i32 %".1337", %".1332"
  %"isetrp_src_to_i32.57" = zext i1 1 to i32
  %"isetrp_src_to_i1.57" = icmp ne i32 %"isetrp_src_to_i32.57", 0
  %"isetrp_cmp2.57" = and i1 %"isetrp_cmp1.57", %"isetrp_src_to_i1.57"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.57" to i32
  br label %"BB_2b80"
BB_2b80:
  %"cond_trunc.53" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.53" = zext i1 %"cond_trunc.53" to i32
  %"pbra_cond_to_i1.53" = icmp ne i32 %"pbra_cond_to_i32.53", 0
  br i1 %"pbra_cond_to_i1.53", label %"BB_2ce0_3050", label %"BB_2b90"
BB_2b90:
  %".1340" = zext i32 0 to i64
  %".1341" = zext i32 %"lds.16" to i64
  %".1342" = shl i64 %".1341", 32
  %"shf_concat.32" = or i64 %".1340", %".1342"
  %"shf_shift_64.32" = zext i32 16 to i64
  %".1343" = lshr i64 %"shf_concat.32", %"shf_shift_64.32"
  %"shf_hi.12" = lshr i64 %".1343", 32
  %"shf_result.32" = trunc i64 %"shf_hi.12" to i32
  %".1344" = zext i32 0 to i64
  %".1345" = zext i32 %".1324" to i64
  %".1346" = shl i64 %".1345", 32
  %"shf_concat.33" = or i64 %".1344", %".1346"
  %"shf_shift_64.33" = zext i32 16 to i64
  %".1347" = lshr i64 %"shf_concat.33", %"shf_shift_64.33"
  %"shf_hi.13" = lshr i64 %".1347", 32
  %"shf_result.33" = trunc i64 %"shf_hi.13" to i32
  %".1348" = xor i32 %"shf_result.32", -1
  %".1349" = xor i32 %"shf_result.33", -1
  %".1350" = xor i32 0, -1
  %".1351" = and i32 %"shf_result.32", %"shf_result.33"
  %".1352" = and i32 %".1351", %".1350"
  %".1353" = and i32 %"shf_result.32", %"shf_result.33"
  %".1354" = and i32 %".1353", 0
  %".1355" = or i32 %".1352", %".1354"
  %"isetrp_cmp1.58" = icmp ne i32 %".1355", %"shf_result.33"
  %"isetrp_src_to_i32.58" = zext i1 1 to i32
  %"isetrp_src_to_i1.58" = icmp ne i32 %"isetrp_src_to_i32.58", 0
  %"isetrp_cmp2.58" = and i1 %"isetrp_cmp1.58", %"isetrp_src_to_i1.58"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.58" to i32
  br label %"BB_2bd0"
BB_2bd0:
  %"cond_trunc.54" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.54" = zext i1 %"cond_trunc.54" to i32
  %"pbra_cond_to_i1.54" = icmp ne i32 %"pbra_cond_to_i32.54", 0
  br i1 %"pbra_cond_to_i1.54", label %"BB_2cb0_2ff0", label %"BB_2be0"
BB_2be0:
  %"activemask.3" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.3" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.3" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.3", i1 0)
  %"flo.3" = sub i32 31, %"flo_clz.3"
  %".1358" = xor i32 0, -1
  %".1359" = xor i32 %".1324", -1
  %".1360" = xor i32 0, -1
  %".1361" = and i32 %".1358", %".1359"
  %".1362" = and i32 %".1361", %".1360"
  %".1363" = and i32 %".1358", %".1359"
  %".1364" = and i32 %".1363", 0
  %".1365" = or i32 %".1362", %".1364"
  %".1366" = and i32 0, %".1359"
  %".1367" = and i32 %".1366", %".1360"
  %".1368" = or i32 %".1365", %".1367"
  %".1369" = and i32 0, %".1359"
  %".1370" = and i32 %".1369", 0
  %".1371" = or i32 %".1368", %".1370"
  %"imad_tmp.53" = mul i32 0, 0
  %"imad.56" = add i32 %"imad_tmp.53", %".1371"
  %"redux_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.3" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.56", i32 %"redux_mask.3")
  %".1372" = xor i32 %".1371", -1
  %".1373" = call i32 @"llvm.cttz.i32"(i32 %".1372", i1 0)
  %".1374" = shl i32 %".1373", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".1374") convergent
  %"isetrp_cmp1.59" = icmp eq i32 %"laneid.3", %"flo.3"
  %"isetrp_src_to_i32.59" = zext i1 1 to i32
  %"isetrp_src_to_i1.59" = icmp ne i32 %"isetrp_src_to_i32.59", 0
  %"isetrp_cmp2.59" = and i1 %"isetrp_cmp1.59", %"isetrp_src_to_i1.59"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.59" to i32
  %"imad_tmp.54" = mul i32 0, 0
  %"imad.57" = add i32 %"imad_tmp.54", %"redux_sync_and.3"
  br label %"BB_2c80"
BB_2c80:
  %"cond_trunc.55" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.55" = zext i1 %"cond_trunc.55" to i32
  %"pbra_cond_to_i1.55" = icmp ne i32 %"pbra_cond_to_i32.55", 0
  br i1 %"pbra_cond_to_i1.55", label %"BB_80002c80", label %"BB_2cf0"
BB_80002c80:
  %"atoms_shared_addr_winoff.8" = and i32 %".1283", 16777215
  %".1378" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.8"
  %"atoms_ptr.8" = bitcast i8 addrspace(3)* %".1378" to i32 addrspace(3)*
  %"atoms_and.3" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.8", i32 %"imad.57" monotonic
  br label %"BB_2cf0"
BB_2cb0_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2cf0"
BB_2ce0_3050:
  call void @"llvm.trap"()
  br label %"BB_2cf0"
BB_2cf0:
  %"s2ur_cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.55" = mul i32 0, 0
  %"imad.58" = add i32 %"imad_tmp.55", 255
  %"imad_tmp.56" = mul i32 0, 0
  %"imad.59" = add i32 %"imad_tmp.56", 1
  %".1382" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".1383" = zext i32 1024 to i64
  %".1384" = zext i32 24 to i64
  %".1385" = shl i64 %".1382", %".1384"
  %".1386" = and i64 %".1385", 4294967295
  %".1387" = add i64 %".1386", %".1383"
  %".1388" = trunc i64 %".1387" to i32
  %"lds_addr_memaddr_offset_add.8" = add i32 %".1388", 2072
  %"lds_shared_addr_winoff.17" = and i32 %"lds_addr_memaddr_offset_add.8", 16777215
  %".1389" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.17"
  %"lds_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".1389" to i32 addrspace(3)*
  %"lds.17" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.12"
  %".1390" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".1391" = zext i32 80 to i64
  %".1392" = zext i32 24 to i64
  %".1393" = shl i64 %".1390", %".1392"
  %".1394" = and i64 %".1393", 4294967295
  %".1395" = add i64 %".1394", %".1391"
  %".1396" = trunc i64 %".1395" to i32
  %"lds_shared_addr_winoff.18" = and i32 %".1396", 16777215
  %".1397" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.18"
  %"lds_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".1397" to i32 addrspace(3)*
  %"lds.18" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.13"
  %".1398" = xor i32 %"lds.17", -1
  %".1399" = xor i32 65535, -1
  %".1400" = xor i32 0, -1
  %".1401" = and i32 %"lds.17", 65535
  %".1402" = and i32 %".1401", %".1400"
  %".1403" = and i32 %"lds.17", 65535
  %".1404" = and i32 %".1403", 0
  %".1405" = or i32 %".1402", %".1404"
  %".1406" = zext i32 0 to i64
  %".1407" = zext i32 %".1405" to i64
  %".1408" = shl i64 %".1407", 32
  %"shf_concat.34" = or i64 %".1406", %".1408"
  %"shf_shift_64.34" = zext i32 5 to i64
  %".1409" = lshr i64 %"shf_concat.34", %"shf_shift_64.34"
  %"shf_hi.14" = lshr i64 %".1409", 32
  %"shf_result.34" = trunc i64 %"shf_hi.14" to i32
  %"viadd.15" = add i32 %"shf_result.34", 16
  %".1410" = zext i32 %"imad.58" to i64
  %".1411" = zext i32 0 to i64
  %".1412" = shl i64 %".1411", 32
  %"shf_concat.35" = or i64 %".1410", %".1412"
  %"shf_shift_64.35" = zext i32 %"shf_result.34" to i64
  %".1413" = shl i64 %"shf_concat.35", %"shf_shift_64.35"
  %"shf_result.35" = trunc i64 %".1413" to i32
  %".1414" = zext i32 %"imad.59" to i64
  %".1415" = zext i32 0 to i64
  %".1416" = shl i64 %".1415", 32
  %"shf_concat.36" = or i64 %".1414", %".1416"
  %"shf_shift_64.36" = zext i32 %"viadd.15" to i64
  %".1417" = shl i64 %"shf_concat.36", %"shf_shift_64.36"
  %"shf_result.36" = trunc i64 %".1417" to i32
  %".1418" = xor i32 %"shf_result.36", -1
  %".1419" = xor i32 %"shf_result.35", -1
  %".1420" = xor i32 0, -1
  %".1421" = and i32 %".1418", %"shf_result.35"
  %".1422" = and i32 %".1421", %".1420"
  %".1423" = and i32 %".1418", %"shf_result.35"
  %".1424" = and i32 %".1423", 0
  %".1425" = or i32 %".1422", %".1424"
  %".1426" = and i32 %"shf_result.36", %".1419"
  %".1427" = and i32 %".1426", %".1420"
  %".1428" = or i32 %".1425", %".1427"
  %".1429" = and i32 %"shf_result.36", %".1419"
  %".1430" = and i32 %".1429", 0
  %".1431" = or i32 %".1428", %".1430"
  %".1432" = and i32 %"shf_result.36", %"shf_result.35"
  %".1433" = and i32 %".1432", %".1420"
  %".1434" = or i32 %".1431", %".1433"
  %".1435" = and i32 %"shf_result.36", %"shf_result.35"
  %".1436" = and i32 %".1435", 0
  %".1437" = or i32 %".1434", %".1436"
  %".1438" = xor i32 %".1437", -1
  %".1439" = xor i32 65535, -1
  %".1440" = xor i32 0, -1
  %".1441" = and i32 %".1437", 65535
  %".1442" = and i32 %".1441", %".1440"
  %".1443" = and i32 %".1437", 65535
  %".1444" = and i32 %".1443", 0
  %".1445" = or i32 %".1442", %".1444"
  %".1446" = xor i32 %".1437", -1
  %".1447" = xor i32 65535, -1
  %".1448" = xor i32 %"lds.18", -1
  %".1449" = and i32 %".1437", 65535
  %".1450" = and i32 %".1449", %"lds.18"
  %"isetrp_cmp1.60" = icmp ne i32 %".1450", %".1445"
  %"isetrp_src_to_i32.60" = zext i1 1 to i32
  %"isetrp_src_to_i1.60" = icmp ne i32 %"isetrp_src_to_i32.60", 0
  %"isetrp_cmp2.60" = and i1 %"isetrp_cmp1.60", %"isetrp_src_to_i1.60"
  %"P33_to_i32" = zext i1 %"isetrp_cmp2.60" to i32
  br label %"BB_2e30"
BB_2e30:
  %"cond_trunc.56" = trunc i32 %"P33_to_i32" to i1
  %"pbra_cond_to_i32.56" = zext i1 %"cond_trunc.56" to i32
  %"pbra_cond_to_i1.56" = icmp ne i32 %"pbra_cond_to_i32.56", 0
  br i1 %"pbra_cond_to_i1.56", label %"BB_2f90_3050", label %"BB_2e40"
BB_2e40:
  %".1453" = zext i32 0 to i64
  %".1454" = zext i32 %"lds.18" to i64
  %".1455" = shl i64 %".1454", 32
  %"shf_concat.37" = or i64 %".1453", %".1455"
  %"shf_shift_64.37" = zext i32 16 to i64
  %".1456" = lshr i64 %"shf_concat.37", %"shf_shift_64.37"
  %"shf_hi.15" = lshr i64 %".1456", 32
  %"shf_result.37" = trunc i64 %"shf_hi.15" to i32
  %".1457" = zext i32 0 to i64
  %".1458" = zext i32 %".1437" to i64
  %".1459" = shl i64 %".1458", 32
  %"shf_concat.38" = or i64 %".1457", %".1459"
  %"shf_shift_64.38" = zext i32 16 to i64
  %".1460" = lshr i64 %"shf_concat.38", %"shf_shift_64.38"
  %"shf_hi.16" = lshr i64 %".1460", 32
  %"shf_result.38" = trunc i64 %"shf_hi.16" to i32
  %".1461" = xor i32 %"shf_result.37", -1
  %".1462" = xor i32 %"shf_result.38", -1
  %".1463" = xor i32 0, -1
  %".1464" = and i32 %"shf_result.37", %"shf_result.38"
  %".1465" = and i32 %".1464", %".1463"
  %".1466" = and i32 %"shf_result.37", %"shf_result.38"
  %".1467" = and i32 %".1466", 0
  %".1468" = or i32 %".1465", %".1467"
  %"isetrp_cmp1.61" = icmp ne i32 %".1468", %"shf_result.38"
  %"isetrp_src_to_i32.61" = zext i1 1 to i32
  %"isetrp_src_to_i1.61" = icmp ne i32 %"isetrp_src_to_i32.61", 0
  %"isetrp_cmp2.61" = and i1 %"isetrp_cmp1.61", %"isetrp_src_to_i1.61"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.61" to i32
  br label %"BB_2e80"
BB_2e80:
  %"cond_trunc.57" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.57" = zext i1 %"cond_trunc.57" to i32
  %"pbra_cond_to_i1.57" = icmp ne i32 %"pbra_cond_to_i32.57", 0
  br i1 %"pbra_cond_to_i1.57", label %"BB_2f60_2ff0", label %"BB_2e90"
BB_2e90:
  %"activemask.4" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.4" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.4" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.4", i1 0)
  %"flo.4" = sub i32 31, %"flo_clz.4"
  %".1471" = xor i32 0, -1
  %".1472" = xor i32 %".1437", -1
  %".1473" = xor i32 0, -1
  %".1474" = and i32 %".1471", %".1472"
  %".1475" = and i32 %".1474", %".1473"
  %".1476" = and i32 %".1471", %".1472"
  %".1477" = and i32 %".1476", 0
  %".1478" = or i32 %".1475", %".1477"
  %".1479" = and i32 0, %".1472"
  %".1480" = and i32 %".1479", %".1473"
  %".1481" = or i32 %".1478", %".1480"
  %".1482" = and i32 0, %".1472"
  %".1483" = and i32 %".1482", 0
  %".1484" = or i32 %".1481", %".1483"
  %"imad_tmp.57" = mul i32 0, 0
  %"imad.60" = add i32 %"imad_tmp.57", %".1484"
  %"redux_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.4" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.60", i32 %"redux_mask.4")
  %".1485" = xor i32 %".1484", -1
  %".1486" = call i32 @"llvm.cttz.i32"(i32 %".1485", i1 0)
  %".1487" = shl i32 %".1486", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 256;", "r,~{memory}"(i32 %".1487") convergent
  %"isetrp_cmp1.62" = icmp eq i32 %"laneid.4", %"flo.4"
  %"isetrp_src_to_i32.62" = zext i1 1 to i32
  %"isetrp_src_to_i1.62" = icmp ne i32 %"isetrp_src_to_i32.62", 0
  %"isetrp_cmp2.62" = and i1 %"isetrp_cmp1.62", %"isetrp_src_to_i1.62"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.62" to i32
  %"imad_tmp.58" = mul i32 0, 0
  %"imad.61" = add i32 %"imad_tmp.58", %"redux_sync_and.4"
  br label %"BB_2f30"
BB_2f30:
  %"cond_trunc.58" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.58" = zext i1 %"cond_trunc.58" to i32
  %"pbra_cond_to_i1.58" = icmp ne i32 %"pbra_cond_to_i32.58", 0
  br i1 %"pbra_cond_to_i1.58", label %"BB_80002f30", label %"BB_2fa0"
BB_80002f30:
  %"atoms_shared_addr_winoff.9" = and i32 %".1396", 16777215
  %".1491" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.9"
  %"atoms_ptr.9" = bitcast i8 addrspace(3)* %".1491" to i32 addrspace(3)*
  %"atoms_and.4" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.9", i32 %"imad.61" monotonic
  br label %"BB_2fa0"
BB_2f60_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2fa0"
BB_2f90_3050:
  call void @"llvm.trap"()
  br label %"BB_2fa0"
BB_2fa0:
  ret void
BB_80002280:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"P109_to_i32" = zext i1 0 to i32
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0050"
BB_0050:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0280", label %"BB_0060"
BB_0060:
  %".24" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".25" = bitcast i8* %".24" to i64*
  %"ldc_const" = load i64, i64* %".25"
  %"UR5:UR4_r0" = trunc i64 %"ldc_const" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x.1", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".26" = xor i32 %"imad", -1
  %".27" = xor i32 508, -1
  %".28" = xor i32 0, -1
  %".29" = and i32 %"imad", 508
  %".30" = and i32 %".29", %".28"
  %".31" = and i32 %"imad", 508
  %".32" = and i32 %".31", 0
  %".33" = or i32 %".30", %".32"
  %"iadd3_o1_64" = zext i32 %".33" to i64
  %"iadd3_o2_64" = zext i32 %"UR5:UR4_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P110_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR5:UR4_r1"
  %"imad_cin_trunc" = trunc i32 %"P110_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R50:R11_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R50:R11_addr_ptr"
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".34" = zext i32 %"cluster_ctarank" to i64
  %".35" = zext i32 %"viadd" to i64
  %".36" = zext i32 24 to i64
  %".37" = shl i64 %".34", %".36"
  %".38" = and i64 %".37", 4294967295
  %".39" = add i64 %".38", %".35"
  %".40" = trunc i64 %".39" to i32
  %"imad_tmp.2" = mul i32 %"imad", 1
  %"imad.2" = add i32 %"imad_tmp.2", %".40"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"imad.2", %"BB_0060"], [%"viadd.2", %"BB_0170"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"BB_0060"], [%"viadd.1", %"BB_0170"]
  %"isetrp_cmp1.1" = icmp uge i32 %"phi.1", 128
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P52_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi", 16777215
  %".42" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".42" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 128
  %"viadd.2" = add i32 %"phi", 512
  br label %"BB_0170"
BB_0170:
  %"cond_trunc.1" = trunc i32 %"P52_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0130", label %"BB_0180"
BB_0180:
  %".46" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".47" = bitcast i8* %".46" to i64*
  %"ldc_const.1" = load i64, i64* %".47"
  %"R5:R4_r0" = trunc i64 %"ldc_const.1" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %".48" = zext i32 %"cluster_ctarank" to i64
  %".49" = zext i32 1024 to i64
  %".50" = zext i32 24 to i64
  %".51" = shl i64 %".48", %".50"
  %".52" = and i64 %".51", 4294967295
  %".53" = add i64 %".52", %".49"
  %".54" = trunc i64 %".53" to i32
  %"imad_tmp.3" = mul i32 %"imad", 1
  %"imad.3" = add i32 %"imad_tmp.3", %".54"
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.4" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad.4" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.4", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P63_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %"R5:R4_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P63_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.5", %"imad_cin_ext.1"
  br label %"BB_0200"
BB_0200:
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_0180"], [%"viadd.3", %"BB_0270"]
  %"phi.3" = phi  i32 [%"imad_with_cin.1", %"BB_0180"], [%"imad_with_cin.2", %"BB_0270"]
  %"phi.4" = phi  i32 [%"iadd3_trunc.1", %"BB_0180"], [%"iadd3_trunc.2", %"BB_0270"]
  %"phi.5" = phi  i32 [%"imad.3", %"BB_0180"], [%"viadd.4", %"BB_0270"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R89:R48_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R89:R48_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P86_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.3" = add i32 %"phi.2", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P124_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %"phi.3"
  %"imad_cin_trunc.2" = trunc i32 %"P124_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.6", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.5", 16777215
  %".56" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".56" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.4" = add i32 %"phi.5", 512
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.2" = trunc i32 %"P86_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0200", label %"BB_0280"
BB_0280:
  %"phi.6" = phi  i32 [0, %"BB_0050"], [%"UR5:UR4_r1", %"BB_0270"]
  %"phi.7" = phi  i32 [0, %"BB_0050"], [%"ldg.1", %"BB_0270"]
  %"phi.8" = phi  i32 [0, %"BB_0050"], [%"viadd.4", %"BB_0270"]
  %"phi.9" = phi  i32 [%"P109_to_i32", %"BB_0050"], [%"P124_to_i32", %"BB_0270"]
  %"isetrp_cmp1.3" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P76_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  br label %"BB_02b0"
BB_02b0:
  %"cond_trunc.3" = trunc i32 %"P76_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002b0", label %"BB_02d0"
BB_800002b0:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"cluster_ctarank.1", %"BB_800002b0"], [%"phi.7", %"BB_02b0"]
  %"phi.11" = phi  i32 [1024, %"BB_800002b0"], [%"phi.8", %"BB_02b0"]
  %"vote_pred_trunc" = trunc i32 %"P76_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P9_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P76_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_02f0"
BB_800002e0:
  %"viadd.5" = add i32 %"phi.11", 2048
  br label %"BB_02f0"
BB_02f0:
  %"phi.12" = phi  i32 [%"viadd.5", %"BB_800002e0"], [%"phi.11", %"BB_02e0"]
  %"cond_trunc.5" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800002f0", label %"BB_0320"
BB_800002f0:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".67" = zext i32 %"iadd3_n2" to i64
  %".68" = zext i32 0 to i64
  %".69" = shl i64 %".68", 32
  %"shf_concat" = or i64 %".67", %".69"
  %"shf_shift_64" = zext i32 11 to i64
  %".70" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".70" to i32
  %".71" = zext i32 %"iadd3_n2" to i64
  %".72" = zext i32 0 to i64
  %".73" = shl i64 %".72", 32
  %"shf_concat.1" = or i64 %".71", %".73"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".74" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".74" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.13" = phi  i32 [%"shf_result", %"BB_800002f0"], [%"phi.6", %"BB_02f0"]
  %"phi.14" = phi  i32 [%"shf_result.1", %"BB_800002f0"], [1, %"BB_02f0"]
  %"vote_pred_trunc.1" = trunc i32 %"P76_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P18_to_i32" = zext i1 %"vote_all.1" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.6" = trunc i32 %"P76_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_80000330", label %"BB_0350"
BB_80000330:
  %".78" = zext i32 %"phi.10" to i64
  %".79" = zext i32 %"phi.12" to i64
  %".80" = zext i32 24 to i64
  %".81" = shl i64 %".78", %".80"
  %".82" = and i64 %".81", 4294967295
  %".83" = add i64 %".82", %".79"
  %".84" = trunc i64 %".83" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.15" = phi  i32 [%".84", %"BB_80000330"], [0, %"BB_0330"]
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.7" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.7", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.15", 16777215
  %".89" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".89" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.14" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".90" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".90" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.8" = trunc i32 %"P30_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0680", label %"BB_0390"
BB_0390:
  %"cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".94" = zext i32 %"cluster_ctarank.2" to i64
  %".95" = zext i32 64 to i64
  %".96" = zext i32 24 to i64
  %".97" = shl i64 %".94", %".96"
  %".98" = and i64 %".97", 4294967295
  %".99" = add i64 %".98", %".95"
  %".100" = trunc i64 %".99" to i32
  %"lds_shared_addr_winoff" = and i32 %".100", 16777215
  %".101" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".101"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P117_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0410"
BB_0410:
  %"cond_trunc.9" = trunc i32 %"P117_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0610", label %"BB_0420"
BB_0420:
  %"allocation_slot_winoff" = and i32 3080, 16777215
  %".104" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".105" = ptrtoint i8 addrspace(3)* %".104" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".105", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P34_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0430"
BB_0430:
  %"cond_trunc.10" = trunc i32 %"P34_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0680", label %"BB_0440"
BB_0440:
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", 1
  %"tmem_alloc_winoff" = and i32 3080, 16777215
  %".109" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".110" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %".111" = load i32, i32 addrspace(3)* %".110"
  %".112" = lshr i32 %".111", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P25_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".113" = xor i32 %"plop3_a_bit", 1
  %".114" = xor i32 %"plop3_b_bit", 1
  %".115" = xor i32 %"plop3_c_bit", 1
  %".116" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".117" = and i32 %".116", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".117", 0
  %"P55_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P55_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P66_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", %".112"
  br label %"BB_04c0"
BB_04c0:
  %"cond_trunc.11" = trunc i32 %"P66_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0560", label %"BB_04d0"
BB_04d0:
  %"tmem_alloc_winoff.1" = and i32 3080, 16777215
  %".120" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".121" = bitcast i8 addrspace(3)* %".120" to i32 addrspace(3)*
  %".122" = load i32, i32 addrspace(3)* %".121"
  %".123" = lshr i32 %".122", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".124" = xor i32 %"plop3_a_bit.1", 1
  %".125" = xor i32 %"plop3_b_bit.1", 1
  %".126" = xor i32 %"plop3_c_bit.1", 1
  %".127" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".128" = and i32 %".127", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".128", 0
  %"P88_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P88_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P99_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", %".123"
  br label %"BB_0550"
BB_0550:
  %"cond_trunc.12" = trunc i32 %"P99_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_04d0", label %"BB_0560"
BB_0560:
  %"phi.16" = phi  i32 [%"imad.8", %"BB_04c0"], [%"imad.9", %"BB_0550"]
  %"viadd.6" = add i32 %"phi.16", 16
  %".131" = zext i32 %"imad.7" to i64
  %".132" = zext i32 0 to i64
  %".133" = shl i64 %".132", 32
  %"shf_concat.2" = or i64 %".131", %".133"
  %"shf_shift_64.2" = zext i32 %"phi.16" to i64
  %".134" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".134" to i32
  %"imad_tmp.9" = mul i32 %"phi.16", 32
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %".135" = zext i32 %"imad.7" to i64
  %".136" = zext i32 0 to i64
  %".137" = shl i64 %".136", 32
  %"shf_concat.3" = or i64 %".135", %".137"
  %"shf_shift_64.3" = zext i32 %"viadd.6" to i64
  %".138" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".138" to i32
  %".139" = zext i32 %"cluster_ctarank.2" to i64
  %".140" = zext i32 1024 to i64
  %".141" = zext i32 24 to i64
  %".142" = shl i64 %".139", %".141"
  %".143" = and i64 %".142", 4294967295
  %".144" = add i64 %".143", %".140"
  %".145" = trunc i64 %".144" to i32
  %".146" = zext i32 %"cluster_ctarank.2" to i64
  %".147" = zext i32 80 to i64
  %".148" = zext i32 24 to i64
  %".149" = shl i64 %".146", %".148"
  %".150" = and i64 %".149", 4294967295
  %".151" = add i64 %".150", %".147"
  %".152" = trunc i64 %".151" to i32
  %".153" = xor i32 %"shf_result.3", -1
  %".154" = xor i32 %"shf_result.2", -1
  %".155" = xor i32 0, -1
  %".156" = and i32 %".153", %"shf_result.2"
  %".157" = and i32 %".156", %".155"
  %".158" = and i32 %".153", %"shf_result.2"
  %".159" = and i32 %".158", 0
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %"shf_result.3", %".154"
  %".162" = and i32 %".161", %".155"
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %"shf_result.3", %".154"
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %"shf_result.3", %"shf_result.2"
  %".168" = and i32 %".167", %".155"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %"shf_result.3", %"shf_result.2"
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %"atoms_shared_addr_winoff" = and i32 %".152", 16777215
  %".173" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".173" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".172" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".145", 2056
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".174" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".174" to i32 addrspace(3)*
  store volatile i32 %"imad.10", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0680"
BB_0610:
  %".177" = zext i32 %"cluster_ctarank.2" to i64
  %".178" = zext i32 1024 to i64
  %".179" = zext i32 24 to i64
  %".180" = shl i64 %".177", %".179"
  %".181" = and i64 %".180", 4294967295
  %".182" = add i64 %".181", %".178"
  %".183" = trunc i64 %".182" to i32
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.10", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".183", 2056
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".184" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".184" to i32 addrspace(3)*
  store volatile i32 %"imad.11", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0650_3020"
BB_0650_3020:
  call void @"llvm.trap"()
  br label %"BB_0680"
BB_0680:
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_06c0"
BB_06c0:
  %"cond_trunc.13" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_1260", label %"BB_06d0"
BB_06d0:
  %"cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".190" = zext i32 %"cluster_ctarank.3" to i64
  %".191" = zext i32 64 to i64
  %".192" = zext i32 24 to i64
  %".193" = shl i64 %".190", %".192"
  %".194" = and i64 %".193", 4294967295
  %".195" = add i64 %".194", %".191"
  %".196" = trunc i64 %".195" to i32
  %"lds_shared_addr_winoff.1" = and i32 %".196", 16777215
  %".197" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds.1" = load volatile i8, i8 addrspace(3)* %".197"
  %"lds_zext.1" = zext i8 %"lds.1" to i32
  %"isetrp_cmp1.9" = icmp ne i32 %"lds_zext.1", 0
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0750"
BB_0750:
  %"cond_trunc.14" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0950", label %"BB_0760"
BB_0760:
  %"allocation_slot_winoff.1" = and i32 3084, 16777215
  %".200" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.1"
  %".201" = ptrtoint i8 addrspace(3)* %".200" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".201", i32 32) convergent
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0770"
BB_0770:
  %"cond_trunc.15" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_09a0", label %"BB_0780"
BB_0780:
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.11", 1
  %"tmem_alloc_winoff.2" = and i32 3084, 16777215
  %".205" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.2"
  %".206" = bitcast i8 addrspace(3)* %".205" to i32 addrspace(3)*
  %".207" = load i32, i32 addrspace(3)* %".206"
  %".208" = lshr i32 %".207", 5
  %"P27_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.2" = trunc i32 %"P27_to_i32" to i1
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 %"lop3_c_trunc.2" to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".209" = xor i32 %"plop3_a_bit.2", 1
  %".210" = xor i32 %"plop3_b_bit.2", 1
  %".211" = xor i32 %"plop3_c_bit.2", 1
  %".212" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".213" = and i32 %".212", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".213", 0
  %"P38_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"sel_pred_trunc.2" = trunc i32 %"P38_to_i32" to i1
  %"sel_pred_not.2" = xor i1 %"sel_pred_trunc.2", -1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_not.2" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 0, i32 4294967295
  %"isetrp_cmp1.10" = icmp ne i32 %"sel.2", 0
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", %".208"
  br label %"BB_0800"
BB_0800:
  %"cond_trunc.16" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_08a0", label %"BB_0810"
BB_0810:
  %"tmem_alloc_winoff.3" = and i32 3084, 16777215
  %".216" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.3"
  %".217" = bitcast i8 addrspace(3)* %".216" to i32 addrspace(3)*
  %".218" = load i32, i32 addrspace(3)* %".217"
  %".219" = lshr i32 %".218", 5
  %"P11_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.3" = trunc i32 %"P11_to_i32" to i1
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 %"lop3_c_trunc.3" to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".220" = xor i32 %"plop3_a_bit.3", 1
  %".221" = xor i32 %"plop3_b_bit.3", 1
  %".222" = xor i32 %"plop3_c_bit.3", 1
  %".223" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".224" = and i32 %".223", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".224", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"sel_pred_trunc.3" = trunc i32 %"P40_to_i32" to i1
  %"sel_pred_not.3" = xor i1 %"sel_pred_trunc.3", -1
  %"sel_pred_to_i32.3" = zext i1 %"sel_pred_not.3" to i32
  %"sel_pred_to_i1.3" = icmp ne i32 %"sel_pred_to_i32.3", 0
  %"sel.3" = select  i1 %"sel_pred_to_i1.3", i32 0, i32 4294967295
  %"isetrp_cmp1.11" = icmp ne i32 %"sel.3", 0
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", %".219"
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.17" = trunc i32 %"P41_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0810", label %"BB_08a0"
BB_08a0:
  %"phi.17" = phi  i32 [%"imad.13", %"BB_0800"], [%"imad.14", %"BB_0890"]
  %"viadd.7" = add i32 %"phi.17", 16
  %".227" = zext i32 %"imad.12" to i64
  %".228" = zext i32 0 to i64
  %".229" = shl i64 %".228", 32
  %"shf_concat.4" = or i64 %".227", %".229"
  %"shf_shift_64.4" = zext i32 %"phi.17" to i64
  %".230" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".230" to i32
  %"imad_tmp.14" = mul i32 %"phi.17", 32
  %"imad.15" = add i32 %"imad_tmp.14", 0
  %".231" = zext i32 %"imad.12" to i64
  %".232" = zext i32 0 to i64
  %".233" = shl i64 %".232", 32
  %"shf_concat.5" = or i64 %".231", %".233"
  %"shf_shift_64.5" = zext i32 %"viadd.7" to i64
  %".234" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".234" to i32
  %".235" = zext i32 %"cluster_ctarank.3" to i64
  %".236" = zext i32 80 to i64
  %".237" = zext i32 24 to i64
  %".238" = shl i64 %".235", %".237"
  %".239" = and i64 %".238", 4294967295
  %".240" = add i64 %".239", %".236"
  %".241" = trunc i64 %".240" to i32
  %".242" = xor i32 %"shf_result.5", -1
  %".243" = xor i32 %"shf_result.4", -1
  %".244" = xor i32 0, -1
  %".245" = and i32 %".242", %"shf_result.4"
  %".246" = and i32 %".245", %".244"
  %".247" = and i32 %".242", %"shf_result.4"
  %".248" = and i32 %".247", 0
  %".249" = or i32 %".246", %".248"
  %".250" = and i32 %"shf_result.5", %".243"
  %".251" = and i32 %".250", %".244"
  %".252" = or i32 %".249", %".251"
  %".253" = and i32 %"shf_result.5", %".243"
  %".254" = and i32 %".253", 0
  %".255" = or i32 %".252", %".254"
  %".256" = and i32 %"shf_result.5", %"shf_result.4"
  %".257" = and i32 %".256", %".244"
  %".258" = or i32 %".255", %".257"
  %".259" = and i32 %"shf_result.5", %"shf_result.4"
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = zext i32 %"cluster_ctarank.3" to i64
  %".263" = zext i32 1024 to i64
  %".264" = zext i32 24 to i64
  %".265" = shl i64 %".262", %".264"
  %".266" = and i64 %".265", 4294967295
  %".267" = add i64 %".266", %".263"
  %".268" = trunc i64 %".267" to i32
  %"atoms_shared_addr_winoff.1" = and i32 %".241", 16777215
  %".269" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".269" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %".261" monotonic
  %"sts_addr_memaddr_offset_add.2" = add i32 %".268", 2060
  %"sts_shared_addr_winoff.4" = and i32 %"sts_addr_memaddr_offset_add.2", 16777215
  %".270" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".270" to i32 addrspace(3)*
  store volatile i32 %"imad.15", i32 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_09a0"
BB_0950:
  %".273" = zext i32 %"cluster_ctarank.3" to i64
  %".274" = zext i32 1024 to i64
  %".275" = zext i32 24 to i64
  %".276" = shl i64 %".273", %".275"
  %".277" = and i64 %".276", 4294967295
  %".278" = add i64 %".277", %".274"
  %".279" = trunc i64 %".278" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.15", -1
  %"sts_addr_memaddr_offset_add.3" = add i32 %".279", 2060
  %"sts_shared_addr_winoff.5" = and i32 %"sts_addr_memaddr_offset_add.3", 16777215
  %".280" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".280" to i32 addrspace(3)*
  store volatile i32 %"imad.16", i32 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_0990_3020"
BB_0990_3020:
  call void @"llvm.trap"()
  br label %"BB_09a0"
BB_09a0:
  %"cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".284" = zext i32 %"cluster_ctarank.4" to i64
  %".285" = zext i32 64 to i64
  %".286" = zext i32 24 to i64
  %".287" = shl i64 %".284", %".286"
  %".288" = and i64 %".287", 4294967295
  %".289" = add i64 %".288", %".285"
  %".290" = trunc i64 %".289" to i32
  %"lds_shared_addr_winoff.2" = and i32 %".290", 16777215
  %".291" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds.2" = load volatile i8, i8 addrspace(3)* %".291"
  %"lds_zext.2" = zext i8 %"lds.2" to i32
  %"isetrp_cmp1.12" = icmp ne i32 %"lds_zext.2", 0
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P43_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  br label %"BB_0a20"
BB_0a20:
  %"cond_trunc.18" = trunc i32 %"P43_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0c30", label %"BB_0a30"
BB_0a30:
  %"allocation_slot_winoff.2" = and i32 3088, 16777215
  %".294" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.2"
  %".295" = ptrtoint i8 addrspace(3)* %".294" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".295", i32 64) convergent
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P45_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0a40"
BB_0a40:
  %"cond_trunc.19" = trunc i32 %"P45_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0c80", label %"BB_0a50"
BB_0a50:
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.16", 1
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.17", 3
  %"tmem_alloc_winoff.4" = and i32 3088, 16777215
  %".299" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.4"
  %".300" = bitcast i8 addrspace(3)* %".299" to i32 addrspace(3)*
  %".301" = load i32, i32 addrspace(3)* %".300"
  %".302" = lshr i32 %".301", 5
  %"P12_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.4" = trunc i32 %"P12_to_i32" to i1
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 %"lop3_c_trunc.4" to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".303" = xor i32 %"plop3_a_bit.4", 1
  %".304" = xor i32 %"plop3_b_bit.4", 1
  %".305" = xor i32 %"plop3_c_bit.4", 1
  %".306" = and i32 %"plop3_a_bit.4", %"plop3_b_bit.4"
  %".307" = and i32 %".306", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".307", 0
  %"P47_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"sel_pred_trunc.4" = trunc i32 %"P47_to_i32" to i1
  %"sel_pred_not.4" = xor i1 %"sel_pred_trunc.4", -1
  %"sel_pred_to_i32.4" = zext i1 %"sel_pred_not.4" to i32
  %"sel_pred_to_i1.4" = icmp ne i32 %"sel_pred_to_i32.4", 0
  %"sel.4" = select  i1 %"sel_pred_to_i1.4", i32 0, i32 4294967295
  %"isetrp_cmp1.13" = icmp ne i32 %"sel.4", 0
  %"isetrp_src_to_i32.13" = zext i1 1 to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P48_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.18", %".302"
  br label %"BB_0ae0"
BB_0ae0:
  %"cond_trunc.20" = trunc i32 %"P48_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0b80", label %"BB_0af0"
BB_0af0:
  %"tmem_alloc_winoff.5" = and i32 3088, 16777215
  %".310" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.5"
  %".311" = bitcast i8 addrspace(3)* %".310" to i32 addrspace(3)*
  %".312" = load i32, i32 addrspace(3)* %".311"
  %".313" = lshr i32 %".312", 5
  %"P14_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.5" = trunc i32 %"P14_to_i32" to i1
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 %"lop3_c_trunc.5" to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".314" = xor i32 %"plop3_a_bit.5", 1
  %".315" = xor i32 %"plop3_b_bit.5", 1
  %".316" = xor i32 %"plop3_c_bit.5", 1
  %".317" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".318" = and i32 %".317", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".318", 0
  %"P49_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"sel_pred_trunc.5" = trunc i32 %"P49_to_i32" to i1
  %"sel_pred_not.5" = xor i1 %"sel_pred_trunc.5", -1
  %"sel_pred_to_i32.5" = zext i1 %"sel_pred_not.5" to i32
  %"sel_pred_to_i1.5" = icmp ne i32 %"sel_pred_to_i32.5", 0
  %"sel.5" = select  i1 %"sel_pred_to_i1.5", i32 0, i32 4294967295
  %"isetrp_cmp1.14" = icmp ne i32 %"sel.5", 0
  %"isetrp_src_to_i32.14" = zext i1 1 to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P50_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.19", %".313"
  br label %"BB_0b70"
BB_0b70:
  %"cond_trunc.21" = trunc i32 %"P50_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0af0", label %"BB_0b80"
BB_0b80:
  %"phi.18" = phi  i32 [%"imad.19", %"BB_0ae0"], [%"imad.20", %"BB_0b70"]
  %"viadd.8" = add i32 %"phi.18", 16
  %".321" = zext i32 %"imad.18" to i64
  %".322" = zext i32 0 to i64
  %".323" = shl i64 %".322", 32
  %"shf_concat.6" = or i64 %".321", %".323"
  %"shf_shift_64.6" = zext i32 %"phi.18" to i64
  %".324" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".324" to i32
  %"imad_tmp.20" = mul i32 %"phi.18", 32
  %"imad.21" = add i32 %"imad_tmp.20", 0
  %".325" = zext i32 %"imad.17" to i64
  %".326" = zext i32 0 to i64
  %".327" = shl i64 %".326", 32
  %"shf_concat.7" = or i64 %".325", %".327"
  %"shf_shift_64.7" = zext i32 %"viadd.8" to i64
  %".328" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".328" to i32
  %".329" = zext i32 %"cluster_ctarank.4" to i64
  %".330" = zext i32 80 to i64
  %".331" = zext i32 24 to i64
  %".332" = shl i64 %".329", %".331"
  %".333" = and i64 %".332", 4294967295
  %".334" = add i64 %".333", %".330"
  %".335" = trunc i64 %".334" to i32
  %".336" = xor i32 %"shf_result.7", -1
  %".337" = xor i32 %"shf_result.6", -1
  %".338" = xor i32 0, -1
  %".339" = and i32 %".336", %"shf_result.6"
  %".340" = and i32 %".339", %".338"
  %".341" = and i32 %".336", %"shf_result.6"
  %".342" = and i32 %".341", 0
  %".343" = or i32 %".340", %".342"
  %".344" = and i32 %"shf_result.7", %".337"
  %".345" = and i32 %".344", %".338"
  %".346" = or i32 %".343", %".345"
  %".347" = and i32 %"shf_result.7", %".337"
  %".348" = and i32 %".347", 0
  %".349" = or i32 %".346", %".348"
  %".350" = and i32 %"shf_result.7", %"shf_result.6"
  %".351" = and i32 %".350", %".338"
  %".352" = or i32 %".349", %".351"
  %".353" = and i32 %"shf_result.7", %"shf_result.6"
  %".354" = and i32 %".353", 0
  %".355" = or i32 %".352", %".354"
  %".356" = zext i32 %"cluster_ctarank.4" to i64
  %".357" = zext i32 1024 to i64
  %".358" = zext i32 24 to i64
  %".359" = shl i64 %".356", %".358"
  %".360" = and i64 %".359", 4294967295
  %".361" = add i64 %".360", %".357"
  %".362" = trunc i64 %".361" to i32
  %"atoms_shared_addr_winoff.2" = and i32 %".335", 16777215
  %".363" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".363" to i32 addrspace(3)*
  %"atoms_or.2" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.2", i32 %".355" monotonic
  %"sts_addr_memaddr_offset_add.4" = add i32 %".362", 2064
  %"sts_shared_addr_winoff.6" = and i32 %"sts_addr_memaddr_offset_add.4", 16777215
  %".364" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".364" to i32 addrspace(3)*
  store volatile i32 %"imad.21", i32 addrspace(3)* %"sts_shared_addr_cast.6"
  br label %"BB_0c80"
BB_0c30:
  %".367" = zext i32 %"cluster_ctarank.4" to i64
  %".368" = zext i32 1024 to i64
  %".369" = zext i32 24 to i64
  %".370" = shl i64 %".367", %".369"
  %".371" = and i64 %".370", 4294967295
  %".372" = add i64 %".371", %".368"
  %".373" = trunc i64 %".372" to i32
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.21", -1
  %"sts_addr_memaddr_offset_add.5" = add i32 %".373", 2064
  %"sts_shared_addr_winoff.7" = and i32 %"sts_addr_memaddr_offset_add.5", 16777215
  %".374" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.7"
  %"sts_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".374" to i32 addrspace(3)*
  store volatile i32 %"imad.22", i32 addrspace(3)* %"sts_shared_addr_cast.7"
  br label %"BB_0c70_3020"
BB_0c70_3020:
  call void @"llvm.trap"()
  br label %"BB_0c80"
BB_0c80:
  %"cluster_ctarank.5" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".378" = zext i32 %"cluster_ctarank.5" to i64
  %".379" = zext i32 64 to i64
  %".380" = zext i32 24 to i64
  %".381" = shl i64 %".378", %".380"
  %".382" = and i64 %".381", 4294967295
  %".383" = add i64 %".382", %".379"
  %".384" = trunc i64 %".383" to i32
  %"lds_shared_addr_winoff.3" = and i32 %".384", 16777215
  %".385" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds.3" = load volatile i8, i8 addrspace(3)* %".385"
  %"lds_zext.3" = zext i8 %"lds.3" to i32
  %"isetrp_cmp1.15" = icmp ne i32 %"lds_zext.3", 0
  %"isetrp_src_to_i32.15" = zext i1 1 to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P53_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  br label %"BB_0d00"
BB_0d00:
  %"cond_trunc.22" = trunc i32 %"P53_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0f10", label %"BB_0d10"
BB_0d10:
  %"allocation_slot_winoff.3" = and i32 3092, 16777215
  %".388" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.3"
  %".389" = ptrtoint i8 addrspace(3)* %".388" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".389", i32 128) convergent
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P54_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0d20"
BB_0d20:
  %"cond_trunc.23" = trunc i32 %"P54_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.23", -1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_0f60", label %"BB_0d30"
BB_0d30:
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.22", 1
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.23", 15
  %"tmem_alloc_winoff.6" = and i32 3092, 16777215
  %".393" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.6"
  %".394" = bitcast i8 addrspace(3)* %".393" to i32 addrspace(3)*
  %".395" = load i32, i32 addrspace(3)* %".394"
  %".396" = lshr i32 %".395", 5
  %"P16_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.6" = trunc i32 %"P16_to_i32" to i1
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 %"lop3_c_trunc.6" to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".397" = xor i32 %"plop3_a_bit.6", 1
  %".398" = xor i32 %"plop3_b_bit.6", 1
  %".399" = xor i32 %"plop3_c_bit.6", 1
  %".400" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".401" = and i32 %".400", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".401", 0
  %"P57_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"sel_pred_trunc.6" = trunc i32 %"P57_to_i32" to i1
  %"sel_pred_not.6" = xor i1 %"sel_pred_trunc.6", -1
  %"sel_pred_to_i32.6" = zext i1 %"sel_pred_not.6" to i32
  %"sel_pred_to_i1.6" = icmp ne i32 %"sel_pred_to_i32.6", 0
  %"sel.6" = select  i1 %"sel_pred_to_i1.6", i32 0, i32 4294967295
  %"isetrp_cmp1.16" = icmp ne i32 %"sel.6", 0
  %"isetrp_src_to_i32.16" = zext i1 1 to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.24", %".396"
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.24" = trunc i32 %"P58_to_i32" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_0e60", label %"BB_0dd0"
BB_0dd0:
  %"tmem_alloc_winoff.7" = and i32 3092, 16777215
  %".404" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.7"
  %".405" = bitcast i8 addrspace(3)* %".404" to i32 addrspace(3)*
  %".406" = load i32, i32 addrspace(3)* %".405"
  %".407" = lshr i32 %".406", 5
  %"P19_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.7" = trunc i32 %"P19_to_i32" to i1
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 %"lop3_c_trunc.7" to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".408" = xor i32 %"plop3_a_bit.7", 1
  %".409" = xor i32 %"plop3_b_bit.7", 1
  %".410" = xor i32 %"plop3_c_bit.7", 1
  %".411" = and i32 %"plop3_a_bit.7", %"plop3_b_bit.7"
  %".412" = and i32 %".411", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".412", 0
  %"P59_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"sel_pred_trunc.7" = trunc i32 %"P59_to_i32" to i1
  %"sel_pred_not.7" = xor i1 %"sel_pred_trunc.7", -1
  %"sel_pred_to_i32.7" = zext i1 %"sel_pred_not.7" to i32
  %"sel_pred_to_i1.7" = icmp ne i32 %"sel_pred_to_i32.7", 0
  %"sel.7" = select  i1 %"sel_pred_to_i1.7", i32 0, i32 4294967295
  %"isetrp_cmp1.17" = icmp ne i32 %"sel.7", 0
  %"isetrp_src_to_i32.17" = zext i1 1 to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P61_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.25", %".407"
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.25" = trunc i32 %"P61_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.25", -1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_0dd0", label %"BB_0e60"
BB_0e60:
  %"phi.19" = phi  i32 [%"imad.25", %"BB_0dc0"], [%"imad.26", %"BB_0e50"]
  %"viadd.9" = add i32 %"phi.19", 16
  %".415" = zext i32 %"imad.24" to i64
  %".416" = zext i32 0 to i64
  %".417" = shl i64 %".416", 32
  %"shf_concat.8" = or i64 %".415", %".417"
  %"shf_shift_64.8" = zext i32 %"phi.19" to i64
  %".418" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".418" to i32
  %"imad_tmp.26" = mul i32 %"phi.19", 32
  %"imad.27" = add i32 %"imad_tmp.26", 0
  %".419" = zext i32 %"imad.23" to i64
  %".420" = zext i32 0 to i64
  %".421" = shl i64 %".420", 32
  %"shf_concat.9" = or i64 %".419", %".421"
  %"shf_shift_64.9" = zext i32 %"viadd.9" to i64
  %".422" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".422" to i32
  %".423" = zext i32 %"cluster_ctarank.5" to i64
  %".424" = zext i32 80 to i64
  %".425" = zext i32 24 to i64
  %".426" = shl i64 %".423", %".425"
  %".427" = and i64 %".426", 4294967295
  %".428" = add i64 %".427", %".424"
  %".429" = trunc i64 %".428" to i32
  %".430" = xor i32 %"shf_result.9", -1
  %".431" = xor i32 %"shf_result.8", -1
  %".432" = xor i32 0, -1
  %".433" = and i32 %".430", %"shf_result.8"
  %".434" = and i32 %".433", %".432"
  %".435" = and i32 %".430", %"shf_result.8"
  %".436" = and i32 %".435", 0
  %".437" = or i32 %".434", %".436"
  %".438" = and i32 %"shf_result.9", %".431"
  %".439" = and i32 %".438", %".432"
  %".440" = or i32 %".437", %".439"
  %".441" = and i32 %"shf_result.9", %".431"
  %".442" = and i32 %".441", 0
  %".443" = or i32 %".440", %".442"
  %".444" = and i32 %"shf_result.9", %"shf_result.8"
  %".445" = and i32 %".444", %".432"
  %".446" = or i32 %".443", %".445"
  %".447" = and i32 %"shf_result.9", %"shf_result.8"
  %".448" = and i32 %".447", 0
  %".449" = or i32 %".446", %".448"
  %".450" = zext i32 %"cluster_ctarank.5" to i64
  %".451" = zext i32 1024 to i64
  %".452" = zext i32 24 to i64
  %".453" = shl i64 %".450", %".452"
  %".454" = and i64 %".453", 4294967295
  %".455" = add i64 %".454", %".451"
  %".456" = trunc i64 %".455" to i32
  %"atoms_shared_addr_winoff.3" = and i32 %".429", 16777215
  %".457" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".457" to i32 addrspace(3)*
  %"atoms_or.3" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.3", i32 %".449" monotonic
  %"sts_addr_memaddr_offset_add.6" = add i32 %".456", 2068
  %"sts_shared_addr_winoff.8" = and i32 %"sts_addr_memaddr_offset_add.6", 16777215
  %".458" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.8"
  %"sts_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".458" to i32 addrspace(3)*
  store volatile i32 %"imad.27", i32 addrspace(3)* %"sts_shared_addr_cast.8"
  br label %"BB_0f60"
BB_0f10:
  %".461" = zext i32 %"cluster_ctarank.5" to i64
  %".462" = zext i32 1024 to i64
  %".463" = zext i32 24 to i64
  %".464" = shl i64 %".461", %".463"
  %".465" = and i64 %".464", 4294967295
  %".466" = add i64 %".465", %".462"
  %".467" = trunc i64 %".466" to i32
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.28" = add i32 %"imad_tmp.27", -1
  %"sts_addr_memaddr_offset_add.7" = add i32 %".467", 2068
  %"sts_shared_addr_winoff.9" = and i32 %"sts_addr_memaddr_offset_add.7", 16777215
  %".468" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.9"
  %"sts_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".468" to i32 addrspace(3)*
  store volatile i32 %"imad.28", i32 addrspace(3)* %"sts_shared_addr_cast.9"
  br label %"BB_0f50_3020"
BB_0f50_3020:
  call void @"llvm.trap"()
  br label %"BB_0f60"
BB_0f60:
  %"cluster_ctarank.6" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".472" = zext i32 %"cluster_ctarank.6" to i64
  %".473" = zext i32 64 to i64
  %".474" = zext i32 24 to i64
  %".475" = shl i64 %".472", %".474"
  %".476" = and i64 %".475", 4294967295
  %".477" = add i64 %".476", %".473"
  %".478" = trunc i64 %".477" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".478", 16777215
  %".479" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds.4" = load volatile i8, i8 addrspace(3)* %".479"
  %"lds_zext.4" = zext i8 %"lds.4" to i32
  %"isetrp_cmp1.18" = icmp ne i32 %"lds_zext.4", 0
  %"isetrp_src_to_i32.18" = zext i1 1 to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P62_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  br label %"BB_0fe0"
BB_0fe0:
  %"cond_trunc.26" = trunc i32 %"P62_to_i32" to i1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_trunc.26" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_11f0", label %"BB_0ff0"
BB_0ff0:
  %"allocation_slot_winoff.4" = and i32 3096, 16777215
  %".482" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff.4"
  %".483" = ptrtoint i8 addrspace(3)* %".482" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".483", i32 256) convergent
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P64_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_1000"
BB_1000:
  %"cond_trunc.27" = trunc i32 %"P64_to_i32" to i1
  %"cond_not.15" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.15" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_1260", label %"BB_1010"
BB_1010:
  %"imad_tmp.28" = mul i32 0, 0
  %"imad.29" = add i32 %"imad_tmp.28", 1
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.29", 255
  %"tmem_alloc_winoff.8" = and i32 3096, 16777215
  %".487" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.8"
  %".488" = bitcast i8 addrspace(3)* %".487" to i32 addrspace(3)*
  %".489" = load i32, i32 addrspace(3)* %".488"
  %".490" = lshr i32 %".489", 5
  %"P20_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.8" = trunc i32 %"P20_to_i32" to i1
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 %"lop3_c_trunc.8" to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".491" = xor i32 %"plop3_a_bit.8", 1
  %".492" = xor i32 %"plop3_b_bit.8", 1
  %".493" = xor i32 %"plop3_c_bit.8", 1
  %".494" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".495" = and i32 %".494", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".495", 0
  %"P67_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"sel_pred_trunc.8" = trunc i32 %"P67_to_i32" to i1
  %"sel_pred_not.8" = xor i1 %"sel_pred_trunc.8", -1
  %"sel_pred_to_i32.8" = zext i1 %"sel_pred_not.8" to i32
  %"sel_pred_to_i1.8" = icmp ne i32 %"sel_pred_to_i32.8", 0
  %"sel.8" = select  i1 %"sel_pred_to_i1.8", i32 0, i32 4294967295
  %"isetrp_cmp1.19" = icmp ne i32 %"sel.8", 0
  %"isetrp_src_to_i32.19" = zext i1 1 to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P68_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.30", %".490"
  br label %"BB_10a0"
BB_10a0:
  %"cond_trunc.28" = trunc i32 %"P68_to_i32" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_1140", label %"BB_10b0"
BB_10b0:
  %"tmem_alloc_winoff.9" = and i32 3096, 16777215
  %".498" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.9"
  %".499" = bitcast i8 addrspace(3)* %".498" to i32 addrspace(3)*
  %".500" = load i32, i32 addrspace(3)* %".499"
  %".501" = lshr i32 %".500", 5
  %"P21_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.9" = trunc i32 %"P21_to_i32" to i1
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 %"lop3_c_trunc.9" to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".502" = xor i32 %"plop3_a_bit.9", 1
  %".503" = xor i32 %"plop3_b_bit.9", 1
  %".504" = xor i32 %"plop3_c_bit.9", 1
  %".505" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".506" = and i32 %".505", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".506", 0
  %"P70_to_i32" = zext i1 %"plop3_pred.9" to i32
  %"sel_pred_trunc.9" = trunc i32 %"P70_to_i32" to i1
  %"sel_pred_not.9" = xor i1 %"sel_pred_trunc.9", -1
  %"sel_pred_to_i32.9" = zext i1 %"sel_pred_not.9" to i32
  %"sel_pred_to_i1.9" = icmp ne i32 %"sel_pred_to_i32.9", 0
  %"sel.9" = select  i1 %"sel_pred_to_i1.9", i32 0, i32 4294967295
  %"isetrp_cmp1.20" = icmp ne i32 %"sel.9", 0
  %"isetrp_src_to_i32.20" = zext i1 1 to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P71_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.31", %".501"
  br label %"BB_1130"
BB_1130:
  %"cond_trunc.29" = trunc i32 %"P71_to_i32" to i1
  %"cond_not.16" = xor i1 %"cond_trunc.29", -1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_not.16" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_10b0", label %"BB_1140"
BB_1140:
  %"phi.20" = phi  i32 [%"imad.31", %"BB_10a0"], [%"imad.32", %"BB_1130"]
  %"viadd.10" = add i32 %"phi.20", 16
  %".509" = zext i32 %"imad.30" to i64
  %".510" = zext i32 0 to i64
  %".511" = shl i64 %".510", 32
  %"shf_concat.10" = or i64 %".509", %".511"
  %"shf_shift_64.10" = zext i32 %"phi.20" to i64
  %".512" = shl i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_result.10" = trunc i64 %".512" to i32
  %"imad_tmp.32" = mul i32 %"phi.20", 32
  %"imad.33" = add i32 %"imad_tmp.32", 0
  %".513" = zext i32 %"imad.29" to i64
  %".514" = zext i32 0 to i64
  %".515" = shl i64 %".514", 32
  %"shf_concat.11" = or i64 %".513", %".515"
  %"shf_shift_64.11" = zext i32 %"viadd.10" to i64
  %".516" = shl i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_result.11" = trunc i64 %".516" to i32
  %".517" = zext i32 %"cluster_ctarank.6" to i64
  %".518" = zext i32 1024 to i64
  %".519" = zext i32 24 to i64
  %".520" = shl i64 %".517", %".519"
  %".521" = and i64 %".520", 4294967295
  %".522" = add i64 %".521", %".518"
  %".523" = trunc i64 %".522" to i32
  %".524" = zext i32 %"cluster_ctarank.6" to i64
  %".525" = zext i32 80 to i64
  %".526" = zext i32 24 to i64
  %".527" = shl i64 %".524", %".526"
  %".528" = and i64 %".527", 4294967295
  %".529" = add i64 %".528", %".525"
  %".530" = trunc i64 %".529" to i32
  %".531" = xor i32 %"shf_result.11", -1
  %".532" = xor i32 %"shf_result.10", -1
  %".533" = xor i32 0, -1
  %".534" = and i32 %".531", %"shf_result.10"
  %".535" = and i32 %".534", %".533"
  %".536" = and i32 %".531", %"shf_result.10"
  %".537" = and i32 %".536", 0
  %".538" = or i32 %".535", %".537"
  %".539" = and i32 %"shf_result.11", %".532"
  %".540" = and i32 %".539", %".533"
  %".541" = or i32 %".538", %".540"
  %".542" = and i32 %"shf_result.11", %".532"
  %".543" = and i32 %".542", 0
  %".544" = or i32 %".541", %".543"
  %".545" = and i32 %"shf_result.11", %"shf_result.10"
  %".546" = and i32 %".545", %".533"
  %".547" = or i32 %".544", %".546"
  %".548" = and i32 %"shf_result.11", %"shf_result.10"
  %".549" = and i32 %".548", 0
  %".550" = or i32 %".547", %".549"
  %"atoms_shared_addr_winoff.4" = and i32 %".530", 16777215
  %".551" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.4"
  %"atoms_ptr.4" = bitcast i8 addrspace(3)* %".551" to i32 addrspace(3)*
  %"atoms_or.4" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.4", i32 %".550" monotonic
  %"sts_addr_memaddr_offset_add.8" = add i32 %".523", 2072
  %"sts_shared_addr_winoff.10" = and i32 %"sts_addr_memaddr_offset_add.8", 16777215
  %".552" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.10"
  %"sts_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".552" to i32 addrspace(3)*
  store volatile i32 %"imad.33", i32 addrspace(3)* %"sts_shared_addr_cast.10"
  br label %"BB_1260"
BB_11f0:
  %".555" = zext i32 %"cluster_ctarank.6" to i64
  %".556" = zext i32 1024 to i64
  %".557" = zext i32 24 to i64
  %".558" = shl i64 %".555", %".557"
  %".559" = and i64 %".558", 4294967295
  %".560" = add i64 %".559", %".556"
  %".561" = trunc i64 %".560" to i32
  %"imad_tmp.33" = mul i32 0, 0
  %"imad.34" = add i32 %"imad_tmp.33", -1
  %"sts_addr_memaddr_offset_add.9" = add i32 %".561", 2072
  %"sts_shared_addr_winoff.11" = and i32 %"sts_addr_memaddr_offset_add.9", 16777215
  %".562" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.11"
  %"sts_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".562" to i32 addrspace(3)*
  store volatile i32 %"imad.34", i32 addrspace(3)* %"sts_shared_addr_cast.11"
  br label %"BB_1230_3020"
BB_1230_3020:
  call void @"llvm.trap"()
  br label %"BB_1260"
BB_1260:
  %"isetrp_cmp1.21" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.21" = zext i1 1 to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P72_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %".566" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".567" = bitcast i8* %".566" to i64*
  %"ldc_const.2" = load i64, i64* %".567"
  %"R19:R18_r0" = trunc i64 %"ldc_const.2" to i32
  %"R19:R18_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"imad_tmp.34" = mul i32 %"tid_x.1", 18
  %"imad.35" = add i32 %"imad_tmp.34", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.35" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.36" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R19:R18_r0.1" = trunc i64 %"imad.36" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"imad.36", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R77:R45_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R77:R45_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R77:R45_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R77:R45_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R77:R45_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R77:R45_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R77:R45_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R77:R45_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.7"
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.35" = mul i32 %"tid_x.1", 65536
  %"imad.37" = add i32 %"imad_tmp.35", 0
  %".568" = xor i32 %"imad.37", -1
  %".569" = xor i32 65011712, -1
  %".570" = xor i32 0, -1
  %".571" = and i32 %"imad.37", 65011712
  %".572" = and i32 %".571", %".570"
  %".573" = and i32 %"imad.37", 65011712
  %".574" = and i32 %".573", 0
  %".575" = or i32 %".572", %".574"
  %".576" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".577" = zext i32 1024 to i64
  %".578" = zext i32 24 to i64
  %".579" = shl i64 %".576", %".578"
  %".580" = and i64 %".579", 4294967295
  %".581" = add i64 %".580", %".577"
  %".582" = trunc i64 %".581" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".583" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".583" to i64 addrspace(3)*
  %"lds.5" = load volatile i64, i64 addrspace(3)* %"lds_shared_addr_cast"
  %"R13:R12_r0" = trunc i64 %"lds.5" to i32
  %"R13:R12_r1_shift" = lshr i64 %"lds.5", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.36" = mul i32 %"R13:R12_r1", 1
  %"imad.38" = add i32 %"imad_tmp.36", %".575"
  %"sttm_memaddr_offset_add" = add i32 %"imad.38", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.38", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R77:R45_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R77:R45_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R77:R45_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R77:R45_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R77:R45_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R77:R45_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R77:R45_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R77:R45_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.15"
  %"imad_addend_neg" = sub i32 0, %"R13:R12_r0"
  %"imad_tmp.37" = mul i32 %"R13:R12_r1", 1
  %"imad.39" = add i32 %"imad_tmp.37", %"imad_addend_neg"
  %"imad_tmp.38" = mul i32 %".575", 1
  %"imad.40" = add i32 %"imad_tmp.38", %"R13:R12_r0"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.38", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.38", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_1530"
BB_1530:
  %"cond_trunc.30" = trunc i32 %"P72_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_18a0", label %"BB_1540"
BB_1540:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".593" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".593" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.1" = add i32 1024, 1024
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %".594" = zext i32 0 to i64
  %".595" = zext i32 %".582" to i64
  %".596" = shl i64 %".595", 32
  %"shf_concat.12" = or i64 %".594", %".596"
  %"shf_shift_64.12" = zext i32 4 to i64
  %".597" = lshr i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_hi" = lshr i64 %".597", 32
  %"shf_result.12" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".598" = xor i32 %"plop3_a_bit.10", 1
  %".599" = xor i32 %"plop3_b_bit.10", 1
  %".600" = xor i32 %"plop3_c_bit.10", 1
  %".601" = and i32 %"plop3_a_bit.10", %"plop3_b_bit.10"
  %".602" = and i32 %".601", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".602", 0
  %"P74_to_i32" = zext i1 %"plop3_pred.10" to i32
  %".603" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".604" = zext i32 %"iadd3_n2.1" to i64
  %".605" = zext i32 24 to i64
  %".606" = shl i64 %".603", %".605"
  %".607" = and i64 %".606", 4294967295
  %".608" = add i64 %".607", %".604"
  %".609" = trunc i64 %".608" to i32
  %".610" = xor i32 %"shf_result.12", -1
  %".611" = xor i32 16376, -1
  %".612" = xor i32 0, -1
  %".613" = and i32 %"shf_result.12", 16376
  %".614" = and i32 %".613", %".612"
  %".615" = and i32 %"shf_result.12", 16376
  %".616" = and i32 %".615", 0
  %".617" = or i32 %".614", %".616"
  %".618" = zext i32 0 to i64
  %".619" = zext i32 %".609" to i64
  %".620" = shl i64 %".619", 32
  %"shf_concat.13" = or i64 %".618", %".620"
  %"shf_shift_64.13" = zext i32 4 to i64
  %".621" = lshr i64 %"shf_concat.13", %"shf_shift_64.13"
  %"shf_hi.1" = lshr i64 %".621", 32
  %"shf_result.13" = trunc i64 %"shf_hi.1" to i32
  %".622" = xor i32 %".617", -1
  %".623" = xor i32 524288, -1
  %".624" = xor i32 0, -1
  %".625" = and i32 %".622", 524288
  %".626" = and i32 %".625", %".624"
  %".627" = and i32 %".622", 524288
  %".628" = and i32 %".627", 0
  %".629" = or i32 %".626", %".628"
  %".630" = and i32 %".617", %".623"
  %".631" = and i32 %".630", %".624"
  %".632" = or i32 %".629", %".631"
  %".633" = and i32 %".617", %".623"
  %".634" = and i32 %".633", 0
  %".635" = or i32 %".632", %".634"
  %".636" = and i32 %".617", 524288
  %".637" = and i32 %".636", %".624"
  %".638" = or i32 %".635", %".637"
  %".639" = and i32 %".617", 524288
  %".640" = and i32 %".639", 0
  %".641" = or i32 %".638", %".640"
  %".642" = xor i32 %"shf_result.13", -1
  %".643" = xor i32 16376, -1
  %".644" = xor i32 0, -1
  %".645" = and i32 %"shf_result.13", 16376
  %".646" = and i32 %".645", %".644"
  %".647" = and i32 %"shf_result.13", 16376
  %".648" = and i32 %".647", 0
  %".649" = or i32 %".646", %".648"
  %".650" = xor i32 %".649", -1
  %".651" = xor i32 524288, -1
  %".652" = xor i32 0, -1
  %".653" = and i32 %".650", 524288
  %".654" = and i32 %".653", %".652"
  %".655" = and i32 %".650", 524288
  %".656" = and i32 %".655", 0
  %".657" = or i32 %".654", %".656"
  %".658" = and i32 %".649", %".651"
  %".659" = and i32 %".658", %".652"
  %".660" = or i32 %".657", %".659"
  %".661" = and i32 %".649", %".651"
  %".662" = and i32 %".661", 0
  %".663" = or i32 %".660", %".662"
  %".664" = and i32 %".649", 524288
  %".665" = and i32 %".664", %".652"
  %".666" = or i32 %".663", %".665"
  %".667" = and i32 %".649", 524288
  %".668" = and i32 %".667", 0
  %".669" = or i32 %".666", %".668"
  %"iadd3_n1.2" = add i32 %"imad.39", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", %"lds.6"
  br label %"BB_1650"
BB_1650:
  %"phi.21" = phi  i32 [%"phi.9", %"BB_1540"], [%"P5_to_i32", %"BB_1680"]
  %"phi.22" = phi  i32 [%"P74_to_i32", %"BB_1540"], [%"phi.24", %"BB_1680"]
  %"cond_trunc.31" = trunc i32 %"phi.22" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_80001650", label %"BB_1660"
BB_80001650:
  %"elect_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"election.5" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.5")
  %"elect_p.5" = extractvalue {i32, i1} %"election.5", 1
  %"P3_to_i32" = zext i1 %"elect_p.5" to i32
  br label %"BB_1660"
BB_1660:
  %"phi.23" = phi  i32 [%"P3_to_i32", %"BB_80001650"], [%"phi.21", %"BB_1650"]
  %"mma_b_r0_ext" = zext i32 %".669" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".673" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".674" = sub i64 %".673", 0
  %".675" = lshr i64 %".674", 4
  %".676" = add i64 %"mma_b_packed_1", %".675"
  %".677" = and i64 %".676", 16383
  %".678" = and i64 %"mma_b_packed_1", -16384
  %".679" = or i64 %".678", %".677"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.6", i32 %"iadd3_n2.2", i64 %".679", i32 134747536, i32 %"mma_arg_zext")
  br label %"BB_1670"
BB_1670:
  %"cond_trunc.32" = trunc i32 %"phi.23" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_80001670", label %"BB_1680"
BB_80001670:
  %"lop3_a_trunc" = trunc i32 %"phi.23" to i1
  %"lop3_a_cast_zext.11" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".683" = xor i32 %"plop3_a_bit.11", 1
  %".684" = xor i32 %"plop3_b_bit.11", 1
  %".685" = xor i32 %"plop3_c_bit.11", 1
  %".686" = and i32 %".683", %"plop3_b_bit.11"
  %".687" = and i32 %".686", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".687", 0
  %"P78_to_i32" = zext i1 %"plop3_pred.11" to i32
  br label %"BB_1680"
BB_1680:
  %"phi.24" = phi  i32 [%"P78_to_i32", %"BB_80001670"], [%"phi.22", %"BB_1670"]
  %"lop3_a_cast_zext.12" = zext i1 1 to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".689" = xor i32 %"plop3_a_bit.12", 1
  %".690" = xor i32 %"plop3_b_bit.12", 1
  %".691" = xor i32 %"plop3_c_bit.12", 1
  %".692" = and i32 %".689", %"plop3_b_bit.12"
  %".693" = and i32 %".692", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".693", 0
  %"P5_to_i32" = zext i1 %"plop3_pred.12" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.24" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_1650", label %"BB_16a0"
BB_16a0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".695" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".695" to i32 addrspace(3)*
  %"lds.7" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.13" = zext i1 1 to i32
  %"lop3_b_cast_zext.13" = zext i1 1 to i32
  %"lop3_c_cast_zext.13" = zext i1 1 to i32
  %"plop3_a_bit.13" = and i32 %"lop3_a_cast_zext.13", 1
  %"plop3_b_bit.13" = and i32 %"lop3_b_cast_zext.13", 1
  %"plop3_c_bit.13" = and i32 %"lop3_c_cast_zext.13", 1
  %".696" = xor i32 %"plop3_a_bit.13", 1
  %".697" = xor i32 %"plop3_b_bit.13", 1
  %".698" = xor i32 %"plop3_c_bit.13", 1
  %".699" = and i32 %"plop3_a_bit.13", %"plop3_b_bit.13"
  %".700" = and i32 %".699", %"plop3_c_bit.13"
  %"plop3_pred.13" = icmp ne i32 %".700", 0
  %"P80_to_i32" = zext i1 %"plop3_pred.13" to i32
  %"iadd3_n1.3" = add i32 %"imad.39", %"lds.7"
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"iadd3_n2.3", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"iadd3_n2.3", 4
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_1720"
BB_1720:
  %"phi.25" = phi  i32 [%"P5_to_i32", %"BB_16a0"], [%"P113_to_i32", %"BB_1750"]
  %"phi.26" = phi  i32 [%"P80_to_i32", %"BB_16a0"], [%"phi.28", %"BB_1750"]
  %"cond_trunc.33" = trunc i32 %"phi.26" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_80001720", label %"BB_1730"
BB_80001720:
  %"elect_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"election.6" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.6")
  %"elect_p.6" = extractvalue {i32, i1} %"election.6", 1
  %"P7_to_i32" = zext i1 %"elect_p.6" to i32
  br label %"BB_1730"
BB_1730:
  %"phi.27" = phi  i32 [%"P7_to_i32", %"BB_80001720"], [%"phi.25", %"BB_1720"]
  %"mma_b_r0_ext.1" = zext i32 %".641" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".704" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".705" = sub i64 %".704", 0
  %".706" = lshr i64 %".705", 4
  %".707" = add i64 %"mma_b_packed_1.1", %".706"
  %".708" = and i64 %".707", 16383
  %".709" = and i64 %"mma_b_packed_1.1", -16384
  %".710" = or i64 %".709", %".708"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.7", i32 %"iadd3_n2.4", i64 %".710", i32 679744944, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.3", i32 %"iadd3_n2.5")
  br label %"BB_1740"
BB_1740:
  %"cond_trunc.34" = trunc i32 %"phi.27" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_80001740", label %"BB_1750"
BB_80001740:
  %"lop3_a_trunc.1" = trunc i32 %"phi.27" to i1
  %"lop3_a_cast_zext.14" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.14" = zext i1 1 to i32
  %"lop3_c_cast_zext.14" = zext i1 1 to i32
  %"plop3_a_bit.14" = and i32 %"lop3_a_cast_zext.14", 1
  %"plop3_b_bit.14" = and i32 %"lop3_b_cast_zext.14", 1
  %"plop3_c_bit.14" = and i32 %"lop3_c_cast_zext.14", 1
  %".714" = xor i32 %"plop3_a_bit.14", 1
  %".715" = xor i32 %"plop3_b_bit.14", 1
  %".716" = xor i32 %"plop3_c_bit.14", 1
  %".717" = and i32 %".714", %"plop3_b_bit.14"
  %".718" = and i32 %".717", %"plop3_c_bit.14"
  %"plop3_pred.14" = icmp ne i32 %".718", 0
  %"P82_to_i32" = zext i1 %"plop3_pred.14" to i32
  br label %"BB_1750"
BB_1750:
  %"phi.28" = phi  i32 [%"P82_to_i32", %"BB_80001740"], [%"phi.26", %"BB_1740"]
  %"lop3_a_cast_zext.15" = zext i1 1 to i32
  %"lop3_b_cast_zext.15" = zext i1 1 to i32
  %"lop3_c_cast_zext.15" = zext i1 1 to i32
  %"plop3_a_bit.15" = and i32 %"lop3_a_cast_zext.15", 1
  %"plop3_b_bit.15" = and i32 %"lop3_b_cast_zext.15", 1
  %"plop3_c_bit.15" = and i32 %"lop3_c_cast_zext.15", 1
  %".720" = xor i32 %"plop3_a_bit.15", 1
  %".721" = xor i32 %"plop3_b_bit.15", 1
  %".722" = xor i32 %"plop3_c_bit.15", 1
  %".723" = and i32 %".720", %"plop3_b_bit.15"
  %".724" = and i32 %".723", %"plop3_c_bit.15"
  %"plop3_pred.15" = icmp ne i32 %".724", 0
  %"P113_to_i32" = zext i1 %"plop3_pred.15" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.28" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_1720", label %"BB_1770"
BB_1770:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.8" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".726" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.8"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".726" to i32 addrspace(3)*
  %"lds.8" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.16" = zext i1 1 to i32
  %"lop3_b_cast_zext.16" = zext i1 1 to i32
  %"lop3_c_cast_zext.16" = zext i1 1 to i32
  %"plop3_a_bit.16" = and i32 %"lop3_a_cast_zext.16", 1
  %"plop3_b_bit.16" = and i32 %"lop3_b_cast_zext.16", 1
  %"plop3_c_bit.16" = and i32 %"lop3_c_cast_zext.16", 1
  %".727" = xor i32 %"plop3_a_bit.16", 1
  %".728" = xor i32 %"plop3_b_bit.16", 1
  %".729" = xor i32 %"plop3_c_bit.16", 1
  %".730" = and i32 %"plop3_a_bit.16", %"plop3_b_bit.16"
  %".731" = and i32 %".730", %"plop3_c_bit.16"
  %"plop3_pred.16" = icmp ne i32 %".731", 0
  %"P84_to_i32" = zext i1 %"plop3_pred.16" to i32
  %"iadd3_n1.6" = add i32 %"imad.39", %"lds.8"
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"iadd3_n2.6", 16
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"iadd3_n1.8" = add i32 %"iadd3_n2.6", 4
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  br label %"BB_17d0"
BB_17d0:
  %"phi.29" = phi  i32 [%"P113_to_i32", %"BB_1770"], [%"P118_to_i32", %"BB_1800"]
  %"phi.30" = phi  i32 [%"P84_to_i32", %"BB_1770"], [%"phi.32", %"BB_1800"]
  %"cond_trunc.35" = trunc i32 %"phi.30" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_800017d0", label %"BB_17e0"
BB_800017d0:
  %"elect_mask.7" = call i32 @"llvm.nvvm.activemask"()
  %"election.7" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.7")
  %"elect_p.7" = extractvalue {i32, i1} %"election.7", 1
  %"P115_to_i32" = zext i1 %"elect_p.7" to i32
  br label %"BB_17e0"
BB_17e0:
  %"phi.31" = phi  i32 [%"P115_to_i32", %"BB_800017d0"], [%"phi.29", %"BB_17d0"]
  %"mma_b_r0_ext.2" = zext i32 %".641" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".735" = ptrtoint [3104 x i8] addrspace(3)* @"shared_mem" to i64
  %".736" = sub i64 %".735", 0
  %".737" = lshr i64 %".736", 4
  %".738" = add i64 %"mma_b_packed_1.2", %".737"
  %".739" = and i64 %".738", 16383
  %".740" = and i64 %"mma_b_packed_1.2", -16384
  %".741" = or i64 %".740", %".739"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.8", i32 %"iadd3_n2.7", i64 %".741", i32 679744944, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.6", i32 %"iadd3_n2.8")
  br label %"BB_17f0"
BB_17f0:
  %"cond_trunc.36" = trunc i32 %"phi.31" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_800017f0", label %"BB_1800"
BB_800017f0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.31" to i1
  %"lop3_a_cast_zext.17" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.17" = zext i1 1 to i32
  %"lop3_c_cast_zext.17" = zext i1 1 to i32
  %"plop3_a_bit.17" = and i32 %"lop3_a_cast_zext.17", 1
  %"plop3_b_bit.17" = and i32 %"lop3_b_cast_zext.17", 1
  %"plop3_c_bit.17" = and i32 %"lop3_c_cast_zext.17", 1
  %".745" = xor i32 %"plop3_a_bit.17", 1
  %".746" = xor i32 %"plop3_b_bit.17", 1
  %".747" = xor i32 %"plop3_c_bit.17", 1
  %".748" = and i32 %".745", %"plop3_b_bit.17"
  %".749" = and i32 %".748", %"plop3_c_bit.17"
  %"plop3_pred.17" = icmp ne i32 %".749", 0
  %"P89_to_i32" = zext i1 %"plop3_pred.17" to i32
  br label %"BB_1800"
BB_1800:
  %"phi.32" = phi  i32 [%"P89_to_i32", %"BB_800017f0"], [%"phi.30", %"BB_17f0"]
  %"lop3_a_cast_zext.18" = zext i1 1 to i32
  %"lop3_b_cast_zext.18" = zext i1 1 to i32
  %"lop3_c_cast_zext.18" = zext i1 1 to i32
  %"plop3_a_bit.18" = and i32 %"lop3_a_cast_zext.18", 1
  %"plop3_b_bit.18" = and i32 %"lop3_b_cast_zext.18", 1
  %"plop3_c_bit.18" = and i32 %"lop3_c_cast_zext.18", 1
  %".751" = xor i32 %"plop3_a_bit.18", 1
  %".752" = xor i32 %"plop3_b_bit.18", 1
  %".753" = xor i32 %"plop3_c_bit.18", 1
  %".754" = and i32 %".751", %"plop3_b_bit.18"
  %".755" = and i32 %".754", %"plop3_c_bit.18"
  %"plop3_pred.18" = icmp ne i32 %".755", 0
  %"P118_to_i32" = zext i1 %"plop3_pred.18" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.32" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_17d0", label %"BB_1820"
BB_1820:
  %"iadd3_n1.9" = add i32 1024, 2048
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"lop3_a_cast_zext.19" = zext i1 1 to i32
  %"lop3_b_cast_zext.19" = zext i1 1 to i32
  %"lop3_c_cast_zext.19" = zext i1 1 to i32
  %"plop3_a_bit.19" = and i32 %"lop3_a_cast_zext.19", 1
  %"plop3_b_bit.19" = and i32 %"lop3_b_cast_zext.19", 1
  %"plop3_c_bit.19" = and i32 %"lop3_c_cast_zext.19", 1
  %".757" = xor i32 %"plop3_a_bit.19", 1
  %".758" = xor i32 %"plop3_b_bit.19", 1
  %".759" = xor i32 %"plop3_c_bit.19", 1
  %".760" = and i32 %"plop3_a_bit.19", %"plop3_b_bit.19"
  %".761" = and i32 %".760", %"plop3_c_bit.19"
  %"plop3_pred.19" = icmp ne i32 %".761", 0
  %"P91_to_i32" = zext i1 %"plop3_pred.19" to i32
  %".762" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".763" = zext i32 %"iadd3_n2.9" to i64
  %".764" = zext i32 24 to i64
  %".765" = shl i64 %".762", %".764"
  %".766" = and i64 %".765", 4294967295
  %".767" = add i64 %".766", %".763"
  %".768" = trunc i64 %".767" to i32
  br label %"BB_1850"
BB_1850:
  %"phi.33" = phi  i32 [%"P118_to_i32", %"BB_1820"], [%"P123_to_i32", %"BB_1880"]
  %"phi.34" = phi  i32 [%"P91_to_i32", %"BB_1820"], [%"phi.36", %"BB_1880"]
  %"cond_trunc.37" = trunc i32 %"phi.34" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_80001850", label %"BB_1860"
BB_80001850:
  %"elect_mask.8" = call i32 @"llvm.nvvm.activemask"()
  %"election.8" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.8")
  %"elect_p.8" = extractvalue {i32, i1} %"election.8", 1
  %"P120_to_i32" = zext i1 %"elect_p.8" to i32
  br label %"BB_1860"
BB_1860:
  %"phi.35" = phi  i32 [%"P120_to_i32", %"BB_80001850"], [%"phi.33", %"BB_1850"]
  %"utcbar_local_winoff" = and i32 %".768", 16777215
  %".772" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".773" = ptrtoint i8 addrspace(3)* %".772" to i32
  %".774" = lshr i32 %".768", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".773", i32 %".774")
  br label %"BB_1870"
BB_1870:
  %"cond_trunc.38" = trunc i32 %"phi.35" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_80001870", label %"BB_1880"
BB_80001870:
  %"lop3_a_trunc.3" = trunc i32 %"phi.35" to i1
  %"lop3_a_cast_zext.20" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.20" = zext i1 1 to i32
  %"lop3_c_cast_zext.20" = zext i1 1 to i32
  %"plop3_a_bit.20" = and i32 %"lop3_a_cast_zext.20", 1
  %"plop3_b_bit.20" = and i32 %"lop3_b_cast_zext.20", 1
  %"plop3_c_bit.20" = and i32 %"lop3_c_cast_zext.20", 1
  %".778" = xor i32 %"plop3_a_bit.20", 1
  %".779" = xor i32 %"plop3_b_bit.20", 1
  %".780" = xor i32 %"plop3_c_bit.20", 1
  %".781" = and i32 %".778", %"plop3_b_bit.20"
  %".782" = and i32 %".781", %"plop3_c_bit.20"
  %"plop3_pred.20" = icmp ne i32 %".782", 0
  %"P93_to_i32" = zext i1 %"plop3_pred.20" to i32
  br label %"BB_1880"
BB_1880:
  %"phi.36" = phi  i32 [%"P93_to_i32", %"BB_80001870"], [%"phi.34", %"BB_1870"]
  %"lop3_a_cast_zext.21" = zext i1 1 to i32
  %"lop3_b_cast_zext.21" = zext i1 1 to i32
  %"lop3_c_cast_zext.21" = zext i1 1 to i32
  %"plop3_a_bit.21" = and i32 %"lop3_a_cast_zext.21", 1
  %"plop3_b_bit.21" = and i32 %"lop3_b_cast_zext.21", 1
  %"plop3_c_bit.21" = and i32 %"lop3_c_cast_zext.21", 1
  %".784" = xor i32 %"plop3_a_bit.21", 1
  %".785" = xor i32 %"plop3_b_bit.21", 1
  %".786" = xor i32 %"plop3_c_bit.21", 1
  %".787" = and i32 %".784", %"plop3_b_bit.21"
  %".788" = and i32 %".787", %"plop3_c_bit.21"
  %"plop3_pred.21" = icmp ne i32 %".788", 0
  %"P123_to_i32" = zext i1 %"plop3_pred.21" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.36" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.3", label %"BB_1850", label %"BB_18a0"
BB_18a0:
  %"isetrp_cmp1.22" = icmp uge i32 %"tid_x.1", 32
  %"isetrp_src_to_i32.22" = zext i1 1 to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P125_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"lop3_a_cast_zext.22" = zext i1 1 to i32
  %"lop3_b_cast_zext.22" = zext i1 1 to i32
  %"lop3_c_cast_zext.22" = zext i1 1 to i32
  %"plop3_a_bit.22" = and i32 %"lop3_a_cast_zext.22", 1
  %"plop3_b_bit.22" = and i32 %"lop3_b_cast_zext.22", 1
  %"plop3_c_bit.22" = and i32 %"lop3_c_cast_zext.22", 1
  %".790" = xor i32 %"plop3_a_bit.22", 1
  %".791" = xor i32 %"plop3_b_bit.22", 1
  %".792" = xor i32 %"plop3_c_bit.22", 1
  %".793" = and i32 %"plop3_a_bit.22", %"plop3_b_bit.22"
  %".794" = and i32 %".793", %"plop3_c_bit.22"
  %"plop3_pred.22" = icmp ne i32 %".794", 0
  %"P95_to_i32" = zext i1 %"plop3_pred.22" to i32
  br label %"BB_18d0"
BB_18d0:
  %"cond_trunc.39" = trunc i32 %"P125_to_i32" to i1
  %"cond_not.17" = xor i1 %"cond_trunc.39", -1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_not.17" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_1d20", label %"BB_18e0"
BB_18e0:
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".797" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".798" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".799" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".800" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldg_addr_r0_ext.18" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9220
  %"R77:R45_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.16"
  %"ldg_addr_r0_ext.19" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.19" = or i64 0, %"ldg_addr_r0_ext.19"
  %"ldg_addr_r1_ext.19" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.19" = shl i64 %"ldg_addr_r1_ext.19", 32
  %"ldg_addr_packed_1.19" = or i64 %"ldg_addr_packed_0.19", %"ldg_addr_r1_shift.19"
  %"ldg_addr_memaddr_offset_add.18" = add i64 %"ldg_addr_packed_1.19", 9216
  %"R77:R45_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  %"ldg.19" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.17"
  %"ldg_addr_r0_ext.20" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.20" = or i64 0, %"ldg_addr_r0_ext.20"
  %"ldg_addr_r1_ext.20" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.20" = shl i64 %"ldg_addr_r1_ext.20", 32
  %"ldg_addr_packed_1.20" = or i64 %"ldg_addr_packed_0.20", %"ldg_addr_r1_shift.20"
  %"ldg_addr_memaddr_offset_add.19" = add i64 %"ldg_addr_packed_1.20", 9224
  %"R77:R45_addr_ptr.18" = inttoptr i64 %"ldg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  %"ldg.20" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.18"
  %"ldg_addr_r0_ext.21" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.21" = or i64 0, %"ldg_addr_r0_ext.21"
  %"ldg_addr_r1_ext.21" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.21" = shl i64 %"ldg_addr_r1_ext.21", 32
  %"ldg_addr_packed_1.21" = or i64 %"ldg_addr_packed_0.21", %"ldg_addr_r1_shift.21"
  %"ldg_addr_memaddr_offset_add.20" = add i64 %"ldg_addr_packed_1.21", 9228
  %"R77:R45_addr_ptr.19" = inttoptr i64 %"ldg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  %"ldg.21" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.19"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.38", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".801" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".802" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".803" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".804" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"ldg_addr_r0_ext.22" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.22" = or i64 0, %"ldg_addr_r0_ext.22"
  %"ldg_addr_r1_ext.22" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.22" = shl i64 %"ldg_addr_r1_ext.22", 32
  %"ldg_addr_packed_1.22" = or i64 %"ldg_addr_packed_0.22", %"ldg_addr_r1_shift.22"
  %"ldg_addr_memaddr_offset_add.21" = add i64 %"ldg_addr_packed_1.22", 9232
  %"R77:R45_addr_ptr.20" = inttoptr i64 %"ldg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  %"ldg.22" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.20"
  %"ldg_addr_r0_ext.23" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.23" = or i64 0, %"ldg_addr_r0_ext.23"
  %"ldg_addr_r1_ext.23" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.23" = shl i64 %"ldg_addr_r1_ext.23", 32
  %"ldg_addr_packed_1.23" = or i64 %"ldg_addr_packed_0.23", %"ldg_addr_r1_shift.23"
  %"ldg_addr_memaddr_offset_add.22" = add i64 %"ldg_addr_packed_1.23", 9236
  %"R77:R45_addr_ptr.21" = inttoptr i64 %"ldg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  %"ldg.23" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.21"
  %"ldg_addr_r0_ext.24" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.24" = or i64 0, %"ldg_addr_r0_ext.24"
  %"ldg_addr_r1_ext.24" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.24" = shl i64 %"ldg_addr_r1_ext.24", 32
  %"ldg_addr_packed_1.24" = or i64 %"ldg_addr_packed_0.24", %"ldg_addr_r1_shift.24"
  %"ldg_addr_memaddr_offset_add.23" = add i64 %"ldg_addr_packed_1.24", 9240
  %"R77:R45_addr_ptr.22" = inttoptr i64 %"ldg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  %"ldg.24" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.22"
  %"ldg_addr_r0_ext.25" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.25" = or i64 0, %"ldg_addr_r0_ext.25"
  %"ldg_addr_r1_ext.25" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.25" = shl i64 %"ldg_addr_r1_ext.25", 32
  %"ldg_addr_packed_1.25" = or i64 %"ldg_addr_packed_0.25", %"ldg_addr_r1_shift.25"
  %"ldg_addr_memaddr_offset_add.24" = add i64 %"ldg_addr_packed_1.25", 9244
  %"R77:R45_addr_ptr.23" = inttoptr i64 %"ldg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  %"ldg.25" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.23"
  %"isetrp_cmp1.23" = icmp ne i32 %".798", %"ldg.18"
  %"isetrp_src_to_i32.23" = zext i1 1 to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P96_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".805" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".806" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".807" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".808" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"ldg_addr_r0_ext.26" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.26" = or i64 0, %"ldg_addr_r0_ext.26"
  %"ldg_addr_r1_ext.26" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.26" = shl i64 %"ldg_addr_r1_ext.26", 32
  %"ldg_addr_packed_1.26" = or i64 %"ldg_addr_packed_0.26", %"ldg_addr_r1_shift.26"
  %"ldg_addr_memaddr_offset_add.25" = add i64 %"ldg_addr_packed_1.26", 9216
  %"R77:R45_addr_ptr.24" = inttoptr i64 %"ldg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  %"ldg.26" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.24"
  %"isetrp_src_trunc" = trunc i32 %"P96_to_i32" to i1
  %"isetrp_src_not" = xor i1 %"isetrp_src_trunc", -1
  %"isetrp_cmp1.24" = icmp eq i32 %".797", %"ldg.19"
  %"isetrp_src_to_i32.24" = zext i1 %"isetrp_src_not" to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P111_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %"ldg_addr_r0_ext.27" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.27" = or i64 0, %"ldg_addr_r0_ext.27"
  %"ldg_addr_r1_ext.27" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.27" = shl i64 %"ldg_addr_r1_ext.27", 32
  %"ldg_addr_packed_1.27" = or i64 %"ldg_addr_packed_0.27", %"ldg_addr_r1_shift.27"
  %"ldg_addr_memaddr_offset_add.26" = add i64 %"ldg_addr_packed_1.27", 9220
  %"R77:R45_addr_ptr.25" = inttoptr i64 %"ldg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  %"ldg.27" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.25"
  %"isetrp_src_trunc.1" = trunc i32 %"P111_to_i32" to i1
  %"isetrp_cmp1.25" = icmp eq i32 %".799", %"ldg.20"
  %"isetrp_src_to_i32.25" = zext i1 %"isetrp_src_trunc.1" to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P129_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  %"ldg_addr_r0_ext.28" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.28" = or i64 0, %"ldg_addr_r0_ext.28"
  %"ldg_addr_r1_ext.28" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.28" = shl i64 %"ldg_addr_r1_ext.28", 32
  %"ldg_addr_packed_1.28" = or i64 %"ldg_addr_packed_0.28", %"ldg_addr_r1_shift.28"
  %"ldg_addr_memaddr_offset_add.27" = add i64 %"ldg_addr_packed_1.28", 9224
  %"R77:R45_addr_ptr.26" = inttoptr i64 %"ldg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  %"ldg.28" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.26"
  %"isetrp_src_trunc.2" = trunc i32 %"P129_to_i32" to i1
  %"isetrp_cmp1.26" = icmp eq i32 %".800", %"ldg.21"
  %"isetrp_src_to_i32.26" = zext i1 %"isetrp_src_trunc.2" to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"ldg_addr_r0_ext.29" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.29" = or i64 0, %"ldg_addr_r0_ext.29"
  %"ldg_addr_r1_ext.29" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.29" = shl i64 %"ldg_addr_r1_ext.29", 32
  %"ldg_addr_packed_1.29" = or i64 %"ldg_addr_packed_0.29", %"ldg_addr_r1_shift.29"
  %"ldg_addr_memaddr_offset_add.28" = add i64 %"ldg_addr_packed_1.29", 9228
  %"R77:R45_addr_ptr.27" = inttoptr i64 %"ldg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  %"ldg.29" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.27"
  %"isetrp_src_trunc.3" = trunc i32 %"P10_to_i32" to i1
  %"isetrp_cmp1.27" = icmp eq i32 %".801", %"ldg.22"
  %"isetrp_src_to_i32.27" = zext i1 %"isetrp_src_trunc.3" to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P17_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.38", 4
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".809" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".810" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".811" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".812" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"ldg_addr_r0_ext.30" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.30" = or i64 0, %"ldg_addr_r0_ext.30"
  %"ldg_addr_r1_ext.30" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.30" = shl i64 %"ldg_addr_r1_ext.30", 32
  %"ldg_addr_packed_1.30" = or i64 %"ldg_addr_packed_0.30", %"ldg_addr_r1_shift.30"
  %"ldg_addr_memaddr_offset_add.29" = add i64 %"ldg_addr_packed_1.30", 9232
  %"R77:R45_addr_ptr.28" = inttoptr i64 %"ldg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  %"ldg.30" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.28"
  %"ldg_addr_r0_ext.31" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.31" = or i64 0, %"ldg_addr_r0_ext.31"
  %"ldg_addr_r1_ext.31" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.31" = shl i64 %"ldg_addr_r1_ext.31", 32
  %"ldg_addr_packed_1.31" = or i64 %"ldg_addr_packed_0.31", %"ldg_addr_r1_shift.31"
  %"ldg_addr_memaddr_offset_add.30" = add i64 %"ldg_addr_packed_1.31", 9236
  %"R77:R45_addr_ptr.29" = inttoptr i64 %"ldg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  %"ldg.31" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.29"
  %"isetrp_src_trunc.4" = trunc i32 %"P17_to_i32" to i1
  %"isetrp_cmp1.28" = icmp eq i32 %".802", %"ldg.23"
  %"isetrp_src_to_i32.28" = zext i1 %"isetrp_src_trunc.4" to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"ldg_addr_r0_ext.32" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.32" = or i64 0, %"ldg_addr_r0_ext.32"
  %"ldg_addr_r1_ext.32" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.32" = shl i64 %"ldg_addr_r1_ext.32", 32
  %"ldg_addr_packed_1.32" = or i64 %"ldg_addr_packed_0.32", %"ldg_addr_r1_shift.32"
  %"ldg_addr_memaddr_offset_add.31" = add i64 %"ldg_addr_packed_1.32", 9244
  %"R77:R45_addr_ptr.30" = inttoptr i64 %"ldg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  %"ldg.32" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.30"
  %"isetrp_src_trunc.5" = trunc i32 %"P23_to_i32" to i1
  %"isetrp_cmp1.29" = icmp eq i32 %".803", %"ldg.24"
  %"isetrp_src_to_i32.29" = zext i1 %"isetrp_src_trunc.5" to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = and i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  %"ldg_addr_r0_ext.33" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.33" = or i64 0, %"ldg_addr_r0_ext.33"
  %"ldg_addr_r1_ext.33" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.33" = shl i64 %"ldg_addr_r1_ext.33", 32
  %"ldg_addr_packed_1.33" = or i64 %"ldg_addr_packed_0.33", %"ldg_addr_r1_shift.33"
  %"ldg_addr_memaddr_offset_add.32" = add i64 %"ldg_addr_packed_1.33", 9240
  %"R77:R45_addr_ptr.31" = inttoptr i64 %"ldg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  %"ldg.33" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.31"
  %"isetrp_src_trunc.6" = trunc i32 %"P28_to_i32" to i1
  %"isetrp_cmp1.30" = icmp eq i32 %".804", %"ldg.25"
  %"isetrp_src_to_i32.30" = zext i1 %"isetrp_src_trunc.6" to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = and i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".813" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".814" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".815" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".816" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"isetrp_src_trunc.7" = trunc i32 %"P44_to_i32" to i1
  %"isetrp_cmp1.31" = icmp eq i32 %".805", %"ldg.26"
  %"isetrp_src_to_i32.31" = zext i1 %"isetrp_src_trunc.7" to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P121_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  %"ldg_addr_r0_ext.34" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.34" = or i64 0, %"ldg_addr_r0_ext.34"
  %"ldg_addr_r1_ext.34" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.34" = shl i64 %"ldg_addr_r1_ext.34", 32
  %"ldg_addr_packed_1.34" = or i64 %"ldg_addr_packed_0.34", %"ldg_addr_r1_shift.34"
  %"ldg_addr_memaddr_offset_add.33" = add i64 %"ldg_addr_packed_1.34", 9216
  %"R77:R45_addr_ptr.32" = inttoptr i64 %"ldg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  %"ldg.34" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.32"
  %"isetrp_src_trunc.8" = trunc i32 %"P121_to_i32" to i1
  %"isetrp_cmp1.32" = icmp eq i32 %".806", %"ldg.27"
  %"isetrp_src_to_i32.32" = zext i1 %"isetrp_src_trunc.8" to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %"ldg_addr_r0_ext.35" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.35" = or i64 0, %"ldg_addr_r0_ext.35"
  %"ldg_addr_r1_ext.35" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.35" = shl i64 %"ldg_addr_r1_ext.35", 32
  %"ldg_addr_packed_1.35" = or i64 %"ldg_addr_packed_0.35", %"ldg_addr_r1_shift.35"
  %"ldg_addr_memaddr_offset_add.34" = add i64 %"ldg_addr_packed_1.35", 9220
  %"R77:R45_addr_ptr.33" = inttoptr i64 %"ldg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  %"ldg.35" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.33"
  %"isetrp_src_trunc.9" = trunc i32 %"P42_to_i32" to i1
  %"isetrp_cmp1.33" = icmp eq i32 %".807", %"ldg.28"
  %"isetrp_src_to_i32.33" = zext i1 %"isetrp_src_trunc.9" to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P60_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  %"ldg_addr_r0_ext.36" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.36" = or i64 0, %"ldg_addr_r0_ext.36"
  %"ldg_addr_r1_ext.36" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.36" = shl i64 %"ldg_addr_r1_ext.36", 32
  %"ldg_addr_packed_1.36" = or i64 %"ldg_addr_packed_0.36", %"ldg_addr_r1_shift.36"
  %"ldg_addr_memaddr_offset_add.35" = add i64 %"ldg_addr_packed_1.36", 9224
  %"R77:R45_addr_ptr.34" = inttoptr i64 %"ldg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  %"ldg.36" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.34"
  %"isetrp_src_trunc.10" = trunc i32 %"P60_to_i32" to i1
  %"isetrp_cmp1.34" = icmp eq i32 %".808", %"ldg.29"
  %"isetrp_src_to_i32.34" = zext i1 %"isetrp_src_trunc.10" to i32
  %"isetrp_src_to_i1.34" = icmp ne i32 %"isetrp_src_to_i32.34", 0
  %"isetrp_cmp2.34" = and i1 %"isetrp_cmp1.34", %"isetrp_src_to_i1.34"
  %"P69_to_i32" = zext i1 %"isetrp_cmp2.34" to i32
  %"ldg_addr_r0_ext.37" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.37" = or i64 0, %"ldg_addr_r0_ext.37"
  %"ldg_addr_r1_ext.37" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.37" = shl i64 %"ldg_addr_r1_ext.37", 32
  %"ldg_addr_packed_1.37" = or i64 %"ldg_addr_packed_0.37", %"ldg_addr_r1_shift.37"
  %"ldg_addr_memaddr_offset_add.36" = add i64 %"ldg_addr_packed_1.37", 9228
  %"R77:R45_addr_ptr.35" = inttoptr i64 %"ldg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  %"ldg.37" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.35"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.38", 4
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".817" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".818" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".819" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".820" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"isetrp_src_trunc.11" = trunc i32 %"P69_to_i32" to i1
  %"isetrp_cmp1.35" = icmp eq i32 %".809", %"ldg.30"
  %"isetrp_src_to_i32.35" = zext i1 %"isetrp_src_trunc.11" to i32
  %"isetrp_src_to_i1.35" = icmp ne i32 %"isetrp_src_to_i32.35", 0
  %"isetrp_cmp2.35" = and i1 %"isetrp_cmp1.35", %"isetrp_src_to_i1.35"
  %"P87_to_i32" = zext i1 %"isetrp_cmp2.35" to i32
  %"ldg_addr_r0_ext.38" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.38" = or i64 0, %"ldg_addr_r0_ext.38"
  %"ldg_addr_r1_ext.38" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.38" = shl i64 %"ldg_addr_r1_ext.38", 32
  %"ldg_addr_packed_1.38" = or i64 %"ldg_addr_packed_0.38", %"ldg_addr_r1_shift.38"
  %"ldg_addr_memaddr_offset_add.37" = add i64 %"ldg_addr_packed_1.38", 9232
  %"R77:R45_addr_ptr.36" = inttoptr i64 %"ldg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  %"ldg.38" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.36"
  %"ldg_addr_r0_ext.39" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.39" = or i64 0, %"ldg_addr_r0_ext.39"
  %"ldg_addr_r1_ext.39" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.39" = shl i64 %"ldg_addr_r1_ext.39", 32
  %"ldg_addr_packed_1.39" = or i64 %"ldg_addr_packed_0.39", %"ldg_addr_r1_shift.39"
  %"ldg_addr_memaddr_offset_add.38" = add i64 %"ldg_addr_packed_1.39", 9236
  %"R77:R45_addr_ptr.37" = inttoptr i64 %"ldg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  %"ldg.39" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.37"
  %"isetrp_src_trunc.12" = trunc i32 %"P87_to_i32" to i1
  %"isetrp_cmp1.36" = icmp eq i32 %".810", %"ldg.31"
  %"isetrp_src_to_i32.36" = zext i1 %"isetrp_src_trunc.12" to i32
  %"isetrp_src_to_i1.36" = icmp ne i32 %"isetrp_src_to_i32.36", 0
  %"isetrp_cmp2.36" = and i1 %"isetrp_cmp1.36", %"isetrp_src_to_i1.36"
  %"P97_to_i32" = zext i1 %"isetrp_cmp2.36" to i32
  %"ldg_addr_r0_ext.40" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.40" = or i64 0, %"ldg_addr_r0_ext.40"
  %"ldg_addr_r1_ext.40" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.40" = shl i64 %"ldg_addr_r1_ext.40", 32
  %"ldg_addr_packed_1.40" = or i64 %"ldg_addr_packed_0.40", %"ldg_addr_r1_shift.40"
  %"ldg_addr_memaddr_offset_add.39" = add i64 %"ldg_addr_packed_1.40", 9240
  %"R77:R45_addr_ptr.38" = inttoptr i64 %"ldg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  %"ldg.40" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.38"
  %"ldg_addr_r0_ext.41" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.41" = or i64 0, %"ldg_addr_r0_ext.41"
  %"ldg_addr_r1_ext.41" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.41" = shl i64 %"ldg_addr_r1_ext.41", 32
  %"ldg_addr_packed_1.41" = or i64 %"ldg_addr_packed_0.41", %"ldg_addr_r1_shift.41"
  %"ldg_addr_memaddr_offset_add.40" = add i64 %"ldg_addr_packed_1.41", 9244
  %"R77:R45_addr_ptr.39" = inttoptr i64 %"ldg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  %"ldg.41" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.39"
  %"isetrp_src_trunc.13" = trunc i32 %"P97_to_i32" to i1
  %"isetrp_cmp1.37" = icmp eq i32 %".811", %"ldg.33"
  %"isetrp_src_to_i32.37" = zext i1 %"isetrp_src_trunc.13" to i32
  %"isetrp_src_to_i1.37" = icmp ne i32 %"isetrp_src_to_i32.37", 0
  %"isetrp_cmp2.37" = and i1 %"isetrp_cmp1.37", %"isetrp_src_to_i1.37"
  %"P98_to_i32" = zext i1 %"isetrp_cmp2.37" to i32
  %"isetrp_src_trunc.14" = trunc i32 %"P98_to_i32" to i1
  %"isetrp_cmp1.38" = icmp eq i32 %".812", %"ldg.32"
  %"isetrp_src_to_i32.38" = zext i1 %"isetrp_src_trunc.14" to i32
  %"isetrp_src_to_i1.38" = icmp ne i32 %"isetrp_src_to_i32.38", 0
  %"isetrp_cmp2.38" = and i1 %"isetrp_cmp1.38", %"isetrp_src_to_i1.38"
  %"P101_to_i32" = zext i1 %"isetrp_cmp2.38" to i32
  %"isetrp_src_trunc.15" = trunc i32 %"P101_to_i32" to i1
  %"isetrp_cmp1.39" = icmp eq i32 %".813", %"ldg.34"
  %"isetrp_src_to_i32.39" = zext i1 %"isetrp_src_trunc.15" to i32
  %"isetrp_src_to_i1.39" = icmp ne i32 %"isetrp_src_to_i32.39", 0
  %"isetrp_cmp2.39" = and i1 %"isetrp_cmp1.39", %"isetrp_src_to_i1.39"
  %"P102_to_i32" = zext i1 %"isetrp_cmp2.39" to i32
  %"isetrp_src_trunc.16" = trunc i32 %"P102_to_i32" to i1
  %"isetrp_cmp1.40" = icmp eq i32 %".814", %"ldg.35"
  %"isetrp_src_to_i32.40" = zext i1 %"isetrp_src_trunc.16" to i32
  %"isetrp_src_to_i1.40" = icmp ne i32 %"isetrp_src_to_i32.40", 0
  %"isetrp_cmp2.40" = and i1 %"isetrp_cmp1.40", %"isetrp_src_to_i1.40"
  %"P103_to_i32" = zext i1 %"isetrp_cmp2.40" to i32
  %"isetrp_src_trunc.17" = trunc i32 %"P103_to_i32" to i1
  %"isetrp_cmp1.41" = icmp eq i32 %".815", %"ldg.36"
  %"isetrp_src_to_i32.41" = zext i1 %"isetrp_src_trunc.17" to i32
  %"isetrp_src_to_i1.41" = icmp ne i32 %"isetrp_src_to_i32.41", 0
  %"isetrp_cmp2.41" = and i1 %"isetrp_cmp1.41", %"isetrp_src_to_i1.41"
  %"P104_to_i32" = zext i1 %"isetrp_cmp2.41" to i32
  %"isetrp_src_trunc.18" = trunc i32 %"P104_to_i32" to i1
  %"isetrp_cmp1.42" = icmp eq i32 %".816", %"ldg.37"
  %"isetrp_src_to_i32.42" = zext i1 %"isetrp_src_trunc.18" to i32
  %"isetrp_src_to_i1.42" = icmp ne i32 %"isetrp_src_to_i32.42", 0
  %"isetrp_cmp2.42" = and i1 %"isetrp_cmp1.42", %"isetrp_src_to_i1.42"
  %"P106_to_i32" = zext i1 %"isetrp_cmp2.42" to i32
  %"isetrp_src_trunc.19" = trunc i32 %"P106_to_i32" to i1
  %"isetrp_cmp1.43" = icmp eq i32 %".817", %"ldg.38"
  %"isetrp_src_to_i32.43" = zext i1 %"isetrp_src_trunc.19" to i32
  %"isetrp_src_to_i1.43" = icmp ne i32 %"isetrp_src_to_i32.43", 0
  %"isetrp_cmp2.43" = and i1 %"isetrp_cmp1.43", %"isetrp_src_to_i1.43"
  %"P107_to_i32" = zext i1 %"isetrp_cmp2.43" to i32
  %"isetrp_src_trunc.20" = trunc i32 %"P107_to_i32" to i1
  %"isetrp_cmp1.44" = icmp eq i32 %".818", %"ldg.39"
  %"isetrp_src_to_i32.44" = zext i1 %"isetrp_src_trunc.20" to i32
  %"isetrp_src_to_i1.44" = icmp ne i32 %"isetrp_src_to_i32.44", 0
  %"isetrp_cmp2.44" = and i1 %"isetrp_cmp1.44", %"isetrp_src_to_i1.44"
  %"P108_to_i32" = zext i1 %"isetrp_cmp2.44" to i32
  %"isetrp_src_trunc.21" = trunc i32 %"P108_to_i32" to i1
  %"isetrp_cmp1.45" = icmp eq i32 %".819", %"ldg.40"
  %"isetrp_src_to_i32.45" = zext i1 %"isetrp_src_trunc.21" to i32
  %"isetrp_src_to_i1.45" = icmp ne i32 %"isetrp_src_to_i32.45", 0
  %"isetrp_cmp2.45" = and i1 %"isetrp_cmp1.45", %"isetrp_src_to_i1.45"
  %"P77_to_i32" = zext i1 %"isetrp_cmp2.45" to i32
  %"isetrp_src_trunc.22" = trunc i32 %"P77_to_i32" to i1
  %"isetrp_cmp1.46" = icmp eq i32 %".820", %"ldg.41"
  %"isetrp_src_to_i32.46" = zext i1 %"isetrp_src_trunc.22" to i32
  %"isetrp_src_to_i1.46" = icmp ne i32 %"isetrp_src_to_i32.46", 0
  %"isetrp_cmp2.46" = and i1 %"isetrp_cmp1.46", %"isetrp_src_to_i1.46"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.46" to i32
  br label %"BB_1d20"
BB_1d20:
  %"phi.37" = phi  i32 [%"P35_to_i32", %"BB_18e0"], [%"P95_to_i32", %"BB_18d0"]
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.10" = add i32 1024, 2048
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %".822" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".823" = zext i32 %"iadd3_n2.10" to i64
  %".824" = zext i32 24 to i64
  %".825" = shl i64 %".822", %".824"
  %".826" = and i64 %".825", 4294967295
  %".827" = add i64 %".826", %".823"
  %".828" = trunc i64 %".827" to i32
  %"mbar_shared_winoff.1" = and i32 %".828", 16777215
  %".829" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".829" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P126_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_1d80"
BB_1d80:
  %"cond_trunc.40" = trunc i32 %"P126_to_i32" to i1
  %"cond_not.18" = xor i1 %"cond_trunc.40", -1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_not.18" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_2fc0", label %"BB_1d90"
BB_2fc0:
  %"mbar_shared_winoff.2" = and i32 %".828", 16777215
  %".832" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".832" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P127_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_2fd0"
BB_2fd0:
  %"cond_trunc.41" = trunc i32 %"P127_to_i32" to i1
  %"cond_not.19" = xor i1 %"cond_trunc.41", -1
  %"pbra_cond_to_i32.41" = zext i1 %"cond_not.19" to i32
  %"pbra_cond_to_i1.41" = icmp ne i32 %"pbra_cond_to_i32.41", 0
  br i1 %"pbra_cond_to_i1.41", label %"BB_2fc0", label %"BB_1d90"
BB_1d90:
  %".835" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".836" = bitcast i8* %".835" to i64*
  %"ldc_const.3" = load i64, i64* %".836"
  %"R25:R24_r0" = trunc i64 %"ldc_const.3" to i32
  %"R25:R24_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R25:R24_r1" = trunc i64 %"R25:R24_r1_shift" to i32
  %"imad_tmp.39" = mul i32 %"tid_x.1", 40
  %"imad.41" = add i32 %"imad_tmp.39", 0
  %"imad_tmp.40" = mul i32 %"imad.39", 1
  %"imad.42" = add i32 %"imad_tmp.40", %"imad.40"
  %"isetrp_cmp1.47" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.47" = zext i1 1 to i32
  %"isetrp_src_to_i1.47" = icmp ne i32 %"isetrp_src_to_i32.47", 0
  %"isetrp_cmp2.47" = and i1 %"isetrp_cmp1.47", %"isetrp_src_to_i1.47"
  %"P128_to_i32" = zext i1 %"isetrp_cmp2.47" to i32
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.40")
  %".837" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".838" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".839" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".840" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.40", 4
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".841" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".842" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".843" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".844" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R25:R24_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R25:R24_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.41" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.43" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R25:R24_r0.1" = trunc i64 %"imad.43" to i32
  %"R25:R24_r1_shift.1" = lshr i64 %"imad.43", 32
  %"R25:R24_r1.1" = trunc i64 %"R25:R24_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R405:R397_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".837", i32 addrspace(1)* %"R405:R397_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R405:R397_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".838", i32 addrspace(1)* %"R405:R397_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R405:R397_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".839", i32 addrspace(1)* %"R405:R397_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R405:R397_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".840", i32 addrspace(1)* %"R405:R397_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R405:R397_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".841", i32 addrspace(1)* %"R405:R397_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.40", 8
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".850" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".851" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".852" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".853" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R405:R397_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".842", i32 addrspace(1)* %"R405:R397_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R405:R397_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".843", i32 addrspace(1)* %"R405:R397_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R405:R397_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".844", i32 addrspace(1)* %"R405:R397_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.40", 12
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".857" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".858" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".859" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".860" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R405:R397_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".850", i32 addrspace(1)* %"R405:R397_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R405:R397_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".851", i32 addrspace(1)* %"R405:R397_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R405:R397_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".852", i32 addrspace(1)* %"R405:R397_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R405:R397_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".853", i32 addrspace(1)* %"R405:R397_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R405:R397_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".857", i32 addrspace(1)* %"R405:R397_addr_ptr.12"
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.38")
  %".866" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".867" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".868" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".869" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R405:R397_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".858", i32 addrspace(1)* %"R405:R397_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R405:R397_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".859", i32 addrspace(1)* %"R405:R397_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R405:R397_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".860", i32 addrspace(1)* %"R405:R397_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.42", 4
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".873" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".874" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".875" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".876" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R405:R397_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".866", i32 addrspace(1)* %"R405:R397_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R405:R397_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".867", i32 addrspace(1)* %"R405:R397_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R405:R397_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".868", i32 addrspace(1)* %"R405:R397_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R405:R397_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".869", i32 addrspace(1)* %"R405:R397_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R405:R397_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".873", i32 addrspace(1)* %"R405:R397_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.40", 16
  %"ldtm.12" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".882" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 0
  %".883" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 1
  %".884" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 2
  %".885" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R405:R397_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".874", i32 addrspace(1)* %"R405:R397_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R405:R397_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".875", i32 addrspace(1)* %"R405:R397_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R405:R397_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".876", i32 addrspace(1)* %"R405:R397_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.40", 20
  %"ldtm.13" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".889" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 0
  %".890" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 1
  %".891" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 2
  %".892" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R405:R397_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".882", i32 addrspace(1)* %"R405:R397_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R405:R397_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".883", i32 addrspace(1)* %"R405:R397_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R405:R397_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".884", i32 addrspace(1)* %"R405:R397_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R405:R397_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".885", i32 addrspace(1)* %"R405:R397_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R405:R397_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".889", i32 addrspace(1)* %"R405:R397_addr_ptr.28"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.40", 24
  %"ldtm.14" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".898" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 0
  %".899" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 1
  %".900" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 2
  %".901" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 3
  %"stg_addr_r0_ext.29" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R405:R397_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".890", i32 addrspace(1)* %"R405:R397_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R405:R397_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".891", i32 addrspace(1)* %"R405:R397_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R405:R397_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".892", i32 addrspace(1)* %"R405:R397_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.40", 28
  %"ldtm.15" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".905" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 0
  %".906" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 1
  %".907" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 2
  %".908" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 3
  %"stg_addr_r0_ext.32" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 128
  %"R405:R397_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".898", i32 addrspace(1)* %"R405:R397_addr_ptr.32"
  %"stg_addr_r0_ext.33" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 132
  %"R405:R397_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".899", i32 addrspace(1)* %"R405:R397_addr_ptr.33"
  %"stg_addr_r0_ext.34" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 136
  %"R405:R397_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".900", i32 addrspace(1)* %"R405:R397_addr_ptr.34"
  %"stg_addr_r0_ext.35" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 140
  %"R405:R397_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".901", i32 addrspace(1)* %"R405:R397_addr_ptr.35"
  %"stg_addr_r0_ext.36" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 144
  %"R405:R397_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".905", i32 addrspace(1)* %"R405:R397_addr_ptr.36"
  %"stg_addr_r0_ext.37" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 148
  %"R405:R397_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".906", i32 addrspace(1)* %"R405:R397_addr_ptr.37"
  %"stg_addr_r0_ext.38" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 152
  %"R405:R397_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".907", i32 addrspace(1)* %"R405:R397_addr_ptr.38"
  %"stg_addr_r0_ext.39" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 156
  %"R405:R397_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".908", i32 addrspace(1)* %"R405:R397_addr_ptr.39"
  br label %"BB_2220"
BB_2220:
  %"cond_trunc.42" = trunc i32 %"phi.37" to i1
  %"pbra_cond_to_i32.42" = zext i1 %"cond_trunc.42" to i32
  %"pbra_cond_to_i1.42" = icmp ne i32 %"pbra_cond_to_i32.42", 0
  br i1 %"pbra_cond_to_i1.42", label %"BB_2260", label %"BB_2230"
BB_2230:
  %"ldg_addr_r0_ext.42" = zext i32 %"R19:R18_r0.1" to i64
  %"ldg_addr_packed_0.42" = or i64 0, %"ldg_addr_r0_ext.42"
  %"ldg_addr_r1_ext.42" = zext i32 %"R19:R18_r1.1" to i64
  %"ldg_addr_r1_shift.42" = shl i64 %"ldg_addr_r1_ext.42", 32
  %"ldg_addr_packed_1.42" = or i64 %"ldg_addr_packed_0.42", %"ldg_addr_r1_shift.42"
  %"ldg_addr_memaddr_offset_add.41" = add i64 %"ldg_addr_packed_1.42", 9216
  %"R77:R45_addr_ptr.40" = inttoptr i64 %"ldg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  %"ldg.42" = load i32, i32 addrspace(1)* %"R77:R45_addr_ptr.40"
  %".919" = xor i32 0, -1
  %".920" = xor i32 %"ldg.42", -1
  %".921" = xor i32 0, -1
  %".922" = and i32 %".919", %".920"
  %".923" = and i32 %".922", %".921"
  %".924" = and i32 %".919", %".920"
  %".925" = and i32 %".924", 0
  %".926" = or i32 %".923", %".925"
  %".927" = and i32 0, %".920"
  %".928" = and i32 %".927", %".921"
  %".929" = or i32 %".926", %".928"
  %".930" = and i32 0, %".920"
  %".931" = and i32 %".930", 0
  %".932" = or i32 %".929", %".931"
  %"stg_addr_r0_ext.40" = zext i32 %"R25:R24_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R25:R24_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 64
  %"R405:R397_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".932", i32 addrspace(1)* %"R405:R397_addr_ptr.40"
  br label %"BB_2260"
BB_2260:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_2280"
BB_2280:
  %"cond_trunc.43" = trunc i32 %"P128_to_i32" to i1
  %"pbra_cond_to_i32.43" = zext i1 %"cond_trunc.43" to i32
  %"pbra_cond_to_i1.43" = icmp ne i32 %"pbra_cond_to_i32.43", 0
  br i1 %"pbra_cond_to_i1.43", label %"BB_80002280", label %"BB_2290"
BB_2290:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".582", 2056
  %"lds_shared_addr_winoff.9" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".937" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.9"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".937" to i32 addrspace(3)*
  %"lds.9" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.41" = mul i32 0, 0
  %"imad.44" = add i32 %"imad_tmp.41", 1
  %".938" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".939" = zext i32 80 to i64
  %".940" = zext i32 24 to i64
  %".941" = shl i64 %".938", %".940"
  %".942" = and i64 %".941", 4294967295
  %".943" = add i64 %".942", %".939"
  %".944" = trunc i64 %".943" to i32
  %"lds_shared_addr_winoff.10" = and i32 %".944", 16777215
  %".945" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.10"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".945" to i32 addrspace(3)*
  %"lds.10" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".946" = xor i32 %"lds.9", -1
  %".947" = xor i32 65535, -1
  %".948" = xor i32 0, -1
  %".949" = and i32 %"lds.9", 65535
  %".950" = and i32 %".949", %".948"
  %".951" = and i32 %"lds.9", 65535
  %".952" = and i32 %".951", 0
  %".953" = or i32 %".950", %".952"
  %".954" = zext i32 0 to i64
  %".955" = zext i32 %".953" to i64
  %".956" = shl i64 %".955", 32
  %"shf_concat.14" = or i64 %".954", %".956"
  %"shf_shift_64.14" = zext i32 5 to i64
  %".957" = lshr i64 %"shf_concat.14", %"shf_shift_64.14"
  %"shf_hi.2" = lshr i64 %".957", 32
  %"shf_result.14" = trunc i64 %"shf_hi.2" to i32
  %"viadd.11" = add i32 %"shf_result.14", 16
  %".958" = zext i32 %"imad.44" to i64
  %".959" = zext i32 0 to i64
  %".960" = shl i64 %".959", 32
  %"shf_concat.15" = or i64 %".958", %".960"
  %"shf_shift_64.15" = zext i32 %"shf_result.14" to i64
  %".961" = shl i64 %"shf_concat.15", %"shf_shift_64.15"
  %"shf_result.15" = trunc i64 %".961" to i32
  %".962" = zext i32 %"imad.44" to i64
  %".963" = zext i32 0 to i64
  %".964" = shl i64 %".963", 32
  %"shf_concat.16" = or i64 %".962", %".964"
  %"shf_shift_64.16" = zext i32 %"viadd.11" to i64
  %".965" = shl i64 %"shf_concat.16", %"shf_shift_64.16"
  %"shf_result.16" = trunc i64 %".965" to i32
  %".966" = xor i32 %"shf_result.16", -1
  %".967" = xor i32 %"shf_result.15", -1
  %".968" = xor i32 0, -1
  %".969" = and i32 %".966", %"shf_result.15"
  %".970" = and i32 %".969", %".968"
  %".971" = and i32 %".966", %"shf_result.15"
  %".972" = and i32 %".971", 0
  %".973" = or i32 %".970", %".972"
  %".974" = and i32 %"shf_result.16", %".967"
  %".975" = and i32 %".974", %".968"
  %".976" = or i32 %".973", %".975"
  %".977" = and i32 %"shf_result.16", %".967"
  %".978" = and i32 %".977", 0
  %".979" = or i32 %".976", %".978"
  %".980" = and i32 %"shf_result.16", %"shf_result.15"
  %".981" = and i32 %".980", %".968"
  %".982" = or i32 %".979", %".981"
  %".983" = and i32 %"shf_result.16", %"shf_result.15"
  %".984" = and i32 %".983", 0
  %".985" = or i32 %".982", %".984"
  %".986" = xor i32 %".985", -1
  %".987" = xor i32 65535, -1
  %".988" = xor i32 0, -1
  %".989" = and i32 %".985", 65535
  %".990" = and i32 %".989", %".988"
  %".991" = and i32 %".985", 65535
  %".992" = and i32 %".991", 0
  %".993" = or i32 %".990", %".992"
  %".994" = xor i32 %".985", -1
  %".995" = xor i32 65535, -1
  %".996" = xor i32 %"lds.10", -1
  %".997" = and i32 %".985", 65535
  %".998" = and i32 %".997", %"lds.10"
  %"isetrp_cmp1.48" = icmp ne i32 %".998", %".993"
  %"isetrp_src_to_i32.48" = zext i1 1 to i32
  %"isetrp_src_to_i1.48" = icmp ne i32 %"isetrp_src_to_i32.48", 0
  %"isetrp_cmp2.48" = and i1 %"isetrp_cmp1.48", %"isetrp_src_to_i1.48"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.48" to i32
  br label %"BB_2380"
BB_2380:
  %"cond_trunc.44" = trunc i32 %"P56_to_i32" to i1
  %"pbra_cond_to_i32.44" = zext i1 %"cond_trunc.44" to i32
  %"pbra_cond_to_i1.44" = icmp ne i32 %"pbra_cond_to_i32.44", 0
  br i1 %"pbra_cond_to_i1.44", label %"BB_24e0_3050", label %"BB_2390"
BB_2390:
  %".1001" = zext i32 0 to i64
  %".1002" = zext i32 %"lds.10" to i64
  %".1003" = shl i64 %".1002", 32
  %"shf_concat.17" = or i64 %".1001", %".1003"
  %"shf_shift_64.17" = zext i32 16 to i64
  %".1004" = lshr i64 %"shf_concat.17", %"shf_shift_64.17"
  %"shf_hi.3" = lshr i64 %".1004", 32
  %"shf_result.17" = trunc i64 %"shf_hi.3" to i32
  %".1005" = zext i32 0 to i64
  %".1006" = zext i32 %".985" to i64
  %".1007" = shl i64 %".1006", 32
  %"shf_concat.18" = or i64 %".1005", %".1007"
  %"shf_shift_64.18" = zext i32 16 to i64
  %".1008" = lshr i64 %"shf_concat.18", %"shf_shift_64.18"
  %"shf_hi.4" = lshr i64 %".1008", 32
  %"shf_result.18" = trunc i64 %"shf_hi.4" to i32
  %".1009" = xor i32 %"shf_result.17", -1
  %".1010" = xor i32 %"shf_result.18", -1
  %".1011" = xor i32 0, -1
  %".1012" = and i32 %"shf_result.17", %"shf_result.18"
  %".1013" = and i32 %".1012", %".1011"
  %".1014" = and i32 %"shf_result.17", %"shf_result.18"
  %".1015" = and i32 %".1014", 0
  %".1016" = or i32 %".1013", %".1015"
  %"isetrp_cmp1.49" = icmp ne i32 %".1016", %"shf_result.18"
  %"isetrp_src_to_i32.49" = zext i1 1 to i32
  %"isetrp_src_to_i1.49" = icmp ne i32 %"isetrp_src_to_i32.49", 0
  %"isetrp_cmp2.49" = and i1 %"isetrp_cmp1.49", %"isetrp_src_to_i1.49"
  %"P65_to_i32" = zext i1 %"isetrp_cmp2.49" to i32
  br label %"BB_23d0"
BB_23d0:
  %"cond_trunc.45" = trunc i32 %"P65_to_i32" to i1
  %"pbra_cond_to_i32.45" = zext i1 %"cond_trunc.45" to i32
  %"pbra_cond_to_i1.45" = icmp ne i32 %"pbra_cond_to_i32.45", 0
  br i1 %"pbra_cond_to_i1.45", label %"BB_24b0_2ff0", label %"BB_23e0"
BB_23e0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".1019" = xor i32 0, -1
  %".1020" = xor i32 %".985", -1
  %".1021" = xor i32 0, -1
  %".1022" = and i32 %".1019", %".1020"
  %".1023" = and i32 %".1022", %".1021"
  %".1024" = and i32 %".1019", %".1020"
  %".1025" = and i32 %".1024", 0
  %".1026" = or i32 %".1023", %".1025"
  %".1027" = and i32 0, %".1020"
  %".1028" = and i32 %".1027", %".1021"
  %".1029" = or i32 %".1026", %".1028"
  %".1030" = and i32 0, %".1020"
  %".1031" = and i32 %".1030", 0
  %".1032" = or i32 %".1029", %".1031"
  %"imad_tmp.42" = mul i32 0, 0
  %"imad.45" = add i32 %"imad_tmp.42", %".1032"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.45", i32 %"redux_mask")
  %".1033" = xor i32 %".1032", -1
  %".1034" = call i32 @"llvm.cttz.i32"(i32 %".1033", i1 0)
  %".1035" = shl i32 %".1034", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".1035") convergent
  %"isetrp_cmp1.50" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.50" = zext i1 1 to i32
  %"isetrp_src_to_i1.50" = icmp ne i32 %"isetrp_src_to_i32.50", 0
  %"isetrp_cmp2.50" = and i1 %"isetrp_cmp1.50", %"isetrp_src_to_i1.50"
  %"P73_to_i32" = zext i1 %"isetrp_cmp2.50" to i32
  %"imad_tmp.43" = mul i32 0, 0
  %"imad.46" = add i32 %"imad_tmp.43", %"redux_sync_and"
  br label %"BB_2480"
BB_2480:
  %"cond_trunc.46" = trunc i32 %"P73_to_i32" to i1
  %"pbra_cond_to_i32.46" = zext i1 %"cond_trunc.46" to i32
  %"pbra_cond_to_i1.46" = icmp ne i32 %"pbra_cond_to_i32.46", 0
  br i1 %"pbra_cond_to_i1.46", label %"BB_80002480", label %"BB_24f0"
BB_80002480:
  %"atoms_shared_addr_winoff.5" = and i32 %".944", 16777215
  %".1039" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.5"
  %"atoms_ptr.5" = bitcast i8 addrspace(3)* %".1039" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.5", i32 %"imad.46" monotonic
  br label %"BB_24f0"
BB_24b0_2ff0:
  call void @"llvm.trap"()
  br label %"BB_24f0"
BB_24e0_3050:
  call void @"llvm.trap"()
  br label %"BB_24f0"
BB_24f0:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.44" = mul i32 0, 0
  %"imad.47" = add i32 %"imad_tmp.44", 1
  %".1043" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".1044" = zext i32 1024 to i64
  %".1045" = zext i32 24 to i64
  %".1046" = shl i64 %".1043", %".1045"
  %".1047" = and i64 %".1046", 4294967295
  %".1048" = add i64 %".1047", %".1044"
  %".1049" = trunc i64 %".1048" to i32
  %"lds_addr_memaddr_offset_add.5" = add i32 %".1049", 2060
  %"lds_shared_addr_winoff.11" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".1050" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.11"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".1050" to i32 addrspace(3)*
  %"lds.11" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %".1051" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".1052" = zext i32 80 to i64
  %".1053" = zext i32 24 to i64
  %".1054" = shl i64 %".1051", %".1053"
  %".1055" = and i64 %".1054", 4294967295
  %".1056" = add i64 %".1055", %".1052"
  %".1057" = trunc i64 %".1056" to i32
  %"lds_shared_addr_winoff.12" = and i32 %".1057", 16777215
  %".1058" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.12"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".1058" to i32 addrspace(3)*
  %"lds.12" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.7"
  %".1059" = xor i32 %"lds.11", -1
  %".1060" = xor i32 65535, -1
  %".1061" = xor i32 0, -1
  %".1062" = and i32 %"lds.11", 65535
  %".1063" = and i32 %".1062", %".1061"
  %".1064" = and i32 %"lds.11", 65535
  %".1065" = and i32 %".1064", 0
  %".1066" = or i32 %".1063", %".1065"
  %".1067" = zext i32 0 to i64
  %".1068" = zext i32 %".1066" to i64
  %".1069" = shl i64 %".1068", 32
  %"shf_concat.19" = or i64 %".1067", %".1069"
  %"shf_shift_64.19" = zext i32 5 to i64
  %".1070" = lshr i64 %"shf_concat.19", %"shf_shift_64.19"
  %"shf_hi.5" = lshr i64 %".1070", 32
  %"shf_result.19" = trunc i64 %"shf_hi.5" to i32
  %"viadd.12" = add i32 %"shf_result.19", 16
  %".1071" = zext i32 %"imad.47" to i64
  %".1072" = zext i32 0 to i64
  %".1073" = shl i64 %".1072", 32
  %"shf_concat.20" = or i64 %".1071", %".1073"
  %"shf_shift_64.20" = zext i32 %"shf_result.19" to i64
  %".1074" = shl i64 %"shf_concat.20", %"shf_shift_64.20"
  %"shf_result.20" = trunc i64 %".1074" to i32
  %".1075" = zext i32 %"imad.47" to i64
  %".1076" = zext i32 0 to i64
  %".1077" = shl i64 %".1076", 32
  %"shf_concat.21" = or i64 %".1075", %".1077"
  %"shf_shift_64.21" = zext i32 %"viadd.12" to i64
  %".1078" = shl i64 %"shf_concat.21", %"shf_shift_64.21"
  %"shf_result.21" = trunc i64 %".1078" to i32
  %".1079" = xor i32 %"shf_result.21", -1
  %".1080" = xor i32 %"shf_result.20", -1
  %".1081" = xor i32 0, -1
  %".1082" = and i32 %".1079", %"shf_result.20"
  %".1083" = and i32 %".1082", %".1081"
  %".1084" = and i32 %".1079", %"shf_result.20"
  %".1085" = and i32 %".1084", 0
  %".1086" = or i32 %".1083", %".1085"
  %".1087" = and i32 %"shf_result.21", %".1080"
  %".1088" = and i32 %".1087", %".1081"
  %".1089" = or i32 %".1086", %".1088"
  %".1090" = and i32 %"shf_result.21", %".1080"
  %".1091" = and i32 %".1090", 0
  %".1092" = or i32 %".1089", %".1091"
  %".1093" = and i32 %"shf_result.21", %"shf_result.20"
  %".1094" = and i32 %".1093", %".1081"
  %".1095" = or i32 %".1092", %".1094"
  %".1096" = and i32 %"shf_result.21", %"shf_result.20"
  %".1097" = and i32 %".1096", 0
  %".1098" = or i32 %".1095", %".1097"
  %".1099" = xor i32 %".1098", -1
  %".1100" = xor i32 65535, -1
  %".1101" = xor i32 0, -1
  %".1102" = and i32 %".1098", 65535
  %".1103" = and i32 %".1102", %".1101"
  %".1104" = and i32 %".1098", 65535
  %".1105" = and i32 %".1104", 0
  %".1106" = or i32 %".1103", %".1105"
  %".1107" = xor i32 %".1098", -1
  %".1108" = xor i32 65535, -1
  %".1109" = xor i32 %"lds.12", -1
  %".1110" = and i32 %".1098", 65535
  %".1111" = and i32 %".1110", %"lds.12"
  %"isetrp_cmp1.51" = icmp ne i32 %".1111", %".1106"
  %"isetrp_src_to_i32.51" = zext i1 1 to i32
  %"isetrp_src_to_i1.51" = icmp ne i32 %"isetrp_src_to_i32.51", 0
  %"isetrp_cmp2.51" = and i1 %"isetrp_cmp1.51", %"isetrp_src_to_i1.51"
  %"P100_to_i32" = zext i1 %"isetrp_cmp2.51" to i32
  br label %"BB_2620"
BB_2620:
  %"cond_trunc.47" = trunc i32 %"P100_to_i32" to i1
  %"pbra_cond_to_i32.47" = zext i1 %"cond_trunc.47" to i32
  %"pbra_cond_to_i1.47" = icmp ne i32 %"pbra_cond_to_i32.47", 0
  br i1 %"pbra_cond_to_i1.47", label %"BB_2780_3050", label %"BB_2630"
BB_2630:
  %".1114" = zext i32 0 to i64
  %".1115" = zext i32 %"lds.12" to i64
  %".1116" = shl i64 %".1115", 32
  %"shf_concat.22" = or i64 %".1114", %".1116"
  %"shf_shift_64.22" = zext i32 16 to i64
  %".1117" = lshr i64 %"shf_concat.22", %"shf_shift_64.22"
  %"shf_hi.6" = lshr i64 %".1117", 32
  %"shf_result.22" = trunc i64 %"shf_hi.6" to i32
  %".1118" = zext i32 0 to i64
  %".1119" = zext i32 %".1098" to i64
  %".1120" = shl i64 %".1119", 32
  %"shf_concat.23" = or i64 %".1118", %".1120"
  %"shf_shift_64.23" = zext i32 16 to i64
  %".1121" = lshr i64 %"shf_concat.23", %"shf_shift_64.23"
  %"shf_hi.7" = lshr i64 %".1121", 32
  %"shf_result.23" = trunc i64 %"shf_hi.7" to i32
  %".1122" = xor i32 %"shf_result.22", -1
  %".1123" = xor i32 %"shf_result.23", -1
  %".1124" = xor i32 0, -1
  %".1125" = and i32 %"shf_result.22", %"shf_result.23"
  %".1126" = and i32 %".1125", %".1124"
  %".1127" = and i32 %"shf_result.22", %"shf_result.23"
  %".1128" = and i32 %".1127", 0
  %".1129" = or i32 %".1126", %".1128"
  %"isetrp_cmp1.52" = icmp ne i32 %".1129", %"shf_result.23"
  %"isetrp_src_to_i32.52" = zext i1 1 to i32
  %"isetrp_src_to_i1.52" = icmp ne i32 %"isetrp_src_to_i32.52", 0
  %"isetrp_cmp2.52" = and i1 %"isetrp_cmp1.52", %"isetrp_src_to_i1.52"
  %"P51_to_i32" = zext i1 %"isetrp_cmp2.52" to i32
  br label %"BB_2670"
BB_2670:
  %"cond_trunc.48" = trunc i32 %"P51_to_i32" to i1
  %"pbra_cond_to_i32.48" = zext i1 %"cond_trunc.48" to i32
  %"pbra_cond_to_i1.48" = icmp ne i32 %"pbra_cond_to_i32.48", 0
  br i1 %"pbra_cond_to_i1.48", label %"BB_2750_2ff0", label %"BB_2680"
BB_2680:
  %"activemask.1" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.1" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.1" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.1", i1 0)
  %"flo.1" = sub i32 31, %"flo_clz.1"
  %".1132" = xor i32 0, -1
  %".1133" = xor i32 %".1098", -1
  %".1134" = xor i32 0, -1
  %".1135" = and i32 %".1132", %".1133"
  %".1136" = and i32 %".1135", %".1134"
  %".1137" = and i32 %".1132", %".1133"
  %".1138" = and i32 %".1137", 0
  %".1139" = or i32 %".1136", %".1138"
  %".1140" = and i32 0, %".1133"
  %".1141" = and i32 %".1140", %".1134"
  %".1142" = or i32 %".1139", %".1141"
  %".1143" = and i32 0, %".1133"
  %".1144" = and i32 %".1143", 0
  %".1145" = or i32 %".1142", %".1144"
  %"imad_tmp.45" = mul i32 0, 0
  %"imad.48" = add i32 %"imad_tmp.45", %".1145"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.48", i32 %"redux_mask.1")
  %".1146" = xor i32 %".1145", -1
  %".1147" = call i32 @"llvm.cttz.i32"(i32 %".1146", i1 0)
  %".1148" = shl i32 %".1147", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".1148") convergent
  %"isetrp_cmp1.53" = icmp eq i32 %"laneid.1", %"flo.1"
  %"isetrp_src_to_i32.53" = zext i1 1 to i32
  %"isetrp_src_to_i1.53" = icmp ne i32 %"isetrp_src_to_i32.53", 0
  %"isetrp_cmp2.53" = and i1 %"isetrp_cmp1.53", %"isetrp_src_to_i1.53"
  %"P105_to_i32" = zext i1 %"isetrp_cmp2.53" to i32
  %"imad_tmp.46" = mul i32 0, 0
  %"imad.49" = add i32 %"imad_tmp.46", %"redux_sync_and.1"
  br label %"BB_2720"
BB_2720:
  %"cond_trunc.49" = trunc i32 %"P105_to_i32" to i1
  %"pbra_cond_to_i32.49" = zext i1 %"cond_trunc.49" to i32
  %"pbra_cond_to_i1.49" = icmp ne i32 %"pbra_cond_to_i32.49", 0
  br i1 %"pbra_cond_to_i1.49", label %"BB_80002720", label %"BB_2790"
BB_80002720:
  %"atoms_shared_addr_winoff.6" = and i32 %".1057", 16777215
  %".1152" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.6"
  %"atoms_ptr.6" = bitcast i8 addrspace(3)* %".1152" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.6", i32 %"imad.49" monotonic
  br label %"BB_2790"
BB_2750_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2790"
BB_2780_3050:
  call void @"llvm.trap"()
  br label %"BB_2790"
BB_2790:
  %"s2ur_cluster_ctarank.2" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.47" = mul i32 0, 0
  %"imad.50" = add i32 %"imad_tmp.47", 3
  %"imad_tmp.48" = mul i32 0, 0
  %"imad.51" = add i32 %"imad_tmp.48", 1
  %".1156" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".1157" = zext i32 1024 to i64
  %".1158" = zext i32 24 to i64
  %".1159" = shl i64 %".1156", %".1158"
  %".1160" = and i64 %".1159", 4294967295
  %".1161" = add i64 %".1160", %".1157"
  %".1162" = trunc i64 %".1161" to i32
  %"lds_addr_memaddr_offset_add.6" = add i32 %".1162", 2064
  %"lds_shared_addr_winoff.13" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".1163" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.13"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".1163" to i32 addrspace(3)*
  %"lds.13" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.8"
  %".1164" = zext i32 %"s2ur_cluster_ctarank.2" to i64
  %".1165" = zext i32 80 to i64
  %".1166" = zext i32 24 to i64
  %".1167" = shl i64 %".1164", %".1166"
  %".1168" = and i64 %".1167", 4294967295
  %".1169" = add i64 %".1168", %".1165"
  %".1170" = trunc i64 %".1169" to i32
  %"lds_shared_addr_winoff.14" = and i32 %".1170", 16777215
  %".1171" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.14"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".1171" to i32 addrspace(3)*
  %"lds.14" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.9"
  %".1172" = xor i32 %"lds.13", -1
  %".1173" = xor i32 65535, -1
  %".1174" = xor i32 0, -1
  %".1175" = and i32 %"lds.13", 65535
  %".1176" = and i32 %".1175", %".1174"
  %".1177" = and i32 %"lds.13", 65535
  %".1178" = and i32 %".1177", 0
  %".1179" = or i32 %".1176", %".1178"
  %".1180" = zext i32 0 to i64
  %".1181" = zext i32 %".1179" to i64
  %".1182" = shl i64 %".1181", 32
  %"shf_concat.24" = or i64 %".1180", %".1182"
  %"shf_shift_64.24" = zext i32 5 to i64
  %".1183" = lshr i64 %"shf_concat.24", %"shf_shift_64.24"
  %"shf_hi.8" = lshr i64 %".1183", 32
  %"shf_result.24" = trunc i64 %"shf_hi.8" to i32
  %"viadd.13" = add i32 %"shf_result.24", 16
  %".1184" = zext i32 %"imad.50" to i64
  %".1185" = zext i32 0 to i64
  %".1186" = shl i64 %".1185", 32
  %"shf_concat.25" = or i64 %".1184", %".1186"
  %"shf_shift_64.25" = zext i32 %"shf_result.24" to i64
  %".1187" = shl i64 %"shf_concat.25", %"shf_shift_64.25"
  %"shf_result.25" = trunc i64 %".1187" to i32
  %".1188" = zext i32 %"imad.51" to i64
  %".1189" = zext i32 0 to i64
  %".1190" = shl i64 %".1189", 32
  %"shf_concat.26" = or i64 %".1188", %".1190"
  %"shf_shift_64.26" = zext i32 %"viadd.13" to i64
  %".1191" = shl i64 %"shf_concat.26", %"shf_shift_64.26"
  %"shf_result.26" = trunc i64 %".1191" to i32
  %".1192" = xor i32 %"shf_result.26", -1
  %".1193" = xor i32 %"shf_result.25", -1
  %".1194" = xor i32 0, -1
  %".1195" = and i32 %".1192", %"shf_result.25"
  %".1196" = and i32 %".1195", %".1194"
  %".1197" = and i32 %".1192", %"shf_result.25"
  %".1198" = and i32 %".1197", 0
  %".1199" = or i32 %".1196", %".1198"
  %".1200" = and i32 %"shf_result.26", %".1193"
  %".1201" = and i32 %".1200", %".1194"
  %".1202" = or i32 %".1199", %".1201"
  %".1203" = and i32 %"shf_result.26", %".1193"
  %".1204" = and i32 %".1203", 0
  %".1205" = or i32 %".1202", %".1204"
  %".1206" = and i32 %"shf_result.26", %"shf_result.25"
  %".1207" = and i32 %".1206", %".1194"
  %".1208" = or i32 %".1205", %".1207"
  %".1209" = and i32 %"shf_result.26", %"shf_result.25"
  %".1210" = and i32 %".1209", 0
  %".1211" = or i32 %".1208", %".1210"
  %".1212" = xor i32 %".1211", -1
  %".1213" = xor i32 65535, -1
  %".1214" = xor i32 0, -1
  %".1215" = and i32 %".1211", 65535
  %".1216" = and i32 %".1215", %".1214"
  %".1217" = and i32 %".1211", 65535
  %".1218" = and i32 %".1217", 0
  %".1219" = or i32 %".1216", %".1218"
  %".1220" = xor i32 %".1211", -1
  %".1221" = xor i32 65535, -1
  %".1222" = xor i32 %"lds.14", -1
  %".1223" = and i32 %".1211", 65535
  %".1224" = and i32 %".1223", %"lds.14"
  %"isetrp_cmp1.54" = icmp ne i32 %".1224", %".1219"
  %"isetrp_src_to_i32.54" = zext i1 1 to i32
  %"isetrp_src_to_i1.54" = icmp ne i32 %"isetrp_src_to_i32.54", 0
  %"isetrp_cmp2.54" = and i1 %"isetrp_cmp1.54", %"isetrp_src_to_i1.54"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.54" to i32
  br label %"BB_28d0"
BB_28d0:
  %"cond_trunc.50" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.50" = zext i1 %"cond_trunc.50" to i32
  %"pbra_cond_to_i1.50" = icmp ne i32 %"pbra_cond_to_i32.50", 0
  br i1 %"pbra_cond_to_i1.50", label %"BB_2a30_3050", label %"BB_28e0"
BB_28e0:
  %".1227" = zext i32 0 to i64
  %".1228" = zext i32 %"lds.14" to i64
  %".1229" = shl i64 %".1228", 32
  %"shf_concat.27" = or i64 %".1227", %".1229"
  %"shf_shift_64.27" = zext i32 16 to i64
  %".1230" = lshr i64 %"shf_concat.27", %"shf_shift_64.27"
  %"shf_hi.9" = lshr i64 %".1230", 32
  %"shf_result.27" = trunc i64 %"shf_hi.9" to i32
  %".1231" = zext i32 0 to i64
  %".1232" = zext i32 %".1211" to i64
  %".1233" = shl i64 %".1232", 32
  %"shf_concat.28" = or i64 %".1231", %".1233"
  %"shf_shift_64.28" = zext i32 16 to i64
  %".1234" = lshr i64 %"shf_concat.28", %"shf_shift_64.28"
  %"shf_hi.10" = lshr i64 %".1234", 32
  %"shf_result.28" = trunc i64 %"shf_hi.10" to i32
  %".1235" = xor i32 %"shf_result.27", -1
  %".1236" = xor i32 %"shf_result.28", -1
  %".1237" = xor i32 0, -1
  %".1238" = and i32 %"shf_result.27", %"shf_result.28"
  %".1239" = and i32 %".1238", %".1237"
  %".1240" = and i32 %"shf_result.27", %"shf_result.28"
  %".1241" = and i32 %".1240", 0
  %".1242" = or i32 %".1239", %".1241"
  %"isetrp_cmp1.55" = icmp ne i32 %".1242", %"shf_result.28"
  %"isetrp_src_to_i32.55" = zext i1 1 to i32
  %"isetrp_src_to_i1.55" = icmp ne i32 %"isetrp_src_to_i32.55", 0
  %"isetrp_cmp2.55" = and i1 %"isetrp_cmp1.55", %"isetrp_src_to_i1.55"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.55" to i32
  br label %"BB_2920"
BB_2920:
  %"cond_trunc.51" = trunc i32 %"P15_to_i32" to i1
  %"pbra_cond_to_i32.51" = zext i1 %"cond_trunc.51" to i32
  %"pbra_cond_to_i1.51" = icmp ne i32 %"pbra_cond_to_i32.51", 0
  br i1 %"pbra_cond_to_i1.51", label %"BB_2a00_2ff0", label %"BB_2930"
BB_2930:
  %"activemask.2" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.2" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.2" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.2", i1 0)
  %"flo.2" = sub i32 31, %"flo_clz.2"
  %".1245" = xor i32 0, -1
  %".1246" = xor i32 %".1211", -1
  %".1247" = xor i32 0, -1
  %".1248" = and i32 %".1245", %".1246"
  %".1249" = and i32 %".1248", %".1247"
  %".1250" = and i32 %".1245", %".1246"
  %".1251" = and i32 %".1250", 0
  %".1252" = or i32 %".1249", %".1251"
  %".1253" = and i32 0, %".1246"
  %".1254" = and i32 %".1253", %".1247"
  %".1255" = or i32 %".1252", %".1254"
  %".1256" = and i32 0, %".1246"
  %".1257" = and i32 %".1256", 0
  %".1258" = or i32 %".1255", %".1257"
  %"imad_tmp.49" = mul i32 0, 0
  %"imad.52" = add i32 %"imad_tmp.49", %".1258"
  %"redux_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.2" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.52", i32 %"redux_mask.2")
  %".1259" = xor i32 %".1258", -1
  %".1260" = call i32 @"llvm.cttz.i32"(i32 %".1259", i1 0)
  %".1261" = shl i32 %".1260", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".1261") convergent
  %"isetrp_cmp1.56" = icmp eq i32 %"laneid.2", %"flo.2"
  %"isetrp_src_to_i32.56" = zext i1 1 to i32
  %"isetrp_src_to_i1.56" = icmp ne i32 %"isetrp_src_to_i32.56", 0
  %"isetrp_cmp2.56" = and i1 %"isetrp_cmp1.56", %"isetrp_src_to_i1.56"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.56" to i32
  %"imad_tmp.50" = mul i32 0, 0
  %"imad.53" = add i32 %"imad_tmp.50", %"redux_sync_and.2"
  br label %"BB_29d0"
BB_29d0:
  %"cond_trunc.52" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.52" = zext i1 %"cond_trunc.52" to i32
  %"pbra_cond_to_i1.52" = icmp ne i32 %"pbra_cond_to_i32.52", 0
  br i1 %"pbra_cond_to_i1.52", label %"BB_800029d0", label %"BB_2a40"
BB_800029d0:
  %"atoms_shared_addr_winoff.7" = and i32 %".1170", 16777215
  %".1265" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.7"
  %"atoms_ptr.7" = bitcast i8 addrspace(3)* %".1265" to i32 addrspace(3)*
  %"atoms_and.2" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.7", i32 %"imad.53" monotonic
  br label %"BB_2a40"
BB_2a00_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2a40"
BB_2a30_3050:
  call void @"llvm.trap"()
  br label %"BB_2a40"
BB_2a40:
  %"s2ur_cluster_ctarank.3" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.51" = mul i32 0, 0
  %"imad.54" = add i32 %"imad_tmp.51", 15
  %"imad_tmp.52" = mul i32 0, 0
  %"imad.55" = add i32 %"imad_tmp.52", 1
  %".1269" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".1270" = zext i32 1024 to i64
  %".1271" = zext i32 24 to i64
  %".1272" = shl i64 %".1269", %".1271"
  %".1273" = and i64 %".1272", 4294967295
  %".1274" = add i64 %".1273", %".1270"
  %".1275" = trunc i64 %".1274" to i32
  %"lds_addr_memaddr_offset_add.7" = add i32 %".1275", 2068
  %"lds_shared_addr_winoff.15" = and i32 %"lds_addr_memaddr_offset_add.7", 16777215
  %".1276" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.15"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".1276" to i32 addrspace(3)*
  %"lds.15" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.10"
  %".1277" = zext i32 %"s2ur_cluster_ctarank.3" to i64
  %".1278" = zext i32 80 to i64
  %".1279" = zext i32 24 to i64
  %".1280" = shl i64 %".1277", %".1279"
  %".1281" = and i64 %".1280", 4294967295
  %".1282" = add i64 %".1281", %".1278"
  %".1283" = trunc i64 %".1282" to i32
  %"lds_shared_addr_winoff.16" = and i32 %".1283", 16777215
  %".1284" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.16"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".1284" to i32 addrspace(3)*
  %"lds.16" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.11"
  %".1285" = xor i32 %"lds.15", -1
  %".1286" = xor i32 65535, -1
  %".1287" = xor i32 0, -1
  %".1288" = and i32 %"lds.15", 65535
  %".1289" = and i32 %".1288", %".1287"
  %".1290" = and i32 %"lds.15", 65535
  %".1291" = and i32 %".1290", 0
  %".1292" = or i32 %".1289", %".1291"
  %".1293" = zext i32 0 to i64
  %".1294" = zext i32 %".1292" to i64
  %".1295" = shl i64 %".1294", 32
  %"shf_concat.29" = or i64 %".1293", %".1295"
  %"shf_shift_64.29" = zext i32 5 to i64
  %".1296" = lshr i64 %"shf_concat.29", %"shf_shift_64.29"
  %"shf_hi.11" = lshr i64 %".1296", 32
  %"shf_result.29" = trunc i64 %"shf_hi.11" to i32
  %"viadd.14" = add i32 %"shf_result.29", 16
  %".1297" = zext i32 %"imad.54" to i64
  %".1298" = zext i32 0 to i64
  %".1299" = shl i64 %".1298", 32
  %"shf_concat.30" = or i64 %".1297", %".1299"
  %"shf_shift_64.30" = zext i32 %"shf_result.29" to i64
  %".1300" = shl i64 %"shf_concat.30", %"shf_shift_64.30"
  %"shf_result.30" = trunc i64 %".1300" to i32
  %".1301" = zext i32 %"imad.55" to i64
  %".1302" = zext i32 0 to i64
  %".1303" = shl i64 %".1302", 32
  %"shf_concat.31" = or i64 %".1301", %".1303"
  %"shf_shift_64.31" = zext i32 %"viadd.14" to i64
  %".1304" = shl i64 %"shf_concat.31", %"shf_shift_64.31"
  %"shf_result.31" = trunc i64 %".1304" to i32
  %".1305" = xor i32 %"shf_result.31", -1
  %".1306" = xor i32 %"shf_result.30", -1
  %".1307" = xor i32 0, -1
  %".1308" = and i32 %".1305", %"shf_result.30"
  %".1309" = and i32 %".1308", %".1307"
  %".1310" = and i32 %".1305", %"shf_result.30"
  %".1311" = and i32 %".1310", 0
  %".1312" = or i32 %".1309", %".1311"
  %".1313" = and i32 %"shf_result.31", %".1306"
  %".1314" = and i32 %".1313", %".1307"
  %".1315" = or i32 %".1312", %".1314"
  %".1316" = and i32 %"shf_result.31", %".1306"
  %".1317" = and i32 %".1316", 0
  %".1318" = or i32 %".1315", %".1317"
  %".1319" = and i32 %"shf_result.31", %"shf_result.30"
  %".1320" = and i32 %".1319", %".1307"
  %".1321" = or i32 %".1318", %".1320"
  %".1322" = and i32 %"shf_result.31", %"shf_result.30"
  %".1323" = and i32 %".1322", 0
  %".1324" = or i32 %".1321", %".1323"
  %".1325" = xor i32 %".1324", -1
  %".1326" = xor i32 65535, -1
  %".1327" = xor i32 0, -1
  %".1328" = and i32 %".1324", 65535
  %".1329" = and i32 %".1328", %".1327"
  %".1330" = and i32 %".1324", 65535
  %".1331" = and i32 %".1330", 0
  %".1332" = or i32 %".1329", %".1331"
  %".1333" = xor i32 %".1324", -1
  %".1334" = xor i32 65535, -1
  %".1335" = xor i32 %"lds.16", -1
  %".1336" = and i32 %".1324", 65535
  %".1337" = and i32 %".1336", %"lds.16"
  %"isetrp_cmp1.57" = icmp ne i32 %".1337", %".1332"
  %"isetrp_src_to_i32.57" = zext i1 1 to i32
  %"isetrp_src_to_i1.57" = icmp ne i32 %"isetrp_src_to_i32.57", 0
  %"isetrp_cmp2.57" = and i1 %"isetrp_cmp1.57", %"isetrp_src_to_i1.57"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.57" to i32
  br label %"BB_2b80"
BB_2b80:
  %"cond_trunc.53" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.53" = zext i1 %"cond_trunc.53" to i32
  %"pbra_cond_to_i1.53" = icmp ne i32 %"pbra_cond_to_i32.53", 0
  br i1 %"pbra_cond_to_i1.53", label %"BB_2ce0_3050", label %"BB_2b90"
BB_2b90:
  %".1340" = zext i32 0 to i64
  %".1341" = zext i32 %"lds.16" to i64
  %".1342" = shl i64 %".1341", 32
  %"shf_concat.32" = or i64 %".1340", %".1342"
  %"shf_shift_64.32" = zext i32 16 to i64
  %".1343" = lshr i64 %"shf_concat.32", %"shf_shift_64.32"
  %"shf_hi.12" = lshr i64 %".1343", 32
  %"shf_result.32" = trunc i64 %"shf_hi.12" to i32
  %".1344" = zext i32 0 to i64
  %".1345" = zext i32 %".1324" to i64
  %".1346" = shl i64 %".1345", 32
  %"shf_concat.33" = or i64 %".1344", %".1346"
  %"shf_shift_64.33" = zext i32 16 to i64
  %".1347" = lshr i64 %"shf_concat.33", %"shf_shift_64.33"
  %"shf_hi.13" = lshr i64 %".1347", 32
  %"shf_result.33" = trunc i64 %"shf_hi.13" to i32
  %".1348" = xor i32 %"shf_result.32", -1
  %".1349" = xor i32 %"shf_result.33", -1
  %".1350" = xor i32 0, -1
  %".1351" = and i32 %"shf_result.32", %"shf_result.33"
  %".1352" = and i32 %".1351", %".1350"
  %".1353" = and i32 %"shf_result.32", %"shf_result.33"
  %".1354" = and i32 %".1353", 0
  %".1355" = or i32 %".1352", %".1354"
  %"isetrp_cmp1.58" = icmp ne i32 %".1355", %"shf_result.33"
  %"isetrp_src_to_i32.58" = zext i1 1 to i32
  %"isetrp_src_to_i1.58" = icmp ne i32 %"isetrp_src_to_i32.58", 0
  %"isetrp_cmp2.58" = and i1 %"isetrp_cmp1.58", %"isetrp_src_to_i1.58"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.58" to i32
  br label %"BB_2bd0"
BB_2bd0:
  %"cond_trunc.54" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.54" = zext i1 %"cond_trunc.54" to i32
  %"pbra_cond_to_i1.54" = icmp ne i32 %"pbra_cond_to_i32.54", 0
  br i1 %"pbra_cond_to_i1.54", label %"BB_2cb0_2ff0", label %"BB_2be0"
BB_2be0:
  %"activemask.3" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.3" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.3" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.3", i1 0)
  %"flo.3" = sub i32 31, %"flo_clz.3"
  %".1358" = xor i32 0, -1
  %".1359" = xor i32 %".1324", -1
  %".1360" = xor i32 0, -1
  %".1361" = and i32 %".1358", %".1359"
  %".1362" = and i32 %".1361", %".1360"
  %".1363" = and i32 %".1358", %".1359"
  %".1364" = and i32 %".1363", 0
  %".1365" = or i32 %".1362", %".1364"
  %".1366" = and i32 0, %".1359"
  %".1367" = and i32 %".1366", %".1360"
  %".1368" = or i32 %".1365", %".1367"
  %".1369" = and i32 0, %".1359"
  %".1370" = and i32 %".1369", 0
  %".1371" = or i32 %".1368", %".1370"
  %"imad_tmp.53" = mul i32 0, 0
  %"imad.56" = add i32 %"imad_tmp.53", %".1371"
  %"redux_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.3" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.56", i32 %"redux_mask.3")
  %".1372" = xor i32 %".1371", -1
  %".1373" = call i32 @"llvm.cttz.i32"(i32 %".1372", i1 0)
  %".1374" = shl i32 %".1373", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".1374") convergent
  %"isetrp_cmp1.59" = icmp eq i32 %"laneid.3", %"flo.3"
  %"isetrp_src_to_i32.59" = zext i1 1 to i32
  %"isetrp_src_to_i1.59" = icmp ne i32 %"isetrp_src_to_i32.59", 0
  %"isetrp_cmp2.59" = and i1 %"isetrp_cmp1.59", %"isetrp_src_to_i1.59"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.59" to i32
  %"imad_tmp.54" = mul i32 0, 0
  %"imad.57" = add i32 %"imad_tmp.54", %"redux_sync_and.3"
  br label %"BB_2c80"
BB_2c80:
  %"cond_trunc.55" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.55" = zext i1 %"cond_trunc.55" to i32
  %"pbra_cond_to_i1.55" = icmp ne i32 %"pbra_cond_to_i32.55", 0
  br i1 %"pbra_cond_to_i1.55", label %"BB_80002c80", label %"BB_2cf0"
BB_80002c80:
  %"atoms_shared_addr_winoff.8" = and i32 %".1283", 16777215
  %".1378" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.8"
  %"atoms_ptr.8" = bitcast i8 addrspace(3)* %".1378" to i32 addrspace(3)*
  %"atoms_and.3" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.8", i32 %"imad.57" monotonic
  br label %"BB_2cf0"
BB_2cb0_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2cf0"
BB_2ce0_3050:
  call void @"llvm.trap"()
  br label %"BB_2cf0"
BB_2cf0:
  %"s2ur_cluster_ctarank.4" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.55" = mul i32 0, 0
  %"imad.58" = add i32 %"imad_tmp.55", 255
  %"imad_tmp.56" = mul i32 0, 0
  %"imad.59" = add i32 %"imad_tmp.56", 1
  %".1382" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".1383" = zext i32 1024 to i64
  %".1384" = zext i32 24 to i64
  %".1385" = shl i64 %".1382", %".1384"
  %".1386" = and i64 %".1385", 4294967295
  %".1387" = add i64 %".1386", %".1383"
  %".1388" = trunc i64 %".1387" to i32
  %"lds_addr_memaddr_offset_add.8" = add i32 %".1388", 2072
  %"lds_shared_addr_winoff.17" = and i32 %"lds_addr_memaddr_offset_add.8", 16777215
  %".1389" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.17"
  %"lds_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".1389" to i32 addrspace(3)*
  %"lds.17" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.12"
  %".1390" = zext i32 %"s2ur_cluster_ctarank.4" to i64
  %".1391" = zext i32 80 to i64
  %".1392" = zext i32 24 to i64
  %".1393" = shl i64 %".1390", %".1392"
  %".1394" = and i64 %".1393", 4294967295
  %".1395" = add i64 %".1394", %".1391"
  %".1396" = trunc i64 %".1395" to i32
  %"lds_shared_addr_winoff.18" = and i32 %".1396", 16777215
  %".1397" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.18"
  %"lds_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".1397" to i32 addrspace(3)*
  %"lds.18" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.13"
  %".1398" = xor i32 %"lds.17", -1
  %".1399" = xor i32 65535, -1
  %".1400" = xor i32 0, -1
  %".1401" = and i32 %"lds.17", 65535
  %".1402" = and i32 %".1401", %".1400"
  %".1403" = and i32 %"lds.17", 65535
  %".1404" = and i32 %".1403", 0
  %".1405" = or i32 %".1402", %".1404"
  %".1406" = zext i32 0 to i64
  %".1407" = zext i32 %".1405" to i64
  %".1408" = shl i64 %".1407", 32
  %"shf_concat.34" = or i64 %".1406", %".1408"
  %"shf_shift_64.34" = zext i32 5 to i64
  %".1409" = lshr i64 %"shf_concat.34", %"shf_shift_64.34"
  %"shf_hi.14" = lshr i64 %".1409", 32
  %"shf_result.34" = trunc i64 %"shf_hi.14" to i32
  %"viadd.15" = add i32 %"shf_result.34", 16
  %".1410" = zext i32 %"imad.58" to i64
  %".1411" = zext i32 0 to i64
  %".1412" = shl i64 %".1411", 32
  %"shf_concat.35" = or i64 %".1410", %".1412"
  %"shf_shift_64.35" = zext i32 %"shf_result.34" to i64
  %".1413" = shl i64 %"shf_concat.35", %"shf_shift_64.35"
  %"shf_result.35" = trunc i64 %".1413" to i32
  %".1414" = zext i32 %"imad.59" to i64
  %".1415" = zext i32 0 to i64
  %".1416" = shl i64 %".1415", 32
  %"shf_concat.36" = or i64 %".1414", %".1416"
  %"shf_shift_64.36" = zext i32 %"viadd.15" to i64
  %".1417" = shl i64 %"shf_concat.36", %"shf_shift_64.36"
  %"shf_result.36" = trunc i64 %".1417" to i32
  %".1418" = xor i32 %"shf_result.36", -1
  %".1419" = xor i32 %"shf_result.35", -1
  %".1420" = xor i32 0, -1
  %".1421" = and i32 %".1418", %"shf_result.35"
  %".1422" = and i32 %".1421", %".1420"
  %".1423" = and i32 %".1418", %"shf_result.35"
  %".1424" = and i32 %".1423", 0
  %".1425" = or i32 %".1422", %".1424"
  %".1426" = and i32 %"shf_result.36", %".1419"
  %".1427" = and i32 %".1426", %".1420"
  %".1428" = or i32 %".1425", %".1427"
  %".1429" = and i32 %"shf_result.36", %".1419"
  %".1430" = and i32 %".1429", 0
  %".1431" = or i32 %".1428", %".1430"
  %".1432" = and i32 %"shf_result.36", %"shf_result.35"
  %".1433" = and i32 %".1432", %".1420"
  %".1434" = or i32 %".1431", %".1433"
  %".1435" = and i32 %"shf_result.36", %"shf_result.35"
  %".1436" = and i32 %".1435", 0
  %".1437" = or i32 %".1434", %".1436"
  %".1438" = xor i32 %".1437", -1
  %".1439" = xor i32 65535, -1
  %".1440" = xor i32 0, -1
  %".1441" = and i32 %".1437", 65535
  %".1442" = and i32 %".1441", %".1440"
  %".1443" = and i32 %".1437", 65535
  %".1444" = and i32 %".1443", 0
  %".1445" = or i32 %".1442", %".1444"
  %".1446" = xor i32 %".1437", -1
  %".1447" = xor i32 65535, -1
  %".1448" = xor i32 %"lds.18", -1
  %".1449" = and i32 %".1437", 65535
  %".1450" = and i32 %".1449", %"lds.18"
  %"isetrp_cmp1.60" = icmp ne i32 %".1450", %".1445"
  %"isetrp_src_to_i32.60" = zext i1 1 to i32
  %"isetrp_src_to_i1.60" = icmp ne i32 %"isetrp_src_to_i32.60", 0
  %"isetrp_cmp2.60" = and i1 %"isetrp_cmp1.60", %"isetrp_src_to_i1.60"
  %"P33_to_i32" = zext i1 %"isetrp_cmp2.60" to i32
  br label %"BB_2e30"
BB_2e30:
  %"cond_trunc.56" = trunc i32 %"P33_to_i32" to i1
  %"pbra_cond_to_i32.56" = zext i1 %"cond_trunc.56" to i32
  %"pbra_cond_to_i1.56" = icmp ne i32 %"pbra_cond_to_i32.56", 0
  br i1 %"pbra_cond_to_i1.56", label %"BB_2f90_3050", label %"BB_2e40"
BB_2e40:
  %".1453" = zext i32 0 to i64
  %".1454" = zext i32 %"lds.18" to i64
  %".1455" = shl i64 %".1454", 32
  %"shf_concat.37" = or i64 %".1453", %".1455"
  %"shf_shift_64.37" = zext i32 16 to i64
  %".1456" = lshr i64 %"shf_concat.37", %"shf_shift_64.37"
  %"shf_hi.15" = lshr i64 %".1456", 32
  %"shf_result.37" = trunc i64 %"shf_hi.15" to i32
  %".1457" = zext i32 0 to i64
  %".1458" = zext i32 %".1437" to i64
  %".1459" = shl i64 %".1458", 32
  %"shf_concat.38" = or i64 %".1457", %".1459"
  %"shf_shift_64.38" = zext i32 16 to i64
  %".1460" = lshr i64 %"shf_concat.38", %"shf_shift_64.38"
  %"shf_hi.16" = lshr i64 %".1460", 32
  %"shf_result.38" = trunc i64 %"shf_hi.16" to i32
  %".1461" = xor i32 %"shf_result.37", -1
  %".1462" = xor i32 %"shf_result.38", -1
  %".1463" = xor i32 0, -1
  %".1464" = and i32 %"shf_result.37", %"shf_result.38"
  %".1465" = and i32 %".1464", %".1463"
  %".1466" = and i32 %"shf_result.37", %"shf_result.38"
  %".1467" = and i32 %".1466", 0
  %".1468" = or i32 %".1465", %".1467"
  %"isetrp_cmp1.61" = icmp ne i32 %".1468", %"shf_result.38"
  %"isetrp_src_to_i32.61" = zext i1 1 to i32
  %"isetrp_src_to_i1.61" = icmp ne i32 %"isetrp_src_to_i32.61", 0
  %"isetrp_cmp2.61" = and i1 %"isetrp_cmp1.61", %"isetrp_src_to_i1.61"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.61" to i32
  br label %"BB_2e80"
BB_2e80:
  %"cond_trunc.57" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.57" = zext i1 %"cond_trunc.57" to i32
  %"pbra_cond_to_i1.57" = icmp ne i32 %"pbra_cond_to_i32.57", 0
  br i1 %"pbra_cond_to_i1.57", label %"BB_2f60_2ff0", label %"BB_2e90"
BB_2e90:
  %"activemask.4" = call i32 @"llvm.nvvm.activemask"()
  %"laneid.4" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz.4" = call i32 @"llvm.ctlz.i32"(i32 %"activemask.4", i1 0)
  %"flo.4" = sub i32 31, %"flo_clz.4"
  %".1471" = xor i32 0, -1
  %".1472" = xor i32 %".1437", -1
  %".1473" = xor i32 0, -1
  %".1474" = and i32 %".1471", %".1472"
  %".1475" = and i32 %".1474", %".1473"
  %".1476" = and i32 %".1471", %".1472"
  %".1477" = and i32 %".1476", 0
  %".1478" = or i32 %".1475", %".1477"
  %".1479" = and i32 0, %".1472"
  %".1480" = and i32 %".1479", %".1473"
  %".1481" = or i32 %".1478", %".1480"
  %".1482" = and i32 0, %".1472"
  %".1483" = and i32 %".1482", 0
  %".1484" = or i32 %".1481", %".1483"
  %"imad_tmp.57" = mul i32 0, 0
  %"imad.60" = add i32 %"imad_tmp.57", %".1484"
  %"redux_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.4" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.60", i32 %"redux_mask.4")
  %".1485" = xor i32 %".1484", -1
  %".1486" = call i32 @"llvm.cttz.i32"(i32 %".1485", i1 0)
  %".1487" = shl i32 %".1486", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 256;", "r,~{memory}"(i32 %".1487") convergent
  %"isetrp_cmp1.62" = icmp eq i32 %"laneid.4", %"flo.4"
  %"isetrp_src_to_i32.62" = zext i1 1 to i32
  %"isetrp_src_to_i1.62" = icmp ne i32 %"isetrp_src_to_i32.62", 0
  %"isetrp_cmp2.62" = and i1 %"isetrp_cmp1.62", %"isetrp_src_to_i1.62"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.62" to i32
  %"imad_tmp.58" = mul i32 0, 0
  %"imad.61" = add i32 %"imad_tmp.58", %"redux_sync_and.4"
  br label %"BB_2f30"
BB_2f30:
  %"cond_trunc.58" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.58" = zext i1 %"cond_trunc.58" to i32
  %"pbra_cond_to_i1.58" = icmp ne i32 %"pbra_cond_to_i32.58", 0
  br i1 %"pbra_cond_to_i1.58", label %"BB_80002f30", label %"BB_2fa0"
BB_80002f30:
  %"atoms_shared_addr_winoff.9" = and i32 %".1396", 16777215
  %".1491" = getelementptr inbounds [3104 x i8], [3104 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.9"
  %"atoms_ptr.9" = bitcast i8 addrspace(3)* %".1491" to i32 addrspace(3)*
  %"atoms_and.4" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.9", i32 %"imad.61" monotonic
  br label %"BB_2fa0"
BB_2f60_2ff0:
  call void @"llvm.trap"()
  br label %"BB_2fa0"
BB_2f90_3050:
  call void @"llvm.trap"()
  br label %"BB_2fa0"
BB_2fa0:
  ret void
BB_80002280:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
