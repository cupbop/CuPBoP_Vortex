; ModuleID = "tcgen05_tmem_a_sm100a_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [10256 x i8], align 16
define void @"_Z8mma_caseILj1188EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R145:R118_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R145:R118_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P28_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P47_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P27_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P29_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R136:R90_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R136:R90_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P27_to_i32", %"BB_01a0"], [%"P30_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P47_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P37_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P47_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P38_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P38_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P8_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P39_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P39_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P10_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P10_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P40_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P40_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P3_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P3_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0f60"
BB_05f0_0f60:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".173" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".174" = bitcast i8* %".173" to i64*
  %"ldc_const.1" = load i64, i64* %".174"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 2
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R99:R77_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R99:R77_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R99:R77_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R99:R77_addr_ptr.1"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".175" = xor i32 %"imad.11", -1
  %".176" = xor i32 65011712, -1
  %".177" = xor i32 0, -1
  %".178" = and i32 %"imad.11", 65011712
  %".179" = and i32 %".178", %".177"
  %".180" = and i32 %"imad.11", 65011712
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".184" = zext i32 1024 to i64
  %".185" = zext i32 24 to i64
  %".186" = shl i64 %".183", %".185"
  %".187" = and i64 %".186", 4294967295
  %".188" = add i64 %".187", %".184"
  %".189" = trunc i64 %".188" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".190" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".182"
  %"R7:R6_r0" = trunc i64 0 to i32
  %"R7:R6_r1_shift" = lshr i64 0, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"R7:R6_r0", i32 %"R7:R6_r1")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_07b0"
BB_07b0:
  %"cond_trunc.11" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a10", label %"BB_07c0"
BB_07c0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".196" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".196" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".197" = xor i32 %"plop3_a_bit.2", 1
  %".198" = xor i32 %"plop3_b_bit.2", 1
  %".199" = xor i32 %"plop3_c_bit.2", 1
  %".200" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".201" = and i32 %".200", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".201", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".202" = zext i32 0 to i64
  %".203" = zext i32 %".189" to i64
  %".204" = shl i64 %".203", 32
  %"shf_concat.4" = or i64 %".202", %".204"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".205" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".205", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"viadd.5" = add i32 %"lds.1", 16
  %".206" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".207" = zext i32 %"iadd3_n2.3" to i64
  %".208" = zext i32 24 to i64
  %".209" = shl i64 %".206", %".208"
  %".210" = and i64 %".209", 4294967295
  %".211" = add i64 %".210", %".207"
  %".212" = trunc i64 %".211" to i32
  %".213" = xor i32 %"shf_result.4", -1
  %".214" = xor i32 16376, -1
  %".215" = xor i32 0, -1
  %".216" = and i32 %"shf_result.4", 16376
  %".217" = and i32 %".216", %".215"
  %".218" = and i32 %"shf_result.4", 16376
  %".219" = and i32 %".218", 0
  %".220" = or i32 %".217", %".219"
  %".221" = zext i32 0 to i64
  %".222" = zext i32 %".212" to i64
  %".223" = shl i64 %".222", 32
  %"shf_concat.5" = or i64 %".221", %".223"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".224" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".224", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".225" = xor i32 %".220", -1
  %".226" = xor i32 524288, -1
  %".227" = xor i32 0, -1
  %".228" = and i32 %".225", 524288
  %".229" = and i32 %".228", %".227"
  %".230" = and i32 %".225", 524288
  %".231" = and i32 %".230", 0
  %".232" = or i32 %".229", %".231"
  %".233" = and i32 %".220", %".226"
  %".234" = and i32 %".233", %".227"
  %".235" = or i32 %".232", %".234"
  %".236" = and i32 %".220", %".226"
  %".237" = and i32 %".236", 0
  %".238" = or i32 %".235", %".237"
  %".239" = and i32 %".220", 524288
  %".240" = and i32 %".239", %".227"
  %".241" = or i32 %".238", %".240"
  %".242" = and i32 %".220", 524288
  %".243" = and i32 %".242", 0
  %".244" = or i32 %".241", %".243"
  %".245" = xor i32 %"shf_result.5", -1
  %".246" = xor i32 16376, -1
  %".247" = xor i32 0, -1
  %".248" = and i32 %"shf_result.5", 16376
  %".249" = and i32 %".248", %".247"
  %".250" = and i32 %"shf_result.5", 16376
  %".251" = and i32 %".250", 0
  %".252" = or i32 %".249", %".251"
  %".253" = xor i32 %".252", -1
  %".254" = xor i32 524288, -1
  %".255" = xor i32 0, -1
  %".256" = and i32 %".253", 524288
  %".257" = and i32 %".256", %".255"
  %".258" = and i32 %".253", 524288
  %".259" = and i32 %".258", 0
  %".260" = or i32 %".257", %".259"
  %".261" = and i32 %".252", %".254"
  %".262" = and i32 %".261", %".255"
  %".263" = or i32 %".260", %".262"
  %".264" = and i32 %".252", %".254"
  %".265" = and i32 %".264", 0
  %".266" = or i32 %".263", %".265"
  %".267" = and i32 %".252", 524288
  %".268" = and i32 %".267", %".255"
  %".269" = or i32 %".266", %".268"
  %".270" = and i32 %".252", 524288
  %".271" = and i32 %".270", 0
  %".272" = or i32 %".269", %".271"
  %"iadd3_n1.4" = add i32 %"lds.2", 24
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_08a0"
BB_08a0:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_07c0"], [%"P15_to_i32", %"BB_08d0"]
  %"phi.16" = phi  i32 [%"P43_to_i32", %"BB_07c0"], [%"phi.18", %"BB_08d0"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_800008a0", label %"BB_08b0"
BB_800008a0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P33_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_08b0"
BB_08b0:
  %"phi.17" = phi  i32 [%"P33_to_i32", %"BB_800008a0"], [%"phi.15", %"BB_08a0"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.2", 24
  %"copy_desc_r0_ext" = zext i32 %".244" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".276" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".277" = sub i64 %".276", 0
  %".278" = lshr i64 %".277", 4
  %".279" = add i64 %"copy_desc_packed_1", %".278"
  %".280" = and i64 %".279", 16383
  %".281" = and i64 %"copy_desc_packed_1", -16384
  %".282" = or i64 %".281", %".280"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".282")
  br label %"BB_08c0"
BB_08c0:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_800008c0", label %"BB_08d0"
BB_800008c0:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".286" = xor i32 %"plop3_a_bit.3", 1
  %".287" = xor i32 %"plop3_b_bit.3", 1
  %".288" = xor i32 %"plop3_c_bit.3", 1
  %".289" = and i32 %".286", %"plop3_b_bit.3"
  %".290" = and i32 %".289", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".290", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_08d0"
BB_08d0:
  %"phi.18" = phi  i32 [%"P9_to_i32", %"BB_800008c0"], [%"phi.16", %"BB_08c0"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".292" = xor i32 %"plop3_a_bit.4", 1
  %".293" = xor i32 %"plop3_b_bit.4", 1
  %".294" = xor i32 %"plop3_c_bit.4", 1
  %".295" = and i32 %".292", %"plop3_b_bit.4"
  %".296" = and i32 %".295", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".296", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_08a0", label %"BB_08f0"
BB_08f0:
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".298" = xor i32 %"plop3_a_bit.5", 1
  %".299" = xor i32 %"plop3_b_bit.5", 1
  %".300" = xor i32 %"plop3_c_bit.5", 1
  %".301" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".302" = and i32 %".301", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".302", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.5" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.19" = phi  i32 [%"P15_to_i32", %"BB_08f0"], [%"P20_to_i32", %"BB_0970"]
  %"phi.20" = phi  i32 [%"P36_to_i32", %"BB_08f0"], [%"phi.22", %"BB_0970"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000940", label %"BB_0950"
BB_80000940:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P17_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0950"
BB_0950:
  %"phi.21" = phi  i32 [%"P17_to_i32", %"BB_80000940"], [%"phi.19", %"BB_0940"]
  %"mma_b_r0_ext" = zext i32 %".272" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16416 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".306" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".307" = sub i64 %".306", 0
  %".308" = lshr i64 %".307", 4
  %".309" = add i64 %"mma_b_packed_1", %".308"
  %".310" = and i64 %".309", 16383
  %".311" = and i64 %"mma_b_packed_1", -16384
  %".312" = or i64 %".311", %".310"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.sp.cta_group::1.kind::i8 [$0], [$1], $2, [$5], $3, use_d; } }", "r,r,l,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".312", i32 134481060, i32 %"mma_arg_zext", i32 %"viadd.5")
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".316" = xor i32 %"plop3_a_bit.6", 1
  %".317" = xor i32 %"plop3_b_bit.6", 1
  %".318" = xor i32 %"plop3_c_bit.6", 1
  %".319" = and i32 %".316", %"plop3_b_bit.6"
  %".320" = and i32 %".319", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".320", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.22" = phi  i32 [%"P44_to_i32", %"BB_80000960"], [%"phi.20", %"BB_0960"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".322" = xor i32 %"plop3_a_bit.7", 1
  %".323" = xor i32 %"plop3_b_bit.7", 1
  %".324" = xor i32 %"plop3_c_bit.7", 1
  %".325" = and i32 %".322", %"plop3_b_bit.7"
  %".326" = and i32 %".325", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".326", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0940", label %"BB_0990"
BB_0990:
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".328" = xor i32 %"plop3_a_bit.8", 1
  %".329" = xor i32 %"plop3_b_bit.8", 1
  %".330" = xor i32 %"plop3_c_bit.8", 1
  %".331" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".332" = and i32 %".331", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".332", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".333" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".334" = zext i32 %"iadd3_n2.5" to i64
  %".335" = zext i32 24 to i64
  %".336" = shl i64 %".333", %".335"
  %".337" = and i64 %".336", 4294967295
  %".338" = add i64 %".337", %".334"
  %".339" = trunc i64 %".338" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.23" = phi  i32 [%"P20_to_i32", %"BB_0990"], [%"P25_to_i32", %"BB_09f0"]
  %"phi.24" = phi  i32 [%"P1_to_i32", %"BB_0990"], [%"phi.26", %"BB_09f0"]
  %"cond_trunc.16" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800009c0", label %"BB_09d0"
BB_800009c0:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P22_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_09d0"
BB_09d0:
  %"phi.25" = phi  i32 [%"P22_to_i32", %"BB_800009c0"], [%"phi.23", %"BB_09c0"]
  %"utcbar_local_winoff" = and i32 %".339", 16777215
  %".343" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".344" = ptrtoint i8 addrspace(3)* %".343" to i32
  %".345" = lshr i32 %".339", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".344", i32 %".345")
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.17" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".349" = xor i32 %"plop3_a_bit.9", 1
  %".350" = xor i32 %"plop3_b_bit.9", 1
  %".351" = xor i32 %"plop3_c_bit.9", 1
  %".352" = and i32 %".349", %"plop3_b_bit.9"
  %".353" = and i32 %".352", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".353", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.26" = phi  i32 [%"P23_to_i32", %"BB_800009e0"], [%"phi.24", %"BB_09e0"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".355" = xor i32 %"plop3_a_bit.10", 1
  %".356" = xor i32 %"plop3_b_bit.10", 1
  %".357" = xor i32 %"plop3_c_bit.10", 1
  %".358" = and i32 %".355", %"plop3_b_bit.10"
  %".359" = and i32 %".358", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".359", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_09c0", label %"BB_0a10"
BB_0a10:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %".361" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".362" = zext i32 %"iadd3_n2.6" to i64
  %".363" = zext i32 24 to i64
  %".364" = shl i64 %".361", %".363"
  %".365" = and i64 %".364", 4294967295
  %".366" = add i64 %".365", %".362"
  %".367" = trunc i64 %".366" to i32
  %"mbar_shared_winoff.1" = and i32 %".367", 16777215
  %".368" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".368" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P45_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.18" = trunc i32 %"P45_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0f00", label %"BB_0a70"
BB_0f00:
  %"mbar_shared_winoff.2" = and i32 %".367", 16777215
  %".371" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".371" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P48_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.19" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0f00", label %"BB_0a70"
BB_0a70:
  %".374" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".375" = bitcast i8* %".374" to i64*
  %"ldc_const.2" = load i64, i64* %".375"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P50_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".379" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".380" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".381" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".382" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".383" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R102:R81_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R102:R81_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R102:R81_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R102:R81_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R102:R81_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R102:R81_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R102:R81_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".379", i32 addrspace(1)* %"R102:R81_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R102:R81_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".380", i32 addrspace(1)* %"R102:R81_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".389" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".390" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".391" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".392" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R102:R81_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".381", i32 addrspace(1)* %"R102:R81_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R102:R81_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".382", i32 addrspace(1)* %"R102:R81_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R102:R81_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".383", i32 addrspace(1)* %"R102:R81_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".396" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".397" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".398" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".399" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R102:R81_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".389", i32 addrspace(1)* %"R102:R81_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R102:R81_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".390", i32 addrspace(1)* %"R102:R81_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R102:R81_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".391", i32 addrspace(1)* %"R102:R81_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R102:R81_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".392", i32 addrspace(1)* %"R102:R81_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R102:R81_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".396", i32 addrspace(1)* %"R102:R81_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R102:R81_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".397", i32 addrspace(1)* %"R102:R81_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R102:R81_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".398", i32 addrspace(1)* %"R102:R81_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R102:R81_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".399", i32 addrspace(1)* %"R102:R81_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c70"
BB_0c70:
  %"cond_trunc.20" = trunc i32 %"P50_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000c70", label %"BB_0c80"
BB_0c80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".410" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".410" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".411" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".412" = zext i32 80 to i64
  %".413" = zext i32 24 to i64
  %".414" = shl i64 %".411", %".413"
  %".415" = and i64 %".414", 4294967295
  %".416" = add i64 %".415", %".412"
  %".417" = trunc i64 %".416" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".417", 16777215
  %".418" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".418" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".419" = xor i32 %"lds.3", -1
  %".420" = xor i32 65535, -1
  %".421" = xor i32 0, -1
  %".422" = and i32 %"lds.3", 65535
  %".423" = and i32 %".422", %".421"
  %".424" = and i32 %"lds.3", 65535
  %".425" = and i32 %".424", 0
  %".426" = or i32 %".423", %".425"
  %".427" = zext i32 0 to i64
  %".428" = zext i32 %".426" to i64
  %".429" = shl i64 %".428", 32
  %"shf_concat.6" = or i64 %".427", %".429"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".430" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".430", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.6" = add i32 %"shf_result.6", 16
  %".431" = zext i32 %"imad.15" to i64
  %".432" = zext i32 0 to i64
  %".433" = shl i64 %".432", 32
  %"shf_concat.7" = or i64 %".431", %".433"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".434" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".434" to i32
  %".435" = zext i32 %"imad.15" to i64
  %".436" = zext i32 0 to i64
  %".437" = shl i64 %".436", 32
  %"shf_concat.8" = or i64 %".435", %".437"
  %"shf_shift_64.8" = zext i32 %"viadd.6" to i64
  %".438" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".438" to i32
  %".439" = xor i32 %"shf_result.8", -1
  %".440" = xor i32 %"shf_result.7", -1
  %".441" = xor i32 0, -1
  %".442" = and i32 %".439", %"shf_result.7"
  %".443" = and i32 %".442", %".441"
  %".444" = and i32 %".439", %"shf_result.7"
  %".445" = and i32 %".444", 0
  %".446" = or i32 %".443", %".445"
  %".447" = and i32 %"shf_result.8", %".440"
  %".448" = and i32 %".447", %".441"
  %".449" = or i32 %".446", %".448"
  %".450" = and i32 %"shf_result.8", %".440"
  %".451" = and i32 %".450", 0
  %".452" = or i32 %".449", %".451"
  %".453" = and i32 %"shf_result.8", %"shf_result.7"
  %".454" = and i32 %".453", %".441"
  %".455" = or i32 %".452", %".454"
  %".456" = and i32 %"shf_result.8", %"shf_result.7"
  %".457" = and i32 %".456", 0
  %".458" = or i32 %".455", %".457"
  %".459" = xor i32 %".458", -1
  %".460" = xor i32 65535, -1
  %".461" = xor i32 0, -1
  %".462" = and i32 %".458", 65535
  %".463" = and i32 %".462", %".461"
  %".464" = and i32 %".458", 65535
  %".465" = and i32 %".464", 0
  %".466" = or i32 %".463", %".465"
  %".467" = xor i32 %".458", -1
  %".468" = xor i32 65535, -1
  %".469" = xor i32 %"lds.4", -1
  %".470" = and i32 %".458", 65535
  %".471" = and i32 %".470", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".471", %".466"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0d70"
BB_0d70:
  %"cond_trunc.21" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0ed0_0f90", label %"BB_0d80"
BB_0d80:
  %".474" = zext i32 0 to i64
  %".475" = zext i32 %"lds.4" to i64
  %".476" = shl i64 %".475", 32
  %"shf_concat.9" = or i64 %".474", %".476"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".477" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".477", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".478" = zext i32 0 to i64
  %".479" = zext i32 %".458" to i64
  %".480" = shl i64 %".479", 32
  %"shf_concat.10" = or i64 %".478", %".480"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".481" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".481", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".482" = xor i32 %"shf_result.9", -1
  %".483" = xor i32 %"shf_result.10", -1
  %".484" = xor i32 0, -1
  %".485" = and i32 %"shf_result.9", %"shf_result.10"
  %".486" = and i32 %".485", %".484"
  %".487" = and i32 %"shf_result.9", %"shf_result.10"
  %".488" = and i32 %".487", 0
  %".489" = or i32 %".486", %".488"
  %"isetrp_cmp1.11" = icmp ne i32 %".489", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.22" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0ea0_0f30", label %"BB_0dd0"
BB_0dd0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".492" = xor i32 0, -1
  %".493" = xor i32 %".458", -1
  %".494" = xor i32 0, -1
  %".495" = and i32 %".492", %".493"
  %".496" = and i32 %".495", %".494"
  %".497" = and i32 %".492", %".493"
  %".498" = and i32 %".497", 0
  %".499" = or i32 %".496", %".498"
  %".500" = and i32 0, %".493"
  %".501" = and i32 %".500", %".494"
  %".502" = or i32 %".499", %".501"
  %".503" = and i32 0, %".493"
  %".504" = and i32 %".503", 0
  %".505" = or i32 %".502", %".504"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".505"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask")
  %".506" = xor i32 %".505", -1
  %".507" = call i32 @"llvm.cttz.i32"(i32 %".506", i1 0)
  %".508" = shl i32 %".507", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".508") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.23" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000e70", label %"BB_0ee0"
BB_80000e70:
  %"atoms_shared_addr_winoff.1" = and i32 %".417", 16777215
  %".512" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".512" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.17" monotonic
  br label %"BB_0ee0"
BB_0ea0_0f30:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ed0_0f90:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ee0:
  ret void
BB_80000c70:
  ret void
}

define void @"_Z8mma_caseILj74896EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R110:R91_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R110:R91_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P28_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P47_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P27_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P29_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R67:R64_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R64_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P27_to_i32", %"BB_01a0"], [%"P30_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P47_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P37_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P47_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P38_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P38_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P8_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P39_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P39_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P10_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P10_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P40_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P40_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P3_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P3_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0ec0"
BB_05f0_0ec0:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %".173" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".174" = zext i32 1024 to i64
  %".175" = zext i32 24 to i64
  %".176" = shl i64 %".173", %".175"
  %".177" = and i64 %".176", 4294967295
  %".178" = add i64 %".177", %".174"
  %".179" = trunc i64 %".178" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".180" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".180" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.11" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0940", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".184" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".184" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".185" = xor i32 %"plop3_a_bit.2", 1
  %".186" = xor i32 %"plop3_b_bit.2", 1
  %".187" = xor i32 %"plop3_c_bit.2", 1
  %".188" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".189" = and i32 %".188", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".189", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".190" = zext i32 0 to i64
  %".191" = zext i32 %".179" to i64
  %".192" = shl i64 %".191", 32
  %"shf_concat.4" = or i64 %".190", %".192"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".193" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".193", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".194" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".195" = zext i32 %"iadd3_n2.3" to i64
  %".196" = zext i32 24 to i64
  %".197" = shl i64 %".194", %".196"
  %".198" = and i64 %".197", 4294967295
  %".199" = add i64 %".198", %".195"
  %".200" = trunc i64 %".199" to i32
  %".201" = xor i32 %"shf_result.4", -1
  %".202" = xor i32 16376, -1
  %".203" = xor i32 0, -1
  %".204" = and i32 %"shf_result.4", 16376
  %".205" = and i32 %".204", %".203"
  %".206" = and i32 %"shf_result.4", 16376
  %".207" = and i32 %".206", 0
  %".208" = or i32 %".205", %".207"
  %".209" = zext i32 0 to i64
  %".210" = zext i32 %".200" to i64
  %".211" = shl i64 %".210", 32
  %"shf_concat.5" = or i64 %".209", %".211"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".212" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".212", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".213" = xor i32 %".208", -1
  %".214" = xor i32 524288, -1
  %".215" = xor i32 0, -1
  %".216" = and i32 %".213", 524288
  %".217" = and i32 %".216", %".215"
  %".218" = and i32 %".213", 524288
  %".219" = and i32 %".218", 0
  %".220" = or i32 %".217", %".219"
  %".221" = and i32 %".208", %".214"
  %".222" = and i32 %".221", %".215"
  %".223" = or i32 %".220", %".222"
  %".224" = and i32 %".208", %".214"
  %".225" = and i32 %".224", 0
  %".226" = or i32 %".223", %".225"
  %".227" = and i32 %".208", 524288
  %".228" = and i32 %".227", %".215"
  %".229" = or i32 %".226", %".228"
  %".230" = and i32 %".208", 524288
  %".231" = and i32 %".230", 0
  %".232" = or i32 %".229", %".231"
  %".233" = xor i32 %"shf_result.5", -1
  %".234" = xor i32 16376, -1
  %".235" = xor i32 0, -1
  %".236" = and i32 %"shf_result.5", 16376
  %".237" = and i32 %".236", %".235"
  %".238" = and i32 %"shf_result.5", 16376
  %".239" = and i32 %".238", 0
  %".240" = or i32 %".237", %".239"
  %".241" = xor i32 %".240", -1
  %".242" = xor i32 1048576, -1
  %".243" = xor i32 0, -1
  %".244" = and i32 %".241", 1048576
  %".245" = and i32 %".244", %".243"
  %".246" = and i32 %".241", 1048576
  %".247" = and i32 %".246", 0
  %".248" = or i32 %".245", %".247"
  %".249" = and i32 %".240", %".242"
  %".250" = and i32 %".249", %".243"
  %".251" = or i32 %".248", %".250"
  %".252" = and i32 %".240", %".242"
  %".253" = and i32 %".252", 0
  %".254" = or i32 %".251", %".253"
  %".255" = and i32 %".240", 1048576
  %".256" = and i32 %".255", %".243"
  %".257" = or i32 %".254", %".256"
  %".258" = and i32 %".240", 1048576
  %".259" = and i32 %".258", 0
  %".260" = or i32 %".257", %".259"
  %"iadd3_n1.4" = add i32 %"lds.2", 24
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_07d0"
BB_07d0:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0700"], [%"P15_to_i32", %"BB_0800"]
  %"phi.16" = phi  i32 [%"P43_to_i32", %"BB_0700"], [%"phi.18", %"BB_0800"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_800007d0", label %"BB_07e0"
BB_800007d0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P33_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07e0"
BB_07e0:
  %"phi.17" = phi  i32 [%"P33_to_i32", %"BB_800007d0"], [%"phi.15", %"BB_07d0"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.2", 24
  %"copy_desc_r0_ext" = zext i32 %".232" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".264" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".265" = sub i64 %".264", 0
  %".266" = lshr i64 %".265", 4
  %".267" = add i64 %"copy_desc_packed_1", %".266"
  %".268" = and i64 %".267", 16383
  %".269" = and i64 %"copy_desc_packed_1", -16384
  %".270" = or i64 %".269", %".268"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".270")
  br label %"BB_07f0"
BB_07f0:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_800007f0", label %"BB_0800"
BB_800007f0:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".274" = xor i32 %"plop3_a_bit.3", 1
  %".275" = xor i32 %"plop3_b_bit.3", 1
  %".276" = xor i32 %"plop3_c_bit.3", 1
  %".277" = and i32 %".274", %"plop3_b_bit.3"
  %".278" = and i32 %".277", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".278", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0800"
BB_0800:
  %"phi.18" = phi  i32 [%"P9_to_i32", %"BB_800007f0"], [%"phi.16", %"BB_07f0"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".280" = xor i32 %"plop3_a_bit.4", 1
  %".281" = xor i32 %"plop3_b_bit.4", 1
  %".282" = xor i32 %"plop3_c_bit.4", 1
  %".283" = and i32 %".280", %"plop3_b_bit.4"
  %".284" = and i32 %".283", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".284", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_07d0", label %"BB_0820"
BB_0820:
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".286" = xor i32 %"plop3_a_bit.5", 1
  %".287" = xor i32 %"plop3_b_bit.5", 1
  %".288" = xor i32 %"plop3_c_bit.5", 1
  %".289" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".290" = and i32 %".289", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".290", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.5" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.19" = phi  i32 [%"P15_to_i32", %"BB_0820"], [%"P20_to_i32", %"BB_08a0"]
  %"phi.20" = phi  i32 [%"P36_to_i32", %"BB_0820"], [%"phi.22", %"BB_08a0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000870", label %"BB_0880"
BB_80000870:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P17_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0880"
BB_0880:
  %"phi.21" = phi  i32 [%"P17_to_i32", %"BB_80000870"], [%"phi.19", %"BB_0870"]
  %"mma_b_r0_ext" = zext i32 %".260" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16392 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".294" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".295" = sub i64 %".294", 0
  %".296" = lshr i64 %".295", 4
  %".297" = add i64 %"mma_b_packed_1", %".296"
  %".298" = and i64 %".297", 16383
  %".299" = and i64 %"mma_b_packed_1", -16384
  %".300" = or i64 %".299", %".298"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f16 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".300", i32 134554768, i32 %"mma_arg_zext")
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".304" = xor i32 %"plop3_a_bit.6", 1
  %".305" = xor i32 %"plop3_b_bit.6", 1
  %".306" = xor i32 %"plop3_c_bit.6", 1
  %".307" = and i32 %".304", %"plop3_b_bit.6"
  %".308" = and i32 %".307", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".308", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.22" = phi  i32 [%"P44_to_i32", %"BB_80000890"], [%"phi.20", %"BB_0890"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".310" = xor i32 %"plop3_a_bit.7", 1
  %".311" = xor i32 %"plop3_b_bit.7", 1
  %".312" = xor i32 %"plop3_c_bit.7", 1
  %".313" = and i32 %".310", %"plop3_b_bit.7"
  %".314" = and i32 %".313", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".314", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0870", label %"BB_08c0"
BB_08c0:
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".316" = xor i32 %"plop3_a_bit.8", 1
  %".317" = xor i32 %"plop3_b_bit.8", 1
  %".318" = xor i32 %"plop3_c_bit.8", 1
  %".319" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".320" = and i32 %".319", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".320", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".321" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".322" = zext i32 %"iadd3_n2.5" to i64
  %".323" = zext i32 24 to i64
  %".324" = shl i64 %".321", %".323"
  %".325" = and i64 %".324", 4294967295
  %".326" = add i64 %".325", %".322"
  %".327" = trunc i64 %".326" to i32
  br label %"BB_08f0"
BB_08f0:
  %"phi.23" = phi  i32 [%"P20_to_i32", %"BB_08c0"], [%"P25_to_i32", %"BB_0920"]
  %"phi.24" = phi  i32 [%"P1_to_i32", %"BB_08c0"], [%"phi.26", %"BB_0920"]
  %"cond_trunc.16" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P22_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0900"
BB_0900:
  %"phi.25" = phi  i32 [%"P22_to_i32", %"BB_800008f0"], [%"phi.23", %"BB_08f0"]
  %"utcbar_local_winoff" = and i32 %".327", 16777215
  %".331" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".332" = ptrtoint i8 addrspace(3)* %".331" to i32
  %".333" = lshr i32 %".327", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".332", i32 %".333")
  br label %"BB_0910"
BB_0910:
  %"cond_trunc.17" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"lop3_a_trunc.2" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".337" = xor i32 %"plop3_a_bit.9", 1
  %".338" = xor i32 %"plop3_b_bit.9", 1
  %".339" = xor i32 %"plop3_c_bit.9", 1
  %".340" = and i32 %".337", %"plop3_b_bit.9"
  %".341" = and i32 %".340", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".341", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.26" = phi  i32 [%"P23_to_i32", %"BB_80000910"], [%"phi.24", %"BB_0910"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".343" = xor i32 %"plop3_a_bit.10", 1
  %".344" = xor i32 %"plop3_b_bit.10", 1
  %".345" = xor i32 %"plop3_c_bit.10", 1
  %".346" = and i32 %".343", %"plop3_b_bit.10"
  %".347" = and i32 %".346", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".347", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_08f0", label %"BB_0940"
BB_0940:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"imad_tmp.8" = mul i32 %"tid_x.1", 65536
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %".349" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".350" = zext i32 %"iadd3_n2.6" to i64
  %".351" = zext i32 24 to i64
  %".352" = shl i64 %".349", %".351"
  %".353" = and i64 %".352", 4294967295
  %".354" = add i64 %".353", %".350"
  %".355" = trunc i64 %".354" to i32
  %".356" = xor i32 %"imad.9", -1
  %".357" = xor i32 65011712, -1
  %".358" = xor i32 0, -1
  %".359" = and i32 %"imad.9", 65011712
  %".360" = and i32 %".359", %".358"
  %".361" = and i32 %"imad.9", 65011712
  %".362" = and i32 %".361", 0
  %".363" = or i32 %".360", %".362"
  %"imad_tmp.9" = mul i32 %"lds.1", 1
  %"imad.10" = add i32 %"imad_tmp.9", %".363"
  %"mbar_shared_winoff.1" = and i32 %".355", 16777215
  %".364" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".364" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P45_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_09c0"
BB_09c0:
  %"cond_trunc.18" = trunc i32 %"P45_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0e60", label %"BB_09d0"
BB_0e60:
  %"mbar_shared_winoff.2" = and i32 %".355", 16777215
  %".367" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".367" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P48_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.19" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0e60", label %"BB_09d0"
BB_09d0:
  %".370" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".371" = bitcast i8* %".370" to i64*
  %"ldc_const.1" = load i64, i64* %".371"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x.1", 16
  %"imad.11" = add i32 %"imad_tmp.10", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P50_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.10")
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".373" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.10", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".379" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.11" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.12" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.12" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.12", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R78:R55_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R78:R55_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R78:R55_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".373", i32 addrspace(1)* %"R78:R55_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R78:R55_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R78:R55_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R78:R55_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R78:R55_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R78:R55_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R78:R55_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.10", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".385" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".386" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".387" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".388" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R78:R55_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R78:R55_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R78:R55_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R78:R55_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R78:R55_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".379", i32 addrspace(1)* %"R78:R55_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.10", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".392" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".393" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".394" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".395" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R78:R55_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".385", i32 addrspace(1)* %"R78:R55_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R78:R55_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".386", i32 addrspace(1)* %"R78:R55_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R78:R55_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".387", i32 addrspace(1)* %"R78:R55_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R78:R55_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".388", i32 addrspace(1)* %"R78:R55_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R78:R55_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".392", i32 addrspace(1)* %"R78:R55_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R78:R55_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".393", i32 addrspace(1)* %"R78:R55_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R78:R55_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".394", i32 addrspace(1)* %"R78:R55_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R78:R55_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".395", i32 addrspace(1)* %"R78:R55_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0bd0"
BB_0bd0:
  %"cond_trunc.20" = trunc i32 %"P50_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000bd0", label %"BB_0be0"
BB_0be0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".406" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".406" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 1
  %".407" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".408" = zext i32 80 to i64
  %".409" = zext i32 24 to i64
  %".410" = shl i64 %".407", %".409"
  %".411" = and i64 %".410", 4294967295
  %".412" = add i64 %".411", %".408"
  %".413" = trunc i64 %".412" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".413", 16777215
  %".414" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".414" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".415" = xor i32 %"lds.3", -1
  %".416" = xor i32 65535, -1
  %".417" = xor i32 0, -1
  %".418" = and i32 %"lds.3", 65535
  %".419" = and i32 %".418", %".417"
  %".420" = and i32 %"lds.3", 65535
  %".421" = and i32 %".420", 0
  %".422" = or i32 %".419", %".421"
  %".423" = zext i32 0 to i64
  %".424" = zext i32 %".422" to i64
  %".425" = shl i64 %".424", 32
  %"shf_concat.6" = or i64 %".423", %".425"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".426" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".426", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".427" = zext i32 %"imad.13" to i64
  %".428" = zext i32 0 to i64
  %".429" = shl i64 %".428", 32
  %"shf_concat.7" = or i64 %".427", %".429"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".430" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".430" to i32
  %".431" = zext i32 %"imad.13" to i64
  %".432" = zext i32 0 to i64
  %".433" = shl i64 %".432", 32
  %"shf_concat.8" = or i64 %".431", %".433"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".434" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".434" to i32
  %".435" = xor i32 %"shf_result.8", -1
  %".436" = xor i32 %"shf_result.7", -1
  %".437" = xor i32 0, -1
  %".438" = and i32 %".435", %"shf_result.7"
  %".439" = and i32 %".438", %".437"
  %".440" = and i32 %".435", %"shf_result.7"
  %".441" = and i32 %".440", 0
  %".442" = or i32 %".439", %".441"
  %".443" = and i32 %"shf_result.8", %".436"
  %".444" = and i32 %".443", %".437"
  %".445" = or i32 %".442", %".444"
  %".446" = and i32 %"shf_result.8", %".436"
  %".447" = and i32 %".446", 0
  %".448" = or i32 %".445", %".447"
  %".449" = and i32 %"shf_result.8", %"shf_result.7"
  %".450" = and i32 %".449", %".437"
  %".451" = or i32 %".448", %".450"
  %".452" = and i32 %"shf_result.8", %"shf_result.7"
  %".453" = and i32 %".452", 0
  %".454" = or i32 %".451", %".453"
  %".455" = xor i32 %".454", -1
  %".456" = xor i32 65535, -1
  %".457" = xor i32 0, -1
  %".458" = and i32 %".454", 65535
  %".459" = and i32 %".458", %".457"
  %".460" = and i32 %".454", 65535
  %".461" = and i32 %".460", 0
  %".462" = or i32 %".459", %".461"
  %".463" = xor i32 %".454", -1
  %".464" = xor i32 65535, -1
  %".465" = xor i32 %"lds.4", -1
  %".466" = and i32 %".454", 65535
  %".467" = and i32 %".466", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".467", %".462"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0cd0"
BB_0cd0:
  %"cond_trunc.21" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0e30_0ef0", label %"BB_0ce0"
BB_0ce0:
  %".470" = zext i32 0 to i64
  %".471" = zext i32 %"lds.4" to i64
  %".472" = shl i64 %".471", 32
  %"shf_concat.9" = or i64 %".470", %".472"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".473" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".473", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".474" = zext i32 0 to i64
  %".475" = zext i32 %".454" to i64
  %".476" = shl i64 %".475", 32
  %"shf_concat.10" = or i64 %".474", %".476"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".477" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".477", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".478" = xor i32 %"shf_result.9", -1
  %".479" = xor i32 %"shf_result.10", -1
  %".480" = xor i32 0, -1
  %".481" = and i32 %"shf_result.9", %"shf_result.10"
  %".482" = and i32 %".481", %".480"
  %".483" = and i32 %"shf_result.9", %"shf_result.10"
  %".484" = and i32 %".483", 0
  %".485" = or i32 %".482", %".484"
  %"isetrp_cmp1.11" = icmp ne i32 %".485", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0d20"
BB_0d20:
  %"cond_trunc.22" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0e00_0e90", label %"BB_0d30"
BB_0d30:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".488" = xor i32 0, -1
  %".489" = xor i32 %".454", -1
  %".490" = xor i32 0, -1
  %".491" = and i32 %".488", %".489"
  %".492" = and i32 %".491", %".490"
  %".493" = and i32 %".488", %".489"
  %".494" = and i32 %".493", 0
  %".495" = or i32 %".492", %".494"
  %".496" = and i32 0, %".489"
  %".497" = and i32 %".496", %".490"
  %".498" = or i32 %".495", %".497"
  %".499" = and i32 0, %".489"
  %".500" = and i32 %".499", 0
  %".501" = or i32 %".498", %".500"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", %".501"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.14", i32 %"redux_mask")
  %".502" = xor i32 %".501", -1
  %".503" = call i32 @"llvm.cttz.i32"(i32 %".502", i1 0)
  %".504" = shl i32 %".503", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".504") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0dd0"
BB_0dd0:
  %"cond_trunc.23" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000dd0", label %"BB_0e40"
BB_80000dd0:
  %"atoms_shared_addr_winoff.1" = and i32 %".413", 16777215
  %".508" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".508" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.15" monotonic
  br label %"BB_0e40"
BB_0e00_0e90:
  call void @"llvm.trap"()
  br label %"BB_0e40"
BB_0e30_0ef0:
  call void @"llvm.trap"()
  br label %"BB_0e40"
BB_0e40:
  ret void
BB_80000bd0:
  ret void
}

define void @"_Z8mma_caseILj65696EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R110:R91_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R110:R91_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P28_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P47_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P27_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P29_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R67:R64_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R64_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P27_to_i32", %"BB_01a0"], [%"P30_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P47_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P37_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P47_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P38_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P38_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P8_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P39_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P39_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P10_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P10_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P40_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P40_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P3_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P3_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0ec0"
BB_05f0_0ec0:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %".173" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".174" = zext i32 1024 to i64
  %".175" = zext i32 24 to i64
  %".176" = shl i64 %".173", %".175"
  %".177" = and i64 %".176", 4294967295
  %".178" = add i64 %".177", %".174"
  %".179" = trunc i64 %".178" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".180" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".180" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.11" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0940", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".184" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".184" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".185" = xor i32 %"plop3_a_bit.2", 1
  %".186" = xor i32 %"plop3_b_bit.2", 1
  %".187" = xor i32 %"plop3_c_bit.2", 1
  %".188" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".189" = and i32 %".188", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".189", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".190" = zext i32 0 to i64
  %".191" = zext i32 %".179" to i64
  %".192" = shl i64 %".191", 32
  %"shf_concat.4" = or i64 %".190", %".192"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".193" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".193", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".194" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".195" = zext i32 %"iadd3_n2.3" to i64
  %".196" = zext i32 24 to i64
  %".197" = shl i64 %".194", %".196"
  %".198" = and i64 %".197", 4294967295
  %".199" = add i64 %".198", %".195"
  %".200" = trunc i64 %".199" to i32
  %".201" = xor i32 %"shf_result.4", -1
  %".202" = xor i32 16376, -1
  %".203" = xor i32 0, -1
  %".204" = and i32 %"shf_result.4", 16376
  %".205" = and i32 %".204", %".203"
  %".206" = and i32 %"shf_result.4", 16376
  %".207" = and i32 %".206", 0
  %".208" = or i32 %".205", %".207"
  %".209" = zext i32 0 to i64
  %".210" = zext i32 %".200" to i64
  %".211" = shl i64 %".210", 32
  %"shf_concat.5" = or i64 %".209", %".211"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".212" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".212", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".213" = xor i32 %".208", -1
  %".214" = xor i32 524288, -1
  %".215" = xor i32 0, -1
  %".216" = and i32 %".213", 524288
  %".217" = and i32 %".216", %".215"
  %".218" = and i32 %".213", 524288
  %".219" = and i32 %".218", 0
  %".220" = or i32 %".217", %".219"
  %".221" = and i32 %".208", %".214"
  %".222" = and i32 %".221", %".215"
  %".223" = or i32 %".220", %".222"
  %".224" = and i32 %".208", %".214"
  %".225" = and i32 %".224", 0
  %".226" = or i32 %".223", %".225"
  %".227" = and i32 %".208", 524288
  %".228" = and i32 %".227", %".215"
  %".229" = or i32 %".226", %".228"
  %".230" = and i32 %".208", 524288
  %".231" = and i32 %".230", 0
  %".232" = or i32 %".229", %".231"
  %".233" = xor i32 %"shf_result.5", -1
  %".234" = xor i32 16376, -1
  %".235" = xor i32 0, -1
  %".236" = and i32 %"shf_result.5", 16376
  %".237" = and i32 %".236", %".235"
  %".238" = and i32 %"shf_result.5", 16376
  %".239" = and i32 %".238", 0
  %".240" = or i32 %".237", %".239"
  %".241" = xor i32 %".240", -1
  %".242" = xor i32 524288, -1
  %".243" = xor i32 0, -1
  %".244" = and i32 %".241", 524288
  %".245" = and i32 %".244", %".243"
  %".246" = and i32 %".241", 524288
  %".247" = and i32 %".246", 0
  %".248" = or i32 %".245", %".247"
  %".249" = and i32 %".240", %".242"
  %".250" = and i32 %".249", %".243"
  %".251" = or i32 %".248", %".250"
  %".252" = and i32 %".240", %".242"
  %".253" = and i32 %".252", 0
  %".254" = or i32 %".251", %".253"
  %".255" = and i32 %".240", 524288
  %".256" = and i32 %".255", %".243"
  %".257" = or i32 %".254", %".256"
  %".258" = and i32 %".240", 524288
  %".259" = and i32 %".258", 0
  %".260" = or i32 %".257", %".259"
  %"iadd3_n1.4" = add i32 %"lds.2", 24
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_07d0"
BB_07d0:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0700"], [%"P15_to_i32", %"BB_0800"]
  %"phi.16" = phi  i32 [%"P43_to_i32", %"BB_0700"], [%"phi.18", %"BB_0800"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_800007d0", label %"BB_07e0"
BB_800007d0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P33_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07e0"
BB_07e0:
  %"phi.17" = phi  i32 [%"P33_to_i32", %"BB_800007d0"], [%"phi.15", %"BB_07d0"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.2", 24
  %"copy_desc_r0_ext" = zext i32 %".232" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".264" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".265" = sub i64 %".264", 0
  %".266" = lshr i64 %".265", 4
  %".267" = add i64 %"copy_desc_packed_1", %".266"
  %".268" = and i64 %".267", 16383
  %".269" = and i64 %"copy_desc_packed_1", -16384
  %".270" = or i64 %".269", %".268"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".270")
  br label %"BB_07f0"
BB_07f0:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_800007f0", label %"BB_0800"
BB_800007f0:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".274" = xor i32 %"plop3_a_bit.3", 1
  %".275" = xor i32 %"plop3_b_bit.3", 1
  %".276" = xor i32 %"plop3_c_bit.3", 1
  %".277" = and i32 %".274", %"plop3_b_bit.3"
  %".278" = and i32 %".277", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".278", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0800"
BB_0800:
  %"phi.18" = phi  i32 [%"P9_to_i32", %"BB_800007f0"], [%"phi.16", %"BB_07f0"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".280" = xor i32 %"plop3_a_bit.4", 1
  %".281" = xor i32 %"plop3_b_bit.4", 1
  %".282" = xor i32 %"plop3_c_bit.4", 1
  %".283" = and i32 %".280", %"plop3_b_bit.4"
  %".284" = and i32 %".283", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".284", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_07d0", label %"BB_0820"
BB_0820:
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".286" = xor i32 %"plop3_a_bit.5", 1
  %".287" = xor i32 %"plop3_b_bit.5", 1
  %".288" = xor i32 %"plop3_c_bit.5", 1
  %".289" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".290" = and i32 %".289", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".290", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.5" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.19" = phi  i32 [%"P15_to_i32", %"BB_0820"], [%"P20_to_i32", %"BB_08a0"]
  %"phi.20" = phi  i32 [%"P36_to_i32", %"BB_0820"], [%"phi.22", %"BB_08a0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000870", label %"BB_0880"
BB_80000870:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P17_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0880"
BB_0880:
  %"phi.21" = phi  i32 [%"P17_to_i32", %"BB_80000870"], [%"phi.19", %"BB_0870"]
  %"mma_b_r0_ext" = zext i32 %".260" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16392 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".294" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".295" = sub i64 %".294", 0
  %".296" = lshr i64 %".295", 4
  %".297" = add i64 %"mma_b_packed_1", %".296"
  %".298" = and i64 %".297", 16383
  %".299" = and i64 %"mma_b_packed_1", -16384
  %".300" = or i64 %".299", %".298"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::i8 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".300", i32 134545568, i32 %"mma_arg_zext")
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".304" = xor i32 %"plop3_a_bit.6", 1
  %".305" = xor i32 %"plop3_b_bit.6", 1
  %".306" = xor i32 %"plop3_c_bit.6", 1
  %".307" = and i32 %".304", %"plop3_b_bit.6"
  %".308" = and i32 %".307", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".308", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.22" = phi  i32 [%"P44_to_i32", %"BB_80000890"], [%"phi.20", %"BB_0890"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".310" = xor i32 %"plop3_a_bit.7", 1
  %".311" = xor i32 %"plop3_b_bit.7", 1
  %".312" = xor i32 %"plop3_c_bit.7", 1
  %".313" = and i32 %".310", %"plop3_b_bit.7"
  %".314" = and i32 %".313", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".314", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0870", label %"BB_08c0"
BB_08c0:
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".316" = xor i32 %"plop3_a_bit.8", 1
  %".317" = xor i32 %"plop3_b_bit.8", 1
  %".318" = xor i32 %"plop3_c_bit.8", 1
  %".319" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".320" = and i32 %".319", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".320", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".321" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".322" = zext i32 %"iadd3_n2.5" to i64
  %".323" = zext i32 24 to i64
  %".324" = shl i64 %".321", %".323"
  %".325" = and i64 %".324", 4294967295
  %".326" = add i64 %".325", %".322"
  %".327" = trunc i64 %".326" to i32
  br label %"BB_08f0"
BB_08f0:
  %"phi.23" = phi  i32 [%"P20_to_i32", %"BB_08c0"], [%"P25_to_i32", %"BB_0920"]
  %"phi.24" = phi  i32 [%"P1_to_i32", %"BB_08c0"], [%"phi.26", %"BB_0920"]
  %"cond_trunc.16" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P22_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0900"
BB_0900:
  %"phi.25" = phi  i32 [%"P22_to_i32", %"BB_800008f0"], [%"phi.23", %"BB_08f0"]
  %"utcbar_local_winoff" = and i32 %".327", 16777215
  %".331" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".332" = ptrtoint i8 addrspace(3)* %".331" to i32
  %".333" = lshr i32 %".327", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".332", i32 %".333")
  br label %"BB_0910"
BB_0910:
  %"cond_trunc.17" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"lop3_a_trunc.2" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".337" = xor i32 %"plop3_a_bit.9", 1
  %".338" = xor i32 %"plop3_b_bit.9", 1
  %".339" = xor i32 %"plop3_c_bit.9", 1
  %".340" = and i32 %".337", %"plop3_b_bit.9"
  %".341" = and i32 %".340", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".341", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.26" = phi  i32 [%"P23_to_i32", %"BB_80000910"], [%"phi.24", %"BB_0910"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".343" = xor i32 %"plop3_a_bit.10", 1
  %".344" = xor i32 %"plop3_b_bit.10", 1
  %".345" = xor i32 %"plop3_c_bit.10", 1
  %".346" = and i32 %".343", %"plop3_b_bit.10"
  %".347" = and i32 %".346", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".347", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_08f0", label %"BB_0940"
BB_0940:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"imad_tmp.8" = mul i32 %"tid_x.1", 65536
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %".349" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".350" = zext i32 %"iadd3_n2.6" to i64
  %".351" = zext i32 24 to i64
  %".352" = shl i64 %".349", %".351"
  %".353" = and i64 %".352", 4294967295
  %".354" = add i64 %".353", %".350"
  %".355" = trunc i64 %".354" to i32
  %".356" = xor i32 %"imad.9", -1
  %".357" = xor i32 65011712, -1
  %".358" = xor i32 0, -1
  %".359" = and i32 %"imad.9", 65011712
  %".360" = and i32 %".359", %".358"
  %".361" = and i32 %"imad.9", 65011712
  %".362" = and i32 %".361", 0
  %".363" = or i32 %".360", %".362"
  %"imad_tmp.9" = mul i32 %"lds.1", 1
  %"imad.10" = add i32 %"imad_tmp.9", %".363"
  %"mbar_shared_winoff.1" = and i32 %".355", 16777215
  %".364" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".364" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P45_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_09c0"
BB_09c0:
  %"cond_trunc.18" = trunc i32 %"P45_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0e60", label %"BB_09d0"
BB_0e60:
  %"mbar_shared_winoff.2" = and i32 %".355", 16777215
  %".367" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".367" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P48_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.19" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0e60", label %"BB_09d0"
BB_09d0:
  %".370" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".371" = bitcast i8* %".370" to i64*
  %"ldc_const.1" = load i64, i64* %".371"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x.1", 16
  %"imad.11" = add i32 %"imad_tmp.10", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P50_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.10")
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".373" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.10", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".379" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.11" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.12" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.12" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.12", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R78:R55_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R78:R55_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R78:R55_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".373", i32 addrspace(1)* %"R78:R55_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R78:R55_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R78:R55_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R78:R55_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R78:R55_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R78:R55_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R78:R55_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.10", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".385" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".386" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".387" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".388" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R78:R55_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R78:R55_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R78:R55_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R78:R55_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R78:R55_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".379", i32 addrspace(1)* %"R78:R55_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.10", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".392" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".393" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".394" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".395" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R78:R55_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".385", i32 addrspace(1)* %"R78:R55_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R78:R55_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".386", i32 addrspace(1)* %"R78:R55_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R78:R55_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".387", i32 addrspace(1)* %"R78:R55_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R78:R55_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".388", i32 addrspace(1)* %"R78:R55_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R78:R55_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".392", i32 addrspace(1)* %"R78:R55_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R78:R55_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".393", i32 addrspace(1)* %"R78:R55_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R78:R55_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".394", i32 addrspace(1)* %"R78:R55_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R78:R55_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".395", i32 addrspace(1)* %"R78:R55_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0bd0"
BB_0bd0:
  %"cond_trunc.20" = trunc i32 %"P50_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000bd0", label %"BB_0be0"
BB_0be0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".406" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".406" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 1
  %".407" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".408" = zext i32 80 to i64
  %".409" = zext i32 24 to i64
  %".410" = shl i64 %".407", %".409"
  %".411" = and i64 %".410", 4294967295
  %".412" = add i64 %".411", %".408"
  %".413" = trunc i64 %".412" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".413", 16777215
  %".414" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".414" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".415" = xor i32 %"lds.3", -1
  %".416" = xor i32 65535, -1
  %".417" = xor i32 0, -1
  %".418" = and i32 %"lds.3", 65535
  %".419" = and i32 %".418", %".417"
  %".420" = and i32 %"lds.3", 65535
  %".421" = and i32 %".420", 0
  %".422" = or i32 %".419", %".421"
  %".423" = zext i32 0 to i64
  %".424" = zext i32 %".422" to i64
  %".425" = shl i64 %".424", 32
  %"shf_concat.6" = or i64 %".423", %".425"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".426" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".426", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".427" = zext i32 %"imad.13" to i64
  %".428" = zext i32 0 to i64
  %".429" = shl i64 %".428", 32
  %"shf_concat.7" = or i64 %".427", %".429"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".430" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".430" to i32
  %".431" = zext i32 %"imad.13" to i64
  %".432" = zext i32 0 to i64
  %".433" = shl i64 %".432", 32
  %"shf_concat.8" = or i64 %".431", %".433"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".434" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".434" to i32
  %".435" = xor i32 %"shf_result.8", -1
  %".436" = xor i32 %"shf_result.7", -1
  %".437" = xor i32 0, -1
  %".438" = and i32 %".435", %"shf_result.7"
  %".439" = and i32 %".438", %".437"
  %".440" = and i32 %".435", %"shf_result.7"
  %".441" = and i32 %".440", 0
  %".442" = or i32 %".439", %".441"
  %".443" = and i32 %"shf_result.8", %".436"
  %".444" = and i32 %".443", %".437"
  %".445" = or i32 %".442", %".444"
  %".446" = and i32 %"shf_result.8", %".436"
  %".447" = and i32 %".446", 0
  %".448" = or i32 %".445", %".447"
  %".449" = and i32 %"shf_result.8", %"shf_result.7"
  %".450" = and i32 %".449", %".437"
  %".451" = or i32 %".448", %".450"
  %".452" = and i32 %"shf_result.8", %"shf_result.7"
  %".453" = and i32 %".452", 0
  %".454" = or i32 %".451", %".453"
  %".455" = xor i32 %".454", -1
  %".456" = xor i32 65535, -1
  %".457" = xor i32 0, -1
  %".458" = and i32 %".454", 65535
  %".459" = and i32 %".458", %".457"
  %".460" = and i32 %".454", 65535
  %".461" = and i32 %".460", 0
  %".462" = or i32 %".459", %".461"
  %".463" = xor i32 %".454", -1
  %".464" = xor i32 65535, -1
  %".465" = xor i32 %"lds.4", -1
  %".466" = and i32 %".454", 65535
  %".467" = and i32 %".466", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".467", %".462"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0cd0"
BB_0cd0:
  %"cond_trunc.21" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0e30_0ef0", label %"BB_0ce0"
BB_0ce0:
  %".470" = zext i32 0 to i64
  %".471" = zext i32 %"lds.4" to i64
  %".472" = shl i64 %".471", 32
  %"shf_concat.9" = or i64 %".470", %".472"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".473" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".473", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".474" = zext i32 0 to i64
  %".475" = zext i32 %".454" to i64
  %".476" = shl i64 %".475", 32
  %"shf_concat.10" = or i64 %".474", %".476"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".477" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".477", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".478" = xor i32 %"shf_result.9", -1
  %".479" = xor i32 %"shf_result.10", -1
  %".480" = xor i32 0, -1
  %".481" = and i32 %"shf_result.9", %"shf_result.10"
  %".482" = and i32 %".481", %".480"
  %".483" = and i32 %"shf_result.9", %"shf_result.10"
  %".484" = and i32 %".483", 0
  %".485" = or i32 %".482", %".484"
  %"isetrp_cmp1.11" = icmp ne i32 %".485", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0d20"
BB_0d20:
  %"cond_trunc.22" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0e00_0e90", label %"BB_0d30"
BB_0d30:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".488" = xor i32 0, -1
  %".489" = xor i32 %".454", -1
  %".490" = xor i32 0, -1
  %".491" = and i32 %".488", %".489"
  %".492" = and i32 %".491", %".490"
  %".493" = and i32 %".488", %".489"
  %".494" = and i32 %".493", 0
  %".495" = or i32 %".492", %".494"
  %".496" = and i32 0, %".489"
  %".497" = and i32 %".496", %".490"
  %".498" = or i32 %".495", %".497"
  %".499" = and i32 0, %".489"
  %".500" = and i32 %".499", 0
  %".501" = or i32 %".498", %".500"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", %".501"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.14", i32 %"redux_mask")
  %".502" = xor i32 %".501", -1
  %".503" = call i32 @"llvm.cttz.i32"(i32 %".502", i1 0)
  %".504" = shl i32 %".503", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".504") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0dd0"
BB_0dd0:
  %"cond_trunc.23" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000dd0", label %"BB_0e40"
BB_80000dd0:
  %"atoms_shared_addr_winoff.1" = and i32 %".413", 16777215
  %".508" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".508" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.15" monotonic
  br label %"BB_0e40"
BB_0e00_0e90:
  call void @"llvm.trap"()
  br label %"BB_0e40"
BB_0e30_0ef0:
  call void @"llvm.trap"()
  br label %"BB_0e40"
BB_0e40:
  ret void
BB_80000bd0:
  ret void
}

define void @"_Z8mma_caseILj1184EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R110:R91_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R110:R91_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P28_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P47_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P27_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P29_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R67:R64_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R64_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P27_to_i32", %"BB_01a0"], [%"P30_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P47_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P37_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P47_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P38_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P38_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P8_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P39_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P39_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P10_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P10_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P40_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P40_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P3_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P3_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0ec0"
BB_05f0_0ec0:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %".173" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".174" = zext i32 1024 to i64
  %".175" = zext i32 24 to i64
  %".176" = shl i64 %".173", %".175"
  %".177" = and i64 %".176", 4294967295
  %".178" = add i64 %".177", %".174"
  %".179" = trunc i64 %".178" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".180" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".180" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.11" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0940", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".184" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".184" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".185" = xor i32 %"plop3_a_bit.2", 1
  %".186" = xor i32 %"plop3_b_bit.2", 1
  %".187" = xor i32 %"plop3_c_bit.2", 1
  %".188" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".189" = and i32 %".188", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".189", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".190" = zext i32 0 to i64
  %".191" = zext i32 %".179" to i64
  %".192" = shl i64 %".191", 32
  %"shf_concat.4" = or i64 %".190", %".192"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".193" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".193", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".194" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".195" = zext i32 %"iadd3_n2.3" to i64
  %".196" = zext i32 24 to i64
  %".197" = shl i64 %".194", %".196"
  %".198" = and i64 %".197", 4294967295
  %".199" = add i64 %".198", %".195"
  %".200" = trunc i64 %".199" to i32
  %".201" = xor i32 %"shf_result.4", -1
  %".202" = xor i32 16376, -1
  %".203" = xor i32 0, -1
  %".204" = and i32 %"shf_result.4", 16376
  %".205" = and i32 %".204", %".203"
  %".206" = and i32 %"shf_result.4", 16376
  %".207" = and i32 %".206", 0
  %".208" = or i32 %".205", %".207"
  %".209" = zext i32 0 to i64
  %".210" = zext i32 %".200" to i64
  %".211" = shl i64 %".210", 32
  %"shf_concat.5" = or i64 %".209", %".211"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".212" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".212", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".213" = xor i32 %".208", -1
  %".214" = xor i32 524288, -1
  %".215" = xor i32 0, -1
  %".216" = and i32 %".213", 524288
  %".217" = and i32 %".216", %".215"
  %".218" = and i32 %".213", 524288
  %".219" = and i32 %".218", 0
  %".220" = or i32 %".217", %".219"
  %".221" = and i32 %".208", %".214"
  %".222" = and i32 %".221", %".215"
  %".223" = or i32 %".220", %".222"
  %".224" = and i32 %".208", %".214"
  %".225" = and i32 %".224", 0
  %".226" = or i32 %".223", %".225"
  %".227" = and i32 %".208", 524288
  %".228" = and i32 %".227", %".215"
  %".229" = or i32 %".226", %".228"
  %".230" = and i32 %".208", 524288
  %".231" = and i32 %".230", 0
  %".232" = or i32 %".229", %".231"
  %".233" = xor i32 %"shf_result.5", -1
  %".234" = xor i32 16376, -1
  %".235" = xor i32 0, -1
  %".236" = and i32 %"shf_result.5", 16376
  %".237" = and i32 %".236", %".235"
  %".238" = and i32 %"shf_result.5", 16376
  %".239" = and i32 %".238", 0
  %".240" = or i32 %".237", %".239"
  %".241" = xor i32 %".240", -1
  %".242" = xor i32 524288, -1
  %".243" = xor i32 0, -1
  %".244" = and i32 %".241", 524288
  %".245" = and i32 %".244", %".243"
  %".246" = and i32 %".241", 524288
  %".247" = and i32 %".246", 0
  %".248" = or i32 %".245", %".247"
  %".249" = and i32 %".240", %".242"
  %".250" = and i32 %".249", %".243"
  %".251" = or i32 %".248", %".250"
  %".252" = and i32 %".240", %".242"
  %".253" = and i32 %".252", 0
  %".254" = or i32 %".251", %".253"
  %".255" = and i32 %".240", 524288
  %".256" = and i32 %".255", %".243"
  %".257" = or i32 %".254", %".256"
  %".258" = and i32 %".240", 524288
  %".259" = and i32 %".258", 0
  %".260" = or i32 %".257", %".259"
  %"iadd3_n1.4" = add i32 %"lds.2", 24
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_07d0"
BB_07d0:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0700"], [%"P15_to_i32", %"BB_0800"]
  %"phi.16" = phi  i32 [%"P43_to_i32", %"BB_0700"], [%"phi.18", %"BB_0800"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_800007d0", label %"BB_07e0"
BB_800007d0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P33_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07e0"
BB_07e0:
  %"phi.17" = phi  i32 [%"P33_to_i32", %"BB_800007d0"], [%"phi.15", %"BB_07d0"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.2", 24
  %"copy_desc_r0_ext" = zext i32 %".232" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".264" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".265" = sub i64 %".264", 0
  %".266" = lshr i64 %".265", 4
  %".267" = add i64 %"copy_desc_packed_1", %".266"
  %".268" = and i64 %".267", 16383
  %".269" = and i64 %"copy_desc_packed_1", -16384
  %".270" = or i64 %".269", %".268"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".270")
  br label %"BB_07f0"
BB_07f0:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_800007f0", label %"BB_0800"
BB_800007f0:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".274" = xor i32 %"plop3_a_bit.3", 1
  %".275" = xor i32 %"plop3_b_bit.3", 1
  %".276" = xor i32 %"plop3_c_bit.3", 1
  %".277" = and i32 %".274", %"plop3_b_bit.3"
  %".278" = and i32 %".277", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".278", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0800"
BB_0800:
  %"phi.18" = phi  i32 [%"P9_to_i32", %"BB_800007f0"], [%"phi.16", %"BB_07f0"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".280" = xor i32 %"plop3_a_bit.4", 1
  %".281" = xor i32 %"plop3_b_bit.4", 1
  %".282" = xor i32 %"plop3_c_bit.4", 1
  %".283" = and i32 %".280", %"plop3_b_bit.4"
  %".284" = and i32 %".283", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".284", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_07d0", label %"BB_0820"
BB_0820:
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".286" = xor i32 %"plop3_a_bit.5", 1
  %".287" = xor i32 %"plop3_b_bit.5", 1
  %".288" = xor i32 %"plop3_c_bit.5", 1
  %".289" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".290" = and i32 %".289", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".290", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.5" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.19" = phi  i32 [%"P15_to_i32", %"BB_0820"], [%"P20_to_i32", %"BB_08a0"]
  %"phi.20" = phi  i32 [%"P36_to_i32", %"BB_0820"], [%"phi.22", %"BB_08a0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000870", label %"BB_0880"
BB_80000870:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P17_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0880"
BB_0880:
  %"phi.21" = phi  i32 [%"P17_to_i32", %"BB_80000870"], [%"phi.19", %"BB_0870"]
  %"mma_b_r0_ext" = zext i32 %".260" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".294" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".295" = sub i64 %".294", 0
  %".296" = lshr i64 %".295", 4
  %".297" = add i64 %"mma_b_packed_1", %".296"
  %".298" = and i64 %".297", 16383
  %".299" = and i64 %"mma_b_packed_1", -16384
  %".300" = or i64 %".299", %".298"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::i8 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".300", i32 134481056, i32 %"mma_arg_zext")
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".304" = xor i32 %"plop3_a_bit.6", 1
  %".305" = xor i32 %"plop3_b_bit.6", 1
  %".306" = xor i32 %"plop3_c_bit.6", 1
  %".307" = and i32 %".304", %"plop3_b_bit.6"
  %".308" = and i32 %".307", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".308", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.22" = phi  i32 [%"P44_to_i32", %"BB_80000890"], [%"phi.20", %"BB_0890"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".310" = xor i32 %"plop3_a_bit.7", 1
  %".311" = xor i32 %"plop3_b_bit.7", 1
  %".312" = xor i32 %"plop3_c_bit.7", 1
  %".313" = and i32 %".310", %"plop3_b_bit.7"
  %".314" = and i32 %".313", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".314", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0870", label %"BB_08c0"
BB_08c0:
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".316" = xor i32 %"plop3_a_bit.8", 1
  %".317" = xor i32 %"plop3_b_bit.8", 1
  %".318" = xor i32 %"plop3_c_bit.8", 1
  %".319" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".320" = and i32 %".319", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".320", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".321" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".322" = zext i32 %"iadd3_n2.5" to i64
  %".323" = zext i32 24 to i64
  %".324" = shl i64 %".321", %".323"
  %".325" = and i64 %".324", 4294967295
  %".326" = add i64 %".325", %".322"
  %".327" = trunc i64 %".326" to i32
  br label %"BB_08f0"
BB_08f0:
  %"phi.23" = phi  i32 [%"P20_to_i32", %"BB_08c0"], [%"P25_to_i32", %"BB_0920"]
  %"phi.24" = phi  i32 [%"P1_to_i32", %"BB_08c0"], [%"phi.26", %"BB_0920"]
  %"cond_trunc.16" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P22_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0900"
BB_0900:
  %"phi.25" = phi  i32 [%"P22_to_i32", %"BB_800008f0"], [%"phi.23", %"BB_08f0"]
  %"utcbar_local_winoff" = and i32 %".327", 16777215
  %".331" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".332" = ptrtoint i8 addrspace(3)* %".331" to i32
  %".333" = lshr i32 %".327", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".332", i32 %".333")
  br label %"BB_0910"
BB_0910:
  %"cond_trunc.17" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"lop3_a_trunc.2" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".337" = xor i32 %"plop3_a_bit.9", 1
  %".338" = xor i32 %"plop3_b_bit.9", 1
  %".339" = xor i32 %"plop3_c_bit.9", 1
  %".340" = and i32 %".337", %"plop3_b_bit.9"
  %".341" = and i32 %".340", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".341", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.26" = phi  i32 [%"P23_to_i32", %"BB_80000910"], [%"phi.24", %"BB_0910"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".343" = xor i32 %"plop3_a_bit.10", 1
  %".344" = xor i32 %"plop3_b_bit.10", 1
  %".345" = xor i32 %"plop3_c_bit.10", 1
  %".346" = and i32 %".343", %"plop3_b_bit.10"
  %".347" = and i32 %".346", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".347", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_08f0", label %"BB_0940"
BB_0940:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"imad_tmp.8" = mul i32 %"tid_x.1", 65536
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %".349" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".350" = zext i32 %"iadd3_n2.6" to i64
  %".351" = zext i32 24 to i64
  %".352" = shl i64 %".349", %".351"
  %".353" = and i64 %".352", 4294967295
  %".354" = add i64 %".353", %".350"
  %".355" = trunc i64 %".354" to i32
  %".356" = xor i32 %"imad.9", -1
  %".357" = xor i32 65011712, -1
  %".358" = xor i32 0, -1
  %".359" = and i32 %"imad.9", 65011712
  %".360" = and i32 %".359", %".358"
  %".361" = and i32 %"imad.9", 65011712
  %".362" = and i32 %".361", 0
  %".363" = or i32 %".360", %".362"
  %"imad_tmp.9" = mul i32 %"lds.1", 1
  %"imad.10" = add i32 %"imad_tmp.9", %".363"
  %"mbar_shared_winoff.1" = and i32 %".355", 16777215
  %".364" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".364" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P45_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_09c0"
BB_09c0:
  %"cond_trunc.18" = trunc i32 %"P45_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0e60", label %"BB_09d0"
BB_0e60:
  %"mbar_shared_winoff.2" = and i32 %".355", 16777215
  %".367" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".367" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P48_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.19" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0e60", label %"BB_09d0"
BB_09d0:
  %".370" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".371" = bitcast i8* %".370" to i64*
  %"ldc_const.1" = load i64, i64* %".371"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x.1", 16
  %"imad.11" = add i32 %"imad_tmp.10", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P50_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.10")
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".373" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.10", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".379" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.11" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.12" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.12" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.12", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R78:R55_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R78:R55_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R78:R55_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".373", i32 addrspace(1)* %"R78:R55_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R78:R55_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R78:R55_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R78:R55_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R78:R55_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R78:R55_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R78:R55_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.10", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".385" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".386" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".387" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".388" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R78:R55_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R78:R55_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R78:R55_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R78:R55_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R78:R55_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".379", i32 addrspace(1)* %"R78:R55_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.10", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".392" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".393" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".394" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".395" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R78:R55_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".385", i32 addrspace(1)* %"R78:R55_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R78:R55_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".386", i32 addrspace(1)* %"R78:R55_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R78:R55_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".387", i32 addrspace(1)* %"R78:R55_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R78:R55_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".388", i32 addrspace(1)* %"R78:R55_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R78:R55_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".392", i32 addrspace(1)* %"R78:R55_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R78:R55_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".393", i32 addrspace(1)* %"R78:R55_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R78:R55_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".394", i32 addrspace(1)* %"R78:R55_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R78:R55_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".395", i32 addrspace(1)* %"R78:R55_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0bd0"
BB_0bd0:
  %"cond_trunc.20" = trunc i32 %"P50_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000bd0", label %"BB_0be0"
BB_0be0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".406" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".406" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 1
  %".407" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".408" = zext i32 80 to i64
  %".409" = zext i32 24 to i64
  %".410" = shl i64 %".407", %".409"
  %".411" = and i64 %".410", 4294967295
  %".412" = add i64 %".411", %".408"
  %".413" = trunc i64 %".412" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".413", 16777215
  %".414" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".414" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".415" = xor i32 %"lds.3", -1
  %".416" = xor i32 65535, -1
  %".417" = xor i32 0, -1
  %".418" = and i32 %"lds.3", 65535
  %".419" = and i32 %".418", %".417"
  %".420" = and i32 %"lds.3", 65535
  %".421" = and i32 %".420", 0
  %".422" = or i32 %".419", %".421"
  %".423" = zext i32 0 to i64
  %".424" = zext i32 %".422" to i64
  %".425" = shl i64 %".424", 32
  %"shf_concat.6" = or i64 %".423", %".425"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".426" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".426", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".427" = zext i32 %"imad.13" to i64
  %".428" = zext i32 0 to i64
  %".429" = shl i64 %".428", 32
  %"shf_concat.7" = or i64 %".427", %".429"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".430" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".430" to i32
  %".431" = zext i32 %"imad.13" to i64
  %".432" = zext i32 0 to i64
  %".433" = shl i64 %".432", 32
  %"shf_concat.8" = or i64 %".431", %".433"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".434" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".434" to i32
  %".435" = xor i32 %"shf_result.8", -1
  %".436" = xor i32 %"shf_result.7", -1
  %".437" = xor i32 0, -1
  %".438" = and i32 %".435", %"shf_result.7"
  %".439" = and i32 %".438", %".437"
  %".440" = and i32 %".435", %"shf_result.7"
  %".441" = and i32 %".440", 0
  %".442" = or i32 %".439", %".441"
  %".443" = and i32 %"shf_result.8", %".436"
  %".444" = and i32 %".443", %".437"
  %".445" = or i32 %".442", %".444"
  %".446" = and i32 %"shf_result.8", %".436"
  %".447" = and i32 %".446", 0
  %".448" = or i32 %".445", %".447"
  %".449" = and i32 %"shf_result.8", %"shf_result.7"
  %".450" = and i32 %".449", %".437"
  %".451" = or i32 %".448", %".450"
  %".452" = and i32 %"shf_result.8", %"shf_result.7"
  %".453" = and i32 %".452", 0
  %".454" = or i32 %".451", %".453"
  %".455" = xor i32 %".454", -1
  %".456" = xor i32 65535, -1
  %".457" = xor i32 0, -1
  %".458" = and i32 %".454", 65535
  %".459" = and i32 %".458", %".457"
  %".460" = and i32 %".454", 65535
  %".461" = and i32 %".460", 0
  %".462" = or i32 %".459", %".461"
  %".463" = xor i32 %".454", -1
  %".464" = xor i32 65535, -1
  %".465" = xor i32 %"lds.4", -1
  %".466" = and i32 %".454", 65535
  %".467" = and i32 %".466", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".467", %".462"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0cd0"
BB_0cd0:
  %"cond_trunc.21" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0e30_0ef0", label %"BB_0ce0"
BB_0ce0:
  %".470" = zext i32 0 to i64
  %".471" = zext i32 %"lds.4" to i64
  %".472" = shl i64 %".471", 32
  %"shf_concat.9" = or i64 %".470", %".472"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".473" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".473", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".474" = zext i32 0 to i64
  %".475" = zext i32 %".454" to i64
  %".476" = shl i64 %".475", 32
  %"shf_concat.10" = or i64 %".474", %".476"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".477" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".477", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".478" = xor i32 %"shf_result.9", -1
  %".479" = xor i32 %"shf_result.10", -1
  %".480" = xor i32 0, -1
  %".481" = and i32 %"shf_result.9", %"shf_result.10"
  %".482" = and i32 %".481", %".480"
  %".483" = and i32 %"shf_result.9", %"shf_result.10"
  %".484" = and i32 %".483", 0
  %".485" = or i32 %".482", %".484"
  %"isetrp_cmp1.11" = icmp ne i32 %".485", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0d20"
BB_0d20:
  %"cond_trunc.22" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0e00_0e90", label %"BB_0d30"
BB_0d30:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".488" = xor i32 0, -1
  %".489" = xor i32 %".454", -1
  %".490" = xor i32 0, -1
  %".491" = and i32 %".488", %".489"
  %".492" = and i32 %".491", %".490"
  %".493" = and i32 %".488", %".489"
  %".494" = and i32 %".493", 0
  %".495" = or i32 %".492", %".494"
  %".496" = and i32 0, %".489"
  %".497" = and i32 %".496", %".490"
  %".498" = or i32 %".495", %".497"
  %".499" = and i32 0, %".489"
  %".500" = and i32 %".499", 0
  %".501" = or i32 %".498", %".500"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", %".501"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.14", i32 %"redux_mask")
  %".502" = xor i32 %".501", -1
  %".503" = call i32 @"llvm.cttz.i32"(i32 %".502", i1 0)
  %".504" = shl i32 %".503", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".504") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0dd0"
BB_0dd0:
  %"cond_trunc.23" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000dd0", label %"BB_0e40"
BB_80000dd0:
  %"atoms_shared_addr_winoff.1" = and i32 %".413", 16777215
  %".508" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".508" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.15" monotonic
  br label %"BB_0e40"
BB_0e00_0e90:
  call void @"llvm.trap"()
  br label %"BB_0e40"
BB_0e30_0ef0:
  call void @"llvm.trap"()
  br label %"BB_0e40"
BB_0e40:
  ret void
BB_80000bd0:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z8mma_caseILj1188EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z8mma_caseILj74896EEvPKjPj", !"kernel", i32 1 }
!3 = !{ void (i64, i64)* @"_Z8mma_caseILj65696EEvPKjPj", !"kernel", i32 1 }
!4 = !{ void (i64, i64)* @"_Z8mma_caseILj1184EEvPKjPj", !"kernel", i32 1 }
