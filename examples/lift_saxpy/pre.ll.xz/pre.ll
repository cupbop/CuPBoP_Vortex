; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../sweep_sb1/lifted/saxpy_sm90_lifted.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../sweep_sb1/lifted/saxpy_sm90_lifted.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16
@const_mem = global [5 x [552 x i8]] zeroinitializer, align 16

define void @_Z12saxpy_kernelPKfPffi(i64 %arg_528, i64 %arg_536, i32 %arg_544, i32 %arg_548) {
EntryBB_0000:
  %param_local = alloca [560 x i8], align 16
  %.6 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 528
  store i64 %arg_528, ptr %.6, align 16
  %.9 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 536
  store i64 %arg_536, ptr %.9, align 8
  %.12 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 544
  store i32 %arg_544, ptr %.12, align 32
  %.15 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 548
  store i32 %arg_548, ptr %.15, align 4
  %ntid_x = call i32 @llvm.nvvm.read.ptx.sreg.ntid.x()
  %s2ur_ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %imad_tmp = mul i32 %ntid_x, %s2ur_ctaid_x
  %imad = add i32 %imad_tmp, %tid_x
  %isetrp_cmp1 = icmp sge i32 %imad, %arg_548
  br label %BB_0070

BB_0070:                                          ; preds = %EntryBB_0000
  %0 = zext i1 %isetrp_cmp1 to i32
  %1 = icmp ne i32 %0, 0
  br i1 %1, label %BB_80000070, label %BB_0080

BB_0080:                                          ; preds = %BB_0070
  %ldc_const.1 = load i64, ptr %.6, align 8
  %ldc_const.2 = load i32, ptr %.12, align 4
  %R11_bitcast = bitcast i32 %ldc_const.2 to float
  %ldc_const.3 = load i64, ptr %.9, align 8
  %imad_lhs_64 = sext i32 %imad to i64
  %imad_tmp_64 = mul i64 %imad_lhs_64, 4
  %2 = add i64 %imad_tmp_64, %ldc_const.1
  %"R17:R14_addr_ptr" = inttoptr i64 %2 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R17:R14_addr_ptr", align 4
  %3 = add i64 %imad_tmp_64, %ldc_const.3
  %"R4:R3_addr_ptr" = inttoptr i64 %3 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R4:R3_addr_ptr", align 4
  %ffma = call float @llvm.fma.f32(float %ldg, float %R11_bitcast, float %ldg.1)
  store float %ffma, ptr addrspace(1) %"R4:R3_addr_ptr", align 4
  ret void

BB_80000070:                                      ; preds = %BB_0070
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #0

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z12saxpy_kernelPKfPffi, !"kernel", i32 1}
