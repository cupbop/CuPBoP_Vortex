; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/backprop.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/backprop.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [1088 x i8], align 16
@const_mem = internal global [5 x [368 x i8]] zeroinitializer, align 16

define void @_Z22bpnn_layerforward_CUDAPfS_S_S_ii(i64 %arg_320, i64 %arg_328, i64 %arg_336, i64 %arg_344, i32 %arg_352, i32 %arg_356) {
EntryBB_0000:
  %param_local = alloca [368 x i8], align 16
  %.8 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 320
  store i64 %arg_320, ptr %.8, align 64
  %.11 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 328
  store i64 %arg_328, ptr %.11, align 8
  %.14 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 336
  store i64 %arg_336, ptr %.14, align 16
  %.17 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 344
  store i64 %arg_344, ptr %.17, align 8
  %.20 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 352
  store i32 %arg_352, ptr %.20, align 32
  %.23 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 356
  store i32 %arg_356, ptr %.23, align 4
  %legacy_entry_mask = call i32 @llvm.nvvm.vote.ballot.sync(i32 -1, i1 true)
  %mov = load i32, ptr %.23, align 4
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %legacy_a_wide = zext i32 %mov to i64
  %legacy_sum = add i64 %legacy_a_wide, 1
  %legacy_result = trunc i64 %legacy_sum to i32
  %tid_y = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %legacy_a_shift = shl i32 %mov, 4
  %legacy_a_wide.1 = zext i32 %legacy_a_shift to i64
  %legacy_sum.1 = add i64 %legacy_a_wide.1, 16
  %legacy_result.1 = trunc i64 %legacy_sum.1 to i32
  %i2f_directed = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 16)
  %ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %isetrp_cmp1 = icmp ne i32 %tid_x, 0
  %mufu_rcp = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed)
  %cast = bitcast float %mufu_rcp to i32
  br label %BB_0058

BB_0058:                                          ; preds = %EntryBB_0000
  %cond_not = xor i1 %isetrp_cmp1, true
  br i1 %cond_not, label %BB_80000058, label %BB_0080

BB_80000058:                                      ; preds = %BB_0058
  %legacy_a_shift.1 = shl i32 %ctaid_y, 4
  %legacy_a_wide.2 = zext i32 %legacy_a_shift.1 to i64
  %legacy_b_wide.2 = zext i32 %tid_y to i64
  %legacy_sum.2 = add i64 %legacy_a_wide.2, %legacy_b_wide.2
  %legacy_result.2 = trunc i64 %legacy_sum.2 to i32
  %shr_result = ashr i32 %legacy_result.2, 30
  %legacy_a_shift.2 = shl i32 %legacy_result.2, 2
  %legacy_b = load i32, ptr %.8, align 4
  %.33 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 324
  %legacy_b.1 = load i32, ptr %.33, align 4
  %0 = zext i32 %legacy_a_shift.2 to i64
  %1 = zext i32 %legacy_b to i64
  %2 = zext i32 %shr_result to i64
  %3 = shl i64 %2, 32
  %4 = zext i32 %legacy_b.1 to i64
  %5 = shl i64 %4, 32
  %6 = add i64 %0, %1
  %7 = add i64 %6, %3
  %8 = add i64 %7, %5
  %ldg_addr_memaddr_offset_add = add i64 %8, 4
  %"R135:R48_addr_ptr" = inttoptr i64 %ldg_addr_memaddr_offset_add to ptr addrspace(1)
  %ldg = load i32, ptr addrspace(1) %"R135:R48_addr_ptr", align 4
  br label %BB_0080

BB_0080:                                          ; preds = %BB_80000058, %BB_0058
  %phi = phi i32 [ %ldg, %BB_80000058 ], [ 0, %BB_0058 ]
  %legacy_a_wide.5 = zext i32 %tid_x to i64
  %legacy_b.2 = load i32, ptr %.23, align 4
  %legacy_b_wide.5 = zext i32 %legacy_b.2 to i64
  %legacy_sum.5 = add i64 %legacy_a_wide.5, %legacy_b_wide.5
  %legacy_result.5 = trunc i64 %legacy_sum.5 to i32
  %.39 = trunc i32 %legacy_result to i16
  %.40 = zext i16 %.39 to i32
  %.41 = lshr i32 %tid_y, 16
  %.42 = trunc i32 %.41 to i16
  %.43 = zext i16 %.42 to i32
  %xmad_product = mul i32 %.40, %.43
  %.44 = and i32 %xmad_product, 65535
  %.45 = shl i32 %tid_y, 16
  %xmad_merge = or i32 %.44, %.45
  %.48 = trunc i32 %tid_y to i16
  %.49 = zext i16 %.48 to i32
  %xmad_product.1 = mul i32 %.40, %.49
  %xmad_sum.1 = add i32 %xmad_product.1, %legacy_result.5
  %.50 = lshr i32 %legacy_result, 16
  %.51 = trunc i32 %.50 to i16
  %.52 = zext i16 %.51 to i32
  %.53 = lshr i32 %xmad_merge, 16
  %.54 = trunc i32 %.53 to i16
  %.55 = zext i16 %.54 to i32
  %xmad_product.2 = mul i32 %.52, %.55
  %xmad_psl = shl i32 %xmad_product.2, 16
  %.56 = shl i32 %xmad_merge, 16
  %xmad_cbcc = add i32 %xmad_sum.1, %.56
  %xmad_sum.2 = add i32 %xmad_psl, %xmad_cbcc
  %i2f_directed.1 = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 4)
  %.57 = trunc i32 %legacy_result.1 to i16
  %.58 = zext i16 %.57 to i32
  %.59 = lshr i32 %ctaid_y, 16
  %.60 = trunc i32 %.59 to i16
  %.61 = zext i16 %.60 to i32
  %xmad_product.3 = mul i32 %.58, %.61
  %.62 = and i32 %xmad_product.3, 65535
  %.63 = shl i32 %ctaid_y, 16
  %xmad_merge.1 = or i32 %.62, %.63
  %.66 = trunc i32 %ctaid_y to i16
  %.67 = zext i16 %.66 to i32
  %xmad_product.4 = mul i32 %.58, %.67
  %xmad_sum.4 = add i32 %xmad_product.4, %xmad_sum.2
  %mufu_rcp.1 = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed.1)
  %cast.1 = bitcast float %mufu_rcp.1 to i32
  %.68 = lshr i32 %legacy_result.1, 16
  %.69 = trunc i32 %.68 to i16
  %.70 = zext i16 %.69 to i32
  %.71 = lshr i32 %xmad_merge.1, 16
  %.72 = trunc i32 %.71 to i16
  %.73 = zext i16 %.72 to i32
  %xmad_product.5 = mul i32 %.70, %.73
  %xmad_psl.1 = shl i32 %xmad_product.5, 16
  %.74 = shl i32 %xmad_merge.1, 16
  %xmad_cbcc.1 = add i32 %xmad_sum.4, %.74
  %xmad_sum.5 = add i32 %xmad_psl.1, %xmad_cbcc.1
  %shl = shl i32 %tid_y, 2
  %shr_result.1 = ashr i32 %xmad_sum.5, 30
  %legacy_a_shift.3 = shl i32 %xmad_sum.5, 2
  %legacy_b.3 = load i32, ptr %.14, align 4
  %i2f_directed.2 = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 2)
  %.78 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 340
  %legacy_b.4 = load i32, ptr %.78, align 4
  %9 = zext i32 %legacy_a_shift.3 to i64
  %10 = zext i32 %legacy_b.3 to i64
  %11 = zext i32 %shr_result.1 to i64
  %12 = shl i64 %11, 32
  %13 = zext i32 %legacy_b.4 to i64
  %14 = shl i64 %13, 32
  %15 = add i64 %9, %10
  %16 = add i64 %15, %12
  %17 = add i64 %16, %14
  %mufu_rcp.2 = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed.2)
  %cast.2 = bitcast float %mufu_rcp.2 to i32
  %legacy_a_wide.8 = zext i32 %cast.2 to i64
  %legacy_sum.8 = add i64 %legacy_a_wide.8, 268435454
  %legacy_result.8 = trunc i64 %legacy_sum.8 to i32
  %cast.3 = bitcast i32 %legacy_result.8 to float
  %f2i = fptoui float %cast.3 to i32
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0110

BB_0110:                                          ; preds = %BB_0080
  %18 = zext i1 %cond_not to i32
  %19 = icmp ne i32 %18, 0
  br i1 %19, label %BB_80000110, label %BB_0118

BB_80000110:                                      ; preds = %BB_0110
  %sts_shared_addr_winoff = and i32 %shl, 16777215
  %.83 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_shared_addr_winoff
  store volatile i32 %phi, ptr addrspace(3) %.83, align 4
  br label %BB_0118

BB_0118:                                          ; preds = %BB_80000110, %BB_0110
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %ldg_addr_memaddr_offset_add.1 = add i64 %17, 8
  %"R138:R74_addr_ptr" = inttoptr i64 %ldg_addr_memaddr_offset_add.1 to ptr addrspace(1)
  %ldg.1 = load i32, ptr addrspace(1) %"R138:R74_addr_ptr", align 4
  %iadd3_o2_not = xor i32 %f2i, -1
  %iadd3_o2_neg = add i32 %iadd3_o2_not, 1
  %iadd3_n2 = add i32 %iadd3_o2_neg, %iadd3_o2_neg
  %i2i_negative = icmp slt i32 %tid_y, 0
  %i2i_absneg = sub i32 0, %tid_y
  %i2i_abs = select i1 %i2i_negative, i32 %i2i_absneg, i32 %tid_y
  %.86 = trunc i32 %f2i to i16
  %.87 = zext i16 %.86 to i32
  %.88 = trunc i32 %iadd3_n2 to i16
  %.89 = zext i16 %.88 to i32
  %xmad_product.6 = mul i32 %.87, %.89
  %.92 = lshr i32 %iadd3_n2, 16
  %.93 = trunc i32 %.92 to i16
  %.94 = zext i16 %.93 to i32
  %xmad_product.7 = mul i32 %.87, %.94
  %.95 = lshr i32 %f2i, 16
  %.96 = trunc i32 %.95 to i16
  %.97 = zext i16 %.96 to i32
  %xmad_product.8 = mul i32 %.97, %.94
  %xmad_sum.8 = add i32 %xmad_product.8, %f2i
  %xmad_product.9 = mul i32 %.97, %.89
  %xmad_chi = lshr i32 %xmad_product.6, 16
  %xmad_sum.9 = add i32 %xmad_product.9, %xmad_chi
  %.106 = zext i32 %xmad_sum.9 to i64
  %.107 = zext i32 %xmad_product.7 to i64
  %.108 = add i64 %.106, %.107
  %.109 = lshr i64 %.108, 16
  %.110 = trunc i64 %.109 to i32
  %legacy_iadd3_rs = add i32 %.110, %xmad_sum.8
  %i2f_directed.3 = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 8)
  %legacy_a_wide.9 = zext i32 %cast.1 to i64
  %legacy_sum.9 = add i64 %legacy_a_wide.9, 268435454
  %legacy_result.9 = trunc i64 %legacy_sum.9 to i32
  %cast.4 = bitcast i32 %legacy_result.9 to float
  %f2i.1 = fptoui float %cast.4 to i32
  %.111 = trunc i32 %legacy_iadd3_rs to i16
  %.112 = zext i16 %.111 to i32
  %.113 = trunc i32 %i2i_abs to i16
  %.114 = zext i16 %.113 to i32
  %xmad_product.10 = mul i32 %.112, %.114
  %mufu_rcp.3 = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed.3)
  %cast.5 = bitcast float %mufu_rcp.3 to i32
  %.117 = lshr i32 %i2i_abs, 16
  %.118 = trunc i32 %.117 to i16
  %.119 = zext i16 %.118 to i32
  %xmad_product.11 = mul i32 %.112, %.119
  %legacy_a_shift.4 = shl i32 %f2i.1, 2
  %legacy_a_wide.10 = zext i32 %legacy_a_shift.4 to i64
  %legacy_a_complement = xor i64 %legacy_a_wide.10, 4294967295
  %legacy_a_negate = add i64 %legacy_a_complement, 1
  %legacy_result.10 = trunc i64 %legacy_a_negate to i32
  %.120 = lshr i32 %legacy_iadd3_rs, 16
  %.121 = trunc i32 %.120 to i16
  %.122 = zext i16 %.121 to i32
  %xmad_product.12 = mul i32 %.122, %.114
  %xmad_chi.1 = lshr i32 %xmad_product.10, 16
  %xmad_sum.12 = add i32 %xmad_product.12, %xmad_chi.1
  %xmad_product.13 = mul i32 %.122, %.119
  %.131 = lshr i32 %f2i.1, 16
  %.132 = trunc i32 %.131 to i16
  %.133 = zext i16 %.132 to i32
  %.134 = lshr i32 %legacy_result.10, 16
  %.135 = trunc i32 %.134 to i16
  %.136 = zext i16 %.135 to i32
  %xmad_product.14 = mul i32 %.133, %.136
  %xmad_sum.14 = add i32 %xmad_product.14, %f2i.1
  %.137 = zext i32 %xmad_sum.12 to i64
  %.138 = zext i32 %xmad_product.11 to i64
  %.139 = add i64 %.137, %.138
  %.140 = lshr i64 %.139, 16
  %.141 = trunc i64 %.140 to i32
  %legacy_iadd3_rs.1 = add i32 %.141, %xmad_product.13
  %.142 = trunc i32 %f2i.1 to i16
  %.143 = zext i16 %.142 to i32
  %.144 = trunc i32 %legacy_result.10 to i16
  %.145 = zext i16 %.144 to i32
  %xmad_product.15 = mul i32 %.143, %.145
  %xmad_product.16 = mul i32 %.143, %.136
  %legacy_a_wide.11 = zext i32 %cast.5 to i64
  %legacy_sum.11 = add i64 %legacy_a_wide.11, 268435454
  %legacy_result.11 = trunc i64 %legacy_sum.11 to i32
  %cast.6 = bitcast i32 %legacy_result.11 to float
  %f2i.2 = fptoui float %cast.6 to i32
  %legacy_a_shift.5 = shl i32 %legacy_iadd3_rs.1, 1
  %legacy_a_wide.12 = zext i32 %legacy_a_shift.5 to i64
  %legacy_a_complement.1 = xor i64 %legacy_a_wide.12, 4294967295
  %legacy_a_negate.1 = add i64 %legacy_a_complement.1, 1
  %legacy_b_wide.12 = zext i32 %i2i_abs to i64
  %legacy_sum.12 = add i64 %legacy_a_negate.1, %legacy_b_wide.12
  %legacy_result.12 = trunc i64 %legacy_sum.12 to i32
  %xmad_product.17 = mul i32 %.133, %.145
  %xmad_chi.2 = lshr i32 %xmad_product.15, 16
  %xmad_sum.17 = add i32 %xmad_product.17, %xmad_chi.2
  %isetrp_cmp1.1 = icmp uge i32 %legacy_result.12, 2
  %.156 = zext i32 %xmad_sum.17 to i64
  %.157 = zext i32 %xmad_product.16 to i64
  %.158 = add i64 %.156, %.157
  %.159 = lshr i64 %.158, 16
  %.160 = trunc i64 %.159 to i32
  %legacy_iadd3_rs.2 = add i32 %.160, %xmad_sum.14
  %legacy_a_shift.6 = shl i32 %tid_y, 6
  %legacy_a_wide.13 = zext i32 %legacy_a_shift.6 to i64
  %legacy_sum.13 = add i64 %legacy_a_wide.13, 64
  %legacy_result.13 = trunc i64 %legacy_sum.13 to i32
  %legacy_a_shift.7 = shl i32 %f2i.2, 3
  %legacy_a_wide.14 = zext i32 %legacy_a_shift.7 to i64
  %legacy_a_complement.2 = xor i64 %legacy_a_wide.14, 4294967295
  %legacy_a_negate.2 = add i64 %legacy_a_complement.2, 1
  %legacy_result.14 = trunc i64 %legacy_a_negate.2 to i32
  %.161 = trunc i32 %legacy_iadd3_rs.2 to i16
  %.162 = zext i16 %.161 to i32
  %xmad_product.18 = mul i32 %.162, %.114
  %legacy_a_shift.8 = shl i32 %tid_x, 2
  %legacy_a_wide.15 = zext i32 %legacy_a_shift.8 to i64
  %legacy_b_wide.15 = zext i32 %legacy_result.13 to i64
  %legacy_sum.15 = add i64 %legacy_a_wide.15, %legacy_b_wide.15
  %legacy_result.15 = trunc i64 %legacy_sum.15 to i32
  %xmad_product.19 = mul i32 %.162, %.119
  %.170 = trunc i32 %f2i.2 to i16
  %.171 = zext i16 %.170 to i32
  %.172 = trunc i32 %legacy_result.14 to i16
  %.173 = zext i16 %.172 to i32
  %xmad_product.20 = mul i32 %.171, %.173
  br label %BB_0238

BB_0238:                                          ; preds = %BB_0118
  %20 = zext i1 %isetrp_cmp1.1 to i32
  %21 = icmp ne i32 %20, 0
  br i1 %21, label %BB_80000238, label %BB_0240

BB_80000238:                                      ; preds = %BB_0238
  %legacy_a_wide.16 = zext i32 %legacy_result.12 to i64
  %legacy_sum.16 = add i64 %legacy_a_wide.16, 4294967294
  %legacy_result.16 = trunc i64 %legacy_sum.16 to i32
  br label %BB_0240

BB_0240:                                          ; preds = %BB_80000238, %BB_0238
  %phi.1 = phi i32 [ %legacy_result.16, %BB_80000238 ], [ %legacy_result.12, %BB_0238 ]
  %.177 = lshr i32 %legacy_iadd3_rs.2, 16
  %.178 = trunc i32 %.177 to i16
  %.179 = zext i16 %.178 to i32
  %xmad_product.21 = mul i32 %.179, %.114
  %xmad_chi.3 = lshr i32 %xmad_product.18, 16
  %xmad_sum.21 = add i32 %xmad_product.21, %xmad_chi.3
  %xmad_product.22 = mul i32 %.179, %.119
  %isetrp_cmp1.2 = icmp sge i32 %tid_y, 0
  %isetrp_cmp1.3 = icmp uge i32 %phi.1, 2
  %.188 = zext i32 %xmad_sum.21 to i64
  %.189 = zext i32 %xmad_product.19 to i64
  %.190 = add i64 %.188, %.189
  %.191 = lshr i64 %.190, 16
  %.192 = trunc i64 %.191 to i32
  %legacy_iadd3_rs.3 = add i32 %.192, %xmad_product.22
  %legacy_a_shift.9 = shl i32 %legacy_iadd3_rs.3, 2
  %legacy_a_wide.17 = zext i32 %legacy_a_shift.9 to i64
  %legacy_a_complement.3 = xor i64 %legacy_a_wide.17, 4294967295
  %legacy_a_negate.3 = add i64 %legacy_a_complement.3, 1
  %legacy_sum.17 = add i64 %legacy_a_negate.3, %legacy_b_wide.12
  %legacy_result.17 = trunc i64 %legacy_sum.17 to i32
  %.193 = lshr i32 %f2i.2, 16
  %.194 = trunc i32 %.193 to i16
  %.195 = zext i16 %.194 to i32
  %.196 = lshr i32 %legacy_result.14, 16
  %.197 = trunc i32 %.196 to i16
  %.198 = zext i16 %.197 to i32
  %xmad_product.23 = mul i32 %.195, %.198
  %xmad_sum.23 = add i32 %xmad_product.23, %f2i.2
  br label %BB_0278

BB_0278:                                          ; preds = %BB_0240
  %22 = zext i1 %isetrp_cmp1.3 to i32
  %23 = icmp ne i32 %22, 0
  br i1 %23, label %BB_80000278, label %BB_0280

BB_80000278:                                      ; preds = %BB_0278
  %legacy_a_wide.18 = zext i32 %phi.1 to i64
  %legacy_sum.18 = add i64 %legacy_a_wide.18, 4294967294
  %legacy_result.18 = trunc i64 %legacy_sum.18 to i32
  br label %BB_0280

BB_0280:                                          ; preds = %BB_80000278, %BB_0278
  %phi.2 = phi i32 [ %legacy_result.18, %BB_80000278 ], [ %phi.1, %BB_0278 ]
  %isetrp_cmp1.4 = icmp uge i32 %legacy_result.17, 4
  br label %BB_0288

BB_0288:                                          ; preds = %BB_0280
  %cond_not.2 = xor i1 %isetrp_cmp1.2, true
  br i1 %cond_not.2, label %BB_80000288, label %BB_0290

BB_80000288:                                      ; preds = %BB_0288
  %legacy_a_wide.19 = zext i32 %phi.2 to i64
  %legacy_a_complement.4 = xor i64 %legacy_a_wide.19, 4294967295
  %legacy_a_negate.4 = add i64 %legacy_a_complement.4, 1
  %legacy_result.19 = trunc i64 %legacy_a_negate.4 to i32
  br label %BB_0290

BB_0290:                                          ; preds = %BB_80000288, %BB_0288
  %phi.3 = phi i32 [ %legacy_result.19, %BB_80000288 ], [ %phi.2, %BB_0288 ]
  %isetrp_cmp1.5 = icmp ne i32 %phi.3, 0
  %legacy_a_wide.20 = zext i32 %cast to i64
  %legacy_sum.20 = add i64 %legacy_a_wide.20, 268435454
  %legacy_result.20 = trunc i64 %legacy_sum.20 to i32
  %cast.7 = bitcast i32 %legacy_result.20 to float
  br label %BB_02a0

BB_02a0:                                          ; preds = %BB_0290
  %24 = zext i1 %isetrp_cmp1.4 to i32
  %25 = icmp ne i32 %24, 0
  br i1 %25, label %BB_800002a0, label %BB_02a8

BB_800002a0:                                      ; preds = %BB_02a0
  %legacy_a_wide.21 = zext i32 %legacy_result.17 to i64
  %legacy_sum.21 = add i64 %legacy_a_wide.21, 4294967292
  %legacy_result.21 = trunc i64 %legacy_sum.21 to i32
  br label %BB_02a8

BB_02a8:                                          ; preds = %BB_800002a0, %BB_02a0
  %phi.4 = phi i32 [ %legacy_result.21, %BB_800002a0 ], [ %legacy_result.17, %BB_02a0 ]
  %isetrp_cmp1.6 = icmp uge i32 %phi.4, 4
  br label %BB_02b0

BB_02b0:                                          ; preds = %BB_02a8
  %26 = zext i1 %isetrp_cmp1.6 to i32
  %27 = icmp ne i32 %26, 0
  br i1 %27, label %BB_800002b0, label %BB_02b8

BB_800002b0:                                      ; preds = %BB_02b0
  %legacy_a_wide.22 = zext i32 %phi.4 to i64
  %legacy_sum.22 = add i64 %legacy_a_wide.22, 4294967292
  %legacy_result.22 = trunc i64 %legacy_sum.22 to i32
  br label %BB_02b8

BB_02b8:                                          ; preds = %BB_800002b0, %BB_02b0
  %phi.5 = phi i32 [ %legacy_result.22, %BB_800002b0 ], [ %phi.4, %BB_02b0 ]
  br i1 %cond_not.2, label %BB_800002b8, label %BB_02c0

BB_800002b8:                                      ; preds = %BB_02b8
  %legacy_a_wide.23 = zext i32 %phi.5 to i64
  %legacy_a_complement.5 = xor i64 %legacy_a_wide.23, 4294967295
  %legacy_a_negate.5 = add i64 %legacy_a_complement.5, 1
  %legacy_result.23 = trunc i64 %legacy_a_negate.5 to i32
  br label %BB_02c0

BB_02c0:                                          ; preds = %BB_800002b8, %BB_02b8
  %phi.6 = phi i32 [ %legacy_result.23, %BB_800002b8 ], [ %phi.5, %BB_02b8 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %sts_shared_addr_winoff.1 = and i32 %legacy_result.15, 16777215
  %.213 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_shared_addr_winoff.1
  store volatile i32 %ldg.1, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %lds_shared_addr_winoff = and i32 %shl, 16777215
  %.215 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff
  %lds = load volatile float, ptr addrspace(3) %.215, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %xmad_product.24 = mul i32 %.171, %.198
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %lds.1 = load volatile float, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %xmad_product.25 = mul i32 %.195, %.173
  %xmad_chi.4 = lshr i32 %xmad_product.20, 16
  %xmad_sum.25 = add i32 %xmad_product.25, %xmad_chi.4
  %.227 = zext i32 %xmad_sum.25 to i64
  %.228 = zext i32 %xmad_product.24 to i64
  %.229 = add i64 %.227, %.228
  %.230 = lshr i64 %.229, 16
  %.231 = trunc i64 %.230 to i32
  %legacy_iadd3_rs.4 = add i32 %.231, %xmad_sum.23
  %f2i.3 = fptoui float %cast.7 to i32
  %.232 = trunc i32 %legacy_iadd3_rs.4 to i16
  %.233 = zext i16 %.232 to i32
  %xmad_product.26 = mul i32 %.233, %.114
  %.236 = lshr i32 %legacy_iadd3_rs.4, 16
  %.237 = trunc i32 %.236 to i16
  %.238 = zext i16 %.237 to i32
  %xmad_product.27 = mul i32 %.238, %.119
  %xmad_product.28 = mul i32 %.238, %.114
  %xmad_chi.5 = lshr i32 %xmad_product.26, 16
  %xmad_sum.28 = add i32 %xmad_product.28, %xmad_chi.5
  %legacy_a_shift.10 = shl i32 %f2i.3, 4
  %legacy_a_wide.24 = zext i32 %legacy_a_shift.10 to i64
  %legacy_a_complement.6 = xor i64 %legacy_a_wide.24, 4294967295
  %legacy_a_negate.6 = add i64 %legacy_a_complement.6, 1
  %legacy_result.24 = trunc i64 %legacy_a_negate.6 to i32
  %fmul = fmul float %lds, %lds.1
  %xmad_product.29 = mul i32 %.233, %.119
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  store volatile float %fmul, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.254 = trunc i32 %f2i.3 to i16
  %.255 = zext i16 %.254 to i32
  %.256 = lshr i32 %legacy_result.24, 16
  %.257 = trunc i32 %.256 to i16
  %.258 = zext i16 %.257 to i32
  %xmad_product.30 = mul i32 %.255, %.258
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %.259 = zext i32 %xmad_sum.28 to i64
  %.260 = zext i32 %xmad_product.29 to i64
  %.261 = add i64 %.259, %.260
  %.262 = lshr i64 %.261, 16
  %.263 = trunc i64 %.262 to i32
  %legacy_iadd3_rs.5 = add i32 %.263, %xmad_product.27
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_03b8

BB_03b8:                                          ; preds = %BB_02c0
  %cond_not.4 = xor i1 %isetrp_cmp1.5, true
  %phi_cast_R28_bitcast = bitcast i32 %legacy_iadd3_rs.4 to float
  br i1 %cond_not.4, label %BB_800003b8, label %BB_03c0

BB_800003b8:                                      ; preds = %BB_03b8
  %lds.2 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_03c0

BB_03c0:                                          ; preds = %BB_800003b8, %BB_03b8
  %phi.7 = phi float [ %lds.2, %BB_800003b8 ], [ %phi_cast_R28_bitcast, %BB_03b8 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.270 = trunc i32 %legacy_result.24 to i16
  %.271 = zext i16 %.270 to i32
  %xmad_product.31 = mul i32 %.255, %.271
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_03d8

BB_03d8:                                          ; preds = %BB_03c0
  %28 = zext i1 %cond_not.4 to i32
  %29 = icmp ne i32 %28, 0
  br i1 %29, label %BB_800003d8, label %BB_03e0

BB_800003d8:                                      ; preds = %BB_03d8
  %lds_addr_memaddr_offset_add = add i32 %legacy_result.15, 64
  %lds_shared_addr_winoff.3 = and i32 %lds_addr_memaddr_offset_add, 16777215
  %.274 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.3
  %lds.3 = load volatile float, ptr addrspace(3) %.274, align 4
  br label %BB_03e0

BB_03e0:                                          ; preds = %BB_800003d8, %BB_03d8
  %phi.8 = phi float [ %lds.3, %BB_800003d8 ], [ %cast.7, %BB_03d8 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.276 = lshr i32 %f2i.3, 16
  %.277 = trunc i32 %.276 to i16
  %.278 = zext i16 %.277 to i32
  %xmad_product.32 = mul i32 %.278, %.258
  %xmad_sum.32 = add i32 %xmad_product.32, %f2i.3
  %legacy_a_shift.11 = shl i32 %legacy_iadd3_rs.5, 3
  %legacy_a_wide.25 = zext i32 %legacy_a_shift.11 to i64
  %legacy_a_complement.7 = xor i64 %legacy_a_wide.25, 4294967295
  %legacy_a_negate.7 = add i64 %legacy_a_complement.7, 1
  %legacy_sum.25 = add i64 %legacy_a_negate.7, %legacy_b_wide.12
  %legacy_result.25 = trunc i64 %legacy_sum.25 to i32
  %xmad_product.33 = mul i32 %.278, %.271
  %xmad_chi.6 = lshr i32 %xmad_product.31, 16
  %xmad_sum.33 = add i32 %xmad_product.33, %xmad_chi.6
  %isetrp_cmp1.7 = icmp uge i32 %legacy_result.25, 8
  %.287 = zext i32 %xmad_sum.33 to i64
  %.288 = zext i32 %xmad_product.30 to i64
  %.289 = add i64 %.287, %.288
  %.290 = lshr i64 %.289, 16
  %.291 = trunc i64 %.290 to i32
  %legacy_iadd3_rs.6 = add i32 %.291, %xmad_sum.32
  %.292 = trunc i32 %legacy_iadd3_rs.6 to i16
  %.293 = zext i16 %.292 to i32
  %xmad_product.34 = mul i32 %.293, %.114
  br label %BB_0418

BB_0418:                                          ; preds = %BB_03e0
  %30 = zext i1 %isetrp_cmp1.7 to i32
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %BB_80000418, label %BB_0420

BB_80000418:                                      ; preds = %BB_0418
  %legacy_a_wide.26 = zext i32 %legacy_result.25 to i64
  %legacy_sum.26 = add i64 %legacy_a_wide.26, 4294967288
  %legacy_result.26 = trunc i64 %legacy_sum.26 to i32
  br label %BB_0420

BB_0420:                                          ; preds = %BB_80000418, %BB_0418
  %phi.9 = phi i32 [ %legacy_result.26, %BB_80000418 ], [ %legacy_result.25, %BB_0418 ]
  %isetrp_cmp1.8 = icmp ne i32 %phi.6, 0
  br label %BB_0428

BB_0428:                                          ; preds = %BB_0420
  %32 = zext i1 %cond_not.4 to i32
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %BB_80000428, label %BB_0430

BB_80000428:                                      ; preds = %BB_0428
  %fadd = fadd float %phi.7, %phi.8
  br label %BB_0430

BB_0430:                                          ; preds = %BB_80000428, %BB_0428
  %phi.10 = phi float [ %fadd, %BB_80000428 ], [ %phi.7, %BB_0428 ]
  %xmad_product.35 = mul i32 %.293, %.119
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0440

BB_0440:                                          ; preds = %BB_0430
  %34 = zext i1 %cond_not.4 to i32
  %35 = icmp ne i32 %34, 0
  br i1 %35, label %BB_80000440, label %BB_0448

BB_80000440:                                      ; preds = %BB_0440
  store volatile float %phi.10, ptr addrspace(3) %.213, align 4
  br label %BB_0448

BB_0448:                                          ; preds = %BB_80000440, %BB_0440
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.312 = lshr i32 %legacy_iadd3_rs.6, 16
  %.313 = trunc i32 %.312 to i16
  %.314 = zext i16 %.313 to i32
  %xmad_product.36 = mul i32 %.314, %.114
  %xmad_chi.7 = lshr i32 %xmad_product.34, 16
  %xmad_sum.36 = add i32 %xmad_product.36, %xmad_chi.7
  %xmad_product.37 = mul i32 %.314, %.119
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %isetrp_cmp1.9 = icmp uge i32 %phi.9, 8
  %.323 = zext i32 %xmad_sum.36 to i64
  %.324 = zext i32 %xmad_product.35 to i64
  %.325 = add i64 %.323, %.324
  %.326 = lshr i64 %.325, 16
  %.327 = trunc i64 %.326 to i32
  %legacy_iadd3_rs.7 = add i32 %.327, %xmad_product.37
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0490

BB_0490:                                          ; preds = %BB_0448
  %cond_not.8 = xor i1 %isetrp_cmp1.8, true
  %phi_cast_R121_bitcast = bitcast i32 %xmad_product.35 to float
  br i1 %cond_not.8, label %BB_80000490, label %BB_0498

BB_80000490:                                      ; preds = %BB_0490
  %lds.4 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_0498

BB_0498:                                          ; preds = %BB_80000490, %BB_0490
  %phi.11 = phi float [ %lds.4, %BB_80000490 ], [ %phi_cast_R121_bitcast, %BB_0490 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %legacy_a_shift.12 = shl i32 %legacy_iadd3_rs.7, 4
  %legacy_a_wide.27 = zext i32 %legacy_a_shift.12 to i64
  %legacy_a_complement.8 = xor i64 %legacy_a_wide.27, 4294967295
  %legacy_a_negate.8 = add i64 %legacy_a_complement.8, 1
  %legacy_sum.27 = add i64 %legacy_a_negate.8, %legacy_b_wide.12
  %legacy_result.27 = trunc i64 %legacy_sum.27 to i32
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_04b0

BB_04b0:                                          ; preds = %BB_0498
  %phi_cast_R54_bitcast = bitcast i32 %xmad_sum.36 to float
  br i1 %cond_not.8, label %BB_800004b0, label %BB_04b8

BB_800004b0:                                      ; preds = %BB_04b0
  %lds_addr_memaddr_offset_add.1 = add i32 %legacy_result.15, 128
  %lds_shared_addr_winoff.5 = and i32 %lds_addr_memaddr_offset_add.1, 16777215
  %.334 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.5
  %lds.5 = load volatile float, ptr addrspace(3) %.334, align 4
  br label %BB_04b8

BB_04b8:                                          ; preds = %BB_800004b0, %BB_04b0
  %phi.12 = phi float [ %lds.5, %BB_800004b0 ], [ %phi_cast_R54_bitcast, %BB_04b0 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_04c0

BB_04c0:                                          ; preds = %BB_04b8
  %36 = zext i1 %isetrp_cmp1.9 to i32
  %37 = icmp ne i32 %36, 0
  br i1 %37, label %BB_800004c0, label %BB_04c8

BB_800004c0:                                      ; preds = %BB_04c0
  %legacy_a_wide.28 = zext i32 %phi.9 to i64
  %legacy_sum.28 = add i64 %legacy_a_wide.28, 4294967288
  %legacy_result.28 = trunc i64 %legacy_sum.28 to i32
  br label %BB_04c8

BB_04c8:                                          ; preds = %BB_800004c0, %BB_04c0
  %phi.13 = phi i32 [ %legacy_result.28, %BB_800004c0 ], [ %phi.9, %BB_04c0 ]
  %isetrp_cmp1.10 = icmp uge i32 %legacy_result.27, 16
  br label %BB_04d0

BB_04d0:                                          ; preds = %BB_04c8
  %38 = zext i1 %cond_not.2 to i32
  %39 = icmp ne i32 %38, 0
  br i1 %39, label %BB_800004d0, label %BB_04d8

BB_800004d0:                                      ; preds = %BB_04d0
  %legacy_a_wide.29 = zext i32 %phi.13 to i64
  %legacy_a_complement.9 = xor i64 %legacy_a_wide.29, 4294967295
  %legacy_a_negate.9 = add i64 %legacy_a_complement.9, 1
  %legacy_result.29 = trunc i64 %legacy_a_negate.9 to i32
  br label %BB_04d8

BB_04d8:                                          ; preds = %BB_800004d0, %BB_04d0
  %phi.14 = phi i32 [ %legacy_result.29, %BB_800004d0 ], [ %phi.13, %BB_04d0 ]
  br i1 %isetrp_cmp1.10, label %BB_800004d8, label %BB_04e0

BB_800004d8:                                      ; preds = %BB_04d8
  %legacy_a_wide.30 = zext i32 %legacy_result.27 to i64
  %legacy_sum.30 = add i64 %legacy_a_wide.30, 4294967280
  %legacy_result.30 = trunc i64 %legacy_sum.30 to i32
  br label %BB_04e0

BB_04e0:                                          ; preds = %BB_800004d8, %BB_04d8
  %phi.15 = phi i32 [ %legacy_result.30, %BB_800004d8 ], [ %legacy_result.27, %BB_04d8 ]
  %isetrp_cmp1.11 = icmp ne i32 %phi.14, 0
  br label %BB_04e8

BB_04e8:                                          ; preds = %BB_04e0
  %40 = zext i1 %cond_not.8 to i32
  %41 = icmp ne i32 %40, 0
  br i1 %41, label %BB_800004e8, label %BB_04f0

BB_800004e8:                                      ; preds = %BB_04e8
  %fadd.1 = fadd float %phi.11, %phi.12
  br label %BB_04f0

BB_04f0:                                          ; preds = %BB_800004e8, %BB_04e8
  %phi.16 = phi float [ %fadd.1, %BB_800004e8 ], [ %phi.11, %BB_04e8 ]
  %isetrp_cmp1.12 = icmp uge i32 %phi.15, 16
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0500

BB_0500:                                          ; preds = %BB_04f0
  %42 = zext i1 %cond_not.8 to i32
  %43 = icmp ne i32 %42, 0
  br i1 %43, label %BB_80000500, label %BB_0508

BB_80000500:                                      ; preds = %BB_0500
  store volatile float %phi.16, ptr addrspace(3) %.213, align 4
  br label %BB_0508

BB_0508:                                          ; preds = %BB_80000500, %BB_0500
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0528

BB_0528:                                          ; preds = %BB_0508
  %cond_not.13 = xor i1 %isetrp_cmp1.11, true
  %phi_cast_R156_bitcast = bitcast i32 %i2i_abs to float
  br i1 %cond_not.13, label %BB_80000528, label %BB_0530

BB_80000528:                                      ; preds = %BB_0528
  %lds.6 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_0530

BB_0530:                                          ; preds = %BB_80000528, %BB_0528
  %phi.17 = phi float [ %lds.6, %BB_80000528 ], [ %phi_cast_R156_bitcast, %BB_0528 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0540

BB_0540:                                          ; preds = %BB_0530
  %44 = zext i1 %cond_not.13 to i32
  %45 = icmp ne i32 %44, 0
  br i1 %45, label %BB_80000540, label %BB_0548

BB_80000540:                                      ; preds = %BB_0540
  %lds_addr_memaddr_offset_add.2 = add i32 %legacy_result.15, 256
  %lds_shared_addr_winoff.7 = and i32 %lds_addr_memaddr_offset_add.2, 16777215
  %.358 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.7
  %lds.7 = load volatile float, ptr addrspace(3) %.358, align 4
  br label %BB_0548

BB_0548:                                          ; preds = %BB_80000540, %BB_0540
  %phi.18 = phi float [ %lds.7, %BB_80000540 ], [ %phi.10, %BB_0540 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0550

BB_0550:                                          ; preds = %BB_0548
  %46 = zext i1 %isetrp_cmp1.12 to i32
  %47 = icmp ne i32 %46, 0
  br i1 %47, label %BB_80000550, label %BB_0558

BB_80000550:                                      ; preds = %BB_0550
  %legacy_a_wide.31 = zext i32 %phi.15 to i64
  %legacy_sum.31 = add i64 %legacy_a_wide.31, 4294967280
  %legacy_result.31 = trunc i64 %legacy_sum.31 to i32
  br label %BB_0558

BB_0558:                                          ; preds = %BB_80000550, %BB_0550
  %phi.19 = phi i32 [ %legacy_result.31, %BB_80000550 ], [ %phi.15, %BB_0550 ]
  br i1 %cond_not.2, label %BB_80000558, label %BB_0560

BB_80000558:                                      ; preds = %BB_0558
  %legacy_a_wide.32 = zext i32 %phi.19 to i64
  %legacy_a_complement.10 = xor i64 %legacy_a_wide.32, 4294967295
  %legacy_a_negate.10 = add i64 %legacy_a_complement.10, 1
  %legacy_result.32 = trunc i64 %legacy_a_negate.10 to i32
  br label %BB_0560

BB_0560:                                          ; preds = %BB_80000558, %BB_0558
  %phi.20 = phi i32 [ %legacy_result.32, %BB_80000558 ], [ %phi.19, %BB_0558 ]
  %isetrp_cmp1.13 = icmp ne i32 %phi.20, 0
  br label %BB_0568

BB_0568:                                          ; preds = %BB_0560
  %48 = zext i1 %cond_not.13 to i32
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %BB_80000568, label %BB_0570

BB_80000568:                                      ; preds = %BB_0568
  %fadd.2 = fadd float %phi.17, %phi.18
  br label %BB_0570

BB_0570:                                          ; preds = %BB_80000568, %BB_0568
  %phi.21 = phi float [ %fadd.2, %BB_80000568 ], [ %phi.17, %BB_0568 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0578

BB_0578:                                          ; preds = %BB_0570
  %50 = zext i1 %cond_not.13 to i32
  %51 = icmp ne i32 %50, 0
  br i1 %51, label %BB_80000578, label %BB_0580

BB_80000578:                                      ; preds = %BB_0578
  store volatile float %phi.21, ptr addrspace(3) %.213, align 4
  br label %BB_0580

BB_0580:                                          ; preds = %BB_80000578, %BB_0578
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_05b0

BB_05b0:                                          ; preds = %BB_0580
  %cond_not.18 = xor i1 %isetrp_cmp1.13, true
  br i1 %cond_not.18, label %BB_800005b0, label %BB_05b8

BB_800005b0:                                      ; preds = %BB_05b0
  %lds.8 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_05b8

BB_05b8:                                          ; preds = %BB_800005b0, %BB_05b0
  %phi.22 = phi float [ %lds.8, %BB_800005b0 ], [ %phi.18, %BB_05b0 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_05c8

BB_05c8:                                          ; preds = %BB_05b8
  %52 = zext i1 %cond_not.18 to i32
  %53 = icmp ne i32 %52, 0
  br i1 %53, label %BB_800005c8, label %BB_05d0

BB_800005c8:                                      ; preds = %BB_05c8
  %lds_addr_memaddr_offset_add.3 = add i32 %legacy_result.15, 512
  %lds_shared_addr_winoff.9 = and i32 %lds_addr_memaddr_offset_add.3, 16777215
  %.379 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.9
  %lds.9 = load volatile float, ptr addrspace(3) %.379, align 4
  br label %BB_05d0

BB_05d0:                                          ; preds = %BB_800005c8, %BB_05c8
  %phi.23 = phi float [ %lds.9, %BB_800005c8 ], [ %phi.16, %BB_05c8 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_05d8

BB_05d8:                                          ; preds = %BB_05d0
  %54 = zext i1 %cond_not.18 to i32
  %55 = icmp ne i32 %54, 0
  br i1 %55, label %BB_800005d8, label %BB_05e0

BB_800005d8:                                      ; preds = %BB_05d8
  %fadd.3 = fadd float %phi.22, %phi.23
  br label %BB_05e0

BB_05e0:                                          ; preds = %BB_800005d8, %BB_05d8
  %phi.24 = phi float [ %fadd.3, %BB_800005d8 ], [ %phi.22, %BB_05d8 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_05e8

BB_05e8:                                          ; preds = %BB_05e0
  %56 = zext i1 %cond_not.18 to i32
  %57 = icmp ne i32 %56, 0
  br i1 %57, label %BB_800005e8, label %BB_05f0

BB_800005e8:                                      ; preds = %BB_05e8
  store volatile float %phi.24, ptr addrspace(3) %.213, align 4
  br label %BB_05f0

BB_05f0:                                          ; preds = %BB_800005e8, %BB_05e8
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %lds.10 = load volatile i32, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  store i32 %lds.10, ptr addrspace(1) %"R138:R74_addr_ptr", align 4
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %legacy_taken_mask = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_entry_mask, i1 %isetrp_cmp1)
  %.391 = xor i32 %legacy_taken_mask, -1
  %legacy_fallthrough_mask = and i32 %legacy_entry_mask, %.391
  %legacy_path_mask = select i1 %isetrp_cmp1, i32 %legacy_taken_mask, i32 %legacy_fallthrough_mask
  br label %BB_06a0

BB_06a0:                                          ; preds = %BB_05f0
  %58 = zext i1 %isetrp_cmp1 to i32
  %59 = icmp ne i32 %58, 0
  br i1 %59, label %BB_800006a0, label %BB_06a8

BB_06a8:                                          ; preds = %BB_06a0
  %xmad_src1 = load i32, ptr %.23, align 4
  %.398 = trunc i32 %xmad_src1 to i16
  %.399 = zext i16 %.398 to i32
  %xmad_product.38 = mul i32 %.67, %.399
  %xmad_sum.38 = add i32 %xmad_product.38, %tid_y
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask)
  %lds_addr_memaddr_offset_add.4 = add i32 %shl, 64
  %lds_shared_addr_winoff.11 = and i32 %lds_addr_memaddr_offset_add.4, 16777215
  %.400 = getelementptr inbounds [1088 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.11
  %lds.11 = load volatile i32, ptr addrspace(3) %.400, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask)
  %xmad_src1.1 = load i32, ptr %.23, align 4
  %.405 = lshr i32 %xmad_src1.1, 16
  %.406 = trunc i32 %.405 to i16
  %.407 = zext i16 %.406 to i32
  %xmad_product.39 = mul i32 %.67, %.407
  %.408 = and i32 %xmad_product.39, 65535
  %.409 = shl i32 %xmad_src1.1, 16
  %xmad_merge.2 = or i32 %.408, %.409
  %.413 = lshr i32 %xmad_merge.2, 16
  %.414 = trunc i32 %.413 to i16
  %.415 = zext i16 %.414 to i32
  %xmad_product.40 = mul i32 %.61, %.415
  %xmad_psl.2 = shl i32 %xmad_product.40, 16
  %.416 = shl i32 %xmad_merge.2, 16
  %xmad_cbcc.2 = add i32 %xmad_sum.38, %.416
  %xmad_sum.40 = add i32 %xmad_psl.2, %xmad_cbcc.2
  %shr_result.2 = ashr i32 %xmad_sum.40, 30
  %legacy_a_shift.13 = shl i32 %xmad_sum.40, 2
  %legacy_b.5 = load i32, ptr %.17, align 4
  %.420 = getelementptr inbounds [368 x i8], ptr %param_local, i64 0, i64 348
  %legacy_b.6 = load i32, ptr %.420, align 4
  %60 = zext i32 %legacy_a_shift.13 to i64
  %61 = zext i32 %legacy_b.5 to i64
  %62 = zext i32 %shr_result.2 to i64
  %63 = shl i64 %62, 32
  %64 = zext i32 %legacy_b.6 to i64
  %65 = shl i64 %64, 32
  %66 = add i64 %60, %61
  %67 = add i64 %66, %63
  %68 = add i64 %67, %65
  %"R142:R103_addr_ptr" = inttoptr i64 %68 to ptr addrspace(1)
  store i32 %lds.11, ptr addrspace(1) %"R142:R103_addr_ptr", align 4
  ret void

BB_800006a0:                                      ; preds = %BB_06a0
  ret void
}

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.vote.ballot.sync(i32, i1) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rcp.approx.ftz.f(float) #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #3

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #3

; Function Attrs: nocallback nounwind
declare void @llvm.nvvm.membar.cta() #4

attributes #0 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #3 = { convergent nocallback nounwind }
attributes #4 = { nocallback nounwind }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z22bpnn_layerforward_CUDAPfS_S_S_ii, !"kernel", i32 1}
