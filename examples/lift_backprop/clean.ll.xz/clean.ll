; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/backprop.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/backprop.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [1088 x i8], align 16
@const_mem = internal global [5 x [368 x i8]] zeroinitializer, align 16

define void @_Z22bpnn_layerforward_CUDAPfS_S_S_ii(i64 %arg_320, i64 %arg_328, i64 %arg_336, i64 %arg_344, i32 %arg_352, i32 %arg_356) {
EntryBB_0000:
  %param_local = alloca [368 x i8], align 16
  %.8 = getelementptr inbounds nuw i8, ptr %param_local, i64 320
  store i64 %arg_320, ptr %.8, align 64
  %.11 = getelementptr inbounds nuw i8, ptr %param_local, i64 328
  store i64 %arg_328, ptr %.11, align 8
  %.14 = getelementptr inbounds nuw i8, ptr %param_local, i64 336
  store i64 %arg_336, ptr %.14, align 16
  %.17 = getelementptr inbounds nuw i8, ptr %param_local, i64 344
  store i64 %arg_344, ptr %.17, align 8
  %.20 = getelementptr inbounds nuw i8, ptr %param_local, i64 352
  store i32 %arg_352, ptr %.20, align 32
  %.23 = getelementptr inbounds nuw i8, ptr %param_local, i64 356
  store i32 %arg_356, ptr %.23, align 4
  %legacy_entry_mask = call i32 @llvm.nvvm.vote.ballot.sync(i32 -1, i1 true)
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %legacy_sum = add i32 %arg_356, 1
  %tid_y = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %legacy_a_shift = shl i32 %arg_356, 4
  %legacy_sum.1 = add i32 %legacy_a_shift, 16
  %i2f_directed = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 16) #5
  %ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %isetrp_cmp1 = icmp ne i32 %tid_x, 0
  %mufu_rcp = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed)
  %cast = bitcast float %mufu_rcp to i32
  br i1 %isetrp_cmp1, label %BB_0080, label %BB_80000058

BB_80000058:                                      ; preds = %EntryBB_0000
  %legacy_a_shift.1 = shl i32 %ctaid_y, 4
  %legacy_sum.2 = add i32 %legacy_a_shift.1, %tid_y
  %shr_result = ashr i32 %legacy_sum.2, 30
  %legacy_a_shift.2 = shl i32 %legacy_sum.2, 2
  %legacy_b = load i32, ptr %.8, align 4
  %.33 = getelementptr inbounds nuw i8, ptr %param_local, i64 324
  %legacy_b.1 = load i32, ptr %.33, align 4
  %0 = zext i32 %legacy_a_shift.2 to i64
  %1 = zext i32 %legacy_b to i64
  %2 = zext i32 %shr_result to i64
  %3 = zext i32 %legacy_b.1 to i64
  %4 = add nuw nsw i64 %0, %1
  %5 = add nuw nsw i64 %2, %3
  %6 = shl i64 %5, 32
  %7 = add i64 %6, %4
  %ldg_addr_memaddr_offset_add = add i64 %7, 4
  %"R135:R48_addr_ptr" = inttoptr i64 %ldg_addr_memaddr_offset_add to ptr addrspace(1)
  %ldg = load i32, ptr addrspace(1) %"R135:R48_addr_ptr", align 4
  br label %BB_0080

BB_0080:                                          ; preds = %BB_80000058, %EntryBB_0000
  %phi = phi i32 [ %ldg, %BB_80000058 ], [ 0, %EntryBB_0000 ]
  %legacy_b.2 = load i32, ptr %.23, align 4
  %legacy_sum.5 = add i32 %tid_x, %legacy_b.2
  %.40 = and i32 %legacy_sum, 65535
  %.41 = lshr i32 %tid_y, 16
  %xmad_product = mul i32 %legacy_sum, %.41
  %.49 = and i32 %tid_y, 65535
  %xmad_product.1 = mul nuw i32 %.40, %.49
  %xmad_sum.1 = add i32 %xmad_product.1, %legacy_sum.5
  %.50 = lshr i32 %legacy_sum, 16
  %xmad_product.2 = mul i32 %.50, %tid_y
  %8 = add i32 %xmad_product, %xmad_product.2
  %9 = shl i32 %8, 16
  %xmad_sum.2 = add i32 %9, %xmad_sum.1
  %i2f_directed.1 = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 4) #5
  %.58 = and i32 %legacy_sum.1, 65520
  %.59 = lshr i32 %ctaid_y, 16
  %xmad_product.3 = mul i32 %legacy_sum.1, %.59
  %.67 = and i32 %ctaid_y, 65535
  %xmad_product.4 = mul nuw i32 %.58, %.67
  %xmad_sum.4 = add i32 %xmad_product.4, %xmad_sum.2
  %mufu_rcp.1 = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed.1)
  %cast.1 = bitcast float %mufu_rcp.1 to i32
  %.68 = lshr i32 %legacy_sum.1, 16
  %xmad_product.5 = mul i32 %.68, %ctaid_y
  %10 = add i32 %xmad_product.3, %xmad_product.5
  %11 = shl i32 %10, 16
  %xmad_sum.5 = add i32 %11, %xmad_sum.4
  %shl = shl i32 %tid_y, 2
  %shr_result.1 = ashr i32 %xmad_sum.5, 30
  %legacy_a_shift.3 = shl i32 %xmad_sum.5, 2
  %legacy_b.3 = load i32, ptr %.14, align 4
  %i2f_directed.2 = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 2) #5
  %.78 = getelementptr inbounds nuw i8, ptr %param_local, i64 340
  %legacy_b.4 = load i32, ptr %.78, align 4
  %12 = zext i32 %legacy_a_shift.3 to i64
  %13 = zext i32 %legacy_b.3 to i64
  %14 = zext i32 %shr_result.1 to i64
  %15 = zext i32 %legacy_b.4 to i64
  %16 = add nuw nsw i64 %12, %13
  %17 = add nuw nsw i64 %14, %15
  %18 = shl i64 %17, 32
  %19 = add i64 %18, %16
  %mufu_rcp.2 = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed.2)
  %cast.2 = bitcast float %mufu_rcp.2 to i32
  %legacy_sum.8 = add i32 %cast.2, 268435454
  %cast.3 = bitcast i32 %legacy_sum.8 to float
  %f2i = fptoui float %cast.3 to i32
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1, label %BB_0118, label %BB_80000110

BB_80000110:                                      ; preds = %BB_0080
  %sts_shared_addr_winoff = and i32 %shl, 16777212
  %20 = zext nneg i32 %sts_shared_addr_winoff to i64
  %.83 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %20
  store volatile i32 %phi, ptr addrspace(3) %.83, align 4
  br label %BB_0118

BB_0118:                                          ; preds = %BB_80000110, %BB_0080
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %ldg_addr_memaddr_offset_add.1 = add i64 %19, 8
  %"R138:R74_addr_ptr" = inttoptr i64 %ldg_addr_memaddr_offset_add.1 to ptr addrspace(1)
  %ldg.1 = load i32, ptr addrspace(1) %"R138:R74_addr_ptr", align 4
  %.neg = mul i32 %f2i, -2
  %i2i_abs = call i32 @llvm.abs.i32(i32 %tid_y, i1 false)
  %.87 = and i32 %f2i, 65535
  %.89 = and i32 %.neg, 65534
  %xmad_product.6 = mul nuw i32 %.87, %.89
  %.92 = lshr i32 %.neg, 16
  %xmad_product.7 = mul nuw i32 %.87, %.92
  %.95 = lshr i32 %f2i, 16
  %xmad_product.8 = mul nuw i32 %.95, %.92
  %xmad_sum.8 = add i32 %xmad_product.8, %f2i
  %xmad_product.9 = mul nuw i32 %.95, %.89
  %xmad_chi = lshr i32 %xmad_product.6, 16
  %xmad_sum.9 = add i32 %xmad_product.9, %xmad_chi
  %.106 = zext i32 %xmad_sum.9 to i64
  %.107 = zext i32 %xmad_product.7 to i64
  %.108 = add nuw nsw i64 %.106, %.107
  %.109 = lshr i64 %.108, 16
  %.110 = trunc nuw nsw i64 %.109 to i32
  %legacy_iadd3_rs = add i32 %xmad_sum.8, %.110
  %i2f_directed.3 = call float asm "cvt.rp.f32.u32 $0, $1;", "=f,r"(i32 8) #5
  %legacy_sum.9 = add i32 %cast.1, 268435454
  %cast.4 = bitcast i32 %legacy_sum.9 to float
  %f2i.1 = fptoui float %cast.4 to i32
  %.112 = and i32 %legacy_iadd3_rs, 65535
  %.114 = and i32 %i2i_abs, 65535
  %xmad_product.10 = mul nuw i32 %.112, %.114
  %mufu_rcp.3 = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed.3)
  %cast.5 = bitcast float %mufu_rcp.3 to i32
  %.117 = lshr i32 %i2i_abs, 16
  %xmad_product.11 = mul nuw i32 %.112, %.117
  %legacy_a_shift.4.neg = mul i32 %f2i.1, -4
  %.120 = lshr i32 %legacy_iadd3_rs, 16
  %xmad_product.12 = mul nuw i32 %.120, %.114
  %xmad_chi.1 = lshr i32 %xmad_product.10, 16
  %xmad_sum.12 = add i32 %xmad_product.12, %xmad_chi.1
  %xmad_product.13 = mul nuw i32 %.120, %.117
  %.131 = lshr i32 %f2i.1, 16
  %.134 = lshr i32 %legacy_a_shift.4.neg, 16
  %xmad_product.14 = mul nuw i32 %.131, %.134
  %xmad_sum.14 = add i32 %xmad_product.14, %f2i.1
  %.137 = zext i32 %xmad_sum.12 to i64
  %.138 = zext i32 %xmad_product.11 to i64
  %.139 = add nuw nsw i64 %.137, %.138
  %.140 = lshr i64 %.139, 16
  %.141 = trunc nuw nsw i64 %.140 to i32
  %legacy_iadd3_rs.1 = add i32 %xmad_product.13, %.141
  %.143 = and i32 %f2i.1, 65535
  %.145 = and i32 %legacy_a_shift.4.neg, 65532
  %xmad_product.15 = mul nuw i32 %.143, %.145
  %xmad_product.16 = mul nuw i32 %.143, %.134
  %legacy_sum.11 = add i32 %cast.5, 268435454
  %cast.6 = bitcast i32 %legacy_sum.11 to float
  %f2i.2 = fptoui float %cast.6 to i32
  %21 = shl i32 %legacy_iadd3_rs.1, 1
  %legacy_sum.12 = sub i32 %i2i_abs, %21
  %xmad_product.17 = mul nuw i32 %.131, %.145
  %xmad_chi.2 = lshr i32 %xmad_product.15, 16
  %xmad_sum.17 = add i32 %xmad_product.17, %xmad_chi.2
  %.156 = zext i32 %xmad_sum.17 to i64
  %.157 = zext i32 %xmad_product.16 to i64
  %.158 = add nuw nsw i64 %.156, %.157
  %.159 = lshr i64 %.158, 16
  %.160 = trunc nuw nsw i64 %.159 to i32
  %legacy_iadd3_rs.2 = add i32 %xmad_sum.14, %.160
  %legacy_a_shift.6 = shl i32 %tid_y, 6
  %legacy_sum.13 = add i32 %legacy_a_shift.6, 64
  %legacy_a_shift.7.neg = mul i32 %f2i.2, -8
  %.162 = and i32 %legacy_iadd3_rs.2, 65535
  %xmad_product.18 = mul nuw i32 %.162, %.114
  %legacy_a_shift.8 = shl i32 %tid_x, 2
  %legacy_sum.15 = add i32 %legacy_a_shift.8, %legacy_sum.13
  %xmad_product.19 = mul nuw i32 %.162, %.117
  %.171 = and i32 %f2i.2, 65535
  %.173 = and i32 %legacy_a_shift.7.neg, 65528
  %xmad_product.20 = mul nuw i32 %.171, %.173
  %isetrp_cmp1.1 = icmp ugt i32 %legacy_sum.12, 1
  %legacy_sum.16 = add i32 %legacy_sum.12, -2
  %phi.1 = select i1 %isetrp_cmp1.1, i32 %legacy_sum.16, i32 %legacy_sum.12
  %.177 = lshr i32 %legacy_iadd3_rs.2, 16
  %xmad_product.21 = mul nuw i32 %.177, %.114
  %xmad_chi.3 = lshr i32 %xmad_product.18, 16
  %xmad_sum.21 = add i32 %xmad_product.21, %xmad_chi.3
  %xmad_product.22 = mul nuw i32 %.177, %.117
  %isetrp_cmp1.2 = icmp slt i32 %tid_y, 0
  %.188 = zext i32 %xmad_sum.21 to i64
  %.189 = zext i32 %xmad_product.19 to i64
  %.190 = add nuw nsw i64 %.188, %.189
  %.191 = lshr i64 %.190, 16
  %.192 = trunc nuw nsw i64 %.191 to i32
  %legacy_iadd3_rs.3 = add i32 %xmad_product.22, %.192
  %22 = shl i32 %legacy_iadd3_rs.3, 2
  %legacy_sum.17 = sub i32 %i2i_abs, %22
  %.193 = lshr i32 %f2i.2, 16
  %.196 = lshr i32 %legacy_a_shift.7.neg, 16
  %xmad_product.23 = mul nuw i32 %.193, %.196
  %xmad_sum.23 = add i32 %xmad_product.23, %f2i.2
  %isetrp_cmp1.3 = icmp ugt i32 %phi.1, 1
  %legacy_sum.18 = add i32 %phi.1, -2
  %phi.2 = select i1 %isetrp_cmp1.3, i32 %legacy_sum.18, i32 %phi.1
  %isetrp_cmp1.4 = icmp ugt i32 %legacy_sum.17, 3
  %legacy_a_negate.4 = sub i32 0, %phi.2
  %phi.3 = select i1 %isetrp_cmp1.2, i32 %legacy_a_negate.4, i32 %phi.2
  %isetrp_cmp1.5.not = icmp eq i32 %phi.3, 0
  %legacy_sum.20 = add i32 %cast, 268435454
  %cast.7 = bitcast i32 %legacy_sum.20 to float
  %legacy_sum.21 = add i32 %legacy_sum.17, -4
  %phi.4 = select i1 %isetrp_cmp1.4, i32 %legacy_sum.21, i32 %legacy_sum.17
  %isetrp_cmp1.6 = icmp ugt i32 %phi.4, 3
  %legacy_sum.22 = add i32 %phi.4, -4
  %phi.5 = select i1 %isetrp_cmp1.6, i32 %legacy_sum.22, i32 %phi.4
  %legacy_a_negate.5 = sub i32 0, %phi.5
  %phi.6 = select i1 %isetrp_cmp1.2, i32 %legacy_a_negate.5, i32 %phi.5
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %sts_shared_addr_winoff.1 = and i32 %legacy_sum.15, 16777212
  %23 = zext nneg i32 %sts_shared_addr_winoff.1 to i64
  %.213 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %23
  store volatile i32 %ldg.1, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %lds_shared_addr_winoff = and i32 %shl, 16777212
  %24 = zext nneg i32 %lds_shared_addr_winoff to i64
  %.215 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %24
  %lds = load volatile float, ptr addrspace(3) %.215, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %xmad_product.24 = mul nuw i32 %.171, %.196
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %lds.1 = load volatile float, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %xmad_product.25 = mul nuw i32 %.193, %.173
  %xmad_chi.4 = lshr i32 %xmad_product.20, 16
  %xmad_sum.25 = add i32 %xmad_product.25, %xmad_chi.4
  %.227 = zext i32 %xmad_sum.25 to i64
  %.228 = zext i32 %xmad_product.24 to i64
  %.229 = add nuw nsw i64 %.227, %.228
  %.230 = lshr i64 %.229, 16
  %.231 = trunc nuw nsw i64 %.230 to i32
  %legacy_iadd3_rs.4 = add i32 %xmad_sum.23, %.231
  %f2i.3 = fptoui float %cast.7 to i32
  %.233 = and i32 %legacy_iadd3_rs.4, 65535
  %xmad_product.26 = mul nuw i32 %.233, %.114
  %.236 = lshr i32 %legacy_iadd3_rs.4, 16
  %xmad_product.27 = mul nuw i32 %.236, %.117
  %xmad_product.28 = mul nuw i32 %.236, %.114
  %xmad_chi.5 = lshr i32 %xmad_product.26, 16
  %xmad_sum.28 = add i32 %xmad_product.28, %xmad_chi.5
  %legacy_a_shift.10.neg = mul i32 %f2i.3, -16
  %fmul = fmul float %lds, %lds.1
  %xmad_product.29 = mul nuw i32 %.233, %.117
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  store volatile float %fmul, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.255 = and i32 %f2i.3, 65535
  %.256 = lshr i32 %legacy_a_shift.10.neg, 16
  %xmad_product.30 = mul nuw i32 %.255, %.256
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %.259 = zext i32 %xmad_sum.28 to i64
  %.260 = zext i32 %xmad_product.29 to i64
  %.261 = add nuw nsw i64 %.259, %.260
  %.262 = lshr i64 %.261, 16
  %.263 = trunc nuw nsw i64 %.262 to i32
  %legacy_iadd3_rs.5 = add i32 %xmad_product.27, %.263
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %phi_cast_R28_bitcast = bitcast i32 %legacy_iadd3_rs.4 to float
  br i1 %isetrp_cmp1.5.not, label %BB_800003b8, label %BB_03c0

BB_800003b8:                                      ; preds = %BB_0118
  %lds.2 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_03c0

BB_03c0:                                          ; preds = %BB_800003b8, %BB_0118
  %phi.7 = phi float [ %lds.2, %BB_800003b8 ], [ %phi_cast_R28_bitcast, %BB_0118 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.271 = and i32 %legacy_a_shift.10.neg, 65520
  %xmad_product.31 = mul nuw i32 %.255, %.271
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1.5.not, label %BB_800003d8, label %BB_03e0

BB_800003d8:                                      ; preds = %BB_03c0
  %lds_addr_memaddr_offset_add = add i32 %legacy_sum.15, 64
  %lds_shared_addr_winoff.3 = and i32 %lds_addr_memaddr_offset_add, 16777212
  %25 = zext nneg i32 %lds_shared_addr_winoff.3 to i64
  %.274 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %25
  %lds.3 = load volatile float, ptr addrspace(3) %.274, align 4
  br label %BB_03e0

BB_03e0:                                          ; preds = %BB_800003d8, %BB_03c0
  %phi.8 = phi float [ %lds.3, %BB_800003d8 ], [ %cast.7, %BB_03c0 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.276 = lshr i32 %f2i.3, 16
  %xmad_product.32 = mul nuw i32 %.276, %.256
  %xmad_sum.32 = add i32 %xmad_product.32, %f2i.3
  %26 = shl i32 %legacy_iadd3_rs.5, 3
  %legacy_sum.25 = sub i32 %i2i_abs, %26
  %xmad_product.33 = mul nuw i32 %.276, %.271
  %xmad_chi.6 = lshr i32 %xmad_product.31, 16
  %xmad_sum.33 = add i32 %xmad_product.33, %xmad_chi.6
  %.287 = zext i32 %xmad_sum.33 to i64
  %.288 = zext i32 %xmad_product.30 to i64
  %.289 = add nuw nsw i64 %.287, %.288
  %.290 = lshr i64 %.289, 16
  %.291 = trunc nuw nsw i64 %.290 to i32
  %legacy_iadd3_rs.6 = add i32 %xmad_sum.32, %.291
  %.293 = and i32 %legacy_iadd3_rs.6, 65535
  %xmad_product.34 = mul nuw i32 %.293, %.114
  %isetrp_cmp1.7 = icmp ugt i32 %legacy_sum.25, 7
  %legacy_sum.26 = add i32 %legacy_sum.25, -8
  %phi.9 = select i1 %isetrp_cmp1.7, i32 %legacy_sum.26, i32 %legacy_sum.25
  %isetrp_cmp1.8.not = icmp eq i32 %phi.6, 0
  %fadd = fadd float %phi.7, %phi.8
  %phi.10 = select i1 %isetrp_cmp1.5.not, float %fadd, float %phi.7
  %xmad_product.35 = mul nuw i32 %.293, %.117
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1.5.not, label %BB_80000440, label %BB_0448

BB_80000440:                                      ; preds = %BB_03e0
  store volatile float %phi.10, ptr addrspace(3) %.213, align 4
  br label %BB_0448

BB_0448:                                          ; preds = %BB_80000440, %BB_03e0
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %.312 = lshr i32 %legacy_iadd3_rs.6, 16
  %xmad_product.36 = mul nuw i32 %.312, %.114
  %xmad_chi.7 = lshr i32 %xmad_product.34, 16
  %xmad_sum.36 = add i32 %xmad_product.36, %xmad_chi.7
  %xmad_product.37 = mul nuw i32 %.312, %.117
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %isetrp_cmp1.9 = icmp ugt i32 %phi.9, 7
  %.323 = zext i32 %xmad_sum.36 to i64
  %.324 = zext i32 %xmad_product.35 to i64
  %.325 = add nuw nsw i64 %.323, %.324
  %.326 = lshr i64 %.325, 16
  %.327 = trunc nuw nsw i64 %.326 to i32
  %legacy_iadd3_rs.7 = add i32 %xmad_product.37, %.327
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %phi_cast_R121_bitcast = bitcast i32 %xmad_product.35 to float
  br i1 %isetrp_cmp1.8.not, label %BB_80000490, label %BB_0498

BB_80000490:                                      ; preds = %BB_0448
  %lds.4 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_0498

BB_0498:                                          ; preds = %BB_80000490, %BB_0448
  %phi.11 = phi float [ %lds.4, %BB_80000490 ], [ %phi_cast_R121_bitcast, %BB_0448 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %27 = shl i32 %legacy_iadd3_rs.7, 4
  %legacy_sum.27 = sub i32 %i2i_abs, %27
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %phi_cast_R54_bitcast = bitcast i32 %xmad_sum.36 to float
  br i1 %isetrp_cmp1.8.not, label %BB_800004b0, label %BB_04b8

BB_800004b0:                                      ; preds = %BB_0498
  %lds_addr_memaddr_offset_add.1 = add i32 %legacy_sum.15, 128
  %lds_shared_addr_winoff.5 = and i32 %lds_addr_memaddr_offset_add.1, 16777212
  %28 = zext nneg i32 %lds_shared_addr_winoff.5 to i64
  %.334 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %28
  %lds.5 = load volatile float, ptr addrspace(3) %.334, align 4
  br label %BB_04b8

BB_04b8:                                          ; preds = %BB_800004b0, %BB_0498
  %phi.12 = phi float [ %lds.5, %BB_800004b0 ], [ %phi_cast_R54_bitcast, %BB_0498 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %legacy_sum.28 = add i32 %phi.9, -8
  %phi.13 = select i1 %isetrp_cmp1.9, i32 %legacy_sum.28, i32 %phi.9
  %isetrp_cmp1.10 = icmp ugt i32 %legacy_sum.27, 15
  %legacy_a_negate.9 = sub i32 0, %phi.13
  %phi.14 = select i1 %isetrp_cmp1.2, i32 %legacy_a_negate.9, i32 %phi.13
  %legacy_sum.30 = add i32 %legacy_sum.27, -16
  %phi.15 = select i1 %isetrp_cmp1.10, i32 %legacy_sum.30, i32 %legacy_sum.27
  %isetrp_cmp1.11.not = icmp eq i32 %phi.14, 0
  %fadd.1 = fadd float %phi.11, %phi.12
  %phi.16 = select i1 %isetrp_cmp1.8.not, float %fadd.1, float %phi.11
  %isetrp_cmp1.12 = icmp ugt i32 %phi.15, 15
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1.8.not, label %BB_80000500, label %BB_0508

BB_80000500:                                      ; preds = %BB_04b8
  store volatile float %phi.16, ptr addrspace(3) %.213, align 4
  br label %BB_0508

BB_0508:                                          ; preds = %BB_80000500, %BB_04b8
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %phi_cast_R156_bitcast = bitcast i32 %i2i_abs to float
  br i1 %isetrp_cmp1.11.not, label %BB_80000528, label %BB_0530

BB_80000528:                                      ; preds = %BB_0508
  %lds.6 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_0530

BB_0530:                                          ; preds = %BB_80000528, %BB_0508
  %phi.17 = phi float [ %lds.6, %BB_80000528 ], [ %phi_cast_R156_bitcast, %BB_0508 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1.11.not, label %BB_80000540, label %BB_0548

BB_80000540:                                      ; preds = %BB_0530
  %lds_addr_memaddr_offset_add.2 = add i32 %legacy_sum.15, 256
  %lds_shared_addr_winoff.7 = and i32 %lds_addr_memaddr_offset_add.2, 16777212
  %29 = zext nneg i32 %lds_shared_addr_winoff.7 to i64
  %.358 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %29
  %lds.7 = load volatile float, ptr addrspace(3) %.358, align 4
  br label %BB_0548

BB_0548:                                          ; preds = %BB_80000540, %BB_0530
  %phi.18 = phi float [ %lds.7, %BB_80000540 ], [ %phi.10, %BB_0530 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %legacy_sum.31 = add i32 %phi.15, -16
  %phi.19 = select i1 %isetrp_cmp1.12, i32 %legacy_sum.31, i32 %phi.15
  %legacy_a_negate.10 = sub i32 0, %phi.19
  %phi.20 = select i1 %isetrp_cmp1.2, i32 %legacy_a_negate.10, i32 %phi.19
  %isetrp_cmp1.13.not = icmp eq i32 %phi.20, 0
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1.11.not, label %BB_80000578, label %BB_0580

BB_80000578:                                      ; preds = %BB_0548
  %fadd.2 = fadd float %phi.17, %phi.18
  store volatile float %fadd.2, ptr addrspace(3) %.213, align 4
  br label %BB_0580

BB_0580:                                          ; preds = %BB_80000578, %BB_0548
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %30 = zext i1 %isetrp_cmp1.13.not to i32
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %BB_800005b0, label %BB_05b8

BB_800005b0:                                      ; preds = %BB_0580
  %lds.8 = load volatile float, ptr addrspace(3) %.213, align 4
  br label %BB_05b8

BB_05b8:                                          ; preds = %BB_800005b0, %BB_0580
  %phi.22 = phi float [ %lds.8, %BB_800005b0 ], [ %phi.18, %BB_0580 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1.13.not, label %BB_800005c8, label %BB_05d0

BB_800005c8:                                      ; preds = %BB_05b8
  %lds_addr_memaddr_offset_add.3 = add i32 %legacy_sum.15, 512
  %lds_shared_addr_winoff.9 = and i32 %lds_addr_memaddr_offset_add.3, 16777212
  %32 = zext nneg i32 %lds_shared_addr_winoff.9 to i64
  %.379 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %32
  %lds.9 = load volatile float, ptr addrspace(3) %.379, align 4
  br label %BB_05d0

BB_05d0:                                          ; preds = %BB_800005c8, %BB_05b8
  %phi.23 = phi float [ %lds.9, %BB_800005c8 ], [ %phi.16, %BB_05b8 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br i1 %isetrp_cmp1.13.not, label %BB_800005e8, label %BB_05f0

BB_800005e8:                                      ; preds = %BB_05d0
  %fadd.3 = fadd float %phi.22, %phi.23
  store volatile float %fadd.3, ptr addrspace(3) %.213, align 4
  br label %BB_05f0

BB_05f0:                                          ; preds = %BB_800005e8, %BB_05d0
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  %lds.10 = load volatile i32, ptr addrspace(3) %.213, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  store i32 %lds.10, ptr addrspace(1) %"R138:R74_addr_ptr", align 4
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %legacy_taken_mask = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_entry_mask, i1 %isetrp_cmp1)
  %33 = zext i1 %isetrp_cmp1 to i32
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %common.ret, label %BB_06a8

common.ret:                                       ; preds = %BB_05f0, %BB_06a8
  ret void

BB_06a8:                                          ; preds = %BB_05f0
  %.391 = xor i32 %legacy_taken_mask, -1
  %legacy_fallthrough_mask = and i32 %legacy_entry_mask, %.391
  %xmad_src1 = load i32, ptr %.23, align 4
  %.399 = and i32 %xmad_src1, 65535
  %xmad_product.38 = mul nuw i32 %.67, %.399
  %xmad_sum.38 = add i32 %xmad_product.38, %tid_y
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_fallthrough_mask)
  %lds_addr_memaddr_offset_add.4 = add i32 %shl, 64
  %lds_shared_addr_winoff.11 = and i32 %lds_addr_memaddr_offset_add.4, 16777212
  %35 = zext nneg i32 %lds_shared_addr_winoff.11 to i64
  %.400 = getelementptr inbounds nuw [1088 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %35
  %lds.11 = load volatile i32, ptr addrspace(3) %.400, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_fallthrough_mask)
  %xmad_src1.1 = load i32, ptr %.23, align 4
  %.405 = lshr i32 %xmad_src1.1, 16
  %xmad_product.39 = mul i32 %ctaid_y, %.405
  %xmad_product.40 = mul i32 %.59, %xmad_src1.1
  %36 = add i32 %xmad_product.39, %xmad_product.40
  %37 = shl i32 %36, 16
  %xmad_sum.40 = add i32 %37, %xmad_sum.38
  %shr_result.2 = ashr i32 %xmad_sum.40, 30
  %legacy_a_shift.13 = shl i32 %xmad_sum.40, 2
  %legacy_b.5 = load i32, ptr %.17, align 4
  %.420 = getelementptr inbounds nuw i8, ptr %param_local, i64 348
  %legacy_b.6 = load i32, ptr %.420, align 4
  %38 = zext i32 %legacy_a_shift.13 to i64
  %39 = zext i32 %legacy_b.5 to i64
  %40 = zext i32 %shr_result.2 to i64
  %41 = zext i32 %legacy_b.6 to i64
  %42 = add nuw nsw i64 %38, %39
  %43 = add nuw nsw i64 %40, %41
  %44 = shl i64 %43, 32
  %45 = add i64 %44, %42
  %"R142:R103_addr_ptr" = inttoptr i64 %45 to ptr addrspace(1)
  store i32 %lds.11, ptr addrspace(1) %"R142:R103_addr_ptr", align 4
  br label %common.ret
}

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.vote.ballot.sync(i32, i1) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rcp.approx.ftz.f(float) #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #3

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #3

; Function Attrs: nocallback nounwind
declare void @llvm.nvvm.membar.cta() #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #3 = { convergent nocallback nounwind }
attributes #4 = { nocallback nounwind }
attributes #5 = { nounwind }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z22bpnn_layerforward_CUDAPfS_S_S_ii, !"kernel", i32 1}
