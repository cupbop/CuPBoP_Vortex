; ModuleID = "/tmp/culifter-sm52-10787/round14/backprop"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [1088 x i8], align 16
define void @"_Z22bpnn_layerforward_CUDAPfS_S_S_ii"(i64 %"arg_320", i64 %"arg_328", i64 %"arg_336", i64 %"arg_344", i32 %"arg_352", i32 %"arg_356")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [368 x i8], align 16
  %".8" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 320
  %".9" = bitcast i8* %".8" to i64*
  store i64 %"arg_320", i64* %".9", align 64
  %".11" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 328
  %".12" = bitcast i8* %".11" to i64*
  store i64 %"arg_328", i64* %".12", align 8
  %".14" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 336
  %".15" = bitcast i8* %".14" to i64*
  store i64 %"arg_336", i64* %".15", align 16
  %".17" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 344
  %".18" = bitcast i8* %".17" to i64*
  store i64 %"arg_344", i64* %".18", align 8
  %".20" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 352
  %".21" = bitcast i8* %".20" to i32*
  store i32 %"arg_352", i32* %".21", align 32
  %".23" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 356
  %".24" = bitcast i8* %".23" to i32*
  store i32 %"arg_356", i32* %".24", align 4
  %"legacy_entry_mask" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 4294967295, i1 1)
  %".26" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 356
  %".27" = bitcast i8* %".26" to i32*
  %"mov" = load i32, i32* %".27"
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"legacy_a_wide" = zext i32 %"mov" to i64
  %"legacy_b_wide" = zext i32 1 to i64
  %"legacy_sum" = add i64 %"legacy_a_wide", %"legacy_b_wide"
  %"legacy_result" = trunc i64 %"legacy_sum" to i32
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"legacy_a_shift" = shl i32 %"mov", 4
  %"legacy_a_wide.1" = zext i32 %"legacy_a_shift" to i64
  %"legacy_b_wide.1" = zext i32 16 to i64
  %"legacy_sum.1" = add i64 %"legacy_a_wide.1", %"legacy_b_wide.1"
  %"legacy_result.1" = trunc i64 %"legacy_sum.1" to i32
  %"i2f_directed" = call float asm  "cvt.rp.f32.u32 $0, $1;", "=f,r"
(i32 16)
  %"ctaid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"mufu_rcp" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"i2f_directed")
  %"cast" = bitcast float %"mufu_rcp" to i32
  br label %"BB_0058"
BB_0058:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000058", label %"BB_0080"
BB_80000058:
  %"legacy_a_shift.1" = shl i32 %"ctaid_y", 4
  %"legacy_a_wide.2" = zext i32 %"legacy_a_shift.1" to i64
  %"legacy_b_wide.2" = zext i32 %"tid_y" to i64
  %"legacy_sum.2" = add i64 %"legacy_a_wide.2", %"legacy_b_wide.2"
  %"legacy_result.2" = trunc i64 %"legacy_sum.2" to i32
  %"shr_overflow" = icmp ugt i32 30, 31
  %"shr_clamp" = select  i1 %"shr_overflow", i32 31, i32 30
  %"shr_result" = ashr i32 %"legacy_result.2", %"shr_clamp"
  %"legacy_a_shift.2" = shl i32 %"legacy_result.2", 2
  %"legacy_a_wide.3" = zext i32 %"legacy_a_shift.2" to i64
  %".30" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 320
  %".31" = bitcast i8* %".30" to i32*
  %"legacy_b" = load i32, i32* %".31"
  %"legacy_b_wide.3" = zext i32 %"legacy_b" to i64
  %"legacy_sum.3" = add i64 %"legacy_a_wide.3", %"legacy_b_wide.3"
  %"legacy_result.3" = trunc i64 %"legacy_sum.3" to i32
  %".32" = lshr i64 %"legacy_sum.3", 32
  %"legacy_cout" = trunc i64 %".32" to i1
  %"P10_to_i32" = zext i1 %"legacy_cout" to i32
  %"legacy_a_wide.4" = zext i32 %"shr_result" to i64
  %".33" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 324
  %".34" = bitcast i8* %".33" to i32*
  %"legacy_b.1" = load i32, i32* %".34"
  %"legacy_b_wide.4" = zext i32 %"legacy_b.1" to i64
  %"legacy_sum.4" = add i64 %"legacy_a_wide.4", %"legacy_b_wide.4"
  %"legacy_cin_trunc" = trunc i32 %"P10_to_i32" to i1
  %".35" = zext i1 %"legacy_cin_trunc" to i64
  %"legacy_sum_cin" = add i64 %"legacy_sum.4", %".35"
  %"legacy_result.4" = trunc i64 %"legacy_sum_cin" to i32
  %"ldg_addr_r0_ext" = zext i32 %"legacy_result.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"legacy_result.4" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 4
  %"R135:R48_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R135:R48_addr_ptr"
  br label %"BB_0080"
BB_0080:
  %"phi" = phi  i32 [%"ldg", %"BB_80000058"], [0, %"BB_0058"]
  %"legacy_a_wide.5" = zext i32 %"tid_x" to i64
  %".37" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 356
  %".38" = bitcast i8* %".37" to i32*
  %"legacy_b.2" = load i32, i32* %".38"
  %"legacy_b_wide.5" = zext i32 %"legacy_b.2" to i64
  %"legacy_sum.5" = add i64 %"legacy_a_wide.5", %"legacy_b_wide.5"
  %"legacy_result.5" = trunc i64 %"legacy_sum.5" to i32
  %".39" = trunc i32 %"legacy_result" to i16
  %".40" = zext i16 %".39" to i32
  %".41" = lshr i32 %"tid_y", 16
  %".42" = trunc i32 %".41" to i16
  %".43" = zext i16 %".42" to i32
  %"xmad_product" = mul i32 %".40", %".43"
  %"xmad_sum" = add i32 %"xmad_product", 0
  %".44" = and i32 %"xmad_sum", 65535
  %".45" = shl i32 %"tid_y", 16
  %"xmad_merge" = or i32 %".44", %".45"
  %".46" = trunc i32 %"legacy_result" to i16
  %".47" = zext i16 %".46" to i32
  %".48" = trunc i32 %"tid_y" to i16
  %".49" = zext i16 %".48" to i32
  %"xmad_product.1" = mul i32 %".47", %".49"
  %"xmad_sum.1" = add i32 %"xmad_product.1", %"legacy_result.5"
  %".50" = lshr i32 %"legacy_result", 16
  %".51" = trunc i32 %".50" to i16
  %".52" = zext i16 %".51" to i32
  %".53" = lshr i32 %"xmad_merge", 16
  %".54" = trunc i32 %".53" to i16
  %".55" = zext i16 %".54" to i32
  %"xmad_product.2" = mul i32 %".52", %".55"
  %"xmad_psl" = shl i32 %"xmad_product.2", 16
  %".56" = shl i32 %"xmad_merge", 16
  %"xmad_cbcc" = add i32 %"xmad_sum.1", %".56"
  %"xmad_sum.2" = add i32 %"xmad_psl", %"xmad_cbcc"
  %"i2f_directed.1" = call float asm  "cvt.rp.f32.u32 $0, $1;", "=f,r"
(i32 4)
  %".57" = trunc i32 %"legacy_result.1" to i16
  %".58" = zext i16 %".57" to i32
  %".59" = lshr i32 %"ctaid_y", 16
  %".60" = trunc i32 %".59" to i16
  %".61" = zext i16 %".60" to i32
  %"xmad_product.3" = mul i32 %".58", %".61"
  %"xmad_sum.3" = add i32 %"xmad_product.3", 0
  %".62" = and i32 %"xmad_sum.3", 65535
  %".63" = shl i32 %"ctaid_y", 16
  %"xmad_merge.1" = or i32 %".62", %".63"
  %".64" = trunc i32 %"legacy_result.1" to i16
  %".65" = zext i16 %".64" to i32
  %".66" = trunc i32 %"ctaid_y" to i16
  %".67" = zext i16 %".66" to i32
  %"xmad_product.4" = mul i32 %".65", %".67"
  %"xmad_sum.4" = add i32 %"xmad_product.4", %"xmad_sum.2"
  %"mufu_rcp.1" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"i2f_directed.1")
  %"cast.1" = bitcast float %"mufu_rcp.1" to i32
  %".68" = lshr i32 %"legacy_result.1", 16
  %".69" = trunc i32 %".68" to i16
  %".70" = zext i16 %".69" to i32
  %".71" = lshr i32 %"xmad_merge.1", 16
  %".72" = trunc i32 %".71" to i16
  %".73" = zext i16 %".72" to i32
  %"xmad_product.5" = mul i32 %".70", %".73"
  %"xmad_psl.1" = shl i32 %"xmad_product.5", 16
  %".74" = shl i32 %"xmad_merge.1", 16
  %"xmad_cbcc.1" = add i32 %"xmad_sum.4", %".74"
  %"xmad_sum.5" = add i32 %"xmad_psl.1", %"xmad_cbcc.1"
  %"shl" = shl i32 %"tid_y", 2
  %"shr_overflow.1" = icmp ugt i32 30, 31
  %"shr_clamp.1" = select  i1 %"shr_overflow.1", i32 31, i32 30
  %"shr_result.1" = ashr i32 %"xmad_sum.5", %"shr_clamp.1"
  %"legacy_a_shift.3" = shl i32 %"xmad_sum.5", 2
  %"legacy_a_wide.6" = zext i32 %"legacy_a_shift.3" to i64
  %".75" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 336
  %".76" = bitcast i8* %".75" to i32*
  %"legacy_b.3" = load i32, i32* %".76"
  %"legacy_b_wide.6" = zext i32 %"legacy_b.3" to i64
  %"legacy_sum.6" = add i64 %"legacy_a_wide.6", %"legacy_b_wide.6"
  %"legacy_result.6" = trunc i64 %"legacy_sum.6" to i32
  %".77" = lshr i64 %"legacy_sum.6", 32
  %"legacy_cout.1" = trunc i64 %".77" to i1
  %"P11_to_i32" = zext i1 %"legacy_cout.1" to i32
  %"i2f_directed.2" = call float asm  "cvt.rp.f32.u32 $0, $1;", "=f,r"
(i32 2)
  %"legacy_a_wide.7" = zext i32 %"shr_result.1" to i64
  %".78" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 340
  %".79" = bitcast i8* %".78" to i32*
  %"legacy_b.4" = load i32, i32* %".79"
  %"legacy_b_wide.7" = zext i32 %"legacy_b.4" to i64
  %"legacy_sum.7" = add i64 %"legacy_a_wide.7", %"legacy_b_wide.7"
  %"legacy_cin_trunc.1" = trunc i32 %"P11_to_i32" to i1
  %".80" = zext i1 %"legacy_cin_trunc.1" to i64
  %"legacy_sum_cin.1" = add i64 %"legacy_sum.7", %".80"
  %"legacy_result.7" = trunc i64 %"legacy_sum_cin.1" to i32
  %"mufu_rcp.2" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"i2f_directed.2")
  %"cast.2" = bitcast float %"mufu_rcp.2" to i32
  %"legacy_a_wide.8" = zext i32 %"cast.2" to i64
  %"legacy_b_wide.8" = zext i32 268435454 to i64
  %"legacy_sum.8" = add i64 %"legacy_a_wide.8", %"legacy_b_wide.8"
  %"legacy_result.8" = trunc i64 %"legacy_sum.8" to i32
  %"cast.3" = bitcast i32 %"legacy_result.8" to float
  %"f2i" = fptoui float %"cast.3" to i32
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0110"
BB_0110:
  %"cond_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_80000110", label %"BB_0118"
BB_80000110:
  %"sts_shared_addr_winoff" = and i32 %"shl", 16777215
  %".83" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".83" to i32 addrspace(3)*
  store volatile i32 %"phi", i32 addrspace(3)* %"sts_shared_addr_cast"
  br label %"BB_0118"
BB_0118:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  %"ldg_addr_r0_ext.1" = zext i32 %"legacy_result.6" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"legacy_result.7" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.1", 8
  %"R138:R74_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R138:R74_addr_ptr"
  %"iadd3_o2_not" = xor i32 %"f2i", -1
  %"iadd3_o2_neg" = add i32 %"iadd3_o2_not", 1
  %"iadd3_o3_not" = xor i32 %"f2i", -1
  %"iadd3_o3_neg" = add i32 %"iadd3_o3_not", 1
  %"iadd3_n1" = add i32 0, %"iadd3_o2_neg"
  %"iadd3_n2" = add i32 %"iadd3_n1", %"iadd3_o3_neg"
  %"i2i_negative" = icmp slt i32 %"tid_y", 0
  %"i2i_absneg" = sub i32 0, %"tid_y"
  %"i2i_abs" = select  i1 %"i2i_negative", i32 %"i2i_absneg", i32 %"tid_y"
  %".86" = trunc i32 %"f2i" to i16
  %".87" = zext i16 %".86" to i32
  %".88" = trunc i32 %"iadd3_n2" to i16
  %".89" = zext i16 %".88" to i32
  %"xmad_product.6" = mul i32 %".87", %".89"
  %"xmad_sum.6" = add i32 %"xmad_product.6", 0
  %".90" = trunc i32 %"f2i" to i16
  %".91" = zext i16 %".90" to i32
  %".92" = lshr i32 %"iadd3_n2", 16
  %".93" = trunc i32 %".92" to i16
  %".94" = zext i16 %".93" to i32
  %"xmad_product.7" = mul i32 %".91", %".94"
  %"xmad_sum.7" = add i32 %"xmad_product.7", 0
  %".95" = lshr i32 %"f2i", 16
  %".96" = trunc i32 %".95" to i16
  %".97" = zext i16 %".96" to i32
  %".98" = lshr i32 %"iadd3_n2", 16
  %".99" = trunc i32 %".98" to i16
  %".100" = zext i16 %".99" to i32
  %"xmad_product.8" = mul i32 %".97", %".100"
  %"xmad_sum.8" = add i32 %"xmad_product.8", %"f2i"
  %".101" = lshr i32 %"f2i", 16
  %".102" = trunc i32 %".101" to i16
  %".103" = zext i16 %".102" to i32
  %".104" = trunc i32 %"iadd3_n2" to i16
  %".105" = zext i16 %".104" to i32
  %"xmad_product.9" = mul i32 %".103", %".105"
  %"xmad_chi" = lshr i32 %"xmad_sum.6", 16
  %"xmad_sum.9" = add i32 %"xmad_product.9", %"xmad_chi"
  %".106" = zext i32 %"xmad_sum.9" to i64
  %".107" = zext i32 %"xmad_sum.7" to i64
  %".108" = add i64 %".106", %".107"
  %".109" = lshr i64 %".108", 16
  %".110" = trunc i64 %".109" to i32
  %"legacy_iadd3_rs" = add i32 %".110", %"xmad_sum.8"
  %"i2f_directed.3" = call float asm  "cvt.rp.f32.u32 $0, $1;", "=f,r"
(i32 8)
  %"legacy_a_wide.9" = zext i32 %"cast.1" to i64
  %"legacy_b_wide.9" = zext i32 268435454 to i64
  %"legacy_sum.9" = add i64 %"legacy_a_wide.9", %"legacy_b_wide.9"
  %"legacy_result.9" = trunc i64 %"legacy_sum.9" to i32
  %"cast.4" = bitcast i32 %"legacy_result.9" to float
  %"f2i.1" = fptoui float %"cast.4" to i32
  %".111" = trunc i32 %"legacy_iadd3_rs" to i16
  %".112" = zext i16 %".111" to i32
  %".113" = trunc i32 %"i2i_abs" to i16
  %".114" = zext i16 %".113" to i32
  %"xmad_product.10" = mul i32 %".112", %".114"
  %"xmad_sum.10" = add i32 %"xmad_product.10", 0
  %"mufu_rcp.3" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"i2f_directed.3")
  %"cast.5" = bitcast float %"mufu_rcp.3" to i32
  %".115" = trunc i32 %"legacy_iadd3_rs" to i16
  %".116" = zext i16 %".115" to i32
  %".117" = lshr i32 %"i2i_abs", 16
  %".118" = trunc i32 %".117" to i16
  %".119" = zext i16 %".118" to i32
  %"xmad_product.11" = mul i32 %".116", %".119"
  %"xmad_sum.11" = add i32 %"xmad_product.11", 0
  %"legacy_a_shift.4" = shl i32 %"f2i.1", 2
  %"legacy_a_wide.10" = zext i32 %"legacy_a_shift.4" to i64
  %"legacy_a_complement" = xor i64 %"legacy_a_wide.10", 4294967295
  %"legacy_a_negate" = add i64 %"legacy_a_complement", 1
  %"legacy_b_wide.10" = zext i32 0 to i64
  %"legacy_sum.10" = add i64 %"legacy_a_negate", %"legacy_b_wide.10"
  %"legacy_result.10" = trunc i64 %"legacy_sum.10" to i32
  %".120" = lshr i32 %"legacy_iadd3_rs", 16
  %".121" = trunc i32 %".120" to i16
  %".122" = zext i16 %".121" to i32
  %".123" = trunc i32 %"i2i_abs" to i16
  %".124" = zext i16 %".123" to i32
  %"xmad_product.12" = mul i32 %".122", %".124"
  %"xmad_chi.1" = lshr i32 %"xmad_sum.10", 16
  %"xmad_sum.12" = add i32 %"xmad_product.12", %"xmad_chi.1"
  %".125" = lshr i32 %"legacy_iadd3_rs", 16
  %".126" = trunc i32 %".125" to i16
  %".127" = zext i16 %".126" to i32
  %".128" = lshr i32 %"i2i_abs", 16
  %".129" = trunc i32 %".128" to i16
  %".130" = zext i16 %".129" to i32
  %"xmad_product.13" = mul i32 %".127", %".130"
  %"xmad_sum.13" = add i32 %"xmad_product.13", 0
  %".131" = lshr i32 %"f2i.1", 16
  %".132" = trunc i32 %".131" to i16
  %".133" = zext i16 %".132" to i32
  %".134" = lshr i32 %"legacy_result.10", 16
  %".135" = trunc i32 %".134" to i16
  %".136" = zext i16 %".135" to i32
  %"xmad_product.14" = mul i32 %".133", %".136"
  %"xmad_sum.14" = add i32 %"xmad_product.14", %"f2i.1"
  %".137" = zext i32 %"xmad_sum.12" to i64
  %".138" = zext i32 %"xmad_sum.11" to i64
  %".139" = add i64 %".137", %".138"
  %".140" = lshr i64 %".139", 16
  %".141" = trunc i64 %".140" to i32
  %"legacy_iadd3_rs.1" = add i32 %".141", %"xmad_sum.13"
  %".142" = trunc i32 %"f2i.1" to i16
  %".143" = zext i16 %".142" to i32
  %".144" = trunc i32 %"legacy_result.10" to i16
  %".145" = zext i16 %".144" to i32
  %"xmad_product.15" = mul i32 %".143", %".145"
  %"xmad_sum.15" = add i32 %"xmad_product.15", 0
  %".146" = trunc i32 %"f2i.1" to i16
  %".147" = zext i16 %".146" to i32
  %".148" = lshr i32 %"legacy_result.10", 16
  %".149" = trunc i32 %".148" to i16
  %".150" = zext i16 %".149" to i32
  %"xmad_product.16" = mul i32 %".147", %".150"
  %"xmad_sum.16" = add i32 %"xmad_product.16", 0
  %"legacy_a_wide.11" = zext i32 %"cast.5" to i64
  %"legacy_b_wide.11" = zext i32 268435454 to i64
  %"legacy_sum.11" = add i64 %"legacy_a_wide.11", %"legacy_b_wide.11"
  %"legacy_result.11" = trunc i64 %"legacy_sum.11" to i32
  %"cast.6" = bitcast i32 %"legacy_result.11" to float
  %"f2i.2" = fptoui float %"cast.6" to i32
  %"legacy_a_shift.5" = shl i32 %"legacy_iadd3_rs.1", 1
  %"legacy_a_wide.12" = zext i32 %"legacy_a_shift.5" to i64
  %"legacy_a_complement.1" = xor i64 %"legacy_a_wide.12", 4294967295
  %"legacy_a_negate.1" = add i64 %"legacy_a_complement.1", 1
  %"legacy_b_wide.12" = zext i32 %"i2i_abs" to i64
  %"legacy_sum.12" = add i64 %"legacy_a_negate.1", %"legacy_b_wide.12"
  %"legacy_result.12" = trunc i64 %"legacy_sum.12" to i32
  %".151" = lshr i32 %"f2i.1", 16
  %".152" = trunc i32 %".151" to i16
  %".153" = zext i16 %".152" to i32
  %".154" = trunc i32 %"legacy_result.10" to i16
  %".155" = zext i16 %".154" to i32
  %"xmad_product.17" = mul i32 %".153", %".155"
  %"xmad_chi.2" = lshr i32 %"xmad_sum.15", 16
  %"xmad_sum.17" = add i32 %"xmad_product.17", %"xmad_chi.2"
  %"isetrp_cmp1.1" = icmp uge i32 %"legacy_result.12", 2
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %".156" = zext i32 %"xmad_sum.17" to i64
  %".157" = zext i32 %"xmad_sum.16" to i64
  %".158" = add i64 %".156", %".157"
  %".159" = lshr i64 %".158", 16
  %".160" = trunc i64 %".159" to i32
  %"legacy_iadd3_rs.2" = add i32 %".160", %"xmad_sum.14"
  %"legacy_a_shift.6" = shl i32 %"tid_y", 6
  %"legacy_a_wide.13" = zext i32 %"legacy_a_shift.6" to i64
  %"legacy_b_wide.13" = zext i32 64 to i64
  %"legacy_sum.13" = add i64 %"legacy_a_wide.13", %"legacy_b_wide.13"
  %"legacy_result.13" = trunc i64 %"legacy_sum.13" to i32
  %"legacy_a_shift.7" = shl i32 %"f2i.2", 3
  %"legacy_a_wide.14" = zext i32 %"legacy_a_shift.7" to i64
  %"legacy_a_complement.2" = xor i64 %"legacy_a_wide.14", 4294967295
  %"legacy_a_negate.2" = add i64 %"legacy_a_complement.2", 1
  %"legacy_b_wide.14" = zext i32 0 to i64
  %"legacy_sum.14" = add i64 %"legacy_a_negate.2", %"legacy_b_wide.14"
  %"legacy_result.14" = trunc i64 %"legacy_sum.14" to i32
  %".161" = trunc i32 %"legacy_iadd3_rs.2" to i16
  %".162" = zext i16 %".161" to i32
  %".163" = trunc i32 %"i2i_abs" to i16
  %".164" = zext i16 %".163" to i32
  %"xmad_product.18" = mul i32 %".162", %".164"
  %"xmad_sum.18" = add i32 %"xmad_product.18", 0
  %"legacy_a_shift.8" = shl i32 %"tid_x", 2
  %"legacy_a_wide.15" = zext i32 %"legacy_a_shift.8" to i64
  %"legacy_b_wide.15" = zext i32 %"legacy_result.13" to i64
  %"legacy_sum.15" = add i64 %"legacy_a_wide.15", %"legacy_b_wide.15"
  %"legacy_result.15" = trunc i64 %"legacy_sum.15" to i32
  %".165" = trunc i32 %"legacy_iadd3_rs.2" to i16
  %".166" = zext i16 %".165" to i32
  %".167" = lshr i32 %"i2i_abs", 16
  %".168" = trunc i32 %".167" to i16
  %".169" = zext i16 %".168" to i32
  %"xmad_product.19" = mul i32 %".166", %".169"
  %"xmad_sum.19" = add i32 %"xmad_product.19", 0
  %".170" = trunc i32 %"f2i.2" to i16
  %".171" = zext i16 %".170" to i32
  %".172" = trunc i32 %"legacy_result.14" to i16
  %".173" = zext i16 %".172" to i32
  %"xmad_product.20" = mul i32 %".171", %".173"
  %"xmad_sum.20" = add i32 %"xmad_product.20", 0
  br label %"BB_0238"
BB_0238:
  %"cond_trunc.2" = trunc i32 %"P12_to_i32" to i1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_trunc.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_80000238", label %"BB_0240"
BB_80000238:
  %"legacy_a_wide.16" = zext i32 %"legacy_result.12" to i64
  %"legacy_b_wide.16" = zext i32 -2 to i64
  %"legacy_sum.16" = add i64 %"legacy_a_wide.16", %"legacy_b_wide.16"
  %"legacy_result.16" = trunc i64 %"legacy_sum.16" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.1" = phi  i32 [%"legacy_result.16", %"BB_80000238"], [%"legacy_result.12", %"BB_0238"]
  %".177" = lshr i32 %"legacy_iadd3_rs.2", 16
  %".178" = trunc i32 %".177" to i16
  %".179" = zext i16 %".178" to i32
  %".180" = trunc i32 %"i2i_abs" to i16
  %".181" = zext i16 %".180" to i32
  %"xmad_product.21" = mul i32 %".179", %".181"
  %"xmad_chi.3" = lshr i32 %"xmad_sum.18", 16
  %"xmad_sum.21" = add i32 %"xmad_product.21", %"xmad_chi.3"
  %".182" = lshr i32 %"legacy_iadd3_rs.2", 16
  %".183" = trunc i32 %".182" to i16
  %".184" = zext i16 %".183" to i32
  %".185" = lshr i32 %"i2i_abs", 16
  %".186" = trunc i32 %".185" to i16
  %".187" = zext i16 %".186" to i32
  %"xmad_product.22" = mul i32 %".184", %".187"
  %"xmad_sum.22" = add i32 %"xmad_product.22", 0
  %"isetrp_cmp1.2" = icmp sge i32 %"tid_y", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.1", 2
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P17_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %".188" = zext i32 %"xmad_sum.21" to i64
  %".189" = zext i32 %"xmad_sum.19" to i64
  %".190" = add i64 %".188", %".189"
  %".191" = lshr i64 %".190", 16
  %".192" = trunc i64 %".191" to i32
  %"legacy_iadd3_rs.3" = add i32 %".192", %"xmad_sum.22"
  %"legacy_a_shift.9" = shl i32 %"legacy_iadd3_rs.3", 2
  %"legacy_a_wide.17" = zext i32 %"legacy_a_shift.9" to i64
  %"legacy_a_complement.3" = xor i64 %"legacy_a_wide.17", 4294967295
  %"legacy_a_negate.3" = add i64 %"legacy_a_complement.3", 1
  %"legacy_b_wide.17" = zext i32 %"i2i_abs" to i64
  %"legacy_sum.17" = add i64 %"legacy_a_negate.3", %"legacy_b_wide.17"
  %"legacy_result.17" = trunc i64 %"legacy_sum.17" to i32
  %".193" = lshr i32 %"f2i.2", 16
  %".194" = trunc i32 %".193" to i16
  %".195" = zext i16 %".194" to i32
  %".196" = lshr i32 %"legacy_result.14", 16
  %".197" = trunc i32 %".196" to i16
  %".198" = zext i16 %".197" to i32
  %"xmad_product.23" = mul i32 %".195", %".198"
  %"xmad_sum.23" = add i32 %"xmad_product.23", %"f2i.2"
  br label %"BB_0278"
BB_0278:
  %"cond_trunc.3" = trunc i32 %"P17_to_i32" to i1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_trunc.3" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000278", label %"BB_0280"
BB_80000278:
  %"legacy_a_wide.18" = zext i32 %"phi.1" to i64
  %"legacy_b_wide.18" = zext i32 -2 to i64
  %"legacy_sum.18" = add i64 %"legacy_a_wide.18", %"legacy_b_wide.18"
  %"legacy_result.18" = trunc i64 %"legacy_sum.18" to i32
  br label %"BB_0280"
BB_0280:
  %"phi.2" = phi  i32 [%"legacy_result.18", %"BB_80000278"], [%"phi.1", %"BB_0278"]
  %"isetrp_cmp1.4" = icmp uge i32 %"legacy_result.17", 4
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0288"
BB_0288:
  %"cond_trunc.4" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000288", label %"BB_0290"
BB_80000288:
  %"legacy_a_wide.19" = zext i32 %"phi.2" to i64
  %"legacy_a_complement.4" = xor i64 %"legacy_a_wide.19", 4294967295
  %"legacy_a_negate.4" = add i64 %"legacy_a_complement.4", 1
  %"legacy_b_wide.19" = zext i32 0 to i64
  %"legacy_sum.19" = add i64 %"legacy_a_negate.4", %"legacy_b_wide.19"
  %"legacy_result.19" = trunc i64 %"legacy_sum.19" to i32
  br label %"BB_0290"
BB_0290:
  %"phi.3" = phi  i32 [%"legacy_result.19", %"BB_80000288"], [%"phi.2", %"BB_0288"]
  %"isetrp_cmp1.5" = icmp ne i32 %"phi.3", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"legacy_a_wide.20" = zext i32 %"cast" to i64
  %"legacy_b_wide.20" = zext i32 268435454 to i64
  %"legacy_sum.20" = add i64 %"legacy_a_wide.20", %"legacy_b_wide.20"
  %"legacy_result.20" = trunc i64 %"legacy_sum.20" to i32
  %"cast.7" = bitcast i32 %"legacy_result.20" to float
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.5" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800002a0", label %"BB_02a8"
BB_800002a0:
  %"legacy_a_wide.21" = zext i32 %"legacy_result.17" to i64
  %"legacy_b_wide.21" = zext i32 -4 to i64
  %"legacy_sum.21" = add i64 %"legacy_a_wide.21", %"legacy_b_wide.21"
  %"legacy_result.21" = trunc i64 %"legacy_sum.21" to i32
  br label %"BB_02a8"
BB_02a8:
  %"phi.4" = phi  i32 [%"legacy_result.21", %"BB_800002a0"], [%"legacy_result.17", %"BB_02a0"]
  %"isetrp_cmp1.6" = icmp uge i32 %"phi.4", 4
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_02b0"
BB_02b0:
  %"cond_trunc.6" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_800002b0", label %"BB_02b8"
BB_800002b0:
  %"legacy_a_wide.22" = zext i32 %"phi.4" to i64
  %"legacy_b_wide.22" = zext i32 -4 to i64
  %"legacy_sum.22" = add i64 %"legacy_a_wide.22", %"legacy_b_wide.22"
  %"legacy_result.22" = trunc i64 %"legacy_sum.22" to i32
  br label %"BB_02b8"
BB_02b8:
  %"phi.5" = phi  i32 [%"legacy_result.22", %"BB_800002b0"], [%"phi.4", %"BB_02b0"]
  %"cond_trunc.7" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.7", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_800002b8", label %"BB_02c0"
BB_800002b8:
  %"legacy_a_wide.23" = zext i32 %"phi.5" to i64
  %"legacy_a_complement.5" = xor i64 %"legacy_a_wide.23", 4294967295
  %"legacy_a_negate.5" = add i64 %"legacy_a_complement.5", 1
  %"legacy_b_wide.23" = zext i32 0 to i64
  %"legacy_sum.23" = add i64 %"legacy_a_negate.5", %"legacy_b_wide.23"
  %"legacy_result.23" = trunc i64 %"legacy_sum.23" to i32
  br label %"BB_02c0"
BB_02c0:
  %"phi.6" = phi  i32 [%"legacy_result.23", %"BB_800002b8"], [%"phi.5", %"BB_02b8"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %"sts_shared_addr_winoff.1" = and i32 %"legacy_result.15", 16777215
  %".213" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".213" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %"lds_shared_addr_winoff" = and i32 %"shl", 16777215
  %".215" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".215" to float addrspace(3)*
  %"lds" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %".216" = trunc i32 %"f2i.2" to i16
  %".217" = zext i16 %".216" to i32
  %".218" = lshr i32 %"legacy_result.14", 16
  %".219" = trunc i32 %".218" to i16
  %".220" = zext i16 %".219" to i32
  %"xmad_product.24" = mul i32 %".217", %".220"
  %"xmad_sum.24" = add i32 %"xmad_product.24", 0
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %"lds_shared_addr_winoff.1" = and i32 %"legacy_result.15", 16777215
  %".221" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".221" to float addrspace(3)*
  %"lds.1" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.1"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %".222" = lshr i32 %"f2i.2", 16
  %".223" = trunc i32 %".222" to i16
  %".224" = zext i16 %".223" to i32
  %".225" = trunc i32 %"legacy_result.14" to i16
  %".226" = zext i16 %".225" to i32
  %"xmad_product.25" = mul i32 %".224", %".226"
  %"xmad_chi.4" = lshr i32 %"xmad_sum.20", 16
  %"xmad_sum.25" = add i32 %"xmad_product.25", %"xmad_chi.4"
  %".227" = zext i32 %"xmad_sum.25" to i64
  %".228" = zext i32 %"xmad_sum.24" to i64
  %".229" = add i64 %".227", %".228"
  %".230" = lshr i64 %".229", 16
  %".231" = trunc i64 %".230" to i32
  %"legacy_iadd3_rs.4" = add i32 %".231", %"xmad_sum.23"
  %"f2i.3" = fptoui float %"cast.7" to i32
  %".232" = trunc i32 %"legacy_iadd3_rs.4" to i16
  %".233" = zext i16 %".232" to i32
  %".234" = trunc i32 %"i2i_abs" to i16
  %".235" = zext i16 %".234" to i32
  %"xmad_product.26" = mul i32 %".233", %".235"
  %"xmad_sum.26" = add i32 %"xmad_product.26", 0
  %".236" = lshr i32 %"legacy_iadd3_rs.4", 16
  %".237" = trunc i32 %".236" to i16
  %".238" = zext i16 %".237" to i32
  %".239" = lshr i32 %"i2i_abs", 16
  %".240" = trunc i32 %".239" to i16
  %".241" = zext i16 %".240" to i32
  %"xmad_product.27" = mul i32 %".238", %".241"
  %"xmad_sum.27" = add i32 %"xmad_product.27", 0
  %".242" = lshr i32 %"legacy_iadd3_rs.4", 16
  %".243" = trunc i32 %".242" to i16
  %".244" = zext i16 %".243" to i32
  %".245" = trunc i32 %"i2i_abs" to i16
  %".246" = zext i16 %".245" to i32
  %"xmad_product.28" = mul i32 %".244", %".246"
  %"xmad_chi.5" = lshr i32 %"xmad_sum.26", 16
  %"xmad_sum.28" = add i32 %"xmad_product.28", %"xmad_chi.5"
  %"legacy_a_shift.10" = shl i32 %"f2i.3", 4
  %"legacy_a_wide.24" = zext i32 %"legacy_a_shift.10" to i64
  %"legacy_a_complement.6" = xor i64 %"legacy_a_wide.24", 4294967295
  %"legacy_a_negate.6" = add i64 %"legacy_a_complement.6", 1
  %"legacy_b_wide.24" = zext i32 0 to i64
  %"legacy_sum.24" = add i64 %"legacy_a_negate.6", %"legacy_b_wide.24"
  %"legacy_result.24" = trunc i64 %"legacy_sum.24" to i32
  %"fmul" = fmul float %"lds", %"lds.1"
  %".247" = trunc i32 %"legacy_iadd3_rs.4" to i16
  %".248" = zext i16 %".247" to i32
  %".249" = lshr i32 %"i2i_abs", 16
  %".250" = trunc i32 %".249" to i16
  %".251" = zext i16 %".250" to i32
  %"xmad_product.29" = mul i32 %".248", %".251"
  %"xmad_sum.29" = add i32 %"xmad_product.29", 0
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %"sts_shared_addr_winoff.2" = and i32 %"legacy_result.15", 16777215
  %".252" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".252" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.2"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %".254" = trunc i32 %"f2i.3" to i16
  %".255" = zext i16 %".254" to i32
  %".256" = lshr i32 %"legacy_result.24", 16
  %".257" = trunc i32 %".256" to i16
  %".258" = zext i16 %".257" to i32
  %"xmad_product.30" = mul i32 %".255", %".258"
  %"xmad_sum.30" = add i32 %"xmad_product.30", 0
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  %".259" = zext i32 %"xmad_sum.28" to i64
  %".260" = zext i32 %"xmad_sum.29" to i64
  %".261" = add i64 %".259", %".260"
  %".262" = lshr i64 %".261", 16
  %".263" = trunc i64 %".262" to i32
  %"legacy_iadd3_rs.5" = add i32 %".263", %"xmad_sum.27"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_03b8"
BB_03b8:
  %"cond_trunc.8" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  %"phi_cast_R28_bitcast" = bitcast i32 %"legacy_iadd3_rs.4" to float
  br i1 %"pbra_cond_to_i1.8", label %"BB_800003b8", label %"BB_03c0"
BB_800003b8:
  %"lds_shared_addr_winoff.2" = and i32 %"legacy_result.15", 16777215
  %".266" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".266" to float addrspace(3)*
  %"lds.2" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.2"
  br label %"BB_03c0"
BB_03c0:
  %"phi.7" = phi  float [%"lds.2", %"BB_800003b8"], [%"phi_cast_R28_bitcast", %"BB_03b8"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %".268" = trunc i32 %"f2i.3" to i16
  %".269" = zext i16 %".268" to i32
  %".270" = trunc i32 %"legacy_result.24" to i16
  %".271" = zext i16 %".270" to i32
  %"xmad_product.31" = mul i32 %".269", %".271"
  %"xmad_sum.31" = add i32 %"xmad_product.31", 0
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_03d8"
BB_03d8:
  %"cond_trunc.9" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  %"phi_cast_R78_bitcast" = bitcast i32 %"legacy_result.20" to float
  br i1 %"pbra_cond_to_i1.9", label %"BB_800003d8", label %"BB_03e0"
BB_800003d8:
  %"lds_addr_memaddr_offset_add" = add i32 %"legacy_result.15", 64
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".274" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".274" to float addrspace(3)*
  %"lds.3" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.3"
  br label %"BB_03e0"
BB_03e0:
  %"phi.8" = phi  float [%"lds.3", %"BB_800003d8"], [%"phi_cast_R78_bitcast", %"BB_03d8"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %".276" = lshr i32 %"f2i.3", 16
  %".277" = trunc i32 %".276" to i16
  %".278" = zext i16 %".277" to i32
  %".279" = lshr i32 %"legacy_result.24", 16
  %".280" = trunc i32 %".279" to i16
  %".281" = zext i16 %".280" to i32
  %"xmad_product.32" = mul i32 %".278", %".281"
  %"xmad_sum.32" = add i32 %"xmad_product.32", %"f2i.3"
  %"legacy_a_shift.11" = shl i32 %"legacy_iadd3_rs.5", 3
  %"legacy_a_wide.25" = zext i32 %"legacy_a_shift.11" to i64
  %"legacy_a_complement.7" = xor i64 %"legacy_a_wide.25", 4294967295
  %"legacy_a_negate.7" = add i64 %"legacy_a_complement.7", 1
  %"legacy_b_wide.25" = zext i32 %"i2i_abs" to i64
  %"legacy_sum.25" = add i64 %"legacy_a_negate.7", %"legacy_b_wide.25"
  %"legacy_result.25" = trunc i64 %"legacy_sum.25" to i32
  %".282" = lshr i32 %"f2i.3", 16
  %".283" = trunc i32 %".282" to i16
  %".284" = zext i16 %".283" to i32
  %".285" = trunc i32 %"legacy_result.24" to i16
  %".286" = zext i16 %".285" to i32
  %"xmad_product.33" = mul i32 %".284", %".286"
  %"xmad_chi.6" = lshr i32 %"xmad_sum.31", 16
  %"xmad_sum.33" = add i32 %"xmad_product.33", %"xmad_chi.6"
  %"isetrp_cmp1.7" = icmp uge i32 %"legacy_result.25", 8
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".287" = zext i32 %"xmad_sum.33" to i64
  %".288" = zext i32 %"xmad_sum.30" to i64
  %".289" = add i64 %".287", %".288"
  %".290" = lshr i64 %".289", 16
  %".291" = trunc i64 %".290" to i32
  %"legacy_iadd3_rs.6" = add i32 %".291", %"xmad_sum.32"
  %".292" = trunc i32 %"legacy_iadd3_rs.6" to i16
  %".293" = zext i16 %".292" to i32
  %".294" = trunc i32 %"i2i_abs" to i16
  %".295" = zext i16 %".294" to i32
  %"xmad_product.34" = mul i32 %".293", %".295"
  %"xmad_sum.34" = add i32 %"xmad_product.34", 0
  br label %"BB_0418"
BB_0418:
  %"cond_trunc.10" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000418", label %"BB_0420"
BB_80000418:
  %"legacy_a_wide.26" = zext i32 %"legacy_result.25" to i64
  %"legacy_b_wide.26" = zext i32 -8 to i64
  %"legacy_sum.26" = add i64 %"legacy_a_wide.26", %"legacy_b_wide.26"
  %"legacy_result.26" = trunc i64 %"legacy_sum.26" to i32
  br label %"BB_0420"
BB_0420:
  %"phi.9" = phi  i32 [%"legacy_result.26", %"BB_80000418"], [%"legacy_result.25", %"BB_0418"]
  %"isetrp_cmp1.8" = icmp ne i32 %"phi.6", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  br label %"BB_0428"
BB_0428:
  %"cond_trunc.11" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000428", label %"BB_0430"
BB_80000428:
  %"fadd" = fadd float %"phi.7", %"phi.8"
  br label %"BB_0430"
BB_0430:
  %"phi.10" = phi  float [%"fadd", %"BB_80000428"], [%"phi.7", %"BB_0428"]
  %".302" = trunc i32 %"legacy_iadd3_rs.6" to i16
  %".303" = zext i16 %".302" to i32
  %".304" = lshr i32 %"i2i_abs", 16
  %".305" = trunc i32 %".304" to i16
  %".306" = zext i16 %".305" to i32
  %"xmad_product.35" = mul i32 %".303", %".306"
  %"xmad_sum.35" = add i32 %"xmad_product.35", 0
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0440"
BB_0440:
  %"cond_trunc.12" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000440", label %"BB_0448"
BB_80000440:
  %"sts_shared_addr_winoff.3" = and i32 %"legacy_result.15", 16777215
  %".309" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".309" to float addrspace(3)*
  store volatile float %"phi.10", float addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0448"
BB_0448:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %".312" = lshr i32 %"legacy_iadd3_rs.6", 16
  %".313" = trunc i32 %".312" to i16
  %".314" = zext i16 %".313" to i32
  %".315" = trunc i32 %"i2i_abs" to i16
  %".316" = zext i16 %".315" to i32
  %"xmad_product.36" = mul i32 %".314", %".316"
  %"xmad_chi.7" = lshr i32 %"xmad_sum.34", 16
  %"xmad_sum.36" = add i32 %"xmad_product.36", %"xmad_chi.7"
  %".317" = lshr i32 %"legacy_iadd3_rs.6", 16
  %".318" = trunc i32 %".317" to i16
  %".319" = zext i16 %".318" to i32
  %".320" = lshr i32 %"i2i_abs", 16
  %".321" = trunc i32 %".320" to i16
  %".322" = zext i16 %".321" to i32
  %"xmad_product.37" = mul i32 %".319", %".322"
  %"xmad_sum.37" = add i32 %"xmad_product.37", 0
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  %"isetrp_cmp1.9" = icmp uge i32 %"phi.9", 8
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %".323" = zext i32 %"xmad_sum.36" to i64
  %".324" = zext i32 %"xmad_sum.35" to i64
  %".325" = add i64 %".323", %".324"
  %".326" = lshr i64 %".325", 16
  %".327" = trunc i64 %".326" to i32
  %"legacy_iadd3_rs.7" = add i32 %".327", %"xmad_sum.37"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0490"
BB_0490:
  %"cond_trunc.13" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  %"phi_cast_R121_bitcast" = bitcast i32 %"xmad_sum.35" to float
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000490", label %"BB_0498"
BB_80000490:
  %"lds_shared_addr_winoff.4" = and i32 %"legacy_result.15", 16777215
  %".330" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".330" to float addrspace(3)*
  %"lds.4" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.4"
  br label %"BB_0498"
BB_0498:
  %"phi.11" = phi  float [%"lds.4", %"BB_80000490"], [%"phi_cast_R121_bitcast", %"BB_0490"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %"legacy_a_shift.12" = shl i32 %"legacy_iadd3_rs.7", 4
  %"legacy_a_wide.27" = zext i32 %"legacy_a_shift.12" to i64
  %"legacy_a_complement.8" = xor i64 %"legacy_a_wide.27", 4294967295
  %"legacy_a_negate.8" = add i64 %"legacy_a_complement.8", 1
  %"legacy_b_wide.27" = zext i32 %"i2i_abs" to i64
  %"legacy_sum.27" = add i64 %"legacy_a_negate.8", %"legacy_b_wide.27"
  %"legacy_result.27" = trunc i64 %"legacy_sum.27" to i32
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_04b0"
BB_04b0:
  %"cond_trunc.14" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  %"phi_cast_R54_bitcast" = bitcast i32 %"xmad_sum.36" to float
  br i1 %"pbra_cond_to_i1.14", label %"BB_800004b0", label %"BB_04b8"
BB_800004b0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %"legacy_result.15", 128
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".334" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".334" to float addrspace(3)*
  %"lds.5" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.5"
  br label %"BB_04b8"
BB_04b8:
  %"phi.12" = phi  float [%"lds.5", %"BB_800004b0"], [%"phi_cast_R54_bitcast", %"BB_04b0"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_04c0"
BB_04c0:
  %"cond_trunc.15" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800004c0", label %"BB_04c8"
BB_800004c0:
  %"legacy_a_wide.28" = zext i32 %"phi.9" to i64
  %"legacy_b_wide.28" = zext i32 -8 to i64
  %"legacy_sum.28" = add i64 %"legacy_a_wide.28", %"legacy_b_wide.28"
  %"legacy_result.28" = trunc i64 %"legacy_sum.28" to i32
  br label %"BB_04c8"
BB_04c8:
  %"phi.13" = phi  i32 [%"legacy_result.28", %"BB_800004c0"], [%"phi.9", %"BB_04c0"]
  %"isetrp_cmp1.10" = icmp uge i32 %"legacy_result.27", 16
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_04d0"
BB_04d0:
  %"cond_trunc.16" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800004d0", label %"BB_04d8"
BB_800004d0:
  %"legacy_a_wide.29" = zext i32 %"phi.13" to i64
  %"legacy_a_complement.9" = xor i64 %"legacy_a_wide.29", 4294967295
  %"legacy_a_negate.9" = add i64 %"legacy_a_complement.9", 1
  %"legacy_b_wide.29" = zext i32 0 to i64
  %"legacy_sum.29" = add i64 %"legacy_a_negate.9", %"legacy_b_wide.29"
  %"legacy_result.29" = trunc i64 %"legacy_sum.29" to i32
  br label %"BB_04d8"
BB_04d8:
  %"phi.14" = phi  i32 [%"legacy_result.29", %"BB_800004d0"], [%"phi.13", %"BB_04d0"]
  %"cond_trunc.17" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_800004d8", label %"BB_04e0"
BB_800004d8:
  %"legacy_a_wide.30" = zext i32 %"legacy_result.27" to i64
  %"legacy_b_wide.30" = zext i32 -16 to i64
  %"legacy_sum.30" = add i64 %"legacy_a_wide.30", %"legacy_b_wide.30"
  %"legacy_result.30" = trunc i64 %"legacy_sum.30" to i32
  br label %"BB_04e0"
BB_04e0:
  %"phi.15" = phi  i32 [%"legacy_result.30", %"BB_800004d8"], [%"legacy_result.27", %"BB_04d8"]
  %"isetrp_cmp1.11" = icmp ne i32 %"phi.14", 0
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_04e8"
BB_04e8:
  %"cond_trunc.18" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_800004e8", label %"BB_04f0"
BB_800004e8:
  %"fadd.1" = fadd float %"phi.11", %"phi.12"
  br label %"BB_04f0"
BB_04f0:
  %"phi.16" = phi  float [%"fadd.1", %"BB_800004e8"], [%"phi.11", %"BB_04e8"]
  %"isetrp_cmp1.12" = icmp uge i32 %"phi.15", 16
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0500"
BB_0500:
  %"cond_trunc.19" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000500", label %"BB_0508"
BB_80000500:
  %"sts_shared_addr_winoff.4" = and i32 %"legacy_result.15", 16777215
  %".349" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".349" to float addrspace(3)*
  store volatile float %"phi.16", float addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_0508"
BB_0508:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0528"
BB_0528:
  %"cond_trunc.20" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.20", -1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  %"phi_cast_R156_bitcast" = bitcast i32 %"i2i_abs" to float
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000528", label %"BB_0530"
BB_80000528:
  %"lds_shared_addr_winoff.6" = and i32 %"legacy_result.15", 16777215
  %".354" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".354" to float addrspace(3)*
  %"lds.6" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.6"
  br label %"BB_0530"
BB_0530:
  %"phi.17" = phi  float [%"lds.6", %"BB_80000528"], [%"phi_cast_R156_bitcast", %"BB_0528"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0540"
BB_0540:
  %"cond_trunc.21" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000540", label %"BB_0548"
BB_80000540:
  %"lds_addr_memaddr_offset_add.2" = add i32 %"legacy_result.15", 256
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".358" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".358" to float addrspace(3)*
  %"lds.7" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.7"
  br label %"BB_0548"
BB_0548:
  %"phi.18" = phi  float [%"lds.7", %"BB_80000540"], [%"phi.10", %"BB_0540"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0550"
BB_0550:
  %"cond_trunc.22" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000550", label %"BB_0558"
BB_80000550:
  %"legacy_a_wide.31" = zext i32 %"phi.15" to i64
  %"legacy_b_wide.31" = zext i32 -16 to i64
  %"legacy_sum.31" = add i64 %"legacy_a_wide.31", %"legacy_b_wide.31"
  %"legacy_result.31" = trunc i64 %"legacy_sum.31" to i32
  br label %"BB_0558"
BB_0558:
  %"phi.19" = phi  i32 [%"legacy_result.31", %"BB_80000550"], [%"phi.15", %"BB_0550"]
  %"cond_trunc.23" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.15" = xor i1 %"cond_trunc.23", -1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_not.15" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000558", label %"BB_0560"
BB_80000558:
  %"legacy_a_wide.32" = zext i32 %"phi.19" to i64
  %"legacy_a_complement.10" = xor i64 %"legacy_a_wide.32", 4294967295
  %"legacy_a_negate.10" = add i64 %"legacy_a_complement.10", 1
  %"legacy_b_wide.32" = zext i32 0 to i64
  %"legacy_sum.32" = add i64 %"legacy_a_negate.10", %"legacy_b_wide.32"
  %"legacy_result.32" = trunc i64 %"legacy_sum.32" to i32
  br label %"BB_0560"
BB_0560:
  %"phi.20" = phi  i32 [%"legacy_result.32", %"BB_80000558"], [%"phi.19", %"BB_0558"]
  %"isetrp_cmp1.13" = icmp ne i32 %"phi.20", 0
  %"isetrp_src_to_i32.13" = zext i1 1 to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  br label %"BB_0568"
BB_0568:
  %"cond_trunc.24" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.16" = xor i1 %"cond_trunc.24", -1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_not.16" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80000568", label %"BB_0570"
BB_80000568:
  %"fadd.2" = fadd float %"phi.17", %"phi.18"
  br label %"BB_0570"
BB_0570:
  %"phi.21" = phi  float [%"fadd.2", %"BB_80000568"], [%"phi.17", %"BB_0568"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0578"
BB_0578:
  %"cond_trunc.25" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.17" = xor i1 %"cond_trunc.25", -1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_not.17" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80000578", label %"BB_0580"
BB_80000578:
  %"sts_shared_addr_winoff.5" = and i32 %"legacy_result.15", 16777215
  %".370" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".370" to float addrspace(3)*
  store volatile float %"phi.21", float addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_0580"
BB_0580:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_05b0"
BB_05b0:
  %"cond_trunc.26" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.18" = xor i1 %"cond_trunc.26", -1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_not.18" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_800005b0", label %"BB_05b8"
BB_800005b0:
  %"lds_shared_addr_winoff.8" = and i32 %"legacy_result.15", 16777215
  %".375" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.8"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".375" to float addrspace(3)*
  %"lds.8" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.8"
  br label %"BB_05b8"
BB_05b8:
  %"phi.22" = phi  float [%"lds.8", %"BB_800005b0"], [%"phi.18", %"BB_05b0"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_05c8"
BB_05c8:
  %"cond_trunc.27" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.19" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.19" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_800005c8", label %"BB_05d0"
BB_800005c8:
  %"lds_addr_memaddr_offset_add.3" = add i32 %"legacy_result.15", 512
  %"lds_shared_addr_winoff.9" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".379" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.9"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".379" to float addrspace(3)*
  %"lds.9" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.9"
  br label %"BB_05d0"
BB_05d0:
  %"phi.23" = phi  float [%"lds.9", %"BB_800005c8"], [%"phi.16", %"BB_05c8"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_05d8"
BB_05d8:
  %"cond_trunc.28" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.20" = xor i1 %"cond_trunc.28", -1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_not.20" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_800005d8", label %"BB_05e0"
BB_800005d8:
  %"fadd.3" = fadd float %"phi.22", %"phi.23"
  br label %"BB_05e0"
BB_05e0:
  %"phi.24" = phi  float [%"fadd.3", %"BB_800005d8"], [%"phi.22", %"BB_05d8"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_05e8"
BB_05e8:
  %"cond_trunc.29" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.21" = xor i1 %"cond_trunc.29", -1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_not.21" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_800005e8", label %"BB_05f0"
BB_800005e8:
  %"sts_shared_addr_winoff.6" = and i32 %"legacy_result.15", 16777215
  %".386" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".386" to float addrspace(3)*
  store volatile float %"phi.24", float addrspace(3)* %"sts_shared_addr_cast.6"
  br label %"BB_05f0"
BB_05f0:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %"lds_shared_addr_winoff.10" = and i32 %"legacy_result.15", 16777215
  %".389" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.10"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".389" to i32 addrspace(3)*
  %"lds.10" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.10"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  %"isetrp_cmp1.14" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.14" = zext i1 1 to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"stg_addr_r0_ext" = zext i32 %"legacy_result.6" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"legacy_result.7" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1", 8
  %"R138:R74_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %"lds.10", i32 addrspace(1)* %"R138:R74_addr_ptr.1"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  %"legacy_branch_predicate_trunc" = trunc i32 %"P16_to_i32" to i1
  %"legacy_taken_mask" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_entry_mask", i1 %"legacy_branch_predicate_trunc")
  %".391" = xor i32 %"legacy_taken_mask", -1
  %"legacy_fallthrough_mask" = and i32 %"legacy_entry_mask", %".391"
  %"legacy_path_mask" = select  i1 %"legacy_branch_predicate_trunc", i32 %"legacy_taken_mask", i32 %"legacy_fallthrough_mask"
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.30" = trunc i32 %"P16_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_800006a0", label %"BB_06a8"
BB_06a8:
  %".394" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 356
  %".395" = bitcast i8* %".394" to i32*
  %"xmad_src1" = load i32, i32* %".395"
  %".396" = trunc i32 %"ctaid_y" to i16
  %".397" = zext i16 %".396" to i32
  %".398" = trunc i32 %"xmad_src1" to i16
  %".399" = zext i16 %".398" to i32
  %"xmad_product.38" = mul i32 %".397", %".399"
  %"xmad_sum.38" = add i32 %"xmad_product.38", %"tid_y"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask")
  %"lds_addr_memaddr_offset_add.4" = add i32 %"shl", 64
  %"lds_shared_addr_winoff.11" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".400" = getelementptr inbounds [1088 x i8], [1088 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.11"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".400" to i32 addrspace(3)*
  %"lds.11" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.11"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask")
  %".401" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 356
  %".402" = bitcast i8* %".401" to i32*
  %"xmad_src1.1" = load i32, i32* %".402"
  %".403" = trunc i32 %"ctaid_y" to i16
  %".404" = zext i16 %".403" to i32
  %".405" = lshr i32 %"xmad_src1.1", 16
  %".406" = trunc i32 %".405" to i16
  %".407" = zext i16 %".406" to i32
  %"xmad_product.39" = mul i32 %".404", %".407"
  %"xmad_sum.39" = add i32 %"xmad_product.39", 0
  %".408" = and i32 %"xmad_sum.39", 65535
  %".409" = shl i32 %"xmad_src1.1", 16
  %"xmad_merge.2" = or i32 %".408", %".409"
  %".410" = lshr i32 %"ctaid_y", 16
  %".411" = trunc i32 %".410" to i16
  %".412" = zext i16 %".411" to i32
  %".413" = lshr i32 %"xmad_merge.2", 16
  %".414" = trunc i32 %".413" to i16
  %".415" = zext i16 %".414" to i32
  %"xmad_product.40" = mul i32 %".412", %".415"
  %"xmad_psl.2" = shl i32 %"xmad_product.40", 16
  %".416" = shl i32 %"xmad_merge.2", 16
  %"xmad_cbcc.2" = add i32 %"xmad_sum.38", %".416"
  %"xmad_sum.40" = add i32 %"xmad_psl.2", %"xmad_cbcc.2"
  %"shr_overflow.2" = icmp ugt i32 30, 31
  %"shr_clamp.2" = select  i1 %"shr_overflow.2", i32 31, i32 30
  %"shr_result.2" = ashr i32 %"xmad_sum.40", %"shr_clamp.2"
  %"legacy_a_shift.13" = shl i32 %"xmad_sum.40", 2
  %"legacy_a_wide.33" = zext i32 %"legacy_a_shift.13" to i64
  %".417" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 344
  %".418" = bitcast i8* %".417" to i32*
  %"legacy_b.5" = load i32, i32* %".418"
  %"legacy_b_wide.33" = zext i32 %"legacy_b.5" to i64
  %"legacy_sum.33" = add i64 %"legacy_a_wide.33", %"legacy_b_wide.33"
  %"legacy_result.33" = trunc i64 %"legacy_sum.33" to i32
  %".419" = lshr i64 %"legacy_sum.33", 32
  %"legacy_cout.2" = trunc i64 %".419" to i1
  %"P13_to_i32" = zext i1 %"legacy_cout.2" to i32
  %"legacy_a_wide.34" = zext i32 %"shr_result.2" to i64
  %".420" = getelementptr inbounds [368 x i8], [368 x i8]* %"param_local", i64 0, i64 348
  %".421" = bitcast i8* %".420" to i32*
  %"legacy_b.6" = load i32, i32* %".421"
  %"legacy_b_wide.34" = zext i32 %"legacy_b.6" to i64
  %"legacy_sum.34" = add i64 %"legacy_a_wide.34", %"legacy_b_wide.34"
  %"legacy_cin_trunc.2" = trunc i32 %"P13_to_i32" to i1
  %".422" = zext i1 %"legacy_cin_trunc.2" to i64
  %"legacy_sum_cin.2" = add i64 %"legacy_sum.34", %".422"
  %"legacy_result.34" = trunc i64 %"legacy_sum_cin.2" to i32
  %"stg_addr_r0_ext.1" = zext i32 %"legacy_result.33" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"legacy_result.34" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"R142:R103_addr_ptr" = inttoptr i64 %"stg_addr_packed_1.1" to i32 addrspace(1)*
  store i32 %"lds.11", i32 addrspace(1)* %"R142:R103_addr_ptr"
  ret void
BB_800006a0:
  ret void
}

@"const_mem" = internal global [5 x [368 x i8]] [[368 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [368 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [368 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [368 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [368 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.vote.ballot.sync"(i32 %".1", i1 %".2") convergent noduplicate

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()

declare float @"llvm.nvvm.rcp.approx.ftz.f"(float %".1")

declare void @"llvm.nvvm.bar.warp.sync"(i32 %".1") convergent noduplicate

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64, i64, i64, i32, i32)* @"_Z22bpnn_layerforward_CUDAPfS_S_S_ii", !"kernel", i32 1 }
