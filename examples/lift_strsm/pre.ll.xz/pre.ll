; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../p2a/ir/p0/strsm.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../p2a/ir/p0/strsm.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16
@const_mem = global [5 x [592 x i8]] zeroinitializer, align 16

define void @_Z19kernel_trsm_l_mul32IfLi8ELb0ELb0ELb0ELb0EEviiPKT_S2_iPS0_iS0_i(i32 %arg_528, i32 %arg_532, i64 %arg_536, i64 %arg_544, i32 %arg_552, i64 %arg_560, i32 %arg_568, i32 %arg_572, i32 %arg_576) {
EntryBB_0000:
  %param_local = alloca [592 x i8], align 16
  %.11 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 528
  store i32 %arg_528, ptr %.11, align 16
  %.14 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 532
  store i32 %arg_532, ptr %.14, align 4
  %.17 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 536
  store i64 %arg_536, ptr %.17, align 8
  %.20 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 544
  store i64 %arg_544, ptr %.20, align 32
  %.23 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 552
  store i32 %arg_552, ptr %.23, align 8
  %.26 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  store i64 %arg_560, ptr %.26, align 16
  %.29 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 568
  store i32 %arg_568, ptr %.29, align 8
  %.32 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 572
  store i32 %arg_572, ptr %.32, align 4
  %.35 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 576
  store i32 %arg_576, ptr %.35, align 64
  %ldc_const = load i32, ptr %.14, align 4
  %isetrp_cmp1 = icmp ne i32 0, %arg_576
  %ldc_const.2 = load i32, ptr %.32, align 4
  %R971_bitcast = bitcast i32 %ldc_const.2 to float
  %isetrp_cmp1.1 = icmp sge i32 %ldc_const, 1
  br label %BB_0080

BB_0080:                                          ; preds = %EntryBB_0000
  %cond_not = xor i1 %isetrp_cmp1, true
  br i1 %cond_not, label %BB_00b0, label %BB_0090

BB_0090:                                          ; preds = %BB_0080
  %ldc_const.3 = load i64, ptr %.17, align 8
  %"R2780:R2715_addr_ptr" = inttoptr i64 %ldc_const.3 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R2780:R2715_addr_ptr", align 4
  br label %BB_00b0

BB_00b0:                                          ; preds = %BB_0090, %BB_0080
  %phi = phi float [ %ldg, %BB_0090 ], [ %R971_bitcast, %BB_0080 ]
  %cond_not.1 = xor i1 %isetrp_cmp1.1, true
  br i1 %cond_not.1, label %BB_800000b0, label %BB_00c0

BB_00c0:                                          ; preds = %BB_00b0
  %s2ur_cluster_ctarank = call i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank()
  %tid_y = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %0 = zext i32 %tid_y to i64
  %ldc_const.4 = load i32, ptr %.11, align 4
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %.53 = zext i32 %ldc_const.4 to i64
  %.54 = shl i64 %.53, 32
  %.55 = ashr i64 %.54, 31
  %shf_hi = lshr i64 %.55, 32
  %shf_result = trunc i64 %shf_hi to i32
  %.56 = zext i32 %shf_result to i64
  %.61 = shl i64 %.56, 5
  %.62 = lshr i64 %.61, 32
  %.63 = add i64 %.62, %.53
  %.64 = trunc i64 %.63 to i32
  %.66 = zext i32 %.64 to i64
  %.67 = shl i64 %.66, 32
  %.68 = ashr i64 %.67, 5
  %shf_hi.1 = lshr i64 %.68, 32
  %shf_result.1 = trunc i64 %shf_hi.1 to i32
  %.69 = zext i32 %s2ur_cluster_ctarank to i64
  %.72 = shl i64 %.69, 24
  %.73 = and i64 %.72, 4294967295
  %.74 = add i64 %.73, 1024
  %.75 = trunc i64 %.74 to i32
  %ldc_const.5 = load i32, ptr %.23, align 4
  %.79 = zext i32 %ldc_const.5 to i64
  %.80 = shl i64 %.79, 32
  %.81 = ashr i64 %.80, 31
  %shf_hi.2 = lshr i64 %.81, 32
  %shf_result.2 = trunc i64 %shf_hi.2 to i32
  %1 = sext i32 %ldc_const.5 to i64
  %imad_addend_r0_ext = zext i32 %tid_x to i64
  %.83 = zext i32 %.75 to i64
  %.85 = shl i64 %imad_addend_r0_ext, 2
  %.86 = and i64 %.85, 4294967295
  %.87 = add i64 %.86, %.83
  %.88 = trunc i64 %.87 to i32
  br label %BB_01c0

BB_01c0:                                          ; preds = %BB_4d80, %BB_00c0
  %phi.1 = phi i32 [ 0, %BB_00c0 ], [ %.10990, %BB_4d80 ]
  %phi.2 = phi float [ 0.000000e+00, %BB_00c0 ], [ %phi.513, %BB_4d80 ]
  %phi.3 = phi i32 [ 0, %BB_00c0 ], [ %phi.514, %BB_4d80 ]
  %phi.4 = phi float [ 0.000000e+00, %BB_00c0 ], [ %phi.515, %BB_4d80 ]
  %phi.5 = phi i32 [ %.75, %BB_00c0 ], [ %phi.516, %BB_4d80 ]
  %s2ur_ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %ldc_const.6 = load i32, ptr %.14, align 4
  %.92 = zext i32 %s2ur_ctaid_x to i64
  %.93 = zext i32 %phi.1 to i64
  %.95 = shl i64 %.92, 3
  %.96 = and i64 %.95, 4294967295
  %.97 = add i64 %.96, %.93
  %.98 = trunc i64 %.97 to i32
  %2 = zext i32 %.98 to i64
  %isetrp_cmp1.2 = icmp ule i32 %ldc_const.6, %.98
  br label %BB_0200

BB_0200:                                          ; preds = %BB_01c0
  %3 = zext i1 %isetrp_cmp1.2 to i32
  %4 = icmp ne i32 %3, 0
  br i1 %4, label %BB_80000200, label %BB_0210

BB_0210:                                          ; preds = %BB_0200
  %ldc_const.7 = load i32, ptr %.11, align 4
  %isetrp_cmp1.3 = icmp sge i32 %ldc_const.7, 32
  br label %BB_0230

BB_0230:                                          ; preds = %BB_0210
  %cond_not.2 = xor i1 %isetrp_cmp1.3, true
  br i1 %cond_not.2, label %BB_4d40, label %BB_0240

BB_0240:                                          ; preds = %BB_0230
  %ldc_const.8 = load i32, ptr %.29, align 4
  %5 = sext i32 %ldc_const.8 to i64
  %iadd3_n1 = add i32 %tid_y, %.98
  %6 = mul i64 %0, %5
  %7 = zext i32 %tid_x to i64
  %8 = add i64 %6, %7
  %9 = mul i64 %5, %2
  %10 = add i64 %9, %8
  br label %BB_0330

BB_0330:                                          ; preds = %BB_4d30, %BB_0240
  %11 = phi i64 [ 0, %BB_0240 ], [ %462, %BB_4d30 ]
  %phi.8 = phi float [ %phi.2, %BB_0240 ], [ %phi.509, %BB_4d30 ]
  %phi.9 = phi i32 [ 0, %BB_0240 ], [ %iadd3_n1.327, %BB_4d30 ]
  %phi.10 = phi i32 [ %phi.3, %BB_0240 ], [ %phi.510, %BB_4d30 ]
  %phi.11 = phi float [ %phi.4, %BB_0240 ], [ %phi.511, %BB_4d30 ]
  %phi.12 = phi i32 [ %phi.5, %BB_0240 ], [ %phi.512, %BB_4d30 ]
  %12 = lshr i64 %11, 32
  %13 = trunc i64 %12 to i32
  %isetrp_cmp1.4 = icmp ne i32 %phi.9, 0
  br label %BB_0350

BB_0350:                                          ; preds = %BB_0330
  %cond_not.3 = xor i1 %isetrp_cmp1.4, true
  br i1 %cond_not.3, label %BB_0c70, label %BB_0360

BB_0360:                                          ; preds = %BB_0350
  %ldc_const.10 = load i64, ptr %.20, align 8
  %ldc_const.11 = load i32, ptr %.14, align 4
  %imad_tmp.4 = mul i32 %tid_y, %shf_result.2
  %14 = zext i32 %imad_tmp.4 to i64
  %15 = shl i64 %14, 32
  %16 = zext i32 %13 to i64
  %17 = or i64 %16, %15
  %imad_tmp.5 = mul i32 %tid_y, 33
  %imad.8 = add i32 %imad_tmp.5, %tid_x
  %18 = mul i64 %0, %1
  %19 = zext i32 %tid_x to i64
  %20 = add i64 %18, %19
  %.138 = zext i32 %imad.8 to i64
  %.139 = zext i32 %phi.12 to i64
  %.141 = shl i64 %.138, 2
  %.142 = and i64 %.141, 4294967295
  %.143 = add i64 %.142, %.139
  %.144 = trunc i64 %.143 to i32
  %.150 = shl i64 %11, 5
  %21 = add i64 %20, %.150
  %isetrp_cmp1.5 = icmp uge i32 %iadd3_n1, %ldc_const.11
  %.161 = shl i64 %21, 2
  %22 = add i64 %ldc_const.10, %.161
  %phi_cast_R1987_bitcast = bitcast float %phi.11 to i32
  %23 = zext i32 %phi.10 to i64
  %24 = shl i64 %23, 32
  %25 = zext i32 %phi_cast_R1987_bitcast to i64
  %26 = or i64 %25, %24
  br label %BB_0470

BB_0470:                                          ; preds = %BB_0c60, %BB_0360
  %27 = phi i64 [ %17, %BB_0360 ], [ %50, %BB_0c60 ]
  %28 = phi i64 [ %26, %BB_0360 ], [ %55, %BB_0c60 ]
  %29 = phi i64 [ %22, %BB_0360 ], [ %51, %BB_0c60 ]
  %phi.13 = phi float [ %phi.8, %BB_0360 ], [ %phi.28, %BB_0c60 ]
  %phi.14 = phi float [ 0.000000e+00, %BB_0360 ], [ %phi.29, %BB_0c60 ]
  %phi.15 = phi i32 [ 0, %BB_0360 ], [ %iadd3_n1.2, %BB_0c60 ]
  %ldc_const.12 = load i32, ptr %.23, align 4
  br label %BB_0480

BB_0480:                                          ; preds = %BB_0470
  %cond_not.4 = xor i1 %isetrp_cmp1.5, true
  br i1 %cond_not.4, label %BB_80000480, label %BB_04c0

BB_80000480:                                      ; preds = %BB_0480
  %.172 = zext i32 %phi.15 to i64
  %.175 = shl i64 %.172, 5
  %shf_result.4 = trunc i64 %.175 to i32
  %ldc_const.13 = load i64, ptr %.26, align 8
  %.178 = sext i32 %shf_result.4 to i64
  %.181 = shl i64 %.178, 1
  %30 = zext i32 %shf_result.4 to i64
  %31 = and i64 %.181, -4294967296
  %32 = add i64 %10, %30
  %33 = add i64 %32, %31
  br label %BB_04c0

BB_04c0:                                          ; preds = %BB_80000480, %BB_0480
  %34 = phi i64 [ %ldc_const.13, %BB_80000480 ], [ %27, %BB_0480 ]
  %35 = phi i64 [ %33, %BB_80000480 ], [ %28, %BB_0480 ]
  %imad_lhs_64.3 = sext i32 %ldc_const.12 to i64
  %imad_tmp_64.3 = mul i64 %imad_lhs_64.3, 32
  %36 = add i64 %imad_tmp_64.3, %29
  %"R1938:R211_addr_ptr" = inttoptr i64 %29 to ptr addrspace(1)
  %ldg.1 = load i32, ptr addrspace(1) %"R1938:R211_addr_ptr", align 4
  %"R2795:R2656_addr_ptr" = inttoptr i64 %36 to ptr addrspace(1)
  %ldg.2 = load i32, ptr addrspace(1) %"R2795:R2656_addr_ptr", align 4
  br label %BB_04f0

BB_04f0:                                          ; preds = %BB_04c0
  %37 = zext i1 %cond_not.4 to i32
  %38 = icmp ne i32 %37, 0
  br i1 %38, label %BB_800004f0, label %BB_0510

BB_800004f0:                                      ; preds = %BB_04f0
  %.204 = shl i64 %35, 2
  %39 = add i64 %34, %.204
  br label %BB_0510

BB_0510:                                          ; preds = %BB_800004f0, %BB_04f0
  %40 = phi i64 [ %39, %BB_800004f0 ], [ %34, %BB_04f0 ]
  %41 = lshr i64 %40, 32
  %42 = trunc i64 %41 to i32
  %imad.10 = add i64 %imad_tmp_64.3, %36
  %"R21:R20_r1_shift" = lshr i64 %imad.10, 32
  %"R21:R20_r1" = trunc i64 %"R21:R20_r1_shift" to i32
  %43 = add i64 %imad_tmp_64.3, %36
  br label %BB_0520

BB_0520:                                          ; preds = %BB_0510
  %44 = zext i1 %cond_not.4 to i32
  %45 = icmp ne i32 %44, 0
  br i1 %45, label %BB_80000520, label %BB_0530

BB_80000520:                                      ; preds = %BB_0520
  %"R2457:R1516_addr_ptr" = inttoptr i64 %40 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R2457:R1516_addr_ptr", align 4
  br label %BB_0530

BB_0530:                                          ; preds = %BB_80000520, %BB_0520
  %phi.28 = phi float [ %ldg.3, %BB_80000520 ], [ %phi.13, %BB_0520 ]
  %46 = add i64 %imad_tmp_64.3, %43
  %"R2620:R2045_addr_ptr" = inttoptr i64 %43 to ptr addrspace(1)
  %ldg.4 = load float, ptr addrspace(1) %"R2620:R2045_addr_ptr", align 4
  %"R2803:R2664_addr_ptr" = inttoptr i64 %46 to ptr addrspace(1)
  %ldg.5 = load i32, ptr addrspace(1) %"R2803:R2664_addr_ptr", align 4
  %.214 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.144
  store volatile i32 %ldg.1, ptr addrspace(3) %.214, align 4
  %sts_addr_memaddr_offset_add = add i32 %.144, 1056
  %.216 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add
  store volatile i32 %ldg.2, ptr addrspace(3) %.216, align 4
  %sts_addr_memaddr_offset_add.1 = add i32 %.144, 2112
  %.218 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.1
  store volatile float %ldg.4, ptr addrspace(3) %.218, align 4
  %sts_addr_memaddr_offset_add.2 = add i32 %.144, 3168
  %.220 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.2
  store volatile i32 %ldg.5, ptr addrspace(3) %.220, align 4
  call void @llvm.nvvm.barrier0()
  br label %BB_05b0

BB_05b0:                                          ; preds = %BB_0530
  %phi_cast_R2620_bitcast = bitcast i32 %"R21:R20_r1" to float
  br i1 %isetrp_cmp1.5, label %BB_0be0, label %BB_05c0

BB_05c0:                                          ; preds = %BB_05b0
  %.224 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.88
  %lds = load volatile float, ptr addrspace(3) %.224, align 4
  %lds_addr_memaddr_offset_add = add i32 %.88, 132
  %.225 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add
  %lds.1 = load volatile float, ptr addrspace(3) %.225, align 4
  %lds_addr_memaddr_offset_add.1 = add i32 %.88, 264
  %.226 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.1
  %lds.2 = load volatile float, ptr addrspace(3) %.226, align 4
  %lds_addr_memaddr_offset_add.2 = add i32 %.88, 396
  %.227 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.2
  %lds.3 = load volatile float, ptr addrspace(3) %.227, align 4
  br label %BB_0620

BB_0620:                                          ; preds = %BB_05c0
  %shfl_activemask = call i32 @llvm.nvvm.activemask()
  %shfl_idx = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask, float %phi.28, i32 0, i32 31)
  %shfl_activemask.1 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.1 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.1, float %phi.28, i32 1, i32 31)
  %shfl_activemask.2 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.2 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.2, float %phi.28, i32 5, i32 31)
  %ffma = call float @llvm.fma.f32(float %lds, float %shfl_idx, float %phi.14)
  %shfl_activemask.3 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.3 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.3, float %phi.28, i32 2, i32 31)
  %ffma.1 = call float @llvm.fma.f32(float %lds.1, float %shfl_idx.1, float %ffma)
  %lds_addr_memaddr_offset_add.3 = add i32 %.88, 528
  %.229 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.3
  %lds.4 = load volatile float, ptr addrspace(3) %.229, align 4
  %shfl_activemask.4 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.4 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.4, float %phi.28, i32 3, i32 31)
  %lds_addr_memaddr_offset_add.4 = add i32 %.88, 660
  %.230 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.4
  %lds.5 = load volatile float, ptr addrspace(3) %.230, align 4
  %shfl_activemask.5 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.5 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.5, float %phi.28, i32 4, i32 31)
  %ffma.2 = call float @llvm.fma.f32(float %lds.2, float %shfl_idx.3, float %ffma.1)
  %lds_addr_memaddr_offset_add.5 = add i32 %.88, 792
  %.231 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.5
  %lds.6 = load volatile float, ptr addrspace(3) %.231, align 4
  %ffma.3 = call float @llvm.fma.f32(float %lds.3, float %shfl_idx.4, float %ffma.2)
  %lds_addr_memaddr_offset_add.6 = add i32 %.88, 924
  %.232 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.6
  %lds.7 = load volatile float, ptr addrspace(3) %.232, align 4
  %lds_addr_memaddr_offset_add.7 = add i32 %.88, 1056
  %.233 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.7
  %lds.8 = load volatile float, ptr addrspace(3) %.233, align 4
  %ffma.4 = call float @llvm.fma.f32(float %lds.4, float %shfl_idx.5, float %ffma.3)
  %shfl_activemask.6 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.6 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.6, float %phi.28, i32 6, i32 31)
  %shfl_activemask.7 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.7 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.7, float %phi.28, i32 7, i32 31)
  %ffma.5 = call float @llvm.fma.f32(float %lds.5, float %shfl_idx.2, float %ffma.4)
  %lds_addr_memaddr_offset_add.8 = add i32 %.88, 1188
  %.234 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.8
  %lds.9 = load volatile float, ptr addrspace(3) %.234, align 4
  %shfl_activemask.8 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.8 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.8, float %phi.28, i32 8, i32 31)
  %ffma.6 = call float @llvm.fma.f32(float %lds.6, float %shfl_idx.6, float %ffma.5)
  %lds_addr_memaddr_offset_add.9 = add i32 %.88, 1320
  %.235 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.9
  %lds.10 = load volatile float, ptr addrspace(3) %.235, align 4
  %ffma.7 = call float @llvm.fma.f32(float %lds.7, float %shfl_idx.7, float %ffma.6)
  %lds_addr_memaddr_offset_add.10 = add i32 %.88, 1452
  %.236 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.10
  %lds.11 = load volatile float, ptr addrspace(3) %.236, align 4
  %shfl_activemask.9 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.9 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.9, float %phi.28, i32 9, i32 31)
  %ffma.8 = call float @llvm.fma.f32(float %lds.8, float %shfl_idx.8, float %ffma.7)
  %shfl_activemask.10 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.10 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.10, float %phi.28, i32 10, i32 31)
  %lds_addr_memaddr_offset_add.11 = add i32 %.88, 1584
  %.237 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.11
  %lds.12 = load volatile float, ptr addrspace(3) %.237, align 4
  %shfl_activemask.11 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.11 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.11, float %phi.28, i32 11, i32 31)
  %ffma.9 = call float @llvm.fma.f32(float %lds.9, float %shfl_idx.9, float %ffma.8)
  %lds_addr_memaddr_offset_add.12 = add i32 %.88, 1716
  %.238 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.12
  %lds.13 = load volatile float, ptr addrspace(3) %.238, align 4
  %shfl_activemask.12 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.12 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.12, float %phi.28, i32 12, i32 31)
  %ffma.10 = call float @llvm.fma.f32(float %lds.10, float %shfl_idx.10, float %ffma.9)
  %lds_addr_memaddr_offset_add.13 = add i32 %.88, 1848
  %.239 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.13
  %lds.14 = load volatile float, ptr addrspace(3) %.239, align 4
  %ffma.11 = call float @llvm.fma.f32(float %lds.11, float %shfl_idx.11, float %ffma.10)
  %lds_addr_memaddr_offset_add.14 = add i32 %.88, 1980
  %.240 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.14
  %lds.15 = load volatile float, ptr addrspace(3) %.240, align 4
  %shfl_activemask.13 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.13 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.13, float %phi.28, i32 13, i32 31)
  %shfl_activemask.14 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.14 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.14, float %phi.28, i32 15, i32 31)
  %ffma.12 = call float @llvm.fma.f32(float %lds.12, float %shfl_idx.12, float %ffma.11)
  %shfl_activemask.15 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.15 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.15, float %phi.28, i32 14, i32 31)
  %lds_addr_memaddr_offset_add.15 = add i32 %.88, 2112
  %.241 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.15
  %lds.16 = load volatile float, ptr addrspace(3) %.241, align 4
  %ffma.13 = call float @llvm.fma.f32(float %lds.13, float %shfl_idx.13, float %ffma.12)
  %lds_addr_memaddr_offset_add.16 = add i32 %.88, 2244
  %.242 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.16
  %lds.17 = load volatile float, ptr addrspace(3) %.242, align 4
  %shfl_activemask.16 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.16 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.16, float %phi.28, i32 16, i32 31)
  %ffma.14 = call float @llvm.fma.f32(float %lds.14, float %shfl_idx.15, float %ffma.13)
  %lds_addr_memaddr_offset_add.17 = add i32 %.88, 2376
  %.243 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.17
  %lds.18 = load volatile float, ptr addrspace(3) %.243, align 4
  %ffma.15 = call float @llvm.fma.f32(float %lds.15, float %shfl_idx.14, float %ffma.14)
  %shfl_activemask.17 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.17 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.17, float %phi.28, i32 17, i32 31)
  %lds_addr_memaddr_offset_add.18 = add i32 %.88, 2508
  %.244 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.18
  %lds.19 = load volatile float, ptr addrspace(3) %.244, align 4
  %shfl_activemask.18 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.18 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.18, float %phi.28, i32 18, i32 31)
  %ffma.16 = call float @llvm.fma.f32(float %lds.16, float %shfl_idx.16, float %ffma.15)
  %shfl_activemask.19 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.19 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.19, float %phi.28, i32 19, i32 31)
  %lds_addr_memaddr_offset_add.19 = add i32 %.88, 2640
  %.245 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.19
  %lds.20 = load volatile float, ptr addrspace(3) %.245, align 4
  %ffma.17 = call float @llvm.fma.f32(float %lds.17, float %shfl_idx.17, float %ffma.16)
  %shfl_activemask.20 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.20 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.20, float %phi.28, i32 20, i32 31)
  %lds_addr_memaddr_offset_add.20 = add i32 %.88, 2772
  %.246 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.20
  %lds.21 = load volatile float, ptr addrspace(3) %.246, align 4
  %shfl_activemask.21 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.21 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.21, float %phi.28, i32 21, i32 31)
  %ffma.18 = call float @llvm.fma.f32(float %lds.18, float %shfl_idx.18, float %ffma.17)
  %lds_addr_memaddr_offset_add.21 = add i32 %.88, 2904
  %.247 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.21
  %lds.22 = load volatile float, ptr addrspace(3) %.247, align 4
  %shfl_activemask.22 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.22 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.22, float %phi.28, i32 22, i32 31)
  %ffma.19 = call float @llvm.fma.f32(float %lds.19, float %shfl_idx.19, float %ffma.18)
  %lds_addr_memaddr_offset_add.22 = add i32 %.88, 3036
  %.248 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.22
  %lds.23 = load volatile float, ptr addrspace(3) %.248, align 4
  %ffma.20 = call float @llvm.fma.f32(float %lds.20, float %shfl_idx.20, float %ffma.19)
  %shfl_activemask.23 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.23 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.23, float %phi.28, i32 23, i32 31)
  %lds_addr_memaddr_offset_add.23 = add i32 %.88, 3168
  %.249 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.23
  %lds.24 = load volatile float, ptr addrspace(3) %.249, align 4
  %ffma.21 = call float @llvm.fma.f32(float %lds.21, float %shfl_idx.21, float %ffma.20)
  %lds_addr_memaddr_offset_add.24 = add i32 %.88, 3432
  %.250 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.24
  %lds.25 = load volatile float, ptr addrspace(3) %.250, align 4
  %lds_addr_memaddr_offset_add.25 = add i32 %.88, 3300
  %.251 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.25
  %lds.26 = load volatile float, ptr addrspace(3) %.251, align 4
  %shfl_activemask.24 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.24 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.24, float %phi.28, i32 24, i32 31)
  %ffma.22 = call float @llvm.fma.f32(float %lds.22, float %shfl_idx.22, float %ffma.21)
  %shfl_activemask.25 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.25 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.25, float %phi.28, i32 25, i32 31)
  %ffma.23 = call float @llvm.fma.f32(float %lds.23, float %shfl_idx.23, float %ffma.22)
  %lds_addr_memaddr_offset_add.26 = add i32 %.88, 3564
  %.252 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.26
  %lds.27 = load volatile float, ptr addrspace(3) %.252, align 4
  %shfl_activemask.26 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.26 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.26, float %phi.28, i32 26, i32 31)
  %shfl_activemask.27 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.27 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.27, float %phi.28, i32 31, i32 31)
  %ffma.24 = call float @llvm.fma.f32(float %lds.24, float %shfl_idx.24, float %ffma.23)
  %shfl_activemask.28 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.28 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.28, float %phi.28, i32 27, i32 31)
  %shfl_activemask.29 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.29 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.29, float %phi.28, i32 29, i32 31)
  %ffma.25 = call float @llvm.fma.f32(float %lds.26, float %shfl_idx.25, float %ffma.24)
  %lds_addr_memaddr_offset_add.27 = add i32 %.88, 3828
  %.253 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.27
  %lds.28 = load volatile float, ptr addrspace(3) %.253, align 4
  %ffma.26 = call float @llvm.fma.f32(float %lds.25, float %shfl_idx.26, float %ffma.25)
  %lds_addr_memaddr_offset_add.28 = add i32 %.88, 3696
  %.254 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.28
  %lds.29 = load volatile float, ptr addrspace(3) %.254, align 4
  %lds_addr_memaddr_offset_add.29 = add i32 %.88, 3960
  %.255 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.29
  %lds.30 = load volatile float, ptr addrspace(3) %.255, align 4
  %lds_addr_memaddr_offset_add.30 = add i32 %.88, 4092
  %.256 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.30
  %lds.31 = load volatile float, ptr addrspace(3) %.256, align 4
  %ffma.27 = call float @llvm.fma.f32(float %lds.27, float %shfl_idx.28, float %ffma.26)
  %shfl_activemask.30 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.30 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.30, float %phi.28, i32 30, i32 31)
  %shfl_activemask.31 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.31 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.31, float %phi.28, i32 28, i32 31)
  br label %BB_0ba0

BB_0ba0:                                          ; preds = %BB_0620
  %ffma.28 = call float @llvm.fma.f32(float %lds.29, float %shfl_idx.31, float %ffma.27)
  %ffma.29 = call float @llvm.fma.f32(float %lds.28, float %shfl_idx.29, float %ffma.28)
  %ffma.30 = call float @llvm.fma.f32(float %lds.30, float %shfl_idx.30, float %ffma.29)
  %ffma.31 = call float @llvm.fma.f32(float %lds.31, float %shfl_idx.27, float %ffma.30)
  %phi_cast_R1572_bitcast = bitcast float %ffma.26 to i32
  br label %BB_0be0

BB_0be0:                                          ; preds = %BB_0ba0, %BB_05b0
  %phi.29 = phi float [ %ffma.31, %BB_0ba0 ], [ %phi.14, %BB_05b0 ]
  %phi.30 = phi float [ %lds.28, %BB_0ba0 ], [ %phi_cast_R2620_bitcast, %BB_05b0 ]
  %phi.31 = phi float [ %lds.29, %BB_0ba0 ], [ %ldg.4, %BB_05b0 ]
  %phi.32 = phi i32 [ %phi_cast_R1572_bitcast, %BB_0ba0 ], [ %42, %BB_05b0 ]
  %ldc_const.14 = load i32, ptr %.23, align 4
  %47 = zext i32 %phi.32 to i64
  %48 = shl i64 %47, 32
  %49 = zext i32 %ldc_const.14 to i64
  %50 = or i64 %49, %48
  %imad_lhs_64.6 = sext i32 %ldc_const.14 to i64
  %imad_tmp_64.6 = mul i64 %imad_lhs_64.6, 32
  %51 = add i64 %imad_tmp_64.6, %46
  %iadd3_n1.2 = add i32 %phi.15, 1
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.6 = icmp uge i32 %iadd3_n1.2, %phi.9
  br label %BB_0c60

BB_0c60:                                          ; preds = %BB_0be0
  %cond_not.7 = xor i1 %isetrp_cmp1.6, true
  %phi_cast_R2155_bitcast = bitcast float %phi.30 to i32
  %phi_cast_R1985_bitcast = bitcast float %phi.31 to i32
  %52 = zext i32 %phi_cast_R2155_bitcast to i64
  %53 = shl i64 %52, 32
  %54 = zext i32 %phi_cast_R1985_bitcast to i64
  %55 = or i64 %54, %53
  br i1 %cond_not.7, label %BB_0470, label %BB_0c70

BB_0c70:                                          ; preds = %BB_0c60, %BB_0350
  %phi.33 = phi float [ %phi.8, %BB_0350 ], [ %phi.28, %BB_0c60 ]
  %phi.34 = phi float [ 0.000000e+00, %BB_0350 ], [ %phi.29, %BB_0c60 ]
  %ldc_const.15 = load i32, ptr %.23, align 4
  %imad_tmp.6 = mul i32 %phi.9, 32
  %ldc_const.16 = load i64, ptr %.20, align 8
  %56 = sext i32 %imad_tmp.6 to i64
  %57 = zext i32 %ldc_const.15 to i64
  %58 = and i64 %.81, -4294967296
  %59 = add i64 %57, 1
  %60 = add i64 %59, %58
  %61 = mul i64 %0, %1
  %62 = zext i32 %tid_x to i64
  %63 = add i64 %61, %62
  %64 = mul i64 %56, %60
  %65 = add i64 %64, %63
  %ldc_const.17 = load i32, ptr %.14, align 4
  %.287 = shl i64 %65, 2
  %66 = add i64 %ldc_const.16, %.287
  %imad_lhs_64.8 = sext i32 %ldc_const.15 to i64
  %imad_tmp_64.8 = mul i64 %imad_lhs_64.8, 32
  %67 = add i64 %imad_tmp_64.8, %66
  %"R1631:R1931_addr_ptr" = inttoptr i64 %66 to ptr addrspace(1)
  %ldg.6 = load i32, ptr addrspace(1) %"R1631:R1931_addr_ptr", align 4
  %68 = add i64 %imad_tmp_64.8, %67
  %"R2726:R2588_addr_ptr" = inttoptr i64 %67 to ptr addrspace(1)
  %ldg.7 = load i32, ptr addrspace(1) %"R2726:R2588_addr_ptr", align 4
  %imad.20 = add i64 %imad_tmp_64.8, %68
  %"R21:R20_r1_shift.1" = lshr i64 %imad.20, 32
  %"R21:R20_r1.1" = trunc i64 %"R21:R20_r1_shift.1" to i32
  %69 = add i64 %imad_tmp_64.8, %68
  %"R1964:R683_addr_ptr" = inttoptr i64 %68 to ptr addrspace(1)
  %ldg.8 = load i32, ptr addrspace(1) %"R1964:R683_addr_ptr", align 4
  %"R2196:R1986_addr_ptr" = inttoptr i64 %69 to ptr addrspace(1)
  %ldg.9 = load float, ptr addrspace(1) %"R2196:R1986_addr_ptr", align 4
  %isetrp_cmp1.7 = icmp uge i32 %iadd3_n1, %ldc_const.17
  %ldc_const.18 = load i64, ptr %.26, align 8
  %70 = add i64 %56, %10
  %.309 = shl i64 %70, 2
  %71 = add i64 %ldc_const.18, %.309
  br label %BB_0e60

BB_0e60:                                          ; preds = %BB_0c70
  %cond_not.8 = xor i1 %isetrp_cmp1.7, true
  br i1 %cond_not.8, label %BB_80000e60, label %BB_0e70

BB_80000e60:                                      ; preds = %BB_0e60
  %"R2733:R2592_addr_ptr" = inttoptr i64 %71 to ptr addrspace(1)
  %ldg.10 = load float, ptr addrspace(1) %"R2733:R2592_addr_ptr", align 4
  br label %BB_0e70

BB_0e70:                                          ; preds = %BB_80000e60, %BB_0e60
  %phi.35 = phi float [ %ldg.10, %BB_80000e60 ], [ %phi.33, %BB_0e60 ]
  %imad_tmp.10 = mul i32 %tid_y, 33
  %imad.21 = add i32 %imad_tmp.10, %tid_x
  %imad_tmp.11 = mul i32 %imad.21, 4
  %imad.22 = add i32 %imad_tmp.11, %phi.12
  %.318 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %imad.22
  store volatile i32 %ldg.6, ptr addrspace(3) %.318, align 4
  %sts_addr_memaddr_offset_add.3 = add i32 %imad.22, 1056
  %.320 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.3
  store volatile i32 %ldg.7, ptr addrspace(3) %.320, align 4
  %sts_addr_memaddr_offset_add.4 = add i32 %imad.22, 2112
  %.322 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.4
  store volatile i32 %ldg.8, ptr addrspace(3) %.322, align 4
  %sts_addr_memaddr_offset_add.5 = add i32 %imad.22, 3168
  %.324 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.5
  store volatile float %ldg.9, ptr addrspace(3) %.324, align 4
  call void @llvm.nvvm.barrier0()
  br label %BB_0ee0

BB_0ee0:                                          ; preds = %BB_0e70
  %72 = zext i1 %isetrp_cmp1.7 to i32
  %73 = icmp ne i32 %72, 0
  br i1 %73, label %BB_4cd0, label %BB_0ef0

BB_0ef0:                                          ; preds = %BB_0ee0
  %isetrp_cmp1.8 = icmp ne i32 %tid_x, 0
  br label %BB_0f20

BB_0f20:                                          ; preds = %BB_0ef0
  %74 = zext i1 %isetrp_cmp1.8 to i32
  %75 = icmp ne i32 %74, 0
  br i1 %75, label %BB_1070, label %BB_0f30

BB_0f30:                                          ; preds = %BB_0f20
  %ffma_addend_fneg = fneg float %phi.34
  %ffma.32 = call float @llvm.fma.f32(float %phi.35, float %phi, float %ffma_addend_fneg)
  %.337 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.75
  %lds.32 = load volatile float, ptr addrspace(3) %.337, align 4
  %mufu_rcp = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.32)
  %fchk_num_bits = bitcast float %ffma.32 to i32
  %fchk_den_bits = bitcast float %lds.32 to i32
  %fchk_aden = and i32 %fchk_den_bits, 2147483647
  %fchk_anum = and i32 %fchk_num_bits, 2147483647
  %fchk_den_subz = icmp ult i32 %fchk_aden, 8388608
  %fchk_den_infnan = icmp uge i32 %fchk_aden, 2139095040
  %fchk_num_infnan = icmp uge i32 %fchk_anum, 2139095040
  %fchk_den_bad = or i1 %fchk_den_subz, %fchk_den_infnan
  %fchk_px = or i1 %fchk_den_bad, %fchk_num_infnan
  %ffma_lhs_fneg = fneg float %lds.32
  %ffma.33 = call float @llvm.fma.f32(float %ffma_lhs_fneg, float %mufu_rcp, float 1.000000e+00)
  %ffma.34 = call float @llvm.fma.f32(float %mufu_rcp, float %ffma.33, float %mufu_rcp)
  %ffma.35 = call float @llvm.fma.f32(float %ffma.32, float %ffma.34, float 0.000000e+00)
  %ffma.36 = call float @llvm.fma.f32(float %ffma_lhs_fneg, float %ffma.35, float %ffma.32)
  %ffma.37 = call float @llvm.fma.f32(float %ffma.34, float %ffma.36, float %ffma.35)
  br label %BB_1010

BB_1010:                                          ; preds = %BB_0f30
  %cond_not.9 = xor i1 %fchk_px, true
  br i1 %cond_not.9, label %BB_1070, label %BB_1040_6f40

BB_1040_6f40:                                     ; preds = %BB_1010
  %.341 = zext i32 %fchk_den_bits to i64
  %.342 = shl i64 %.341, 32
  %.343 = lshr i64 %.342, 23
  %shf_hi.5 = lshr i64 %.343, 32
  %shf_result.6 = trunc i64 %shf_hi.5 to i32
  %.345 = zext i32 %fchk_num_bits to i64
  %.346 = shl i64 %.345, 32
  %.347 = lshr i64 %.346, 23
  %shf_hi.6 = lshr i64 %.347, 32
  %shf_result.7 = trunc i64 %shf_hi.6 to i32
  %.351 = and i32 %shf_result.6, 255
  %.359 = and i32 %shf_result.7, 255
  %iadd3_n1.7 = add i32 %.351, -1
  %iadd3_n1.8 = add i32 %.359, -1
  %isetrp_cmp1.9 = icmp ugt i32 %iadd3_n1.7, 253
  %isetrp_cmp1.10 = icmp ugt i32 %iadd3_n1.8, 253
  %isetrp_cmp2.10 = or i1 %isetrp_cmp1.10, %isetrp_cmp1.9
  br label %BB_1040_6fd0

BB_1040_6fd0:                                     ; preds = %BB_1040_6f40
  %cond_not.10 = xor i1 %isetrp_cmp2.10, true
  br i1 %cond_not.10, label %BB_1040_80006fd0, label %BB_1040_6ff0

BB_1040_6ff0:                                     ; preds = %BB_1040_6fd0
  %fsetrp_lhs_fabs = call float @llvm.nvvm.fabs.f(float %ffma.32)
  %fsetrp_cmp1 = fcmp ugt float %fsetrp_lhs_fabs, 0x7FF0000000000000
  %fsetrp_lhs_fabs.1 = call float @llvm.nvvm.fabs.f(float %lds.32)
  %fsetrp_cmp1.1 = fcmp ugt float %fsetrp_lhs_fabs.1, 0x7FF0000000000000
  %lop3_a_cast_zext = zext i1 %fsetrp_cmp1 to i32
  %lop3_b_cast_zext = zext i1 %fsetrp_cmp1.1 to i32
  %plop3_a_bit = and i32 %lop3_a_cast_zext, 1
  %plop3_b_bit = and i32 %lop3_b_cast_zext, 1
  %.366 = xor i32 %plop3_a_bit, 1
  %.367 = xor i32 %plop3_b_bit, 1
  %.369 = and i32 %.366, %plop3_b_bit
  %.371 = and i32 %plop3_a_bit, %.367
  %.373 = or i32 %.369, %.371
  %.374 = and i32 %plop3_a_bit, %plop3_b_bit
  %.376 = or i32 %.373, %.374
  %lop3_pred_cmp = icmp ne i32 %.376, 0
  br label %BB_1040_7020

BB_1040_7020:                                     ; preds = %BB_1040_6ff0
  %76 = zext i1 %lop3_pred_cmp to i32
  %77 = icmp ne i32 %76, 0
  br i1 %77, label %BB_1040_7580, label %BB_1040_7030

BB_1040_7030:                                     ; preds = %BB_1040_7020
  %.379 = xor i32 %fchk_den_bits, -1
  %.381 = xor i32 %fchk_num_bits, -1
  %.382 = and i32 %.379, 2147483647
  %.383 = and i32 %.382, %fchk_num_bits
  %.385 = and i32 %fchk_aden, %.381
  %.386 = or i32 %.383, %.385
  %.388 = and i32 %fchk_aden, %fchk_num_bits
  %.389 = or i32 %.386, %.388
  %lop3_pred_cmp.1 = icmp ne i32 %.389, 0
  br label %BB_1040_7040

BB_1040_7040:                                     ; preds = %BB_1040_7030
  %cond_not.11 = xor i1 %lop3_pred_cmp.1, true
  br i1 %cond_not.11, label %BB_1040_7560, label %BB_1040_7050

BB_1040_7050:                                     ; preds = %BB_1040_7040
  %fsetrp_cmp1.2 = fcmp une float %fsetrp_lhs_fabs, 0x7FF0000000000000
  %fsetrp_cmp1.3 = fcmp une float %fsetrp_lhs_fabs.1, 0x7FF0000000000000
  br label %BB_1040_7080

BB_1040_7080:                                     ; preds = %BB_1040_7050
  %cond_not.12 = xor i1 %fsetrp_cmp1.3, true
  br i1 %cond_not.12, label %BB_1040_80007080, label %BB_1040_7090

BB_1040_80007080:                                 ; preds = %BB_1040_7080
  %bra_cond_not = xor i1 %fsetrp_cmp1.2, true
  br i1 %bra_cond_not, label %BB_1040_7560, label %BB_1040_7090

BB_1040_7090:                                     ; preds = %BB_1040_80007080, %BB_1040_7080
  %lop3_pred_cmp.2 = icmp ne i32 %fchk_anum, 0
  %lop3_a_cast_zext.1 = zext i1 %fsetrp_cmp1.3 to i32
  %lop3_b_cast_zext.1 = zext i1 %lop3_pred_cmp.2 to i32
  %plop3_a_bit.1 = and i32 %lop3_a_cast_zext.1, 1
  %plop3_b_bit.1 = and i32 %lop3_b_cast_zext.1, 1
  %.403 = xor i32 %plop3_a_bit.1, 1
  %.404 = xor i32 %plop3_b_bit.1, 1
  %.406 = and i32 %.403, %.404
  %.408 = and i32 %.403, %plop3_b_bit.1
  %.410 = or i32 %.406, %.408
  %.411 = and i32 %plop3_a_bit.1, %.404
  %.413 = or i32 %.410, %.411
  %lop3_pred_cmp.3 = icmp ne i32 %.413, 0
  br label %BB_1040_70b0

BB_1040_70b0:                                     ; preds = %BB_1040_7090
  %78 = zext i1 %lop3_pred_cmp.3 to i32
  %79 = icmp ne i32 %78, 0
  br i1 %79, label %BB_1040_7540, label %BB_1040_70c0

BB_1040_70c0:                                     ; preds = %BB_1040_70b0
  %lop3_pred_cmp.4 = icmp ne i32 %fchk_aden, 0
  %lop3_a_cast_zext.2 = zext i1 %fsetrp_cmp1.2 to i32
  %lop3_b_cast_zext.2 = zext i1 %lop3_pred_cmp.4 to i32
  %plop3_a_bit.2 = and i32 %lop3_a_cast_zext.2, 1
  %plop3_b_bit.2 = and i32 %lop3_b_cast_zext.2, 1
  %.424 = xor i32 %plop3_a_bit.2, 1
  %.425 = xor i32 %plop3_b_bit.2, 1
  %.427 = and i32 %.424, %.425
  %.429 = and i32 %.424, %plop3_b_bit.2
  %.431 = or i32 %.427, %.429
  %.432 = and i32 %plop3_a_bit.2, %.425
  %.434 = or i32 %.431, %.432
  %lop3_pred_cmp.5 = icmp ne i32 %.434, 0
  br label %BB_1040_70e0

BB_1040_70e0:                                     ; preds = %BB_1040_70c0
  %80 = zext i1 %lop3_pred_cmp.5 to i32
  %81 = icmp ne i32 %80, 0
  br i1 %81, label %BB_1040_7510, label %BB_1040_70f0

BB_1040_70f0:                                     ; preds = %BB_1040_70e0
  %isetrp_cmp1.11 = icmp sge i32 %iadd3_n1.8, 0
  %isetrp_cmp1.12 = icmp sge i32 %iadd3_n1.7, 0
  br label %BB_1040_7130

BB_1040_7130:                                     ; preds = %BB_1040_70f0
  %82 = zext i1 %isetrp_cmp1.11 to i32
  %83 = icmp ne i32 %82, 0
  br i1 %83, label %BB_1040_80007130, label %BB_1040_7140

BB_1040_80007130:                                 ; preds = %BB_1040_7130
  br label %BB_1040_7140

BB_1040_7140:                                     ; preds = %BB_1040_80007130, %BB_1040_7130
  %phi.36 = phi i32 [ 0, %BB_1040_80007130 ], [ %iadd3_n1.7, %BB_1040_7130 ]
  %cond_not.13 = xor i1 %isetrp_cmp1.11, true
  br i1 %cond_not.13, label %BB_1040_80007140, label %BB_1040_7160

BB_1040_80007140:                                 ; preds = %BB_1040_7140
  %ffma.38 = call float @llvm.fma.f32(float %ffma.32, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2967_bitcast = bitcast float %ffma.38 to i32
  br label %BB_1040_7160

BB_1040_7160:                                     ; preds = %BB_1040_80007140, %BB_1040_7140
  %phi.37 = phi i32 [ %phi_cast_R2967_bitcast, %BB_1040_80007140 ], [ %fchk_num_bits, %BB_1040_7140 ]
  %phi.38 = phi i32 [ -64, %BB_1040_80007140 ], [ %phi.36, %BB_1040_7140 ]
  %cond_not.14 = xor i1 %isetrp_cmp1.12, true
  br i1 %cond_not.14, label %BB_1040_80007160, label %BB_1040_7180

BB_1040_80007160:                                 ; preds = %BB_1040_7160
  %ffma.39 = call float @llvm.fma.f32(float %lds.32, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.1 = add i32 %phi.38, 64
  %phi_cast_R442_bitcast = bitcast float %ffma.39 to i32
  br label %BB_1040_7180

BB_1040_7510:                                     ; preds = %BB_1040_70e0
  %.447 = and i32 %.379, -2147483648
  %.448 = and i32 %.447, %fchk_num_bits
  %.449 = and i32 %fchk_den_bits, -2147483648
  %.450 = and i32 %.449, %.381
  %.451 = or i32 %.448, %.450
  %.452 = xor i32 %.451, -1
  %.455 = and i32 %.452, 2139095040
  %.462 = or i32 %.455, %.451
  %phi_cast_R3002_bitcast = bitcast i32 %.462 to float
  br label %BB_1040_7590

BB_1040_7540:                                     ; preds = %BB_1040_70b0
  %.476 = and i32 %.379, -2147483648
  %.477 = and i32 %.476, %fchk_num_bits
  %.478 = and i32 %fchk_den_bits, -2147483648
  %.479 = and i32 %.478, %.381
  %.480 = or i32 %.477, %.479
  %phi_cast_R3013_bitcast = bitcast i32 %.480 to float
  br label %BB_1040_7590

BB_1040_7560:                                     ; preds = %BB_1040_80007080, %BB_1040_7040
  %mufu_rsq = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1040_7590

BB_1040_7580:                                     ; preds = %BB_1040_7020
  %fadd = fadd float %ffma.32, %lds.32
  br label %BB_1040_7590

BB_1040_80006fd0:                                 ; preds = %BB_1040_6fd0
  br label %BB_1040_7180

BB_1040_7180:                                     ; preds = %BB_1040_80006fd0, %BB_1040_80007160, %BB_1040_7160
  %phi.39 = phi i32 [ %fchk_den_bits, %BB_1040_80006fd0 ], [ %phi_cast_R442_bitcast, %BB_1040_80007160 ], [ %fchk_den_bits, %BB_1040_7160 ]
  %phi.40 = phi i32 [ %fchk_num_bits, %BB_1040_80006fd0 ], [ %phi.37, %BB_1040_80007160 ], [ %phi.37, %BB_1040_7160 ]
  %phi.41 = phi i32 [ 0, %BB_1040_80006fd0 ], [ %viadd.1, %BB_1040_80007160 ], [ %phi.38, %BB_1040_7160 ]
  %.485 = zext i32 %.351 to i64
  %.488 = shl i64 %.485, 23
  %.489 = and i64 %.488, 4294967295
  %.490 = add i64 %.489, 3229614080
  %.491 = trunc i64 %.490 to i32
  %iadd3_n1.10 = add i32 %.359, -127
  %iadd3_o1_not = xor i32 %.491, -1
  %iadd3_o1_neg = add i32 %iadd3_o1_not, 1
  %iadd3_n1.11 = add i32 %iadd3_o1_neg, %phi.39
  %imad_tmp.12 = mul i32 %iadd3_n1.10, -8388608
  %imad.23 = add i32 %imad_tmp.12, %phi.40
  %mufu_src_bitcast = bitcast i32 %iadd3_n1.11 to float
  %mufu_rcp.1 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast)
  %fadd_lhs_fneg = fneg float %mufu_src_bitcast
  %fadd.1 = fadd float %fadd_lhs_fneg, 0.000000e+00
  %iadd3_o3_not = xor i32 %.351, -1
  %iadd3_o3_neg = add i32 %iadd3_o3_not, 1
  %iadd3_n2.12 = add i32 %.359, %iadd3_o3_neg
  %iadd3_n1.13 = add i32 %iadd3_n2.12, %phi.41
  %ffma.40 = call float @llvm.fma.f32(float %mufu_rcp.1, float %fadd.1, float 1.000000e+00)
  %ffma.41 = call float @llvm.fma.f32(float %mufu_rcp.1, float %ffma.40, float %mufu_rcp.1)
  %ffma_lhs_bitcast = bitcast i32 %imad.23 to float
  %ffma.42 = call float @llvm.fma.f32(float %ffma_lhs_bitcast, float %ffma.41, float 0.000000e+00)
  %ffma.43 = call float @llvm.fma.f32(float %fadd.1, float %ffma.42, float %ffma_lhs_bitcast)
  %ffma.44 = call float @llvm.fma.f32(float %ffma.41, float %ffma.43, float %ffma.42)
  %ffma.45 = call float @llvm.fma.f32(float %fadd.1, float %ffma.44, float %ffma_lhs_bitcast)
  %ffma.46 = call float @llvm.fma.f32(float %ffma.41, float %ffma.45, float %ffma.44)
  %shf_hi_bitcast.2 = bitcast float %ffma.46 to i32
  %.493 = zext i32 %shf_hi_bitcast.2 to i64
  %.494 = shl i64 %.493, 32
  %.495 = lshr i64 %.494, 23
  %shf_hi.7 = lshr i64 %.495, 32
  %shf_result.8 = trunc i64 %shf_hi.7 to i32
  %.499 = and i32 %shf_result.8, 255
  %imad.24 = add i32 %.499, %iadd3_n1.13
  %iadd3_n1.14 = add i32 %imad.24, -1
  %isetrp_cmp1.13 = icmp uge i32 %iadd3_n1.14, 254
  br label %BB_1040_72d0

BB_1040_72d0:                                     ; preds = %BB_1040_7180
  %cond_not.15 = xor i1 %isetrp_cmp1.13, true
  br i1 %cond_not.15, label %BB_1040_74e0, label %BB_1040_72e0

BB_1040_72e0:                                     ; preds = %BB_1040_72d0
  %isetrp_cmp1.14 = icmp sgt i32 %imad.24, 254
  br label %BB_1040_72f0

BB_1040_72f0:                                     ; preds = %BB_1040_72e0
  %84 = zext i1 %isetrp_cmp1.14 to i32
  %85 = icmp ne i32 %84, 0
  br i1 %85, label %BB_1040_74b0, label %BB_1040_7300

BB_1040_7300:                                     ; preds = %BB_1040_72f0
  %isetrp_cmp1.15 = icmp sge i32 %imad.24, 1
  br label %BB_1040_7310

BB_1040_7310:                                     ; preds = %BB_1040_7300
  %86 = zext i1 %isetrp_cmp1.15 to i32
  %87 = icmp ne i32 %86, 0
  br i1 %87, label %BB_1040_7590, label %BB_1040_7320

BB_1040_7320:                                     ; preds = %BB_1040_7310
  %isetrp_cmp1.16 = icmp sge i32 %imad.24, -24
  %.513 = and i32 %shf_hi_bitcast.2, -2147483648
  br label %BB_1040_7340

BB_1040_7340:                                     ; preds = %BB_1040_7320
  %cond_not.16 = xor i1 %isetrp_cmp1.16, true
  %phi_cast_R4_bitcast = bitcast i32 %.513 to float
  br i1 %cond_not.16, label %BB_1040_7590, label %BB_1040_7350

BB_1040_7350:                                     ; preds = %BB_1040_7340
  %ffma_rz = call float @llvm.nvvm.fma.rz.f(float %ffma.41, float %ffma.45, float %ffma.44)
  %iadd3_n1.15 = add i32 %imad.24, 32
  %lop3_a_bitcast.6 = bitcast float %ffma_rz to i32
  %.523 = and i32 %lop3_a_bitcast.6, 8388607
  %ffma_rp = call float @llvm.nvvm.fma.rp.f(float %ffma.41, float %ffma.45, float %ffma.44)
  %ffma_rm = call float @llvm.nvvm.fma.rm.f(float %ffma.41, float %ffma.45, float %ffma.44)
  %isetrp_cmp1.18 = icmp ne i32 %imad.24, 0
  %.538 = or i32 8388608, %.523
  %iadd3_o1_not.1 = xor i32 %imad.24, -1
  %iadd3_o1_neg.1 = add i32 %iadd3_o1_not.1, 1
  %.548 = zext i32 %.538 to i64
  %shf_shift_64.9 = zext i32 %iadd3_n1.15 to i64
  %.551 = shl i64 %.548, %shf_shift_64.9
  %shf_result.9 = trunc i64 %.551 to i32
  %fsetrp_cmp1.5 = fcmp une float %ffma_rp, %ffma_rm
  %isetrp_cmp1.19 = icmp ne i32 %shf_result.9, 0
  %isetrp_cmp2.19 = and i1 %isetrp_cmp1.19, %isetrp_cmp1.18
  %.554 = shl i64 %.548, 32
  %shf_shift_64.10 = zext i32 %iadd3_o1_neg.1 to i64
  %.555 = lshr i64 %.554, %shf_shift_64.10
  %shf_hi.8 = lshr i64 %.555, 32
  %shf_result.10 = trunc i64 %shf_hi.8 to i32
  %lop3_a_cast_zext.3 = zext i1 %fsetrp_cmp1.5 to i32
  %lop3_b_cast_zext.3 = zext i1 %isetrp_cmp2.19 to i32
  %plop3_a_bit.3 = and i32 %lop3_a_cast_zext.3, 1
  %plop3_b_bit.3 = and i32 %lop3_b_cast_zext.3, 1
  %.556 = xor i32 %plop3_a_bit.3, 1
  %.557 = xor i32 %plop3_b_bit.3, 1
  %.559 = and i32 %.556, %plop3_b_bit.3
  %.561 = and i32 %plop3_a_bit.3, %.557
  %.563 = or i32 %.559, %.561
  %.564 = and i32 %plop3_a_bit.3, %plop3_b_bit.3
  %.566 = or i32 %.563, %.564
  %lop3_pred_cmp.6 = icmp ne i32 %.566, 0
  %.568 = zext i32 %shf_result.10 to i64
  %.569 = shl i64 %.568, 32
  %.570 = lshr i64 %.569, 1
  %shf_hi.9 = lshr i64 %.570, 32
  %shf_result.11 = trunc i64 %shf_hi.9 to i32
  %sel_pred_not = xor i1 %lop3_pred_cmp.6, true
  %sel.1 = select i1 %sel_pred_not, i32 0, i32 1
  %.571 = xor i32 %sel.1, -1
  %.573 = xor i32 %shf_result.11, -1
  %.574 = and i32 %.571, 1
  %.575 = and i32 %.574, %shf_result.11
  %.583 = and i32 %sel.1, %.573
  %.584 = or i32 %.575, %.583
  %.586 = and i32 %sel.1, %shf_result.11
  %.587 = or i32 %.584, %.586
  %.591 = and i32 %.587, %shf_result.10
  %imad.25 = add i32 %shf_result.11, %.591
  %.596 = xor i32 %imad.25, -1
  %.597 = xor i32 %.513, -1
  %.599 = and i32 %.596, %.513
  %.604 = and i32 %imad.25, %.597
  %.606 = or i32 %.599, %.604
  %.610 = and i32 %imad.25, %.513
  %.612 = or i32 %.606, %.610
  %phi_cast_R17_bitcast = bitcast i32 %.612 to float
  br label %BB_1040_7590

BB_1040_74b0:                                     ; preds = %BB_1040_72f0
  %.620 = and i32 %shf_hi_bitcast.2, -2147483648
  %.635 = or i32 2139095040, %.620
  %phi_cast_R42_bitcast = bitcast i32 %.635 to float
  br label %BB_1040_7590

BB_1040_74e0:                                     ; preds = %BB_1040_72d0
  %.646 = zext i32 %iadd3_n1.13 to i64
  %.649 = shl i64 %.646, 23
  %.650 = and i64 %.649, 4294967295
  %.651 = add i64 %.650, %.493
  %.652 = trunc i64 %.651 to i32
  %phi_cast_R54_bitcast = bitcast i32 %.652 to float
  br label %BB_1040_7590

BB_1040_7590:                                     ; preds = %BB_1040_74e0, %BB_1040_74b0, %BB_1040_7350, %BB_1040_7340, %BB_1040_7310, %BB_1040_7580, %BB_1040_7560, %BB_1040_7540, %BB_1040_7510
  %phi.42 = phi float [ %phi_cast_R17_bitcast, %BB_1040_7350 ], [ %phi_cast_R42_bitcast, %BB_1040_74b0 ], [ %phi_cast_R54_bitcast, %BB_1040_74e0 ], [ %ffma.46, %BB_1040_7310 ], [ %phi_cast_R4_bitcast, %BB_1040_7340 ], [ %phi_cast_R3002_bitcast, %BB_1040_7510 ], [ %phi_cast_R3013_bitcast, %BB_1040_7540 ], [ %mufu_rsq, %BB_1040_7560 ], [ %fadd, %BB_1040_7580 ]
  br label %BB_1070

BB_1070:                                          ; preds = %BB_1040_7590, %BB_1010, %BB_0f20
  %phi.43 = phi float [ %phi.42, %BB_1040_7590 ], [ %ffma.37, %BB_1010 ], [ %phi.35, %BB_0f20 ]
  %phi.44 = phi i32 [ %.75, %BB_1040_7590 ], [ %.75, %BB_1010 ], [ %phi.12, %BB_0f20 ]
  br label %BB_10a0

BB_10a0:                                          ; preds = %BB_1070
  %shfl_activemask.32 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.32 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.32, float %phi.43, i32 0, i32 31)
  br label %BB_10b0

BB_10b0:                                          ; preds = %BB_10a0
  %isetrp_cmp1.21 = icmp ne i32 %tid_x, 1
  br label %BB_10f0

BB_10f0:                                          ; preds = %BB_10b0
  %88 = zext i1 %isetrp_cmp1.8 to i32
  %89 = icmp ne i32 %88, 0
  br i1 %89, label %BB_800010f0, label %BB_1110

BB_800010f0:                                      ; preds = %BB_10f0
  %.659 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.88
  %lds.33 = load volatile float, ptr addrspace(3) %.659, align 4
  %ffma.47 = call float @llvm.fma.f32(float %shfl_idx.32, float %lds.33, float %phi.34)
  br label %BB_1110

BB_1110:                                          ; preds = %BB_800010f0, %BB_10f0
  %phi.45 = phi float [ %ffma.47, %BB_800010f0 ], [ %phi.34, %BB_10f0 ]
  %warp_reconv_mask = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  br i1 %isetrp_cmp1.21, label %BB_1270, label %BB_1120

BB_1120:                                          ; preds = %BB_1110
  %ffma_addend_fneg.1 = fneg float %phi.45
  %ffma.48 = call float @llvm.fma.f32(float %phi.43, float %phi, float %ffma_addend_fneg.1)
  %lds_addr_memaddr_offset_add.31 = add i32 %.75, 136
  %.669 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.31
  %lds.34 = load volatile float, ptr addrspace(3) %.669, align 4
  %mufu_rcp.2 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.34)
  %fchk_num_bits.1 = bitcast float %ffma.48 to i32
  %fchk_den_bits.1 = bitcast float %lds.34 to i32
  %fchk_aden.1 = and i32 %fchk_den_bits.1, 2147483647
  %fchk_anum.1 = and i32 %fchk_num_bits.1, 2147483647
  %fchk_den_subz.1 = icmp ult i32 %fchk_aden.1, 8388608
  %fchk_den_infnan.1 = icmp uge i32 %fchk_aden.1, 2139095040
  %fchk_num_infnan.1 = icmp uge i32 %fchk_anum.1, 2139095040
  %fchk_den_bad.1 = or i1 %fchk_den_subz.1, %fchk_den_infnan.1
  %fchk_px.1 = or i1 %fchk_den_bad.1, %fchk_num_infnan.1
  %ffma_lhs_fneg.2 = fneg float %lds.34
  %ffma.49 = call float @llvm.fma.f32(float %ffma_lhs_fneg.2, float %mufu_rcp.2, float 1.000000e+00)
  %ffma.50 = call float @llvm.fma.f32(float %mufu_rcp.2, float %ffma.49, float %mufu_rcp.2)
  %ffma.51 = call float @llvm.fma.f32(float %ffma.48, float %ffma.50, float 0.000000e+00)
  %ffma.52 = call float @llvm.fma.f32(float %ffma_lhs_fneg.2, float %ffma.51, float %ffma.48)
  %ffma.53 = call float @llvm.fma.f32(float %ffma.50, float %ffma.52, float %ffma.51)
  br label %BB_1200

BB_1200:                                          ; preds = %BB_1120
  %cond_not.17 = xor i1 %fchk_px.1, true
  br i1 %cond_not.17, label %BB_1250, label %BB_1230_6f40

BB_1230_6f40:                                     ; preds = %BB_1200
  %.673 = zext i32 %fchk_den_bits.1 to i64
  %.674 = shl i64 %.673, 32
  %.675 = lshr i64 %.674, 23
  %shf_hi.10 = lshr i64 %.675, 32
  %shf_result.12 = trunc i64 %shf_hi.10 to i32
  %.677 = zext i32 %fchk_num_bits.1 to i64
  %.678 = shl i64 %.677, 32
  %.679 = lshr i64 %.678, 23
  %shf_hi.11 = lshr i64 %.679, 32
  %shf_result.13 = trunc i64 %shf_hi.11 to i32
  %.683 = and i32 %shf_result.12, 255
  %.691 = and i32 %shf_result.13, 255
  %iadd3_n1.17 = add i32 %.683, -1
  %iadd3_n1.18 = add i32 %.691, -1
  %isetrp_cmp1.22 = icmp ugt i32 %iadd3_n1.17, 253
  %isetrp_cmp1.23 = icmp ugt i32 %iadd3_n1.18, 253
  %isetrp_cmp2.23 = or i1 %isetrp_cmp1.23, %isetrp_cmp1.22
  br label %BB_1230_6fd0

BB_1230_6fd0:                                     ; preds = %BB_1230_6f40
  %cond_not.18 = xor i1 %isetrp_cmp2.23, true
  br i1 %cond_not.18, label %BB_1230_80006fd0, label %BB_1230_6ff0

BB_1230_6ff0:                                     ; preds = %BB_1230_6fd0
  %fsetrp_lhs_fabs.5 = call float @llvm.nvvm.fabs.f(float %ffma.48)
  %fsetrp_cmp1.6 = fcmp ugt float %fsetrp_lhs_fabs.5, 0x7FF0000000000000
  %fsetrp_lhs_fabs.6 = call float @llvm.nvvm.fabs.f(float %lds.34)
  %fsetrp_cmp1.7 = fcmp ugt float %fsetrp_lhs_fabs.6, 0x7FF0000000000000
  %lop3_a_cast_zext.4 = zext i1 %fsetrp_cmp1.6 to i32
  %lop3_b_cast_zext.4 = zext i1 %fsetrp_cmp1.7 to i32
  %plop3_a_bit.4 = and i32 %lop3_a_cast_zext.4, 1
  %plop3_b_bit.4 = and i32 %lop3_b_cast_zext.4, 1
  %.698 = xor i32 %plop3_a_bit.4, 1
  %.699 = xor i32 %plop3_b_bit.4, 1
  %.701 = and i32 %.698, %plop3_b_bit.4
  %.703 = and i32 %plop3_a_bit.4, %.699
  %.705 = or i32 %.701, %.703
  %.706 = and i32 %plop3_a_bit.4, %plop3_b_bit.4
  %.708 = or i32 %.705, %.706
  %lop3_pred_cmp.7 = icmp ne i32 %.708, 0
  br label %BB_1230_7020

BB_1230_7020:                                     ; preds = %BB_1230_6ff0
  %90 = zext i1 %lop3_pred_cmp.7 to i32
  %91 = icmp ne i32 %90, 0
  br i1 %91, label %BB_1230_7580, label %BB_1230_7030

BB_1230_7030:                                     ; preds = %BB_1230_7020
  %.711 = xor i32 %fchk_den_bits.1, -1
  %.713 = xor i32 %fchk_num_bits.1, -1
  %.714 = and i32 %.711, 2147483647
  %.715 = and i32 %.714, %fchk_num_bits.1
  %.717 = and i32 %fchk_aden.1, %.713
  %.718 = or i32 %.715, %.717
  %.720 = and i32 %fchk_aden.1, %fchk_num_bits.1
  %.721 = or i32 %.718, %.720
  %lop3_pred_cmp.8 = icmp ne i32 %.721, 0
  br label %BB_1230_7040

BB_1230_7040:                                     ; preds = %BB_1230_7030
  %cond_not.19 = xor i1 %lop3_pred_cmp.8, true
  br i1 %cond_not.19, label %BB_1230_7560, label %BB_1230_7050

BB_1230_7050:                                     ; preds = %BB_1230_7040
  %fsetrp_cmp1.8 = fcmp une float %fsetrp_lhs_fabs.5, 0x7FF0000000000000
  %fsetrp_cmp1.9 = fcmp une float %fsetrp_lhs_fabs.6, 0x7FF0000000000000
  br label %BB_1230_7080

BB_1230_7080:                                     ; preds = %BB_1230_7050
  %cond_not.20 = xor i1 %fsetrp_cmp1.9, true
  br i1 %cond_not.20, label %BB_1230_80007080, label %BB_1230_7090

BB_1230_80007080:                                 ; preds = %BB_1230_7080
  %bra_cond_not.1 = xor i1 %fsetrp_cmp1.8, true
  br i1 %bra_cond_not.1, label %BB_1230_7560, label %BB_1230_7090

BB_1230_7090:                                     ; preds = %BB_1230_80007080, %BB_1230_7080
  %lop3_pred_cmp.9 = icmp ne i32 %fchk_anum.1, 0
  %lop3_a_cast_zext.5 = zext i1 %fsetrp_cmp1.9 to i32
  %lop3_b_cast_zext.5 = zext i1 %lop3_pred_cmp.9 to i32
  %plop3_a_bit.5 = and i32 %lop3_a_cast_zext.5, 1
  %plop3_b_bit.5 = and i32 %lop3_b_cast_zext.5, 1
  %.735 = xor i32 %plop3_a_bit.5, 1
  %.736 = xor i32 %plop3_b_bit.5, 1
  %.738 = and i32 %.735, %.736
  %.740 = and i32 %.735, %plop3_b_bit.5
  %.742 = or i32 %.738, %.740
  %.743 = and i32 %plop3_a_bit.5, %.736
  %.745 = or i32 %.742, %.743
  %lop3_pred_cmp.10 = icmp ne i32 %.745, 0
  br label %BB_1230_70b0

BB_1230_70b0:                                     ; preds = %BB_1230_7090
  %92 = zext i1 %lop3_pred_cmp.10 to i32
  %93 = icmp ne i32 %92, 0
  br i1 %93, label %BB_1230_7540, label %BB_1230_70c0

BB_1230_70c0:                                     ; preds = %BB_1230_70b0
  %lop3_pred_cmp.11 = icmp ne i32 %fchk_aden.1, 0
  %lop3_a_cast_zext.6 = zext i1 %fsetrp_cmp1.8 to i32
  %lop3_b_cast_zext.6 = zext i1 %lop3_pred_cmp.11 to i32
  %plop3_a_bit.6 = and i32 %lop3_a_cast_zext.6, 1
  %plop3_b_bit.6 = and i32 %lop3_b_cast_zext.6, 1
  %.756 = xor i32 %plop3_a_bit.6, 1
  %.757 = xor i32 %plop3_b_bit.6, 1
  %.759 = and i32 %.756, %.757
  %.761 = and i32 %.756, %plop3_b_bit.6
  %.763 = or i32 %.759, %.761
  %.764 = and i32 %plop3_a_bit.6, %.757
  %.766 = or i32 %.763, %.764
  %lop3_pred_cmp.12 = icmp ne i32 %.766, 0
  br label %BB_1230_70e0

BB_1230_70e0:                                     ; preds = %BB_1230_70c0
  %94 = zext i1 %lop3_pred_cmp.12 to i32
  %95 = icmp ne i32 %94, 0
  br i1 %95, label %BB_1230_7510, label %BB_1230_70f0

BB_1230_70f0:                                     ; preds = %BB_1230_70e0
  %isetrp_cmp1.24 = icmp sge i32 %iadd3_n1.18, 0
  %isetrp_cmp1.25 = icmp sge i32 %iadd3_n1.17, 0
  br label %BB_1230_7130

BB_1230_7130:                                     ; preds = %BB_1230_70f0
  %96 = zext i1 %isetrp_cmp1.24 to i32
  %97 = icmp ne i32 %96, 0
  br i1 %97, label %BB_1230_80007130, label %BB_1230_7140

BB_1230_80007130:                                 ; preds = %BB_1230_7130
  br label %BB_1230_7140

BB_1230_7140:                                     ; preds = %BB_1230_80007130, %BB_1230_7130
  %phi.46 = phi i32 [ 0, %BB_1230_80007130 ], [ %iadd3_n1.17, %BB_1230_7130 ]
  %cond_not.21 = xor i1 %isetrp_cmp1.24, true
  br i1 %cond_not.21, label %BB_1230_80007140, label %BB_1230_7160

BB_1230_80007140:                                 ; preds = %BB_1230_7140
  %ffma.54 = call float @llvm.fma.f32(float %ffma.48, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R129_bitcast = bitcast float %ffma.54 to i32
  br label %BB_1230_7160

BB_1230_7160:                                     ; preds = %BB_1230_80007140, %BB_1230_7140
  %phi.47 = phi i32 [ %phi_cast_R129_bitcast, %BB_1230_80007140 ], [ %fchk_num_bits.1, %BB_1230_7140 ]
  %phi.48 = phi i32 [ -64, %BB_1230_80007140 ], [ %phi.46, %BB_1230_7140 ]
  %cond_not.22 = xor i1 %isetrp_cmp1.25, true
  br i1 %cond_not.22, label %BB_1230_80007160, label %BB_1230_7180

BB_1230_80007160:                                 ; preds = %BB_1230_7160
  %ffma.55 = call float @llvm.fma.f32(float %lds.34, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.3 = add i32 %phi.48, 64
  %phi_cast_R617_bitcast = bitcast float %ffma.55 to i32
  br label %BB_1230_7180

BB_1230_7510:                                     ; preds = %BB_1230_70e0
  %.779 = and i32 %.711, -2147483648
  %.780 = and i32 %.779, %fchk_num_bits.1
  %.781 = and i32 %fchk_den_bits.1, -2147483648
  %.782 = and i32 %.781, %.713
  %.783 = or i32 %.780, %.782
  %.784 = xor i32 %.783, -1
  %.787 = and i32 %.784, 2139095040
  %.794 = or i32 %.787, %.783
  %phi_cast_R164_bitcast = bitcast i32 %.794 to float
  br label %BB_1230_7590

BB_1230_7540:                                     ; preds = %BB_1230_70b0
  %.808 = and i32 %.711, -2147483648
  %.809 = and i32 %.808, %fchk_num_bits.1
  %.810 = and i32 %fchk_den_bits.1, -2147483648
  %.811 = and i32 %.810, %.713
  %.812 = or i32 %.809, %.811
  %phi_cast_R177_bitcast = bitcast i32 %.812 to float
  br label %BB_1230_7590

BB_1230_7560:                                     ; preds = %BB_1230_80007080, %BB_1230_7040
  %mufu_rsq.1 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1230_7590

BB_1230_7580:                                     ; preds = %BB_1230_7020
  %fadd.2 = fadd float %ffma.48, %lds.34
  br label %BB_1230_7590

BB_1230_80006fd0:                                 ; preds = %BB_1230_6fd0
  br label %BB_1230_7180

BB_1230_7180:                                     ; preds = %BB_1230_80006fd0, %BB_1230_80007160, %BB_1230_7160
  %phi.49 = phi i32 [ %fchk_den_bits.1, %BB_1230_80006fd0 ], [ %phi_cast_R617_bitcast, %BB_1230_80007160 ], [ %fchk_den_bits.1, %BB_1230_7160 ]
  %phi.50 = phi i32 [ %fchk_num_bits.1, %BB_1230_80006fd0 ], [ %phi.47, %BB_1230_80007160 ], [ %phi.47, %BB_1230_7160 ]
  %phi.51 = phi i32 [ 0, %BB_1230_80006fd0 ], [ %viadd.3, %BB_1230_80007160 ], [ %phi.48, %BB_1230_7160 ]
  %.817 = zext i32 %.683 to i64
  %.820 = shl i64 %.817, 23
  %.821 = and i64 %.820, 4294967295
  %.822 = add i64 %.821, 3229614080
  %.823 = trunc i64 %.822 to i32
  %iadd3_n1.20 = add i32 %.691, -127
  %iadd3_o1_not.2 = xor i32 %.823, -1
  %iadd3_o1_neg.2 = add i32 %iadd3_o1_not.2, 1
  %iadd3_n1.21 = add i32 %iadd3_o1_neg.2, %phi.49
  %imad_tmp.16 = mul i32 %iadd3_n1.20, -8388608
  %imad.27 = add i32 %imad_tmp.16, %phi.50
  %mufu_src_bitcast.1 = bitcast i32 %iadd3_n1.21 to float
  %mufu_rcp.3 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.1)
  %fadd_lhs_fneg.1 = fneg float %mufu_src_bitcast.1
  %fadd.3 = fadd float %fadd_lhs_fneg.1, 0.000000e+00
  %iadd3_o3_not.1 = xor i32 %.683, -1
  %iadd3_o3_neg.1 = add i32 %iadd3_o3_not.1, 1
  %iadd3_n2.22 = add i32 %.691, %iadd3_o3_neg.1
  %iadd3_n1.23 = add i32 %iadd3_n2.22, %phi.51
  %ffma.56 = call float @llvm.fma.f32(float %mufu_rcp.3, float %fadd.3, float 1.000000e+00)
  %ffma.57 = call float @llvm.fma.f32(float %mufu_rcp.3, float %ffma.56, float %mufu_rcp.3)
  %ffma_lhs_bitcast.1 = bitcast i32 %imad.27 to float
  %ffma.58 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.1, float %ffma.57, float 0.000000e+00)
  %ffma.59 = call float @llvm.fma.f32(float %fadd.3, float %ffma.58, float %ffma_lhs_bitcast.1)
  %ffma.60 = call float @llvm.fma.f32(float %ffma.57, float %ffma.59, float %ffma.58)
  %ffma.61 = call float @llvm.fma.f32(float %fadd.3, float %ffma.60, float %ffma_lhs_bitcast.1)
  %ffma.62 = call float @llvm.fma.f32(float %ffma.57, float %ffma.61, float %ffma.60)
  %shf_hi_bitcast.5 = bitcast float %ffma.62 to i32
  %.825 = zext i32 %shf_hi_bitcast.5 to i64
  %.826 = shl i64 %.825, 32
  %.827 = lshr i64 %.826, 23
  %shf_hi.12 = lshr i64 %.827, 32
  %shf_result.14 = trunc i64 %shf_hi.12 to i32
  %.831 = and i32 %shf_result.14, 255
  %imad.28 = add i32 %.831, %iadd3_n1.23
  %iadd3_n1.24 = add i32 %imad.28, -1
  %isetrp_cmp1.26 = icmp uge i32 %iadd3_n1.24, 254
  br label %BB_1230_72d0

BB_1230_72d0:                                     ; preds = %BB_1230_7180
  %cond_not.23 = xor i1 %isetrp_cmp1.26, true
  br i1 %cond_not.23, label %BB_1230_74e0, label %BB_1230_72e0

BB_1230_72e0:                                     ; preds = %BB_1230_72d0
  %isetrp_cmp1.27 = icmp sgt i32 %imad.28, 254
  br label %BB_1230_72f0

BB_1230_72f0:                                     ; preds = %BB_1230_72e0
  %98 = zext i1 %isetrp_cmp1.27 to i32
  %99 = icmp ne i32 %98, 0
  br i1 %99, label %BB_1230_74b0, label %BB_1230_7300

BB_1230_7300:                                     ; preds = %BB_1230_72f0
  %isetrp_cmp1.28 = icmp sge i32 %imad.28, 1
  br label %BB_1230_7310

BB_1230_7310:                                     ; preds = %BB_1230_7300
  %phi_cast_R668_bitcast.2 = bitcast i32 %iadd3_n1.23 to float
  br i1 %isetrp_cmp1.28, label %BB_1230_7590, label %BB_1230_7320

BB_1230_7320:                                     ; preds = %BB_1230_7310
  %isetrp_cmp1.29 = icmp sge i32 %imad.28, -24
  %.845 = and i32 %shf_hi_bitcast.5, -2147483648
  br label %BB_1230_7340

BB_1230_7340:                                     ; preds = %BB_1230_7320
  %cond_not.24 = xor i1 %isetrp_cmp1.29, true
  %phi_cast_R252_bitcast = bitcast i32 %.845 to float
  br i1 %cond_not.24, label %BB_1230_7590, label %BB_1230_7350

BB_1230_7350:                                     ; preds = %BB_1230_7340
  %ffma_rz.1 = call float @llvm.nvvm.fma.rz.f(float %ffma.57, float %ffma.61, float %ffma.60)
  %iadd3_n1.25 = add i32 %imad.28, 32
  %lop3_a_bitcast.14 = bitcast float %ffma_rz.1 to i32
  %.855 = and i32 %lop3_a_bitcast.14, 8388607
  %ffma_rp.1 = call float @llvm.nvvm.fma.rp.f(float %ffma.57, float %ffma.61, float %ffma.60)
  %ffma_rm.1 = call float @llvm.nvvm.fma.rm.f(float %ffma.57, float %ffma.61, float %ffma.60)
  %isetrp_cmp1.31 = icmp ne i32 %imad.28, 0
  %.870 = or i32 8388608, %.855
  %iadd3_o1_not.3 = xor i32 %imad.28, -1
  %iadd3_o1_neg.3 = add i32 %iadd3_o1_not.3, 1
  %.880 = zext i32 %.870 to i64
  %shf_shift_64.15 = zext i32 %iadd3_n1.25 to i64
  %.883 = shl i64 %.880, %shf_shift_64.15
  %shf_result.15 = trunc i64 %.883 to i32
  %fsetrp_cmp1.11 = fcmp une float %ffma_rp.1, %ffma_rm.1
  %isetrp_cmp1.32 = icmp ne i32 %shf_result.15, 0
  %isetrp_cmp2.32 = and i1 %isetrp_cmp1.32, %isetrp_cmp1.31
  %.886 = shl i64 %.880, 32
  %shf_shift_64.16 = zext i32 %iadd3_o1_neg.3 to i64
  %.887 = lshr i64 %.886, %shf_shift_64.16
  %shf_hi.13 = lshr i64 %.887, 32
  %shf_result.16 = trunc i64 %shf_hi.13 to i32
  %lop3_a_cast_zext.7 = zext i1 %fsetrp_cmp1.11 to i32
  %lop3_b_cast_zext.7 = zext i1 %isetrp_cmp2.32 to i32
  %plop3_a_bit.7 = and i32 %lop3_a_cast_zext.7, 1
  %plop3_b_bit.7 = and i32 %lop3_b_cast_zext.7, 1
  %.888 = xor i32 %plop3_a_bit.7, 1
  %.889 = xor i32 %plop3_b_bit.7, 1
  %.891 = and i32 %.888, %plop3_b_bit.7
  %.893 = and i32 %plop3_a_bit.7, %.889
  %.895 = or i32 %.891, %.893
  %.896 = and i32 %plop3_a_bit.7, %plop3_b_bit.7
  %.898 = or i32 %.895, %.896
  %lop3_pred_cmp.13 = icmp ne i32 %.898, 0
  %.900 = zext i32 %shf_result.16 to i64
  %.901 = shl i64 %.900, 32
  %.902 = lshr i64 %.901, 1
  %shf_hi.14 = lshr i64 %.902, 32
  %shf_result.17 = trunc i64 %shf_hi.14 to i32
  %sel_pred_not.1 = xor i1 %lop3_pred_cmp.13, true
  %sel.3 = select i1 %sel_pred_not.1, i32 0, i32 1
  %.903 = xor i32 %sel.3, -1
  %.905 = xor i32 %shf_result.17, -1
  %.906 = and i32 %.903, 1
  %.907 = and i32 %.906, %shf_result.17
  %.915 = and i32 %sel.3, %.905
  %.916 = or i32 %.907, %.915
  %.918 = and i32 %sel.3, %shf_result.17
  %.919 = or i32 %.916, %.918
  %.923 = and i32 %.919, %shf_result.16
  %imad.29 = add i32 %shf_result.17, %.923
  %.928 = xor i32 %imad.29, -1
  %.929 = xor i32 %.845, -1
  %.931 = and i32 %.928, %.845
  %.936 = and i32 %imad.29, %.929
  %.938 = or i32 %.931, %.936
  %.942 = and i32 %imad.29, %.845
  %.944 = or i32 %.938, %.942
  %phi_cast_R264_bitcast = bitcast i32 %.944 to float
  %phi_cast_R1113_bitcast = bitcast i32 %.870 to float
  br label %BB_1230_7590

BB_1230_74b0:                                     ; preds = %BB_1230_72f0
  %.952 = and i32 %shf_hi_bitcast.5, -2147483648
  %.967 = or i32 2139095040, %.952
  %phi_cast_R289_bitcast = bitcast i32 %.967 to float
  %phi_cast_R668_bitcast = bitcast i32 %iadd3_n1.23 to float
  br label %BB_1230_7590

BB_1230_74e0:                                     ; preds = %BB_1230_72d0
  %.978 = zext i32 %iadd3_n1.23 to i64
  %.981 = shl i64 %.978, 23
  %.982 = and i64 %.981, 4294967295
  %.983 = add i64 %.982, %.825
  %.984 = trunc i64 %.983 to i32
  %phi_cast_R303_bitcast = bitcast i32 %.984 to float
  %phi_cast_R668_bitcast.1 = bitcast i32 %iadd3_n1.23 to float
  br label %BB_1230_7590

BB_1230_7590:                                     ; preds = %BB_1230_74e0, %BB_1230_74b0, %BB_1230_7350, %BB_1230_7340, %BB_1230_7310, %BB_1230_7580, %BB_1230_7560, %BB_1230_7540, %BB_1230_7510
  %phi.52 = phi float [ %phi_cast_R264_bitcast, %BB_1230_7350 ], [ %phi_cast_R289_bitcast, %BB_1230_74b0 ], [ %phi_cast_R303_bitcast, %BB_1230_74e0 ], [ %ffma.62, %BB_1230_7310 ], [ %phi_cast_R252_bitcast, %BB_1230_7340 ], [ %phi_cast_R164_bitcast, %BB_1230_7510 ], [ %phi_cast_R177_bitcast, %BB_1230_7540 ], [ %mufu_rsq.1, %BB_1230_7560 ], [ %fadd.2, %BB_1230_7580 ]
  %phi.53 = phi float [ %phi_cast_R1113_bitcast, %BB_1230_7350 ], [ %phi_cast_R668_bitcast, %BB_1230_74b0 ], [ %phi_cast_R668_bitcast.1, %BB_1230_74e0 ], [ %phi_cast_R668_bitcast.2, %BB_1230_7310 ], [ %phi_cast_R668_bitcast.2, %BB_1230_7340 ], [ %shfl_idx.32, %BB_1230_7510 ], [ %shfl_idx.32, %BB_1230_7540 ], [ %shfl_idx.32, %BB_1230_7560 ], [ %shfl_idx.32, %BB_1230_7580 ]
  br label %BB_1250

BB_1250:                                          ; preds = %BB_1230_7590, %BB_1200
  %phi.54 = phi float [ %phi.52, %BB_1230_7590 ], [ %ffma.53, %BB_1200 ]
  %phi.55 = phi float [ %phi.53, %BB_1230_7590 ], [ %shfl_idx.32, %BB_1200 ]
  br label %BB_1270

BB_1270:                                          ; preds = %BB_1250, %BB_1110
  %phi.56 = phi float [ %phi.54, %BB_1250 ], [ %phi.43, %BB_1110 ]
  %phi.57 = phi float [ %phi.55, %BB_1250 ], [ %shfl_idx.32, %BB_1110 ]
  %phi.58 = phi i32 [ %.75, %BB_1250 ], [ %phi.44, %BB_1110 ]
  %phi.59 = phi float [ %phi.54, %BB_1250 ], [ %phi.43, %BB_1110 ]
  br label %BB_12a0

BB_12a0:                                          ; preds = %BB_1270
  %shfl_activemask.33 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.33 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.33, float %phi.59, i32 1, i32 31)
  br label %BB_12b0

BB_12b0:                                          ; preds = %BB_12a0
  %isetrp_cmp1.33 = icmp uge i32 %tid_x, 2
  %isetrp_cmp1.34 = icmp ne i32 %tid_x, 2
  br label %BB_12e0

BB_12e0:                                          ; preds = %BB_12b0
  %100 = zext i1 %isetrp_cmp1.33 to i32
  %101 = icmp ne i32 %100, 0
  br i1 %101, label %BB_800012e0, label %BB_1300

BB_800012e0:                                      ; preds = %BB_12e0
  %lds_addr_memaddr_offset_add.32 = add i32 %.88, 132
  %.992 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.32
  %lds.35 = load volatile float, ptr addrspace(3) %.992, align 4
  %ffma.63 = call float @llvm.fma.f32(float %shfl_idx.33, float %lds.35, float %phi.45)
  br label %BB_1300

BB_1300:                                          ; preds = %BB_800012e0, %BB_12e0
  %phi.60 = phi float [ %ffma.63, %BB_800012e0 ], [ %phi.45, %BB_12e0 ]
  %warp_reconv_mask.1 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  br i1 %isetrp_cmp1.34, label %BB_1460, label %BB_1310

BB_1310:                                          ; preds = %BB_1300
  %ffma_addend_fneg.2 = fneg float %phi.60
  %ffma.64 = call float @llvm.fma.f32(float %phi.56, float %phi, float %ffma_addend_fneg.2)
  %lds_addr_memaddr_offset_add.33 = add i32 %.75, 272
  %.1002 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.33
  %lds.36 = load volatile float, ptr addrspace(3) %.1002, align 4
  %mufu_rcp.4 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.36)
  %fchk_num_bits.2 = bitcast float %ffma.64 to i32
  %fchk_den_bits.2 = bitcast float %lds.36 to i32
  %fchk_aden.2 = and i32 %fchk_den_bits.2, 2147483647
  %fchk_anum.2 = and i32 %fchk_num_bits.2, 2147483647
  %fchk_den_subz.2 = icmp ult i32 %fchk_aden.2, 8388608
  %fchk_den_infnan.2 = icmp uge i32 %fchk_aden.2, 2139095040
  %fchk_num_infnan.2 = icmp uge i32 %fchk_anum.2, 2139095040
  %fchk_den_bad.2 = or i1 %fchk_den_subz.2, %fchk_den_infnan.2
  %fchk_px.2 = or i1 %fchk_den_bad.2, %fchk_num_infnan.2
  %ffma_lhs_fneg.4 = fneg float %lds.36
  %ffma.65 = call float @llvm.fma.f32(float %ffma_lhs_fneg.4, float %mufu_rcp.4, float 1.000000e+00)
  %ffma.66 = call float @llvm.fma.f32(float %mufu_rcp.4, float %ffma.65, float %mufu_rcp.4)
  %ffma.67 = call float @llvm.fma.f32(float %ffma.64, float %ffma.66, float 0.000000e+00)
  %ffma.68 = call float @llvm.fma.f32(float %ffma_lhs_fneg.4, float %ffma.67, float %ffma.64)
  %ffma.69 = call float @llvm.fma.f32(float %ffma.66, float %ffma.68, float %ffma.67)
  br label %BB_13f0

BB_13f0:                                          ; preds = %BB_1310
  %cond_not.25 = xor i1 %fchk_px.2, true
  br i1 %cond_not.25, label %BB_1440, label %BB_1420_6f40

BB_1420_6f40:                                     ; preds = %BB_13f0
  %.1006 = zext i32 %fchk_den_bits.2 to i64
  %.1007 = shl i64 %.1006, 32
  %.1008 = lshr i64 %.1007, 23
  %shf_hi.15 = lshr i64 %.1008, 32
  %shf_result.18 = trunc i64 %shf_hi.15 to i32
  %.1010 = zext i32 %fchk_num_bits.2 to i64
  %.1011 = shl i64 %.1010, 32
  %.1012 = lshr i64 %.1011, 23
  %shf_hi.16 = lshr i64 %.1012, 32
  %shf_result.19 = trunc i64 %shf_hi.16 to i32
  %.1016 = and i32 %shf_result.18, 255
  %.1024 = and i32 %shf_result.19, 255
  %iadd3_n1.27 = add i32 %.1016, -1
  %iadd3_n1.28 = add i32 %.1024, -1
  %isetrp_cmp1.35 = icmp ugt i32 %iadd3_n1.27, 253
  %isetrp_cmp1.36 = icmp ugt i32 %iadd3_n1.28, 253
  %isetrp_cmp2.36 = or i1 %isetrp_cmp1.36, %isetrp_cmp1.35
  br label %BB_1420_6fd0

BB_1420_6fd0:                                     ; preds = %BB_1420_6f40
  %cond_not.26 = xor i1 %isetrp_cmp2.36, true
  br i1 %cond_not.26, label %BB_1420_80006fd0, label %BB_1420_6ff0

BB_1420_6ff0:                                     ; preds = %BB_1420_6fd0
  %fsetrp_lhs_fabs.10 = call float @llvm.nvvm.fabs.f(float %ffma.64)
  %fsetrp_cmp1.12 = fcmp ugt float %fsetrp_lhs_fabs.10, 0x7FF0000000000000
  %fsetrp_lhs_fabs.11 = call float @llvm.nvvm.fabs.f(float %lds.36)
  %fsetrp_cmp1.13 = fcmp ugt float %fsetrp_lhs_fabs.11, 0x7FF0000000000000
  %lop3_a_cast_zext.8 = zext i1 %fsetrp_cmp1.12 to i32
  %lop3_b_cast_zext.8 = zext i1 %fsetrp_cmp1.13 to i32
  %plop3_a_bit.8 = and i32 %lop3_a_cast_zext.8, 1
  %plop3_b_bit.8 = and i32 %lop3_b_cast_zext.8, 1
  %.1031 = xor i32 %plop3_a_bit.8, 1
  %.1032 = xor i32 %plop3_b_bit.8, 1
  %.1034 = and i32 %.1031, %plop3_b_bit.8
  %.1036 = and i32 %plop3_a_bit.8, %.1032
  %.1038 = or i32 %.1034, %.1036
  %.1039 = and i32 %plop3_a_bit.8, %plop3_b_bit.8
  %.1041 = or i32 %.1038, %.1039
  %lop3_pred_cmp.14 = icmp ne i32 %.1041, 0
  br label %BB_1420_7020

BB_1420_7020:                                     ; preds = %BB_1420_6ff0
  %102 = zext i1 %lop3_pred_cmp.14 to i32
  %103 = icmp ne i32 %102, 0
  br i1 %103, label %BB_1420_7580, label %BB_1420_7030

BB_1420_7030:                                     ; preds = %BB_1420_7020
  %.1044 = xor i32 %fchk_den_bits.2, -1
  %.1046 = xor i32 %fchk_num_bits.2, -1
  %.1047 = and i32 %.1044, 2147483647
  %.1048 = and i32 %.1047, %fchk_num_bits.2
  %.1050 = and i32 %fchk_aden.2, %.1046
  %.1051 = or i32 %.1048, %.1050
  %.1053 = and i32 %fchk_aden.2, %fchk_num_bits.2
  %.1054 = or i32 %.1051, %.1053
  %lop3_pred_cmp.15 = icmp ne i32 %.1054, 0
  br label %BB_1420_7040

BB_1420_7040:                                     ; preds = %BB_1420_7030
  %cond_not.27 = xor i1 %lop3_pred_cmp.15, true
  br i1 %cond_not.27, label %BB_1420_7560, label %BB_1420_7050

BB_1420_7050:                                     ; preds = %BB_1420_7040
  %fsetrp_cmp1.14 = fcmp une float %fsetrp_lhs_fabs.10, 0x7FF0000000000000
  %fsetrp_cmp1.15 = fcmp une float %fsetrp_lhs_fabs.11, 0x7FF0000000000000
  br label %BB_1420_7080

BB_1420_7080:                                     ; preds = %BB_1420_7050
  %cond_not.28 = xor i1 %fsetrp_cmp1.15, true
  br i1 %cond_not.28, label %BB_1420_80007080, label %BB_1420_7090

BB_1420_80007080:                                 ; preds = %BB_1420_7080
  %bra_cond_not.2 = xor i1 %fsetrp_cmp1.14, true
  br i1 %bra_cond_not.2, label %BB_1420_7560, label %BB_1420_7090

BB_1420_7090:                                     ; preds = %BB_1420_80007080, %BB_1420_7080
  %lop3_pred_cmp.16 = icmp ne i32 %fchk_anum.2, 0
  %lop3_a_cast_zext.9 = zext i1 %fsetrp_cmp1.15 to i32
  %lop3_b_cast_zext.9 = zext i1 %lop3_pred_cmp.16 to i32
  %plop3_a_bit.9 = and i32 %lop3_a_cast_zext.9, 1
  %plop3_b_bit.9 = and i32 %lop3_b_cast_zext.9, 1
  %.1068 = xor i32 %plop3_a_bit.9, 1
  %.1069 = xor i32 %plop3_b_bit.9, 1
  %.1071 = and i32 %.1068, %.1069
  %.1073 = and i32 %.1068, %plop3_b_bit.9
  %.1075 = or i32 %.1071, %.1073
  %.1076 = and i32 %plop3_a_bit.9, %.1069
  %.1078 = or i32 %.1075, %.1076
  %lop3_pred_cmp.17 = icmp ne i32 %.1078, 0
  br label %BB_1420_70b0

BB_1420_70b0:                                     ; preds = %BB_1420_7090
  %104 = zext i1 %lop3_pred_cmp.17 to i32
  %105 = icmp ne i32 %104, 0
  br i1 %105, label %BB_1420_7540, label %BB_1420_70c0

BB_1420_70c0:                                     ; preds = %BB_1420_70b0
  %lop3_pred_cmp.18 = icmp ne i32 %fchk_aden.2, 0
  %lop3_a_cast_zext.10 = zext i1 %fsetrp_cmp1.14 to i32
  %lop3_b_cast_zext.10 = zext i1 %lop3_pred_cmp.18 to i32
  %plop3_a_bit.10 = and i32 %lop3_a_cast_zext.10, 1
  %plop3_b_bit.10 = and i32 %lop3_b_cast_zext.10, 1
  %.1089 = xor i32 %plop3_a_bit.10, 1
  %.1090 = xor i32 %plop3_b_bit.10, 1
  %.1092 = and i32 %.1089, %.1090
  %.1094 = and i32 %.1089, %plop3_b_bit.10
  %.1096 = or i32 %.1092, %.1094
  %.1097 = and i32 %plop3_a_bit.10, %.1090
  %.1099 = or i32 %.1096, %.1097
  %lop3_pred_cmp.19 = icmp ne i32 %.1099, 0
  br label %BB_1420_70e0

BB_1420_70e0:                                     ; preds = %BB_1420_70c0
  %106 = zext i1 %lop3_pred_cmp.19 to i32
  %107 = icmp ne i32 %106, 0
  br i1 %107, label %BB_1420_7510, label %BB_1420_70f0

BB_1420_70f0:                                     ; preds = %BB_1420_70e0
  %isetrp_cmp1.37 = icmp sge i32 %iadd3_n1.28, 0
  %isetrp_cmp1.38 = icmp sge i32 %iadd3_n1.27, 0
  br label %BB_1420_7130

BB_1420_7130:                                     ; preds = %BB_1420_70f0
  %108 = zext i1 %isetrp_cmp1.37 to i32
  %109 = icmp ne i32 %108, 0
  br i1 %109, label %BB_1420_80007130, label %BB_1420_7140

BB_1420_80007130:                                 ; preds = %BB_1420_7130
  br label %BB_1420_7140

BB_1420_7140:                                     ; preds = %BB_1420_80007130, %BB_1420_7130
  %phi.61 = phi i32 [ 0, %BB_1420_80007130 ], [ %iadd3_n1.27, %BB_1420_7130 ]
  %cond_not.29 = xor i1 %isetrp_cmp1.37, true
  br i1 %cond_not.29, label %BB_1420_80007140, label %BB_1420_7160

BB_1420_80007140:                                 ; preds = %BB_1420_7140
  %ffma.70 = call float @llvm.fma.f32(float %ffma.64, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R364_bitcast = bitcast float %ffma.70 to i32
  br label %BB_1420_7160

BB_1420_7160:                                     ; preds = %BB_1420_80007140, %BB_1420_7140
  %phi.62 = phi i32 [ %phi_cast_R364_bitcast, %BB_1420_80007140 ], [ %fchk_num_bits.2, %BB_1420_7140 ]
  %phi.63 = phi i32 [ -64, %BB_1420_80007140 ], [ %phi.61, %BB_1420_7140 ]
  %cond_not.30 = xor i1 %isetrp_cmp1.38, true
  br i1 %cond_not.30, label %BB_1420_80007160, label %BB_1420_7180

BB_1420_80007160:                                 ; preds = %BB_1420_7160
  %ffma.71 = call float @llvm.fma.f32(float %lds.36, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.5 = add i32 %phi.63, 64
  %phi_cast_R799_bitcast = bitcast float %ffma.71 to i32
  br label %BB_1420_7180

BB_1420_7510:                                     ; preds = %BB_1420_70e0
  %.1112 = and i32 %.1044, -2147483648
  %.1113 = and i32 %.1112, %fchk_num_bits.2
  %.1114 = and i32 %fchk_den_bits.2, -2147483648
  %.1115 = and i32 %.1114, %.1046
  %.1116 = or i32 %.1113, %.1115
  %.1117 = xor i32 %.1116, -1
  %.1120 = and i32 %.1117, 2139095040
  %.1127 = or i32 %.1120, %.1116
  %phi_cast_R382_bitcast = bitcast i32 %.1127 to float
  br label %BB_1420_7590

BB_1420_7540:                                     ; preds = %BB_1420_70b0
  %.1141 = and i32 %.1044, -2147483648
  %.1142 = and i32 %.1141, %fchk_num_bits.2
  %.1143 = and i32 %fchk_den_bits.2, -2147483648
  %.1144 = and i32 %.1143, %.1046
  %.1145 = or i32 %.1142, %.1144
  %phi_cast_R383_bitcast = bitcast i32 %.1145 to float
  br label %BB_1420_7590

BB_1420_7560:                                     ; preds = %BB_1420_80007080, %BB_1420_7040
  %mufu_rsq.2 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1420_7590

BB_1420_7580:                                     ; preds = %BB_1420_7020
  %fadd.4 = fadd float %ffma.64, %lds.36
  br label %BB_1420_7590

BB_1420_80006fd0:                                 ; preds = %BB_1420_6fd0
  br label %BB_1420_7180

BB_1420_7180:                                     ; preds = %BB_1420_80006fd0, %BB_1420_80007160, %BB_1420_7160
  %phi.64 = phi i32 [ %fchk_den_bits.2, %BB_1420_80006fd0 ], [ %phi_cast_R799_bitcast, %BB_1420_80007160 ], [ %fchk_den_bits.2, %BB_1420_7160 ]
  %phi.65 = phi i32 [ %fchk_num_bits.2, %BB_1420_80006fd0 ], [ %phi.62, %BB_1420_80007160 ], [ %phi.62, %BB_1420_7160 ]
  %phi.66 = phi i32 [ 0, %BB_1420_80006fd0 ], [ %viadd.5, %BB_1420_80007160 ], [ %phi.63, %BB_1420_7160 ]
  %.1150 = zext i32 %.1016 to i64
  %.1153 = shl i64 %.1150, 23
  %.1154 = and i64 %.1153, 4294967295
  %.1155 = add i64 %.1154, 3229614080
  %.1156 = trunc i64 %.1155 to i32
  %iadd3_n1.30 = add i32 %.1024, -127
  %iadd3_o1_not.4 = xor i32 %.1156, -1
  %iadd3_o1_neg.4 = add i32 %iadd3_o1_not.4, 1
  %iadd3_n1.31 = add i32 %iadd3_o1_neg.4, %phi.64
  %imad_tmp.19 = mul i32 %iadd3_n1.30, -8388608
  %imad.30 = add i32 %imad_tmp.19, %phi.65
  %mufu_src_bitcast.2 = bitcast i32 %iadd3_n1.31 to float
  %mufu_rcp.5 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.2)
  %fadd_lhs_fneg.2 = fneg float %mufu_src_bitcast.2
  %fadd.5 = fadd float %fadd_lhs_fneg.2, 0.000000e+00
  %iadd3_o3_not.2 = xor i32 %.1016, -1
  %iadd3_o3_neg.2 = add i32 %iadd3_o3_not.2, 1
  %iadd3_n2.32 = add i32 %.1024, %iadd3_o3_neg.2
  %iadd3_n1.33 = add i32 %iadd3_n2.32, %phi.66
  %ffma.72 = call float @llvm.fma.f32(float %mufu_rcp.5, float %fadd.5, float 1.000000e+00)
  %ffma.73 = call float @llvm.fma.f32(float %mufu_rcp.5, float %ffma.72, float %mufu_rcp.5)
  %ffma_lhs_bitcast.2 = bitcast i32 %imad.30 to float
  %ffma.74 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.2, float %ffma.73, float 0.000000e+00)
  %ffma.75 = call float @llvm.fma.f32(float %fadd.5, float %ffma.74, float %ffma_lhs_bitcast.2)
  %ffma.76 = call float @llvm.fma.f32(float %ffma.73, float %ffma.75, float %ffma.74)
  %ffma.77 = call float @llvm.fma.f32(float %fadd.5, float %ffma.76, float %ffma_lhs_bitcast.2)
  %ffma.78 = call float @llvm.fma.f32(float %ffma.73, float %ffma.77, float %ffma.76)
  %shf_hi_bitcast.8 = bitcast float %ffma.78 to i32
  %.1158 = zext i32 %shf_hi_bitcast.8 to i64
  %.1159 = shl i64 %.1158, 32
  %.1160 = lshr i64 %.1159, 23
  %shf_hi.17 = lshr i64 %.1160, 32
  %shf_result.20 = trunc i64 %shf_hi.17 to i32
  %.1164 = and i32 %shf_result.20, 255
  %imad.31 = add i32 %.1164, %iadd3_n1.33
  %iadd3_n1.34 = add i32 %imad.31, -1
  %isetrp_cmp1.39 = icmp uge i32 %iadd3_n1.34, 254
  br label %BB_1420_72d0

BB_1420_72d0:                                     ; preds = %BB_1420_7180
  %cond_not.31 = xor i1 %isetrp_cmp1.39, true
  br i1 %cond_not.31, label %BB_1420_74e0, label %BB_1420_72e0

BB_1420_72e0:                                     ; preds = %BB_1420_72d0
  %isetrp_cmp1.40 = icmp sgt i32 %imad.31, 254
  br label %BB_1420_72f0

BB_1420_72f0:                                     ; preds = %BB_1420_72e0
  %110 = zext i1 %isetrp_cmp1.40 to i32
  %111 = icmp ne i32 %110, 0
  br i1 %111, label %BB_1420_74b0, label %BB_1420_7300

BB_1420_7300:                                     ; preds = %BB_1420_72f0
  %isetrp_cmp1.41 = icmp sge i32 %imad.31, 1
  br label %BB_1420_7310

BB_1420_7310:                                     ; preds = %BB_1420_7300
  %phi_cast_R1890_bitcast.2 = bitcast i32 %iadd3_n1.33 to float
  br i1 %isetrp_cmp1.41, label %BB_1420_7590, label %BB_1420_7320

BB_1420_7320:                                     ; preds = %BB_1420_7310
  %isetrp_cmp1.42 = icmp sge i32 %imad.31, -24
  %.1178 = and i32 %shf_hi_bitcast.8, -2147483648
  br label %BB_1420_7340

BB_1420_7340:                                     ; preds = %BB_1420_7320
  %cond_not.32 = xor i1 %isetrp_cmp1.42, true
  %phi_cast_R392_bitcast = bitcast i32 %.1178 to float
  br i1 %cond_not.32, label %BB_1420_7590, label %BB_1420_7350

BB_1420_7350:                                     ; preds = %BB_1420_7340
  %ffma_rz.2 = call float @llvm.nvvm.fma.rz.f(float %ffma.73, float %ffma.77, float %ffma.76)
  %iadd3_n1.35 = add i32 %imad.31, 32
  %lop3_a_bitcast.22 = bitcast float %ffma_rz.2 to i32
  %.1188 = and i32 %lop3_a_bitcast.22, 8388607
  %ffma_rp.2 = call float @llvm.nvvm.fma.rp.f(float %ffma.73, float %ffma.77, float %ffma.76)
  %ffma_rm.2 = call float @llvm.nvvm.fma.rm.f(float %ffma.73, float %ffma.77, float %ffma.76)
  %isetrp_cmp1.44 = icmp ne i32 %imad.31, 0
  %.1203 = or i32 8388608, %.1188
  %iadd3_o1_not.5 = xor i32 %imad.31, -1
  %iadd3_o1_neg.5 = add i32 %iadd3_o1_not.5, 1
  %.1213 = zext i32 %.1203 to i64
  %shf_shift_64.21 = zext i32 %iadd3_n1.35 to i64
  %.1216 = shl i64 %.1213, %shf_shift_64.21
  %shf_result.21 = trunc i64 %.1216 to i32
  %fsetrp_cmp1.17 = fcmp une float %ffma_rp.2, %ffma_rm.2
  %isetrp_cmp1.45 = icmp ne i32 %shf_result.21, 0
  %isetrp_cmp2.45 = and i1 %isetrp_cmp1.45, %isetrp_cmp1.44
  %.1219 = shl i64 %.1213, 32
  %shf_shift_64.22 = zext i32 %iadd3_o1_neg.5 to i64
  %.1220 = lshr i64 %.1219, %shf_shift_64.22
  %shf_hi.18 = lshr i64 %.1220, 32
  %shf_result.22 = trunc i64 %shf_hi.18 to i32
  %lop3_a_cast_zext.11 = zext i1 %fsetrp_cmp1.17 to i32
  %lop3_b_cast_zext.11 = zext i1 %isetrp_cmp2.45 to i32
  %plop3_a_bit.11 = and i32 %lop3_a_cast_zext.11, 1
  %plop3_b_bit.11 = and i32 %lop3_b_cast_zext.11, 1
  %.1221 = xor i32 %plop3_a_bit.11, 1
  %.1222 = xor i32 %plop3_b_bit.11, 1
  %.1224 = and i32 %.1221, %plop3_b_bit.11
  %.1226 = and i32 %plop3_a_bit.11, %.1222
  %.1228 = or i32 %.1224, %.1226
  %.1229 = and i32 %plop3_a_bit.11, %plop3_b_bit.11
  %.1231 = or i32 %.1228, %.1229
  %lop3_pred_cmp.20 = icmp ne i32 %.1231, 0
  %.1233 = zext i32 %shf_result.22 to i64
  %.1234 = shl i64 %.1233, 32
  %.1235 = lshr i64 %.1234, 1
  %shf_hi.19 = lshr i64 %.1235, 32
  %shf_result.23 = trunc i64 %shf_hi.19 to i32
  %sel_pred_not.2 = xor i1 %lop3_pred_cmp.20, true
  %sel.5 = select i1 %sel_pred_not.2, i32 0, i32 1
  %.1236 = xor i32 %sel.5, -1
  %.1238 = xor i32 %shf_result.23, -1
  %.1239 = and i32 %.1236, 1
  %.1240 = and i32 %.1239, %shf_result.23
  %.1248 = and i32 %sel.5, %.1238
  %.1249 = or i32 %.1240, %.1248
  %.1251 = and i32 %sel.5, %shf_result.23
  %.1252 = or i32 %.1249, %.1251
  %.1256 = and i32 %.1252, %shf_result.22
  %imad.32 = add i32 %shf_result.23, %.1256
  %.1261 = xor i32 %imad.32, -1
  %.1262 = xor i32 %.1178, -1
  %.1264 = and i32 %.1261, %.1178
  %.1269 = and i32 %imad.32, %.1262
  %.1271 = or i32 %.1264, %.1269
  %.1275 = and i32 %imad.32, %.1178
  %.1277 = or i32 %.1271, %.1275
  %phi_cast_R393_bitcast = bitcast i32 %.1277 to float
  %phi_cast_R2224_bitcast = bitcast i32 %.1203 to float
  br label %BB_1420_7590

BB_1420_74b0:                                     ; preds = %BB_1420_72f0
  %.1285 = and i32 %shf_hi_bitcast.8, -2147483648
  %.1300 = or i32 2139095040, %.1285
  %phi_cast_R395_bitcast = bitcast i32 %.1300 to float
  %phi_cast_R1890_bitcast = bitcast i32 %iadd3_n1.33 to float
  br label %BB_1420_7590

BB_1420_74e0:                                     ; preds = %BB_1420_72d0
  %.1311 = zext i32 %iadd3_n1.33 to i64
  %.1314 = shl i64 %.1311, 23
  %.1315 = and i64 %.1314, 4294967295
  %.1316 = add i64 %.1315, %.1158
  %.1317 = trunc i64 %.1316 to i32
  %phi_cast_R396_bitcast = bitcast i32 %.1317 to float
  %phi_cast_R1890_bitcast.1 = bitcast i32 %iadd3_n1.33 to float
  br label %BB_1420_7590

BB_1420_7590:                                     ; preds = %BB_1420_74e0, %BB_1420_74b0, %BB_1420_7350, %BB_1420_7340, %BB_1420_7310, %BB_1420_7580, %BB_1420_7560, %BB_1420_7540, %BB_1420_7510
  %phi.67 = phi float [ %phi_cast_R393_bitcast, %BB_1420_7350 ], [ %phi_cast_R395_bitcast, %BB_1420_74b0 ], [ %phi_cast_R396_bitcast, %BB_1420_74e0 ], [ %ffma.78, %BB_1420_7310 ], [ %phi_cast_R392_bitcast, %BB_1420_7340 ], [ %phi_cast_R382_bitcast, %BB_1420_7510 ], [ %phi_cast_R383_bitcast, %BB_1420_7540 ], [ %mufu_rsq.2, %BB_1420_7560 ], [ %fadd.4, %BB_1420_7580 ]
  %phi.68 = phi float [ %phi_cast_R2224_bitcast, %BB_1420_7350 ], [ %phi_cast_R1890_bitcast, %BB_1420_74b0 ], [ %phi_cast_R1890_bitcast.1, %BB_1420_74e0 ], [ %phi_cast_R1890_bitcast.2, %BB_1420_7310 ], [ %phi_cast_R1890_bitcast.2, %BB_1420_7340 ], [ %phi.57, %BB_1420_7510 ], [ %phi.57, %BB_1420_7540 ], [ %phi.57, %BB_1420_7560 ], [ %phi.57, %BB_1420_7580 ]
  br label %BB_1440

BB_1440:                                          ; preds = %BB_1420_7590, %BB_13f0
  %phi.69 = phi float [ %phi.67, %BB_1420_7590 ], [ %ffma.69, %BB_13f0 ]
  %phi.70 = phi float [ %phi.68, %BB_1420_7590 ], [ %phi.57, %BB_13f0 ]
  br label %BB_1460

BB_1460:                                          ; preds = %BB_1440, %BB_1300
  %phi.71 = phi float [ %phi.69, %BB_1440 ], [ %phi.56, %BB_1300 ]
  %phi.72 = phi float [ %phi.70, %BB_1440 ], [ %phi.57, %BB_1300 ]
  %phi.73 = phi i32 [ %.75, %BB_1440 ], [ %phi.58, %BB_1300 ]
  %phi.74 = phi float [ %phi.69, %BB_1440 ], [ %phi.59, %BB_1300 ]
  br label %BB_1490

BB_1490:                                          ; preds = %BB_1460
  %shfl_activemask.34 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.34 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.34, float %phi.74, i32 2, i32 31)
  br label %BB_14a0

BB_14a0:                                          ; preds = %BB_1490
  %isetrp_cmp1.46 = icmp uge i32 %tid_x, 3
  %isetrp_cmp1.47 = icmp ne i32 %tid_x, 3
  br label %BB_14d0

BB_14d0:                                          ; preds = %BB_14a0
  %112 = zext i1 %isetrp_cmp1.46 to i32
  %113 = icmp ne i32 %112, 0
  br i1 %113, label %BB_800014d0, label %BB_14f0

BB_800014d0:                                      ; preds = %BB_14d0
  %lds_addr_memaddr_offset_add.34 = add i32 %.88, 264
  %.1325 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.34
  %lds.37 = load volatile float, ptr addrspace(3) %.1325, align 4
  %ffma.79 = call float @llvm.fma.f32(float %shfl_idx.34, float %lds.37, float %phi.60)
  br label %BB_14f0

BB_14f0:                                          ; preds = %BB_800014d0, %BB_14d0
  %phi.75 = phi float [ %ffma.79, %BB_800014d0 ], [ %phi.60, %BB_14d0 ]
  %warp_reconv_mask.2 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.2)
  br i1 %isetrp_cmp1.47, label %BB_1650, label %BB_1500

BB_1500:                                          ; preds = %BB_14f0
  %ffma_addend_fneg.3 = fneg float %phi.75
  %ffma.80 = call float @llvm.fma.f32(float %phi.71, float %phi, float %ffma_addend_fneg.3)
  %lds_addr_memaddr_offset_add.35 = add i32 %.75, 408
  %.1335 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.35
  %lds.38 = load volatile float, ptr addrspace(3) %.1335, align 4
  %mufu_rcp.6 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.38)
  %fchk_num_bits.3 = bitcast float %ffma.80 to i32
  %fchk_den_bits.3 = bitcast float %lds.38 to i32
  %fchk_aden.3 = and i32 %fchk_den_bits.3, 2147483647
  %fchk_anum.3 = and i32 %fchk_num_bits.3, 2147483647
  %fchk_den_subz.3 = icmp ult i32 %fchk_aden.3, 8388608
  %fchk_den_infnan.3 = icmp uge i32 %fchk_aden.3, 2139095040
  %fchk_num_infnan.3 = icmp uge i32 %fchk_anum.3, 2139095040
  %fchk_den_bad.3 = or i1 %fchk_den_subz.3, %fchk_den_infnan.3
  %fchk_px.3 = or i1 %fchk_den_bad.3, %fchk_num_infnan.3
  %ffma_lhs_fneg.6 = fneg float %lds.38
  %ffma.81 = call float @llvm.fma.f32(float %ffma_lhs_fneg.6, float %mufu_rcp.6, float 1.000000e+00)
  %ffma.82 = call float @llvm.fma.f32(float %mufu_rcp.6, float %ffma.81, float %mufu_rcp.6)
  %ffma.83 = call float @llvm.fma.f32(float %ffma.80, float %ffma.82, float 0.000000e+00)
  %ffma.84 = call float @llvm.fma.f32(float %ffma_lhs_fneg.6, float %ffma.83, float %ffma.80)
  %ffma.85 = call float @llvm.fma.f32(float %ffma.82, float %ffma.84, float %ffma.83)
  br label %BB_15e0

BB_15e0:                                          ; preds = %BB_1500
  %cond_not.33 = xor i1 %fchk_px.3, true
  br i1 %cond_not.33, label %BB_1630, label %BB_1610_6f40

BB_1610_6f40:                                     ; preds = %BB_15e0
  %.1339 = zext i32 %fchk_den_bits.3 to i64
  %.1340 = shl i64 %.1339, 32
  %.1341 = lshr i64 %.1340, 23
  %shf_hi.20 = lshr i64 %.1341, 32
  %shf_result.24 = trunc i64 %shf_hi.20 to i32
  %.1343 = zext i32 %fchk_num_bits.3 to i64
  %.1344 = shl i64 %.1343, 32
  %.1345 = lshr i64 %.1344, 23
  %shf_hi.21 = lshr i64 %.1345, 32
  %shf_result.25 = trunc i64 %shf_hi.21 to i32
  %.1349 = and i32 %shf_result.24, 255
  %.1357 = and i32 %shf_result.25, 255
  %iadd3_n1.37 = add i32 %.1349, -1
  %iadd3_n1.38 = add i32 %.1357, -1
  %isetrp_cmp1.48 = icmp ugt i32 %iadd3_n1.37, 253
  %isetrp_cmp1.49 = icmp ugt i32 %iadd3_n1.38, 253
  %isetrp_cmp2.49 = or i1 %isetrp_cmp1.49, %isetrp_cmp1.48
  br label %BB_1610_6fd0

BB_1610_6fd0:                                     ; preds = %BB_1610_6f40
  %cond_not.34 = xor i1 %isetrp_cmp2.49, true
  br i1 %cond_not.34, label %BB_1610_80006fd0, label %BB_1610_6ff0

BB_1610_6ff0:                                     ; preds = %BB_1610_6fd0
  %fsetrp_lhs_fabs.15 = call float @llvm.nvvm.fabs.f(float %ffma.80)
  %fsetrp_cmp1.18 = fcmp ugt float %fsetrp_lhs_fabs.15, 0x7FF0000000000000
  %fsetrp_lhs_fabs.16 = call float @llvm.nvvm.fabs.f(float %lds.38)
  %fsetrp_cmp1.19 = fcmp ugt float %fsetrp_lhs_fabs.16, 0x7FF0000000000000
  %lop3_a_cast_zext.12 = zext i1 %fsetrp_cmp1.18 to i32
  %lop3_b_cast_zext.12 = zext i1 %fsetrp_cmp1.19 to i32
  %plop3_a_bit.12 = and i32 %lop3_a_cast_zext.12, 1
  %plop3_b_bit.12 = and i32 %lop3_b_cast_zext.12, 1
  %.1364 = xor i32 %plop3_a_bit.12, 1
  %.1365 = xor i32 %plop3_b_bit.12, 1
  %.1367 = and i32 %.1364, %plop3_b_bit.12
  %.1369 = and i32 %plop3_a_bit.12, %.1365
  %.1371 = or i32 %.1367, %.1369
  %.1372 = and i32 %plop3_a_bit.12, %plop3_b_bit.12
  %.1374 = or i32 %.1371, %.1372
  %lop3_pred_cmp.21 = icmp ne i32 %.1374, 0
  br label %BB_1610_7020

BB_1610_7020:                                     ; preds = %BB_1610_6ff0
  %114 = zext i1 %lop3_pred_cmp.21 to i32
  %115 = icmp ne i32 %114, 0
  br i1 %115, label %BB_1610_7580, label %BB_1610_7030

BB_1610_7030:                                     ; preds = %BB_1610_7020
  %.1377 = xor i32 %fchk_den_bits.3, -1
  %.1379 = xor i32 %fchk_num_bits.3, -1
  %.1380 = and i32 %.1377, 2147483647
  %.1381 = and i32 %.1380, %fchk_num_bits.3
  %.1383 = and i32 %fchk_aden.3, %.1379
  %.1384 = or i32 %.1381, %.1383
  %.1386 = and i32 %fchk_aden.3, %fchk_num_bits.3
  %.1387 = or i32 %.1384, %.1386
  %lop3_pred_cmp.22 = icmp ne i32 %.1387, 0
  br label %BB_1610_7040

BB_1610_7040:                                     ; preds = %BB_1610_7030
  %cond_not.35 = xor i1 %lop3_pred_cmp.22, true
  br i1 %cond_not.35, label %BB_1610_7560, label %BB_1610_7050

BB_1610_7050:                                     ; preds = %BB_1610_7040
  %fsetrp_cmp1.20 = fcmp une float %fsetrp_lhs_fabs.15, 0x7FF0000000000000
  %fsetrp_cmp1.21 = fcmp une float %fsetrp_lhs_fabs.16, 0x7FF0000000000000
  br label %BB_1610_7080

BB_1610_7080:                                     ; preds = %BB_1610_7050
  %cond_not.36 = xor i1 %fsetrp_cmp1.21, true
  br i1 %cond_not.36, label %BB_1610_80007080, label %BB_1610_7090

BB_1610_80007080:                                 ; preds = %BB_1610_7080
  %bra_cond_not.3 = xor i1 %fsetrp_cmp1.20, true
  br i1 %bra_cond_not.3, label %BB_1610_7560, label %BB_1610_7090

BB_1610_7090:                                     ; preds = %BB_1610_80007080, %BB_1610_7080
  %lop3_pred_cmp.23 = icmp ne i32 %fchk_anum.3, 0
  %lop3_a_cast_zext.13 = zext i1 %fsetrp_cmp1.21 to i32
  %lop3_b_cast_zext.13 = zext i1 %lop3_pred_cmp.23 to i32
  %plop3_a_bit.13 = and i32 %lop3_a_cast_zext.13, 1
  %plop3_b_bit.13 = and i32 %lop3_b_cast_zext.13, 1
  %.1401 = xor i32 %plop3_a_bit.13, 1
  %.1402 = xor i32 %plop3_b_bit.13, 1
  %.1404 = and i32 %.1401, %.1402
  %.1406 = and i32 %.1401, %plop3_b_bit.13
  %.1408 = or i32 %.1404, %.1406
  %.1409 = and i32 %plop3_a_bit.13, %.1402
  %.1411 = or i32 %.1408, %.1409
  %lop3_pred_cmp.24 = icmp ne i32 %.1411, 0
  br label %BB_1610_70b0

BB_1610_70b0:                                     ; preds = %BB_1610_7090
  %116 = zext i1 %lop3_pred_cmp.24 to i32
  %117 = icmp ne i32 %116, 0
  br i1 %117, label %BB_1610_7540, label %BB_1610_70c0

BB_1610_70c0:                                     ; preds = %BB_1610_70b0
  %lop3_pred_cmp.25 = icmp ne i32 %fchk_aden.3, 0
  %lop3_a_cast_zext.14 = zext i1 %fsetrp_cmp1.20 to i32
  %lop3_b_cast_zext.14 = zext i1 %lop3_pred_cmp.25 to i32
  %plop3_a_bit.14 = and i32 %lop3_a_cast_zext.14, 1
  %plop3_b_bit.14 = and i32 %lop3_b_cast_zext.14, 1
  %.1422 = xor i32 %plop3_a_bit.14, 1
  %.1423 = xor i32 %plop3_b_bit.14, 1
  %.1425 = and i32 %.1422, %.1423
  %.1427 = and i32 %.1422, %plop3_b_bit.14
  %.1429 = or i32 %.1425, %.1427
  %.1430 = and i32 %plop3_a_bit.14, %.1423
  %.1432 = or i32 %.1429, %.1430
  %lop3_pred_cmp.26 = icmp ne i32 %.1432, 0
  br label %BB_1610_70e0

BB_1610_70e0:                                     ; preds = %BB_1610_70c0
  %118 = zext i1 %lop3_pred_cmp.26 to i32
  %119 = icmp ne i32 %118, 0
  br i1 %119, label %BB_1610_7510, label %BB_1610_70f0

BB_1610_70f0:                                     ; preds = %BB_1610_70e0
  %isetrp_cmp1.50 = icmp sge i32 %iadd3_n1.38, 0
  %isetrp_cmp1.51 = icmp sge i32 %iadd3_n1.37, 0
  br label %BB_1610_7130

BB_1610_7130:                                     ; preds = %BB_1610_70f0
  %120 = zext i1 %isetrp_cmp1.50 to i32
  %121 = icmp ne i32 %120, 0
  br i1 %121, label %BB_1610_80007130, label %BB_1610_7140

BB_1610_80007130:                                 ; preds = %BB_1610_7130
  br label %BB_1610_7140

BB_1610_7140:                                     ; preds = %BB_1610_80007130, %BB_1610_7130
  %phi.76 = phi i32 [ 0, %BB_1610_80007130 ], [ %iadd3_n1.37, %BB_1610_7130 ]
  %cond_not.37 = xor i1 %isetrp_cmp1.50, true
  br i1 %cond_not.37, label %BB_1610_80007140, label %BB_1610_7160

BB_1610_80007140:                                 ; preds = %BB_1610_7140
  %ffma.86 = call float @llvm.fma.f32(float %ffma.80, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R401_bitcast = bitcast float %ffma.86 to i32
  br label %BB_1610_7160

BB_1610_7160:                                     ; preds = %BB_1610_80007140, %BB_1610_7140
  %phi.77 = phi i32 [ %phi_cast_R401_bitcast, %BB_1610_80007140 ], [ %fchk_num_bits.3, %BB_1610_7140 ]
  %phi.78 = phi i32 [ -64, %BB_1610_80007140 ], [ %phi.76, %BB_1610_7140 ]
  %cond_not.38 = xor i1 %isetrp_cmp1.51, true
  br i1 %cond_not.38, label %BB_1610_80007160, label %BB_1610_7180

BB_1610_80007160:                                 ; preds = %BB_1610_7160
  %ffma.87 = call float @llvm.fma.f32(float %lds.38, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.7 = add i32 %phi.78, 64
  %phi_cast_R910_bitcast = bitcast float %ffma.87 to i32
  br label %BB_1610_7180

BB_1610_7510:                                     ; preds = %BB_1610_70e0
  %.1445 = and i32 %.1377, -2147483648
  %.1446 = and i32 %.1445, %fchk_num_bits.3
  %.1447 = and i32 %fchk_den_bits.3, -2147483648
  %.1448 = and i32 %.1447, %.1379
  %.1449 = or i32 %.1446, %.1448
  %.1450 = xor i32 %.1449, -1
  %.1453 = and i32 %.1450, 2139095040
  %.1460 = or i32 %.1453, %.1449
  %phi_cast_R405_bitcast = bitcast i32 %.1460 to float
  br label %BB_1610_7590

BB_1610_7540:                                     ; preds = %BB_1610_70b0
  %.1474 = and i32 %.1377, -2147483648
  %.1475 = and i32 %.1474, %fchk_num_bits.3
  %.1476 = and i32 %fchk_den_bits.3, -2147483648
  %.1477 = and i32 %.1476, %.1379
  %.1478 = or i32 %.1475, %.1477
  %phi_cast_R406_bitcast = bitcast i32 %.1478 to float
  br label %BB_1610_7590

BB_1610_7560:                                     ; preds = %BB_1610_80007080, %BB_1610_7040
  %mufu_rsq.3 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1610_7590

BB_1610_7580:                                     ; preds = %BB_1610_7020
  %fadd.6 = fadd float %ffma.80, %lds.38
  br label %BB_1610_7590

BB_1610_80006fd0:                                 ; preds = %BB_1610_6fd0
  br label %BB_1610_7180

BB_1610_7180:                                     ; preds = %BB_1610_80006fd0, %BB_1610_80007160, %BB_1610_7160
  %phi.79 = phi i32 [ %fchk_den_bits.3, %BB_1610_80006fd0 ], [ %phi_cast_R910_bitcast, %BB_1610_80007160 ], [ %fchk_den_bits.3, %BB_1610_7160 ]
  %phi.80 = phi i32 [ %fchk_num_bits.3, %BB_1610_80006fd0 ], [ %phi.77, %BB_1610_80007160 ], [ %phi.77, %BB_1610_7160 ]
  %phi.81 = phi i32 [ 0, %BB_1610_80006fd0 ], [ %viadd.7, %BB_1610_80007160 ], [ %phi.78, %BB_1610_7160 ]
  %.1483 = zext i32 %.1349 to i64
  %.1486 = shl i64 %.1483, 23
  %.1487 = and i64 %.1486, 4294967295
  %.1488 = add i64 %.1487, 3229614080
  %.1489 = trunc i64 %.1488 to i32
  %iadd3_n1.40 = add i32 %.1357, -127
  %iadd3_o1_not.6 = xor i32 %.1489, -1
  %iadd3_o1_neg.6 = add i32 %iadd3_o1_not.6, 1
  %iadd3_n1.41 = add i32 %iadd3_o1_neg.6, %phi.79
  %imad_tmp.22 = mul i32 %iadd3_n1.40, -8388608
  %imad.33 = add i32 %imad_tmp.22, %phi.80
  %mufu_src_bitcast.3 = bitcast i32 %iadd3_n1.41 to float
  %mufu_rcp.7 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.3)
  %fadd_lhs_fneg.3 = fneg float %mufu_src_bitcast.3
  %fadd.7 = fadd float %fadd_lhs_fneg.3, 0.000000e+00
  %iadd3_o3_not.3 = xor i32 %.1349, -1
  %iadd3_o3_neg.3 = add i32 %iadd3_o3_not.3, 1
  %iadd3_n2.42 = add i32 %.1357, %iadd3_o3_neg.3
  %iadd3_n1.43 = add i32 %iadd3_n2.42, %phi.81
  %ffma.88 = call float @llvm.fma.f32(float %mufu_rcp.7, float %fadd.7, float 1.000000e+00)
  %ffma.89 = call float @llvm.fma.f32(float %mufu_rcp.7, float %ffma.88, float %mufu_rcp.7)
  %ffma_lhs_bitcast.3 = bitcast i32 %imad.33 to float
  %ffma.90 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.3, float %ffma.89, float 0.000000e+00)
  %ffma.91 = call float @llvm.fma.f32(float %fadd.7, float %ffma.90, float %ffma_lhs_bitcast.3)
  %ffma.92 = call float @llvm.fma.f32(float %ffma.89, float %ffma.91, float %ffma.90)
  %ffma.93 = call float @llvm.fma.f32(float %fadd.7, float %ffma.92, float %ffma_lhs_bitcast.3)
  %ffma.94 = call float @llvm.fma.f32(float %ffma.89, float %ffma.93, float %ffma.92)
  %shf_hi_bitcast.11 = bitcast float %ffma.94 to i32
  %.1491 = zext i32 %shf_hi_bitcast.11 to i64
  %.1492 = shl i64 %.1491, 32
  %.1493 = lshr i64 %.1492, 23
  %shf_hi.22 = lshr i64 %.1493, 32
  %shf_result.26 = trunc i64 %shf_hi.22 to i32
  %.1497 = and i32 %shf_result.26, 255
  %imad.34 = add i32 %.1497, %iadd3_n1.43
  %iadd3_n1.44 = add i32 %imad.34, -1
  %isetrp_cmp1.52 = icmp uge i32 %iadd3_n1.44, 254
  br label %BB_1610_72d0

BB_1610_72d0:                                     ; preds = %BB_1610_7180
  %cond_not.39 = xor i1 %isetrp_cmp1.52, true
  br i1 %cond_not.39, label %BB_1610_74e0, label %BB_1610_72e0

BB_1610_72e0:                                     ; preds = %BB_1610_72d0
  %isetrp_cmp1.53 = icmp sgt i32 %imad.34, 254
  br label %BB_1610_72f0

BB_1610_72f0:                                     ; preds = %BB_1610_72e0
  %122 = zext i1 %isetrp_cmp1.53 to i32
  %123 = icmp ne i32 %122, 0
  br i1 %123, label %BB_1610_74b0, label %BB_1610_7300

BB_1610_7300:                                     ; preds = %BB_1610_72f0
  %isetrp_cmp1.54 = icmp sge i32 %imad.34, 1
  br label %BB_1610_7310

BB_1610_7310:                                     ; preds = %BB_1610_7300
  %phi_cast_R2398_bitcast.2 = bitcast i32 %iadd3_n1.43 to float
  br i1 %isetrp_cmp1.54, label %BB_1610_7590, label %BB_1610_7320

BB_1610_7320:                                     ; preds = %BB_1610_7310
  %isetrp_cmp1.55 = icmp sge i32 %imad.34, -24
  %.1511 = and i32 %shf_hi_bitcast.11, -2147483648
  br label %BB_1610_7340

BB_1610_7340:                                     ; preds = %BB_1610_7320
  %cond_not.40 = xor i1 %isetrp_cmp1.55, true
  %phi_cast_R415_bitcast = bitcast i32 %.1511 to float
  br i1 %cond_not.40, label %BB_1610_7590, label %BB_1610_7350

BB_1610_7350:                                     ; preds = %BB_1610_7340
  %ffma_rz.3 = call float @llvm.nvvm.fma.rz.f(float %ffma.89, float %ffma.93, float %ffma.92)
  %iadd3_n1.45 = add i32 %imad.34, 32
  %lop3_a_bitcast.30 = bitcast float %ffma_rz.3 to i32
  %.1521 = and i32 %lop3_a_bitcast.30, 8388607
  %ffma_rp.3 = call float @llvm.nvvm.fma.rp.f(float %ffma.89, float %ffma.93, float %ffma.92)
  %ffma_rm.3 = call float @llvm.nvvm.fma.rm.f(float %ffma.89, float %ffma.93, float %ffma.92)
  %isetrp_cmp1.57 = icmp ne i32 %imad.34, 0
  %.1536 = or i32 8388608, %.1521
  %iadd3_o1_not.7 = xor i32 %imad.34, -1
  %iadd3_o1_neg.7 = add i32 %iadd3_o1_not.7, 1
  %.1546 = zext i32 %.1536 to i64
  %shf_shift_64.27 = zext i32 %iadd3_n1.45 to i64
  %.1549 = shl i64 %.1546, %shf_shift_64.27
  %shf_result.27 = trunc i64 %.1549 to i32
  %fsetrp_cmp1.23 = fcmp une float %ffma_rp.3, %ffma_rm.3
  %isetrp_cmp1.58 = icmp ne i32 %shf_result.27, 0
  %isetrp_cmp2.58 = and i1 %isetrp_cmp1.58, %isetrp_cmp1.57
  %.1552 = shl i64 %.1546, 32
  %shf_shift_64.28 = zext i32 %iadd3_o1_neg.7 to i64
  %.1553 = lshr i64 %.1552, %shf_shift_64.28
  %shf_hi.23 = lshr i64 %.1553, 32
  %shf_result.28 = trunc i64 %shf_hi.23 to i32
  %lop3_a_cast_zext.15 = zext i1 %fsetrp_cmp1.23 to i32
  %lop3_b_cast_zext.15 = zext i1 %isetrp_cmp2.58 to i32
  %plop3_a_bit.15 = and i32 %lop3_a_cast_zext.15, 1
  %plop3_b_bit.15 = and i32 %lop3_b_cast_zext.15, 1
  %.1554 = xor i32 %plop3_a_bit.15, 1
  %.1555 = xor i32 %plop3_b_bit.15, 1
  %.1557 = and i32 %.1554, %plop3_b_bit.15
  %.1559 = and i32 %plop3_a_bit.15, %.1555
  %.1561 = or i32 %.1557, %.1559
  %.1562 = and i32 %plop3_a_bit.15, %plop3_b_bit.15
  %.1564 = or i32 %.1561, %.1562
  %lop3_pred_cmp.27 = icmp ne i32 %.1564, 0
  %.1566 = zext i32 %shf_result.28 to i64
  %.1567 = shl i64 %.1566, 32
  %.1568 = lshr i64 %.1567, 1
  %shf_hi.24 = lshr i64 %.1568, 32
  %shf_result.29 = trunc i64 %shf_hi.24 to i32
  %sel_pred_not.3 = xor i1 %lop3_pred_cmp.27, true
  %sel.7 = select i1 %sel_pred_not.3, i32 0, i32 1
  %.1569 = xor i32 %sel.7, -1
  %.1571 = xor i32 %shf_result.29, -1
  %.1572 = and i32 %.1569, 1
  %.1573 = and i32 %.1572, %shf_result.29
  %.1581 = and i32 %sel.7, %.1571
  %.1582 = or i32 %.1573, %.1581
  %.1584 = and i32 %sel.7, %shf_result.29
  %.1585 = or i32 %.1582, %.1584
  %.1589 = and i32 %.1585, %shf_result.28
  %imad.35 = add i32 %shf_result.29, %.1589
  %.1594 = xor i32 %imad.35, -1
  %.1595 = xor i32 %.1511, -1
  %.1597 = and i32 %.1594, %.1511
  %.1602 = and i32 %imad.35, %.1595
  %.1604 = or i32 %.1597, %.1602
  %.1608 = and i32 %imad.35, %.1511
  %.1610 = or i32 %.1604, %.1608
  %phi_cast_R416_bitcast = bitcast i32 %.1610 to float
  %phi_cast_R2421_bitcast = bitcast i32 %.1536 to float
  br label %BB_1610_7590

BB_1610_74b0:                                     ; preds = %BB_1610_72f0
  %.1618 = and i32 %shf_hi_bitcast.11, -2147483648
  %.1633 = or i32 2139095040, %.1618
  %phi_cast_R418_bitcast = bitcast i32 %.1633 to float
  %phi_cast_R2398_bitcast = bitcast i32 %iadd3_n1.43 to float
  br label %BB_1610_7590

BB_1610_74e0:                                     ; preds = %BB_1610_72d0
  %.1644 = zext i32 %iadd3_n1.43 to i64
  %.1647 = shl i64 %.1644, 23
  %.1648 = and i64 %.1647, 4294967295
  %.1649 = add i64 %.1648, %.1491
  %.1650 = trunc i64 %.1649 to i32
  %phi_cast_R419_bitcast = bitcast i32 %.1650 to float
  %phi_cast_R2398_bitcast.1 = bitcast i32 %iadd3_n1.43 to float
  br label %BB_1610_7590

BB_1610_7590:                                     ; preds = %BB_1610_74e0, %BB_1610_74b0, %BB_1610_7350, %BB_1610_7340, %BB_1610_7310, %BB_1610_7580, %BB_1610_7560, %BB_1610_7540, %BB_1610_7510
  %phi.82 = phi float [ %phi_cast_R416_bitcast, %BB_1610_7350 ], [ %phi_cast_R418_bitcast, %BB_1610_74b0 ], [ %phi_cast_R419_bitcast, %BB_1610_74e0 ], [ %ffma.94, %BB_1610_7310 ], [ %phi_cast_R415_bitcast, %BB_1610_7340 ], [ %phi_cast_R405_bitcast, %BB_1610_7510 ], [ %phi_cast_R406_bitcast, %BB_1610_7540 ], [ %mufu_rsq.3, %BB_1610_7560 ], [ %fadd.6, %BB_1610_7580 ]
  %phi.83 = phi float [ %phi_cast_R2421_bitcast, %BB_1610_7350 ], [ %phi_cast_R2398_bitcast, %BB_1610_74b0 ], [ %phi_cast_R2398_bitcast.1, %BB_1610_74e0 ], [ %phi_cast_R2398_bitcast.2, %BB_1610_7310 ], [ %phi_cast_R2398_bitcast.2, %BB_1610_7340 ], [ %phi.72, %BB_1610_7510 ], [ %phi.72, %BB_1610_7540 ], [ %phi.72, %BB_1610_7560 ], [ %phi.72, %BB_1610_7580 ]
  br label %BB_1630

BB_1630:                                          ; preds = %BB_1610_7590, %BB_15e0
  %phi.84 = phi float [ %phi.82, %BB_1610_7590 ], [ %ffma.85, %BB_15e0 ]
  %phi.85 = phi float [ %phi.83, %BB_1610_7590 ], [ %phi.72, %BB_15e0 ]
  br label %BB_1650

BB_1650:                                          ; preds = %BB_1630, %BB_14f0
  %phi.86 = phi float [ %phi.84, %BB_1630 ], [ %phi.71, %BB_14f0 ]
  %phi.87 = phi float [ %phi.85, %BB_1630 ], [ %phi.72, %BB_14f0 ]
  %phi.88 = phi i32 [ %.75, %BB_1630 ], [ %phi.73, %BB_14f0 ]
  %phi.89 = phi float [ %phi.84, %BB_1630 ], [ %phi.74, %BB_14f0 ]
  br label %BB_1680

BB_1680:                                          ; preds = %BB_1650
  %shfl_activemask.35 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.35 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.35, float %phi.89, i32 3, i32 31)
  br label %BB_1690

BB_1690:                                          ; preds = %BB_1680
  %isetrp_cmp1.59 = icmp uge i32 %tid_x, 4
  %isetrp_cmp1.60 = icmp ne i32 %tid_x, 4
  br label %BB_16c0

BB_16c0:                                          ; preds = %BB_1690
  %124 = zext i1 %isetrp_cmp1.59 to i32
  %125 = icmp ne i32 %124, 0
  br i1 %125, label %BB_800016c0, label %BB_16e0

BB_800016c0:                                      ; preds = %BB_16c0
  %lds_addr_memaddr_offset_add.36 = add i32 %.88, 396
  %.1658 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.36
  %lds.39 = load volatile float, ptr addrspace(3) %.1658, align 4
  %ffma.95 = call float @llvm.fma.f32(float %shfl_idx.35, float %lds.39, float %phi.75)
  br label %BB_16e0

BB_16e0:                                          ; preds = %BB_800016c0, %BB_16c0
  %phi.90 = phi float [ %ffma.95, %BB_800016c0 ], [ %phi.75, %BB_16c0 ]
  %warp_reconv_mask.3 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.3)
  br i1 %isetrp_cmp1.60, label %BB_1840, label %BB_16f0

BB_16f0:                                          ; preds = %BB_16e0
  %ffma_addend_fneg.4 = fneg float %phi.90
  %ffma.96 = call float @llvm.fma.f32(float %phi.86, float %phi, float %ffma_addend_fneg.4)
  %lds_addr_memaddr_offset_add.37 = add i32 %.75, 544
  %.1668 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.37
  %lds.40 = load volatile float, ptr addrspace(3) %.1668, align 4
  %mufu_rcp.8 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.40)
  %fchk_num_bits.4 = bitcast float %ffma.96 to i32
  %fchk_den_bits.4 = bitcast float %lds.40 to i32
  %fchk_aden.4 = and i32 %fchk_den_bits.4, 2147483647
  %fchk_anum.4 = and i32 %fchk_num_bits.4, 2147483647
  %fchk_den_subz.4 = icmp ult i32 %fchk_aden.4, 8388608
  %fchk_den_infnan.4 = icmp uge i32 %fchk_aden.4, 2139095040
  %fchk_num_infnan.4 = icmp uge i32 %fchk_anum.4, 2139095040
  %fchk_den_bad.4 = or i1 %fchk_den_subz.4, %fchk_den_infnan.4
  %fchk_px.4 = or i1 %fchk_den_bad.4, %fchk_num_infnan.4
  %ffma_lhs_fneg.8 = fneg float %lds.40
  %ffma.97 = call float @llvm.fma.f32(float %ffma_lhs_fneg.8, float %mufu_rcp.8, float 1.000000e+00)
  %ffma.98 = call float @llvm.fma.f32(float %mufu_rcp.8, float %ffma.97, float %mufu_rcp.8)
  %ffma.99 = call float @llvm.fma.f32(float %ffma.96, float %ffma.98, float 0.000000e+00)
  %ffma.100 = call float @llvm.fma.f32(float %ffma_lhs_fneg.8, float %ffma.99, float %ffma.96)
  %ffma.101 = call float @llvm.fma.f32(float %ffma.98, float %ffma.100, float %ffma.99)
  br label %BB_17d0

BB_17d0:                                          ; preds = %BB_16f0
  %cond_not.41 = xor i1 %fchk_px.4, true
  br i1 %cond_not.41, label %BB_1820, label %BB_1800_6f40

BB_1800_6f40:                                     ; preds = %BB_17d0
  %.1672 = zext i32 %fchk_den_bits.4 to i64
  %.1673 = shl i64 %.1672, 32
  %.1674 = lshr i64 %.1673, 23
  %shf_hi.25 = lshr i64 %.1674, 32
  %shf_result.30 = trunc i64 %shf_hi.25 to i32
  %.1676 = zext i32 %fchk_num_bits.4 to i64
  %.1677 = shl i64 %.1676, 32
  %.1678 = lshr i64 %.1677, 23
  %shf_hi.26 = lshr i64 %.1678, 32
  %shf_result.31 = trunc i64 %shf_hi.26 to i32
  %.1682 = and i32 %shf_result.30, 255
  %.1690 = and i32 %shf_result.31, 255
  %iadd3_n1.47 = add i32 %.1682, -1
  %iadd3_n1.48 = add i32 %.1690, -1
  %isetrp_cmp1.61 = icmp ugt i32 %iadd3_n1.47, 253
  %isetrp_cmp1.62 = icmp ugt i32 %iadd3_n1.48, 253
  %isetrp_cmp2.62 = or i1 %isetrp_cmp1.62, %isetrp_cmp1.61
  br label %BB_1800_6fd0

BB_1800_6fd0:                                     ; preds = %BB_1800_6f40
  %cond_not.42 = xor i1 %isetrp_cmp2.62, true
  br i1 %cond_not.42, label %BB_1800_80006fd0, label %BB_1800_6ff0

BB_1800_6ff0:                                     ; preds = %BB_1800_6fd0
  %fsetrp_lhs_fabs.20 = call float @llvm.nvvm.fabs.f(float %ffma.96)
  %fsetrp_cmp1.24 = fcmp ugt float %fsetrp_lhs_fabs.20, 0x7FF0000000000000
  %fsetrp_lhs_fabs.21 = call float @llvm.nvvm.fabs.f(float %lds.40)
  %fsetrp_cmp1.25 = fcmp ugt float %fsetrp_lhs_fabs.21, 0x7FF0000000000000
  %lop3_a_cast_zext.16 = zext i1 %fsetrp_cmp1.24 to i32
  %lop3_b_cast_zext.16 = zext i1 %fsetrp_cmp1.25 to i32
  %plop3_a_bit.16 = and i32 %lop3_a_cast_zext.16, 1
  %plop3_b_bit.16 = and i32 %lop3_b_cast_zext.16, 1
  %.1697 = xor i32 %plop3_a_bit.16, 1
  %.1698 = xor i32 %plop3_b_bit.16, 1
  %.1700 = and i32 %.1697, %plop3_b_bit.16
  %.1702 = and i32 %plop3_a_bit.16, %.1698
  %.1704 = or i32 %.1700, %.1702
  %.1705 = and i32 %plop3_a_bit.16, %plop3_b_bit.16
  %.1707 = or i32 %.1704, %.1705
  %lop3_pred_cmp.28 = icmp ne i32 %.1707, 0
  br label %BB_1800_7020

BB_1800_7020:                                     ; preds = %BB_1800_6ff0
  %126 = zext i1 %lop3_pred_cmp.28 to i32
  %127 = icmp ne i32 %126, 0
  br i1 %127, label %BB_1800_7580, label %BB_1800_7030

BB_1800_7030:                                     ; preds = %BB_1800_7020
  %.1710 = xor i32 %fchk_den_bits.4, -1
  %.1712 = xor i32 %fchk_num_bits.4, -1
  %.1713 = and i32 %.1710, 2147483647
  %.1714 = and i32 %.1713, %fchk_num_bits.4
  %.1716 = and i32 %fchk_aden.4, %.1712
  %.1717 = or i32 %.1714, %.1716
  %.1719 = and i32 %fchk_aden.4, %fchk_num_bits.4
  %.1720 = or i32 %.1717, %.1719
  %lop3_pred_cmp.29 = icmp ne i32 %.1720, 0
  br label %BB_1800_7040

BB_1800_7040:                                     ; preds = %BB_1800_7030
  %cond_not.43 = xor i1 %lop3_pred_cmp.29, true
  br i1 %cond_not.43, label %BB_1800_7560, label %BB_1800_7050

BB_1800_7050:                                     ; preds = %BB_1800_7040
  %fsetrp_cmp1.26 = fcmp une float %fsetrp_lhs_fabs.20, 0x7FF0000000000000
  %fsetrp_cmp1.27 = fcmp une float %fsetrp_lhs_fabs.21, 0x7FF0000000000000
  br label %BB_1800_7080

BB_1800_7080:                                     ; preds = %BB_1800_7050
  %cond_not.44 = xor i1 %fsetrp_cmp1.27, true
  br i1 %cond_not.44, label %BB_1800_80007080, label %BB_1800_7090

BB_1800_80007080:                                 ; preds = %BB_1800_7080
  %bra_cond_not.4 = xor i1 %fsetrp_cmp1.26, true
  br i1 %bra_cond_not.4, label %BB_1800_7560, label %BB_1800_7090

BB_1800_7090:                                     ; preds = %BB_1800_80007080, %BB_1800_7080
  %lop3_pred_cmp.30 = icmp ne i32 %fchk_anum.4, 0
  %lop3_a_cast_zext.17 = zext i1 %fsetrp_cmp1.27 to i32
  %lop3_b_cast_zext.17 = zext i1 %lop3_pred_cmp.30 to i32
  %plop3_a_bit.17 = and i32 %lop3_a_cast_zext.17, 1
  %plop3_b_bit.17 = and i32 %lop3_b_cast_zext.17, 1
  %.1734 = xor i32 %plop3_a_bit.17, 1
  %.1735 = xor i32 %plop3_b_bit.17, 1
  %.1737 = and i32 %.1734, %.1735
  %.1739 = and i32 %.1734, %plop3_b_bit.17
  %.1741 = or i32 %.1737, %.1739
  %.1742 = and i32 %plop3_a_bit.17, %.1735
  %.1744 = or i32 %.1741, %.1742
  %lop3_pred_cmp.31 = icmp ne i32 %.1744, 0
  br label %BB_1800_70b0

BB_1800_70b0:                                     ; preds = %BB_1800_7090
  %128 = zext i1 %lop3_pred_cmp.31 to i32
  %129 = icmp ne i32 %128, 0
  br i1 %129, label %BB_1800_7540, label %BB_1800_70c0

BB_1800_70c0:                                     ; preds = %BB_1800_70b0
  %lop3_pred_cmp.32 = icmp ne i32 %fchk_aden.4, 0
  %lop3_a_cast_zext.18 = zext i1 %fsetrp_cmp1.26 to i32
  %lop3_b_cast_zext.18 = zext i1 %lop3_pred_cmp.32 to i32
  %plop3_a_bit.18 = and i32 %lop3_a_cast_zext.18, 1
  %plop3_b_bit.18 = and i32 %lop3_b_cast_zext.18, 1
  %.1755 = xor i32 %plop3_a_bit.18, 1
  %.1756 = xor i32 %plop3_b_bit.18, 1
  %.1758 = and i32 %.1755, %.1756
  %.1760 = and i32 %.1755, %plop3_b_bit.18
  %.1762 = or i32 %.1758, %.1760
  %.1763 = and i32 %plop3_a_bit.18, %.1756
  %.1765 = or i32 %.1762, %.1763
  %lop3_pred_cmp.33 = icmp ne i32 %.1765, 0
  br label %BB_1800_70e0

BB_1800_70e0:                                     ; preds = %BB_1800_70c0
  %130 = zext i1 %lop3_pred_cmp.33 to i32
  %131 = icmp ne i32 %130, 0
  br i1 %131, label %BB_1800_7510, label %BB_1800_70f0

BB_1800_70f0:                                     ; preds = %BB_1800_70e0
  %isetrp_cmp1.63 = icmp sge i32 %iadd3_n1.48, 0
  %isetrp_cmp1.64 = icmp sge i32 %iadd3_n1.47, 0
  br label %BB_1800_7130

BB_1800_7130:                                     ; preds = %BB_1800_70f0
  %132 = zext i1 %isetrp_cmp1.63 to i32
  %133 = icmp ne i32 %132, 0
  br i1 %133, label %BB_1800_80007130, label %BB_1800_7140

BB_1800_80007130:                                 ; preds = %BB_1800_7130
  br label %BB_1800_7140

BB_1800_7140:                                     ; preds = %BB_1800_80007130, %BB_1800_7130
  %phi.91 = phi i32 [ 0, %BB_1800_80007130 ], [ %iadd3_n1.47, %BB_1800_7130 ]
  %cond_not.45 = xor i1 %isetrp_cmp1.63, true
  br i1 %cond_not.45, label %BB_1800_80007140, label %BB_1800_7160

BB_1800_80007140:                                 ; preds = %BB_1800_7140
  %ffma.102 = call float @llvm.fma.f32(float %ffma.96, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2802_bitcast = bitcast float %ffma.102 to i32
  br label %BB_1800_7160

BB_1800_7160:                                     ; preds = %BB_1800_80007140, %BB_1800_7140
  %phi.92 = phi i32 [ %phi_cast_R2802_bitcast, %BB_1800_80007140 ], [ %fchk_num_bits.4, %BB_1800_7140 ]
  %phi.93 = phi i32 [ -64, %BB_1800_80007140 ], [ %phi.91, %BB_1800_7140 ]
  %cond_not.46 = xor i1 %isetrp_cmp1.64, true
  br i1 %cond_not.46, label %BB_1800_80007160, label %BB_1800_7180

BB_1800_80007160:                                 ; preds = %BB_1800_7160
  %ffma.103 = call float @llvm.fma.f32(float %lds.40, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.9 = add i32 %phi.93, 64
  %phi_cast_R929_bitcast = bitcast float %ffma.103 to i32
  br label %BB_1800_7180

BB_1800_7510:                                     ; preds = %BB_1800_70e0
  %.1778 = and i32 %.1710, -2147483648
  %.1779 = and i32 %.1778, %fchk_num_bits.4
  %.1780 = and i32 %fchk_den_bits.4, -2147483648
  %.1781 = and i32 %.1780, %.1712
  %.1782 = or i32 %.1779, %.1781
  %.1783 = xor i32 %.1782, -1
  %.1786 = and i32 %.1783, 2139095040
  %.1793 = or i32 %.1786, %.1782
  %phi_cast_R2806_bitcast = bitcast i32 %.1793 to float
  br label %BB_1800_7590

BB_1800_7540:                                     ; preds = %BB_1800_70b0
  %.1807 = and i32 %.1710, -2147483648
  %.1808 = and i32 %.1807, %fchk_num_bits.4
  %.1809 = and i32 %fchk_den_bits.4, -2147483648
  %.1810 = and i32 %.1809, %.1712
  %.1811 = or i32 %.1808, %.1810
  %phi_cast_R2807_bitcast = bitcast i32 %.1811 to float
  br label %BB_1800_7590

BB_1800_7560:                                     ; preds = %BB_1800_80007080, %BB_1800_7040
  %mufu_rsq.4 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1800_7590

BB_1800_7580:                                     ; preds = %BB_1800_7020
  %fadd.8 = fadd float %ffma.96, %lds.40
  br label %BB_1800_7590

BB_1800_80006fd0:                                 ; preds = %BB_1800_6fd0
  br label %BB_1800_7180

BB_1800_7180:                                     ; preds = %BB_1800_80006fd0, %BB_1800_80007160, %BB_1800_7160
  %phi.94 = phi i32 [ %fchk_den_bits.4, %BB_1800_80006fd0 ], [ %phi_cast_R929_bitcast, %BB_1800_80007160 ], [ %fchk_den_bits.4, %BB_1800_7160 ]
  %phi.95 = phi i32 [ %fchk_num_bits.4, %BB_1800_80006fd0 ], [ %phi.92, %BB_1800_80007160 ], [ %phi.92, %BB_1800_7160 ]
  %phi.96 = phi i32 [ 0, %BB_1800_80006fd0 ], [ %viadd.9, %BB_1800_80007160 ], [ %phi.93, %BB_1800_7160 ]
  %.1816 = zext i32 %.1682 to i64
  %.1819 = shl i64 %.1816, 23
  %.1820 = and i64 %.1819, 4294967295
  %.1821 = add i64 %.1820, 3229614080
  %.1822 = trunc i64 %.1821 to i32
  %iadd3_n1.50 = add i32 %.1690, -127
  %iadd3_o1_not.8 = xor i32 %.1822, -1
  %iadd3_o1_neg.8 = add i32 %iadd3_o1_not.8, 1
  %iadd3_n1.51 = add i32 %iadd3_o1_neg.8, %phi.94
  %imad_tmp.26 = mul i32 %iadd3_n1.50, -8388608
  %imad.37 = add i32 %imad_tmp.26, %phi.95
  %mufu_src_bitcast.4 = bitcast i32 %iadd3_n1.51 to float
  %mufu_rcp.9 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.4)
  %fadd_lhs_fneg.4 = fneg float %mufu_src_bitcast.4
  %fadd.9 = fadd float %fadd_lhs_fneg.4, 0.000000e+00
  %iadd3_o3_not.4 = xor i32 %.1682, -1
  %iadd3_o3_neg.4 = add i32 %iadd3_o3_not.4, 1
  %iadd3_n2.52 = add i32 %.1690, %iadd3_o3_neg.4
  %iadd3_n1.53 = add i32 %iadd3_n2.52, %phi.96
  %ffma.104 = call float @llvm.fma.f32(float %mufu_rcp.9, float %fadd.9, float 1.000000e+00)
  %ffma.105 = call float @llvm.fma.f32(float %mufu_rcp.9, float %ffma.104, float %mufu_rcp.9)
  %ffma_lhs_bitcast.4 = bitcast i32 %imad.37 to float
  %ffma.106 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.4, float %ffma.105, float 0.000000e+00)
  %ffma.107 = call float @llvm.fma.f32(float %fadd.9, float %ffma.106, float %ffma_lhs_bitcast.4)
  %ffma.108 = call float @llvm.fma.f32(float %ffma.105, float %ffma.107, float %ffma.106)
  %ffma.109 = call float @llvm.fma.f32(float %fadd.9, float %ffma.108, float %ffma_lhs_bitcast.4)
  %ffma.110 = call float @llvm.fma.f32(float %ffma.105, float %ffma.109, float %ffma.108)
  %shf_hi_bitcast.14 = bitcast float %ffma.110 to i32
  %.1824 = zext i32 %shf_hi_bitcast.14 to i64
  %.1825 = shl i64 %.1824, 32
  %.1826 = lshr i64 %.1825, 23
  %shf_hi.27 = lshr i64 %.1826, 32
  %shf_result.32 = trunc i64 %shf_hi.27 to i32
  %.1830 = and i32 %shf_result.32, 255
  %imad.38 = add i32 %.1830, %iadd3_n1.53
  %iadd3_n1.54 = add i32 %imad.38, -1
  %isetrp_cmp1.65 = icmp uge i32 %iadd3_n1.54, 254
  br label %BB_1800_72d0

BB_1800_72d0:                                     ; preds = %BB_1800_7180
  %cond_not.47 = xor i1 %isetrp_cmp1.65, true
  br i1 %cond_not.47, label %BB_1800_74e0, label %BB_1800_72e0

BB_1800_72e0:                                     ; preds = %BB_1800_72d0
  %isetrp_cmp1.66 = icmp sgt i32 %imad.38, 254
  br label %BB_1800_72f0

BB_1800_72f0:                                     ; preds = %BB_1800_72e0
  %134 = zext i1 %isetrp_cmp1.66 to i32
  %135 = icmp ne i32 %134, 0
  br i1 %135, label %BB_1800_74b0, label %BB_1800_7300

BB_1800_7300:                                     ; preds = %BB_1800_72f0
  %isetrp_cmp1.67 = icmp sge i32 %imad.38, 1
  br label %BB_1800_7310

BB_1800_7310:                                     ; preds = %BB_1800_7300
  %phi_cast_R2520_bitcast.2 = bitcast i32 %iadd3_n1.53 to float
  br i1 %isetrp_cmp1.67, label %BB_1800_7590, label %BB_1800_7320

BB_1800_7320:                                     ; preds = %BB_1800_7310
  %isetrp_cmp1.68 = icmp sge i32 %imad.38, -24
  %.1844 = and i32 %shf_hi_bitcast.14, -2147483648
  br label %BB_1800_7340

BB_1800_7340:                                     ; preds = %BB_1800_7320
  %cond_not.48 = xor i1 %isetrp_cmp1.68, true
  %phi_cast_R2817_bitcast = bitcast i32 %.1844 to float
  br i1 %cond_not.48, label %BB_1800_7590, label %BB_1800_7350

BB_1800_7350:                                     ; preds = %BB_1800_7340
  %ffma_rz.4 = call float @llvm.nvvm.fma.rz.f(float %ffma.105, float %ffma.109, float %ffma.108)
  %iadd3_n1.55 = add i32 %imad.38, 32
  %lop3_a_bitcast.38 = bitcast float %ffma_rz.4 to i32
  %.1854 = and i32 %lop3_a_bitcast.38, 8388607
  %ffma_rp.4 = call float @llvm.nvvm.fma.rp.f(float %ffma.105, float %ffma.109, float %ffma.108)
  %ffma_rm.4 = call float @llvm.nvvm.fma.rm.f(float %ffma.105, float %ffma.109, float %ffma.108)
  %isetrp_cmp1.70 = icmp ne i32 %imad.38, 0
  %.1869 = or i32 8388608, %.1854
  %iadd3_o1_not.9 = xor i32 %imad.38, -1
  %iadd3_o1_neg.9 = add i32 %iadd3_o1_not.9, 1
  %.1879 = zext i32 %.1869 to i64
  %shf_shift_64.33 = zext i32 %iadd3_n1.55 to i64
  %.1882 = shl i64 %.1879, %shf_shift_64.33
  %shf_result.33 = trunc i64 %.1882 to i32
  %fsetrp_cmp1.29 = fcmp une float %ffma_rp.4, %ffma_rm.4
  %isetrp_cmp1.71 = icmp ne i32 %shf_result.33, 0
  %isetrp_cmp2.71 = and i1 %isetrp_cmp1.71, %isetrp_cmp1.70
  %.1885 = shl i64 %.1879, 32
  %shf_shift_64.34 = zext i32 %iadd3_o1_neg.9 to i64
  %.1886 = lshr i64 %.1885, %shf_shift_64.34
  %shf_hi.28 = lshr i64 %.1886, 32
  %shf_result.34 = trunc i64 %shf_hi.28 to i32
  %lop3_a_cast_zext.19 = zext i1 %fsetrp_cmp1.29 to i32
  %lop3_b_cast_zext.19 = zext i1 %isetrp_cmp2.71 to i32
  %plop3_a_bit.19 = and i32 %lop3_a_cast_zext.19, 1
  %plop3_b_bit.19 = and i32 %lop3_b_cast_zext.19, 1
  %.1887 = xor i32 %plop3_a_bit.19, 1
  %.1888 = xor i32 %plop3_b_bit.19, 1
  %.1890 = and i32 %.1887, %plop3_b_bit.19
  %.1892 = and i32 %plop3_a_bit.19, %.1888
  %.1894 = or i32 %.1890, %.1892
  %.1895 = and i32 %plop3_a_bit.19, %plop3_b_bit.19
  %.1897 = or i32 %.1894, %.1895
  %lop3_pred_cmp.34 = icmp ne i32 %.1897, 0
  %.1899 = zext i32 %shf_result.34 to i64
  %.1900 = shl i64 %.1899, 32
  %.1901 = lshr i64 %.1900, 1
  %shf_hi.29 = lshr i64 %.1901, 32
  %shf_result.35 = trunc i64 %shf_hi.29 to i32
  %sel_pred_not.4 = xor i1 %lop3_pred_cmp.34, true
  %sel.9 = select i1 %sel_pred_not.4, i32 0, i32 1
  %.1902 = xor i32 %sel.9, -1
  %.1904 = xor i32 %shf_result.35, -1
  %.1905 = and i32 %.1902, 1
  %.1906 = and i32 %.1905, %shf_result.35
  %.1914 = and i32 %sel.9, %.1904
  %.1915 = or i32 %.1906, %.1914
  %.1917 = and i32 %sel.9, %shf_result.35
  %.1918 = or i32 %.1915, %.1917
  %.1922 = and i32 %.1918, %shf_result.34
  %imad.39 = add i32 %shf_result.35, %.1922
  %.1927 = xor i32 %imad.39, -1
  %.1928 = xor i32 %.1844, -1
  %.1930 = and i32 %.1927, %.1844
  %.1935 = and i32 %imad.39, %.1928
  %.1937 = or i32 %.1930, %.1935
  %.1941 = and i32 %imad.39, %.1844
  %.1943 = or i32 %.1937, %.1941
  %phi_cast_R2818_bitcast = bitcast i32 %.1943 to float
  %phi_cast_R2543_bitcast = bitcast i32 %.1869 to float
  br label %BB_1800_7590

BB_1800_74b0:                                     ; preds = %BB_1800_72f0
  %.1951 = and i32 %shf_hi_bitcast.14, -2147483648
  %.1966 = or i32 2139095040, %.1951
  %phi_cast_R2821_bitcast = bitcast i32 %.1966 to float
  %phi_cast_R2520_bitcast = bitcast i32 %iadd3_n1.53 to float
  br label %BB_1800_7590

BB_1800_74e0:                                     ; preds = %BB_1800_72d0
  %.1977 = zext i32 %iadd3_n1.53 to i64
  %.1980 = shl i64 %.1977, 23
  %.1981 = and i64 %.1980, 4294967295
  %.1982 = add i64 %.1981, %.1824
  %.1983 = trunc i64 %.1982 to i32
  %phi_cast_R2822_bitcast = bitcast i32 %.1983 to float
  %phi_cast_R2520_bitcast.1 = bitcast i32 %iadd3_n1.53 to float
  br label %BB_1800_7590

BB_1800_7590:                                     ; preds = %BB_1800_74e0, %BB_1800_74b0, %BB_1800_7350, %BB_1800_7340, %BB_1800_7310, %BB_1800_7580, %BB_1800_7560, %BB_1800_7540, %BB_1800_7510
  %phi.97 = phi float [ %phi_cast_R2818_bitcast, %BB_1800_7350 ], [ %phi_cast_R2821_bitcast, %BB_1800_74b0 ], [ %phi_cast_R2822_bitcast, %BB_1800_74e0 ], [ %ffma.110, %BB_1800_7310 ], [ %phi_cast_R2817_bitcast, %BB_1800_7340 ], [ %phi_cast_R2806_bitcast, %BB_1800_7510 ], [ %phi_cast_R2807_bitcast, %BB_1800_7540 ], [ %mufu_rsq.4, %BB_1800_7560 ], [ %fadd.8, %BB_1800_7580 ]
  %phi.98 = phi float [ %phi_cast_R2543_bitcast, %BB_1800_7350 ], [ %phi_cast_R2520_bitcast, %BB_1800_74b0 ], [ %phi_cast_R2520_bitcast.1, %BB_1800_74e0 ], [ %phi_cast_R2520_bitcast.2, %BB_1800_7310 ], [ %phi_cast_R2520_bitcast.2, %BB_1800_7340 ], [ %phi.87, %BB_1800_7510 ], [ %phi.87, %BB_1800_7540 ], [ %phi.87, %BB_1800_7560 ], [ %phi.87, %BB_1800_7580 ]
  br label %BB_1820

BB_1820:                                          ; preds = %BB_1800_7590, %BB_17d0
  %phi.99 = phi float [ %phi.97, %BB_1800_7590 ], [ %ffma.101, %BB_17d0 ]
  %phi.100 = phi float [ %phi.98, %BB_1800_7590 ], [ %phi.87, %BB_17d0 ]
  br label %BB_1840

BB_1840:                                          ; preds = %BB_1820, %BB_16e0
  %phi.101 = phi float [ %phi.99, %BB_1820 ], [ %phi.86, %BB_16e0 ]
  %phi.102 = phi float [ %phi.100, %BB_1820 ], [ %phi.87, %BB_16e0 ]
  %phi.103 = phi i32 [ %.75, %BB_1820 ], [ %phi.88, %BB_16e0 ]
  %phi.104 = phi float [ %phi.99, %BB_1820 ], [ %phi.89, %BB_16e0 ]
  br label %BB_1870

BB_1870:                                          ; preds = %BB_1840
  %shfl_activemask.36 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.36 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.36, float %phi.104, i32 4, i32 31)
  br label %BB_1880

BB_1880:                                          ; preds = %BB_1870
  %isetrp_cmp1.72 = icmp uge i32 %tid_x, 5
  %isetrp_cmp1.73 = icmp ne i32 %tid_x, 5
  br label %BB_18b0

BB_18b0:                                          ; preds = %BB_1880
  %136 = zext i1 %isetrp_cmp1.72 to i32
  %137 = icmp ne i32 %136, 0
  br i1 %137, label %BB_800018b0, label %BB_18d0

BB_800018b0:                                      ; preds = %BB_18b0
  %lds_addr_memaddr_offset_add.38 = add i32 %.88, 528
  %.1991 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.38
  %lds.41 = load volatile float, ptr addrspace(3) %.1991, align 4
  %ffma.111 = call float @llvm.fma.f32(float %shfl_idx.36, float %lds.41, float %phi.90)
  br label %BB_18d0

BB_18d0:                                          ; preds = %BB_800018b0, %BB_18b0
  %phi.105 = phi float [ %ffma.111, %BB_800018b0 ], [ %phi.90, %BB_18b0 ]
  %warp_reconv_mask.4 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.4)
  br i1 %isetrp_cmp1.73, label %BB_1a30, label %BB_18e0

BB_18e0:                                          ; preds = %BB_18d0
  %ffma_addend_fneg.5 = fneg float %phi.105
  %ffma.112 = call float @llvm.fma.f32(float %phi.101, float %phi, float %ffma_addend_fneg.5)
  %lds_addr_memaddr_offset_add.39 = add i32 %.75, 680
  %.2001 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.39
  %lds.42 = load volatile float, ptr addrspace(3) %.2001, align 4
  %mufu_rcp.10 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.42)
  %fchk_num_bits.5 = bitcast float %ffma.112 to i32
  %fchk_den_bits.5 = bitcast float %lds.42 to i32
  %fchk_aden.5 = and i32 %fchk_den_bits.5, 2147483647
  %fchk_anum.5 = and i32 %fchk_num_bits.5, 2147483647
  %fchk_den_subz.5 = icmp ult i32 %fchk_aden.5, 8388608
  %fchk_den_infnan.5 = icmp uge i32 %fchk_aden.5, 2139095040
  %fchk_num_infnan.5 = icmp uge i32 %fchk_anum.5, 2139095040
  %fchk_den_bad.5 = or i1 %fchk_den_subz.5, %fchk_den_infnan.5
  %fchk_px.5 = or i1 %fchk_den_bad.5, %fchk_num_infnan.5
  %ffma_lhs_fneg.10 = fneg float %lds.42
  %ffma.113 = call float @llvm.fma.f32(float %ffma_lhs_fneg.10, float %mufu_rcp.10, float 1.000000e+00)
  %ffma.114 = call float @llvm.fma.f32(float %mufu_rcp.10, float %ffma.113, float %mufu_rcp.10)
  %ffma.115 = call float @llvm.fma.f32(float %ffma.112, float %ffma.114, float 0.000000e+00)
  %ffma.116 = call float @llvm.fma.f32(float %ffma_lhs_fneg.10, float %ffma.115, float %ffma.112)
  %ffma.117 = call float @llvm.fma.f32(float %ffma.114, float %ffma.116, float %ffma.115)
  br label %BB_19c0

BB_19c0:                                          ; preds = %BB_18e0
  %cond_not.49 = xor i1 %fchk_px.5, true
  br i1 %cond_not.49, label %BB_1a10, label %BB_19f0_6f40

BB_19f0_6f40:                                     ; preds = %BB_19c0
  %.2005 = zext i32 %fchk_den_bits.5 to i64
  %.2006 = shl i64 %.2005, 32
  %.2007 = lshr i64 %.2006, 23
  %shf_hi.30 = lshr i64 %.2007, 32
  %shf_result.36 = trunc i64 %shf_hi.30 to i32
  %.2009 = zext i32 %fchk_num_bits.5 to i64
  %.2010 = shl i64 %.2009, 32
  %.2011 = lshr i64 %.2010, 23
  %shf_hi.31 = lshr i64 %.2011, 32
  %shf_result.37 = trunc i64 %shf_hi.31 to i32
  %.2015 = and i32 %shf_result.36, 255
  %.2023 = and i32 %shf_result.37, 255
  %iadd3_n1.57 = add i32 %.2015, -1
  %iadd3_n1.58 = add i32 %.2023, -1
  %isetrp_cmp1.74 = icmp ugt i32 %iadd3_n1.57, 253
  %isetrp_cmp1.75 = icmp ugt i32 %iadd3_n1.58, 253
  %isetrp_cmp2.75 = or i1 %isetrp_cmp1.75, %isetrp_cmp1.74
  br label %BB_19f0_6fd0

BB_19f0_6fd0:                                     ; preds = %BB_19f0_6f40
  %cond_not.50 = xor i1 %isetrp_cmp2.75, true
  br i1 %cond_not.50, label %BB_19f0_80006fd0, label %BB_19f0_6ff0

BB_19f0_6ff0:                                     ; preds = %BB_19f0_6fd0
  %fsetrp_lhs_fabs.25 = call float @llvm.nvvm.fabs.f(float %ffma.112)
  %fsetrp_cmp1.30 = fcmp ugt float %fsetrp_lhs_fabs.25, 0x7FF0000000000000
  %fsetrp_lhs_fabs.26 = call float @llvm.nvvm.fabs.f(float %lds.42)
  %fsetrp_cmp1.31 = fcmp ugt float %fsetrp_lhs_fabs.26, 0x7FF0000000000000
  %lop3_a_cast_zext.20 = zext i1 %fsetrp_cmp1.30 to i32
  %lop3_b_cast_zext.20 = zext i1 %fsetrp_cmp1.31 to i32
  %plop3_a_bit.20 = and i32 %lop3_a_cast_zext.20, 1
  %plop3_b_bit.20 = and i32 %lop3_b_cast_zext.20, 1
  %.2030 = xor i32 %plop3_a_bit.20, 1
  %.2031 = xor i32 %plop3_b_bit.20, 1
  %.2033 = and i32 %.2030, %plop3_b_bit.20
  %.2035 = and i32 %plop3_a_bit.20, %.2031
  %.2037 = or i32 %.2033, %.2035
  %.2038 = and i32 %plop3_a_bit.20, %plop3_b_bit.20
  %.2040 = or i32 %.2037, %.2038
  %lop3_pred_cmp.35 = icmp ne i32 %.2040, 0
  br label %BB_19f0_7020

BB_19f0_7020:                                     ; preds = %BB_19f0_6ff0
  %138 = zext i1 %lop3_pred_cmp.35 to i32
  %139 = icmp ne i32 %138, 0
  br i1 %139, label %BB_19f0_7580, label %BB_19f0_7030

BB_19f0_7030:                                     ; preds = %BB_19f0_7020
  %.2043 = xor i32 %fchk_den_bits.5, -1
  %.2045 = xor i32 %fchk_num_bits.5, -1
  %.2046 = and i32 %.2043, 2147483647
  %.2047 = and i32 %.2046, %fchk_num_bits.5
  %.2049 = and i32 %fchk_aden.5, %.2045
  %.2050 = or i32 %.2047, %.2049
  %.2052 = and i32 %fchk_aden.5, %fchk_num_bits.5
  %.2053 = or i32 %.2050, %.2052
  %lop3_pred_cmp.36 = icmp ne i32 %.2053, 0
  br label %BB_19f0_7040

BB_19f0_7040:                                     ; preds = %BB_19f0_7030
  %cond_not.51 = xor i1 %lop3_pred_cmp.36, true
  br i1 %cond_not.51, label %BB_19f0_7560, label %BB_19f0_7050

BB_19f0_7050:                                     ; preds = %BB_19f0_7040
  %fsetrp_cmp1.32 = fcmp une float %fsetrp_lhs_fabs.25, 0x7FF0000000000000
  %fsetrp_cmp1.33 = fcmp une float %fsetrp_lhs_fabs.26, 0x7FF0000000000000
  br label %BB_19f0_7080

BB_19f0_7080:                                     ; preds = %BB_19f0_7050
  %cond_not.52 = xor i1 %fsetrp_cmp1.33, true
  br i1 %cond_not.52, label %BB_19f0_80007080, label %BB_19f0_7090

BB_19f0_80007080:                                 ; preds = %BB_19f0_7080
  %bra_cond_not.5 = xor i1 %fsetrp_cmp1.32, true
  br i1 %bra_cond_not.5, label %BB_19f0_7560, label %BB_19f0_7090

BB_19f0_7090:                                     ; preds = %BB_19f0_80007080, %BB_19f0_7080
  %lop3_pred_cmp.37 = icmp ne i32 %fchk_anum.5, 0
  %lop3_a_cast_zext.21 = zext i1 %fsetrp_cmp1.33 to i32
  %lop3_b_cast_zext.21 = zext i1 %lop3_pred_cmp.37 to i32
  %plop3_a_bit.21 = and i32 %lop3_a_cast_zext.21, 1
  %plop3_b_bit.21 = and i32 %lop3_b_cast_zext.21, 1
  %.2067 = xor i32 %plop3_a_bit.21, 1
  %.2068 = xor i32 %plop3_b_bit.21, 1
  %.2070 = and i32 %.2067, %.2068
  %.2072 = and i32 %.2067, %plop3_b_bit.21
  %.2074 = or i32 %.2070, %.2072
  %.2075 = and i32 %plop3_a_bit.21, %.2068
  %.2077 = or i32 %.2074, %.2075
  %lop3_pred_cmp.38 = icmp ne i32 %.2077, 0
  br label %BB_19f0_70b0

BB_19f0_70b0:                                     ; preds = %BB_19f0_7090
  %140 = zext i1 %lop3_pred_cmp.38 to i32
  %141 = icmp ne i32 %140, 0
  br i1 %141, label %BB_19f0_7540, label %BB_19f0_70c0

BB_19f0_70c0:                                     ; preds = %BB_19f0_70b0
  %lop3_pred_cmp.39 = icmp ne i32 %fchk_aden.5, 0
  %lop3_a_cast_zext.22 = zext i1 %fsetrp_cmp1.32 to i32
  %lop3_b_cast_zext.22 = zext i1 %lop3_pred_cmp.39 to i32
  %plop3_a_bit.22 = and i32 %lop3_a_cast_zext.22, 1
  %plop3_b_bit.22 = and i32 %lop3_b_cast_zext.22, 1
  %.2088 = xor i32 %plop3_a_bit.22, 1
  %.2089 = xor i32 %plop3_b_bit.22, 1
  %.2091 = and i32 %.2088, %.2089
  %.2093 = and i32 %.2088, %plop3_b_bit.22
  %.2095 = or i32 %.2091, %.2093
  %.2096 = and i32 %plop3_a_bit.22, %.2089
  %.2098 = or i32 %.2095, %.2096
  %lop3_pred_cmp.40 = icmp ne i32 %.2098, 0
  br label %BB_19f0_70e0

BB_19f0_70e0:                                     ; preds = %BB_19f0_70c0
  %142 = zext i1 %lop3_pred_cmp.40 to i32
  %143 = icmp ne i32 %142, 0
  br i1 %143, label %BB_19f0_7510, label %BB_19f0_70f0

BB_19f0_70f0:                                     ; preds = %BB_19f0_70e0
  %isetrp_cmp1.76 = icmp sge i32 %iadd3_n1.58, 0
  %isetrp_cmp1.77 = icmp sge i32 %iadd3_n1.57, 0
  br label %BB_19f0_7130

BB_19f0_7130:                                     ; preds = %BB_19f0_70f0
  %144 = zext i1 %isetrp_cmp1.76 to i32
  %145 = icmp ne i32 %144, 0
  br i1 %145, label %BB_19f0_80007130, label %BB_19f0_7140

BB_19f0_80007130:                                 ; preds = %BB_19f0_7130
  br label %BB_19f0_7140

BB_19f0_7140:                                     ; preds = %BB_19f0_80007130, %BB_19f0_7130
  %phi.106 = phi i32 [ 0, %BB_19f0_80007130 ], [ %iadd3_n1.57, %BB_19f0_7130 ]
  %cond_not.53 = xor i1 %isetrp_cmp1.76, true
  br i1 %cond_not.53, label %BB_19f0_80007140, label %BB_19f0_7160

BB_19f0_80007140:                                 ; preds = %BB_19f0_7140
  %ffma.118 = call float @llvm.fma.f32(float %ffma.112, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2826_bitcast = bitcast float %ffma.118 to i32
  br label %BB_19f0_7160

BB_19f0_7160:                                     ; preds = %BB_19f0_80007140, %BB_19f0_7140
  %phi.107 = phi i32 [ %phi_cast_R2826_bitcast, %BB_19f0_80007140 ], [ %fchk_num_bits.5, %BB_19f0_7140 ]
  %phi.108 = phi i32 [ -64, %BB_19f0_80007140 ], [ %phi.106, %BB_19f0_7140 ]
  %cond_not.54 = xor i1 %isetrp_cmp1.77, true
  br i1 %cond_not.54, label %BB_19f0_80007160, label %BB_19f0_7180

BB_19f0_80007160:                                 ; preds = %BB_19f0_7160
  %ffma.119 = call float @llvm.fma.f32(float %lds.42, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.11 = add i32 %phi.108, 64
  %phi_cast_R949_bitcast = bitcast float %ffma.119 to i32
  br label %BB_19f0_7180

BB_19f0_7510:                                     ; preds = %BB_19f0_70e0
  %.2111 = and i32 %.2043, -2147483648
  %.2112 = and i32 %.2111, %fchk_num_bits.5
  %.2113 = and i32 %fchk_den_bits.5, -2147483648
  %.2114 = and i32 %.2113, %.2045
  %.2115 = or i32 %.2112, %.2114
  %.2116 = xor i32 %.2115, -1
  %.2119 = and i32 %.2116, 2139095040
  %.2126 = or i32 %.2119, %.2115
  %phi_cast_R2830_bitcast = bitcast i32 %.2126 to float
  br label %BB_19f0_7590

BB_19f0_7540:                                     ; preds = %BB_19f0_70b0
  %.2140 = and i32 %.2043, -2147483648
  %.2141 = and i32 %.2140, %fchk_num_bits.5
  %.2142 = and i32 %fchk_den_bits.5, -2147483648
  %.2143 = and i32 %.2142, %.2045
  %.2144 = or i32 %.2141, %.2143
  %phi_cast_R2832_bitcast = bitcast i32 %.2144 to float
  br label %BB_19f0_7590

BB_19f0_7560:                                     ; preds = %BB_19f0_80007080, %BB_19f0_7040
  %mufu_rsq.5 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_19f0_7590

BB_19f0_7580:                                     ; preds = %BB_19f0_7020
  %fadd.10 = fadd float %ffma.112, %lds.42
  br label %BB_19f0_7590

BB_19f0_80006fd0:                                 ; preds = %BB_19f0_6fd0
  br label %BB_19f0_7180

BB_19f0_7180:                                     ; preds = %BB_19f0_80006fd0, %BB_19f0_80007160, %BB_19f0_7160
  %phi.109 = phi i32 [ %fchk_den_bits.5, %BB_19f0_80006fd0 ], [ %phi_cast_R949_bitcast, %BB_19f0_80007160 ], [ %fchk_den_bits.5, %BB_19f0_7160 ]
  %phi.110 = phi i32 [ %fchk_num_bits.5, %BB_19f0_80006fd0 ], [ %phi.107, %BB_19f0_80007160 ], [ %phi.107, %BB_19f0_7160 ]
  %phi.111 = phi i32 [ 0, %BB_19f0_80006fd0 ], [ %viadd.11, %BB_19f0_80007160 ], [ %phi.108, %BB_19f0_7160 ]
  %.2149 = zext i32 %.2015 to i64
  %.2152 = shl i64 %.2149, 23
  %.2153 = and i64 %.2152, 4294967295
  %.2154 = add i64 %.2153, 3229614080
  %.2155 = trunc i64 %.2154 to i32
  %iadd3_n1.60 = add i32 %.2023, -127
  %iadd3_o1_not.10 = xor i32 %.2155, -1
  %iadd3_o1_neg.10 = add i32 %iadd3_o1_not.10, 1
  %iadd3_n1.61 = add i32 %iadd3_o1_neg.10, %phi.109
  %imad_tmp.29 = mul i32 %iadd3_n1.60, -8388608
  %imad.40 = add i32 %imad_tmp.29, %phi.110
  %mufu_src_bitcast.5 = bitcast i32 %iadd3_n1.61 to float
  %mufu_rcp.11 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.5)
  %fadd_lhs_fneg.5 = fneg float %mufu_src_bitcast.5
  %fadd.11 = fadd float %fadd_lhs_fneg.5, 0.000000e+00
  %iadd3_o3_not.5 = xor i32 %.2015, -1
  %iadd3_o3_neg.5 = add i32 %iadd3_o3_not.5, 1
  %iadd3_n2.62 = add i32 %.2023, %iadd3_o3_neg.5
  %iadd3_n1.63 = add i32 %iadd3_n2.62, %phi.111
  %ffma.120 = call float @llvm.fma.f32(float %mufu_rcp.11, float %fadd.11, float 1.000000e+00)
  %ffma.121 = call float @llvm.fma.f32(float %mufu_rcp.11, float %ffma.120, float %mufu_rcp.11)
  %ffma_lhs_bitcast.5 = bitcast i32 %imad.40 to float
  %ffma.122 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.5, float %ffma.121, float 0.000000e+00)
  %ffma.123 = call float @llvm.fma.f32(float %fadd.11, float %ffma.122, float %ffma_lhs_bitcast.5)
  %ffma.124 = call float @llvm.fma.f32(float %ffma.121, float %ffma.123, float %ffma.122)
  %ffma.125 = call float @llvm.fma.f32(float %fadd.11, float %ffma.124, float %ffma_lhs_bitcast.5)
  %ffma.126 = call float @llvm.fma.f32(float %ffma.121, float %ffma.125, float %ffma.124)
  %shf_hi_bitcast.17 = bitcast float %ffma.126 to i32
  %.2157 = zext i32 %shf_hi_bitcast.17 to i64
  %.2158 = shl i64 %.2157, 32
  %.2159 = lshr i64 %.2158, 23
  %shf_hi.32 = lshr i64 %.2159, 32
  %shf_result.38 = trunc i64 %shf_hi.32 to i32
  %.2163 = and i32 %shf_result.38, 255
  %imad.41 = add i32 %.2163, %iadd3_n1.63
  %iadd3_n1.64 = add i32 %imad.41, -1
  %isetrp_cmp1.78 = icmp uge i32 %iadd3_n1.64, 254
  br label %BB_19f0_72d0

BB_19f0_72d0:                                     ; preds = %BB_19f0_7180
  %cond_not.55 = xor i1 %isetrp_cmp1.78, true
  br i1 %cond_not.55, label %BB_19f0_74e0, label %BB_19f0_72e0

BB_19f0_72e0:                                     ; preds = %BB_19f0_72d0
  %isetrp_cmp1.79 = icmp sgt i32 %imad.41, 254
  br label %BB_19f0_72f0

BB_19f0_72f0:                                     ; preds = %BB_19f0_72e0
  %146 = zext i1 %isetrp_cmp1.79 to i32
  %147 = icmp ne i32 %146, 0
  br i1 %147, label %BB_19f0_74b0, label %BB_19f0_7300

BB_19f0_7300:                                     ; preds = %BB_19f0_72f0
  %isetrp_cmp1.80 = icmp sge i32 %imad.41, 1
  br label %BB_19f0_7310

BB_19f0_7310:                                     ; preds = %BB_19f0_7300
  %phi_cast_R2643_bitcast.2 = bitcast i32 %iadd3_n1.63 to float
  br i1 %isetrp_cmp1.80, label %BB_19f0_7590, label %BB_19f0_7320

BB_19f0_7320:                                     ; preds = %BB_19f0_7310
  %isetrp_cmp1.81 = icmp sge i32 %imad.41, -24
  %.2177 = and i32 %shf_hi_bitcast.17, -2147483648
  br label %BB_19f0_7340

BB_19f0_7340:                                     ; preds = %BB_19f0_7320
  %cond_not.56 = xor i1 %isetrp_cmp1.81, true
  %phi_cast_R2839_bitcast = bitcast i32 %.2177 to float
  br i1 %cond_not.56, label %BB_19f0_7590, label %BB_19f0_7350

BB_19f0_7350:                                     ; preds = %BB_19f0_7340
  %ffma_rz.5 = call float @llvm.nvvm.fma.rz.f(float %ffma.121, float %ffma.125, float %ffma.124)
  %iadd3_n1.65 = add i32 %imad.41, 32
  %lop3_a_bitcast.46 = bitcast float %ffma_rz.5 to i32
  %.2187 = and i32 %lop3_a_bitcast.46, 8388607
  %ffma_rp.5 = call float @llvm.nvvm.fma.rp.f(float %ffma.121, float %ffma.125, float %ffma.124)
  %ffma_rm.5 = call float @llvm.nvvm.fma.rm.f(float %ffma.121, float %ffma.125, float %ffma.124)
  %isetrp_cmp1.83 = icmp ne i32 %imad.41, 0
  %.2202 = or i32 8388608, %.2187
  %iadd3_o1_not.11 = xor i32 %imad.41, -1
  %iadd3_o1_neg.11 = add i32 %iadd3_o1_not.11, 1
  %.2212 = zext i32 %.2202 to i64
  %shf_shift_64.39 = zext i32 %iadd3_n1.65 to i64
  %.2215 = shl i64 %.2212, %shf_shift_64.39
  %shf_result.39 = trunc i64 %.2215 to i32
  %fsetrp_cmp1.35 = fcmp une float %ffma_rp.5, %ffma_rm.5
  %isetrp_cmp1.84 = icmp ne i32 %shf_result.39, 0
  %isetrp_cmp2.84 = and i1 %isetrp_cmp1.84, %isetrp_cmp1.83
  %.2218 = shl i64 %.2212, 32
  %shf_shift_64.40 = zext i32 %iadd3_o1_neg.11 to i64
  %.2219 = lshr i64 %.2218, %shf_shift_64.40
  %shf_hi.33 = lshr i64 %.2219, 32
  %shf_result.40 = trunc i64 %shf_hi.33 to i32
  %lop3_a_cast_zext.23 = zext i1 %fsetrp_cmp1.35 to i32
  %lop3_b_cast_zext.23 = zext i1 %isetrp_cmp2.84 to i32
  %plop3_a_bit.23 = and i32 %lop3_a_cast_zext.23, 1
  %plop3_b_bit.23 = and i32 %lop3_b_cast_zext.23, 1
  %.2220 = xor i32 %plop3_a_bit.23, 1
  %.2221 = xor i32 %plop3_b_bit.23, 1
  %.2223 = and i32 %.2220, %plop3_b_bit.23
  %.2225 = and i32 %plop3_a_bit.23, %.2221
  %.2227 = or i32 %.2223, %.2225
  %.2228 = and i32 %plop3_a_bit.23, %plop3_b_bit.23
  %.2230 = or i32 %.2227, %.2228
  %lop3_pred_cmp.41 = icmp ne i32 %.2230, 0
  %.2232 = zext i32 %shf_result.40 to i64
  %.2233 = shl i64 %.2232, 32
  %.2234 = lshr i64 %.2233, 1
  %shf_hi.34 = lshr i64 %.2234, 32
  %shf_result.41 = trunc i64 %shf_hi.34 to i32
  %sel_pred_not.5 = xor i1 %lop3_pred_cmp.41, true
  %sel.11 = select i1 %sel_pred_not.5, i32 0, i32 1
  %.2235 = xor i32 %sel.11, -1
  %.2237 = xor i32 %shf_result.41, -1
  %.2238 = and i32 %.2235, 1
  %.2239 = and i32 %.2238, %shf_result.41
  %.2247 = and i32 %sel.11, %.2237
  %.2248 = or i32 %.2239, %.2247
  %.2250 = and i32 %sel.11, %shf_result.41
  %.2251 = or i32 %.2248, %.2250
  %.2255 = and i32 %.2251, %shf_result.40
  %imad.42 = add i32 %shf_result.41, %.2255
  %.2260 = xor i32 %imad.42, -1
  %.2261 = xor i32 %.2177, -1
  %.2263 = and i32 %.2260, %.2177
  %.2268 = and i32 %imad.42, %.2261
  %.2270 = or i32 %.2263, %.2268
  %.2274 = and i32 %imad.42, %.2177
  %.2276 = or i32 %.2270, %.2274
  %phi_cast_R2841_bitcast = bitcast i32 %.2276 to float
  %phi_cast_R2665_bitcast = bitcast i32 %.2202 to float
  br label %BB_19f0_7590

BB_19f0_74b0:                                     ; preds = %BB_19f0_72f0
  %.2284 = and i32 %shf_hi_bitcast.17, -2147483648
  %.2299 = or i32 2139095040, %.2284
  %phi_cast_R2844_bitcast = bitcast i32 %.2299 to float
  %phi_cast_R2643_bitcast = bitcast i32 %iadd3_n1.63 to float
  br label %BB_19f0_7590

BB_19f0_74e0:                                     ; preds = %BB_19f0_72d0
  %.2310 = zext i32 %iadd3_n1.63 to i64
  %.2313 = shl i64 %.2310, 23
  %.2314 = and i64 %.2313, 4294967295
  %.2315 = add i64 %.2314, %.2157
  %.2316 = trunc i64 %.2315 to i32
  %phi_cast_R2845_bitcast = bitcast i32 %.2316 to float
  %phi_cast_R2643_bitcast.1 = bitcast i32 %iadd3_n1.63 to float
  br label %BB_19f0_7590

BB_19f0_7590:                                     ; preds = %BB_19f0_74e0, %BB_19f0_74b0, %BB_19f0_7350, %BB_19f0_7340, %BB_19f0_7310, %BB_19f0_7580, %BB_19f0_7560, %BB_19f0_7540, %BB_19f0_7510
  %phi.112 = phi float [ %phi_cast_R2841_bitcast, %BB_19f0_7350 ], [ %phi_cast_R2844_bitcast, %BB_19f0_74b0 ], [ %phi_cast_R2845_bitcast, %BB_19f0_74e0 ], [ %ffma.126, %BB_19f0_7310 ], [ %phi_cast_R2839_bitcast, %BB_19f0_7340 ], [ %phi_cast_R2830_bitcast, %BB_19f0_7510 ], [ %phi_cast_R2832_bitcast, %BB_19f0_7540 ], [ %mufu_rsq.5, %BB_19f0_7560 ], [ %fadd.10, %BB_19f0_7580 ]
  %phi.113 = phi float [ %phi_cast_R2665_bitcast, %BB_19f0_7350 ], [ %phi_cast_R2643_bitcast, %BB_19f0_74b0 ], [ %phi_cast_R2643_bitcast.1, %BB_19f0_74e0 ], [ %phi_cast_R2643_bitcast.2, %BB_19f0_7310 ], [ %phi_cast_R2643_bitcast.2, %BB_19f0_7340 ], [ %phi.102, %BB_19f0_7510 ], [ %phi.102, %BB_19f0_7540 ], [ %phi.102, %BB_19f0_7560 ], [ %phi.102, %BB_19f0_7580 ]
  br label %BB_1a10

BB_1a10:                                          ; preds = %BB_19f0_7590, %BB_19c0
  %phi.114 = phi float [ %phi.112, %BB_19f0_7590 ], [ %ffma.117, %BB_19c0 ]
  %phi.115 = phi float [ %phi.113, %BB_19f0_7590 ], [ %phi.102, %BB_19c0 ]
  br label %BB_1a30

BB_1a30:                                          ; preds = %BB_1a10, %BB_18d0
  %phi.116 = phi float [ %phi.114, %BB_1a10 ], [ %phi.101, %BB_18d0 ]
  %phi.117 = phi float [ %phi.115, %BB_1a10 ], [ %phi.102, %BB_18d0 ]
  %phi.118 = phi i32 [ %.75, %BB_1a10 ], [ %phi.103, %BB_18d0 ]
  %phi.119 = phi float [ %phi.114, %BB_1a10 ], [ %phi.104, %BB_18d0 ]
  br label %BB_1a60

BB_1a60:                                          ; preds = %BB_1a30
  %shfl_activemask.37 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.37 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.37, float %phi.119, i32 5, i32 31)
  br label %BB_1a70

BB_1a70:                                          ; preds = %BB_1a60
  %isetrp_cmp1.85 = icmp uge i32 %tid_x, 6
  %isetrp_cmp1.86 = icmp ne i32 %tid_x, 6
  br label %BB_1aa0

BB_1aa0:                                          ; preds = %BB_1a70
  %148 = zext i1 %isetrp_cmp1.85 to i32
  %149 = icmp ne i32 %148, 0
  br i1 %149, label %BB_80001aa0, label %BB_1ac0

BB_80001aa0:                                      ; preds = %BB_1aa0
  %lds_addr_memaddr_offset_add.40 = add i32 %.88, 660
  %.2324 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.40
  %lds.43 = load volatile float, ptr addrspace(3) %.2324, align 4
  %ffma.127 = call float @llvm.fma.f32(float %shfl_idx.37, float %lds.43, float %phi.105)
  br label %BB_1ac0

BB_1ac0:                                          ; preds = %BB_80001aa0, %BB_1aa0
  %phi.120 = phi float [ %ffma.127, %BB_80001aa0 ], [ %phi.105, %BB_1aa0 ]
  %warp_reconv_mask.5 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.5)
  br i1 %isetrp_cmp1.86, label %BB_1c20, label %BB_1ad0

BB_1ad0:                                          ; preds = %BB_1ac0
  %ffma_addend_fneg.6 = fneg float %phi.120
  %ffma.128 = call float @llvm.fma.f32(float %phi.116, float %phi, float %ffma_addend_fneg.6)
  %lds_addr_memaddr_offset_add.41 = add i32 %.75, 816
  %.2334 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.41
  %lds.44 = load volatile float, ptr addrspace(3) %.2334, align 4
  %mufu_rcp.12 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.44)
  %fchk_num_bits.6 = bitcast float %ffma.128 to i32
  %fchk_den_bits.6 = bitcast float %lds.44 to i32
  %fchk_aden.6 = and i32 %fchk_den_bits.6, 2147483647
  %fchk_anum.6 = and i32 %fchk_num_bits.6, 2147483647
  %fchk_den_subz.6 = icmp ult i32 %fchk_aden.6, 8388608
  %fchk_den_infnan.6 = icmp uge i32 %fchk_aden.6, 2139095040
  %fchk_num_infnan.6 = icmp uge i32 %fchk_anum.6, 2139095040
  %fchk_den_bad.6 = or i1 %fchk_den_subz.6, %fchk_den_infnan.6
  %fchk_px.6 = or i1 %fchk_den_bad.6, %fchk_num_infnan.6
  %ffma_lhs_fneg.12 = fneg float %lds.44
  %ffma.129 = call float @llvm.fma.f32(float %ffma_lhs_fneg.12, float %mufu_rcp.12, float 1.000000e+00)
  %ffma.130 = call float @llvm.fma.f32(float %mufu_rcp.12, float %ffma.129, float %mufu_rcp.12)
  %ffma.131 = call float @llvm.fma.f32(float %ffma.128, float %ffma.130, float 0.000000e+00)
  %ffma.132 = call float @llvm.fma.f32(float %ffma_lhs_fneg.12, float %ffma.131, float %ffma.128)
  %ffma.133 = call float @llvm.fma.f32(float %ffma.130, float %ffma.132, float %ffma.131)
  br label %BB_1bb0

BB_1bb0:                                          ; preds = %BB_1ad0
  %cond_not.57 = xor i1 %fchk_px.6, true
  br i1 %cond_not.57, label %BB_1c00, label %BB_1be0_6f40

BB_1be0_6f40:                                     ; preds = %BB_1bb0
  %.2338 = zext i32 %fchk_den_bits.6 to i64
  %.2339 = shl i64 %.2338, 32
  %.2340 = lshr i64 %.2339, 23
  %shf_hi.35 = lshr i64 %.2340, 32
  %shf_result.42 = trunc i64 %shf_hi.35 to i32
  %.2342 = zext i32 %fchk_num_bits.6 to i64
  %.2343 = shl i64 %.2342, 32
  %.2344 = lshr i64 %.2343, 23
  %shf_hi.36 = lshr i64 %.2344, 32
  %shf_result.43 = trunc i64 %shf_hi.36 to i32
  %.2348 = and i32 %shf_result.42, 255
  %.2356 = and i32 %shf_result.43, 255
  %iadd3_n1.67 = add i32 %.2348, -1
  %iadd3_n1.68 = add i32 %.2356, -1
  %isetrp_cmp1.87 = icmp ugt i32 %iadd3_n1.67, 253
  %isetrp_cmp1.88 = icmp ugt i32 %iadd3_n1.68, 253
  %isetrp_cmp2.88 = or i1 %isetrp_cmp1.88, %isetrp_cmp1.87
  br label %BB_1be0_6fd0

BB_1be0_6fd0:                                     ; preds = %BB_1be0_6f40
  %cond_not.58 = xor i1 %isetrp_cmp2.88, true
  br i1 %cond_not.58, label %BB_1be0_80006fd0, label %BB_1be0_6ff0

BB_1be0_6ff0:                                     ; preds = %BB_1be0_6fd0
  %fsetrp_lhs_fabs.30 = call float @llvm.nvvm.fabs.f(float %ffma.128)
  %fsetrp_cmp1.36 = fcmp ugt float %fsetrp_lhs_fabs.30, 0x7FF0000000000000
  %fsetrp_lhs_fabs.31 = call float @llvm.nvvm.fabs.f(float %lds.44)
  %fsetrp_cmp1.37 = fcmp ugt float %fsetrp_lhs_fabs.31, 0x7FF0000000000000
  %lop3_a_cast_zext.24 = zext i1 %fsetrp_cmp1.36 to i32
  %lop3_b_cast_zext.24 = zext i1 %fsetrp_cmp1.37 to i32
  %plop3_a_bit.24 = and i32 %lop3_a_cast_zext.24, 1
  %plop3_b_bit.24 = and i32 %lop3_b_cast_zext.24, 1
  %.2363 = xor i32 %plop3_a_bit.24, 1
  %.2364 = xor i32 %plop3_b_bit.24, 1
  %.2366 = and i32 %.2363, %plop3_b_bit.24
  %.2368 = and i32 %plop3_a_bit.24, %.2364
  %.2370 = or i32 %.2366, %.2368
  %.2371 = and i32 %plop3_a_bit.24, %plop3_b_bit.24
  %.2373 = or i32 %.2370, %.2371
  %lop3_pred_cmp.42 = icmp ne i32 %.2373, 0
  br label %BB_1be0_7020

BB_1be0_7020:                                     ; preds = %BB_1be0_6ff0
  %150 = zext i1 %lop3_pred_cmp.42 to i32
  %151 = icmp ne i32 %150, 0
  br i1 %151, label %BB_1be0_7580, label %BB_1be0_7030

BB_1be0_7030:                                     ; preds = %BB_1be0_7020
  %.2376 = xor i32 %fchk_den_bits.6, -1
  %.2378 = xor i32 %fchk_num_bits.6, -1
  %.2379 = and i32 %.2376, 2147483647
  %.2380 = and i32 %.2379, %fchk_num_bits.6
  %.2382 = and i32 %fchk_aden.6, %.2378
  %.2383 = or i32 %.2380, %.2382
  %.2385 = and i32 %fchk_aden.6, %fchk_num_bits.6
  %.2386 = or i32 %.2383, %.2385
  %lop3_pred_cmp.43 = icmp ne i32 %.2386, 0
  br label %BB_1be0_7040

BB_1be0_7040:                                     ; preds = %BB_1be0_7030
  %cond_not.59 = xor i1 %lop3_pred_cmp.43, true
  br i1 %cond_not.59, label %BB_1be0_7560, label %BB_1be0_7050

BB_1be0_7050:                                     ; preds = %BB_1be0_7040
  %fsetrp_cmp1.38 = fcmp une float %fsetrp_lhs_fabs.30, 0x7FF0000000000000
  %fsetrp_cmp1.39 = fcmp une float %fsetrp_lhs_fabs.31, 0x7FF0000000000000
  br label %BB_1be0_7080

BB_1be0_7080:                                     ; preds = %BB_1be0_7050
  %cond_not.60 = xor i1 %fsetrp_cmp1.39, true
  br i1 %cond_not.60, label %BB_1be0_80007080, label %BB_1be0_7090

BB_1be0_80007080:                                 ; preds = %BB_1be0_7080
  %bra_cond_not.6 = xor i1 %fsetrp_cmp1.38, true
  br i1 %bra_cond_not.6, label %BB_1be0_7560, label %BB_1be0_7090

BB_1be0_7090:                                     ; preds = %BB_1be0_80007080, %BB_1be0_7080
  %lop3_pred_cmp.44 = icmp ne i32 %fchk_anum.6, 0
  %lop3_a_cast_zext.25 = zext i1 %fsetrp_cmp1.39 to i32
  %lop3_b_cast_zext.25 = zext i1 %lop3_pred_cmp.44 to i32
  %plop3_a_bit.25 = and i32 %lop3_a_cast_zext.25, 1
  %plop3_b_bit.25 = and i32 %lop3_b_cast_zext.25, 1
  %.2400 = xor i32 %plop3_a_bit.25, 1
  %.2401 = xor i32 %plop3_b_bit.25, 1
  %.2403 = and i32 %.2400, %.2401
  %.2405 = and i32 %.2400, %plop3_b_bit.25
  %.2407 = or i32 %.2403, %.2405
  %.2408 = and i32 %plop3_a_bit.25, %.2401
  %.2410 = or i32 %.2407, %.2408
  %lop3_pred_cmp.45 = icmp ne i32 %.2410, 0
  br label %BB_1be0_70b0

BB_1be0_70b0:                                     ; preds = %BB_1be0_7090
  %152 = zext i1 %lop3_pred_cmp.45 to i32
  %153 = icmp ne i32 %152, 0
  br i1 %153, label %BB_1be0_7540, label %BB_1be0_70c0

BB_1be0_70c0:                                     ; preds = %BB_1be0_70b0
  %lop3_pred_cmp.46 = icmp ne i32 %fchk_aden.6, 0
  %lop3_a_cast_zext.26 = zext i1 %fsetrp_cmp1.38 to i32
  %lop3_b_cast_zext.26 = zext i1 %lop3_pred_cmp.46 to i32
  %plop3_a_bit.26 = and i32 %lop3_a_cast_zext.26, 1
  %plop3_b_bit.26 = and i32 %lop3_b_cast_zext.26, 1
  %.2421 = xor i32 %plop3_a_bit.26, 1
  %.2422 = xor i32 %plop3_b_bit.26, 1
  %.2424 = and i32 %.2421, %.2422
  %.2426 = and i32 %.2421, %plop3_b_bit.26
  %.2428 = or i32 %.2424, %.2426
  %.2429 = and i32 %plop3_a_bit.26, %.2422
  %.2431 = or i32 %.2428, %.2429
  %lop3_pred_cmp.47 = icmp ne i32 %.2431, 0
  br label %BB_1be0_70e0

BB_1be0_70e0:                                     ; preds = %BB_1be0_70c0
  %154 = zext i1 %lop3_pred_cmp.47 to i32
  %155 = icmp ne i32 %154, 0
  br i1 %155, label %BB_1be0_7510, label %BB_1be0_70f0

BB_1be0_70f0:                                     ; preds = %BB_1be0_70e0
  %isetrp_cmp1.89 = icmp sge i32 %iadd3_n1.68, 0
  %isetrp_cmp1.90 = icmp sge i32 %iadd3_n1.67, 0
  br label %BB_1be0_7130

BB_1be0_7130:                                     ; preds = %BB_1be0_70f0
  %156 = zext i1 %isetrp_cmp1.89 to i32
  %157 = icmp ne i32 %156, 0
  br i1 %157, label %BB_1be0_80007130, label %BB_1be0_7140

BB_1be0_80007130:                                 ; preds = %BB_1be0_7130
  br label %BB_1be0_7140

BB_1be0_7140:                                     ; preds = %BB_1be0_80007130, %BB_1be0_7130
  %phi.121 = phi i32 [ 0, %BB_1be0_80007130 ], [ %iadd3_n1.67, %BB_1be0_7130 ]
  %cond_not.61 = xor i1 %isetrp_cmp1.89, true
  br i1 %cond_not.61, label %BB_1be0_80007140, label %BB_1be0_7160

BB_1be0_80007140:                                 ; preds = %BB_1be0_7140
  %ffma.134 = call float @llvm.fma.f32(float %ffma.128, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2849_bitcast = bitcast float %ffma.134 to i32
  br label %BB_1be0_7160

BB_1be0_7160:                                     ; preds = %BB_1be0_80007140, %BB_1be0_7140
  %phi.122 = phi i32 [ %phi_cast_R2849_bitcast, %BB_1be0_80007140 ], [ %fchk_num_bits.6, %BB_1be0_7140 ]
  %phi.123 = phi i32 [ -64, %BB_1be0_80007140 ], [ %phi.121, %BB_1be0_7140 ]
  %cond_not.62 = xor i1 %isetrp_cmp1.90, true
  br i1 %cond_not.62, label %BB_1be0_80007160, label %BB_1be0_7180

BB_1be0_80007160:                                 ; preds = %BB_1be0_7160
  %ffma.135 = call float @llvm.fma.f32(float %lds.44, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.13 = add i32 %phi.123, 64
  %phi_cast_R430_bitcast = bitcast float %ffma.135 to i32
  br label %BB_1be0_7180

BB_1be0_7510:                                     ; preds = %BB_1be0_70e0
  %.2444 = and i32 %.2376, -2147483648
  %.2445 = and i32 %.2444, %fchk_num_bits.6
  %.2446 = and i32 %fchk_den_bits.6, -2147483648
  %.2447 = and i32 %.2446, %.2378
  %.2448 = or i32 %.2445, %.2447
  %.2449 = xor i32 %.2448, -1
  %.2452 = and i32 %.2449, 2139095040
  %.2459 = or i32 %.2452, %.2448
  %phi_cast_R2854_bitcast = bitcast i32 %.2459 to float
  br label %BB_1be0_7590

BB_1be0_7540:                                     ; preds = %BB_1be0_70b0
  %.2473 = and i32 %.2376, -2147483648
  %.2474 = and i32 %.2473, %fchk_num_bits.6
  %.2475 = and i32 %fchk_den_bits.6, -2147483648
  %.2476 = and i32 %.2475, %.2378
  %.2477 = or i32 %.2474, %.2476
  %phi_cast_R2855_bitcast = bitcast i32 %.2477 to float
  br label %BB_1be0_7590

BB_1be0_7560:                                     ; preds = %BB_1be0_80007080, %BB_1be0_7040
  %mufu_rsq.6 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1be0_7590

BB_1be0_7580:                                     ; preds = %BB_1be0_7020
  %fadd.12 = fadd float %ffma.128, %lds.44
  br label %BB_1be0_7590

BB_1be0_80006fd0:                                 ; preds = %BB_1be0_6fd0
  br label %BB_1be0_7180

BB_1be0_7180:                                     ; preds = %BB_1be0_80006fd0, %BB_1be0_80007160, %BB_1be0_7160
  %phi.124 = phi i32 [ %fchk_den_bits.6, %BB_1be0_80006fd0 ], [ %phi_cast_R430_bitcast, %BB_1be0_80007160 ], [ %fchk_den_bits.6, %BB_1be0_7160 ]
  %phi.125 = phi i32 [ %fchk_num_bits.6, %BB_1be0_80006fd0 ], [ %phi.122, %BB_1be0_80007160 ], [ %phi.122, %BB_1be0_7160 ]
  %phi.126 = phi i32 [ 0, %BB_1be0_80006fd0 ], [ %viadd.13, %BB_1be0_80007160 ], [ %phi.123, %BB_1be0_7160 ]
  %.2482 = zext i32 %.2348 to i64
  %.2485 = shl i64 %.2482, 23
  %.2486 = and i64 %.2485, 4294967295
  %.2487 = add i64 %.2486, 3229614080
  %.2488 = trunc i64 %.2487 to i32
  %iadd3_n1.70 = add i32 %.2356, -127
  %iadd3_o1_not.12 = xor i32 %.2488, -1
  %iadd3_o1_neg.12 = add i32 %iadd3_o1_not.12, 1
  %iadd3_n1.71 = add i32 %iadd3_o1_neg.12, %phi.124
  %imad_tmp.32 = mul i32 %iadd3_n1.70, -8388608
  %imad.43 = add i32 %imad_tmp.32, %phi.125
  %mufu_src_bitcast.6 = bitcast i32 %iadd3_n1.71 to float
  %mufu_rcp.13 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.6)
  %fadd_lhs_fneg.6 = fneg float %mufu_src_bitcast.6
  %fadd.13 = fadd float %fadd_lhs_fneg.6, 0.000000e+00
  %iadd3_o3_not.6 = xor i32 %.2348, -1
  %iadd3_o3_neg.6 = add i32 %iadd3_o3_not.6, 1
  %iadd3_n2.72 = add i32 %.2356, %iadd3_o3_neg.6
  %iadd3_n1.73 = add i32 %iadd3_n2.72, %phi.126
  %ffma.136 = call float @llvm.fma.f32(float %mufu_rcp.13, float %fadd.13, float 1.000000e+00)
  %ffma.137 = call float @llvm.fma.f32(float %mufu_rcp.13, float %ffma.136, float %mufu_rcp.13)
  %ffma_lhs_bitcast.6 = bitcast i32 %imad.43 to float
  %ffma.138 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.6, float %ffma.137, float 0.000000e+00)
  %ffma.139 = call float @llvm.fma.f32(float %fadd.13, float %ffma.138, float %ffma_lhs_bitcast.6)
  %ffma.140 = call float @llvm.fma.f32(float %ffma.137, float %ffma.139, float %ffma.138)
  %ffma.141 = call float @llvm.fma.f32(float %fadd.13, float %ffma.140, float %ffma_lhs_bitcast.6)
  %ffma.142 = call float @llvm.fma.f32(float %ffma.137, float %ffma.141, float %ffma.140)
  %shf_hi_bitcast.20 = bitcast float %ffma.142 to i32
  %.2490 = zext i32 %shf_hi_bitcast.20 to i64
  %.2491 = shl i64 %.2490, 32
  %.2492 = lshr i64 %.2491, 23
  %shf_hi.37 = lshr i64 %.2492, 32
  %shf_result.44 = trunc i64 %shf_hi.37 to i32
  %.2496 = and i32 %shf_result.44, 255
  %imad.44 = add i32 %.2496, %iadd3_n1.73
  %iadd3_n1.74 = add i32 %imad.44, -1
  %isetrp_cmp1.91 = icmp uge i32 %iadd3_n1.74, 254
  br label %BB_1be0_72d0

BB_1be0_72d0:                                     ; preds = %BB_1be0_7180
  %cond_not.63 = xor i1 %isetrp_cmp1.91, true
  br i1 %cond_not.63, label %BB_1be0_74e0, label %BB_1be0_72e0

BB_1be0_72e0:                                     ; preds = %BB_1be0_72d0
  %isetrp_cmp1.92 = icmp sgt i32 %imad.44, 254
  br label %BB_1be0_72f0

BB_1be0_72f0:                                     ; preds = %BB_1be0_72e0
  %158 = zext i1 %isetrp_cmp1.92 to i32
  %159 = icmp ne i32 %158, 0
  br i1 %159, label %BB_1be0_74b0, label %BB_1be0_7300

BB_1be0_7300:                                     ; preds = %BB_1be0_72f0
  %isetrp_cmp1.93 = icmp sge i32 %imad.44, 1
  br label %BB_1be0_7310

BB_1be0_7310:                                     ; preds = %BB_1be0_7300
  %phi_cast_R2754_bitcast.2 = bitcast i32 %iadd3_n1.73 to float
  br i1 %isetrp_cmp1.93, label %BB_1be0_7590, label %BB_1be0_7320

BB_1be0_7320:                                     ; preds = %BB_1be0_7310
  %isetrp_cmp1.94 = icmp sge i32 %imad.44, -24
  %.2510 = and i32 %shf_hi_bitcast.20, -2147483648
  br label %BB_1be0_7340

BB_1be0_7340:                                     ; preds = %BB_1be0_7320
  %cond_not.64 = xor i1 %isetrp_cmp1.94, true
  %phi_cast_R2862_bitcast = bitcast i32 %.2510 to float
  br i1 %cond_not.64, label %BB_1be0_7590, label %BB_1be0_7350

BB_1be0_7350:                                     ; preds = %BB_1be0_7340
  %ffma_rz.6 = call float @llvm.nvvm.fma.rz.f(float %ffma.137, float %ffma.141, float %ffma.140)
  %iadd3_n1.75 = add i32 %imad.44, 32
  %lop3_a_bitcast.54 = bitcast float %ffma_rz.6 to i32
  %.2520 = and i32 %lop3_a_bitcast.54, 8388607
  %ffma_rp.6 = call float @llvm.nvvm.fma.rp.f(float %ffma.137, float %ffma.141, float %ffma.140)
  %ffma_rm.6 = call float @llvm.nvvm.fma.rm.f(float %ffma.137, float %ffma.141, float %ffma.140)
  %isetrp_cmp1.96 = icmp ne i32 %imad.44, 0
  %.2535 = or i32 8388608, %.2520
  %iadd3_o1_not.13 = xor i32 %imad.44, -1
  %iadd3_o1_neg.13 = add i32 %iadd3_o1_not.13, 1
  %.2545 = zext i32 %.2535 to i64
  %shf_shift_64.45 = zext i32 %iadd3_n1.75 to i64
  %.2548 = shl i64 %.2545, %shf_shift_64.45
  %shf_result.45 = trunc i64 %.2548 to i32
  %fsetrp_cmp1.41 = fcmp une float %ffma_rp.6, %ffma_rm.6
  %isetrp_cmp1.97 = icmp ne i32 %shf_result.45, 0
  %isetrp_cmp2.97 = and i1 %isetrp_cmp1.97, %isetrp_cmp1.96
  %.2551 = shl i64 %.2545, 32
  %shf_shift_64.46 = zext i32 %iadd3_o1_neg.13 to i64
  %.2552 = lshr i64 %.2551, %shf_shift_64.46
  %shf_hi.38 = lshr i64 %.2552, 32
  %shf_result.46 = trunc i64 %shf_hi.38 to i32
  %lop3_a_cast_zext.27 = zext i1 %fsetrp_cmp1.41 to i32
  %lop3_b_cast_zext.27 = zext i1 %isetrp_cmp2.97 to i32
  %plop3_a_bit.27 = and i32 %lop3_a_cast_zext.27, 1
  %plop3_b_bit.27 = and i32 %lop3_b_cast_zext.27, 1
  %.2553 = xor i32 %plop3_a_bit.27, 1
  %.2554 = xor i32 %plop3_b_bit.27, 1
  %.2556 = and i32 %.2553, %plop3_b_bit.27
  %.2558 = and i32 %plop3_a_bit.27, %.2554
  %.2560 = or i32 %.2556, %.2558
  %.2561 = and i32 %plop3_a_bit.27, %plop3_b_bit.27
  %.2563 = or i32 %.2560, %.2561
  %lop3_pred_cmp.48 = icmp ne i32 %.2563, 0
  %.2565 = zext i32 %shf_result.46 to i64
  %.2566 = shl i64 %.2565, 32
  %.2567 = lshr i64 %.2566, 1
  %shf_hi.39 = lshr i64 %.2567, 32
  %shf_result.47 = trunc i64 %shf_hi.39 to i32
  %sel_pred_not.6 = xor i1 %lop3_pred_cmp.48, true
  %sel.13 = select i1 %sel_pred_not.6, i32 0, i32 1
  %.2568 = xor i32 %sel.13, -1
  %.2570 = xor i32 %shf_result.47, -1
  %.2571 = and i32 %.2568, 1
  %.2572 = and i32 %.2571, %shf_result.47
  %.2580 = and i32 %sel.13, %.2570
  %.2581 = or i32 %.2572, %.2580
  %.2583 = and i32 %sel.13, %shf_result.47
  %.2584 = or i32 %.2581, %.2583
  %.2588 = and i32 %.2584, %shf_result.46
  %imad.45 = add i32 %shf_result.47, %.2588
  %.2593 = xor i32 %imad.45, -1
  %.2594 = xor i32 %.2510, -1
  %.2596 = and i32 %.2593, %.2510
  %.2601 = and i32 %imad.45, %.2594
  %.2603 = or i32 %.2596, %.2601
  %.2607 = and i32 %imad.45, %.2510
  %.2609 = or i32 %.2603, %.2607
  %phi_cast_R2863_bitcast = bitcast i32 %.2609 to float
  %phi_cast_R2787_bitcast = bitcast i32 %.2535 to float
  br label %BB_1be0_7590

BB_1be0_74b0:                                     ; preds = %BB_1be0_72f0
  %.2617 = and i32 %shf_hi_bitcast.20, -2147483648
  %.2632 = or i32 2139095040, %.2617
  %phi_cast_R2868_bitcast = bitcast i32 %.2632 to float
  %phi_cast_R2754_bitcast = bitcast i32 %iadd3_n1.73 to float
  br label %BB_1be0_7590

BB_1be0_74e0:                                     ; preds = %BB_1be0_72d0
  %.2643 = zext i32 %iadd3_n1.73 to i64
  %.2646 = shl i64 %.2643, 23
  %.2647 = and i64 %.2646, 4294967295
  %.2648 = add i64 %.2647, %.2490
  %.2649 = trunc i64 %.2648 to i32
  %phi_cast_R2869_bitcast = bitcast i32 %.2649 to float
  %phi_cast_R2754_bitcast.1 = bitcast i32 %iadd3_n1.73 to float
  br label %BB_1be0_7590

BB_1be0_7590:                                     ; preds = %BB_1be0_74e0, %BB_1be0_74b0, %BB_1be0_7350, %BB_1be0_7340, %BB_1be0_7310, %BB_1be0_7580, %BB_1be0_7560, %BB_1be0_7540, %BB_1be0_7510
  %phi.127 = phi float [ %phi_cast_R2863_bitcast, %BB_1be0_7350 ], [ %phi_cast_R2868_bitcast, %BB_1be0_74b0 ], [ %phi_cast_R2869_bitcast, %BB_1be0_74e0 ], [ %ffma.142, %BB_1be0_7310 ], [ %phi_cast_R2862_bitcast, %BB_1be0_7340 ], [ %phi_cast_R2854_bitcast, %BB_1be0_7510 ], [ %phi_cast_R2855_bitcast, %BB_1be0_7540 ], [ %mufu_rsq.6, %BB_1be0_7560 ], [ %fadd.12, %BB_1be0_7580 ]
  %phi.128 = phi float [ %phi_cast_R2787_bitcast, %BB_1be0_7350 ], [ %phi_cast_R2754_bitcast, %BB_1be0_74b0 ], [ %phi_cast_R2754_bitcast.1, %BB_1be0_74e0 ], [ %phi_cast_R2754_bitcast.2, %BB_1be0_7310 ], [ %phi_cast_R2754_bitcast.2, %BB_1be0_7340 ], [ %phi.117, %BB_1be0_7510 ], [ %phi.117, %BB_1be0_7540 ], [ %phi.117, %BB_1be0_7560 ], [ %phi.117, %BB_1be0_7580 ]
  br label %BB_1c00

BB_1c00:                                          ; preds = %BB_1be0_7590, %BB_1bb0
  %phi.129 = phi float [ %phi.127, %BB_1be0_7590 ], [ %ffma.133, %BB_1bb0 ]
  %phi.130 = phi float [ %phi.128, %BB_1be0_7590 ], [ %phi.117, %BB_1bb0 ]
  br label %BB_1c20

BB_1c20:                                          ; preds = %BB_1c00, %BB_1ac0
  %phi.131 = phi float [ %phi.129, %BB_1c00 ], [ %phi.116, %BB_1ac0 ]
  %phi.132 = phi float [ %phi.130, %BB_1c00 ], [ %phi.117, %BB_1ac0 ]
  %phi.133 = phi i32 [ %.75, %BB_1c00 ], [ %phi.118, %BB_1ac0 ]
  %phi.134 = phi float [ %phi.129, %BB_1c00 ], [ %phi.119, %BB_1ac0 ]
  br label %BB_1c50

BB_1c50:                                          ; preds = %BB_1c20
  %shfl_activemask.38 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.38 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.38, float %phi.134, i32 6, i32 31)
  br label %BB_1c60

BB_1c60:                                          ; preds = %BB_1c50
  %isetrp_cmp1.98 = icmp uge i32 %tid_x, 7
  %isetrp_cmp1.99 = icmp ne i32 %tid_x, 7
  br label %BB_1c90

BB_1c90:                                          ; preds = %BB_1c60
  %160 = zext i1 %isetrp_cmp1.98 to i32
  %161 = icmp ne i32 %160, 0
  br i1 %161, label %BB_80001c90, label %BB_1cb0

BB_80001c90:                                      ; preds = %BB_1c90
  %lds_addr_memaddr_offset_add.42 = add i32 %.88, 792
  %.2657 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.42
  %lds.45 = load volatile float, ptr addrspace(3) %.2657, align 4
  %ffma.143 = call float @llvm.fma.f32(float %shfl_idx.38, float %lds.45, float %phi.120)
  br label %BB_1cb0

BB_1cb0:                                          ; preds = %BB_80001c90, %BB_1c90
  %phi.135 = phi float [ %ffma.143, %BB_80001c90 ], [ %phi.120, %BB_1c90 ]
  %warp_reconv_mask.6 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.6)
  br i1 %isetrp_cmp1.99, label %BB_1e10, label %BB_1cc0

BB_1cc0:                                          ; preds = %BB_1cb0
  %ffma_addend_fneg.7 = fneg float %phi.135
  %ffma.144 = call float @llvm.fma.f32(float %phi.131, float %phi, float %ffma_addend_fneg.7)
  %lds_addr_memaddr_offset_add.43 = add i32 %.75, 952
  %.2667 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.43
  %lds.46 = load volatile float, ptr addrspace(3) %.2667, align 4
  %mufu_rcp.14 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.46)
  %fchk_num_bits.7 = bitcast float %ffma.144 to i32
  %fchk_den_bits.7 = bitcast float %lds.46 to i32
  %fchk_aden.7 = and i32 %fchk_den_bits.7, 2147483647
  %fchk_anum.7 = and i32 %fchk_num_bits.7, 2147483647
  %fchk_den_subz.7 = icmp ult i32 %fchk_aden.7, 8388608
  %fchk_den_infnan.7 = icmp uge i32 %fchk_aden.7, 2139095040
  %fchk_num_infnan.7 = icmp uge i32 %fchk_anum.7, 2139095040
  %fchk_den_bad.7 = or i1 %fchk_den_subz.7, %fchk_den_infnan.7
  %fchk_px.7 = or i1 %fchk_den_bad.7, %fchk_num_infnan.7
  %ffma_lhs_fneg.14 = fneg float %lds.46
  %ffma.145 = call float @llvm.fma.f32(float %ffma_lhs_fneg.14, float %mufu_rcp.14, float 1.000000e+00)
  %ffma.146 = call float @llvm.fma.f32(float %mufu_rcp.14, float %ffma.145, float %mufu_rcp.14)
  %ffma.147 = call float @llvm.fma.f32(float %ffma.144, float %ffma.146, float 0.000000e+00)
  %ffma.148 = call float @llvm.fma.f32(float %ffma_lhs_fneg.14, float %ffma.147, float %ffma.144)
  %ffma.149 = call float @llvm.fma.f32(float %ffma.146, float %ffma.148, float %ffma.147)
  br label %BB_1da0

BB_1da0:                                          ; preds = %BB_1cc0
  %cond_not.65 = xor i1 %fchk_px.7, true
  br i1 %cond_not.65, label %BB_1df0, label %BB_1dd0_6f40

BB_1dd0_6f40:                                     ; preds = %BB_1da0
  %.2671 = zext i32 %fchk_den_bits.7 to i64
  %.2672 = shl i64 %.2671, 32
  %.2673 = lshr i64 %.2672, 23
  %shf_hi.40 = lshr i64 %.2673, 32
  %shf_result.48 = trunc i64 %shf_hi.40 to i32
  %.2675 = zext i32 %fchk_num_bits.7 to i64
  %.2676 = shl i64 %.2675, 32
  %.2677 = lshr i64 %.2676, 23
  %shf_hi.41 = lshr i64 %.2677, 32
  %shf_result.49 = trunc i64 %shf_hi.41 to i32
  %.2681 = and i32 %shf_result.48, 255
  %.2689 = and i32 %shf_result.49, 255
  %iadd3_n1.77 = add i32 %.2681, -1
  %iadd3_n1.78 = add i32 %.2689, -1
  %isetrp_cmp1.100 = icmp ugt i32 %iadd3_n1.77, 253
  %isetrp_cmp1.101 = icmp ugt i32 %iadd3_n1.78, 253
  %isetrp_cmp2.101 = or i1 %isetrp_cmp1.101, %isetrp_cmp1.100
  br label %BB_1dd0_6fd0

BB_1dd0_6fd0:                                     ; preds = %BB_1dd0_6f40
  %cond_not.66 = xor i1 %isetrp_cmp2.101, true
  br i1 %cond_not.66, label %BB_1dd0_80006fd0, label %BB_1dd0_6ff0

BB_1dd0_6ff0:                                     ; preds = %BB_1dd0_6fd0
  %fsetrp_lhs_fabs.35 = call float @llvm.nvvm.fabs.f(float %ffma.144)
  %fsetrp_cmp1.42 = fcmp ugt float %fsetrp_lhs_fabs.35, 0x7FF0000000000000
  %fsetrp_lhs_fabs.36 = call float @llvm.nvvm.fabs.f(float %lds.46)
  %fsetrp_cmp1.43 = fcmp ugt float %fsetrp_lhs_fabs.36, 0x7FF0000000000000
  %lop3_a_cast_zext.28 = zext i1 %fsetrp_cmp1.42 to i32
  %lop3_b_cast_zext.28 = zext i1 %fsetrp_cmp1.43 to i32
  %plop3_a_bit.28 = and i32 %lop3_a_cast_zext.28, 1
  %plop3_b_bit.28 = and i32 %lop3_b_cast_zext.28, 1
  %.2696 = xor i32 %plop3_a_bit.28, 1
  %.2697 = xor i32 %plop3_b_bit.28, 1
  %.2699 = and i32 %.2696, %plop3_b_bit.28
  %.2701 = and i32 %plop3_a_bit.28, %.2697
  %.2703 = or i32 %.2699, %.2701
  %.2704 = and i32 %plop3_a_bit.28, %plop3_b_bit.28
  %.2706 = or i32 %.2703, %.2704
  %lop3_pred_cmp.49 = icmp ne i32 %.2706, 0
  br label %BB_1dd0_7020

BB_1dd0_7020:                                     ; preds = %BB_1dd0_6ff0
  %162 = zext i1 %lop3_pred_cmp.49 to i32
  %163 = icmp ne i32 %162, 0
  br i1 %163, label %BB_1dd0_7580, label %BB_1dd0_7030

BB_1dd0_7030:                                     ; preds = %BB_1dd0_7020
  %.2709 = xor i32 %fchk_den_bits.7, -1
  %.2711 = xor i32 %fchk_num_bits.7, -1
  %.2712 = and i32 %.2709, 2147483647
  %.2713 = and i32 %.2712, %fchk_num_bits.7
  %.2715 = and i32 %fchk_aden.7, %.2711
  %.2716 = or i32 %.2713, %.2715
  %.2718 = and i32 %fchk_aden.7, %fchk_num_bits.7
  %.2719 = or i32 %.2716, %.2718
  %lop3_pred_cmp.50 = icmp ne i32 %.2719, 0
  br label %BB_1dd0_7040

BB_1dd0_7040:                                     ; preds = %BB_1dd0_7030
  %cond_not.67 = xor i1 %lop3_pred_cmp.50, true
  br i1 %cond_not.67, label %BB_1dd0_7560, label %BB_1dd0_7050

BB_1dd0_7050:                                     ; preds = %BB_1dd0_7040
  %fsetrp_cmp1.44 = fcmp une float %fsetrp_lhs_fabs.35, 0x7FF0000000000000
  %fsetrp_cmp1.45 = fcmp une float %fsetrp_lhs_fabs.36, 0x7FF0000000000000
  br label %BB_1dd0_7080

BB_1dd0_7080:                                     ; preds = %BB_1dd0_7050
  %cond_not.68 = xor i1 %fsetrp_cmp1.45, true
  br i1 %cond_not.68, label %BB_1dd0_80007080, label %BB_1dd0_7090

BB_1dd0_80007080:                                 ; preds = %BB_1dd0_7080
  %bra_cond_not.7 = xor i1 %fsetrp_cmp1.44, true
  br i1 %bra_cond_not.7, label %BB_1dd0_7560, label %BB_1dd0_7090

BB_1dd0_7090:                                     ; preds = %BB_1dd0_80007080, %BB_1dd0_7080
  %lop3_pred_cmp.51 = icmp ne i32 %fchk_anum.7, 0
  %lop3_a_cast_zext.29 = zext i1 %fsetrp_cmp1.45 to i32
  %lop3_b_cast_zext.29 = zext i1 %lop3_pred_cmp.51 to i32
  %plop3_a_bit.29 = and i32 %lop3_a_cast_zext.29, 1
  %plop3_b_bit.29 = and i32 %lop3_b_cast_zext.29, 1
  %.2733 = xor i32 %plop3_a_bit.29, 1
  %.2734 = xor i32 %plop3_b_bit.29, 1
  %.2736 = and i32 %.2733, %.2734
  %.2738 = and i32 %.2733, %plop3_b_bit.29
  %.2740 = or i32 %.2736, %.2738
  %.2741 = and i32 %plop3_a_bit.29, %.2734
  %.2743 = or i32 %.2740, %.2741
  %lop3_pred_cmp.52 = icmp ne i32 %.2743, 0
  br label %BB_1dd0_70b0

BB_1dd0_70b0:                                     ; preds = %BB_1dd0_7090
  %164 = zext i1 %lop3_pred_cmp.52 to i32
  %165 = icmp ne i32 %164, 0
  br i1 %165, label %BB_1dd0_7540, label %BB_1dd0_70c0

BB_1dd0_70c0:                                     ; preds = %BB_1dd0_70b0
  %lop3_pred_cmp.53 = icmp ne i32 %fchk_aden.7, 0
  %lop3_a_cast_zext.30 = zext i1 %fsetrp_cmp1.44 to i32
  %lop3_b_cast_zext.30 = zext i1 %lop3_pred_cmp.53 to i32
  %plop3_a_bit.30 = and i32 %lop3_a_cast_zext.30, 1
  %plop3_b_bit.30 = and i32 %lop3_b_cast_zext.30, 1
  %.2754 = xor i32 %plop3_a_bit.30, 1
  %.2755 = xor i32 %plop3_b_bit.30, 1
  %.2757 = and i32 %.2754, %.2755
  %.2759 = and i32 %.2754, %plop3_b_bit.30
  %.2761 = or i32 %.2757, %.2759
  %.2762 = and i32 %plop3_a_bit.30, %.2755
  %.2764 = or i32 %.2761, %.2762
  %lop3_pred_cmp.54 = icmp ne i32 %.2764, 0
  br label %BB_1dd0_70e0

BB_1dd0_70e0:                                     ; preds = %BB_1dd0_70c0
  %166 = zext i1 %lop3_pred_cmp.54 to i32
  %167 = icmp ne i32 %166, 0
  br i1 %167, label %BB_1dd0_7510, label %BB_1dd0_70f0

BB_1dd0_70f0:                                     ; preds = %BB_1dd0_70e0
  %isetrp_cmp1.102 = icmp sge i32 %iadd3_n1.78, 0
  %isetrp_cmp1.103 = icmp sge i32 %iadd3_n1.77, 0
  br label %BB_1dd0_7130

BB_1dd0_7130:                                     ; preds = %BB_1dd0_70f0
  %168 = zext i1 %isetrp_cmp1.102 to i32
  %169 = icmp ne i32 %168, 0
  br i1 %169, label %BB_1dd0_80007130, label %BB_1dd0_7140

BB_1dd0_80007130:                                 ; preds = %BB_1dd0_7130
  br label %BB_1dd0_7140

BB_1dd0_7140:                                     ; preds = %BB_1dd0_80007130, %BB_1dd0_7130
  %phi.136 = phi i32 [ 0, %BB_1dd0_80007130 ], [ %iadd3_n1.77, %BB_1dd0_7130 ]
  %cond_not.69 = xor i1 %isetrp_cmp1.102, true
  br i1 %cond_not.69, label %BB_1dd0_80007140, label %BB_1dd0_7160

BB_1dd0_80007140:                                 ; preds = %BB_1dd0_7140
  %ffma.150 = call float @llvm.fma.f32(float %ffma.144, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2874_bitcast = bitcast float %ffma.150 to i32
  br label %BB_1dd0_7160

BB_1dd0_7160:                                     ; preds = %BB_1dd0_80007140, %BB_1dd0_7140
  %phi.137 = phi i32 [ %phi_cast_R2874_bitcast, %BB_1dd0_80007140 ], [ %fchk_num_bits.7, %BB_1dd0_7140 ]
  %phi.138 = phi i32 [ -64, %BB_1dd0_80007140 ], [ %phi.136, %BB_1dd0_7140 ]
  %cond_not.70 = xor i1 %isetrp_cmp1.103, true
  br i1 %cond_not.70, label %BB_1dd0_80007160, label %BB_1dd0_7180

BB_1dd0_80007160:                                 ; preds = %BB_1dd0_7160
  %ffma.151 = call float @llvm.fma.f32(float %lds.46, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.15 = add i32 %phi.138, 64
  %phi_cast_R448_bitcast = bitcast float %ffma.151 to i32
  br label %BB_1dd0_7180

BB_1dd0_7510:                                     ; preds = %BB_1dd0_70e0
  %.2777 = and i32 %.2709, -2147483648
  %.2778 = and i32 %.2777, %fchk_num_bits.7
  %.2779 = and i32 %fchk_den_bits.7, -2147483648
  %.2780 = and i32 %.2779, %.2711
  %.2781 = or i32 %.2778, %.2780
  %.2782 = xor i32 %.2781, -1
  %.2785 = and i32 %.2782, 2139095040
  %.2792 = or i32 %.2785, %.2781
  %phi_cast_R2879_bitcast = bitcast i32 %.2792 to float
  br label %BB_1dd0_7590

BB_1dd0_7540:                                     ; preds = %BB_1dd0_70b0
  %.2806 = and i32 %.2709, -2147483648
  %.2807 = and i32 %.2806, %fchk_num_bits.7
  %.2808 = and i32 %fchk_den_bits.7, -2147483648
  %.2809 = and i32 %.2808, %.2711
  %.2810 = or i32 %.2807, %.2809
  %phi_cast_R2880_bitcast = bitcast i32 %.2810 to float
  br label %BB_1dd0_7590

BB_1dd0_7560:                                     ; preds = %BB_1dd0_80007080, %BB_1dd0_7040
  %mufu_rsq.7 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1dd0_7590

BB_1dd0_7580:                                     ; preds = %BB_1dd0_7020
  %fadd.14 = fadd float %ffma.144, %lds.46
  br label %BB_1dd0_7590

BB_1dd0_80006fd0:                                 ; preds = %BB_1dd0_6fd0
  br label %BB_1dd0_7180

BB_1dd0_7180:                                     ; preds = %BB_1dd0_80006fd0, %BB_1dd0_80007160, %BB_1dd0_7160
  %phi.139 = phi i32 [ %fchk_den_bits.7, %BB_1dd0_80006fd0 ], [ %phi_cast_R448_bitcast, %BB_1dd0_80007160 ], [ %fchk_den_bits.7, %BB_1dd0_7160 ]
  %phi.140 = phi i32 [ %fchk_num_bits.7, %BB_1dd0_80006fd0 ], [ %phi.137, %BB_1dd0_80007160 ], [ %phi.137, %BB_1dd0_7160 ]
  %phi.141 = phi i32 [ 0, %BB_1dd0_80006fd0 ], [ %viadd.15, %BB_1dd0_80007160 ], [ %phi.138, %BB_1dd0_7160 ]
  %.2815 = zext i32 %.2681 to i64
  %.2818 = shl i64 %.2815, 23
  %.2819 = and i64 %.2818, 4294967295
  %.2820 = add i64 %.2819, 3229614080
  %.2821 = trunc i64 %.2820 to i32
  %iadd3_n1.80 = add i32 %.2689, -127
  %iadd3_o1_not.14 = xor i32 %.2821, -1
  %iadd3_o1_neg.14 = add i32 %iadd3_o1_not.14, 1
  %iadd3_n1.81 = add i32 %iadd3_o1_neg.14, %phi.139
  %imad_tmp.36 = mul i32 %iadd3_n1.80, -8388608
  %imad.47 = add i32 %imad_tmp.36, %phi.140
  %mufu_src_bitcast.7 = bitcast i32 %iadd3_n1.81 to float
  %mufu_rcp.15 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.7)
  %fadd_lhs_fneg.7 = fneg float %mufu_src_bitcast.7
  %fadd.15 = fadd float %fadd_lhs_fneg.7, 0.000000e+00
  %iadd3_o3_not.7 = xor i32 %.2681, -1
  %iadd3_o3_neg.7 = add i32 %iadd3_o3_not.7, 1
  %iadd3_n2.82 = add i32 %.2689, %iadd3_o3_neg.7
  %iadd3_n1.83 = add i32 %iadd3_n2.82, %phi.141
  %ffma.152 = call float @llvm.fma.f32(float %mufu_rcp.15, float %fadd.15, float 1.000000e+00)
  %ffma.153 = call float @llvm.fma.f32(float %mufu_rcp.15, float %ffma.152, float %mufu_rcp.15)
  %ffma_lhs_bitcast.7 = bitcast i32 %imad.47 to float
  %ffma.154 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.7, float %ffma.153, float 0.000000e+00)
  %ffma.155 = call float @llvm.fma.f32(float %fadd.15, float %ffma.154, float %ffma_lhs_bitcast.7)
  %ffma.156 = call float @llvm.fma.f32(float %ffma.153, float %ffma.155, float %ffma.154)
  %ffma.157 = call float @llvm.fma.f32(float %fadd.15, float %ffma.156, float %ffma_lhs_bitcast.7)
  %ffma.158 = call float @llvm.fma.f32(float %ffma.153, float %ffma.157, float %ffma.156)
  %shf_hi_bitcast.23 = bitcast float %ffma.158 to i32
  %.2823 = zext i32 %shf_hi_bitcast.23 to i64
  %.2824 = shl i64 %.2823, 32
  %.2825 = lshr i64 %.2824, 23
  %shf_hi.42 = lshr i64 %.2825, 32
  %shf_result.50 = trunc i64 %shf_hi.42 to i32
  %.2829 = and i32 %shf_result.50, 255
  %imad.48 = add i32 %.2829, %iadd3_n1.83
  %iadd3_n1.84 = add i32 %imad.48, -1
  %isetrp_cmp1.104 = icmp uge i32 %iadd3_n1.84, 254
  br label %BB_1dd0_72d0

BB_1dd0_72d0:                                     ; preds = %BB_1dd0_7180
  %cond_not.71 = xor i1 %isetrp_cmp1.104, true
  br i1 %cond_not.71, label %BB_1dd0_74e0, label %BB_1dd0_72e0

BB_1dd0_72e0:                                     ; preds = %BB_1dd0_72d0
  %isetrp_cmp1.105 = icmp sgt i32 %imad.48, 254
  br label %BB_1dd0_72f0

BB_1dd0_72f0:                                     ; preds = %BB_1dd0_72e0
  %170 = zext i1 %isetrp_cmp1.105 to i32
  %171 = icmp ne i32 %170, 0
  br i1 %171, label %BB_1dd0_74b0, label %BB_1dd0_7300

BB_1dd0_7300:                                     ; preds = %BB_1dd0_72f0
  %isetrp_cmp1.106 = icmp sge i32 %imad.48, 1
  br label %BB_1dd0_7310

BB_1dd0_7310:                                     ; preds = %BB_1dd0_7300
  %phi_cast_R2876_bitcast.2 = bitcast i32 %iadd3_n1.83 to float
  br i1 %isetrp_cmp1.106, label %BB_1dd0_7590, label %BB_1dd0_7320

BB_1dd0_7320:                                     ; preds = %BB_1dd0_7310
  %isetrp_cmp1.107 = icmp sge i32 %imad.48, -24
  %.2843 = and i32 %shf_hi_bitcast.23, -2147483648
  br label %BB_1dd0_7340

BB_1dd0_7340:                                     ; preds = %BB_1dd0_7320
  %cond_not.72 = xor i1 %isetrp_cmp1.107, true
  %phi_cast_R2889_bitcast = bitcast i32 %.2843 to float
  br i1 %cond_not.72, label %BB_1dd0_7590, label %BB_1dd0_7350

BB_1dd0_7350:                                     ; preds = %BB_1dd0_7340
  %ffma_rz.7 = call float @llvm.nvvm.fma.rz.f(float %ffma.153, float %ffma.157, float %ffma.156)
  %iadd3_n1.85 = add i32 %imad.48, 32
  %lop3_a_bitcast.62 = bitcast float %ffma_rz.7 to i32
  %.2853 = and i32 %lop3_a_bitcast.62, 8388607
  %ffma_rp.7 = call float @llvm.nvvm.fma.rp.f(float %ffma.153, float %ffma.157, float %ffma.156)
  %ffma_rm.7 = call float @llvm.nvvm.fma.rm.f(float %ffma.153, float %ffma.157, float %ffma.156)
  %isetrp_cmp1.109 = icmp ne i32 %imad.48, 0
  %.2868 = or i32 8388608, %.2853
  %iadd3_o1_not.15 = xor i32 %imad.48, -1
  %iadd3_o1_neg.15 = add i32 %iadd3_o1_not.15, 1
  %.2878 = zext i32 %.2868 to i64
  %shf_shift_64.51 = zext i32 %iadd3_n1.85 to i64
  %.2881 = shl i64 %.2878, %shf_shift_64.51
  %shf_result.51 = trunc i64 %.2881 to i32
  %fsetrp_cmp1.47 = fcmp une float %ffma_rp.7, %ffma_rm.7
  %isetrp_cmp1.110 = icmp ne i32 %shf_result.51, 0
  %isetrp_cmp2.110 = and i1 %isetrp_cmp1.110, %isetrp_cmp1.109
  %.2884 = shl i64 %.2878, 32
  %shf_shift_64.52 = zext i32 %iadd3_o1_neg.15 to i64
  %.2885 = lshr i64 %.2884, %shf_shift_64.52
  %shf_hi.43 = lshr i64 %.2885, 32
  %shf_result.52 = trunc i64 %shf_hi.43 to i32
  %lop3_a_cast_zext.31 = zext i1 %fsetrp_cmp1.47 to i32
  %lop3_b_cast_zext.31 = zext i1 %isetrp_cmp2.110 to i32
  %plop3_a_bit.31 = and i32 %lop3_a_cast_zext.31, 1
  %plop3_b_bit.31 = and i32 %lop3_b_cast_zext.31, 1
  %.2886 = xor i32 %plop3_a_bit.31, 1
  %.2887 = xor i32 %plop3_b_bit.31, 1
  %.2889 = and i32 %.2886, %plop3_b_bit.31
  %.2891 = and i32 %plop3_a_bit.31, %.2887
  %.2893 = or i32 %.2889, %.2891
  %.2894 = and i32 %plop3_a_bit.31, %plop3_b_bit.31
  %.2896 = or i32 %.2893, %.2894
  %lop3_pred_cmp.55 = icmp ne i32 %.2896, 0
  %.2898 = zext i32 %shf_result.52 to i64
  %.2899 = shl i64 %.2898, 32
  %.2900 = lshr i64 %.2899, 1
  %shf_hi.44 = lshr i64 %.2900, 32
  %shf_result.53 = trunc i64 %shf_hi.44 to i32
  %sel_pred_not.7 = xor i1 %lop3_pred_cmp.55, true
  %sel.15 = select i1 %sel_pred_not.7, i32 0, i32 1
  %.2901 = xor i32 %sel.15, -1
  %.2903 = xor i32 %shf_result.53, -1
  %.2904 = and i32 %.2901, 1
  %.2905 = and i32 %.2904, %shf_result.53
  %.2913 = and i32 %sel.15, %.2903
  %.2914 = or i32 %.2905, %.2913
  %.2916 = and i32 %sel.15, %shf_result.53
  %.2917 = or i32 %.2914, %.2916
  %.2921 = and i32 %.2917, %shf_result.52
  %imad.49 = add i32 %shf_result.53, %.2921
  %.2926 = xor i32 %imad.49, -1
  %.2927 = xor i32 %.2843, -1
  %.2929 = and i32 %.2926, %.2843
  %.2934 = and i32 %imad.49, %.2927
  %.2936 = or i32 %.2929, %.2934
  %.2940 = and i32 %imad.49, %.2843
  %.2942 = or i32 %.2936, %.2940
  %phi_cast_R2890_bitcast = bitcast i32 %.2942 to float
  %phi_cast_R2898_bitcast = bitcast i32 %.2868 to float
  br label %BB_1dd0_7590

BB_1dd0_74b0:                                     ; preds = %BB_1dd0_72f0
  %.2950 = and i32 %shf_hi_bitcast.23, -2147483648
  %.2965 = or i32 2139095040, %.2950
  %phi_cast_R2893_bitcast = bitcast i32 %.2965 to float
  %phi_cast_R2876_bitcast = bitcast i32 %iadd3_n1.83 to float
  br label %BB_1dd0_7590

BB_1dd0_74e0:                                     ; preds = %BB_1dd0_72d0
  %.2976 = zext i32 %iadd3_n1.83 to i64
  %.2979 = shl i64 %.2976, 23
  %.2980 = and i64 %.2979, 4294967295
  %.2981 = add i64 %.2980, %.2823
  %.2982 = trunc i64 %.2981 to i32
  %phi_cast_R2895_bitcast = bitcast i32 %.2982 to float
  %phi_cast_R2876_bitcast.1 = bitcast i32 %iadd3_n1.83 to float
  br label %BB_1dd0_7590

BB_1dd0_7590:                                     ; preds = %BB_1dd0_74e0, %BB_1dd0_74b0, %BB_1dd0_7350, %BB_1dd0_7340, %BB_1dd0_7310, %BB_1dd0_7580, %BB_1dd0_7560, %BB_1dd0_7540, %BB_1dd0_7510
  %phi.142 = phi float [ %phi_cast_R2890_bitcast, %BB_1dd0_7350 ], [ %phi_cast_R2893_bitcast, %BB_1dd0_74b0 ], [ %phi_cast_R2895_bitcast, %BB_1dd0_74e0 ], [ %ffma.158, %BB_1dd0_7310 ], [ %phi_cast_R2889_bitcast, %BB_1dd0_7340 ], [ %phi_cast_R2879_bitcast, %BB_1dd0_7510 ], [ %phi_cast_R2880_bitcast, %BB_1dd0_7540 ], [ %mufu_rsq.7, %BB_1dd0_7560 ], [ %fadd.14, %BB_1dd0_7580 ]
  %phi.143 = phi float [ %phi_cast_R2898_bitcast, %BB_1dd0_7350 ], [ %phi_cast_R2876_bitcast, %BB_1dd0_74b0 ], [ %phi_cast_R2876_bitcast.1, %BB_1dd0_74e0 ], [ %phi_cast_R2876_bitcast.2, %BB_1dd0_7310 ], [ %phi_cast_R2876_bitcast.2, %BB_1dd0_7340 ], [ %phi.132, %BB_1dd0_7510 ], [ %phi.132, %BB_1dd0_7540 ], [ %phi.132, %BB_1dd0_7560 ], [ %phi.132, %BB_1dd0_7580 ]
  br label %BB_1df0

BB_1df0:                                          ; preds = %BB_1dd0_7590, %BB_1da0
  %phi.144 = phi float [ %phi.142, %BB_1dd0_7590 ], [ %ffma.149, %BB_1da0 ]
  %phi.145 = phi float [ %phi.143, %BB_1dd0_7590 ], [ %phi.132, %BB_1da0 ]
  br label %BB_1e10

BB_1e10:                                          ; preds = %BB_1df0, %BB_1cb0
  %phi.146 = phi float [ %phi.144, %BB_1df0 ], [ %phi.131, %BB_1cb0 ]
  %phi.147 = phi float [ %phi.145, %BB_1df0 ], [ %phi.132, %BB_1cb0 ]
  %phi.148 = phi i32 [ %.75, %BB_1df0 ], [ %phi.133, %BB_1cb0 ]
  %phi.149 = phi float [ %phi.144, %BB_1df0 ], [ %phi.134, %BB_1cb0 ]
  br label %BB_1e40

BB_1e40:                                          ; preds = %BB_1e10
  %shfl_activemask.39 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.39 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.39, float %phi.149, i32 7, i32 31)
  br label %BB_1e50

BB_1e50:                                          ; preds = %BB_1e40
  %isetrp_cmp1.111 = icmp uge i32 %tid_x, 8
  %isetrp_cmp1.112 = icmp ne i32 %tid_x, 8
  br label %BB_1e80

BB_1e80:                                          ; preds = %BB_1e50
  %172 = zext i1 %isetrp_cmp1.111 to i32
  %173 = icmp ne i32 %172, 0
  br i1 %173, label %BB_80001e80, label %BB_1ea0

BB_80001e80:                                      ; preds = %BB_1e80
  %lds_addr_memaddr_offset_add.44 = add i32 %.88, 924
  %.2990 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.44
  %lds.47 = load volatile float, ptr addrspace(3) %.2990, align 4
  %ffma.159 = call float @llvm.fma.f32(float %shfl_idx.39, float %lds.47, float %phi.135)
  br label %BB_1ea0

BB_1ea0:                                          ; preds = %BB_80001e80, %BB_1e80
  %phi.150 = phi float [ %ffma.159, %BB_80001e80 ], [ %phi.135, %BB_1e80 ]
  %warp_reconv_mask.7 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.7)
  br i1 %isetrp_cmp1.112, label %BB_2000, label %BB_1eb0

BB_1eb0:                                          ; preds = %BB_1ea0
  %ffma_addend_fneg.8 = fneg float %phi.150
  %ffma.160 = call float @llvm.fma.f32(float %phi.146, float %phi, float %ffma_addend_fneg.8)
  %lds_addr_memaddr_offset_add.45 = add i32 %.75, 1088
  %.3000 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.45
  %lds.48 = load volatile float, ptr addrspace(3) %.3000, align 4
  %mufu_rcp.16 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.48)
  %fchk_num_bits.8 = bitcast float %ffma.160 to i32
  %fchk_den_bits.8 = bitcast float %lds.48 to i32
  %fchk_aden.8 = and i32 %fchk_den_bits.8, 2147483647
  %fchk_anum.8 = and i32 %fchk_num_bits.8, 2147483647
  %fchk_den_subz.8 = icmp ult i32 %fchk_aden.8, 8388608
  %fchk_den_infnan.8 = icmp uge i32 %fchk_aden.8, 2139095040
  %fchk_num_infnan.8 = icmp uge i32 %fchk_anum.8, 2139095040
  %fchk_den_bad.8 = or i1 %fchk_den_subz.8, %fchk_den_infnan.8
  %fchk_px.8 = or i1 %fchk_den_bad.8, %fchk_num_infnan.8
  %ffma_lhs_fneg.16 = fneg float %lds.48
  %ffma.161 = call float @llvm.fma.f32(float %ffma_lhs_fneg.16, float %mufu_rcp.16, float 1.000000e+00)
  %ffma.162 = call float @llvm.fma.f32(float %mufu_rcp.16, float %ffma.161, float %mufu_rcp.16)
  %ffma.163 = call float @llvm.fma.f32(float %ffma.160, float %ffma.162, float 0.000000e+00)
  %ffma.164 = call float @llvm.fma.f32(float %ffma_lhs_fneg.16, float %ffma.163, float %ffma.160)
  %ffma.165 = call float @llvm.fma.f32(float %ffma.162, float %ffma.164, float %ffma.163)
  br label %BB_1f90

BB_1f90:                                          ; preds = %BB_1eb0
  %cond_not.73 = xor i1 %fchk_px.8, true
  br i1 %cond_not.73, label %BB_1fe0, label %BB_1fc0_6f40

BB_1fc0_6f40:                                     ; preds = %BB_1f90
  %.3004 = zext i32 %fchk_den_bits.8 to i64
  %.3005 = shl i64 %.3004, 32
  %.3006 = lshr i64 %.3005, 23
  %shf_hi.45 = lshr i64 %.3006, 32
  %shf_result.54 = trunc i64 %shf_hi.45 to i32
  %.3008 = zext i32 %fchk_num_bits.8 to i64
  %.3009 = shl i64 %.3008, 32
  %.3010 = lshr i64 %.3009, 23
  %shf_hi.46 = lshr i64 %.3010, 32
  %shf_result.55 = trunc i64 %shf_hi.46 to i32
  %.3014 = and i32 %shf_result.54, 255
  %.3022 = and i32 %shf_result.55, 255
  %iadd3_n1.87 = add i32 %.3014, -1
  %iadd3_n1.88 = add i32 %.3022, -1
  %isetrp_cmp1.113 = icmp ugt i32 %iadd3_n1.87, 253
  %isetrp_cmp1.114 = icmp ugt i32 %iadd3_n1.88, 253
  %isetrp_cmp2.114 = or i1 %isetrp_cmp1.114, %isetrp_cmp1.113
  br label %BB_1fc0_6fd0

BB_1fc0_6fd0:                                     ; preds = %BB_1fc0_6f40
  %cond_not.74 = xor i1 %isetrp_cmp2.114, true
  br i1 %cond_not.74, label %BB_1fc0_80006fd0, label %BB_1fc0_6ff0

BB_1fc0_6ff0:                                     ; preds = %BB_1fc0_6fd0
  %fsetrp_lhs_fabs.40 = call float @llvm.nvvm.fabs.f(float %ffma.160)
  %fsetrp_cmp1.48 = fcmp ugt float %fsetrp_lhs_fabs.40, 0x7FF0000000000000
  %fsetrp_lhs_fabs.41 = call float @llvm.nvvm.fabs.f(float %lds.48)
  %fsetrp_cmp1.49 = fcmp ugt float %fsetrp_lhs_fabs.41, 0x7FF0000000000000
  %lop3_a_cast_zext.32 = zext i1 %fsetrp_cmp1.48 to i32
  %lop3_b_cast_zext.32 = zext i1 %fsetrp_cmp1.49 to i32
  %plop3_a_bit.32 = and i32 %lop3_a_cast_zext.32, 1
  %plop3_b_bit.32 = and i32 %lop3_b_cast_zext.32, 1
  %.3029 = xor i32 %plop3_a_bit.32, 1
  %.3030 = xor i32 %plop3_b_bit.32, 1
  %.3032 = and i32 %.3029, %plop3_b_bit.32
  %.3034 = and i32 %plop3_a_bit.32, %.3030
  %.3036 = or i32 %.3032, %.3034
  %.3037 = and i32 %plop3_a_bit.32, %plop3_b_bit.32
  %.3039 = or i32 %.3036, %.3037
  %lop3_pred_cmp.56 = icmp ne i32 %.3039, 0
  br label %BB_1fc0_7020

BB_1fc0_7020:                                     ; preds = %BB_1fc0_6ff0
  %174 = zext i1 %lop3_pred_cmp.56 to i32
  %175 = icmp ne i32 %174, 0
  br i1 %175, label %BB_1fc0_7580, label %BB_1fc0_7030

BB_1fc0_7030:                                     ; preds = %BB_1fc0_7020
  %.3042 = xor i32 %fchk_den_bits.8, -1
  %.3044 = xor i32 %fchk_num_bits.8, -1
  %.3045 = and i32 %.3042, 2147483647
  %.3046 = and i32 %.3045, %fchk_num_bits.8
  %.3048 = and i32 %fchk_aden.8, %.3044
  %.3049 = or i32 %.3046, %.3048
  %.3051 = and i32 %fchk_aden.8, %fchk_num_bits.8
  %.3052 = or i32 %.3049, %.3051
  %lop3_pred_cmp.57 = icmp ne i32 %.3052, 0
  br label %BB_1fc0_7040

BB_1fc0_7040:                                     ; preds = %BB_1fc0_7030
  %cond_not.75 = xor i1 %lop3_pred_cmp.57, true
  br i1 %cond_not.75, label %BB_1fc0_7560, label %BB_1fc0_7050

BB_1fc0_7050:                                     ; preds = %BB_1fc0_7040
  %fsetrp_cmp1.50 = fcmp une float %fsetrp_lhs_fabs.40, 0x7FF0000000000000
  %fsetrp_cmp1.51 = fcmp une float %fsetrp_lhs_fabs.41, 0x7FF0000000000000
  br label %BB_1fc0_7080

BB_1fc0_7080:                                     ; preds = %BB_1fc0_7050
  %cond_not.76 = xor i1 %fsetrp_cmp1.51, true
  br i1 %cond_not.76, label %BB_1fc0_80007080, label %BB_1fc0_7090

BB_1fc0_80007080:                                 ; preds = %BB_1fc0_7080
  %bra_cond_not.8 = xor i1 %fsetrp_cmp1.50, true
  br i1 %bra_cond_not.8, label %BB_1fc0_7560, label %BB_1fc0_7090

BB_1fc0_7090:                                     ; preds = %BB_1fc0_80007080, %BB_1fc0_7080
  %lop3_pred_cmp.58 = icmp ne i32 %fchk_anum.8, 0
  %lop3_a_cast_zext.33 = zext i1 %fsetrp_cmp1.51 to i32
  %lop3_b_cast_zext.33 = zext i1 %lop3_pred_cmp.58 to i32
  %plop3_a_bit.33 = and i32 %lop3_a_cast_zext.33, 1
  %plop3_b_bit.33 = and i32 %lop3_b_cast_zext.33, 1
  %.3066 = xor i32 %plop3_a_bit.33, 1
  %.3067 = xor i32 %plop3_b_bit.33, 1
  %.3069 = and i32 %.3066, %.3067
  %.3071 = and i32 %.3066, %plop3_b_bit.33
  %.3073 = or i32 %.3069, %.3071
  %.3074 = and i32 %plop3_a_bit.33, %.3067
  %.3076 = or i32 %.3073, %.3074
  %lop3_pred_cmp.59 = icmp ne i32 %.3076, 0
  br label %BB_1fc0_70b0

BB_1fc0_70b0:                                     ; preds = %BB_1fc0_7090
  %176 = zext i1 %lop3_pred_cmp.59 to i32
  %177 = icmp ne i32 %176, 0
  br i1 %177, label %BB_1fc0_7540, label %BB_1fc0_70c0

BB_1fc0_70c0:                                     ; preds = %BB_1fc0_70b0
  %lop3_pred_cmp.60 = icmp ne i32 %fchk_aden.8, 0
  %lop3_a_cast_zext.34 = zext i1 %fsetrp_cmp1.50 to i32
  %lop3_b_cast_zext.34 = zext i1 %lop3_pred_cmp.60 to i32
  %plop3_a_bit.34 = and i32 %lop3_a_cast_zext.34, 1
  %plop3_b_bit.34 = and i32 %lop3_b_cast_zext.34, 1
  %.3087 = xor i32 %plop3_a_bit.34, 1
  %.3088 = xor i32 %plop3_b_bit.34, 1
  %.3090 = and i32 %.3087, %.3088
  %.3092 = and i32 %.3087, %plop3_b_bit.34
  %.3094 = or i32 %.3090, %.3092
  %.3095 = and i32 %plop3_a_bit.34, %.3088
  %.3097 = or i32 %.3094, %.3095
  %lop3_pred_cmp.61 = icmp ne i32 %.3097, 0
  br label %BB_1fc0_70e0

BB_1fc0_70e0:                                     ; preds = %BB_1fc0_70c0
  %178 = zext i1 %lop3_pred_cmp.61 to i32
  %179 = icmp ne i32 %178, 0
  br i1 %179, label %BB_1fc0_7510, label %BB_1fc0_70f0

BB_1fc0_70f0:                                     ; preds = %BB_1fc0_70e0
  %isetrp_cmp1.115 = icmp sge i32 %iadd3_n1.88, 0
  %isetrp_cmp1.116 = icmp sge i32 %iadd3_n1.87, 0
  br label %BB_1fc0_7130

BB_1fc0_7130:                                     ; preds = %BB_1fc0_70f0
  %180 = zext i1 %isetrp_cmp1.115 to i32
  %181 = icmp ne i32 %180, 0
  br i1 %181, label %BB_1fc0_80007130, label %BB_1fc0_7140

BB_1fc0_80007130:                                 ; preds = %BB_1fc0_7130
  br label %BB_1fc0_7140

BB_1fc0_7140:                                     ; preds = %BB_1fc0_80007130, %BB_1fc0_7130
  %phi.151 = phi i32 [ 0, %BB_1fc0_80007130 ], [ %iadd3_n1.87, %BB_1fc0_7130 ]
  %cond_not.77 = xor i1 %isetrp_cmp1.115, true
  br i1 %cond_not.77, label %BB_1fc0_80007140, label %BB_1fc0_7160

BB_1fc0_80007140:                                 ; preds = %BB_1fc0_7140
  %ffma.166 = call float @llvm.fma.f32(float %ffma.160, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2899_bitcast = bitcast float %ffma.166 to i32
  br label %BB_1fc0_7160

BB_1fc0_7160:                                     ; preds = %BB_1fc0_80007140, %BB_1fc0_7140
  %phi.152 = phi i32 [ %phi_cast_R2899_bitcast, %BB_1fc0_80007140 ], [ %fchk_num_bits.8, %BB_1fc0_7140 ]
  %phi.153 = phi i32 [ -64, %BB_1fc0_80007140 ], [ %phi.151, %BB_1fc0_7140 ]
  %cond_not.78 = xor i1 %isetrp_cmp1.116, true
  br i1 %cond_not.78, label %BB_1fc0_80007160, label %BB_1fc0_7180

BB_1fc0_80007160:                                 ; preds = %BB_1fc0_7160
  %ffma.167 = call float @llvm.fma.f32(float %lds.48, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.17 = add i32 %phi.153, 64
  %phi_cast_R464_bitcast = bitcast float %ffma.167 to i32
  br label %BB_1fc0_7180

BB_1fc0_7510:                                     ; preds = %BB_1fc0_70e0
  %.3110 = and i32 %.3042, -2147483648
  %.3111 = and i32 %.3110, %fchk_num_bits.8
  %.3112 = and i32 %fchk_den_bits.8, -2147483648
  %.3113 = and i32 %.3112, %.3044
  %.3114 = or i32 %.3111, %.3113
  %.3115 = xor i32 %.3114, -1
  %.3118 = and i32 %.3115, 2139095040
  %.3125 = or i32 %.3118, %.3114
  %phi_cast_R2902_bitcast = bitcast i32 %.3125 to float
  br label %BB_1fc0_7590

BB_1fc0_7540:                                     ; preds = %BB_1fc0_70b0
  %.3139 = and i32 %.3042, -2147483648
  %.3140 = and i32 %.3139, %fchk_num_bits.8
  %.3141 = and i32 %fchk_den_bits.8, -2147483648
  %.3142 = and i32 %.3141, %.3044
  %.3143 = or i32 %.3140, %.3142
  %phi_cast_R2905_bitcast = bitcast i32 %.3143 to float
  br label %BB_1fc0_7590

BB_1fc0_7560:                                     ; preds = %BB_1fc0_80007080, %BB_1fc0_7040
  %mufu_rsq.8 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_1fc0_7590

BB_1fc0_7580:                                     ; preds = %BB_1fc0_7020
  %fadd.16 = fadd float %ffma.160, %lds.48
  br label %BB_1fc0_7590

BB_1fc0_80006fd0:                                 ; preds = %BB_1fc0_6fd0
  br label %BB_1fc0_7180

BB_1fc0_7180:                                     ; preds = %BB_1fc0_80006fd0, %BB_1fc0_80007160, %BB_1fc0_7160
  %phi.154 = phi i32 [ %fchk_den_bits.8, %BB_1fc0_80006fd0 ], [ %phi_cast_R464_bitcast, %BB_1fc0_80007160 ], [ %fchk_den_bits.8, %BB_1fc0_7160 ]
  %phi.155 = phi i32 [ %fchk_num_bits.8, %BB_1fc0_80006fd0 ], [ %phi.152, %BB_1fc0_80007160 ], [ %phi.152, %BB_1fc0_7160 ]
  %phi.156 = phi i32 [ 0, %BB_1fc0_80006fd0 ], [ %viadd.17, %BB_1fc0_80007160 ], [ %phi.153, %BB_1fc0_7160 ]
  %.3148 = zext i32 %.3014 to i64
  %.3151 = shl i64 %.3148, 23
  %.3152 = and i64 %.3151, 4294967295
  %.3153 = add i64 %.3152, 3229614080
  %.3154 = trunc i64 %.3153 to i32
  %iadd3_n1.90 = add i32 %.3022, -127
  %iadd3_o1_not.16 = xor i32 %.3154, -1
  %iadd3_o1_neg.16 = add i32 %iadd3_o1_not.16, 1
  %iadd3_n1.91 = add i32 %iadd3_o1_neg.16, %phi.154
  %imad_tmp.39 = mul i32 %iadd3_n1.90, -8388608
  %imad.50 = add i32 %imad_tmp.39, %phi.155
  %mufu_src_bitcast.8 = bitcast i32 %iadd3_n1.91 to float
  %mufu_rcp.17 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.8)
  %fadd_lhs_fneg.8 = fneg float %mufu_src_bitcast.8
  %fadd.17 = fadd float %fadd_lhs_fneg.8, 0.000000e+00
  %iadd3_o3_not.8 = xor i32 %.3014, -1
  %iadd3_o3_neg.8 = add i32 %iadd3_o3_not.8, 1
  %iadd3_n2.92 = add i32 %.3022, %iadd3_o3_neg.8
  %iadd3_n1.93 = add i32 %iadd3_n2.92, %phi.156
  %ffma.168 = call float @llvm.fma.f32(float %mufu_rcp.17, float %fadd.17, float 1.000000e+00)
  %ffma.169 = call float @llvm.fma.f32(float %mufu_rcp.17, float %ffma.168, float %mufu_rcp.17)
  %ffma_lhs_bitcast.8 = bitcast i32 %imad.50 to float
  %ffma.170 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.8, float %ffma.169, float 0.000000e+00)
  %ffma.171 = call float @llvm.fma.f32(float %fadd.17, float %ffma.170, float %ffma_lhs_bitcast.8)
  %ffma.172 = call float @llvm.fma.f32(float %ffma.169, float %ffma.171, float %ffma.170)
  %ffma.173 = call float @llvm.fma.f32(float %fadd.17, float %ffma.172, float %ffma_lhs_bitcast.8)
  %ffma.174 = call float @llvm.fma.f32(float %ffma.169, float %ffma.173, float %ffma.172)
  %shf_hi_bitcast.26 = bitcast float %ffma.174 to i32
  %.3156 = zext i32 %shf_hi_bitcast.26 to i64
  %.3157 = shl i64 %.3156, 32
  %.3158 = lshr i64 %.3157, 23
  %shf_hi.47 = lshr i64 %.3158, 32
  %shf_result.56 = trunc i64 %shf_hi.47 to i32
  %.3162 = and i32 %shf_result.56, 255
  %imad.51 = add i32 %.3162, %iadd3_n1.93
  %iadd3_n1.94 = add i32 %imad.51, -1
  %isetrp_cmp1.117 = icmp uge i32 %iadd3_n1.94, 254
  br label %BB_1fc0_72d0

BB_1fc0_72d0:                                     ; preds = %BB_1fc0_7180
  %cond_not.79 = xor i1 %isetrp_cmp1.117, true
  br i1 %cond_not.79, label %BB_1fc0_74e0, label %BB_1fc0_72e0

BB_1fc0_72e0:                                     ; preds = %BB_1fc0_72d0
  %isetrp_cmp1.118 = icmp sgt i32 %imad.51, 254
  br label %BB_1fc0_72f0

BB_1fc0_72f0:                                     ; preds = %BB_1fc0_72e0
  %182 = zext i1 %isetrp_cmp1.118 to i32
  %183 = icmp ne i32 %182, 0
  br i1 %183, label %BB_1fc0_74b0, label %BB_1fc0_7300

BB_1fc0_7300:                                     ; preds = %BB_1fc0_72f0
  %isetrp_cmp1.119 = icmp sge i32 %imad.51, 1
  br label %BB_1fc0_7310

BB_1fc0_7310:                                     ; preds = %BB_1fc0_7300
  %phi_cast_R2998_bitcast.2 = bitcast i32 %iadd3_n1.93 to float
  br i1 %isetrp_cmp1.119, label %BB_1fc0_7590, label %BB_1fc0_7320

BB_1fc0_7320:                                     ; preds = %BB_1fc0_7310
  %isetrp_cmp1.120 = icmp sge i32 %imad.51, -24
  %.3176 = and i32 %shf_hi_bitcast.26, -2147483648
  br label %BB_1fc0_7340

BB_1fc0_7340:                                     ; preds = %BB_1fc0_7320
  %cond_not.80 = xor i1 %isetrp_cmp1.120, true
  %phi_cast_R2912_bitcast = bitcast i32 %.3176 to float
  br i1 %cond_not.80, label %BB_1fc0_7590, label %BB_1fc0_7350

BB_1fc0_7350:                                     ; preds = %BB_1fc0_7340
  %ffma_rz.8 = call float @llvm.nvvm.fma.rz.f(float %ffma.169, float %ffma.173, float %ffma.172)
  %iadd3_n1.95 = add i32 %imad.51, 32
  %lop3_a_bitcast.70 = bitcast float %ffma_rz.8 to i32
  %.3186 = and i32 %lop3_a_bitcast.70, 8388607
  %ffma_rp.8 = call float @llvm.nvvm.fma.rp.f(float %ffma.169, float %ffma.173, float %ffma.172)
  %ffma_rm.8 = call float @llvm.nvvm.fma.rm.f(float %ffma.169, float %ffma.173, float %ffma.172)
  %isetrp_cmp1.122 = icmp ne i32 %imad.51, 0
  %.3201 = or i32 8388608, %.3186
  %iadd3_o1_not.17 = xor i32 %imad.51, -1
  %iadd3_o1_neg.17 = add i32 %iadd3_o1_not.17, 1
  %.3211 = zext i32 %.3201 to i64
  %shf_shift_64.57 = zext i32 %iadd3_n1.95 to i64
  %.3214 = shl i64 %.3211, %shf_shift_64.57
  %shf_result.57 = trunc i64 %.3214 to i32
  %fsetrp_cmp1.53 = fcmp une float %ffma_rp.8, %ffma_rm.8
  %isetrp_cmp1.123 = icmp ne i32 %shf_result.57, 0
  %isetrp_cmp2.123 = and i1 %isetrp_cmp1.123, %isetrp_cmp1.122
  %.3217 = shl i64 %.3211, 32
  %shf_shift_64.58 = zext i32 %iadd3_o1_neg.17 to i64
  %.3218 = lshr i64 %.3217, %shf_shift_64.58
  %shf_hi.48 = lshr i64 %.3218, 32
  %shf_result.58 = trunc i64 %shf_hi.48 to i32
  %lop3_a_cast_zext.35 = zext i1 %fsetrp_cmp1.53 to i32
  %lop3_b_cast_zext.35 = zext i1 %isetrp_cmp2.123 to i32
  %plop3_a_bit.35 = and i32 %lop3_a_cast_zext.35, 1
  %plop3_b_bit.35 = and i32 %lop3_b_cast_zext.35, 1
  %.3219 = xor i32 %plop3_a_bit.35, 1
  %.3220 = xor i32 %plop3_b_bit.35, 1
  %.3222 = and i32 %.3219, %plop3_b_bit.35
  %.3224 = and i32 %plop3_a_bit.35, %.3220
  %.3226 = or i32 %.3222, %.3224
  %.3227 = and i32 %plop3_a_bit.35, %plop3_b_bit.35
  %.3229 = or i32 %.3226, %.3227
  %lop3_pred_cmp.62 = icmp ne i32 %.3229, 0
  %.3231 = zext i32 %shf_result.58 to i64
  %.3232 = shl i64 %.3231, 32
  %.3233 = lshr i64 %.3232, 1
  %shf_hi.49 = lshr i64 %.3233, 32
  %shf_result.59 = trunc i64 %shf_hi.49 to i32
  %sel_pred_not.8 = xor i1 %lop3_pred_cmp.62, true
  %sel.17 = select i1 %sel_pred_not.8, i32 0, i32 1
  %.3234 = xor i32 %sel.17, -1
  %.3236 = xor i32 %shf_result.59, -1
  %.3237 = and i32 %.3234, 1
  %.3238 = and i32 %.3237, %shf_result.59
  %.3246 = and i32 %sel.17, %.3236
  %.3247 = or i32 %.3238, %.3246
  %.3249 = and i32 %sel.17, %shf_result.59
  %.3250 = or i32 %.3247, %.3249
  %.3254 = and i32 %.3250, %shf_result.58
  %imad.52 = add i32 %shf_result.59, %.3254
  %.3259 = xor i32 %imad.52, -1
  %.3260 = xor i32 %.3176, -1
  %.3262 = and i32 %.3259, %.3176
  %.3267 = and i32 %imad.52, %.3260
  %.3269 = or i32 %.3262, %.3267
  %.3273 = and i32 %imad.52, %.3176
  %.3275 = or i32 %.3269, %.3273
  %phi_cast_R2913_bitcast = bitcast i32 %.3275 to float
  %phi_cast_R3020_bitcast = bitcast i32 %.3201 to float
  br label %BB_1fc0_7590

BB_1fc0_74b0:                                     ; preds = %BB_1fc0_72f0
  %.3283 = and i32 %shf_hi_bitcast.26, -2147483648
  %.3298 = or i32 2139095040, %.3283
  %phi_cast_R2915_bitcast = bitcast i32 %.3298 to float
  %phi_cast_R2998_bitcast = bitcast i32 %iadd3_n1.93 to float
  br label %BB_1fc0_7590

BB_1fc0_74e0:                                     ; preds = %BB_1fc0_72d0
  %.3309 = zext i32 %iadd3_n1.93 to i64
  %.3312 = shl i64 %.3309, 23
  %.3313 = and i64 %.3312, 4294967295
  %.3314 = add i64 %.3313, %.3156
  %.3315 = trunc i64 %.3314 to i32
  %phi_cast_R2918_bitcast = bitcast i32 %.3315 to float
  %phi_cast_R2998_bitcast.1 = bitcast i32 %iadd3_n1.93 to float
  br label %BB_1fc0_7590

BB_1fc0_7590:                                     ; preds = %BB_1fc0_74e0, %BB_1fc0_74b0, %BB_1fc0_7350, %BB_1fc0_7340, %BB_1fc0_7310, %BB_1fc0_7580, %BB_1fc0_7560, %BB_1fc0_7540, %BB_1fc0_7510
  %phi.157 = phi float [ %phi_cast_R2913_bitcast, %BB_1fc0_7350 ], [ %phi_cast_R2915_bitcast, %BB_1fc0_74b0 ], [ %phi_cast_R2918_bitcast, %BB_1fc0_74e0 ], [ %ffma.174, %BB_1fc0_7310 ], [ %phi_cast_R2912_bitcast, %BB_1fc0_7340 ], [ %phi_cast_R2902_bitcast, %BB_1fc0_7510 ], [ %phi_cast_R2905_bitcast, %BB_1fc0_7540 ], [ %mufu_rsq.8, %BB_1fc0_7560 ], [ %fadd.16, %BB_1fc0_7580 ]
  %phi.158 = phi float [ %phi_cast_R3020_bitcast, %BB_1fc0_7350 ], [ %phi_cast_R2998_bitcast, %BB_1fc0_74b0 ], [ %phi_cast_R2998_bitcast.1, %BB_1fc0_74e0 ], [ %phi_cast_R2998_bitcast.2, %BB_1fc0_7310 ], [ %phi_cast_R2998_bitcast.2, %BB_1fc0_7340 ], [ %phi.147, %BB_1fc0_7510 ], [ %phi.147, %BB_1fc0_7540 ], [ %phi.147, %BB_1fc0_7560 ], [ %phi.147, %BB_1fc0_7580 ]
  br label %BB_1fe0

BB_1fe0:                                          ; preds = %BB_1fc0_7590, %BB_1f90
  %phi.159 = phi float [ %phi.157, %BB_1fc0_7590 ], [ %ffma.165, %BB_1f90 ]
  %phi.160 = phi float [ %phi.158, %BB_1fc0_7590 ], [ %phi.147, %BB_1f90 ]
  br label %BB_2000

BB_2000:                                          ; preds = %BB_1fe0, %BB_1ea0
  %phi.161 = phi float [ %phi.159, %BB_1fe0 ], [ %phi.146, %BB_1ea0 ]
  %phi.162 = phi float [ %phi.160, %BB_1fe0 ], [ %phi.147, %BB_1ea0 ]
  %phi.163 = phi i32 [ %.75, %BB_1fe0 ], [ %phi.148, %BB_1ea0 ]
  %phi.164 = phi float [ %phi.159, %BB_1fe0 ], [ %phi.149, %BB_1ea0 ]
  br label %BB_2030

BB_2030:                                          ; preds = %BB_2000
  %shfl_activemask.40 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.40 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.40, float %phi.164, i32 8, i32 31)
  br label %BB_2040

BB_2040:                                          ; preds = %BB_2030
  %isetrp_cmp1.124 = icmp uge i32 %tid_x, 9
  %isetrp_cmp1.125 = icmp ne i32 %tid_x, 9
  br label %BB_2070

BB_2070:                                          ; preds = %BB_2040
  %184 = zext i1 %isetrp_cmp1.124 to i32
  %185 = icmp ne i32 %184, 0
  br i1 %185, label %BB_80002070, label %BB_2090

BB_80002070:                                      ; preds = %BB_2070
  %lds_addr_memaddr_offset_add.46 = add i32 %.88, 1056
  %.3323 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.46
  %lds.49 = load volatile float, ptr addrspace(3) %.3323, align 4
  %ffma.175 = call float @llvm.fma.f32(float %shfl_idx.40, float %lds.49, float %phi.150)
  br label %BB_2090

BB_2090:                                          ; preds = %BB_80002070, %BB_2070
  %phi.165 = phi float [ %ffma.175, %BB_80002070 ], [ %phi.150, %BB_2070 ]
  %warp_reconv_mask.8 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.8)
  br i1 %isetrp_cmp1.125, label %BB_21f0, label %BB_20a0

BB_20a0:                                          ; preds = %BB_2090
  %ffma_addend_fneg.9 = fneg float %phi.165
  %ffma.176 = call float @llvm.fma.f32(float %phi.161, float %phi, float %ffma_addend_fneg.9)
  %lds_addr_memaddr_offset_add.47 = add i32 %.75, 1224
  %.3333 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.47
  %lds.50 = load volatile float, ptr addrspace(3) %.3333, align 4
  %mufu_rcp.18 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.50)
  %fchk_num_bits.9 = bitcast float %ffma.176 to i32
  %fchk_den_bits.9 = bitcast float %lds.50 to i32
  %fchk_aden.9 = and i32 %fchk_den_bits.9, 2147483647
  %fchk_anum.9 = and i32 %fchk_num_bits.9, 2147483647
  %fchk_den_subz.9 = icmp ult i32 %fchk_aden.9, 8388608
  %fchk_den_infnan.9 = icmp uge i32 %fchk_aden.9, 2139095040
  %fchk_num_infnan.9 = icmp uge i32 %fchk_anum.9, 2139095040
  %fchk_den_bad.9 = or i1 %fchk_den_subz.9, %fchk_den_infnan.9
  %fchk_px.9 = or i1 %fchk_den_bad.9, %fchk_num_infnan.9
  %ffma_lhs_fneg.18 = fneg float %lds.50
  %ffma.177 = call float @llvm.fma.f32(float %ffma_lhs_fneg.18, float %mufu_rcp.18, float 1.000000e+00)
  %ffma.178 = call float @llvm.fma.f32(float %mufu_rcp.18, float %ffma.177, float %mufu_rcp.18)
  %ffma.179 = call float @llvm.fma.f32(float %ffma.176, float %ffma.178, float 0.000000e+00)
  %ffma.180 = call float @llvm.fma.f32(float %ffma_lhs_fneg.18, float %ffma.179, float %ffma.176)
  %ffma.181 = call float @llvm.fma.f32(float %ffma.178, float %ffma.180, float %ffma.179)
  br label %BB_2180

BB_2180:                                          ; preds = %BB_20a0
  %cond_not.81 = xor i1 %fchk_px.9, true
  br i1 %cond_not.81, label %BB_21d0, label %BB_21b0_6f40

BB_21b0_6f40:                                     ; preds = %BB_2180
  %.3337 = zext i32 %fchk_den_bits.9 to i64
  %.3338 = shl i64 %.3337, 32
  %.3339 = lshr i64 %.3338, 23
  %shf_hi.50 = lshr i64 %.3339, 32
  %shf_result.60 = trunc i64 %shf_hi.50 to i32
  %.3341 = zext i32 %fchk_num_bits.9 to i64
  %.3342 = shl i64 %.3341, 32
  %.3343 = lshr i64 %.3342, 23
  %shf_hi.51 = lshr i64 %.3343, 32
  %shf_result.61 = trunc i64 %shf_hi.51 to i32
  %.3347 = and i32 %shf_result.60, 255
  %.3355 = and i32 %shf_result.61, 255
  %iadd3_n1.97 = add i32 %.3347, -1
  %iadd3_n1.98 = add i32 %.3355, -1
  %isetrp_cmp1.126 = icmp ugt i32 %iadd3_n1.97, 253
  %isetrp_cmp1.127 = icmp ugt i32 %iadd3_n1.98, 253
  %isetrp_cmp2.127 = or i1 %isetrp_cmp1.127, %isetrp_cmp1.126
  br label %BB_21b0_6fd0

BB_21b0_6fd0:                                     ; preds = %BB_21b0_6f40
  %cond_not.82 = xor i1 %isetrp_cmp2.127, true
  br i1 %cond_not.82, label %BB_21b0_80006fd0, label %BB_21b0_6ff0

BB_21b0_6ff0:                                     ; preds = %BB_21b0_6fd0
  %fsetrp_lhs_fabs.45 = call float @llvm.nvvm.fabs.f(float %ffma.176)
  %fsetrp_cmp1.54 = fcmp ugt float %fsetrp_lhs_fabs.45, 0x7FF0000000000000
  %fsetrp_lhs_fabs.46 = call float @llvm.nvvm.fabs.f(float %lds.50)
  %fsetrp_cmp1.55 = fcmp ugt float %fsetrp_lhs_fabs.46, 0x7FF0000000000000
  %lop3_a_cast_zext.36 = zext i1 %fsetrp_cmp1.54 to i32
  %lop3_b_cast_zext.36 = zext i1 %fsetrp_cmp1.55 to i32
  %plop3_a_bit.36 = and i32 %lop3_a_cast_zext.36, 1
  %plop3_b_bit.36 = and i32 %lop3_b_cast_zext.36, 1
  %.3362 = xor i32 %plop3_a_bit.36, 1
  %.3363 = xor i32 %plop3_b_bit.36, 1
  %.3365 = and i32 %.3362, %plop3_b_bit.36
  %.3367 = and i32 %plop3_a_bit.36, %.3363
  %.3369 = or i32 %.3365, %.3367
  %.3370 = and i32 %plop3_a_bit.36, %plop3_b_bit.36
  %.3372 = or i32 %.3369, %.3370
  %lop3_pred_cmp.63 = icmp ne i32 %.3372, 0
  br label %BB_21b0_7020

BB_21b0_7020:                                     ; preds = %BB_21b0_6ff0
  %186 = zext i1 %lop3_pred_cmp.63 to i32
  %187 = icmp ne i32 %186, 0
  br i1 %187, label %BB_21b0_7580, label %BB_21b0_7030

BB_21b0_7030:                                     ; preds = %BB_21b0_7020
  %.3375 = xor i32 %fchk_den_bits.9, -1
  %.3377 = xor i32 %fchk_num_bits.9, -1
  %.3378 = and i32 %.3375, 2147483647
  %.3379 = and i32 %.3378, %fchk_num_bits.9
  %.3381 = and i32 %fchk_aden.9, %.3377
  %.3382 = or i32 %.3379, %.3381
  %.3384 = and i32 %fchk_aden.9, %fchk_num_bits.9
  %.3385 = or i32 %.3382, %.3384
  %lop3_pred_cmp.64 = icmp ne i32 %.3385, 0
  br label %BB_21b0_7040

BB_21b0_7040:                                     ; preds = %BB_21b0_7030
  %cond_not.83 = xor i1 %lop3_pred_cmp.64, true
  br i1 %cond_not.83, label %BB_21b0_7560, label %BB_21b0_7050

BB_21b0_7050:                                     ; preds = %BB_21b0_7040
  %fsetrp_cmp1.56 = fcmp une float %fsetrp_lhs_fabs.45, 0x7FF0000000000000
  %fsetrp_cmp1.57 = fcmp une float %fsetrp_lhs_fabs.46, 0x7FF0000000000000
  br label %BB_21b0_7080

BB_21b0_7080:                                     ; preds = %BB_21b0_7050
  %cond_not.84 = xor i1 %fsetrp_cmp1.57, true
  br i1 %cond_not.84, label %BB_21b0_80007080, label %BB_21b0_7090

BB_21b0_80007080:                                 ; preds = %BB_21b0_7080
  %bra_cond_not.9 = xor i1 %fsetrp_cmp1.56, true
  br i1 %bra_cond_not.9, label %BB_21b0_7560, label %BB_21b0_7090

BB_21b0_7090:                                     ; preds = %BB_21b0_80007080, %BB_21b0_7080
  %lop3_pred_cmp.65 = icmp ne i32 %fchk_anum.9, 0
  %lop3_a_cast_zext.37 = zext i1 %fsetrp_cmp1.57 to i32
  %lop3_b_cast_zext.37 = zext i1 %lop3_pred_cmp.65 to i32
  %plop3_a_bit.37 = and i32 %lop3_a_cast_zext.37, 1
  %plop3_b_bit.37 = and i32 %lop3_b_cast_zext.37, 1
  %.3399 = xor i32 %plop3_a_bit.37, 1
  %.3400 = xor i32 %plop3_b_bit.37, 1
  %.3402 = and i32 %.3399, %.3400
  %.3404 = and i32 %.3399, %plop3_b_bit.37
  %.3406 = or i32 %.3402, %.3404
  %.3407 = and i32 %plop3_a_bit.37, %.3400
  %.3409 = or i32 %.3406, %.3407
  %lop3_pred_cmp.66 = icmp ne i32 %.3409, 0
  br label %BB_21b0_70b0

BB_21b0_70b0:                                     ; preds = %BB_21b0_7090
  %188 = zext i1 %lop3_pred_cmp.66 to i32
  %189 = icmp ne i32 %188, 0
  br i1 %189, label %BB_21b0_7540, label %BB_21b0_70c0

BB_21b0_70c0:                                     ; preds = %BB_21b0_70b0
  %lop3_pred_cmp.67 = icmp ne i32 %fchk_aden.9, 0
  %lop3_a_cast_zext.38 = zext i1 %fsetrp_cmp1.56 to i32
  %lop3_b_cast_zext.38 = zext i1 %lop3_pred_cmp.67 to i32
  %plop3_a_bit.38 = and i32 %lop3_a_cast_zext.38, 1
  %plop3_b_bit.38 = and i32 %lop3_b_cast_zext.38, 1
  %.3420 = xor i32 %plop3_a_bit.38, 1
  %.3421 = xor i32 %plop3_b_bit.38, 1
  %.3423 = and i32 %.3420, %.3421
  %.3425 = and i32 %.3420, %plop3_b_bit.38
  %.3427 = or i32 %.3423, %.3425
  %.3428 = and i32 %plop3_a_bit.38, %.3421
  %.3430 = or i32 %.3427, %.3428
  %lop3_pred_cmp.68 = icmp ne i32 %.3430, 0
  br label %BB_21b0_70e0

BB_21b0_70e0:                                     ; preds = %BB_21b0_70c0
  %190 = zext i1 %lop3_pred_cmp.68 to i32
  %191 = icmp ne i32 %190, 0
  br i1 %191, label %BB_21b0_7510, label %BB_21b0_70f0

BB_21b0_70f0:                                     ; preds = %BB_21b0_70e0
  %isetrp_cmp1.128 = icmp sge i32 %iadd3_n1.98, 0
  %isetrp_cmp1.129 = icmp sge i32 %iadd3_n1.97, 0
  br label %BB_21b0_7130

BB_21b0_7130:                                     ; preds = %BB_21b0_70f0
  %192 = zext i1 %isetrp_cmp1.128 to i32
  %193 = icmp ne i32 %192, 0
  br i1 %193, label %BB_21b0_80007130, label %BB_21b0_7140

BB_21b0_80007130:                                 ; preds = %BB_21b0_7130
  br label %BB_21b0_7140

BB_21b0_7140:                                     ; preds = %BB_21b0_80007130, %BB_21b0_7130
  %phi.166 = phi i32 [ 0, %BB_21b0_80007130 ], [ %iadd3_n1.97, %BB_21b0_7130 ]
  %cond_not.85 = xor i1 %isetrp_cmp1.128, true
  br i1 %cond_not.85, label %BB_21b0_80007140, label %BB_21b0_7160

BB_21b0_80007140:                                 ; preds = %BB_21b0_7140
  %ffma.182 = call float @llvm.fma.f32(float %ffma.176, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2922_bitcast = bitcast float %ffma.182 to i32
  br label %BB_21b0_7160

BB_21b0_7160:                                     ; preds = %BB_21b0_80007140, %BB_21b0_7140
  %phi.167 = phi i32 [ %phi_cast_R2922_bitcast, %BB_21b0_80007140 ], [ %fchk_num_bits.9, %BB_21b0_7140 ]
  %phi.168 = phi i32 [ -64, %BB_21b0_80007140 ], [ %phi.166, %BB_21b0_7140 ]
  %cond_not.86 = xor i1 %isetrp_cmp1.129, true
  br i1 %cond_not.86, label %BB_21b0_80007160, label %BB_21b0_7180

BB_21b0_80007160:                                 ; preds = %BB_21b0_7160
  %ffma.183 = call float @llvm.fma.f32(float %lds.50, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.19 = add i32 %phi.168, 64
  %phi_cast_R485_bitcast = bitcast float %ffma.183 to i32
  br label %BB_21b0_7180

BB_21b0_7510:                                     ; preds = %BB_21b0_70e0
  %.3443 = and i32 %.3375, -2147483648
  %.3444 = and i32 %.3443, %fchk_num_bits.9
  %.3445 = and i32 %fchk_den_bits.9, -2147483648
  %.3446 = and i32 %.3445, %.3377
  %.3447 = or i32 %.3444, %.3446
  %.3448 = xor i32 %.3447, -1
  %.3451 = and i32 %.3448, 2139095040
  %.3458 = or i32 %.3451, %.3447
  %phi_cast_R2925_bitcast = bitcast i32 %.3458 to float
  br label %BB_21b0_7590

BB_21b0_7540:                                     ; preds = %BB_21b0_70b0
  %.3472 = and i32 %.3375, -2147483648
  %.3473 = and i32 %.3472, %fchk_num_bits.9
  %.3474 = and i32 %fchk_den_bits.9, -2147483648
  %.3475 = and i32 %.3474, %.3377
  %.3476 = or i32 %.3473, %.3475
  %phi_cast_R2927_bitcast = bitcast i32 %.3476 to float
  br label %BB_21b0_7590

BB_21b0_7560:                                     ; preds = %BB_21b0_80007080, %BB_21b0_7040
  %mufu_rsq.9 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_21b0_7590

BB_21b0_7580:                                     ; preds = %BB_21b0_7020
  %fadd.18 = fadd float %ffma.176, %lds.50
  br label %BB_21b0_7590

BB_21b0_80006fd0:                                 ; preds = %BB_21b0_6fd0
  br label %BB_21b0_7180

BB_21b0_7180:                                     ; preds = %BB_21b0_80006fd0, %BB_21b0_80007160, %BB_21b0_7160
  %phi.169 = phi i32 [ %fchk_den_bits.9, %BB_21b0_80006fd0 ], [ %phi_cast_R485_bitcast, %BB_21b0_80007160 ], [ %fchk_den_bits.9, %BB_21b0_7160 ]
  %phi.170 = phi i32 [ %fchk_num_bits.9, %BB_21b0_80006fd0 ], [ %phi.167, %BB_21b0_80007160 ], [ %phi.167, %BB_21b0_7160 ]
  %phi.171 = phi i32 [ 0, %BB_21b0_80006fd0 ], [ %viadd.19, %BB_21b0_80007160 ], [ %phi.168, %BB_21b0_7160 ]
  %.3481 = zext i32 %.3347 to i64
  %.3484 = shl i64 %.3481, 23
  %.3485 = and i64 %.3484, 4294967295
  %.3486 = add i64 %.3485, 3229614080
  %.3487 = trunc i64 %.3486 to i32
  %iadd3_n1.100 = add i32 %.3355, -127
  %iadd3_o1_not.18 = xor i32 %.3487, -1
  %iadd3_o1_neg.18 = add i32 %iadd3_o1_not.18, 1
  %iadd3_n1.101 = add i32 %iadd3_o1_neg.18, %phi.169
  %imad_tmp.42 = mul i32 %iadd3_n1.100, -8388608
  %imad.53 = add i32 %imad_tmp.42, %phi.170
  %mufu_src_bitcast.9 = bitcast i32 %iadd3_n1.101 to float
  %mufu_rcp.19 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.9)
  %fadd_lhs_fneg.9 = fneg float %mufu_src_bitcast.9
  %fadd.19 = fadd float %fadd_lhs_fneg.9, 0.000000e+00
  %iadd3_o3_not.9 = xor i32 %.3347, -1
  %iadd3_o3_neg.9 = add i32 %iadd3_o3_not.9, 1
  %iadd3_n2.102 = add i32 %.3355, %iadd3_o3_neg.9
  %iadd3_n1.103 = add i32 %iadd3_n2.102, %phi.171
  %ffma.184 = call float @llvm.fma.f32(float %mufu_rcp.19, float %fadd.19, float 1.000000e+00)
  %ffma.185 = call float @llvm.fma.f32(float %mufu_rcp.19, float %ffma.184, float %mufu_rcp.19)
  %ffma_lhs_bitcast.9 = bitcast i32 %imad.53 to float
  %ffma.186 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.9, float %ffma.185, float 0.000000e+00)
  %ffma.187 = call float @llvm.fma.f32(float %fadd.19, float %ffma.186, float %ffma_lhs_bitcast.9)
  %ffma.188 = call float @llvm.fma.f32(float %ffma.185, float %ffma.187, float %ffma.186)
  %ffma.189 = call float @llvm.fma.f32(float %fadd.19, float %ffma.188, float %ffma_lhs_bitcast.9)
  %ffma.190 = call float @llvm.fma.f32(float %ffma.185, float %ffma.189, float %ffma.188)
  %shf_hi_bitcast.29 = bitcast float %ffma.190 to i32
  %.3489 = zext i32 %shf_hi_bitcast.29 to i64
  %.3490 = shl i64 %.3489, 32
  %.3491 = lshr i64 %.3490, 23
  %shf_hi.52 = lshr i64 %.3491, 32
  %shf_result.62 = trunc i64 %shf_hi.52 to i32
  %.3495 = and i32 %shf_result.62, 255
  %imad.54 = add i32 %.3495, %iadd3_n1.103
  %iadd3_n1.104 = add i32 %imad.54, -1
  %isetrp_cmp1.130 = icmp uge i32 %iadd3_n1.104, 254
  br label %BB_21b0_72d0

BB_21b0_72d0:                                     ; preds = %BB_21b0_7180
  %cond_not.87 = xor i1 %isetrp_cmp1.130, true
  br i1 %cond_not.87, label %BB_21b0_74e0, label %BB_21b0_72e0

BB_21b0_72e0:                                     ; preds = %BB_21b0_72d0
  %isetrp_cmp1.131 = icmp sgt i32 %imad.54, 254
  br label %BB_21b0_72f0

BB_21b0_72f0:                                     ; preds = %BB_21b0_72e0
  %194 = zext i1 %isetrp_cmp1.131 to i32
  %195 = icmp ne i32 %194, 0
  br i1 %195, label %BB_21b0_74b0, label %BB_21b0_7300

BB_21b0_7300:                                     ; preds = %BB_21b0_72f0
  %isetrp_cmp1.132 = icmp sge i32 %imad.54, 1
  br label %BB_21b0_7310

BB_21b0_7310:                                     ; preds = %BB_21b0_7300
  %phi_cast_R36_bitcast.2 = bitcast i32 %iadd3_n1.103 to float
  br i1 %isetrp_cmp1.132, label %BB_21b0_7590, label %BB_21b0_7320

BB_21b0_7320:                                     ; preds = %BB_21b0_7310
  %isetrp_cmp1.133 = icmp sge i32 %imad.54, -24
  %.3509 = and i32 %shf_hi_bitcast.29, -2147483648
  br label %BB_21b0_7340

BB_21b0_7340:                                     ; preds = %BB_21b0_7320
  %cond_not.88 = xor i1 %isetrp_cmp1.133, true
  %phi_cast_R2936_bitcast = bitcast i32 %.3509 to float
  br i1 %cond_not.88, label %BB_21b0_7590, label %BB_21b0_7350

BB_21b0_7350:                                     ; preds = %BB_21b0_7340
  %ffma_rz.9 = call float @llvm.nvvm.fma.rz.f(float %ffma.185, float %ffma.189, float %ffma.188)
  %iadd3_n1.105 = add i32 %imad.54, 32
  %lop3_a_bitcast.78 = bitcast float %ffma_rz.9 to i32
  %.3519 = and i32 %lop3_a_bitcast.78, 8388607
  %ffma_rp.9 = call float @llvm.nvvm.fma.rp.f(float %ffma.185, float %ffma.189, float %ffma.188)
  %ffma_rm.9 = call float @llvm.nvvm.fma.rm.f(float %ffma.185, float %ffma.189, float %ffma.188)
  %isetrp_cmp1.135 = icmp ne i32 %imad.54, 0
  %.3534 = or i32 8388608, %.3519
  %iadd3_o1_not.19 = xor i32 %imad.54, -1
  %iadd3_o1_neg.19 = add i32 %iadd3_o1_not.19, 1
  %.3544 = zext i32 %.3534 to i64
  %shf_shift_64.63 = zext i32 %iadd3_n1.105 to i64
  %.3547 = shl i64 %.3544, %shf_shift_64.63
  %shf_result.63 = trunc i64 %.3547 to i32
  %fsetrp_cmp1.59 = fcmp une float %ffma_rp.9, %ffma_rm.9
  %isetrp_cmp1.136 = icmp ne i32 %shf_result.63, 0
  %isetrp_cmp2.136 = and i1 %isetrp_cmp1.136, %isetrp_cmp1.135
  %.3550 = shl i64 %.3544, 32
  %shf_shift_64.64 = zext i32 %iadd3_o1_neg.19 to i64
  %.3551 = lshr i64 %.3550, %shf_shift_64.64
  %shf_hi.53 = lshr i64 %.3551, 32
  %shf_result.64 = trunc i64 %shf_hi.53 to i32
  %lop3_a_cast_zext.39 = zext i1 %fsetrp_cmp1.59 to i32
  %lop3_b_cast_zext.39 = zext i1 %isetrp_cmp2.136 to i32
  %plop3_a_bit.39 = and i32 %lop3_a_cast_zext.39, 1
  %plop3_b_bit.39 = and i32 %lop3_b_cast_zext.39, 1
  %.3552 = xor i32 %plop3_a_bit.39, 1
  %.3553 = xor i32 %plop3_b_bit.39, 1
  %.3555 = and i32 %.3552, %plop3_b_bit.39
  %.3557 = and i32 %plop3_a_bit.39, %.3553
  %.3559 = or i32 %.3555, %.3557
  %.3560 = and i32 %plop3_a_bit.39, %plop3_b_bit.39
  %.3562 = or i32 %.3559, %.3560
  %lop3_pred_cmp.69 = icmp ne i32 %.3562, 0
  %.3564 = zext i32 %shf_result.64 to i64
  %.3565 = shl i64 %.3564, 32
  %.3566 = lshr i64 %.3565, 1
  %shf_hi.54 = lshr i64 %.3566, 32
  %shf_result.65 = trunc i64 %shf_hi.54 to i32
  %sel_pred_not.9 = xor i1 %lop3_pred_cmp.69, true
  %sel.19 = select i1 %sel_pred_not.9, i32 0, i32 1
  %.3567 = xor i32 %sel.19, -1
  %.3569 = xor i32 %shf_result.65, -1
  %.3570 = and i32 %.3567, 1
  %.3571 = and i32 %.3570, %shf_result.65
  %.3579 = and i32 %sel.19, %.3569
  %.3580 = or i32 %.3571, %.3579
  %.3582 = and i32 %sel.19, %shf_result.65
  %.3583 = or i32 %.3580, %.3582
  %.3587 = and i32 %.3583, %shf_result.64
  %imad.55 = add i32 %shf_result.65, %.3587
  %.3592 = xor i32 %imad.55, -1
  %.3593 = xor i32 %.3509, -1
  %.3595 = and i32 %.3592, %.3509
  %.3600 = and i32 %imad.55, %.3593
  %.3602 = or i32 %.3595, %.3600
  %.3606 = and i32 %imad.55, %.3509
  %.3608 = or i32 %.3602, %.3606
  %phi_cast_R2937_bitcast = bitcast i32 %.3608 to float
  %phi_cast_R58_bitcast = bitcast i32 %.3534 to float
  br label %BB_21b0_7590

BB_21b0_74b0:                                     ; preds = %BB_21b0_72f0
  %.3616 = and i32 %shf_hi_bitcast.29, -2147483648
  %.3631 = or i32 2139095040, %.3616
  %phi_cast_R2940_bitcast = bitcast i32 %.3631 to float
  %phi_cast_R36_bitcast = bitcast i32 %iadd3_n1.103 to float
  br label %BB_21b0_7590

BB_21b0_74e0:                                     ; preds = %BB_21b0_72d0
  %.3642 = zext i32 %iadd3_n1.103 to i64
  %.3645 = shl i64 %.3642, 23
  %.3646 = and i64 %.3645, 4294967295
  %.3647 = add i64 %.3646, %.3489
  %.3648 = trunc i64 %.3647 to i32
  %phi_cast_R2941_bitcast = bitcast i32 %.3648 to float
  %phi_cast_R36_bitcast.1 = bitcast i32 %iadd3_n1.103 to float
  br label %BB_21b0_7590

BB_21b0_7590:                                     ; preds = %BB_21b0_74e0, %BB_21b0_74b0, %BB_21b0_7350, %BB_21b0_7340, %BB_21b0_7310, %BB_21b0_7580, %BB_21b0_7560, %BB_21b0_7540, %BB_21b0_7510
  %phi.172 = phi float [ %phi_cast_R2937_bitcast, %BB_21b0_7350 ], [ %phi_cast_R2940_bitcast, %BB_21b0_74b0 ], [ %phi_cast_R2941_bitcast, %BB_21b0_74e0 ], [ %ffma.190, %BB_21b0_7310 ], [ %phi_cast_R2936_bitcast, %BB_21b0_7340 ], [ %phi_cast_R2925_bitcast, %BB_21b0_7510 ], [ %phi_cast_R2927_bitcast, %BB_21b0_7540 ], [ %mufu_rsq.9, %BB_21b0_7560 ], [ %fadd.18, %BB_21b0_7580 ]
  %phi.173 = phi float [ %phi_cast_R58_bitcast, %BB_21b0_7350 ], [ %phi_cast_R36_bitcast, %BB_21b0_74b0 ], [ %phi_cast_R36_bitcast.1, %BB_21b0_74e0 ], [ %phi_cast_R36_bitcast.2, %BB_21b0_7310 ], [ %phi_cast_R36_bitcast.2, %BB_21b0_7340 ], [ %phi.162, %BB_21b0_7510 ], [ %phi.162, %BB_21b0_7540 ], [ %phi.162, %BB_21b0_7560 ], [ %phi.162, %BB_21b0_7580 ]
  br label %BB_21d0

BB_21d0:                                          ; preds = %BB_21b0_7590, %BB_2180
  %phi.174 = phi float [ %phi.172, %BB_21b0_7590 ], [ %ffma.181, %BB_2180 ]
  %phi.175 = phi float [ %phi.173, %BB_21b0_7590 ], [ %phi.162, %BB_2180 ]
  br label %BB_21f0

BB_21f0:                                          ; preds = %BB_21d0, %BB_2090
  %phi.176 = phi float [ %phi.174, %BB_21d0 ], [ %phi.161, %BB_2090 ]
  %phi.177 = phi float [ %phi.175, %BB_21d0 ], [ %phi.162, %BB_2090 ]
  %phi.178 = phi i32 [ %.75, %BB_21d0 ], [ %phi.163, %BB_2090 ]
  %phi.179 = phi float [ %phi.174, %BB_21d0 ], [ %phi.164, %BB_2090 ]
  br label %BB_2220

BB_2220:                                          ; preds = %BB_21f0
  %shfl_activemask.41 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.41 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.41, float %phi.179, i32 9, i32 31)
  br label %BB_2230

BB_2230:                                          ; preds = %BB_2220
  %isetrp_cmp1.137 = icmp uge i32 %tid_x, 10
  %isetrp_cmp1.138 = icmp ne i32 %tid_x, 10
  br label %BB_2260

BB_2260:                                          ; preds = %BB_2230
  %196 = zext i1 %isetrp_cmp1.137 to i32
  %197 = icmp ne i32 %196, 0
  br i1 %197, label %BB_80002260, label %BB_2280

BB_80002260:                                      ; preds = %BB_2260
  %lds_addr_memaddr_offset_add.48 = add i32 %.88, 1188
  %.3656 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.48
  %lds.51 = load volatile float, ptr addrspace(3) %.3656, align 4
  %ffma.191 = call float @llvm.fma.f32(float %shfl_idx.41, float %lds.51, float %phi.165)
  br label %BB_2280

BB_2280:                                          ; preds = %BB_80002260, %BB_2260
  %phi.180 = phi float [ %ffma.191, %BB_80002260 ], [ %phi.165, %BB_2260 ]
  %warp_reconv_mask.9 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.9)
  br i1 %isetrp_cmp1.138, label %BB_23e0, label %BB_2290

BB_2290:                                          ; preds = %BB_2280
  %ffma_addend_fneg.10 = fneg float %phi.180
  %ffma.192 = call float @llvm.fma.f32(float %phi.176, float %phi, float %ffma_addend_fneg.10)
  %lds_addr_memaddr_offset_add.49 = add i32 %.75, 1360
  %.3666 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.49
  %lds.52 = load volatile float, ptr addrspace(3) %.3666, align 4
  %mufu_rcp.20 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.52)
  %fchk_num_bits.10 = bitcast float %ffma.192 to i32
  %fchk_den_bits.10 = bitcast float %lds.52 to i32
  %fchk_aden.10 = and i32 %fchk_den_bits.10, 2147483647
  %fchk_anum.10 = and i32 %fchk_num_bits.10, 2147483647
  %fchk_den_subz.10 = icmp ult i32 %fchk_aden.10, 8388608
  %fchk_den_infnan.10 = icmp uge i32 %fchk_aden.10, 2139095040
  %fchk_num_infnan.10 = icmp uge i32 %fchk_anum.10, 2139095040
  %fchk_den_bad.10 = or i1 %fchk_den_subz.10, %fchk_den_infnan.10
  %fchk_px.10 = or i1 %fchk_den_bad.10, %fchk_num_infnan.10
  %ffma_lhs_fneg.20 = fneg float %lds.52
  %ffma.193 = call float @llvm.fma.f32(float %ffma_lhs_fneg.20, float %mufu_rcp.20, float 1.000000e+00)
  %ffma.194 = call float @llvm.fma.f32(float %mufu_rcp.20, float %ffma.193, float %mufu_rcp.20)
  %ffma.195 = call float @llvm.fma.f32(float %ffma.192, float %ffma.194, float 0.000000e+00)
  %ffma.196 = call float @llvm.fma.f32(float %ffma_lhs_fneg.20, float %ffma.195, float %ffma.192)
  %ffma.197 = call float @llvm.fma.f32(float %ffma.194, float %ffma.196, float %ffma.195)
  br label %BB_2370

BB_2370:                                          ; preds = %BB_2290
  %cond_not.89 = xor i1 %fchk_px.10, true
  br i1 %cond_not.89, label %BB_23c0, label %BB_23a0_6f40

BB_23a0_6f40:                                     ; preds = %BB_2370
  %.3670 = zext i32 %fchk_den_bits.10 to i64
  %.3671 = shl i64 %.3670, 32
  %.3672 = lshr i64 %.3671, 23
  %shf_hi.55 = lshr i64 %.3672, 32
  %shf_result.66 = trunc i64 %shf_hi.55 to i32
  %.3674 = zext i32 %fchk_num_bits.10 to i64
  %.3675 = shl i64 %.3674, 32
  %.3676 = lshr i64 %.3675, 23
  %shf_hi.56 = lshr i64 %.3676, 32
  %shf_result.67 = trunc i64 %shf_hi.56 to i32
  %.3680 = and i32 %shf_result.66, 255
  %.3688 = and i32 %shf_result.67, 255
  %iadd3_n1.107 = add i32 %.3680, -1
  %iadd3_n1.108 = add i32 %.3688, -1
  %isetrp_cmp1.139 = icmp ugt i32 %iadd3_n1.107, 253
  %isetrp_cmp1.140 = icmp ugt i32 %iadd3_n1.108, 253
  %isetrp_cmp2.140 = or i1 %isetrp_cmp1.140, %isetrp_cmp1.139
  br label %BB_23a0_6fd0

BB_23a0_6fd0:                                     ; preds = %BB_23a0_6f40
  %cond_not.90 = xor i1 %isetrp_cmp2.140, true
  br i1 %cond_not.90, label %BB_23a0_80006fd0, label %BB_23a0_6ff0

BB_23a0_6ff0:                                     ; preds = %BB_23a0_6fd0
  %fsetrp_lhs_fabs.50 = call float @llvm.nvvm.fabs.f(float %ffma.192)
  %fsetrp_cmp1.60 = fcmp ugt float %fsetrp_lhs_fabs.50, 0x7FF0000000000000
  %fsetrp_lhs_fabs.51 = call float @llvm.nvvm.fabs.f(float %lds.52)
  %fsetrp_cmp1.61 = fcmp ugt float %fsetrp_lhs_fabs.51, 0x7FF0000000000000
  %lop3_a_cast_zext.40 = zext i1 %fsetrp_cmp1.60 to i32
  %lop3_b_cast_zext.40 = zext i1 %fsetrp_cmp1.61 to i32
  %plop3_a_bit.40 = and i32 %lop3_a_cast_zext.40, 1
  %plop3_b_bit.40 = and i32 %lop3_b_cast_zext.40, 1
  %.3695 = xor i32 %plop3_a_bit.40, 1
  %.3696 = xor i32 %plop3_b_bit.40, 1
  %.3698 = and i32 %.3695, %plop3_b_bit.40
  %.3700 = and i32 %plop3_a_bit.40, %.3696
  %.3702 = or i32 %.3698, %.3700
  %.3703 = and i32 %plop3_a_bit.40, %plop3_b_bit.40
  %.3705 = or i32 %.3702, %.3703
  %lop3_pred_cmp.70 = icmp ne i32 %.3705, 0
  br label %BB_23a0_7020

BB_23a0_7020:                                     ; preds = %BB_23a0_6ff0
  %198 = zext i1 %lop3_pred_cmp.70 to i32
  %199 = icmp ne i32 %198, 0
  br i1 %199, label %BB_23a0_7580, label %BB_23a0_7030

BB_23a0_7030:                                     ; preds = %BB_23a0_7020
  %.3708 = xor i32 %fchk_den_bits.10, -1
  %.3710 = xor i32 %fchk_num_bits.10, -1
  %.3711 = and i32 %.3708, 2147483647
  %.3712 = and i32 %.3711, %fchk_num_bits.10
  %.3714 = and i32 %fchk_aden.10, %.3710
  %.3715 = or i32 %.3712, %.3714
  %.3717 = and i32 %fchk_aden.10, %fchk_num_bits.10
  %.3718 = or i32 %.3715, %.3717
  %lop3_pred_cmp.71 = icmp ne i32 %.3718, 0
  br label %BB_23a0_7040

BB_23a0_7040:                                     ; preds = %BB_23a0_7030
  %cond_not.91 = xor i1 %lop3_pred_cmp.71, true
  br i1 %cond_not.91, label %BB_23a0_7560, label %BB_23a0_7050

BB_23a0_7050:                                     ; preds = %BB_23a0_7040
  %fsetrp_cmp1.62 = fcmp une float %fsetrp_lhs_fabs.50, 0x7FF0000000000000
  %fsetrp_cmp1.63 = fcmp une float %fsetrp_lhs_fabs.51, 0x7FF0000000000000
  br label %BB_23a0_7080

BB_23a0_7080:                                     ; preds = %BB_23a0_7050
  %cond_not.92 = xor i1 %fsetrp_cmp1.63, true
  br i1 %cond_not.92, label %BB_23a0_80007080, label %BB_23a0_7090

BB_23a0_80007080:                                 ; preds = %BB_23a0_7080
  %bra_cond_not.10 = xor i1 %fsetrp_cmp1.62, true
  br i1 %bra_cond_not.10, label %BB_23a0_7560, label %BB_23a0_7090

BB_23a0_7090:                                     ; preds = %BB_23a0_80007080, %BB_23a0_7080
  %lop3_pred_cmp.72 = icmp ne i32 %fchk_anum.10, 0
  %lop3_a_cast_zext.41 = zext i1 %fsetrp_cmp1.63 to i32
  %lop3_b_cast_zext.41 = zext i1 %lop3_pred_cmp.72 to i32
  %plop3_a_bit.41 = and i32 %lop3_a_cast_zext.41, 1
  %plop3_b_bit.41 = and i32 %lop3_b_cast_zext.41, 1
  %.3732 = xor i32 %plop3_a_bit.41, 1
  %.3733 = xor i32 %plop3_b_bit.41, 1
  %.3735 = and i32 %.3732, %.3733
  %.3737 = and i32 %.3732, %plop3_b_bit.41
  %.3739 = or i32 %.3735, %.3737
  %.3740 = and i32 %plop3_a_bit.41, %.3733
  %.3742 = or i32 %.3739, %.3740
  %lop3_pred_cmp.73 = icmp ne i32 %.3742, 0
  br label %BB_23a0_70b0

BB_23a0_70b0:                                     ; preds = %BB_23a0_7090
  %200 = zext i1 %lop3_pred_cmp.73 to i32
  %201 = icmp ne i32 %200, 0
  br i1 %201, label %BB_23a0_7540, label %BB_23a0_70c0

BB_23a0_70c0:                                     ; preds = %BB_23a0_70b0
  %lop3_pred_cmp.74 = icmp ne i32 %fchk_aden.10, 0
  %lop3_a_cast_zext.42 = zext i1 %fsetrp_cmp1.62 to i32
  %lop3_b_cast_zext.42 = zext i1 %lop3_pred_cmp.74 to i32
  %plop3_a_bit.42 = and i32 %lop3_a_cast_zext.42, 1
  %plop3_b_bit.42 = and i32 %lop3_b_cast_zext.42, 1
  %.3753 = xor i32 %plop3_a_bit.42, 1
  %.3754 = xor i32 %plop3_b_bit.42, 1
  %.3756 = and i32 %.3753, %.3754
  %.3758 = and i32 %.3753, %plop3_b_bit.42
  %.3760 = or i32 %.3756, %.3758
  %.3761 = and i32 %plop3_a_bit.42, %.3754
  %.3763 = or i32 %.3760, %.3761
  %lop3_pred_cmp.75 = icmp ne i32 %.3763, 0
  br label %BB_23a0_70e0

BB_23a0_70e0:                                     ; preds = %BB_23a0_70c0
  %202 = zext i1 %lop3_pred_cmp.75 to i32
  %203 = icmp ne i32 %202, 0
  br i1 %203, label %BB_23a0_7510, label %BB_23a0_70f0

BB_23a0_70f0:                                     ; preds = %BB_23a0_70e0
  %isetrp_cmp1.141 = icmp sge i32 %iadd3_n1.108, 0
  %isetrp_cmp1.142 = icmp sge i32 %iadd3_n1.107, 0
  br label %BB_23a0_7130

BB_23a0_7130:                                     ; preds = %BB_23a0_70f0
  %204 = zext i1 %isetrp_cmp1.141 to i32
  %205 = icmp ne i32 %204, 0
  br i1 %205, label %BB_23a0_80007130, label %BB_23a0_7140

BB_23a0_80007130:                                 ; preds = %BB_23a0_7130
  br label %BB_23a0_7140

BB_23a0_7140:                                     ; preds = %BB_23a0_80007130, %BB_23a0_7130
  %phi.181 = phi i32 [ 0, %BB_23a0_80007130 ], [ %iadd3_n1.107, %BB_23a0_7130 ]
  %cond_not.93 = xor i1 %isetrp_cmp1.141, true
  br i1 %cond_not.93, label %BB_23a0_80007140, label %BB_23a0_7160

BB_23a0_80007140:                                 ; preds = %BB_23a0_7140
  %ffma.198 = call float @llvm.fma.f32(float %ffma.192, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2946_bitcast = bitcast float %ffma.198 to i32
  br label %BB_23a0_7160

BB_23a0_7160:                                     ; preds = %BB_23a0_80007140, %BB_23a0_7140
  %phi.182 = phi i32 [ %phi_cast_R2946_bitcast, %BB_23a0_80007140 ], [ %fchk_num_bits.10, %BB_23a0_7140 ]
  %phi.183 = phi i32 [ -64, %BB_23a0_80007140 ], [ %phi.181, %BB_23a0_7140 ]
  %cond_not.94 = xor i1 %isetrp_cmp1.142, true
  br i1 %cond_not.94, label %BB_23a0_80007160, label %BB_23a0_7180

BB_23a0_80007160:                                 ; preds = %BB_23a0_7160
  %ffma.199 = call float @llvm.fma.f32(float %lds.52, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.21 = add i32 %phi.183, 64
  %phi_cast_R504_bitcast = bitcast float %ffma.199 to i32
  br label %BB_23a0_7180

BB_23a0_7510:                                     ; preds = %BB_23a0_70e0
  %.3776 = and i32 %.3708, -2147483648
  %.3777 = and i32 %.3776, %fchk_num_bits.10
  %.3778 = and i32 %fchk_den_bits.10, -2147483648
  %.3779 = and i32 %.3778, %.3710
  %.3780 = or i32 %.3777, %.3779
  %.3781 = xor i32 %.3780, -1
  %.3784 = and i32 %.3781, 2139095040
  %.3791 = or i32 %.3784, %.3780
  %phi_cast_R2950_bitcast = bitcast i32 %.3791 to float
  br label %BB_23a0_7590

BB_23a0_7540:                                     ; preds = %BB_23a0_70b0
  %.3805 = and i32 %.3708, -2147483648
  %.3806 = and i32 %.3805, %fchk_num_bits.10
  %.3807 = and i32 %fchk_den_bits.10, -2147483648
  %.3808 = and i32 %.3807, %.3710
  %.3809 = or i32 %.3806, %.3808
  %phi_cast_R2951_bitcast = bitcast i32 %.3809 to float
  br label %BB_23a0_7590

BB_23a0_7560:                                     ; preds = %BB_23a0_80007080, %BB_23a0_7040
  %mufu_rsq.10 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_23a0_7590

BB_23a0_7580:                                     ; preds = %BB_23a0_7020
  %fadd.20 = fadd float %ffma.192, %lds.52
  br label %BB_23a0_7590

BB_23a0_80006fd0:                                 ; preds = %BB_23a0_6fd0
  br label %BB_23a0_7180

BB_23a0_7180:                                     ; preds = %BB_23a0_80006fd0, %BB_23a0_80007160, %BB_23a0_7160
  %phi.184 = phi i32 [ %fchk_den_bits.10, %BB_23a0_80006fd0 ], [ %phi_cast_R504_bitcast, %BB_23a0_80007160 ], [ %fchk_den_bits.10, %BB_23a0_7160 ]
  %phi.185 = phi i32 [ %fchk_num_bits.10, %BB_23a0_80006fd0 ], [ %phi.182, %BB_23a0_80007160 ], [ %phi.182, %BB_23a0_7160 ]
  %phi.186 = phi i32 [ 0, %BB_23a0_80006fd0 ], [ %viadd.21, %BB_23a0_80007160 ], [ %phi.183, %BB_23a0_7160 ]
  %.3814 = zext i32 %.3680 to i64
  %.3817 = shl i64 %.3814, 23
  %.3818 = and i64 %.3817, 4294967295
  %.3819 = add i64 %.3818, 3229614080
  %.3820 = trunc i64 %.3819 to i32
  %iadd3_n1.110 = add i32 %.3688, -127
  %iadd3_o1_not.20 = xor i32 %.3820, -1
  %iadd3_o1_neg.20 = add i32 %iadd3_o1_not.20, 1
  %iadd3_n1.111 = add i32 %iadd3_o1_neg.20, %phi.184
  %imad_tmp.46 = mul i32 %iadd3_n1.110, -8388608
  %imad.57 = add i32 %imad_tmp.46, %phi.185
  %mufu_src_bitcast.10 = bitcast i32 %iadd3_n1.111 to float
  %mufu_rcp.21 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.10)
  %fadd_lhs_fneg.10 = fneg float %mufu_src_bitcast.10
  %fadd.21 = fadd float %fadd_lhs_fneg.10, 0.000000e+00
  %iadd3_o3_not.10 = xor i32 %.3680, -1
  %iadd3_o3_neg.10 = add i32 %iadd3_o3_not.10, 1
  %iadd3_n2.112 = add i32 %.3688, %iadd3_o3_neg.10
  %iadd3_n1.113 = add i32 %iadd3_n2.112, %phi.186
  %ffma.200 = call float @llvm.fma.f32(float %mufu_rcp.21, float %fadd.21, float 1.000000e+00)
  %ffma.201 = call float @llvm.fma.f32(float %mufu_rcp.21, float %ffma.200, float %mufu_rcp.21)
  %ffma_lhs_bitcast.10 = bitcast i32 %imad.57 to float
  %ffma.202 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.10, float %ffma.201, float 0.000000e+00)
  %ffma.203 = call float @llvm.fma.f32(float %fadd.21, float %ffma.202, float %ffma_lhs_bitcast.10)
  %ffma.204 = call float @llvm.fma.f32(float %ffma.201, float %ffma.203, float %ffma.202)
  %ffma.205 = call float @llvm.fma.f32(float %fadd.21, float %ffma.204, float %ffma_lhs_bitcast.10)
  %ffma.206 = call float @llvm.fma.f32(float %ffma.201, float %ffma.205, float %ffma.204)
  %shf_hi_bitcast.32 = bitcast float %ffma.206 to i32
  %.3822 = zext i32 %shf_hi_bitcast.32 to i64
  %.3823 = shl i64 %.3822, 32
  %.3824 = lshr i64 %.3823, 23
  %shf_hi.57 = lshr i64 %.3824, 32
  %shf_result.68 = trunc i64 %shf_hi.57 to i32
  %.3828 = and i32 %shf_result.68, 255
  %imad.58 = add i32 %.3828, %iadd3_n1.113
  %iadd3_n1.114 = add i32 %imad.58, -1
  %isetrp_cmp1.143 = icmp uge i32 %iadd3_n1.114, 254
  br label %BB_23a0_72d0

BB_23a0_72d0:                                     ; preds = %BB_23a0_7180
  %cond_not.95 = xor i1 %isetrp_cmp1.143, true
  br i1 %cond_not.95, label %BB_23a0_74e0, label %BB_23a0_72e0

BB_23a0_72e0:                                     ; preds = %BB_23a0_72d0
  %isetrp_cmp1.144 = icmp sgt i32 %imad.58, 254
  br label %BB_23a0_72f0

BB_23a0_72f0:                                     ; preds = %BB_23a0_72e0
  %206 = zext i1 %isetrp_cmp1.144 to i32
  %207 = icmp ne i32 %206, 0
  br i1 %207, label %BB_23a0_74b0, label %BB_23a0_7300

BB_23a0_7300:                                     ; preds = %BB_23a0_72f0
  %isetrp_cmp1.145 = icmp sge i32 %imad.58, 1
  br label %BB_23a0_7310

BB_23a0_7310:                                     ; preds = %BB_23a0_7300
  %phi_cast_R2088_bitcast.2 = bitcast i32 %iadd3_n1.113 to float
  br i1 %isetrp_cmp1.145, label %BB_23a0_7590, label %BB_23a0_7320

BB_23a0_7320:                                     ; preds = %BB_23a0_7310
  %isetrp_cmp1.146 = icmp sge i32 %imad.58, -24
  %.3842 = and i32 %shf_hi_bitcast.32, -2147483648
  br label %BB_23a0_7340

BB_23a0_7340:                                     ; preds = %BB_23a0_7320
  %cond_not.96 = xor i1 %isetrp_cmp1.146, true
  %phi_cast_R2960_bitcast = bitcast i32 %.3842 to float
  br i1 %cond_not.96, label %BB_23a0_7590, label %BB_23a0_7350

BB_23a0_7350:                                     ; preds = %BB_23a0_7340
  %ffma_rz.10 = call float @llvm.nvvm.fma.rz.f(float %ffma.201, float %ffma.205, float %ffma.204)
  %iadd3_n1.115 = add i32 %imad.58, 32
  %lop3_a_bitcast.86 = bitcast float %ffma_rz.10 to i32
  %.3852 = and i32 %lop3_a_bitcast.86, 8388607
  %ffma_rp.10 = call float @llvm.nvvm.fma.rp.f(float %ffma.201, float %ffma.205, float %ffma.204)
  %ffma_rm.10 = call float @llvm.nvvm.fma.rm.f(float %ffma.201, float %ffma.205, float %ffma.204)
  %isetrp_cmp1.148 = icmp ne i32 %imad.58, 0
  %.3867 = or i32 8388608, %.3852
  %iadd3_o1_not.21 = xor i32 %imad.58, -1
  %iadd3_o1_neg.21 = add i32 %iadd3_o1_not.21, 1
  %.3877 = zext i32 %.3867 to i64
  %shf_shift_64.69 = zext i32 %iadd3_n1.115 to i64
  %.3880 = shl i64 %.3877, %shf_shift_64.69
  %shf_result.69 = trunc i64 %.3880 to i32
  %fsetrp_cmp1.65 = fcmp une float %ffma_rp.10, %ffma_rm.10
  %isetrp_cmp1.149 = icmp ne i32 %shf_result.69, 0
  %isetrp_cmp2.149 = and i1 %isetrp_cmp1.149, %isetrp_cmp1.148
  %.3883 = shl i64 %.3877, 32
  %shf_shift_64.70 = zext i32 %iadd3_o1_neg.21 to i64
  %.3884 = lshr i64 %.3883, %shf_shift_64.70
  %shf_hi.58 = lshr i64 %.3884, 32
  %shf_result.70 = trunc i64 %shf_hi.58 to i32
  %lop3_a_cast_zext.43 = zext i1 %fsetrp_cmp1.65 to i32
  %lop3_b_cast_zext.43 = zext i1 %isetrp_cmp2.149 to i32
  %plop3_a_bit.43 = and i32 %lop3_a_cast_zext.43, 1
  %plop3_b_bit.43 = and i32 %lop3_b_cast_zext.43, 1
  %.3885 = xor i32 %plop3_a_bit.43, 1
  %.3886 = xor i32 %plop3_b_bit.43, 1
  %.3888 = and i32 %.3885, %plop3_b_bit.43
  %.3890 = and i32 %plop3_a_bit.43, %.3886
  %.3892 = or i32 %.3888, %.3890
  %.3893 = and i32 %plop3_a_bit.43, %plop3_b_bit.43
  %.3895 = or i32 %.3892, %.3893
  %lop3_pred_cmp.76 = icmp ne i32 %.3895, 0
  %.3897 = zext i32 %shf_result.70 to i64
  %.3898 = shl i64 %.3897, 32
  %.3899 = lshr i64 %.3898, 1
  %shf_hi.59 = lshr i64 %.3899, 32
  %shf_result.71 = trunc i64 %shf_hi.59 to i32
  %sel_pred_not.10 = xor i1 %lop3_pred_cmp.76, true
  %sel.21 = select i1 %sel_pred_not.10, i32 0, i32 1
  %.3900 = xor i32 %sel.21, -1
  %.3902 = xor i32 %shf_result.71, -1
  %.3903 = and i32 %.3900, 1
  %.3904 = and i32 %.3903, %shf_result.71
  %.3912 = and i32 %sel.21, %.3902
  %.3913 = or i32 %.3904, %.3912
  %.3915 = and i32 %sel.21, %shf_result.71
  %.3916 = or i32 %.3913, %.3915
  %.3920 = and i32 %.3916, %shf_result.70
  %imad.59 = add i32 %shf_result.71, %.3920
  %.3925 = xor i32 %imad.59, -1
  %.3926 = xor i32 %.3842, -1
  %.3928 = and i32 %.3925, %.3842
  %.3933 = and i32 %imad.59, %.3926
  %.3935 = or i32 %.3928, %.3933
  %.3939 = and i32 %imad.59, %.3842
  %.3941 = or i32 %.3935, %.3939
  %phi_cast_R2961_bitcast = bitcast i32 %.3941 to float
  %phi_cast_R2091_bitcast = bitcast i32 %.3867 to float
  br label %BB_23a0_7590

BB_23a0_74b0:                                     ; preds = %BB_23a0_72f0
  %.3949 = and i32 %shf_hi_bitcast.32, -2147483648
  %.3964 = or i32 2139095040, %.3949
  %phi_cast_R2963_bitcast = bitcast i32 %.3964 to float
  %phi_cast_R2088_bitcast = bitcast i32 %iadd3_n1.113 to float
  br label %BB_23a0_7590

BB_23a0_74e0:                                     ; preds = %BB_23a0_72d0
  %.3975 = zext i32 %iadd3_n1.113 to i64
  %.3978 = shl i64 %.3975, 23
  %.3979 = and i64 %.3978, 4294967295
  %.3980 = add i64 %.3979, %.3822
  %.3981 = trunc i64 %.3980 to i32
  %phi_cast_R2965_bitcast = bitcast i32 %.3981 to float
  %phi_cast_R2088_bitcast.1 = bitcast i32 %iadd3_n1.113 to float
  br label %BB_23a0_7590

BB_23a0_7590:                                     ; preds = %BB_23a0_74e0, %BB_23a0_74b0, %BB_23a0_7350, %BB_23a0_7340, %BB_23a0_7310, %BB_23a0_7580, %BB_23a0_7560, %BB_23a0_7540, %BB_23a0_7510
  %phi.187 = phi float [ %phi_cast_R2961_bitcast, %BB_23a0_7350 ], [ %phi_cast_R2963_bitcast, %BB_23a0_74b0 ], [ %phi_cast_R2965_bitcast, %BB_23a0_74e0 ], [ %ffma.206, %BB_23a0_7310 ], [ %phi_cast_R2960_bitcast, %BB_23a0_7340 ], [ %phi_cast_R2950_bitcast, %BB_23a0_7510 ], [ %phi_cast_R2951_bitcast, %BB_23a0_7540 ], [ %mufu_rsq.10, %BB_23a0_7560 ], [ %fadd.20, %BB_23a0_7580 ]
  %phi.188 = phi float [ %phi_cast_R2091_bitcast, %BB_23a0_7350 ], [ %phi_cast_R2088_bitcast, %BB_23a0_74b0 ], [ %phi_cast_R2088_bitcast.1, %BB_23a0_74e0 ], [ %phi_cast_R2088_bitcast.2, %BB_23a0_7310 ], [ %phi_cast_R2088_bitcast.2, %BB_23a0_7340 ], [ %phi.177, %BB_23a0_7510 ], [ %phi.177, %BB_23a0_7540 ], [ %phi.177, %BB_23a0_7560 ], [ %phi.177, %BB_23a0_7580 ]
  br label %BB_23c0

BB_23c0:                                          ; preds = %BB_23a0_7590, %BB_2370
  %phi.189 = phi float [ %phi.187, %BB_23a0_7590 ], [ %ffma.197, %BB_2370 ]
  %phi.190 = phi float [ %phi.188, %BB_23a0_7590 ], [ %phi.177, %BB_2370 ]
  br label %BB_23e0

BB_23e0:                                          ; preds = %BB_23c0, %BB_2280
  %phi.191 = phi float [ %phi.189, %BB_23c0 ], [ %phi.176, %BB_2280 ]
  %phi.192 = phi float [ %phi.190, %BB_23c0 ], [ %phi.177, %BB_2280 ]
  %phi.193 = phi i32 [ %.75, %BB_23c0 ], [ %phi.178, %BB_2280 ]
  %phi.194 = phi float [ %phi.189, %BB_23c0 ], [ %phi.179, %BB_2280 ]
  br label %BB_2410

BB_2410:                                          ; preds = %BB_23e0
  %shfl_activemask.42 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.42 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.42, float %phi.194, i32 10, i32 31)
  br label %BB_2420

BB_2420:                                          ; preds = %BB_2410
  %isetrp_cmp1.150 = icmp uge i32 %tid_x, 11
  %isetrp_cmp1.151 = icmp ne i32 %tid_x, 11
  br label %BB_2450

BB_2450:                                          ; preds = %BB_2420
  %208 = zext i1 %isetrp_cmp1.150 to i32
  %209 = icmp ne i32 %208, 0
  br i1 %209, label %BB_80002450, label %BB_2470

BB_80002450:                                      ; preds = %BB_2450
  %lds_addr_memaddr_offset_add.50 = add i32 %.88, 1320
  %.3989 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.50
  %lds.53 = load volatile float, ptr addrspace(3) %.3989, align 4
  %ffma.207 = call float @llvm.fma.f32(float %shfl_idx.42, float %lds.53, float %phi.180)
  br label %BB_2470

BB_2470:                                          ; preds = %BB_80002450, %BB_2450
  %phi.195 = phi float [ %ffma.207, %BB_80002450 ], [ %phi.180, %BB_2450 ]
  %warp_reconv_mask.10 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.10)
  br i1 %isetrp_cmp1.151, label %BB_25d0, label %BB_2480

BB_2480:                                          ; preds = %BB_2470
  %ffma_addend_fneg.11 = fneg float %phi.195
  %ffma.208 = call float @llvm.fma.f32(float %phi.191, float %phi, float %ffma_addend_fneg.11)
  %lds_addr_memaddr_offset_add.51 = add i32 %.75, 1496
  %.3999 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.51
  %lds.54 = load volatile float, ptr addrspace(3) %.3999, align 4
  %mufu_rcp.22 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.54)
  %fchk_num_bits.11 = bitcast float %ffma.208 to i32
  %fchk_den_bits.11 = bitcast float %lds.54 to i32
  %fchk_aden.11 = and i32 %fchk_den_bits.11, 2147483647
  %fchk_anum.11 = and i32 %fchk_num_bits.11, 2147483647
  %fchk_den_subz.11 = icmp ult i32 %fchk_aden.11, 8388608
  %fchk_den_infnan.11 = icmp uge i32 %fchk_aden.11, 2139095040
  %fchk_num_infnan.11 = icmp uge i32 %fchk_anum.11, 2139095040
  %fchk_den_bad.11 = or i1 %fchk_den_subz.11, %fchk_den_infnan.11
  %fchk_px.11 = or i1 %fchk_den_bad.11, %fchk_num_infnan.11
  %ffma_lhs_fneg.22 = fneg float %lds.54
  %ffma.209 = call float @llvm.fma.f32(float %ffma_lhs_fneg.22, float %mufu_rcp.22, float 1.000000e+00)
  %ffma.210 = call float @llvm.fma.f32(float %mufu_rcp.22, float %ffma.209, float %mufu_rcp.22)
  %ffma.211 = call float @llvm.fma.f32(float %ffma.208, float %ffma.210, float 0.000000e+00)
  %ffma.212 = call float @llvm.fma.f32(float %ffma_lhs_fneg.22, float %ffma.211, float %ffma.208)
  %ffma.213 = call float @llvm.fma.f32(float %ffma.210, float %ffma.212, float %ffma.211)
  br label %BB_2560

BB_2560:                                          ; preds = %BB_2480
  %cond_not.97 = xor i1 %fchk_px.11, true
  br i1 %cond_not.97, label %BB_25b0, label %BB_2590_6f40

BB_2590_6f40:                                     ; preds = %BB_2560
  %.4003 = zext i32 %fchk_den_bits.11 to i64
  %.4004 = shl i64 %.4003, 32
  %.4005 = lshr i64 %.4004, 23
  %shf_hi.60 = lshr i64 %.4005, 32
  %shf_result.72 = trunc i64 %shf_hi.60 to i32
  %.4007 = zext i32 %fchk_num_bits.11 to i64
  %.4008 = shl i64 %.4007, 32
  %.4009 = lshr i64 %.4008, 23
  %shf_hi.61 = lshr i64 %.4009, 32
  %shf_result.73 = trunc i64 %shf_hi.61 to i32
  %.4013 = and i32 %shf_result.72, 255
  %.4021 = and i32 %shf_result.73, 255
  %iadd3_n1.117 = add i32 %.4013, -1
  %iadd3_n1.118 = add i32 %.4021, -1
  %isetrp_cmp1.152 = icmp ugt i32 %iadd3_n1.117, 253
  %isetrp_cmp1.153 = icmp ugt i32 %iadd3_n1.118, 253
  %isetrp_cmp2.153 = or i1 %isetrp_cmp1.153, %isetrp_cmp1.152
  br label %BB_2590_6fd0

BB_2590_6fd0:                                     ; preds = %BB_2590_6f40
  %cond_not.98 = xor i1 %isetrp_cmp2.153, true
  br i1 %cond_not.98, label %BB_2590_80006fd0, label %BB_2590_6ff0

BB_2590_6ff0:                                     ; preds = %BB_2590_6fd0
  %fsetrp_lhs_fabs.55 = call float @llvm.nvvm.fabs.f(float %ffma.208)
  %fsetrp_cmp1.66 = fcmp ugt float %fsetrp_lhs_fabs.55, 0x7FF0000000000000
  %fsetrp_lhs_fabs.56 = call float @llvm.nvvm.fabs.f(float %lds.54)
  %fsetrp_cmp1.67 = fcmp ugt float %fsetrp_lhs_fabs.56, 0x7FF0000000000000
  %lop3_a_cast_zext.44 = zext i1 %fsetrp_cmp1.66 to i32
  %lop3_b_cast_zext.44 = zext i1 %fsetrp_cmp1.67 to i32
  %plop3_a_bit.44 = and i32 %lop3_a_cast_zext.44, 1
  %plop3_b_bit.44 = and i32 %lop3_b_cast_zext.44, 1
  %.4028 = xor i32 %plop3_a_bit.44, 1
  %.4029 = xor i32 %plop3_b_bit.44, 1
  %.4031 = and i32 %.4028, %plop3_b_bit.44
  %.4033 = and i32 %plop3_a_bit.44, %.4029
  %.4035 = or i32 %.4031, %.4033
  %.4036 = and i32 %plop3_a_bit.44, %plop3_b_bit.44
  %.4038 = or i32 %.4035, %.4036
  %lop3_pred_cmp.77 = icmp ne i32 %.4038, 0
  br label %BB_2590_7020

BB_2590_7020:                                     ; preds = %BB_2590_6ff0
  %210 = zext i1 %lop3_pred_cmp.77 to i32
  %211 = icmp ne i32 %210, 0
  br i1 %211, label %BB_2590_7580, label %BB_2590_7030

BB_2590_7030:                                     ; preds = %BB_2590_7020
  %.4041 = xor i32 %fchk_den_bits.11, -1
  %.4043 = xor i32 %fchk_num_bits.11, -1
  %.4044 = and i32 %.4041, 2147483647
  %.4045 = and i32 %.4044, %fchk_num_bits.11
  %.4047 = and i32 %fchk_aden.11, %.4043
  %.4048 = or i32 %.4045, %.4047
  %.4050 = and i32 %fchk_aden.11, %fchk_num_bits.11
  %.4051 = or i32 %.4048, %.4050
  %lop3_pred_cmp.78 = icmp ne i32 %.4051, 0
  br label %BB_2590_7040

BB_2590_7040:                                     ; preds = %BB_2590_7030
  %cond_not.99 = xor i1 %lop3_pred_cmp.78, true
  br i1 %cond_not.99, label %BB_2590_7560, label %BB_2590_7050

BB_2590_7050:                                     ; preds = %BB_2590_7040
  %fsetrp_cmp1.68 = fcmp une float %fsetrp_lhs_fabs.55, 0x7FF0000000000000
  %fsetrp_cmp1.69 = fcmp une float %fsetrp_lhs_fabs.56, 0x7FF0000000000000
  br label %BB_2590_7080

BB_2590_7080:                                     ; preds = %BB_2590_7050
  %cond_not.100 = xor i1 %fsetrp_cmp1.69, true
  br i1 %cond_not.100, label %BB_2590_80007080, label %BB_2590_7090

BB_2590_80007080:                                 ; preds = %BB_2590_7080
  %bra_cond_not.11 = xor i1 %fsetrp_cmp1.68, true
  br i1 %bra_cond_not.11, label %BB_2590_7560, label %BB_2590_7090

BB_2590_7090:                                     ; preds = %BB_2590_80007080, %BB_2590_7080
  %lop3_pred_cmp.79 = icmp ne i32 %fchk_anum.11, 0
  %lop3_a_cast_zext.45 = zext i1 %fsetrp_cmp1.69 to i32
  %lop3_b_cast_zext.45 = zext i1 %lop3_pred_cmp.79 to i32
  %plop3_a_bit.45 = and i32 %lop3_a_cast_zext.45, 1
  %plop3_b_bit.45 = and i32 %lop3_b_cast_zext.45, 1
  %.4065 = xor i32 %plop3_a_bit.45, 1
  %.4066 = xor i32 %plop3_b_bit.45, 1
  %.4068 = and i32 %.4065, %.4066
  %.4070 = and i32 %.4065, %plop3_b_bit.45
  %.4072 = or i32 %.4068, %.4070
  %.4073 = and i32 %plop3_a_bit.45, %.4066
  %.4075 = or i32 %.4072, %.4073
  %lop3_pred_cmp.80 = icmp ne i32 %.4075, 0
  br label %BB_2590_70b0

BB_2590_70b0:                                     ; preds = %BB_2590_7090
  %212 = zext i1 %lop3_pred_cmp.80 to i32
  %213 = icmp ne i32 %212, 0
  br i1 %213, label %BB_2590_7540, label %BB_2590_70c0

BB_2590_70c0:                                     ; preds = %BB_2590_70b0
  %lop3_pred_cmp.81 = icmp ne i32 %fchk_aden.11, 0
  %lop3_a_cast_zext.46 = zext i1 %fsetrp_cmp1.68 to i32
  %lop3_b_cast_zext.46 = zext i1 %lop3_pred_cmp.81 to i32
  %plop3_a_bit.46 = and i32 %lop3_a_cast_zext.46, 1
  %plop3_b_bit.46 = and i32 %lop3_b_cast_zext.46, 1
  %.4086 = xor i32 %plop3_a_bit.46, 1
  %.4087 = xor i32 %plop3_b_bit.46, 1
  %.4089 = and i32 %.4086, %.4087
  %.4091 = and i32 %.4086, %plop3_b_bit.46
  %.4093 = or i32 %.4089, %.4091
  %.4094 = and i32 %plop3_a_bit.46, %.4087
  %.4096 = or i32 %.4093, %.4094
  %lop3_pred_cmp.82 = icmp ne i32 %.4096, 0
  br label %BB_2590_70e0

BB_2590_70e0:                                     ; preds = %BB_2590_70c0
  %214 = zext i1 %lop3_pred_cmp.82 to i32
  %215 = icmp ne i32 %214, 0
  br i1 %215, label %BB_2590_7510, label %BB_2590_70f0

BB_2590_70f0:                                     ; preds = %BB_2590_70e0
  %isetrp_cmp1.154 = icmp sge i32 %iadd3_n1.118, 0
  %isetrp_cmp1.155 = icmp sge i32 %iadd3_n1.117, 0
  br label %BB_2590_7130

BB_2590_7130:                                     ; preds = %BB_2590_70f0
  %216 = zext i1 %isetrp_cmp1.154 to i32
  %217 = icmp ne i32 %216, 0
  br i1 %217, label %BB_2590_80007130, label %BB_2590_7140

BB_2590_80007130:                                 ; preds = %BB_2590_7130
  br label %BB_2590_7140

BB_2590_7140:                                     ; preds = %BB_2590_80007130, %BB_2590_7130
  %phi.196 = phi i32 [ 0, %BB_2590_80007130 ], [ %iadd3_n1.117, %BB_2590_7130 ]
  %cond_not.101 = xor i1 %isetrp_cmp1.154, true
  br i1 %cond_not.101, label %BB_2590_80007140, label %BB_2590_7160

BB_2590_80007140:                                 ; preds = %BB_2590_7140
  %ffma.214 = call float @llvm.fma.f32(float %ffma.208, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2969_bitcast = bitcast float %ffma.214 to i32
  br label %BB_2590_7160

BB_2590_7160:                                     ; preds = %BB_2590_80007140, %BB_2590_7140
  %phi.197 = phi i32 [ %phi_cast_R2969_bitcast, %BB_2590_80007140 ], [ %fchk_num_bits.11, %BB_2590_7140 ]
  %phi.198 = phi i32 [ -64, %BB_2590_80007140 ], [ %phi.196, %BB_2590_7140 ]
  %cond_not.102 = xor i1 %isetrp_cmp1.155, true
  br i1 %cond_not.102, label %BB_2590_80007160, label %BB_2590_7180

BB_2590_80007160:                                 ; preds = %BB_2590_7160
  %ffma.215 = call float @llvm.fma.f32(float %lds.54, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.23 = add i32 %phi.198, 64
  %phi_cast_R521_bitcast = bitcast float %ffma.215 to i32
  br label %BB_2590_7180

BB_2590_7510:                                     ; preds = %BB_2590_70e0
  %.4109 = and i32 %.4041, -2147483648
  %.4110 = and i32 %.4109, %fchk_num_bits.11
  %.4111 = and i32 %fchk_den_bits.11, -2147483648
  %.4112 = and i32 %.4111, %.4043
  %.4113 = or i32 %.4110, %.4112
  %.4114 = xor i32 %.4113, -1
  %.4117 = and i32 %.4114, 2139095040
  %.4124 = or i32 %.4117, %.4113
  %phi_cast_R2972_bitcast = bitcast i32 %.4124 to float
  br label %BB_2590_7590

BB_2590_7540:                                     ; preds = %BB_2590_70b0
  %.4138 = and i32 %.4041, -2147483648
  %.4139 = and i32 %.4138, %fchk_num_bits.11
  %.4140 = and i32 %fchk_den_bits.11, -2147483648
  %.4141 = and i32 %.4140, %.4043
  %.4142 = or i32 %.4139, %.4141
  %phi_cast_R2973_bitcast = bitcast i32 %.4142 to float
  br label %BB_2590_7590

BB_2590_7560:                                     ; preds = %BB_2590_80007080, %BB_2590_7040
  %mufu_rsq.11 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_2590_7590

BB_2590_7580:                                     ; preds = %BB_2590_7020
  %fadd.22 = fadd float %ffma.208, %lds.54
  br label %BB_2590_7590

BB_2590_80006fd0:                                 ; preds = %BB_2590_6fd0
  br label %BB_2590_7180

BB_2590_7180:                                     ; preds = %BB_2590_80006fd0, %BB_2590_80007160, %BB_2590_7160
  %phi.199 = phi i32 [ %fchk_den_bits.11, %BB_2590_80006fd0 ], [ %phi_cast_R521_bitcast, %BB_2590_80007160 ], [ %fchk_den_bits.11, %BB_2590_7160 ]
  %phi.200 = phi i32 [ %fchk_num_bits.11, %BB_2590_80006fd0 ], [ %phi.197, %BB_2590_80007160 ], [ %phi.197, %BB_2590_7160 ]
  %phi.201 = phi i32 [ 0, %BB_2590_80006fd0 ], [ %viadd.23, %BB_2590_80007160 ], [ %phi.198, %BB_2590_7160 ]
  %.4147 = zext i32 %.4013 to i64
  %.4150 = shl i64 %.4147, 23
  %.4151 = and i64 %.4150, 4294967295
  %.4152 = add i64 %.4151, 3229614080
  %.4153 = trunc i64 %.4152 to i32
  %iadd3_n1.120 = add i32 %.4021, -127
  %iadd3_o1_not.22 = xor i32 %.4153, -1
  %iadd3_o1_neg.22 = add i32 %iadd3_o1_not.22, 1
  %iadd3_n1.121 = add i32 %iadd3_o1_neg.22, %phi.199
  %imad_tmp.49 = mul i32 %iadd3_n1.120, -8388608
  %imad.60 = add i32 %imad_tmp.49, %phi.200
  %mufu_src_bitcast.11 = bitcast i32 %iadd3_n1.121 to float
  %mufu_rcp.23 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.11)
  %fadd_lhs_fneg.11 = fneg float %mufu_src_bitcast.11
  %fadd.23 = fadd float %fadd_lhs_fneg.11, 0.000000e+00
  %iadd3_o3_not.11 = xor i32 %.4013, -1
  %iadd3_o3_neg.11 = add i32 %iadd3_o3_not.11, 1
  %iadd3_n2.122 = add i32 %.4021, %iadd3_o3_neg.11
  %iadd3_n1.123 = add i32 %iadd3_n2.122, %phi.201
  %ffma.216 = call float @llvm.fma.f32(float %mufu_rcp.23, float %fadd.23, float 1.000000e+00)
  %ffma.217 = call float @llvm.fma.f32(float %mufu_rcp.23, float %ffma.216, float %mufu_rcp.23)
  %ffma_lhs_bitcast.11 = bitcast i32 %imad.60 to float
  %ffma.218 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.11, float %ffma.217, float 0.000000e+00)
  %ffma.219 = call float @llvm.fma.f32(float %fadd.23, float %ffma.218, float %ffma_lhs_bitcast.11)
  %ffma.220 = call float @llvm.fma.f32(float %ffma.217, float %ffma.219, float %ffma.218)
  %ffma.221 = call float @llvm.fma.f32(float %fadd.23, float %ffma.220, float %ffma_lhs_bitcast.11)
  %ffma.222 = call float @llvm.fma.f32(float %ffma.217, float %ffma.221, float %ffma.220)
  %shf_hi_bitcast.35 = bitcast float %ffma.222 to i32
  %.4155 = zext i32 %shf_hi_bitcast.35 to i64
  %.4156 = shl i64 %.4155, 32
  %.4157 = lshr i64 %.4156, 23
  %shf_hi.62 = lshr i64 %.4157, 32
  %shf_result.74 = trunc i64 %shf_hi.62 to i32
  %.4161 = and i32 %shf_result.74, 255
  %imad.61 = add i32 %.4161, %iadd3_n1.123
  %iadd3_n1.124 = add i32 %imad.61, -1
  %isetrp_cmp1.156 = icmp uge i32 %iadd3_n1.124, 254
  br label %BB_2590_72d0

BB_2590_72d0:                                     ; preds = %BB_2590_7180
  %cond_not.103 = xor i1 %isetrp_cmp1.156, true
  br i1 %cond_not.103, label %BB_2590_74e0, label %BB_2590_72e0

BB_2590_72e0:                                     ; preds = %BB_2590_72d0
  %isetrp_cmp1.157 = icmp sgt i32 %imad.61, 254
  br label %BB_2590_72f0

BB_2590_72f0:                                     ; preds = %BB_2590_72e0
  %218 = zext i1 %isetrp_cmp1.157 to i32
  %219 = icmp ne i32 %218, 0
  br i1 %219, label %BB_2590_74b0, label %BB_2590_7300

BB_2590_7300:                                     ; preds = %BB_2590_72f0
  %isetrp_cmp1.158 = icmp sge i32 %imad.61, 1
  br label %BB_2590_7310

BB_2590_7310:                                     ; preds = %BB_2590_7300
  %phi_cast_R2099_bitcast.2 = bitcast i32 %iadd3_n1.123 to float
  br i1 %isetrp_cmp1.158, label %BB_2590_7590, label %BB_2590_7320

BB_2590_7320:                                     ; preds = %BB_2590_7310
  %isetrp_cmp1.159 = icmp sge i32 %imad.61, -24
  %.4175 = and i32 %shf_hi_bitcast.35, -2147483648
  br label %BB_2590_7340

BB_2590_7340:                                     ; preds = %BB_2590_7320
  %cond_not.104 = xor i1 %isetrp_cmp1.159, true
  %phi_cast_R2983_bitcast = bitcast i32 %.4175 to float
  br i1 %cond_not.104, label %BB_2590_7590, label %BB_2590_7350

BB_2590_7350:                                     ; preds = %BB_2590_7340
  %ffma_rz.11 = call float @llvm.nvvm.fma.rz.f(float %ffma.217, float %ffma.221, float %ffma.220)
  %iadd3_n1.125 = add i32 %imad.61, 32
  %lop3_a_bitcast.94 = bitcast float %ffma_rz.11 to i32
  %.4185 = and i32 %lop3_a_bitcast.94, 8388607
  %ffma_rp.11 = call float @llvm.nvvm.fma.rp.f(float %ffma.217, float %ffma.221, float %ffma.220)
  %ffma_rm.11 = call float @llvm.nvvm.fma.rm.f(float %ffma.217, float %ffma.221, float %ffma.220)
  %isetrp_cmp1.161 = icmp ne i32 %imad.61, 0
  %.4200 = or i32 8388608, %.4185
  %iadd3_o1_not.23 = xor i32 %imad.61, -1
  %iadd3_o1_neg.23 = add i32 %iadd3_o1_not.23, 1
  %.4210 = zext i32 %.4200 to i64
  %shf_shift_64.75 = zext i32 %iadd3_n1.125 to i64
  %.4213 = shl i64 %.4210, %shf_shift_64.75
  %shf_result.75 = trunc i64 %.4213 to i32
  %fsetrp_cmp1.71 = fcmp une float %ffma_rp.11, %ffma_rm.11
  %isetrp_cmp1.162 = icmp ne i32 %shf_result.75, 0
  %isetrp_cmp2.162 = and i1 %isetrp_cmp1.162, %isetrp_cmp1.161
  %.4216 = shl i64 %.4210, 32
  %shf_shift_64.76 = zext i32 %iadd3_o1_neg.23 to i64
  %.4217 = lshr i64 %.4216, %shf_shift_64.76
  %shf_hi.63 = lshr i64 %.4217, 32
  %shf_result.76 = trunc i64 %shf_hi.63 to i32
  %lop3_a_cast_zext.47 = zext i1 %fsetrp_cmp1.71 to i32
  %lop3_b_cast_zext.47 = zext i1 %isetrp_cmp2.162 to i32
  %plop3_a_bit.47 = and i32 %lop3_a_cast_zext.47, 1
  %plop3_b_bit.47 = and i32 %lop3_b_cast_zext.47, 1
  %.4218 = xor i32 %plop3_a_bit.47, 1
  %.4219 = xor i32 %plop3_b_bit.47, 1
  %.4221 = and i32 %.4218, %plop3_b_bit.47
  %.4223 = and i32 %plop3_a_bit.47, %.4219
  %.4225 = or i32 %.4221, %.4223
  %.4226 = and i32 %plop3_a_bit.47, %plop3_b_bit.47
  %.4228 = or i32 %.4225, %.4226
  %lop3_pred_cmp.83 = icmp ne i32 %.4228, 0
  %.4230 = zext i32 %shf_result.76 to i64
  %.4231 = shl i64 %.4230, 32
  %.4232 = lshr i64 %.4231, 1
  %shf_hi.64 = lshr i64 %.4232, 32
  %shf_result.77 = trunc i64 %shf_hi.64 to i32
  %sel_pred_not.11 = xor i1 %lop3_pred_cmp.83, true
  %sel.23 = select i1 %sel_pred_not.11, i32 0, i32 1
  %.4233 = xor i32 %sel.23, -1
  %.4235 = xor i32 %shf_result.77, -1
  %.4236 = and i32 %.4233, 1
  %.4237 = and i32 %.4236, %shf_result.77
  %.4245 = and i32 %sel.23, %.4235
  %.4246 = or i32 %.4237, %.4245
  %.4248 = and i32 %sel.23, %shf_result.77
  %.4249 = or i32 %.4246, %.4248
  %.4253 = and i32 %.4249, %shf_result.76
  %imad.62 = add i32 %shf_result.77, %.4253
  %.4258 = xor i32 %imad.62, -1
  %.4259 = xor i32 %.4175, -1
  %.4261 = and i32 %.4258, %.4175
  %.4266 = and i32 %imad.62, %.4259
  %.4268 = or i32 %.4261, %.4266
  %.4272 = and i32 %imad.62, %.4175
  %.4274 = or i32 %.4268, %.4272
  %phi_cast_R2984_bitcast = bitcast i32 %.4274 to float
  %phi_cast_R2103_bitcast = bitcast i32 %.4200 to float
  br label %BB_2590_7590

BB_2590_74b0:                                     ; preds = %BB_2590_72f0
  %.4282 = and i32 %shf_hi_bitcast.35, -2147483648
  %.4297 = or i32 2139095040, %.4282
  %phi_cast_R2986_bitcast = bitcast i32 %.4297 to float
  %phi_cast_R2099_bitcast = bitcast i32 %iadd3_n1.123 to float
  br label %BB_2590_7590

BB_2590_74e0:                                     ; preds = %BB_2590_72d0
  %.4308 = zext i32 %iadd3_n1.123 to i64
  %.4311 = shl i64 %.4308, 23
  %.4312 = and i64 %.4311, 4294967295
  %.4313 = add i64 %.4312, %.4155
  %.4314 = trunc i64 %.4313 to i32
  %phi_cast_R2988_bitcast = bitcast i32 %.4314 to float
  %phi_cast_R2099_bitcast.1 = bitcast i32 %iadd3_n1.123 to float
  br label %BB_2590_7590

BB_2590_7590:                                     ; preds = %BB_2590_74e0, %BB_2590_74b0, %BB_2590_7350, %BB_2590_7340, %BB_2590_7310, %BB_2590_7580, %BB_2590_7560, %BB_2590_7540, %BB_2590_7510
  %phi.202 = phi float [ %phi_cast_R2984_bitcast, %BB_2590_7350 ], [ %phi_cast_R2986_bitcast, %BB_2590_74b0 ], [ %phi_cast_R2988_bitcast, %BB_2590_74e0 ], [ %ffma.222, %BB_2590_7310 ], [ %phi_cast_R2983_bitcast, %BB_2590_7340 ], [ %phi_cast_R2972_bitcast, %BB_2590_7510 ], [ %phi_cast_R2973_bitcast, %BB_2590_7540 ], [ %mufu_rsq.11, %BB_2590_7560 ], [ %fadd.22, %BB_2590_7580 ]
  %phi.203 = phi float [ %phi_cast_R2103_bitcast, %BB_2590_7350 ], [ %phi_cast_R2099_bitcast, %BB_2590_74b0 ], [ %phi_cast_R2099_bitcast.1, %BB_2590_74e0 ], [ %phi_cast_R2099_bitcast.2, %BB_2590_7310 ], [ %phi_cast_R2099_bitcast.2, %BB_2590_7340 ], [ %phi.192, %BB_2590_7510 ], [ %phi.192, %BB_2590_7540 ], [ %phi.192, %BB_2590_7560 ], [ %phi.192, %BB_2590_7580 ]
  br label %BB_25b0

BB_25b0:                                          ; preds = %BB_2590_7590, %BB_2560
  %phi.204 = phi float [ %phi.202, %BB_2590_7590 ], [ %ffma.213, %BB_2560 ]
  %phi.205 = phi float [ %phi.203, %BB_2590_7590 ], [ %phi.192, %BB_2560 ]
  br label %BB_25d0

BB_25d0:                                          ; preds = %BB_25b0, %BB_2470
  %phi.206 = phi float [ %phi.204, %BB_25b0 ], [ %phi.191, %BB_2470 ]
  %phi.207 = phi float [ %phi.205, %BB_25b0 ], [ %phi.192, %BB_2470 ]
  %phi.208 = phi i32 [ %.75, %BB_25b0 ], [ %phi.193, %BB_2470 ]
  %phi.209 = phi float [ %phi.204, %BB_25b0 ], [ %phi.194, %BB_2470 ]
  br label %BB_2600

BB_2600:                                          ; preds = %BB_25d0
  %shfl_activemask.43 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.43 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.43, float %phi.209, i32 11, i32 31)
  br label %BB_2610

BB_2610:                                          ; preds = %BB_2600
  %isetrp_cmp1.163 = icmp uge i32 %tid_x, 12
  %isetrp_cmp1.164 = icmp ne i32 %tid_x, 12
  br label %BB_2640

BB_2640:                                          ; preds = %BB_2610
  %220 = zext i1 %isetrp_cmp1.163 to i32
  %221 = icmp ne i32 %220, 0
  br i1 %221, label %BB_80002640, label %BB_2660

BB_80002640:                                      ; preds = %BB_2640
  %lds_addr_memaddr_offset_add.52 = add i32 %.88, 1452
  %.4322 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.52
  %lds.55 = load volatile float, ptr addrspace(3) %.4322, align 4
  %ffma.223 = call float @llvm.fma.f32(float %shfl_idx.43, float %lds.55, float %phi.195)
  br label %BB_2660

BB_2660:                                          ; preds = %BB_80002640, %BB_2640
  %phi.210 = phi float [ %ffma.223, %BB_80002640 ], [ %phi.195, %BB_2640 ]
  %warp_reconv_mask.11 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.11)
  br i1 %isetrp_cmp1.164, label %BB_27c0, label %BB_2670

BB_2670:                                          ; preds = %BB_2660
  %ffma_addend_fneg.12 = fneg float %phi.210
  %ffma.224 = call float @llvm.fma.f32(float %phi.206, float %phi, float %ffma_addend_fneg.12)
  %lds_addr_memaddr_offset_add.53 = add i32 %.75, 1632
  %.4332 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.53
  %lds.56 = load volatile float, ptr addrspace(3) %.4332, align 4
  %mufu_rcp.24 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.56)
  %fchk_num_bits.12 = bitcast float %ffma.224 to i32
  %fchk_den_bits.12 = bitcast float %lds.56 to i32
  %fchk_aden.12 = and i32 %fchk_den_bits.12, 2147483647
  %fchk_anum.12 = and i32 %fchk_num_bits.12, 2147483647
  %fchk_den_subz.12 = icmp ult i32 %fchk_aden.12, 8388608
  %fchk_den_infnan.12 = icmp uge i32 %fchk_aden.12, 2139095040
  %fchk_num_infnan.12 = icmp uge i32 %fchk_anum.12, 2139095040
  %fchk_den_bad.12 = or i1 %fchk_den_subz.12, %fchk_den_infnan.12
  %fchk_px.12 = or i1 %fchk_den_bad.12, %fchk_num_infnan.12
  %ffma_lhs_fneg.24 = fneg float %lds.56
  %ffma.225 = call float @llvm.fma.f32(float %ffma_lhs_fneg.24, float %mufu_rcp.24, float 1.000000e+00)
  %ffma.226 = call float @llvm.fma.f32(float %mufu_rcp.24, float %ffma.225, float %mufu_rcp.24)
  %ffma.227 = call float @llvm.fma.f32(float %ffma.224, float %ffma.226, float 0.000000e+00)
  %ffma.228 = call float @llvm.fma.f32(float %ffma_lhs_fneg.24, float %ffma.227, float %ffma.224)
  %ffma.229 = call float @llvm.fma.f32(float %ffma.226, float %ffma.228, float %ffma.227)
  br label %BB_2750

BB_2750:                                          ; preds = %BB_2670
  %cond_not.105 = xor i1 %fchk_px.12, true
  br i1 %cond_not.105, label %BB_27a0, label %BB_2780_6f40

BB_2780_6f40:                                     ; preds = %BB_2750
  %.4336 = zext i32 %fchk_den_bits.12 to i64
  %.4337 = shl i64 %.4336, 32
  %.4338 = lshr i64 %.4337, 23
  %shf_hi.65 = lshr i64 %.4338, 32
  %shf_result.78 = trunc i64 %shf_hi.65 to i32
  %.4340 = zext i32 %fchk_num_bits.12 to i64
  %.4341 = shl i64 %.4340, 32
  %.4342 = lshr i64 %.4341, 23
  %shf_hi.66 = lshr i64 %.4342, 32
  %shf_result.79 = trunc i64 %shf_hi.66 to i32
  %.4346 = and i32 %shf_result.78, 255
  %.4354 = and i32 %shf_result.79, 255
  %iadd3_n1.127 = add i32 %.4346, -1
  %iadd3_n1.128 = add i32 %.4354, -1
  %isetrp_cmp1.165 = icmp ugt i32 %iadd3_n1.127, 253
  %isetrp_cmp1.166 = icmp ugt i32 %iadd3_n1.128, 253
  %isetrp_cmp2.166 = or i1 %isetrp_cmp1.166, %isetrp_cmp1.165
  br label %BB_2780_6fd0

BB_2780_6fd0:                                     ; preds = %BB_2780_6f40
  %cond_not.106 = xor i1 %isetrp_cmp2.166, true
  br i1 %cond_not.106, label %BB_2780_80006fd0, label %BB_2780_6ff0

BB_2780_6ff0:                                     ; preds = %BB_2780_6fd0
  %fsetrp_lhs_fabs.60 = call float @llvm.nvvm.fabs.f(float %ffma.224)
  %fsetrp_cmp1.72 = fcmp ugt float %fsetrp_lhs_fabs.60, 0x7FF0000000000000
  %fsetrp_lhs_fabs.61 = call float @llvm.nvvm.fabs.f(float %lds.56)
  %fsetrp_cmp1.73 = fcmp ugt float %fsetrp_lhs_fabs.61, 0x7FF0000000000000
  %lop3_a_cast_zext.48 = zext i1 %fsetrp_cmp1.72 to i32
  %lop3_b_cast_zext.48 = zext i1 %fsetrp_cmp1.73 to i32
  %plop3_a_bit.48 = and i32 %lop3_a_cast_zext.48, 1
  %plop3_b_bit.48 = and i32 %lop3_b_cast_zext.48, 1
  %.4361 = xor i32 %plop3_a_bit.48, 1
  %.4362 = xor i32 %plop3_b_bit.48, 1
  %.4364 = and i32 %.4361, %plop3_b_bit.48
  %.4366 = and i32 %plop3_a_bit.48, %.4362
  %.4368 = or i32 %.4364, %.4366
  %.4369 = and i32 %plop3_a_bit.48, %plop3_b_bit.48
  %.4371 = or i32 %.4368, %.4369
  %lop3_pred_cmp.84 = icmp ne i32 %.4371, 0
  br label %BB_2780_7020

BB_2780_7020:                                     ; preds = %BB_2780_6ff0
  %222 = zext i1 %lop3_pred_cmp.84 to i32
  %223 = icmp ne i32 %222, 0
  br i1 %223, label %BB_2780_7580, label %BB_2780_7030

BB_2780_7030:                                     ; preds = %BB_2780_7020
  %.4374 = xor i32 %fchk_den_bits.12, -1
  %.4376 = xor i32 %fchk_num_bits.12, -1
  %.4377 = and i32 %.4374, 2147483647
  %.4378 = and i32 %.4377, %fchk_num_bits.12
  %.4380 = and i32 %fchk_aden.12, %.4376
  %.4381 = or i32 %.4378, %.4380
  %.4383 = and i32 %fchk_aden.12, %fchk_num_bits.12
  %.4384 = or i32 %.4381, %.4383
  %lop3_pred_cmp.85 = icmp ne i32 %.4384, 0
  br label %BB_2780_7040

BB_2780_7040:                                     ; preds = %BB_2780_7030
  %cond_not.107 = xor i1 %lop3_pred_cmp.85, true
  br i1 %cond_not.107, label %BB_2780_7560, label %BB_2780_7050

BB_2780_7050:                                     ; preds = %BB_2780_7040
  %fsetrp_cmp1.74 = fcmp une float %fsetrp_lhs_fabs.60, 0x7FF0000000000000
  %fsetrp_cmp1.75 = fcmp une float %fsetrp_lhs_fabs.61, 0x7FF0000000000000
  br label %BB_2780_7080

BB_2780_7080:                                     ; preds = %BB_2780_7050
  %cond_not.108 = xor i1 %fsetrp_cmp1.75, true
  br i1 %cond_not.108, label %BB_2780_80007080, label %BB_2780_7090

BB_2780_80007080:                                 ; preds = %BB_2780_7080
  %bra_cond_not.12 = xor i1 %fsetrp_cmp1.74, true
  br i1 %bra_cond_not.12, label %BB_2780_7560, label %BB_2780_7090

BB_2780_7090:                                     ; preds = %BB_2780_80007080, %BB_2780_7080
  %lop3_pred_cmp.86 = icmp ne i32 %fchk_anum.12, 0
  %lop3_a_cast_zext.49 = zext i1 %fsetrp_cmp1.75 to i32
  %lop3_b_cast_zext.49 = zext i1 %lop3_pred_cmp.86 to i32
  %plop3_a_bit.49 = and i32 %lop3_a_cast_zext.49, 1
  %plop3_b_bit.49 = and i32 %lop3_b_cast_zext.49, 1
  %.4398 = xor i32 %plop3_a_bit.49, 1
  %.4399 = xor i32 %plop3_b_bit.49, 1
  %.4401 = and i32 %.4398, %.4399
  %.4403 = and i32 %.4398, %plop3_b_bit.49
  %.4405 = or i32 %.4401, %.4403
  %.4406 = and i32 %plop3_a_bit.49, %.4399
  %.4408 = or i32 %.4405, %.4406
  %lop3_pred_cmp.87 = icmp ne i32 %.4408, 0
  br label %BB_2780_70b0

BB_2780_70b0:                                     ; preds = %BB_2780_7090
  %224 = zext i1 %lop3_pred_cmp.87 to i32
  %225 = icmp ne i32 %224, 0
  br i1 %225, label %BB_2780_7540, label %BB_2780_70c0

BB_2780_70c0:                                     ; preds = %BB_2780_70b0
  %lop3_pred_cmp.88 = icmp ne i32 %fchk_aden.12, 0
  %lop3_a_cast_zext.50 = zext i1 %fsetrp_cmp1.74 to i32
  %lop3_b_cast_zext.50 = zext i1 %lop3_pred_cmp.88 to i32
  %plop3_a_bit.50 = and i32 %lop3_a_cast_zext.50, 1
  %plop3_b_bit.50 = and i32 %lop3_b_cast_zext.50, 1
  %.4419 = xor i32 %plop3_a_bit.50, 1
  %.4420 = xor i32 %plop3_b_bit.50, 1
  %.4422 = and i32 %.4419, %.4420
  %.4424 = and i32 %.4419, %plop3_b_bit.50
  %.4426 = or i32 %.4422, %.4424
  %.4427 = and i32 %plop3_a_bit.50, %.4420
  %.4429 = or i32 %.4426, %.4427
  %lop3_pred_cmp.89 = icmp ne i32 %.4429, 0
  br label %BB_2780_70e0

BB_2780_70e0:                                     ; preds = %BB_2780_70c0
  %226 = zext i1 %lop3_pred_cmp.89 to i32
  %227 = icmp ne i32 %226, 0
  br i1 %227, label %BB_2780_7510, label %BB_2780_70f0

BB_2780_70f0:                                     ; preds = %BB_2780_70e0
  %isetrp_cmp1.167 = icmp sge i32 %iadd3_n1.128, 0
  %isetrp_cmp1.168 = icmp sge i32 %iadd3_n1.127, 0
  br label %BB_2780_7130

BB_2780_7130:                                     ; preds = %BB_2780_70f0
  %228 = zext i1 %isetrp_cmp1.167 to i32
  %229 = icmp ne i32 %228, 0
  br i1 %229, label %BB_2780_80007130, label %BB_2780_7140

BB_2780_80007130:                                 ; preds = %BB_2780_7130
  br label %BB_2780_7140

BB_2780_7140:                                     ; preds = %BB_2780_80007130, %BB_2780_7130
  %phi.211 = phi i32 [ 0, %BB_2780_80007130 ], [ %iadd3_n1.127, %BB_2780_7130 ]
  %cond_not.109 = xor i1 %isetrp_cmp1.167, true
  br i1 %cond_not.109, label %BB_2780_80007140, label %BB_2780_7160

BB_2780_80007140:                                 ; preds = %BB_2780_7140
  %ffma.230 = call float @llvm.fma.f32(float %ffma.224, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R2993_bitcast = bitcast float %ffma.230 to i32
  br label %BB_2780_7160

BB_2780_7160:                                     ; preds = %BB_2780_80007140, %BB_2780_7140
  %phi.212 = phi i32 [ %phi_cast_R2993_bitcast, %BB_2780_80007140 ], [ %fchk_num_bits.12, %BB_2780_7140 ]
  %phi.213 = phi i32 [ -64, %BB_2780_80007140 ], [ %phi.211, %BB_2780_7140 ]
  %cond_not.110 = xor i1 %isetrp_cmp1.168, true
  br i1 %cond_not.110, label %BB_2780_80007160, label %BB_2780_7180

BB_2780_80007160:                                 ; preds = %BB_2780_7160
  %ffma.231 = call float @llvm.fma.f32(float %lds.56, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.25 = add i32 %phi.213, 64
  %phi_cast_R540_bitcast = bitcast float %ffma.231 to i32
  br label %BB_2780_7180

BB_2780_7510:                                     ; preds = %BB_2780_70e0
  %.4442 = and i32 %.4374, -2147483648
  %.4443 = and i32 %.4442, %fchk_num_bits.12
  %.4444 = and i32 %fchk_den_bits.12, -2147483648
  %.4445 = and i32 %.4444, %.4376
  %.4446 = or i32 %.4443, %.4445
  %.4447 = xor i32 %.4446, -1
  %.4450 = and i32 %.4447, 2139095040
  %.4457 = or i32 %.4450, %.4446
  %phi_cast_R2996_bitcast = bitcast i32 %.4457 to float
  br label %BB_2780_7590

BB_2780_7540:                                     ; preds = %BB_2780_70b0
  %.4471 = and i32 %.4374, -2147483648
  %.4472 = and i32 %.4471, %fchk_num_bits.12
  %.4473 = and i32 %fchk_den_bits.12, -2147483648
  %.4474 = and i32 %.4473, %.4376
  %.4475 = or i32 %.4472, %.4474
  %phi_cast_R2997_bitcast = bitcast i32 %.4475 to float
  br label %BB_2780_7590

BB_2780_7560:                                     ; preds = %BB_2780_80007080, %BB_2780_7040
  %mufu_rsq.12 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_2780_7590

BB_2780_7580:                                     ; preds = %BB_2780_7020
  %fadd.24 = fadd float %ffma.224, %lds.56
  br label %BB_2780_7590

BB_2780_80006fd0:                                 ; preds = %BB_2780_6fd0
  br label %BB_2780_7180

BB_2780_7180:                                     ; preds = %BB_2780_80006fd0, %BB_2780_80007160, %BB_2780_7160
  %phi.214 = phi i32 [ %fchk_den_bits.12, %BB_2780_80006fd0 ], [ %phi_cast_R540_bitcast, %BB_2780_80007160 ], [ %fchk_den_bits.12, %BB_2780_7160 ]
  %phi.215 = phi i32 [ %fchk_num_bits.12, %BB_2780_80006fd0 ], [ %phi.212, %BB_2780_80007160 ], [ %phi.212, %BB_2780_7160 ]
  %phi.216 = phi i32 [ 0, %BB_2780_80006fd0 ], [ %viadd.25, %BB_2780_80007160 ], [ %phi.213, %BB_2780_7160 ]
  %.4480 = zext i32 %.4346 to i64
  %.4483 = shl i64 %.4480, 23
  %.4484 = and i64 %.4483, 4294967295
  %.4485 = add i64 %.4484, 3229614080
  %.4486 = trunc i64 %.4485 to i32
  %iadd3_n1.130 = add i32 %.4354, -127
  %iadd3_o1_not.24 = xor i32 %.4486, -1
  %iadd3_o1_neg.24 = add i32 %iadd3_o1_not.24, 1
  %iadd3_n1.131 = add i32 %iadd3_o1_neg.24, %phi.214
  %imad_tmp.52 = mul i32 %iadd3_n1.130, -8388608
  %imad.63 = add i32 %imad_tmp.52, %phi.215
  %mufu_src_bitcast.12 = bitcast i32 %iadd3_n1.131 to float
  %mufu_rcp.25 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.12)
  %fadd_lhs_fneg.12 = fneg float %mufu_src_bitcast.12
  %fadd.25 = fadd float %fadd_lhs_fneg.12, 0.000000e+00
  %iadd3_o3_not.12 = xor i32 %.4346, -1
  %iadd3_o3_neg.12 = add i32 %iadd3_o3_not.12, 1
  %iadd3_n2.132 = add i32 %.4354, %iadd3_o3_neg.12
  %iadd3_n1.133 = add i32 %iadd3_n2.132, %phi.216
  %ffma.232 = call float @llvm.fma.f32(float %mufu_rcp.25, float %fadd.25, float 1.000000e+00)
  %ffma.233 = call float @llvm.fma.f32(float %mufu_rcp.25, float %ffma.232, float %mufu_rcp.25)
  %ffma_lhs_bitcast.12 = bitcast i32 %imad.63 to float
  %ffma.234 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.12, float %ffma.233, float 0.000000e+00)
  %ffma.235 = call float @llvm.fma.f32(float %fadd.25, float %ffma.234, float %ffma_lhs_bitcast.12)
  %ffma.236 = call float @llvm.fma.f32(float %ffma.233, float %ffma.235, float %ffma.234)
  %ffma.237 = call float @llvm.fma.f32(float %fadd.25, float %ffma.236, float %ffma_lhs_bitcast.12)
  %ffma.238 = call float @llvm.fma.f32(float %ffma.233, float %ffma.237, float %ffma.236)
  %shf_hi_bitcast.38 = bitcast float %ffma.238 to i32
  %.4488 = zext i32 %shf_hi_bitcast.38 to i64
  %.4489 = shl i64 %.4488, 32
  %.4490 = lshr i64 %.4489, 23
  %shf_hi.67 = lshr i64 %.4490, 32
  %shf_result.80 = trunc i64 %shf_hi.67 to i32
  %.4494 = and i32 %shf_result.80, 255
  %imad.64 = add i32 %.4494, %iadd3_n1.133
  %iadd3_n1.134 = add i32 %imad.64, -1
  %isetrp_cmp1.169 = icmp uge i32 %iadd3_n1.134, 254
  br label %BB_2780_72d0

BB_2780_72d0:                                     ; preds = %BB_2780_7180
  %cond_not.111 = xor i1 %isetrp_cmp1.169, true
  br i1 %cond_not.111, label %BB_2780_74e0, label %BB_2780_72e0

BB_2780_72e0:                                     ; preds = %BB_2780_72d0
  %isetrp_cmp1.170 = icmp sgt i32 %imad.64, 254
  br label %BB_2780_72f0

BB_2780_72f0:                                     ; preds = %BB_2780_72e0
  %230 = zext i1 %isetrp_cmp1.170 to i32
  %231 = icmp ne i32 %230, 0
  br i1 %231, label %BB_2780_74b0, label %BB_2780_7300

BB_2780_7300:                                     ; preds = %BB_2780_72f0
  %isetrp_cmp1.171 = icmp sge i32 %imad.64, 1
  br label %BB_2780_7310

BB_2780_7310:                                     ; preds = %BB_2780_7300
  %phi_cast_R2110_bitcast.2 = bitcast i32 %iadd3_n1.133 to float
  br i1 %isetrp_cmp1.171, label %BB_2780_7590, label %BB_2780_7320

BB_2780_7320:                                     ; preds = %BB_2780_7310
  %isetrp_cmp1.172 = icmp sge i32 %imad.64, -24
  %.4508 = and i32 %shf_hi_bitcast.38, -2147483648
  br label %BB_2780_7340

BB_2780_7340:                                     ; preds = %BB_2780_7320
  %cond_not.112 = xor i1 %isetrp_cmp1.172, true
  %phi_cast_R3005_bitcast = bitcast i32 %.4508 to float
  br i1 %cond_not.112, label %BB_2780_7590, label %BB_2780_7350

BB_2780_7350:                                     ; preds = %BB_2780_7340
  %ffma_rz.12 = call float @llvm.nvvm.fma.rz.f(float %ffma.233, float %ffma.237, float %ffma.236)
  %iadd3_n1.135 = add i32 %imad.64, 32
  %lop3_a_bitcast.102 = bitcast float %ffma_rz.12 to i32
  %.4518 = and i32 %lop3_a_bitcast.102, 8388607
  %ffma_rp.12 = call float @llvm.nvvm.fma.rp.f(float %ffma.233, float %ffma.237, float %ffma.236)
  %ffma_rm.12 = call float @llvm.nvvm.fma.rm.f(float %ffma.233, float %ffma.237, float %ffma.236)
  %isetrp_cmp1.174 = icmp ne i32 %imad.64, 0
  %.4533 = or i32 8388608, %.4518
  %iadd3_o1_not.25 = xor i32 %imad.64, -1
  %iadd3_o1_neg.25 = add i32 %iadd3_o1_not.25, 1
  %.4543 = zext i32 %.4533 to i64
  %shf_shift_64.81 = zext i32 %iadd3_n1.135 to i64
  %.4546 = shl i64 %.4543, %shf_shift_64.81
  %shf_result.81 = trunc i64 %.4546 to i32
  %fsetrp_cmp1.77 = fcmp une float %ffma_rp.12, %ffma_rm.12
  %isetrp_cmp1.175 = icmp ne i32 %shf_result.81, 0
  %isetrp_cmp2.175 = and i1 %isetrp_cmp1.175, %isetrp_cmp1.174
  %.4549 = shl i64 %.4543, 32
  %shf_shift_64.82 = zext i32 %iadd3_o1_neg.25 to i64
  %.4550 = lshr i64 %.4549, %shf_shift_64.82
  %shf_hi.68 = lshr i64 %.4550, 32
  %shf_result.82 = trunc i64 %shf_hi.68 to i32
  %lop3_a_cast_zext.51 = zext i1 %fsetrp_cmp1.77 to i32
  %lop3_b_cast_zext.51 = zext i1 %isetrp_cmp2.175 to i32
  %plop3_a_bit.51 = and i32 %lop3_a_cast_zext.51, 1
  %plop3_b_bit.51 = and i32 %lop3_b_cast_zext.51, 1
  %.4551 = xor i32 %plop3_a_bit.51, 1
  %.4552 = xor i32 %plop3_b_bit.51, 1
  %.4554 = and i32 %.4551, %plop3_b_bit.51
  %.4556 = and i32 %plop3_a_bit.51, %.4552
  %.4558 = or i32 %.4554, %.4556
  %.4559 = and i32 %plop3_a_bit.51, %plop3_b_bit.51
  %.4561 = or i32 %.4558, %.4559
  %lop3_pred_cmp.90 = icmp ne i32 %.4561, 0
  %.4563 = zext i32 %shf_result.82 to i64
  %.4564 = shl i64 %.4563, 32
  %.4565 = lshr i64 %.4564, 1
  %shf_hi.69 = lshr i64 %.4565, 32
  %shf_result.83 = trunc i64 %shf_hi.69 to i32
  %sel_pred_not.12 = xor i1 %lop3_pred_cmp.90, true
  %sel.25 = select i1 %sel_pred_not.12, i32 0, i32 1
  %.4566 = xor i32 %sel.25, -1
  %.4568 = xor i32 %shf_result.83, -1
  %.4569 = and i32 %.4566, 1
  %.4570 = and i32 %.4569, %shf_result.83
  %.4578 = and i32 %sel.25, %.4568
  %.4579 = or i32 %.4570, %.4578
  %.4581 = and i32 %sel.25, %shf_result.83
  %.4582 = or i32 %.4579, %.4581
  %.4586 = and i32 %.4582, %shf_result.82
  %imad.65 = add i32 %shf_result.83, %.4586
  %.4591 = xor i32 %imad.65, -1
  %.4592 = xor i32 %.4508, -1
  %.4594 = and i32 %.4591, %.4508
  %.4599 = and i32 %imad.65, %.4592
  %.4601 = or i32 %.4594, %.4599
  %.4605 = and i32 %imad.65, %.4508
  %.4607 = or i32 %.4601, %.4605
  %phi_cast_R3007_bitcast = bitcast i32 %.4607 to float
  %phi_cast_R2114_bitcast = bitcast i32 %.4533 to float
  br label %BB_2780_7590

BB_2780_74b0:                                     ; preds = %BB_2780_72f0
  %.4615 = and i32 %shf_hi_bitcast.38, -2147483648
  %.4630 = or i32 2139095040, %.4615
  %phi_cast_R3010_bitcast = bitcast i32 %.4630 to float
  %phi_cast_R2110_bitcast = bitcast i32 %iadd3_n1.133 to float
  br label %BB_2780_7590

BB_2780_74e0:                                     ; preds = %BB_2780_72d0
  %.4641 = zext i32 %iadd3_n1.133 to i64
  %.4644 = shl i64 %.4641, 23
  %.4645 = and i64 %.4644, 4294967295
  %.4646 = add i64 %.4645, %.4488
  %.4647 = trunc i64 %.4646 to i32
  %phi_cast_R3011_bitcast = bitcast i32 %.4647 to float
  %phi_cast_R2110_bitcast.1 = bitcast i32 %iadd3_n1.133 to float
  br label %BB_2780_7590

BB_2780_7590:                                     ; preds = %BB_2780_74e0, %BB_2780_74b0, %BB_2780_7350, %BB_2780_7340, %BB_2780_7310, %BB_2780_7580, %BB_2780_7560, %BB_2780_7540, %BB_2780_7510
  %phi.217 = phi float [ %phi_cast_R3007_bitcast, %BB_2780_7350 ], [ %phi_cast_R3010_bitcast, %BB_2780_74b0 ], [ %phi_cast_R3011_bitcast, %BB_2780_74e0 ], [ %ffma.238, %BB_2780_7310 ], [ %phi_cast_R3005_bitcast, %BB_2780_7340 ], [ %phi_cast_R2996_bitcast, %BB_2780_7510 ], [ %phi_cast_R2997_bitcast, %BB_2780_7540 ], [ %mufu_rsq.12, %BB_2780_7560 ], [ %fadd.24, %BB_2780_7580 ]
  %phi.218 = phi float [ %phi_cast_R2114_bitcast, %BB_2780_7350 ], [ %phi_cast_R2110_bitcast, %BB_2780_74b0 ], [ %phi_cast_R2110_bitcast.1, %BB_2780_74e0 ], [ %phi_cast_R2110_bitcast.2, %BB_2780_7310 ], [ %phi_cast_R2110_bitcast.2, %BB_2780_7340 ], [ %phi.207, %BB_2780_7510 ], [ %phi.207, %BB_2780_7540 ], [ %phi.207, %BB_2780_7560 ], [ %phi.207, %BB_2780_7580 ]
  br label %BB_27a0

BB_27a0:                                          ; preds = %BB_2780_7590, %BB_2750
  %phi.219 = phi float [ %phi.217, %BB_2780_7590 ], [ %ffma.229, %BB_2750 ]
  %phi.220 = phi float [ %phi.218, %BB_2780_7590 ], [ %phi.207, %BB_2750 ]
  br label %BB_27c0

BB_27c0:                                          ; preds = %BB_27a0, %BB_2660
  %phi.221 = phi float [ %phi.219, %BB_27a0 ], [ %phi.206, %BB_2660 ]
  %phi.222 = phi float [ %phi.220, %BB_27a0 ], [ %phi.207, %BB_2660 ]
  %phi.223 = phi i32 [ %.75, %BB_27a0 ], [ %phi.208, %BB_2660 ]
  %phi.224 = phi float [ %phi.219, %BB_27a0 ], [ %phi.209, %BB_2660 ]
  br label %BB_27f0

BB_27f0:                                          ; preds = %BB_27c0
  %shfl_activemask.44 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.44 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.44, float %phi.224, i32 12, i32 31)
  br label %BB_2800

BB_2800:                                          ; preds = %BB_27f0
  %isetrp_cmp1.176 = icmp uge i32 %tid_x, 13
  %isetrp_cmp1.177 = icmp ne i32 %tid_x, 13
  br label %BB_2830

BB_2830:                                          ; preds = %BB_2800
  %232 = zext i1 %isetrp_cmp1.176 to i32
  %233 = icmp ne i32 %232, 0
  br i1 %233, label %BB_80002830, label %BB_2850

BB_80002830:                                      ; preds = %BB_2830
  %lds_addr_memaddr_offset_add.54 = add i32 %.88, 1584
  %.4655 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.54
  %lds.57 = load volatile float, ptr addrspace(3) %.4655, align 4
  %ffma.239 = call float @llvm.fma.f32(float %shfl_idx.44, float %lds.57, float %phi.210)
  br label %BB_2850

BB_2850:                                          ; preds = %BB_80002830, %BB_2830
  %phi.225 = phi float [ %ffma.239, %BB_80002830 ], [ %phi.210, %BB_2830 ]
  %warp_reconv_mask.12 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.12)
  br i1 %isetrp_cmp1.177, label %BB_29b0, label %BB_2860

BB_2860:                                          ; preds = %BB_2850
  %ffma_addend_fneg.13 = fneg float %phi.225
  %ffma.240 = call float @llvm.fma.f32(float %phi.221, float %phi, float %ffma_addend_fneg.13)
  %lds_addr_memaddr_offset_add.55 = add i32 %.75, 1768
  %.4665 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.55
  %lds.58 = load volatile float, ptr addrspace(3) %.4665, align 4
  %mufu_rcp.26 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.58)
  %fchk_num_bits.13 = bitcast float %ffma.240 to i32
  %fchk_den_bits.13 = bitcast float %lds.58 to i32
  %fchk_aden.13 = and i32 %fchk_den_bits.13, 2147483647
  %fchk_anum.13 = and i32 %fchk_num_bits.13, 2147483647
  %fchk_den_subz.13 = icmp ult i32 %fchk_aden.13, 8388608
  %fchk_den_infnan.13 = icmp uge i32 %fchk_aden.13, 2139095040
  %fchk_num_infnan.13 = icmp uge i32 %fchk_anum.13, 2139095040
  %fchk_den_bad.13 = or i1 %fchk_den_subz.13, %fchk_den_infnan.13
  %fchk_px.13 = or i1 %fchk_den_bad.13, %fchk_num_infnan.13
  %ffma_lhs_fneg.26 = fneg float %lds.58
  %ffma.241 = call float @llvm.fma.f32(float %ffma_lhs_fneg.26, float %mufu_rcp.26, float 1.000000e+00)
  %ffma.242 = call float @llvm.fma.f32(float %mufu_rcp.26, float %ffma.241, float %mufu_rcp.26)
  %ffma.243 = call float @llvm.fma.f32(float %ffma.240, float %ffma.242, float 0.000000e+00)
  %ffma.244 = call float @llvm.fma.f32(float %ffma_lhs_fneg.26, float %ffma.243, float %ffma.240)
  %ffma.245 = call float @llvm.fma.f32(float %ffma.242, float %ffma.244, float %ffma.243)
  br label %BB_2940

BB_2940:                                          ; preds = %BB_2860
  %cond_not.113 = xor i1 %fchk_px.13, true
  br i1 %cond_not.113, label %BB_2990, label %BB_2970_6f40

BB_2970_6f40:                                     ; preds = %BB_2940
  %.4669 = zext i32 %fchk_den_bits.13 to i64
  %.4670 = shl i64 %.4669, 32
  %.4671 = lshr i64 %.4670, 23
  %shf_hi.70 = lshr i64 %.4671, 32
  %shf_result.84 = trunc i64 %shf_hi.70 to i32
  %.4673 = zext i32 %fchk_num_bits.13 to i64
  %.4674 = shl i64 %.4673, 32
  %.4675 = lshr i64 %.4674, 23
  %shf_hi.71 = lshr i64 %.4675, 32
  %shf_result.85 = trunc i64 %shf_hi.71 to i32
  %.4679 = and i32 %shf_result.84, 255
  %.4687 = and i32 %shf_result.85, 255
  %iadd3_n1.137 = add i32 %.4679, -1
  %iadd3_n1.138 = add i32 %.4687, -1
  %isetrp_cmp1.178 = icmp ugt i32 %iadd3_n1.137, 253
  %isetrp_cmp1.179 = icmp ugt i32 %iadd3_n1.138, 253
  %isetrp_cmp2.179 = or i1 %isetrp_cmp1.179, %isetrp_cmp1.178
  br label %BB_2970_6fd0

BB_2970_6fd0:                                     ; preds = %BB_2970_6f40
  %cond_not.114 = xor i1 %isetrp_cmp2.179, true
  br i1 %cond_not.114, label %BB_2970_80006fd0, label %BB_2970_6ff0

BB_2970_6ff0:                                     ; preds = %BB_2970_6fd0
  %fsetrp_lhs_fabs.65 = call float @llvm.nvvm.fabs.f(float %ffma.240)
  %fsetrp_cmp1.78 = fcmp ugt float %fsetrp_lhs_fabs.65, 0x7FF0000000000000
  %fsetrp_lhs_fabs.66 = call float @llvm.nvvm.fabs.f(float %lds.58)
  %fsetrp_cmp1.79 = fcmp ugt float %fsetrp_lhs_fabs.66, 0x7FF0000000000000
  %lop3_a_cast_zext.52 = zext i1 %fsetrp_cmp1.78 to i32
  %lop3_b_cast_zext.52 = zext i1 %fsetrp_cmp1.79 to i32
  %plop3_a_bit.52 = and i32 %lop3_a_cast_zext.52, 1
  %plop3_b_bit.52 = and i32 %lop3_b_cast_zext.52, 1
  %.4694 = xor i32 %plop3_a_bit.52, 1
  %.4695 = xor i32 %plop3_b_bit.52, 1
  %.4697 = and i32 %.4694, %plop3_b_bit.52
  %.4699 = and i32 %plop3_a_bit.52, %.4695
  %.4701 = or i32 %.4697, %.4699
  %.4702 = and i32 %plop3_a_bit.52, %plop3_b_bit.52
  %.4704 = or i32 %.4701, %.4702
  %lop3_pred_cmp.91 = icmp ne i32 %.4704, 0
  br label %BB_2970_7020

BB_2970_7020:                                     ; preds = %BB_2970_6ff0
  %234 = zext i1 %lop3_pred_cmp.91 to i32
  %235 = icmp ne i32 %234, 0
  br i1 %235, label %BB_2970_7580, label %BB_2970_7030

BB_2970_7030:                                     ; preds = %BB_2970_7020
  %.4707 = xor i32 %fchk_den_bits.13, -1
  %.4709 = xor i32 %fchk_num_bits.13, -1
  %.4710 = and i32 %.4707, 2147483647
  %.4711 = and i32 %.4710, %fchk_num_bits.13
  %.4713 = and i32 %fchk_aden.13, %.4709
  %.4714 = or i32 %.4711, %.4713
  %.4716 = and i32 %fchk_aden.13, %fchk_num_bits.13
  %.4717 = or i32 %.4714, %.4716
  %lop3_pred_cmp.92 = icmp ne i32 %.4717, 0
  br label %BB_2970_7040

BB_2970_7040:                                     ; preds = %BB_2970_7030
  %cond_not.115 = xor i1 %lop3_pred_cmp.92, true
  br i1 %cond_not.115, label %BB_2970_7560, label %BB_2970_7050

BB_2970_7050:                                     ; preds = %BB_2970_7040
  %fsetrp_cmp1.80 = fcmp une float %fsetrp_lhs_fabs.65, 0x7FF0000000000000
  %fsetrp_cmp1.81 = fcmp une float %fsetrp_lhs_fabs.66, 0x7FF0000000000000
  br label %BB_2970_7080

BB_2970_7080:                                     ; preds = %BB_2970_7050
  %cond_not.116 = xor i1 %fsetrp_cmp1.81, true
  br i1 %cond_not.116, label %BB_2970_80007080, label %BB_2970_7090

BB_2970_80007080:                                 ; preds = %BB_2970_7080
  %bra_cond_not.13 = xor i1 %fsetrp_cmp1.80, true
  br i1 %bra_cond_not.13, label %BB_2970_7560, label %BB_2970_7090

BB_2970_7090:                                     ; preds = %BB_2970_80007080, %BB_2970_7080
  %lop3_pred_cmp.93 = icmp ne i32 %fchk_anum.13, 0
  %lop3_a_cast_zext.53 = zext i1 %fsetrp_cmp1.81 to i32
  %lop3_b_cast_zext.53 = zext i1 %lop3_pred_cmp.93 to i32
  %plop3_a_bit.53 = and i32 %lop3_a_cast_zext.53, 1
  %plop3_b_bit.53 = and i32 %lop3_b_cast_zext.53, 1
  %.4731 = xor i32 %plop3_a_bit.53, 1
  %.4732 = xor i32 %plop3_b_bit.53, 1
  %.4734 = and i32 %.4731, %.4732
  %.4736 = and i32 %.4731, %plop3_b_bit.53
  %.4738 = or i32 %.4734, %.4736
  %.4739 = and i32 %plop3_a_bit.53, %.4732
  %.4741 = or i32 %.4738, %.4739
  %lop3_pred_cmp.94 = icmp ne i32 %.4741, 0
  br label %BB_2970_70b0

BB_2970_70b0:                                     ; preds = %BB_2970_7090
  %236 = zext i1 %lop3_pred_cmp.94 to i32
  %237 = icmp ne i32 %236, 0
  br i1 %237, label %BB_2970_7540, label %BB_2970_70c0

BB_2970_70c0:                                     ; preds = %BB_2970_70b0
  %lop3_pred_cmp.95 = icmp ne i32 %fchk_aden.13, 0
  %lop3_a_cast_zext.54 = zext i1 %fsetrp_cmp1.80 to i32
  %lop3_b_cast_zext.54 = zext i1 %lop3_pred_cmp.95 to i32
  %plop3_a_bit.54 = and i32 %lop3_a_cast_zext.54, 1
  %plop3_b_bit.54 = and i32 %lop3_b_cast_zext.54, 1
  %.4752 = xor i32 %plop3_a_bit.54, 1
  %.4753 = xor i32 %plop3_b_bit.54, 1
  %.4755 = and i32 %.4752, %.4753
  %.4757 = and i32 %.4752, %plop3_b_bit.54
  %.4759 = or i32 %.4755, %.4757
  %.4760 = and i32 %plop3_a_bit.54, %.4753
  %.4762 = or i32 %.4759, %.4760
  %lop3_pred_cmp.96 = icmp ne i32 %.4762, 0
  br label %BB_2970_70e0

BB_2970_70e0:                                     ; preds = %BB_2970_70c0
  %238 = zext i1 %lop3_pred_cmp.96 to i32
  %239 = icmp ne i32 %238, 0
  br i1 %239, label %BB_2970_7510, label %BB_2970_70f0

BB_2970_70f0:                                     ; preds = %BB_2970_70e0
  %isetrp_cmp1.180 = icmp sge i32 %iadd3_n1.138, 0
  %isetrp_cmp1.181 = icmp sge i32 %iadd3_n1.137, 0
  br label %BB_2970_7130

BB_2970_7130:                                     ; preds = %BB_2970_70f0
  %240 = zext i1 %isetrp_cmp1.180 to i32
  %241 = icmp ne i32 %240, 0
  br i1 %241, label %BB_2970_80007130, label %BB_2970_7140

BB_2970_80007130:                                 ; preds = %BB_2970_7130
  br label %BB_2970_7140

BB_2970_7140:                                     ; preds = %BB_2970_80007130, %BB_2970_7130
  %phi.226 = phi i32 [ 0, %BB_2970_80007130 ], [ %iadd3_n1.137, %BB_2970_7130 ]
  %cond_not.117 = xor i1 %isetrp_cmp1.180, true
  br i1 %cond_not.117, label %BB_2970_80007140, label %BB_2970_7160

BB_2970_80007140:                                 ; preds = %BB_2970_7140
  %ffma.246 = call float @llvm.fma.f32(float %ffma.240, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R3016_bitcast = bitcast float %ffma.246 to i32
  br label %BB_2970_7160

BB_2970_7160:                                     ; preds = %BB_2970_80007140, %BB_2970_7140
  %phi.227 = phi i32 [ %phi_cast_R3016_bitcast, %BB_2970_80007140 ], [ %fchk_num_bits.13, %BB_2970_7140 ]
  %phi.228 = phi i32 [ -64, %BB_2970_80007140 ], [ %phi.226, %BB_2970_7140 ]
  %cond_not.118 = xor i1 %isetrp_cmp1.181, true
  br i1 %cond_not.118, label %BB_2970_80007160, label %BB_2970_7180

BB_2970_80007160:                                 ; preds = %BB_2970_7160
  %ffma.247 = call float @llvm.fma.f32(float %lds.58, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.27 = add i32 %phi.228, 64
  %phi_cast_R559_bitcast = bitcast float %ffma.247 to i32
  br label %BB_2970_7180

BB_2970_7510:                                     ; preds = %BB_2970_70e0
  %.4775 = and i32 %.4707, -2147483648
  %.4776 = and i32 %.4775, %fchk_num_bits.13
  %.4777 = and i32 %fchk_den_bits.13, -2147483648
  %.4778 = and i32 %.4777, %.4709
  %.4779 = or i32 %.4776, %.4778
  %.4780 = xor i32 %.4779, -1
  %.4783 = and i32 %.4780, 2139095040
  %.4790 = or i32 %.4783, %.4779
  %phi_cast_R3019_bitcast = bitcast i32 %.4790 to float
  br label %BB_2970_7590

BB_2970_7540:                                     ; preds = %BB_2970_70b0
  %.4804 = and i32 %.4707, -2147483648
  %.4805 = and i32 %.4804, %fchk_num_bits.13
  %.4806 = and i32 %fchk_den_bits.13, -2147483648
  %.4807 = and i32 %.4806, %.4709
  %.4808 = or i32 %.4805, %.4807
  %phi_cast_R3021_bitcast = bitcast i32 %.4808 to float
  br label %BB_2970_7590

BB_2970_7560:                                     ; preds = %BB_2970_80007080, %BB_2970_7040
  %mufu_rsq.13 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_2970_7590

BB_2970_7580:                                     ; preds = %BB_2970_7020
  %fadd.26 = fadd float %ffma.240, %lds.58
  br label %BB_2970_7590

BB_2970_80006fd0:                                 ; preds = %BB_2970_6fd0
  br label %BB_2970_7180

BB_2970_7180:                                     ; preds = %BB_2970_80006fd0, %BB_2970_80007160, %BB_2970_7160
  %phi.229 = phi i32 [ %fchk_den_bits.13, %BB_2970_80006fd0 ], [ %phi_cast_R559_bitcast, %BB_2970_80007160 ], [ %fchk_den_bits.13, %BB_2970_7160 ]
  %phi.230 = phi i32 [ %fchk_num_bits.13, %BB_2970_80006fd0 ], [ %phi.227, %BB_2970_80007160 ], [ %phi.227, %BB_2970_7160 ]
  %phi.231 = phi i32 [ 0, %BB_2970_80006fd0 ], [ %viadd.27, %BB_2970_80007160 ], [ %phi.228, %BB_2970_7160 ]
  %.4813 = zext i32 %.4679 to i64
  %.4816 = shl i64 %.4813, 23
  %.4817 = and i64 %.4816, 4294967295
  %.4818 = add i64 %.4817, 3229614080
  %.4819 = trunc i64 %.4818 to i32
  %iadd3_n1.140 = add i32 %.4687, -127
  %iadd3_o1_not.26 = xor i32 %.4819, -1
  %iadd3_o1_neg.26 = add i32 %iadd3_o1_not.26, 1
  %iadd3_n1.141 = add i32 %iadd3_o1_neg.26, %phi.229
  %imad_tmp.56 = mul i32 %iadd3_n1.140, -8388608
  %imad.67 = add i32 %imad_tmp.56, %phi.230
  %mufu_src_bitcast.13 = bitcast i32 %iadd3_n1.141 to float
  %mufu_rcp.27 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.13)
  %fadd_lhs_fneg.13 = fneg float %mufu_src_bitcast.13
  %fadd.27 = fadd float %fadd_lhs_fneg.13, 0.000000e+00
  %iadd3_o3_not.13 = xor i32 %.4679, -1
  %iadd3_o3_neg.13 = add i32 %iadd3_o3_not.13, 1
  %iadd3_n2.142 = add i32 %.4687, %iadd3_o3_neg.13
  %iadd3_n1.143 = add i32 %iadd3_n2.142, %phi.231
  %ffma.248 = call float @llvm.fma.f32(float %mufu_rcp.27, float %fadd.27, float 1.000000e+00)
  %ffma.249 = call float @llvm.fma.f32(float %mufu_rcp.27, float %ffma.248, float %mufu_rcp.27)
  %ffma_lhs_bitcast.13 = bitcast i32 %imad.67 to float
  %ffma.250 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.13, float %ffma.249, float 0.000000e+00)
  %ffma.251 = call float @llvm.fma.f32(float %fadd.27, float %ffma.250, float %ffma_lhs_bitcast.13)
  %ffma.252 = call float @llvm.fma.f32(float %ffma.249, float %ffma.251, float %ffma.250)
  %ffma.253 = call float @llvm.fma.f32(float %fadd.27, float %ffma.252, float %ffma_lhs_bitcast.13)
  %ffma.254 = call float @llvm.fma.f32(float %ffma.249, float %ffma.253, float %ffma.252)
  %shf_hi_bitcast.41 = bitcast float %ffma.254 to i32
  %.4821 = zext i32 %shf_hi_bitcast.41 to i64
  %.4822 = shl i64 %.4821, 32
  %.4823 = lshr i64 %.4822, 23
  %shf_hi.72 = lshr i64 %.4823, 32
  %shf_result.86 = trunc i64 %shf_hi.72 to i32
  %.4827 = and i32 %shf_result.86, 255
  %imad.68 = add i32 %.4827, %iadd3_n1.143
  %iadd3_n1.144 = add i32 %imad.68, -1
  %isetrp_cmp1.182 = icmp uge i32 %iadd3_n1.144, 254
  br label %BB_2970_72d0

BB_2970_72d0:                                     ; preds = %BB_2970_7180
  %cond_not.119 = xor i1 %isetrp_cmp1.182, true
  br i1 %cond_not.119, label %BB_2970_74e0, label %BB_2970_72e0

BB_2970_72e0:                                     ; preds = %BB_2970_72d0
  %isetrp_cmp1.183 = icmp sgt i32 %imad.68, 254
  br label %BB_2970_72f0

BB_2970_72f0:                                     ; preds = %BB_2970_72e0
  %242 = zext i1 %isetrp_cmp1.183 to i32
  %243 = icmp ne i32 %242, 0
  br i1 %243, label %BB_2970_74b0, label %BB_2970_7300

BB_2970_7300:                                     ; preds = %BB_2970_72f0
  %isetrp_cmp1.184 = icmp sge i32 %imad.68, 1
  br label %BB_2970_7310

BB_2970_7310:                                     ; preds = %BB_2970_7300
  %phi_cast_R2123_bitcast.2 = bitcast i32 %iadd3_n1.143 to float
  br i1 %isetrp_cmp1.184, label %BB_2970_7590, label %BB_2970_7320

BB_2970_7320:                                     ; preds = %BB_2970_7310
  %isetrp_cmp1.185 = icmp sge i32 %imad.68, -24
  %.4841 = and i32 %shf_hi_bitcast.41, -2147483648
  br label %BB_2970_7340

BB_2970_7340:                                     ; preds = %BB_2970_7320
  %cond_not.120 = xor i1 %isetrp_cmp1.185, true
  %phi_cast_R3029_bitcast = bitcast i32 %.4841 to float
  br i1 %cond_not.120, label %BB_2970_7590, label %BB_2970_7350

BB_2970_7350:                                     ; preds = %BB_2970_7340
  %ffma_rz.13 = call float @llvm.nvvm.fma.rz.f(float %ffma.249, float %ffma.253, float %ffma.252)
  %iadd3_n1.145 = add i32 %imad.68, 32
  %lop3_a_bitcast.110 = bitcast float %ffma_rz.13 to i32
  %.4851 = and i32 %lop3_a_bitcast.110, 8388607
  %ffma_rp.13 = call float @llvm.nvvm.fma.rp.f(float %ffma.249, float %ffma.253, float %ffma.252)
  %ffma_rm.13 = call float @llvm.nvvm.fma.rm.f(float %ffma.249, float %ffma.253, float %ffma.252)
  %isetrp_cmp1.187 = icmp ne i32 %imad.68, 0
  %.4866 = or i32 8388608, %.4851
  %iadd3_o1_not.27 = xor i32 %imad.68, -1
  %iadd3_o1_neg.27 = add i32 %iadd3_o1_not.27, 1
  %.4876 = zext i32 %.4866 to i64
  %shf_shift_64.87 = zext i32 %iadd3_n1.145 to i64
  %.4879 = shl i64 %.4876, %shf_shift_64.87
  %shf_result.87 = trunc i64 %.4879 to i32
  %fsetrp_cmp1.83 = fcmp une float %ffma_rp.13, %ffma_rm.13
  %isetrp_cmp1.188 = icmp ne i32 %shf_result.87, 0
  %isetrp_cmp2.188 = and i1 %isetrp_cmp1.188, %isetrp_cmp1.187
  %.4882 = shl i64 %.4876, 32
  %shf_shift_64.88 = zext i32 %iadd3_o1_neg.27 to i64
  %.4883 = lshr i64 %.4882, %shf_shift_64.88
  %shf_hi.73 = lshr i64 %.4883, 32
  %shf_result.88 = trunc i64 %shf_hi.73 to i32
  %lop3_a_cast_zext.55 = zext i1 %fsetrp_cmp1.83 to i32
  %lop3_b_cast_zext.55 = zext i1 %isetrp_cmp2.188 to i32
  %plop3_a_bit.55 = and i32 %lop3_a_cast_zext.55, 1
  %plop3_b_bit.55 = and i32 %lop3_b_cast_zext.55, 1
  %.4884 = xor i32 %plop3_a_bit.55, 1
  %.4885 = xor i32 %plop3_b_bit.55, 1
  %.4887 = and i32 %.4884, %plop3_b_bit.55
  %.4889 = and i32 %plop3_a_bit.55, %.4885
  %.4891 = or i32 %.4887, %.4889
  %.4892 = and i32 %plop3_a_bit.55, %plop3_b_bit.55
  %.4894 = or i32 %.4891, %.4892
  %lop3_pred_cmp.97 = icmp ne i32 %.4894, 0
  %.4896 = zext i32 %shf_result.88 to i64
  %.4897 = shl i64 %.4896, 32
  %.4898 = lshr i64 %.4897, 1
  %shf_hi.74 = lshr i64 %.4898, 32
  %shf_result.89 = trunc i64 %shf_hi.74 to i32
  %sel_pred_not.13 = xor i1 %lop3_pred_cmp.97, true
  %sel.27 = select i1 %sel_pred_not.13, i32 0, i32 1
  %.4899 = xor i32 %sel.27, -1
  %.4901 = xor i32 %shf_result.89, -1
  %.4902 = and i32 %.4899, 1
  %.4903 = and i32 %.4902, %shf_result.89
  %.4911 = and i32 %sel.27, %.4901
  %.4912 = or i32 %.4903, %.4911
  %.4914 = and i32 %sel.27, %shf_result.89
  %.4915 = or i32 %.4912, %.4914
  %.4919 = and i32 %.4915, %shf_result.88
  %imad.69 = add i32 %shf_result.89, %.4919
  %.4924 = xor i32 %imad.69, -1
  %.4925 = xor i32 %.4841, -1
  %.4927 = and i32 %.4924, %.4841
  %.4932 = and i32 %imad.69, %.4925
  %.4934 = or i32 %.4927, %.4932
  %.4938 = and i32 %imad.69, %.4841
  %.4940 = or i32 %.4934, %.4938
  %phi_cast_R3030_bitcast = bitcast i32 %.4940 to float
  %phi_cast_R2126_bitcast = bitcast i32 %.4866 to float
  br label %BB_2970_7590

BB_2970_74b0:                                     ; preds = %BB_2970_72f0
  %.4948 = and i32 %shf_hi_bitcast.41, -2147483648
  %.4963 = or i32 2139095040, %.4948
  %phi_cast_R3033_bitcast = bitcast i32 %.4963 to float
  %phi_cast_R2123_bitcast = bitcast i32 %iadd3_n1.143 to float
  br label %BB_2970_7590

BB_2970_74e0:                                     ; preds = %BB_2970_72d0
  %.4974 = zext i32 %iadd3_n1.143 to i64
  %.4977 = shl i64 %.4974, 23
  %.4978 = and i64 %.4977, 4294967295
  %.4979 = add i64 %.4978, %.4821
  %.4980 = trunc i64 %.4979 to i32
  %phi_cast_R3034_bitcast = bitcast i32 %.4980 to float
  %phi_cast_R2123_bitcast.1 = bitcast i32 %iadd3_n1.143 to float
  br label %BB_2970_7590

BB_2970_7590:                                     ; preds = %BB_2970_74e0, %BB_2970_74b0, %BB_2970_7350, %BB_2970_7340, %BB_2970_7310, %BB_2970_7580, %BB_2970_7560, %BB_2970_7540, %BB_2970_7510
  %phi.232 = phi float [ %phi_cast_R3030_bitcast, %BB_2970_7350 ], [ %phi_cast_R3033_bitcast, %BB_2970_74b0 ], [ %phi_cast_R3034_bitcast, %BB_2970_74e0 ], [ %ffma.254, %BB_2970_7310 ], [ %phi_cast_R3029_bitcast, %BB_2970_7340 ], [ %phi_cast_R3019_bitcast, %BB_2970_7510 ], [ %phi_cast_R3021_bitcast, %BB_2970_7540 ], [ %mufu_rsq.13, %BB_2970_7560 ], [ %fadd.26, %BB_2970_7580 ]
  %phi.233 = phi float [ %phi_cast_R2126_bitcast, %BB_2970_7350 ], [ %phi_cast_R2123_bitcast, %BB_2970_74b0 ], [ %phi_cast_R2123_bitcast.1, %BB_2970_74e0 ], [ %phi_cast_R2123_bitcast.2, %BB_2970_7310 ], [ %phi_cast_R2123_bitcast.2, %BB_2970_7340 ], [ %phi.222, %BB_2970_7510 ], [ %phi.222, %BB_2970_7540 ], [ %phi.222, %BB_2970_7560 ], [ %phi.222, %BB_2970_7580 ]
  br label %BB_2990

BB_2990:                                          ; preds = %BB_2970_7590, %BB_2940
  %phi.234 = phi float [ %phi.232, %BB_2970_7590 ], [ %ffma.245, %BB_2940 ]
  %phi.235 = phi float [ %phi.233, %BB_2970_7590 ], [ %phi.222, %BB_2940 ]
  br label %BB_29b0

BB_29b0:                                          ; preds = %BB_2990, %BB_2850
  %phi.236 = phi float [ %phi.234, %BB_2990 ], [ %phi.221, %BB_2850 ]
  %phi.237 = phi float [ %phi.235, %BB_2990 ], [ %phi.222, %BB_2850 ]
  %phi.238 = phi i32 [ %.75, %BB_2990 ], [ %phi.223, %BB_2850 ]
  %phi.239 = phi float [ %phi.234, %BB_2990 ], [ %phi.224, %BB_2850 ]
  br label %BB_29e0

BB_29e0:                                          ; preds = %BB_29b0
  %shfl_activemask.45 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.45 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.45, float %phi.239, i32 13, i32 31)
  br label %BB_29f0

BB_29f0:                                          ; preds = %BB_29e0
  %isetrp_cmp1.189 = icmp uge i32 %tid_x, 14
  %isetrp_cmp1.190 = icmp ne i32 %tid_x, 14
  br label %BB_2a20

BB_2a20:                                          ; preds = %BB_29f0
  %244 = zext i1 %isetrp_cmp1.189 to i32
  %245 = icmp ne i32 %244, 0
  br i1 %245, label %BB_80002a20, label %BB_2a40

BB_80002a20:                                      ; preds = %BB_2a20
  %lds_addr_memaddr_offset_add.56 = add i32 %.88, 1716
  %.4988 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.56
  %lds.59 = load volatile float, ptr addrspace(3) %.4988, align 4
  %ffma.255 = call float @llvm.fma.f32(float %shfl_idx.45, float %lds.59, float %phi.225)
  br label %BB_2a40

BB_2a40:                                          ; preds = %BB_80002a20, %BB_2a20
  %phi.240 = phi float [ %ffma.255, %BB_80002a20 ], [ %phi.225, %BB_2a20 ]
  %warp_reconv_mask.13 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.13)
  br i1 %isetrp_cmp1.190, label %BB_2ba0, label %BB_2a50

BB_2a50:                                          ; preds = %BB_2a40
  %ffma_addend_fneg.14 = fneg float %phi.240
  %ffma.256 = call float @llvm.fma.f32(float %phi.236, float %phi, float %ffma_addend_fneg.14)
  %lds_addr_memaddr_offset_add.57 = add i32 %.75, 1904
  %.4998 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.57
  %lds.60 = load volatile float, ptr addrspace(3) %.4998, align 4
  %mufu_rcp.28 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.60)
  %fchk_num_bits.14 = bitcast float %ffma.256 to i32
  %fchk_den_bits.14 = bitcast float %lds.60 to i32
  %fchk_aden.14 = and i32 %fchk_den_bits.14, 2147483647
  %fchk_anum.14 = and i32 %fchk_num_bits.14, 2147483647
  %fchk_den_subz.14 = icmp ult i32 %fchk_aden.14, 8388608
  %fchk_den_infnan.14 = icmp uge i32 %fchk_aden.14, 2139095040
  %fchk_num_infnan.14 = icmp uge i32 %fchk_anum.14, 2139095040
  %fchk_den_bad.14 = or i1 %fchk_den_subz.14, %fchk_den_infnan.14
  %fchk_px.14 = or i1 %fchk_den_bad.14, %fchk_num_infnan.14
  %ffma_lhs_fneg.28 = fneg float %lds.60
  %ffma.257 = call float @llvm.fma.f32(float %ffma_lhs_fneg.28, float %mufu_rcp.28, float 1.000000e+00)
  %ffma.258 = call float @llvm.fma.f32(float %mufu_rcp.28, float %ffma.257, float %mufu_rcp.28)
  %ffma.259 = call float @llvm.fma.f32(float %ffma.256, float %ffma.258, float 0.000000e+00)
  %ffma.260 = call float @llvm.fma.f32(float %ffma_lhs_fneg.28, float %ffma.259, float %ffma.256)
  %ffma.261 = call float @llvm.fma.f32(float %ffma.258, float %ffma.260, float %ffma.259)
  br label %BB_2b30

BB_2b30:                                          ; preds = %BB_2a50
  %cond_not.121 = xor i1 %fchk_px.14, true
  br i1 %cond_not.121, label %BB_2b80, label %BB_2b60_6f40

BB_2b60_6f40:                                     ; preds = %BB_2b30
  %.5002 = zext i32 %fchk_den_bits.14 to i64
  %.5003 = shl i64 %.5002, 32
  %.5004 = lshr i64 %.5003, 23
  %shf_hi.75 = lshr i64 %.5004, 32
  %shf_result.90 = trunc i64 %shf_hi.75 to i32
  %.5006 = zext i32 %fchk_num_bits.14 to i64
  %.5007 = shl i64 %.5006, 32
  %.5008 = lshr i64 %.5007, 23
  %shf_hi.76 = lshr i64 %.5008, 32
  %shf_result.91 = trunc i64 %shf_hi.76 to i32
  %.5012 = and i32 %shf_result.90, 255
  %.5020 = and i32 %shf_result.91, 255
  %iadd3_n1.147 = add i32 %.5012, -1
  %iadd3_n1.148 = add i32 %.5020, -1
  %isetrp_cmp1.191 = icmp ugt i32 %iadd3_n1.147, 253
  %isetrp_cmp1.192 = icmp ugt i32 %iadd3_n1.148, 253
  %isetrp_cmp2.192 = or i1 %isetrp_cmp1.192, %isetrp_cmp1.191
  br label %BB_2b60_6fd0

BB_2b60_6fd0:                                     ; preds = %BB_2b60_6f40
  %cond_not.122 = xor i1 %isetrp_cmp2.192, true
  br i1 %cond_not.122, label %BB_2b60_80006fd0, label %BB_2b60_6ff0

BB_2b60_6ff0:                                     ; preds = %BB_2b60_6fd0
  %fsetrp_lhs_fabs.70 = call float @llvm.nvvm.fabs.f(float %ffma.256)
  %fsetrp_cmp1.84 = fcmp ugt float %fsetrp_lhs_fabs.70, 0x7FF0000000000000
  %fsetrp_lhs_fabs.71 = call float @llvm.nvvm.fabs.f(float %lds.60)
  %fsetrp_cmp1.85 = fcmp ugt float %fsetrp_lhs_fabs.71, 0x7FF0000000000000
  %lop3_a_cast_zext.56 = zext i1 %fsetrp_cmp1.84 to i32
  %lop3_b_cast_zext.56 = zext i1 %fsetrp_cmp1.85 to i32
  %plop3_a_bit.56 = and i32 %lop3_a_cast_zext.56, 1
  %plop3_b_bit.56 = and i32 %lop3_b_cast_zext.56, 1
  %.5027 = xor i32 %plop3_a_bit.56, 1
  %.5028 = xor i32 %plop3_b_bit.56, 1
  %.5030 = and i32 %.5027, %plop3_b_bit.56
  %.5032 = and i32 %plop3_a_bit.56, %.5028
  %.5034 = or i32 %.5030, %.5032
  %.5035 = and i32 %plop3_a_bit.56, %plop3_b_bit.56
  %.5037 = or i32 %.5034, %.5035
  %lop3_pred_cmp.98 = icmp ne i32 %.5037, 0
  br label %BB_2b60_7020

BB_2b60_7020:                                     ; preds = %BB_2b60_6ff0
  %246 = zext i1 %lop3_pred_cmp.98 to i32
  %247 = icmp ne i32 %246, 0
  br i1 %247, label %BB_2b60_7580, label %BB_2b60_7030

BB_2b60_7030:                                     ; preds = %BB_2b60_7020
  %.5040 = xor i32 %fchk_den_bits.14, -1
  %.5042 = xor i32 %fchk_num_bits.14, -1
  %.5043 = and i32 %.5040, 2147483647
  %.5044 = and i32 %.5043, %fchk_num_bits.14
  %.5046 = and i32 %fchk_aden.14, %.5042
  %.5047 = or i32 %.5044, %.5046
  %.5049 = and i32 %fchk_aden.14, %fchk_num_bits.14
  %.5050 = or i32 %.5047, %.5049
  %lop3_pred_cmp.99 = icmp ne i32 %.5050, 0
  br label %BB_2b60_7040

BB_2b60_7040:                                     ; preds = %BB_2b60_7030
  %cond_not.123 = xor i1 %lop3_pred_cmp.99, true
  br i1 %cond_not.123, label %BB_2b60_7560, label %BB_2b60_7050

BB_2b60_7050:                                     ; preds = %BB_2b60_7040
  %fsetrp_cmp1.86 = fcmp une float %fsetrp_lhs_fabs.70, 0x7FF0000000000000
  %fsetrp_cmp1.87 = fcmp une float %fsetrp_lhs_fabs.71, 0x7FF0000000000000
  br label %BB_2b60_7080

BB_2b60_7080:                                     ; preds = %BB_2b60_7050
  %cond_not.124 = xor i1 %fsetrp_cmp1.87, true
  br i1 %cond_not.124, label %BB_2b60_80007080, label %BB_2b60_7090

BB_2b60_80007080:                                 ; preds = %BB_2b60_7080
  %bra_cond_not.14 = xor i1 %fsetrp_cmp1.86, true
  br i1 %bra_cond_not.14, label %BB_2b60_7560, label %BB_2b60_7090

BB_2b60_7090:                                     ; preds = %BB_2b60_80007080, %BB_2b60_7080
  %lop3_pred_cmp.100 = icmp ne i32 %fchk_anum.14, 0
  %lop3_a_cast_zext.57 = zext i1 %fsetrp_cmp1.87 to i32
  %lop3_b_cast_zext.57 = zext i1 %lop3_pred_cmp.100 to i32
  %plop3_a_bit.57 = and i32 %lop3_a_cast_zext.57, 1
  %plop3_b_bit.57 = and i32 %lop3_b_cast_zext.57, 1
  %.5064 = xor i32 %plop3_a_bit.57, 1
  %.5065 = xor i32 %plop3_b_bit.57, 1
  %.5067 = and i32 %.5064, %.5065
  %.5069 = and i32 %.5064, %plop3_b_bit.57
  %.5071 = or i32 %.5067, %.5069
  %.5072 = and i32 %plop3_a_bit.57, %.5065
  %.5074 = or i32 %.5071, %.5072
  %lop3_pred_cmp.101 = icmp ne i32 %.5074, 0
  br label %BB_2b60_70b0

BB_2b60_70b0:                                     ; preds = %BB_2b60_7090
  %248 = zext i1 %lop3_pred_cmp.101 to i32
  %249 = icmp ne i32 %248, 0
  br i1 %249, label %BB_2b60_7540, label %BB_2b60_70c0

BB_2b60_70c0:                                     ; preds = %BB_2b60_70b0
  %lop3_pred_cmp.102 = icmp ne i32 %fchk_aden.14, 0
  %lop3_a_cast_zext.58 = zext i1 %fsetrp_cmp1.86 to i32
  %lop3_b_cast_zext.58 = zext i1 %lop3_pred_cmp.102 to i32
  %plop3_a_bit.58 = and i32 %lop3_a_cast_zext.58, 1
  %plop3_b_bit.58 = and i32 %lop3_b_cast_zext.58, 1
  %.5085 = xor i32 %plop3_a_bit.58, 1
  %.5086 = xor i32 %plop3_b_bit.58, 1
  %.5088 = and i32 %.5085, %.5086
  %.5090 = and i32 %.5085, %plop3_b_bit.58
  %.5092 = or i32 %.5088, %.5090
  %.5093 = and i32 %plop3_a_bit.58, %.5086
  %.5095 = or i32 %.5092, %.5093
  %lop3_pred_cmp.103 = icmp ne i32 %.5095, 0
  br label %BB_2b60_70e0

BB_2b60_70e0:                                     ; preds = %BB_2b60_70c0
  %250 = zext i1 %lop3_pred_cmp.103 to i32
  %251 = icmp ne i32 %250, 0
  br i1 %251, label %BB_2b60_7510, label %BB_2b60_70f0

BB_2b60_70f0:                                     ; preds = %BB_2b60_70e0
  %isetrp_cmp1.193 = icmp sge i32 %iadd3_n1.148, 0
  %isetrp_cmp1.194 = icmp sge i32 %iadd3_n1.147, 0
  br label %BB_2b60_7130

BB_2b60_7130:                                     ; preds = %BB_2b60_70f0
  %252 = zext i1 %isetrp_cmp1.193 to i32
  %253 = icmp ne i32 %252, 0
  br i1 %253, label %BB_2b60_80007130, label %BB_2b60_7140

BB_2b60_80007130:                                 ; preds = %BB_2b60_7130
  br label %BB_2b60_7140

BB_2b60_7140:                                     ; preds = %BB_2b60_80007130, %BB_2b60_7130
  %phi.241 = phi i32 [ 0, %BB_2b60_80007130 ], [ %iadd3_n1.147, %BB_2b60_7130 ]
  %cond_not.125 = xor i1 %isetrp_cmp1.193, true
  br i1 %cond_not.125, label %BB_2b60_80007140, label %BB_2b60_7160

BB_2b60_80007140:                                 ; preds = %BB_2b60_7140
  %ffma.262 = call float @llvm.fma.f32(float %ffma.256, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R3039_bitcast = bitcast float %ffma.262 to i32
  br label %BB_2b60_7160

BB_2b60_7160:                                     ; preds = %BB_2b60_80007140, %BB_2b60_7140
  %phi.242 = phi i32 [ %phi_cast_R3039_bitcast, %BB_2b60_80007140 ], [ %fchk_num_bits.14, %BB_2b60_7140 ]
  %phi.243 = phi i32 [ -64, %BB_2b60_80007140 ], [ %phi.241, %BB_2b60_7140 ]
  %cond_not.126 = xor i1 %isetrp_cmp1.194, true
  br i1 %cond_not.126, label %BB_2b60_80007160, label %BB_2b60_7180

BB_2b60_80007160:                                 ; preds = %BB_2b60_7160
  %ffma.263 = call float @llvm.fma.f32(float %lds.60, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.29 = add i32 %phi.243, 64
  %phi_cast_R578_bitcast = bitcast float %ffma.263 to i32
  br label %BB_2b60_7180

BB_2b60_7510:                                     ; preds = %BB_2b60_70e0
  %.5108 = and i32 %.5040, -2147483648
  %.5109 = and i32 %.5108, %fchk_num_bits.14
  %.5110 = and i32 %fchk_den_bits.14, -2147483648
  %.5111 = and i32 %.5110, %.5042
  %.5112 = or i32 %.5109, %.5111
  %.5113 = xor i32 %.5112, -1
  %.5116 = and i32 %.5113, 2139095040
  %.5123 = or i32 %.5116, %.5112
  %phi_cast_R3043_bitcast = bitcast i32 %.5123 to float
  br label %BB_2b60_7590

BB_2b60_7540:                                     ; preds = %BB_2b60_70b0
  %.5137 = and i32 %.5040, -2147483648
  %.5138 = and i32 %.5137, %fchk_num_bits.14
  %.5139 = and i32 %fchk_den_bits.14, -2147483648
  %.5140 = and i32 %.5139, %.5042
  %.5141 = or i32 %.5138, %.5140
  %phi_cast_R3044_bitcast = bitcast i32 %.5141 to float
  br label %BB_2b60_7590

BB_2b60_7560:                                     ; preds = %BB_2b60_80007080, %BB_2b60_7040
  %mufu_rsq.14 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_2b60_7590

BB_2b60_7580:                                     ; preds = %BB_2b60_7020
  %fadd.28 = fadd float %ffma.256, %lds.60
  br label %BB_2b60_7590

BB_2b60_80006fd0:                                 ; preds = %BB_2b60_6fd0
  br label %BB_2b60_7180

BB_2b60_7180:                                     ; preds = %BB_2b60_80006fd0, %BB_2b60_80007160, %BB_2b60_7160
  %phi.244 = phi i32 [ %fchk_den_bits.14, %BB_2b60_80006fd0 ], [ %phi_cast_R578_bitcast, %BB_2b60_80007160 ], [ %fchk_den_bits.14, %BB_2b60_7160 ]
  %phi.245 = phi i32 [ %fchk_num_bits.14, %BB_2b60_80006fd0 ], [ %phi.242, %BB_2b60_80007160 ], [ %phi.242, %BB_2b60_7160 ]
  %phi.246 = phi i32 [ 0, %BB_2b60_80006fd0 ], [ %viadd.29, %BB_2b60_80007160 ], [ %phi.243, %BB_2b60_7160 ]
  %.5146 = zext i32 %.5012 to i64
  %.5149 = shl i64 %.5146, 23
  %.5150 = and i64 %.5149, 4294967295
  %.5151 = add i64 %.5150, 3229614080
  %.5152 = trunc i64 %.5151 to i32
  %iadd3_n1.150 = add i32 %.5020, -127
  %iadd3_o1_not.28 = xor i32 %.5152, -1
  %iadd3_o1_neg.28 = add i32 %iadd3_o1_not.28, 1
  %iadd3_n1.151 = add i32 %iadd3_o1_neg.28, %phi.244
  %imad_tmp.59 = mul i32 %iadd3_n1.150, -8388608
  %imad.70 = add i32 %imad_tmp.59, %phi.245
  %mufu_src_bitcast.14 = bitcast i32 %iadd3_n1.151 to float
  %mufu_rcp.29 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.14)
  %fadd_lhs_fneg.14 = fneg float %mufu_src_bitcast.14
  %fadd.29 = fadd float %fadd_lhs_fneg.14, 0.000000e+00
  %iadd3_o3_not.14 = xor i32 %.5012, -1
  %iadd3_o3_neg.14 = add i32 %iadd3_o3_not.14, 1
  %iadd3_n2.152 = add i32 %.5020, %iadd3_o3_neg.14
  %iadd3_n1.153 = add i32 %iadd3_n2.152, %phi.246
  %ffma.264 = call float @llvm.fma.f32(float %mufu_rcp.29, float %fadd.29, float 1.000000e+00)
  %ffma.265 = call float @llvm.fma.f32(float %mufu_rcp.29, float %ffma.264, float %mufu_rcp.29)
  %ffma_lhs_bitcast.14 = bitcast i32 %imad.70 to float
  %ffma.266 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.14, float %ffma.265, float 0.000000e+00)
  %ffma.267 = call float @llvm.fma.f32(float %fadd.29, float %ffma.266, float %ffma_lhs_bitcast.14)
  %ffma.268 = call float @llvm.fma.f32(float %ffma.265, float %ffma.267, float %ffma.266)
  %ffma.269 = call float @llvm.fma.f32(float %fadd.29, float %ffma.268, float %ffma_lhs_bitcast.14)
  %ffma.270 = call float @llvm.fma.f32(float %ffma.265, float %ffma.269, float %ffma.268)
  %shf_hi_bitcast.44 = bitcast float %ffma.270 to i32
  %.5154 = zext i32 %shf_hi_bitcast.44 to i64
  %.5155 = shl i64 %.5154, 32
  %.5156 = lshr i64 %.5155, 23
  %shf_hi.77 = lshr i64 %.5156, 32
  %shf_result.92 = trunc i64 %shf_hi.77 to i32
  %.5160 = and i32 %shf_result.92, 255
  %imad.71 = add i32 %.5160, %iadd3_n1.153
  %iadd3_n1.154 = add i32 %imad.71, -1
  %isetrp_cmp1.195 = icmp uge i32 %iadd3_n1.154, 254
  br label %BB_2b60_72d0

BB_2b60_72d0:                                     ; preds = %BB_2b60_7180
  %cond_not.127 = xor i1 %isetrp_cmp1.195, true
  br i1 %cond_not.127, label %BB_2b60_74e0, label %BB_2b60_72e0

BB_2b60_72e0:                                     ; preds = %BB_2b60_72d0
  %isetrp_cmp1.196 = icmp sgt i32 %imad.71, 254
  br label %BB_2b60_72f0

BB_2b60_72f0:                                     ; preds = %BB_2b60_72e0
  %254 = zext i1 %isetrp_cmp1.196 to i32
  %255 = icmp ne i32 %254, 0
  br i1 %255, label %BB_2b60_74b0, label %BB_2b60_7300

BB_2b60_7300:                                     ; preds = %BB_2b60_72f0
  %isetrp_cmp1.197 = icmp sge i32 %imad.71, 1
  br label %BB_2b60_7310

BB_2b60_7310:                                     ; preds = %BB_2b60_7300
  %phi_cast_R2133_bitcast.2 = bitcast i32 %iadd3_n1.153 to float
  br i1 %isetrp_cmp1.197, label %BB_2b60_7590, label %BB_2b60_7320

BB_2b60_7320:                                     ; preds = %BB_2b60_7310
  %isetrp_cmp1.198 = icmp sge i32 %imad.71, -24
  %.5174 = and i32 %shf_hi_bitcast.44, -2147483648
  br label %BB_2b60_7340

BB_2b60_7340:                                     ; preds = %BB_2b60_7320
  %cond_not.128 = xor i1 %isetrp_cmp1.198, true
  %phi_cast_R3052_bitcast = bitcast i32 %.5174 to float
  br i1 %cond_not.128, label %BB_2b60_7590, label %BB_2b60_7350

BB_2b60_7350:                                     ; preds = %BB_2b60_7340
  %ffma_rz.14 = call float @llvm.nvvm.fma.rz.f(float %ffma.265, float %ffma.269, float %ffma.268)
  %iadd3_n1.155 = add i32 %imad.71, 32
  %lop3_a_bitcast.118 = bitcast float %ffma_rz.14 to i32
  %.5184 = and i32 %lop3_a_bitcast.118, 8388607
  %ffma_rp.14 = call float @llvm.nvvm.fma.rp.f(float %ffma.265, float %ffma.269, float %ffma.268)
  %ffma_rm.14 = call float @llvm.nvvm.fma.rm.f(float %ffma.265, float %ffma.269, float %ffma.268)
  %isetrp_cmp1.200 = icmp ne i32 %imad.71, 0
  %.5199 = or i32 8388608, %.5184
  %iadd3_o1_not.29 = xor i32 %imad.71, -1
  %iadd3_o1_neg.29 = add i32 %iadd3_o1_not.29, 1
  %.5209 = zext i32 %.5199 to i64
  %shf_shift_64.93 = zext i32 %iadd3_n1.155 to i64
  %.5212 = shl i64 %.5209, %shf_shift_64.93
  %shf_result.93 = trunc i64 %.5212 to i32
  %fsetrp_cmp1.89 = fcmp une float %ffma_rp.14, %ffma_rm.14
  %isetrp_cmp1.201 = icmp ne i32 %shf_result.93, 0
  %isetrp_cmp2.201 = and i1 %isetrp_cmp1.201, %isetrp_cmp1.200
  %.5215 = shl i64 %.5209, 32
  %shf_shift_64.94 = zext i32 %iadd3_o1_neg.29 to i64
  %.5216 = lshr i64 %.5215, %shf_shift_64.94
  %shf_hi.78 = lshr i64 %.5216, 32
  %shf_result.94 = trunc i64 %shf_hi.78 to i32
  %lop3_a_cast_zext.59 = zext i1 %fsetrp_cmp1.89 to i32
  %lop3_b_cast_zext.59 = zext i1 %isetrp_cmp2.201 to i32
  %plop3_a_bit.59 = and i32 %lop3_a_cast_zext.59, 1
  %plop3_b_bit.59 = and i32 %lop3_b_cast_zext.59, 1
  %.5217 = xor i32 %plop3_a_bit.59, 1
  %.5218 = xor i32 %plop3_b_bit.59, 1
  %.5220 = and i32 %.5217, %plop3_b_bit.59
  %.5222 = and i32 %plop3_a_bit.59, %.5218
  %.5224 = or i32 %.5220, %.5222
  %.5225 = and i32 %plop3_a_bit.59, %plop3_b_bit.59
  %.5227 = or i32 %.5224, %.5225
  %lop3_pred_cmp.104 = icmp ne i32 %.5227, 0
  %.5229 = zext i32 %shf_result.94 to i64
  %.5230 = shl i64 %.5229, 32
  %.5231 = lshr i64 %.5230, 1
  %shf_hi.79 = lshr i64 %.5231, 32
  %shf_result.95 = trunc i64 %shf_hi.79 to i32
  %sel_pred_not.14 = xor i1 %lop3_pred_cmp.104, true
  %sel.29 = select i1 %sel_pred_not.14, i32 0, i32 1
  %.5232 = xor i32 %sel.29, -1
  %.5234 = xor i32 %shf_result.95, -1
  %.5235 = and i32 %.5232, 1
  %.5236 = and i32 %.5235, %shf_result.95
  %.5244 = and i32 %sel.29, %.5234
  %.5245 = or i32 %.5236, %.5244
  %.5247 = and i32 %sel.29, %shf_result.95
  %.5248 = or i32 %.5245, %.5247
  %.5252 = and i32 %.5248, %shf_result.94
  %imad.72 = add i32 %shf_result.95, %.5252
  %.5257 = xor i32 %imad.72, -1
  %.5258 = xor i32 %.5174, -1
  %.5260 = and i32 %.5257, %.5174
  %.5265 = and i32 %imad.72, %.5258
  %.5267 = or i32 %.5260, %.5265
  %.5271 = and i32 %imad.72, %.5174
  %.5273 = or i32 %.5267, %.5271
  %phi_cast_R3054_bitcast = bitcast i32 %.5273 to float
  %phi_cast_R2137_bitcast = bitcast i32 %.5199 to float
  br label %BB_2b60_7590

BB_2b60_74b0:                                     ; preds = %BB_2b60_72f0
  %.5281 = and i32 %shf_hi_bitcast.44, -2147483648
  %.5296 = or i32 2139095040, %.5281
  %phi_cast_R3056_bitcast = bitcast i32 %.5296 to float
  %phi_cast_R2133_bitcast = bitcast i32 %iadd3_n1.153 to float
  br label %BB_2b60_7590

BB_2b60_74e0:                                     ; preds = %BB_2b60_72d0
  %.5307 = zext i32 %iadd3_n1.153 to i64
  %.5310 = shl i64 %.5307, 23
  %.5311 = and i64 %.5310, 4294967295
  %.5312 = add i64 %.5311, %.5154
  %.5313 = trunc i64 %.5312 to i32
  %phi_cast_R3057_bitcast = bitcast i32 %.5313 to float
  %phi_cast_R2133_bitcast.1 = bitcast i32 %iadd3_n1.153 to float
  br label %BB_2b60_7590

BB_2b60_7590:                                     ; preds = %BB_2b60_74e0, %BB_2b60_74b0, %BB_2b60_7350, %BB_2b60_7340, %BB_2b60_7310, %BB_2b60_7580, %BB_2b60_7560, %BB_2b60_7540, %BB_2b60_7510
  %phi.247 = phi float [ %phi_cast_R3054_bitcast, %BB_2b60_7350 ], [ %phi_cast_R3056_bitcast, %BB_2b60_74b0 ], [ %phi_cast_R3057_bitcast, %BB_2b60_74e0 ], [ %ffma.270, %BB_2b60_7310 ], [ %phi_cast_R3052_bitcast, %BB_2b60_7340 ], [ %phi_cast_R3043_bitcast, %BB_2b60_7510 ], [ %phi_cast_R3044_bitcast, %BB_2b60_7540 ], [ %mufu_rsq.14, %BB_2b60_7560 ], [ %fadd.28, %BB_2b60_7580 ]
  %phi.248 = phi float [ %phi_cast_R2137_bitcast, %BB_2b60_7350 ], [ %phi_cast_R2133_bitcast, %BB_2b60_74b0 ], [ %phi_cast_R2133_bitcast.1, %BB_2b60_74e0 ], [ %phi_cast_R2133_bitcast.2, %BB_2b60_7310 ], [ %phi_cast_R2133_bitcast.2, %BB_2b60_7340 ], [ %phi.237, %BB_2b60_7510 ], [ %phi.237, %BB_2b60_7540 ], [ %phi.237, %BB_2b60_7560 ], [ %phi.237, %BB_2b60_7580 ]
  br label %BB_2b80

BB_2b80:                                          ; preds = %BB_2b60_7590, %BB_2b30
  %phi.249 = phi float [ %phi.247, %BB_2b60_7590 ], [ %ffma.261, %BB_2b30 ]
  %phi.250 = phi float [ %phi.248, %BB_2b60_7590 ], [ %phi.237, %BB_2b30 ]
  br label %BB_2ba0

BB_2ba0:                                          ; preds = %BB_2b80, %BB_2a40
  %phi.251 = phi float [ %phi.249, %BB_2b80 ], [ %phi.236, %BB_2a40 ]
  %phi.252 = phi float [ %phi.250, %BB_2b80 ], [ %phi.237, %BB_2a40 ]
  %phi.253 = phi i32 [ %.75, %BB_2b80 ], [ %phi.238, %BB_2a40 ]
  %phi.254 = phi float [ %phi.249, %BB_2b80 ], [ %phi.239, %BB_2a40 ]
  br label %BB_2bd0

BB_2bd0:                                          ; preds = %BB_2ba0
  %shfl_activemask.46 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.46 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.46, float %phi.254, i32 14, i32 31)
  br label %BB_2be0

BB_2be0:                                          ; preds = %BB_2bd0
  %isetrp_cmp1.202 = icmp uge i32 %tid_x, 15
  %isetrp_cmp1.203 = icmp ne i32 %tid_x, 15
  br label %BB_2c10

BB_2c10:                                          ; preds = %BB_2be0
  %256 = zext i1 %isetrp_cmp1.202 to i32
  %257 = icmp ne i32 %256, 0
  br i1 %257, label %BB_80002c10, label %BB_2c30

BB_80002c10:                                      ; preds = %BB_2c10
  %lds_addr_memaddr_offset_add.58 = add i32 %.88, 1848
  %.5321 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.58
  %lds.61 = load volatile float, ptr addrspace(3) %.5321, align 4
  %ffma.271 = call float @llvm.fma.f32(float %shfl_idx.46, float %lds.61, float %phi.240)
  br label %BB_2c30

BB_2c30:                                          ; preds = %BB_80002c10, %BB_2c10
  %phi.255 = phi float [ %ffma.271, %BB_80002c10 ], [ %phi.240, %BB_2c10 ]
  %warp_reconv_mask.14 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.14)
  br i1 %isetrp_cmp1.203, label %BB_2d90, label %BB_2c40

BB_2c40:                                          ; preds = %BB_2c30
  %ffma_addend_fneg.15 = fneg float %phi.255
  %ffma.272 = call float @llvm.fma.f32(float %phi.251, float %phi, float %ffma_addend_fneg.15)
  %lds_addr_memaddr_offset_add.59 = add i32 %.75, 2040
  %.5331 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.59
  %lds.62 = load volatile float, ptr addrspace(3) %.5331, align 4
  %mufu_rcp.30 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.62)
  %fchk_num_bits.15 = bitcast float %ffma.272 to i32
  %fchk_den_bits.15 = bitcast float %lds.62 to i32
  %fchk_aden.15 = and i32 %fchk_den_bits.15, 2147483647
  %fchk_anum.15 = and i32 %fchk_num_bits.15, 2147483647
  %fchk_den_subz.15 = icmp ult i32 %fchk_aden.15, 8388608
  %fchk_den_infnan.15 = icmp uge i32 %fchk_aden.15, 2139095040
  %fchk_num_infnan.15 = icmp uge i32 %fchk_anum.15, 2139095040
  %fchk_den_bad.15 = or i1 %fchk_den_subz.15, %fchk_den_infnan.15
  %fchk_px.15 = or i1 %fchk_den_bad.15, %fchk_num_infnan.15
  %ffma_lhs_fneg.30 = fneg float %lds.62
  %ffma.273 = call float @llvm.fma.f32(float %ffma_lhs_fneg.30, float %mufu_rcp.30, float 1.000000e+00)
  %ffma.274 = call float @llvm.fma.f32(float %mufu_rcp.30, float %ffma.273, float %mufu_rcp.30)
  %ffma.275 = call float @llvm.fma.f32(float %ffma.272, float %ffma.274, float 0.000000e+00)
  %ffma.276 = call float @llvm.fma.f32(float %ffma_lhs_fneg.30, float %ffma.275, float %ffma.272)
  %ffma.277 = call float @llvm.fma.f32(float %ffma.274, float %ffma.276, float %ffma.275)
  br label %BB_2d20

BB_2d20:                                          ; preds = %BB_2c40
  %cond_not.129 = xor i1 %fchk_px.15, true
  br i1 %cond_not.129, label %BB_2d70, label %BB_2d50_6f40

BB_2d50_6f40:                                     ; preds = %BB_2d20
  %.5335 = zext i32 %fchk_den_bits.15 to i64
  %.5336 = shl i64 %.5335, 32
  %.5337 = lshr i64 %.5336, 23
  %shf_hi.80 = lshr i64 %.5337, 32
  %shf_result.96 = trunc i64 %shf_hi.80 to i32
  %.5339 = zext i32 %fchk_num_bits.15 to i64
  %.5340 = shl i64 %.5339, 32
  %.5341 = lshr i64 %.5340, 23
  %shf_hi.81 = lshr i64 %.5341, 32
  %shf_result.97 = trunc i64 %shf_hi.81 to i32
  %.5345 = and i32 %shf_result.96, 255
  %.5353 = and i32 %shf_result.97, 255
  %iadd3_n1.157 = add i32 %.5345, -1
  %iadd3_n1.158 = add i32 %.5353, -1
  %isetrp_cmp1.204 = icmp ugt i32 %iadd3_n1.157, 253
  %isetrp_cmp1.205 = icmp ugt i32 %iadd3_n1.158, 253
  %isetrp_cmp2.205 = or i1 %isetrp_cmp1.205, %isetrp_cmp1.204
  br label %BB_2d50_6fd0

BB_2d50_6fd0:                                     ; preds = %BB_2d50_6f40
  %cond_not.130 = xor i1 %isetrp_cmp2.205, true
  br i1 %cond_not.130, label %BB_2d50_80006fd0, label %BB_2d50_6ff0

BB_2d50_6ff0:                                     ; preds = %BB_2d50_6fd0
  %fsetrp_lhs_fabs.75 = call float @llvm.nvvm.fabs.f(float %ffma.272)
  %fsetrp_cmp1.90 = fcmp ugt float %fsetrp_lhs_fabs.75, 0x7FF0000000000000
  %fsetrp_lhs_fabs.76 = call float @llvm.nvvm.fabs.f(float %lds.62)
  %fsetrp_cmp1.91 = fcmp ugt float %fsetrp_lhs_fabs.76, 0x7FF0000000000000
  %lop3_a_cast_zext.60 = zext i1 %fsetrp_cmp1.90 to i32
  %lop3_b_cast_zext.60 = zext i1 %fsetrp_cmp1.91 to i32
  %plop3_a_bit.60 = and i32 %lop3_a_cast_zext.60, 1
  %plop3_b_bit.60 = and i32 %lop3_b_cast_zext.60, 1
  %.5360 = xor i32 %plop3_a_bit.60, 1
  %.5361 = xor i32 %plop3_b_bit.60, 1
  %.5363 = and i32 %.5360, %plop3_b_bit.60
  %.5365 = and i32 %plop3_a_bit.60, %.5361
  %.5367 = or i32 %.5363, %.5365
  %.5368 = and i32 %plop3_a_bit.60, %plop3_b_bit.60
  %.5370 = or i32 %.5367, %.5368
  %lop3_pred_cmp.105 = icmp ne i32 %.5370, 0
  br label %BB_2d50_7020

BB_2d50_7020:                                     ; preds = %BB_2d50_6ff0
  %258 = zext i1 %lop3_pred_cmp.105 to i32
  %259 = icmp ne i32 %258, 0
  br i1 %259, label %BB_2d50_7580, label %BB_2d50_7030

BB_2d50_7030:                                     ; preds = %BB_2d50_7020
  %.5373 = xor i32 %fchk_den_bits.15, -1
  %.5375 = xor i32 %fchk_num_bits.15, -1
  %.5376 = and i32 %.5373, 2147483647
  %.5377 = and i32 %.5376, %fchk_num_bits.15
  %.5379 = and i32 %fchk_aden.15, %.5375
  %.5380 = or i32 %.5377, %.5379
  %.5382 = and i32 %fchk_aden.15, %fchk_num_bits.15
  %.5383 = or i32 %.5380, %.5382
  %lop3_pred_cmp.106 = icmp ne i32 %.5383, 0
  br label %BB_2d50_7040

BB_2d50_7040:                                     ; preds = %BB_2d50_7030
  %cond_not.131 = xor i1 %lop3_pred_cmp.106, true
  br i1 %cond_not.131, label %BB_2d50_7560, label %BB_2d50_7050

BB_2d50_7050:                                     ; preds = %BB_2d50_7040
  %fsetrp_cmp1.92 = fcmp une float %fsetrp_lhs_fabs.75, 0x7FF0000000000000
  %fsetrp_cmp1.93 = fcmp une float %fsetrp_lhs_fabs.76, 0x7FF0000000000000
  br label %BB_2d50_7080

BB_2d50_7080:                                     ; preds = %BB_2d50_7050
  %cond_not.132 = xor i1 %fsetrp_cmp1.93, true
  br i1 %cond_not.132, label %BB_2d50_80007080, label %BB_2d50_7090

BB_2d50_80007080:                                 ; preds = %BB_2d50_7080
  %bra_cond_not.15 = xor i1 %fsetrp_cmp1.92, true
  br i1 %bra_cond_not.15, label %BB_2d50_7560, label %BB_2d50_7090

BB_2d50_7090:                                     ; preds = %BB_2d50_80007080, %BB_2d50_7080
  %lop3_pred_cmp.107 = icmp ne i32 %fchk_anum.15, 0
  %lop3_a_cast_zext.61 = zext i1 %fsetrp_cmp1.93 to i32
  %lop3_b_cast_zext.61 = zext i1 %lop3_pred_cmp.107 to i32
  %plop3_a_bit.61 = and i32 %lop3_a_cast_zext.61, 1
  %plop3_b_bit.61 = and i32 %lop3_b_cast_zext.61, 1
  %.5397 = xor i32 %plop3_a_bit.61, 1
  %.5398 = xor i32 %plop3_b_bit.61, 1
  %.5400 = and i32 %.5397, %.5398
  %.5402 = and i32 %.5397, %plop3_b_bit.61
  %.5404 = or i32 %.5400, %.5402
  %.5405 = and i32 %plop3_a_bit.61, %.5398
  %.5407 = or i32 %.5404, %.5405
  %lop3_pred_cmp.108 = icmp ne i32 %.5407, 0
  br label %BB_2d50_70b0

BB_2d50_70b0:                                     ; preds = %BB_2d50_7090
  %260 = zext i1 %lop3_pred_cmp.108 to i32
  %261 = icmp ne i32 %260, 0
  br i1 %261, label %BB_2d50_7540, label %BB_2d50_70c0

BB_2d50_70c0:                                     ; preds = %BB_2d50_70b0
  %lop3_pred_cmp.109 = icmp ne i32 %fchk_aden.15, 0
  %lop3_a_cast_zext.62 = zext i1 %fsetrp_cmp1.92 to i32
  %lop3_b_cast_zext.62 = zext i1 %lop3_pred_cmp.109 to i32
  %plop3_a_bit.62 = and i32 %lop3_a_cast_zext.62, 1
  %plop3_b_bit.62 = and i32 %lop3_b_cast_zext.62, 1
  %.5418 = xor i32 %plop3_a_bit.62, 1
  %.5419 = xor i32 %plop3_b_bit.62, 1
  %.5421 = and i32 %.5418, %.5419
  %.5423 = and i32 %.5418, %plop3_b_bit.62
  %.5425 = or i32 %.5421, %.5423
  %.5426 = and i32 %plop3_a_bit.62, %.5419
  %.5428 = or i32 %.5425, %.5426
  %lop3_pred_cmp.110 = icmp ne i32 %.5428, 0
  br label %BB_2d50_70e0

BB_2d50_70e0:                                     ; preds = %BB_2d50_70c0
  %262 = zext i1 %lop3_pred_cmp.110 to i32
  %263 = icmp ne i32 %262, 0
  br i1 %263, label %BB_2d50_7510, label %BB_2d50_70f0

BB_2d50_70f0:                                     ; preds = %BB_2d50_70e0
  %isetrp_cmp1.206 = icmp sge i32 %iadd3_n1.158, 0
  %isetrp_cmp1.207 = icmp sge i32 %iadd3_n1.157, 0
  br label %BB_2d50_7130

BB_2d50_7130:                                     ; preds = %BB_2d50_70f0
  %264 = zext i1 %isetrp_cmp1.206 to i32
  %265 = icmp ne i32 %264, 0
  br i1 %265, label %BB_2d50_80007130, label %BB_2d50_7140

BB_2d50_80007130:                                 ; preds = %BB_2d50_7130
  br label %BB_2d50_7140

BB_2d50_7140:                                     ; preds = %BB_2d50_80007130, %BB_2d50_7130
  %phi.256 = phi i32 [ 0, %BB_2d50_80007130 ], [ %iadd3_n1.157, %BB_2d50_7130 ]
  %cond_not.133 = xor i1 %isetrp_cmp1.206, true
  br i1 %cond_not.133, label %BB_2d50_80007140, label %BB_2d50_7160

BB_2d50_80007140:                                 ; preds = %BB_2d50_7140
  %ffma.278 = call float @llvm.fma.f32(float %ffma.272, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R3061_bitcast = bitcast float %ffma.278 to i32
  br label %BB_2d50_7160

BB_2d50_7160:                                     ; preds = %BB_2d50_80007140, %BB_2d50_7140
  %phi.257 = phi i32 [ %phi_cast_R3061_bitcast, %BB_2d50_80007140 ], [ %fchk_num_bits.15, %BB_2d50_7140 ]
  %phi.258 = phi i32 [ -64, %BB_2d50_80007140 ], [ %phi.256, %BB_2d50_7140 ]
  %cond_not.134 = xor i1 %isetrp_cmp1.207, true
  br i1 %cond_not.134, label %BB_2d50_80007160, label %BB_2d50_7180

BB_2d50_80007160:                                 ; preds = %BB_2d50_7160
  %ffma.279 = call float @llvm.fma.f32(float %lds.62, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.31 = add i32 %phi.258, 64
  %phi_cast_R597_bitcast = bitcast float %ffma.279 to i32
  br label %BB_2d50_7180

BB_2d50_7510:                                     ; preds = %BB_2d50_70e0
  %.5441 = and i32 %.5373, -2147483648
  %.5442 = and i32 %.5441, %fchk_num_bits.15
  %.5443 = and i32 %fchk_den_bits.15, -2147483648
  %.5444 = and i32 %.5443, %.5375
  %.5445 = or i32 %.5442, %.5444
  %.5446 = xor i32 %.5445, -1
  %.5449 = and i32 %.5446, 2139095040
  %.5456 = or i32 %.5449, %.5445
  %phi_cast_R3066_bitcast = bitcast i32 %.5456 to float
  br label %BB_2d50_7590

BB_2d50_7540:                                     ; preds = %BB_2d50_70b0
  %.5470 = and i32 %.5373, -2147483648
  %.5471 = and i32 %.5470, %fchk_num_bits.15
  %.5472 = and i32 %fchk_den_bits.15, -2147483648
  %.5473 = and i32 %.5472, %.5375
  %.5474 = or i32 %.5471, %.5473
  %phi_cast_R3067_bitcast = bitcast i32 %.5474 to float
  br label %BB_2d50_7590

BB_2d50_7560:                                     ; preds = %BB_2d50_80007080, %BB_2d50_7040
  %mufu_rsq.15 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_2d50_7590

BB_2d50_7580:                                     ; preds = %BB_2d50_7020
  %fadd.30 = fadd float %ffma.272, %lds.62
  br label %BB_2d50_7590

BB_2d50_80006fd0:                                 ; preds = %BB_2d50_6fd0
  br label %BB_2d50_7180

BB_2d50_7180:                                     ; preds = %BB_2d50_80006fd0, %BB_2d50_80007160, %BB_2d50_7160
  %phi.259 = phi i32 [ %fchk_den_bits.15, %BB_2d50_80006fd0 ], [ %phi_cast_R597_bitcast, %BB_2d50_80007160 ], [ %fchk_den_bits.15, %BB_2d50_7160 ]
  %phi.260 = phi i32 [ %fchk_num_bits.15, %BB_2d50_80006fd0 ], [ %phi.257, %BB_2d50_80007160 ], [ %phi.257, %BB_2d50_7160 ]
  %phi.261 = phi i32 [ 0, %BB_2d50_80006fd0 ], [ %viadd.31, %BB_2d50_80007160 ], [ %phi.258, %BB_2d50_7160 ]
  %.5479 = zext i32 %.5345 to i64
  %.5482 = shl i64 %.5479, 23
  %.5483 = and i64 %.5482, 4294967295
  %.5484 = add i64 %.5483, 3229614080
  %.5485 = trunc i64 %.5484 to i32
  %iadd3_n1.160 = add i32 %.5353, -127
  %iadd3_o1_not.30 = xor i32 %.5485, -1
  %iadd3_o1_neg.30 = add i32 %iadd3_o1_not.30, 1
  %iadd3_n1.161 = add i32 %iadd3_o1_neg.30, %phi.259
  %imad_tmp.62 = mul i32 %iadd3_n1.160, -8388608
  %imad.73 = add i32 %imad_tmp.62, %phi.260
  %mufu_src_bitcast.15 = bitcast i32 %iadd3_n1.161 to float
  %mufu_rcp.31 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.15)
  %fadd_lhs_fneg.15 = fneg float %mufu_src_bitcast.15
  %fadd.31 = fadd float %fadd_lhs_fneg.15, 0.000000e+00
  %iadd3_o3_not.15 = xor i32 %.5345, -1
  %iadd3_o3_neg.15 = add i32 %iadd3_o3_not.15, 1
  %iadd3_n2.162 = add i32 %.5353, %iadd3_o3_neg.15
  %iadd3_n1.163 = add i32 %iadd3_n2.162, %phi.261
  %ffma.280 = call float @llvm.fma.f32(float %mufu_rcp.31, float %fadd.31, float 1.000000e+00)
  %ffma.281 = call float @llvm.fma.f32(float %mufu_rcp.31, float %ffma.280, float %mufu_rcp.31)
  %ffma_lhs_bitcast.15 = bitcast i32 %imad.73 to float
  %ffma.282 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.15, float %ffma.281, float 0.000000e+00)
  %ffma.283 = call float @llvm.fma.f32(float %fadd.31, float %ffma.282, float %ffma_lhs_bitcast.15)
  %ffma.284 = call float @llvm.fma.f32(float %ffma.281, float %ffma.283, float %ffma.282)
  %ffma.285 = call float @llvm.fma.f32(float %fadd.31, float %ffma.284, float %ffma_lhs_bitcast.15)
  %ffma.286 = call float @llvm.fma.f32(float %ffma.281, float %ffma.285, float %ffma.284)
  %shf_hi_bitcast.47 = bitcast float %ffma.286 to i32
  %.5487 = zext i32 %shf_hi_bitcast.47 to i64
  %.5488 = shl i64 %.5487, 32
  %.5489 = lshr i64 %.5488, 23
  %shf_hi.82 = lshr i64 %.5489, 32
  %shf_result.98 = trunc i64 %shf_hi.82 to i32
  %.5493 = and i32 %shf_result.98, 255
  %imad.74 = add i32 %.5493, %iadd3_n1.163
  %iadd3_n1.164 = add i32 %imad.74, -1
  %isetrp_cmp1.208 = icmp uge i32 %iadd3_n1.164, 254
  br label %BB_2d50_72d0

BB_2d50_72d0:                                     ; preds = %BB_2d50_7180
  %cond_not.135 = xor i1 %isetrp_cmp1.208, true
  br i1 %cond_not.135, label %BB_2d50_74e0, label %BB_2d50_72e0

BB_2d50_72e0:                                     ; preds = %BB_2d50_72d0
  %isetrp_cmp1.209 = icmp sgt i32 %imad.74, 254
  br label %BB_2d50_72f0

BB_2d50_72f0:                                     ; preds = %BB_2d50_72e0
  %266 = zext i1 %isetrp_cmp1.209 to i32
  %267 = icmp ne i32 %266, 0
  br i1 %267, label %BB_2d50_74b0, label %BB_2d50_7300

BB_2d50_7300:                                     ; preds = %BB_2d50_72f0
  %isetrp_cmp1.210 = icmp sge i32 %imad.74, 1
  br label %BB_2d50_7310

BB_2d50_7310:                                     ; preds = %BB_2d50_7300
  %phi_cast_R2144_bitcast.2 = bitcast i32 %iadd3_n1.163 to float
  br i1 %isetrp_cmp1.210, label %BB_2d50_7590, label %BB_2d50_7320

BB_2d50_7320:                                     ; preds = %BB_2d50_7310
  %isetrp_cmp1.211 = icmp sge i32 %imad.74, -24
  %.5507 = and i32 %shf_hi_bitcast.47, -2147483648
  br label %BB_2d50_7340

BB_2d50_7340:                                     ; preds = %BB_2d50_7320
  %cond_not.136 = xor i1 %isetrp_cmp1.211, true
  %phi_cast_R3074_bitcast = bitcast i32 %.5507 to float
  br i1 %cond_not.136, label %BB_2d50_7590, label %BB_2d50_7350

BB_2d50_7350:                                     ; preds = %BB_2d50_7340
  %ffma_rz.15 = call float @llvm.nvvm.fma.rz.f(float %ffma.281, float %ffma.285, float %ffma.284)
  %iadd3_n1.165 = add i32 %imad.74, 32
  %lop3_a_bitcast.126 = bitcast float %ffma_rz.15 to i32
  %.5517 = and i32 %lop3_a_bitcast.126, 8388607
  %ffma_rp.15 = call float @llvm.nvvm.fma.rp.f(float %ffma.281, float %ffma.285, float %ffma.284)
  %ffma_rm.15 = call float @llvm.nvvm.fma.rm.f(float %ffma.281, float %ffma.285, float %ffma.284)
  %isetrp_cmp1.213 = icmp ne i32 %imad.74, 0
  %.5532 = or i32 8388608, %.5517
  %iadd3_o1_not.31 = xor i32 %imad.74, -1
  %iadd3_o1_neg.31 = add i32 %iadd3_o1_not.31, 1
  %.5542 = zext i32 %.5532 to i64
  %shf_shift_64.99 = zext i32 %iadd3_n1.165 to i64
  %.5545 = shl i64 %.5542, %shf_shift_64.99
  %shf_result.99 = trunc i64 %.5545 to i32
  %fsetrp_cmp1.95 = fcmp une float %ffma_rp.15, %ffma_rm.15
  %isetrp_cmp1.214 = icmp ne i32 %shf_result.99, 0
  %isetrp_cmp2.214 = and i1 %isetrp_cmp1.214, %isetrp_cmp1.213
  %.5548 = shl i64 %.5542, 32
  %shf_shift_64.100 = zext i32 %iadd3_o1_neg.31 to i64
  %.5549 = lshr i64 %.5548, %shf_shift_64.100
  %shf_hi.83 = lshr i64 %.5549, 32
  %shf_result.100 = trunc i64 %shf_hi.83 to i32
  %lop3_a_cast_zext.63 = zext i1 %fsetrp_cmp1.95 to i32
  %lop3_b_cast_zext.63 = zext i1 %isetrp_cmp2.214 to i32
  %plop3_a_bit.63 = and i32 %lop3_a_cast_zext.63, 1
  %plop3_b_bit.63 = and i32 %lop3_b_cast_zext.63, 1
  %.5550 = xor i32 %plop3_a_bit.63, 1
  %.5551 = xor i32 %plop3_b_bit.63, 1
  %.5553 = and i32 %.5550, %plop3_b_bit.63
  %.5555 = and i32 %plop3_a_bit.63, %.5551
  %.5557 = or i32 %.5553, %.5555
  %.5558 = and i32 %plop3_a_bit.63, %plop3_b_bit.63
  %.5560 = or i32 %.5557, %.5558
  %lop3_pred_cmp.111 = icmp ne i32 %.5560, 0
  %.5562 = zext i32 %shf_result.100 to i64
  %.5563 = shl i64 %.5562, 32
  %.5564 = lshr i64 %.5563, 1
  %shf_hi.84 = lshr i64 %.5564, 32
  %shf_result.101 = trunc i64 %shf_hi.84 to i32
  %sel_pred_not.15 = xor i1 %lop3_pred_cmp.111, true
  %sel.31 = select i1 %sel_pred_not.15, i32 0, i32 1
  %.5565 = xor i32 %sel.31, -1
  %.5567 = xor i32 %shf_result.101, -1
  %.5568 = and i32 %.5565, 1
  %.5569 = and i32 %.5568, %shf_result.101
  %.5577 = and i32 %sel.31, %.5567
  %.5578 = or i32 %.5569, %.5577
  %.5580 = and i32 %sel.31, %shf_result.101
  %.5581 = or i32 %.5578, %.5580
  %.5585 = and i32 %.5581, %shf_result.100
  %imad.75 = add i32 %shf_result.101, %.5585
  %.5590 = xor i32 %imad.75, -1
  %.5591 = xor i32 %.5507, -1
  %.5593 = and i32 %.5590, %.5507
  %.5598 = and i32 %imad.75, %.5591
  %.5600 = or i32 %.5593, %.5598
  %.5604 = and i32 %imad.75, %.5507
  %.5606 = or i32 %.5600, %.5604
  %phi_cast_R3077_bitcast = bitcast i32 %.5606 to float
  %phi_cast_R2147_bitcast = bitcast i32 %.5532 to float
  br label %BB_2d50_7590

BB_2d50_74b0:                                     ; preds = %BB_2d50_72f0
  %.5614 = and i32 %shf_hi_bitcast.47, -2147483648
  %.5629 = or i32 2139095040, %.5614
  %phi_cast_R3079_bitcast = bitcast i32 %.5629 to float
  %phi_cast_R2144_bitcast = bitcast i32 %iadd3_n1.163 to float
  br label %BB_2d50_7590

BB_2d50_74e0:                                     ; preds = %BB_2d50_72d0
  %.5640 = zext i32 %iadd3_n1.163 to i64
  %.5643 = shl i64 %.5640, 23
  %.5644 = and i64 %.5643, 4294967295
  %.5645 = add i64 %.5644, %.5487
  %.5646 = trunc i64 %.5645 to i32
  %phi_cast_R3080_bitcast = bitcast i32 %.5646 to float
  %phi_cast_R2144_bitcast.1 = bitcast i32 %iadd3_n1.163 to float
  br label %BB_2d50_7590

BB_2d50_7590:                                     ; preds = %BB_2d50_74e0, %BB_2d50_74b0, %BB_2d50_7350, %BB_2d50_7340, %BB_2d50_7310, %BB_2d50_7580, %BB_2d50_7560, %BB_2d50_7540, %BB_2d50_7510
  %phi.262 = phi float [ %phi_cast_R3077_bitcast, %BB_2d50_7350 ], [ %phi_cast_R3079_bitcast, %BB_2d50_74b0 ], [ %phi_cast_R3080_bitcast, %BB_2d50_74e0 ], [ %ffma.286, %BB_2d50_7310 ], [ %phi_cast_R3074_bitcast, %BB_2d50_7340 ], [ %phi_cast_R3066_bitcast, %BB_2d50_7510 ], [ %phi_cast_R3067_bitcast, %BB_2d50_7540 ], [ %mufu_rsq.15, %BB_2d50_7560 ], [ %fadd.30, %BB_2d50_7580 ]
  %phi.263 = phi float [ %phi_cast_R2147_bitcast, %BB_2d50_7350 ], [ %phi_cast_R2144_bitcast, %BB_2d50_74b0 ], [ %phi_cast_R2144_bitcast.1, %BB_2d50_74e0 ], [ %phi_cast_R2144_bitcast.2, %BB_2d50_7310 ], [ %phi_cast_R2144_bitcast.2, %BB_2d50_7340 ], [ %phi.252, %BB_2d50_7510 ], [ %phi.252, %BB_2d50_7540 ], [ %phi.252, %BB_2d50_7560 ], [ %phi.252, %BB_2d50_7580 ]
  br label %BB_2d70

BB_2d70:                                          ; preds = %BB_2d50_7590, %BB_2d20
  %phi.264 = phi float [ %phi.262, %BB_2d50_7590 ], [ %ffma.277, %BB_2d20 ]
  %phi.265 = phi float [ %phi.263, %BB_2d50_7590 ], [ %phi.252, %BB_2d20 ]
  br label %BB_2d90

BB_2d90:                                          ; preds = %BB_2d70, %BB_2c30
  %phi.266 = phi float [ %phi.264, %BB_2d70 ], [ %phi.251, %BB_2c30 ]
  %phi.267 = phi float [ %phi.265, %BB_2d70 ], [ %phi.252, %BB_2c30 ]
  %phi.268 = phi i32 [ %.75, %BB_2d70 ], [ %phi.253, %BB_2c30 ]
  %phi.269 = phi float [ %phi.264, %BB_2d70 ], [ %phi.254, %BB_2c30 ]
  br label %BB_2dc0

BB_2dc0:                                          ; preds = %BB_2d90
  %shfl_activemask.47 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.47 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.47, float %phi.269, i32 15, i32 31)
  br label %BB_2dd0

BB_2dd0:                                          ; preds = %BB_2dc0
  %isetrp_cmp1.215 = icmp uge i32 %tid_x, 16
  %isetrp_cmp1.216 = icmp ne i32 %tid_x, 16
  br label %BB_2e00

BB_2e00:                                          ; preds = %BB_2dd0
  %268 = zext i1 %isetrp_cmp1.215 to i32
  %269 = icmp ne i32 %268, 0
  br i1 %269, label %BB_80002e00, label %BB_2e20

BB_80002e00:                                      ; preds = %BB_2e00
  %lds_addr_memaddr_offset_add.60 = add i32 %.88, 1980
  %.5654 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.60
  %lds.63 = load volatile float, ptr addrspace(3) %.5654, align 4
  %ffma.287 = call float @llvm.fma.f32(float %shfl_idx.47, float %lds.63, float %phi.255)
  br label %BB_2e20

BB_2e20:                                          ; preds = %BB_80002e00, %BB_2e00
  %phi.270 = phi float [ %ffma.287, %BB_80002e00 ], [ %phi.255, %BB_2e00 ]
  %warp_reconv_mask.15 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.15)
  br i1 %isetrp_cmp1.216, label %BB_2f80, label %BB_2e30

BB_2e30:                                          ; preds = %BB_2e20
  %ffma_addend_fneg.16 = fneg float %phi.270
  %ffma.288 = call float @llvm.fma.f32(float %phi.266, float %phi, float %ffma_addend_fneg.16)
  %lds_addr_memaddr_offset_add.61 = add i32 %.75, 2176
  %.5664 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.61
  %lds.64 = load volatile float, ptr addrspace(3) %.5664, align 4
  %mufu_rcp.32 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.64)
  %fchk_num_bits.16 = bitcast float %ffma.288 to i32
  %fchk_den_bits.16 = bitcast float %lds.64 to i32
  %fchk_aden.16 = and i32 %fchk_den_bits.16, 2147483647
  %fchk_anum.16 = and i32 %fchk_num_bits.16, 2147483647
  %fchk_den_subz.16 = icmp ult i32 %fchk_aden.16, 8388608
  %fchk_den_infnan.16 = icmp uge i32 %fchk_aden.16, 2139095040
  %fchk_num_infnan.16 = icmp uge i32 %fchk_anum.16, 2139095040
  %fchk_den_bad.16 = or i1 %fchk_den_subz.16, %fchk_den_infnan.16
  %fchk_px.16 = or i1 %fchk_den_bad.16, %fchk_num_infnan.16
  %ffma_lhs_fneg.32 = fneg float %lds.64
  %ffma.289 = call float @llvm.fma.f32(float %ffma_lhs_fneg.32, float %mufu_rcp.32, float 1.000000e+00)
  %ffma.290 = call float @llvm.fma.f32(float %mufu_rcp.32, float %ffma.289, float %mufu_rcp.32)
  %ffma.291 = call float @llvm.fma.f32(float %ffma.288, float %ffma.290, float 0.000000e+00)
  %ffma.292 = call float @llvm.fma.f32(float %ffma_lhs_fneg.32, float %ffma.291, float %ffma.288)
  %ffma.293 = call float @llvm.fma.f32(float %ffma.290, float %ffma.292, float %ffma.291)
  br label %BB_2f10

BB_2f10:                                          ; preds = %BB_2e30
  %cond_not.137 = xor i1 %fchk_px.16, true
  br i1 %cond_not.137, label %BB_2f60, label %BB_2f40_6f40

BB_2f40_6f40:                                     ; preds = %BB_2f10
  %.5668 = zext i32 %fchk_den_bits.16 to i64
  %.5669 = shl i64 %.5668, 32
  %.5670 = lshr i64 %.5669, 23
  %shf_hi.85 = lshr i64 %.5670, 32
  %shf_result.102 = trunc i64 %shf_hi.85 to i32
  %.5672 = zext i32 %fchk_num_bits.16 to i64
  %.5673 = shl i64 %.5672, 32
  %.5674 = lshr i64 %.5673, 23
  %shf_hi.86 = lshr i64 %.5674, 32
  %shf_result.103 = trunc i64 %shf_hi.86 to i32
  %.5678 = and i32 %shf_result.102, 255
  %.5686 = and i32 %shf_result.103, 255
  %iadd3_n1.167 = add i32 %.5678, -1
  %iadd3_n1.168 = add i32 %.5686, -1
  %isetrp_cmp1.217 = icmp ugt i32 %iadd3_n1.167, 253
  %isetrp_cmp1.218 = icmp ugt i32 %iadd3_n1.168, 253
  %isetrp_cmp2.218 = or i1 %isetrp_cmp1.218, %isetrp_cmp1.217
  br label %BB_2f40_6fd0

BB_2f40_6fd0:                                     ; preds = %BB_2f40_6f40
  %cond_not.138 = xor i1 %isetrp_cmp2.218, true
  br i1 %cond_not.138, label %BB_2f40_80006fd0, label %BB_2f40_6ff0

BB_2f40_6ff0:                                     ; preds = %BB_2f40_6fd0
  %fsetrp_lhs_fabs.80 = call float @llvm.nvvm.fabs.f(float %ffma.288)
  %fsetrp_cmp1.96 = fcmp ugt float %fsetrp_lhs_fabs.80, 0x7FF0000000000000
  %fsetrp_lhs_fabs.81 = call float @llvm.nvvm.fabs.f(float %lds.64)
  %fsetrp_cmp1.97 = fcmp ugt float %fsetrp_lhs_fabs.81, 0x7FF0000000000000
  %lop3_a_cast_zext.64 = zext i1 %fsetrp_cmp1.96 to i32
  %lop3_b_cast_zext.64 = zext i1 %fsetrp_cmp1.97 to i32
  %plop3_a_bit.64 = and i32 %lop3_a_cast_zext.64, 1
  %plop3_b_bit.64 = and i32 %lop3_b_cast_zext.64, 1
  %.5693 = xor i32 %plop3_a_bit.64, 1
  %.5694 = xor i32 %plop3_b_bit.64, 1
  %.5696 = and i32 %.5693, %plop3_b_bit.64
  %.5698 = and i32 %plop3_a_bit.64, %.5694
  %.5700 = or i32 %.5696, %.5698
  %.5701 = and i32 %plop3_a_bit.64, %plop3_b_bit.64
  %.5703 = or i32 %.5700, %.5701
  %lop3_pred_cmp.112 = icmp ne i32 %.5703, 0
  br label %BB_2f40_7020

BB_2f40_7020:                                     ; preds = %BB_2f40_6ff0
  %270 = zext i1 %lop3_pred_cmp.112 to i32
  %271 = icmp ne i32 %270, 0
  br i1 %271, label %BB_2f40_7580, label %BB_2f40_7030

BB_2f40_7030:                                     ; preds = %BB_2f40_7020
  %.5706 = xor i32 %fchk_den_bits.16, -1
  %.5708 = xor i32 %fchk_num_bits.16, -1
  %.5709 = and i32 %.5706, 2147483647
  %.5710 = and i32 %.5709, %fchk_num_bits.16
  %.5712 = and i32 %fchk_aden.16, %.5708
  %.5713 = or i32 %.5710, %.5712
  %.5715 = and i32 %fchk_aden.16, %fchk_num_bits.16
  %.5716 = or i32 %.5713, %.5715
  %lop3_pred_cmp.113 = icmp ne i32 %.5716, 0
  br label %BB_2f40_7040

BB_2f40_7040:                                     ; preds = %BB_2f40_7030
  %cond_not.139 = xor i1 %lop3_pred_cmp.113, true
  br i1 %cond_not.139, label %BB_2f40_7560, label %BB_2f40_7050

BB_2f40_7050:                                     ; preds = %BB_2f40_7040
  %fsetrp_cmp1.98 = fcmp une float %fsetrp_lhs_fabs.80, 0x7FF0000000000000
  %fsetrp_cmp1.99 = fcmp une float %fsetrp_lhs_fabs.81, 0x7FF0000000000000
  br label %BB_2f40_7080

BB_2f40_7080:                                     ; preds = %BB_2f40_7050
  %cond_not.140 = xor i1 %fsetrp_cmp1.99, true
  br i1 %cond_not.140, label %BB_2f40_80007080, label %BB_2f40_7090

BB_2f40_80007080:                                 ; preds = %BB_2f40_7080
  %bra_cond_not.16 = xor i1 %fsetrp_cmp1.98, true
  br i1 %bra_cond_not.16, label %BB_2f40_7560, label %BB_2f40_7090

BB_2f40_7090:                                     ; preds = %BB_2f40_80007080, %BB_2f40_7080
  %lop3_pred_cmp.114 = icmp ne i32 %fchk_anum.16, 0
  %lop3_a_cast_zext.65 = zext i1 %fsetrp_cmp1.99 to i32
  %lop3_b_cast_zext.65 = zext i1 %lop3_pred_cmp.114 to i32
  %plop3_a_bit.65 = and i32 %lop3_a_cast_zext.65, 1
  %plop3_b_bit.65 = and i32 %lop3_b_cast_zext.65, 1
  %.5730 = xor i32 %plop3_a_bit.65, 1
  %.5731 = xor i32 %plop3_b_bit.65, 1
  %.5733 = and i32 %.5730, %.5731
  %.5735 = and i32 %.5730, %plop3_b_bit.65
  %.5737 = or i32 %.5733, %.5735
  %.5738 = and i32 %plop3_a_bit.65, %.5731
  %.5740 = or i32 %.5737, %.5738
  %lop3_pred_cmp.115 = icmp ne i32 %.5740, 0
  br label %BB_2f40_70b0

BB_2f40_70b0:                                     ; preds = %BB_2f40_7090
  %272 = zext i1 %lop3_pred_cmp.115 to i32
  %273 = icmp ne i32 %272, 0
  br i1 %273, label %BB_2f40_7540, label %BB_2f40_70c0

BB_2f40_70c0:                                     ; preds = %BB_2f40_70b0
  %lop3_pred_cmp.116 = icmp ne i32 %fchk_aden.16, 0
  %lop3_a_cast_zext.66 = zext i1 %fsetrp_cmp1.98 to i32
  %lop3_b_cast_zext.66 = zext i1 %lop3_pred_cmp.116 to i32
  %plop3_a_bit.66 = and i32 %lop3_a_cast_zext.66, 1
  %plop3_b_bit.66 = and i32 %lop3_b_cast_zext.66, 1
  %.5751 = xor i32 %plop3_a_bit.66, 1
  %.5752 = xor i32 %plop3_b_bit.66, 1
  %.5754 = and i32 %.5751, %.5752
  %.5756 = and i32 %.5751, %plop3_b_bit.66
  %.5758 = or i32 %.5754, %.5756
  %.5759 = and i32 %plop3_a_bit.66, %.5752
  %.5761 = or i32 %.5758, %.5759
  %lop3_pred_cmp.117 = icmp ne i32 %.5761, 0
  br label %BB_2f40_70e0

BB_2f40_70e0:                                     ; preds = %BB_2f40_70c0
  %274 = zext i1 %lop3_pred_cmp.117 to i32
  %275 = icmp ne i32 %274, 0
  br i1 %275, label %BB_2f40_7510, label %BB_2f40_70f0

BB_2f40_70f0:                                     ; preds = %BB_2f40_70e0
  %isetrp_cmp1.219 = icmp sge i32 %iadd3_n1.168, 0
  %isetrp_cmp1.220 = icmp sge i32 %iadd3_n1.167, 0
  br label %BB_2f40_7130

BB_2f40_7130:                                     ; preds = %BB_2f40_70f0
  %276 = zext i1 %isetrp_cmp1.219 to i32
  %277 = icmp ne i32 %276, 0
  br i1 %277, label %BB_2f40_80007130, label %BB_2f40_7140

BB_2f40_80007130:                                 ; preds = %BB_2f40_7130
  br label %BB_2f40_7140

BB_2f40_7140:                                     ; preds = %BB_2f40_80007130, %BB_2f40_7130
  %phi.271 = phi i32 [ 0, %BB_2f40_80007130 ], [ %iadd3_n1.167, %BB_2f40_7130 ]
  %cond_not.141 = xor i1 %isetrp_cmp1.219, true
  br i1 %cond_not.141, label %BB_2f40_80007140, label %BB_2f40_7160

BB_2f40_80007140:                                 ; preds = %BB_2f40_7140
  %ffma.294 = call float @llvm.fma.f32(float %ffma.288, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R3084_bitcast = bitcast float %ffma.294 to i32
  br label %BB_2f40_7160

BB_2f40_7160:                                     ; preds = %BB_2f40_80007140, %BB_2f40_7140
  %phi.272 = phi i32 [ %phi_cast_R3084_bitcast, %BB_2f40_80007140 ], [ %fchk_num_bits.16, %BB_2f40_7140 ]
  %phi.273 = phi i32 [ -64, %BB_2f40_80007140 ], [ %phi.271, %BB_2f40_7140 ]
  %cond_not.142 = xor i1 %isetrp_cmp1.220, true
  br i1 %cond_not.142, label %BB_2f40_80007160, label %BB_2f40_7180

BB_2f40_80007160:                                 ; preds = %BB_2f40_7160
  %ffma.295 = call float @llvm.fma.f32(float %lds.64, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.33 = add i32 %phi.273, 64
  %phi_cast_R612_bitcast = bitcast float %ffma.295 to i32
  br label %BB_2f40_7180

BB_2f40_7510:                                     ; preds = %BB_2f40_70e0
  %.5774 = and i32 %.5706, -2147483648
  %.5775 = and i32 %.5774, %fchk_num_bits.16
  %.5776 = and i32 %fchk_den_bits.16, -2147483648
  %.5777 = and i32 %.5776, %.5708
  %.5778 = or i32 %.5775, %.5777
  %.5779 = xor i32 %.5778, -1
  %.5782 = and i32 %.5779, 2139095040
  %.5789 = or i32 %.5782, %.5778
  %phi_cast_R6_bitcast = bitcast i32 %.5789 to float
  br label %BB_2f40_7590

BB_2f40_7540:                                     ; preds = %BB_2f40_70b0
  %.5803 = and i32 %.5706, -2147483648
  %.5804 = and i32 %.5803, %fchk_num_bits.16
  %.5805 = and i32 %fchk_den_bits.16, -2147483648
  %.5806 = and i32 %.5805, %.5708
  %.5807 = or i32 %.5804, %.5806
  %phi_cast_R7_bitcast = bitcast i32 %.5807 to float
  br label %BB_2f40_7590

BB_2f40_7560:                                     ; preds = %BB_2f40_80007080, %BB_2f40_7040
  %mufu_rsq.16 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_2f40_7590

BB_2f40_7580:                                     ; preds = %BB_2f40_7020
  %fadd.32 = fadd float %ffma.288, %lds.64
  br label %BB_2f40_7590

BB_2f40_80006fd0:                                 ; preds = %BB_2f40_6fd0
  br label %BB_2f40_7180

BB_2f40_7180:                                     ; preds = %BB_2f40_80006fd0, %BB_2f40_80007160, %BB_2f40_7160
  %phi.274 = phi i32 [ %fchk_den_bits.16, %BB_2f40_80006fd0 ], [ %phi_cast_R612_bitcast, %BB_2f40_80007160 ], [ %fchk_den_bits.16, %BB_2f40_7160 ]
  %phi.275 = phi i32 [ %fchk_num_bits.16, %BB_2f40_80006fd0 ], [ %phi.272, %BB_2f40_80007160 ], [ %phi.272, %BB_2f40_7160 ]
  %phi.276 = phi i32 [ 0, %BB_2f40_80006fd0 ], [ %viadd.33, %BB_2f40_80007160 ], [ %phi.273, %BB_2f40_7160 ]
  %.5812 = zext i32 %.5678 to i64
  %.5815 = shl i64 %.5812, 23
  %.5816 = and i64 %.5815, 4294967295
  %.5817 = add i64 %.5816, 3229614080
  %.5818 = trunc i64 %.5817 to i32
  %iadd3_n1.170 = add i32 %.5686, -127
  %iadd3_o1_not.32 = xor i32 %.5818, -1
  %iadd3_o1_neg.32 = add i32 %iadd3_o1_not.32, 1
  %iadd3_n1.171 = add i32 %iadd3_o1_neg.32, %phi.274
  %imad_tmp.66 = mul i32 %iadd3_n1.170, -8388608
  %imad.77 = add i32 %imad_tmp.66, %phi.275
  %mufu_src_bitcast.16 = bitcast i32 %iadd3_n1.171 to float
  %mufu_rcp.33 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.16)
  %fadd_lhs_fneg.16 = fneg float %mufu_src_bitcast.16
  %fadd.33 = fadd float %fadd_lhs_fneg.16, 0.000000e+00
  %iadd3_o3_not.16 = xor i32 %.5678, -1
  %iadd3_o3_neg.16 = add i32 %iadd3_o3_not.16, 1
  %iadd3_n2.172 = add i32 %.5686, %iadd3_o3_neg.16
  %iadd3_n1.173 = add i32 %iadd3_n2.172, %phi.276
  %ffma.296 = call float @llvm.fma.f32(float %mufu_rcp.33, float %fadd.33, float 1.000000e+00)
  %ffma.297 = call float @llvm.fma.f32(float %mufu_rcp.33, float %ffma.296, float %mufu_rcp.33)
  %ffma_lhs_bitcast.16 = bitcast i32 %imad.77 to float
  %ffma.298 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.16, float %ffma.297, float 0.000000e+00)
  %ffma.299 = call float @llvm.fma.f32(float %fadd.33, float %ffma.298, float %ffma_lhs_bitcast.16)
  %ffma.300 = call float @llvm.fma.f32(float %ffma.297, float %ffma.299, float %ffma.298)
  %ffma.301 = call float @llvm.fma.f32(float %fadd.33, float %ffma.300, float %ffma_lhs_bitcast.16)
  %ffma.302 = call float @llvm.fma.f32(float %ffma.297, float %ffma.301, float %ffma.300)
  %shf_hi_bitcast.50 = bitcast float %ffma.302 to i32
  %.5820 = zext i32 %shf_hi_bitcast.50 to i64
  %.5821 = shl i64 %.5820, 32
  %.5822 = lshr i64 %.5821, 23
  %shf_hi.87 = lshr i64 %.5822, 32
  %shf_result.104 = trunc i64 %shf_hi.87 to i32
  %.5826 = and i32 %shf_result.104, 255
  %imad.78 = add i32 %.5826, %iadd3_n1.173
  %iadd3_n1.174 = add i32 %imad.78, -1
  %isetrp_cmp1.221 = icmp uge i32 %iadd3_n1.174, 254
  br label %BB_2f40_72d0

BB_2f40_72d0:                                     ; preds = %BB_2f40_7180
  %cond_not.143 = xor i1 %isetrp_cmp1.221, true
  br i1 %cond_not.143, label %BB_2f40_74e0, label %BB_2f40_72e0

BB_2f40_72e0:                                     ; preds = %BB_2f40_72d0
  %isetrp_cmp1.222 = icmp sgt i32 %imad.78, 254
  br label %BB_2f40_72f0

BB_2f40_72f0:                                     ; preds = %BB_2f40_72e0
  %278 = zext i1 %isetrp_cmp1.222 to i32
  %279 = icmp ne i32 %278, 0
  br i1 %279, label %BB_2f40_74b0, label %BB_2f40_7300

BB_2f40_7300:                                     ; preds = %BB_2f40_72f0
  %isetrp_cmp1.223 = icmp sge i32 %imad.78, 1
  br label %BB_2f40_7310

BB_2f40_7310:                                     ; preds = %BB_2f40_7300
  %phi_cast_R2154_bitcast.2 = bitcast i32 %iadd3_n1.173 to float
  br i1 %isetrp_cmp1.223, label %BB_2f40_7590, label %BB_2f40_7320

BB_2f40_7320:                                     ; preds = %BB_2f40_7310
  %isetrp_cmp1.224 = icmp sge i32 %imad.78, -24
  %.5840 = and i32 %shf_hi_bitcast.50, -2147483648
  br label %BB_2f40_7340

BB_2f40_7340:                                     ; preds = %BB_2f40_7320
  %cond_not.144 = xor i1 %isetrp_cmp1.224, true
  %phi_cast_R15_bitcast = bitcast i32 %.5840 to float
  br i1 %cond_not.144, label %BB_2f40_7590, label %BB_2f40_7350

BB_2f40_7350:                                     ; preds = %BB_2f40_7340
  %ffma_rz.16 = call float @llvm.nvvm.fma.rz.f(float %ffma.297, float %ffma.301, float %ffma.300)
  %iadd3_n1.175 = add i32 %imad.78, 32
  %lop3_a_bitcast.134 = bitcast float %ffma_rz.16 to i32
  %.5850 = and i32 %lop3_a_bitcast.134, 8388607
  %ffma_rp.16 = call float @llvm.nvvm.fma.rp.f(float %ffma.297, float %ffma.301, float %ffma.300)
  %ffma_rm.16 = call float @llvm.nvvm.fma.rm.f(float %ffma.297, float %ffma.301, float %ffma.300)
  %isetrp_cmp1.226 = icmp ne i32 %imad.78, 0
  %.5865 = or i32 8388608, %.5850
  %iadd3_o1_not.33 = xor i32 %imad.78, -1
  %iadd3_o1_neg.33 = add i32 %iadd3_o1_not.33, 1
  %.5875 = zext i32 %.5865 to i64
  %shf_shift_64.105 = zext i32 %iadd3_n1.175 to i64
  %.5878 = shl i64 %.5875, %shf_shift_64.105
  %shf_result.105 = trunc i64 %.5878 to i32
  %fsetrp_cmp1.101 = fcmp une float %ffma_rp.16, %ffma_rm.16
  %isetrp_cmp1.227 = icmp ne i32 %shf_result.105, 0
  %isetrp_cmp2.227 = and i1 %isetrp_cmp1.227, %isetrp_cmp1.226
  %.5881 = shl i64 %.5875, 32
  %shf_shift_64.106 = zext i32 %iadd3_o1_neg.33 to i64
  %.5882 = lshr i64 %.5881, %shf_shift_64.106
  %shf_hi.88 = lshr i64 %.5882, 32
  %shf_result.106 = trunc i64 %shf_hi.88 to i32
  %lop3_a_cast_zext.67 = zext i1 %fsetrp_cmp1.101 to i32
  %lop3_b_cast_zext.67 = zext i1 %isetrp_cmp2.227 to i32
  %plop3_a_bit.67 = and i32 %lop3_a_cast_zext.67, 1
  %plop3_b_bit.67 = and i32 %lop3_b_cast_zext.67, 1
  %.5883 = xor i32 %plop3_a_bit.67, 1
  %.5884 = xor i32 %plop3_b_bit.67, 1
  %.5886 = and i32 %.5883, %plop3_b_bit.67
  %.5888 = and i32 %plop3_a_bit.67, %.5884
  %.5890 = or i32 %.5886, %.5888
  %.5891 = and i32 %plop3_a_bit.67, %plop3_b_bit.67
  %.5893 = or i32 %.5890, %.5891
  %lop3_pred_cmp.118 = icmp ne i32 %.5893, 0
  %.5895 = zext i32 %shf_result.106 to i64
  %.5896 = shl i64 %.5895, 32
  %.5897 = lshr i64 %.5896, 1
  %shf_hi.89 = lshr i64 %.5897, 32
  %shf_result.107 = trunc i64 %shf_hi.89 to i32
  %sel_pred_not.16 = xor i1 %lop3_pred_cmp.118, true
  %sel.33 = select i1 %sel_pred_not.16, i32 0, i32 1
  %.5898 = xor i32 %sel.33, -1
  %.5900 = xor i32 %shf_result.107, -1
  %.5901 = and i32 %.5898, 1
  %.5902 = and i32 %.5901, %shf_result.107
  %.5910 = and i32 %sel.33, %.5900
  %.5911 = or i32 %.5902, %.5910
  %.5913 = and i32 %sel.33, %shf_result.107
  %.5914 = or i32 %.5911, %.5913
  %.5918 = and i32 %.5914, %shf_result.106
  %imad.79 = add i32 %shf_result.107, %.5918
  %.5923 = xor i32 %imad.79, -1
  %.5924 = xor i32 %.5840, -1
  %.5926 = and i32 %.5923, %.5840
  %.5931 = and i32 %imad.79, %.5924
  %.5933 = or i32 %.5926, %.5931
  %.5937 = and i32 %imad.79, %.5840
  %.5939 = or i32 %.5933, %.5937
  %phi_cast_R16_bitcast = bitcast i32 %.5939 to float
  %phi_cast_R2158_bitcast = bitcast i32 %.5865 to float
  br label %BB_2f40_7590

BB_2f40_74b0:                                     ; preds = %BB_2f40_72f0
  %.5947 = and i32 %shf_hi_bitcast.50, -2147483648
  %.5962 = or i32 2139095040, %.5947
  %phi_cast_R19_bitcast = bitcast i32 %.5962 to float
  %phi_cast_R2154_bitcast = bitcast i32 %iadd3_n1.173 to float
  br label %BB_2f40_7590

BB_2f40_74e0:                                     ; preds = %BB_2f40_72d0
  %.5973 = zext i32 %iadd3_n1.173 to i64
  %.5976 = shl i64 %.5973, 23
  %.5977 = and i64 %.5976, 4294967295
  %.5978 = add i64 %.5977, %.5820
  %.5979 = trunc i64 %.5978 to i32
  %phi_cast_R21_bitcast = bitcast i32 %.5979 to float
  %phi_cast_R2154_bitcast.1 = bitcast i32 %iadd3_n1.173 to float
  br label %BB_2f40_7590

BB_2f40_7590:                                     ; preds = %BB_2f40_74e0, %BB_2f40_74b0, %BB_2f40_7350, %BB_2f40_7340, %BB_2f40_7310, %BB_2f40_7580, %BB_2f40_7560, %BB_2f40_7540, %BB_2f40_7510
  %phi.277 = phi float [ %phi_cast_R16_bitcast, %BB_2f40_7350 ], [ %phi_cast_R19_bitcast, %BB_2f40_74b0 ], [ %phi_cast_R21_bitcast, %BB_2f40_74e0 ], [ %ffma.302, %BB_2f40_7310 ], [ %phi_cast_R15_bitcast, %BB_2f40_7340 ], [ %phi_cast_R6_bitcast, %BB_2f40_7510 ], [ %phi_cast_R7_bitcast, %BB_2f40_7540 ], [ %mufu_rsq.16, %BB_2f40_7560 ], [ %fadd.32, %BB_2f40_7580 ]
  %phi.278 = phi float [ %phi_cast_R2158_bitcast, %BB_2f40_7350 ], [ %phi_cast_R2154_bitcast, %BB_2f40_74b0 ], [ %phi_cast_R2154_bitcast.1, %BB_2f40_74e0 ], [ %phi_cast_R2154_bitcast.2, %BB_2f40_7310 ], [ %phi_cast_R2154_bitcast.2, %BB_2f40_7340 ], [ %phi.267, %BB_2f40_7510 ], [ %phi.267, %BB_2f40_7540 ], [ %phi.267, %BB_2f40_7560 ], [ %phi.267, %BB_2f40_7580 ]
  br label %BB_2f60

BB_2f60:                                          ; preds = %BB_2f40_7590, %BB_2f10
  %phi.279 = phi float [ %phi.277, %BB_2f40_7590 ], [ %ffma.293, %BB_2f10 ]
  %phi.280 = phi float [ %phi.278, %BB_2f40_7590 ], [ %phi.267, %BB_2f10 ]
  br label %BB_2f80

BB_2f80:                                          ; preds = %BB_2f60, %BB_2e20
  %phi.281 = phi float [ %phi.279, %BB_2f60 ], [ %phi.266, %BB_2e20 ]
  %phi.282 = phi float [ %phi.280, %BB_2f60 ], [ %phi.267, %BB_2e20 ]
  %phi.283 = phi i32 [ %.75, %BB_2f60 ], [ %phi.268, %BB_2e20 ]
  %phi.284 = phi float [ %phi.279, %BB_2f60 ], [ %phi.269, %BB_2e20 ]
  br label %BB_2fb0

BB_2fb0:                                          ; preds = %BB_2f80
  %shfl_activemask.48 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.48 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.48, float %phi.284, i32 16, i32 31)
  br label %BB_2fc0

BB_2fc0:                                          ; preds = %BB_2fb0
  %isetrp_cmp1.228 = icmp uge i32 %tid_x, 17
  %isetrp_cmp1.229 = icmp ne i32 %tid_x, 17
  br label %BB_2ff0

BB_2ff0:                                          ; preds = %BB_2fc0
  %280 = zext i1 %isetrp_cmp1.228 to i32
  %281 = icmp ne i32 %280, 0
  br i1 %281, label %BB_80002ff0, label %BB_3010

BB_80002ff0:                                      ; preds = %BB_2ff0
  %lds_addr_memaddr_offset_add.62 = add i32 %.88, 2112
  %.5987 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.62
  %lds.65 = load volatile float, ptr addrspace(3) %.5987, align 4
  %ffma.303 = call float @llvm.fma.f32(float %shfl_idx.48, float %lds.65, float %phi.270)
  br label %BB_3010

BB_3010:                                          ; preds = %BB_80002ff0, %BB_2ff0
  %phi.285 = phi float [ %ffma.303, %BB_80002ff0 ], [ %phi.270, %BB_2ff0 ]
  %warp_reconv_mask.16 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.16)
  br i1 %isetrp_cmp1.229, label %BB_3170, label %BB_3020

BB_3020:                                          ; preds = %BB_3010
  %ffma_addend_fneg.17 = fneg float %phi.285
  %ffma.304 = call float @llvm.fma.f32(float %phi.281, float %phi, float %ffma_addend_fneg.17)
  %lds_addr_memaddr_offset_add.63 = add i32 %.75, 2312
  %.5997 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.63
  %lds.66 = load volatile float, ptr addrspace(3) %.5997, align 4
  %mufu_rcp.34 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.66)
  %fchk_num_bits.17 = bitcast float %ffma.304 to i32
  %fchk_den_bits.17 = bitcast float %lds.66 to i32
  %fchk_aden.17 = and i32 %fchk_den_bits.17, 2147483647
  %fchk_anum.17 = and i32 %fchk_num_bits.17, 2147483647
  %fchk_den_subz.17 = icmp ult i32 %fchk_aden.17, 8388608
  %fchk_den_infnan.17 = icmp uge i32 %fchk_aden.17, 2139095040
  %fchk_num_infnan.17 = icmp uge i32 %fchk_anum.17, 2139095040
  %fchk_den_bad.17 = or i1 %fchk_den_subz.17, %fchk_den_infnan.17
  %fchk_px.17 = or i1 %fchk_den_bad.17, %fchk_num_infnan.17
  %ffma_lhs_fneg.34 = fneg float %lds.66
  %ffma.305 = call float @llvm.fma.f32(float %ffma_lhs_fneg.34, float %mufu_rcp.34, float 1.000000e+00)
  %ffma.306 = call float @llvm.fma.f32(float %mufu_rcp.34, float %ffma.305, float %mufu_rcp.34)
  %ffma.307 = call float @llvm.fma.f32(float %ffma.304, float %ffma.306, float 0.000000e+00)
  %ffma.308 = call float @llvm.fma.f32(float %ffma_lhs_fneg.34, float %ffma.307, float %ffma.304)
  %ffma.309 = call float @llvm.fma.f32(float %ffma.306, float %ffma.308, float %ffma.307)
  br label %BB_3100

BB_3100:                                          ; preds = %BB_3020
  %cond_not.145 = xor i1 %fchk_px.17, true
  br i1 %cond_not.145, label %BB_3150, label %BB_3130_6f40

BB_3130_6f40:                                     ; preds = %BB_3100
  %.6001 = zext i32 %fchk_den_bits.17 to i64
  %.6002 = shl i64 %.6001, 32
  %.6003 = lshr i64 %.6002, 23
  %shf_hi.90 = lshr i64 %.6003, 32
  %shf_result.108 = trunc i64 %shf_hi.90 to i32
  %.6005 = zext i32 %fchk_num_bits.17 to i64
  %.6006 = shl i64 %.6005, 32
  %.6007 = lshr i64 %.6006, 23
  %shf_hi.91 = lshr i64 %.6007, 32
  %shf_result.109 = trunc i64 %shf_hi.91 to i32
  %.6011 = and i32 %shf_result.108, 255
  %.6019 = and i32 %shf_result.109, 255
  %iadd3_n1.177 = add i32 %.6011, -1
  %iadd3_n1.178 = add i32 %.6019, -1
  %isetrp_cmp1.230 = icmp ugt i32 %iadd3_n1.177, 253
  %isetrp_cmp1.231 = icmp ugt i32 %iadd3_n1.178, 253
  %isetrp_cmp2.231 = or i1 %isetrp_cmp1.231, %isetrp_cmp1.230
  br label %BB_3130_6fd0

BB_3130_6fd0:                                     ; preds = %BB_3130_6f40
  %cond_not.146 = xor i1 %isetrp_cmp2.231, true
  br i1 %cond_not.146, label %BB_3130_80006fd0, label %BB_3130_6ff0

BB_3130_6ff0:                                     ; preds = %BB_3130_6fd0
  %fsetrp_lhs_fabs.85 = call float @llvm.nvvm.fabs.f(float %ffma.304)
  %fsetrp_cmp1.102 = fcmp ugt float %fsetrp_lhs_fabs.85, 0x7FF0000000000000
  %fsetrp_lhs_fabs.86 = call float @llvm.nvvm.fabs.f(float %lds.66)
  %fsetrp_cmp1.103 = fcmp ugt float %fsetrp_lhs_fabs.86, 0x7FF0000000000000
  %lop3_a_cast_zext.68 = zext i1 %fsetrp_cmp1.102 to i32
  %lop3_b_cast_zext.68 = zext i1 %fsetrp_cmp1.103 to i32
  %plop3_a_bit.68 = and i32 %lop3_a_cast_zext.68, 1
  %plop3_b_bit.68 = and i32 %lop3_b_cast_zext.68, 1
  %.6026 = xor i32 %plop3_a_bit.68, 1
  %.6027 = xor i32 %plop3_b_bit.68, 1
  %.6029 = and i32 %.6026, %plop3_b_bit.68
  %.6031 = and i32 %plop3_a_bit.68, %.6027
  %.6033 = or i32 %.6029, %.6031
  %.6034 = and i32 %plop3_a_bit.68, %plop3_b_bit.68
  %.6036 = or i32 %.6033, %.6034
  %lop3_pred_cmp.119 = icmp ne i32 %.6036, 0
  br label %BB_3130_7020

BB_3130_7020:                                     ; preds = %BB_3130_6ff0
  %282 = zext i1 %lop3_pred_cmp.119 to i32
  %283 = icmp ne i32 %282, 0
  br i1 %283, label %BB_3130_7580, label %BB_3130_7030

BB_3130_7030:                                     ; preds = %BB_3130_7020
  %.6039 = xor i32 %fchk_den_bits.17, -1
  %.6041 = xor i32 %fchk_num_bits.17, -1
  %.6042 = and i32 %.6039, 2147483647
  %.6043 = and i32 %.6042, %fchk_num_bits.17
  %.6045 = and i32 %fchk_aden.17, %.6041
  %.6046 = or i32 %.6043, %.6045
  %.6048 = and i32 %fchk_aden.17, %fchk_num_bits.17
  %.6049 = or i32 %.6046, %.6048
  %lop3_pred_cmp.120 = icmp ne i32 %.6049, 0
  br label %BB_3130_7040

BB_3130_7040:                                     ; preds = %BB_3130_7030
  %cond_not.147 = xor i1 %lop3_pred_cmp.120, true
  br i1 %cond_not.147, label %BB_3130_7560, label %BB_3130_7050

BB_3130_7050:                                     ; preds = %BB_3130_7040
  %fsetrp_cmp1.104 = fcmp une float %fsetrp_lhs_fabs.85, 0x7FF0000000000000
  %fsetrp_cmp1.105 = fcmp une float %fsetrp_lhs_fabs.86, 0x7FF0000000000000
  br label %BB_3130_7080

BB_3130_7080:                                     ; preds = %BB_3130_7050
  %cond_not.148 = xor i1 %fsetrp_cmp1.105, true
  br i1 %cond_not.148, label %BB_3130_80007080, label %BB_3130_7090

BB_3130_80007080:                                 ; preds = %BB_3130_7080
  %bra_cond_not.17 = xor i1 %fsetrp_cmp1.104, true
  br i1 %bra_cond_not.17, label %BB_3130_7560, label %BB_3130_7090

BB_3130_7090:                                     ; preds = %BB_3130_80007080, %BB_3130_7080
  %lop3_pred_cmp.121 = icmp ne i32 %fchk_anum.17, 0
  %lop3_a_cast_zext.69 = zext i1 %fsetrp_cmp1.105 to i32
  %lop3_b_cast_zext.69 = zext i1 %lop3_pred_cmp.121 to i32
  %plop3_a_bit.69 = and i32 %lop3_a_cast_zext.69, 1
  %plop3_b_bit.69 = and i32 %lop3_b_cast_zext.69, 1
  %.6063 = xor i32 %plop3_a_bit.69, 1
  %.6064 = xor i32 %plop3_b_bit.69, 1
  %.6066 = and i32 %.6063, %.6064
  %.6068 = and i32 %.6063, %plop3_b_bit.69
  %.6070 = or i32 %.6066, %.6068
  %.6071 = and i32 %plop3_a_bit.69, %.6064
  %.6073 = or i32 %.6070, %.6071
  %lop3_pred_cmp.122 = icmp ne i32 %.6073, 0
  br label %BB_3130_70b0

BB_3130_70b0:                                     ; preds = %BB_3130_7090
  %284 = zext i1 %lop3_pred_cmp.122 to i32
  %285 = icmp ne i32 %284, 0
  br i1 %285, label %BB_3130_7540, label %BB_3130_70c0

BB_3130_70c0:                                     ; preds = %BB_3130_70b0
  %lop3_pred_cmp.123 = icmp ne i32 %fchk_aden.17, 0
  %lop3_a_cast_zext.70 = zext i1 %fsetrp_cmp1.104 to i32
  %lop3_b_cast_zext.70 = zext i1 %lop3_pred_cmp.123 to i32
  %plop3_a_bit.70 = and i32 %lop3_a_cast_zext.70, 1
  %plop3_b_bit.70 = and i32 %lop3_b_cast_zext.70, 1
  %.6084 = xor i32 %plop3_a_bit.70, 1
  %.6085 = xor i32 %plop3_b_bit.70, 1
  %.6087 = and i32 %.6084, %.6085
  %.6089 = and i32 %.6084, %plop3_b_bit.70
  %.6091 = or i32 %.6087, %.6089
  %.6092 = and i32 %plop3_a_bit.70, %.6085
  %.6094 = or i32 %.6091, %.6092
  %lop3_pred_cmp.124 = icmp ne i32 %.6094, 0
  br label %BB_3130_70e0

BB_3130_70e0:                                     ; preds = %BB_3130_70c0
  %286 = zext i1 %lop3_pred_cmp.124 to i32
  %287 = icmp ne i32 %286, 0
  br i1 %287, label %BB_3130_7510, label %BB_3130_70f0

BB_3130_70f0:                                     ; preds = %BB_3130_70e0
  %isetrp_cmp1.232 = icmp sge i32 %iadd3_n1.178, 0
  %isetrp_cmp1.233 = icmp sge i32 %iadd3_n1.177, 0
  br label %BB_3130_7130

BB_3130_7130:                                     ; preds = %BB_3130_70f0
  %288 = zext i1 %isetrp_cmp1.232 to i32
  %289 = icmp ne i32 %288, 0
  br i1 %289, label %BB_3130_80007130, label %BB_3130_7140

BB_3130_80007130:                                 ; preds = %BB_3130_7130
  br label %BB_3130_7140

BB_3130_7140:                                     ; preds = %BB_3130_80007130, %BB_3130_7130
  %phi.286 = phi i32 [ 0, %BB_3130_80007130 ], [ %iadd3_n1.177, %BB_3130_7130 ]
  %cond_not.149 = xor i1 %isetrp_cmp1.232, true
  br i1 %cond_not.149, label %BB_3130_80007140, label %BB_3130_7160

BB_3130_80007140:                                 ; preds = %BB_3130_7140
  %ffma.310 = call float @llvm.fma.f32(float %ffma.304, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R24_bitcast = bitcast float %ffma.310 to i32
  br label %BB_3130_7160

BB_3130_7160:                                     ; preds = %BB_3130_80007140, %BB_3130_7140
  %phi.287 = phi i32 [ %phi_cast_R24_bitcast, %BB_3130_80007140 ], [ %fchk_num_bits.17, %BB_3130_7140 ]
  %phi.288 = phi i32 [ -64, %BB_3130_80007140 ], [ %phi.286, %BB_3130_7140 ]
  %cond_not.150 = xor i1 %isetrp_cmp1.233, true
  br i1 %cond_not.150, label %BB_3130_80007160, label %BB_3130_7180

BB_3130_80007160:                                 ; preds = %BB_3130_7160
  %ffma.311 = call float @llvm.fma.f32(float %lds.66, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.35 = add i32 %phi.288, 64
  %phi_cast_R631_bitcast = bitcast float %ffma.311 to i32
  br label %BB_3130_7180

BB_3130_7510:                                     ; preds = %BB_3130_70e0
  %.6107 = and i32 %.6039, -2147483648
  %.6108 = and i32 %.6107, %fchk_num_bits.17
  %.6109 = and i32 %fchk_den_bits.17, -2147483648
  %.6110 = and i32 %.6109, %.6041
  %.6111 = or i32 %.6108, %.6110
  %.6112 = xor i32 %.6111, -1
  %.6115 = and i32 %.6112, 2139095040
  %.6122 = or i32 %.6115, %.6111
  %phi_cast_R29_bitcast = bitcast i32 %.6122 to float
  br label %BB_3130_7590

BB_3130_7540:                                     ; preds = %BB_3130_70b0
  %.6136 = and i32 %.6039, -2147483648
  %.6137 = and i32 %.6136, %fchk_num_bits.17
  %.6138 = and i32 %fchk_den_bits.17, -2147483648
  %.6139 = and i32 %.6138, %.6041
  %.6140 = or i32 %.6137, %.6139
  %phi_cast_R31_bitcast = bitcast i32 %.6140 to float
  br label %BB_3130_7590

BB_3130_7560:                                     ; preds = %BB_3130_80007080, %BB_3130_7040
  %mufu_rsq.17 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_3130_7590

BB_3130_7580:                                     ; preds = %BB_3130_7020
  %fadd.34 = fadd float %ffma.304, %lds.66
  br label %BB_3130_7590

BB_3130_80006fd0:                                 ; preds = %BB_3130_6fd0
  br label %BB_3130_7180

BB_3130_7180:                                     ; preds = %BB_3130_80006fd0, %BB_3130_80007160, %BB_3130_7160
  %phi.289 = phi i32 [ %fchk_den_bits.17, %BB_3130_80006fd0 ], [ %phi_cast_R631_bitcast, %BB_3130_80007160 ], [ %fchk_den_bits.17, %BB_3130_7160 ]
  %phi.290 = phi i32 [ %fchk_num_bits.17, %BB_3130_80006fd0 ], [ %phi.287, %BB_3130_80007160 ], [ %phi.287, %BB_3130_7160 ]
  %phi.291 = phi i32 [ 0, %BB_3130_80006fd0 ], [ %viadd.35, %BB_3130_80007160 ], [ %phi.288, %BB_3130_7160 ]
  %.6145 = zext i32 %.6011 to i64
  %.6148 = shl i64 %.6145, 23
  %.6149 = and i64 %.6148, 4294967295
  %.6150 = add i64 %.6149, 3229614080
  %.6151 = trunc i64 %.6150 to i32
  %iadd3_n1.180 = add i32 %.6019, -127
  %iadd3_o1_not.34 = xor i32 %.6151, -1
  %iadd3_o1_neg.34 = add i32 %iadd3_o1_not.34, 1
  %iadd3_n1.181 = add i32 %iadd3_o1_neg.34, %phi.289
  %imad_tmp.69 = mul i32 %iadd3_n1.180, -8388608
  %imad.80 = add i32 %imad_tmp.69, %phi.290
  %mufu_src_bitcast.17 = bitcast i32 %iadd3_n1.181 to float
  %mufu_rcp.35 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.17)
  %fadd_lhs_fneg.17 = fneg float %mufu_src_bitcast.17
  %fadd.35 = fadd float %fadd_lhs_fneg.17, 0.000000e+00
  %iadd3_o3_not.17 = xor i32 %.6011, -1
  %iadd3_o3_neg.17 = add i32 %iadd3_o3_not.17, 1
  %iadd3_n2.182 = add i32 %.6019, %iadd3_o3_neg.17
  %iadd3_n1.183 = add i32 %iadd3_n2.182, %phi.291
  %ffma.312 = call float @llvm.fma.f32(float %mufu_rcp.35, float %fadd.35, float 1.000000e+00)
  %ffma.313 = call float @llvm.fma.f32(float %mufu_rcp.35, float %ffma.312, float %mufu_rcp.35)
  %ffma_lhs_bitcast.17 = bitcast i32 %imad.80 to float
  %ffma.314 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.17, float %ffma.313, float 0.000000e+00)
  %ffma.315 = call float @llvm.fma.f32(float %fadd.35, float %ffma.314, float %ffma_lhs_bitcast.17)
  %ffma.316 = call float @llvm.fma.f32(float %ffma.313, float %ffma.315, float %ffma.314)
  %ffma.317 = call float @llvm.fma.f32(float %fadd.35, float %ffma.316, float %ffma_lhs_bitcast.17)
  %ffma.318 = call float @llvm.fma.f32(float %ffma.313, float %ffma.317, float %ffma.316)
  %shf_hi_bitcast.53 = bitcast float %ffma.318 to i32
  %.6153 = zext i32 %shf_hi_bitcast.53 to i64
  %.6154 = shl i64 %.6153, 32
  %.6155 = lshr i64 %.6154, 23
  %shf_hi.92 = lshr i64 %.6155, 32
  %shf_result.110 = trunc i64 %shf_hi.92 to i32
  %.6159 = and i32 %shf_result.110, 255
  %imad.81 = add i32 %.6159, %iadd3_n1.183
  %iadd3_n1.184 = add i32 %imad.81, -1
  %isetrp_cmp1.234 = icmp uge i32 %iadd3_n1.184, 254
  br label %BB_3130_72d0

BB_3130_72d0:                                     ; preds = %BB_3130_7180
  %cond_not.151 = xor i1 %isetrp_cmp1.234, true
  br i1 %cond_not.151, label %BB_3130_74e0, label %BB_3130_72e0

BB_3130_72e0:                                     ; preds = %BB_3130_72d0
  %isetrp_cmp1.235 = icmp sgt i32 %imad.81, 254
  br label %BB_3130_72f0

BB_3130_72f0:                                     ; preds = %BB_3130_72e0
  %290 = zext i1 %isetrp_cmp1.235 to i32
  %291 = icmp ne i32 %290, 0
  br i1 %291, label %BB_3130_74b0, label %BB_3130_7300

BB_3130_7300:                                     ; preds = %BB_3130_72f0
  %isetrp_cmp1.236 = icmp sge i32 %imad.81, 1
  br label %BB_3130_7310

BB_3130_7310:                                     ; preds = %BB_3130_7300
  %phi_cast_R2165_bitcast.2 = bitcast i32 %iadd3_n1.183 to float
  br i1 %isetrp_cmp1.236, label %BB_3130_7590, label %BB_3130_7320

BB_3130_7320:                                     ; preds = %BB_3130_7310
  %isetrp_cmp1.237 = icmp sge i32 %imad.81, -24
  %.6173 = and i32 %shf_hi_bitcast.53, -2147483648
  br label %BB_3130_7340

BB_3130_7340:                                     ; preds = %BB_3130_7320
  %cond_not.152 = xor i1 %isetrp_cmp1.237, true
  %phi_cast_R39_bitcast = bitcast i32 %.6173 to float
  br i1 %cond_not.152, label %BB_3130_7590, label %BB_3130_7350

BB_3130_7350:                                     ; preds = %BB_3130_7340
  %ffma_rz.17 = call float @llvm.nvvm.fma.rz.f(float %ffma.313, float %ffma.317, float %ffma.316)
  %iadd3_n1.185 = add i32 %imad.81, 32
  %lop3_a_bitcast.142 = bitcast float %ffma_rz.17 to i32
  %.6183 = and i32 %lop3_a_bitcast.142, 8388607
  %ffma_rp.17 = call float @llvm.nvvm.fma.rp.f(float %ffma.313, float %ffma.317, float %ffma.316)
  %ffma_rm.17 = call float @llvm.nvvm.fma.rm.f(float %ffma.313, float %ffma.317, float %ffma.316)
  %isetrp_cmp1.239 = icmp ne i32 %imad.81, 0
  %.6198 = or i32 8388608, %.6183
  %iadd3_o1_not.35 = xor i32 %imad.81, -1
  %iadd3_o1_neg.35 = add i32 %iadd3_o1_not.35, 1
  %.6208 = zext i32 %.6198 to i64
  %shf_shift_64.111 = zext i32 %iadd3_n1.185 to i64
  %.6211 = shl i64 %.6208, %shf_shift_64.111
  %shf_result.111 = trunc i64 %.6211 to i32
  %fsetrp_cmp1.107 = fcmp une float %ffma_rp.17, %ffma_rm.17
  %isetrp_cmp1.240 = icmp ne i32 %shf_result.111, 0
  %isetrp_cmp2.240 = and i1 %isetrp_cmp1.240, %isetrp_cmp1.239
  %.6214 = shl i64 %.6208, 32
  %shf_shift_64.112 = zext i32 %iadd3_o1_neg.35 to i64
  %.6215 = lshr i64 %.6214, %shf_shift_64.112
  %shf_hi.93 = lshr i64 %.6215, 32
  %shf_result.112 = trunc i64 %shf_hi.93 to i32
  %lop3_a_cast_zext.71 = zext i1 %fsetrp_cmp1.107 to i32
  %lop3_b_cast_zext.71 = zext i1 %isetrp_cmp2.240 to i32
  %plop3_a_bit.71 = and i32 %lop3_a_cast_zext.71, 1
  %plop3_b_bit.71 = and i32 %lop3_b_cast_zext.71, 1
  %.6216 = xor i32 %plop3_a_bit.71, 1
  %.6217 = xor i32 %plop3_b_bit.71, 1
  %.6219 = and i32 %.6216, %plop3_b_bit.71
  %.6221 = and i32 %plop3_a_bit.71, %.6217
  %.6223 = or i32 %.6219, %.6221
  %.6224 = and i32 %plop3_a_bit.71, %plop3_b_bit.71
  %.6226 = or i32 %.6223, %.6224
  %lop3_pred_cmp.125 = icmp ne i32 %.6226, 0
  %.6228 = zext i32 %shf_result.112 to i64
  %.6229 = shl i64 %.6228, 32
  %.6230 = lshr i64 %.6229, 1
  %shf_hi.94 = lshr i64 %.6230, 32
  %shf_result.113 = trunc i64 %shf_hi.94 to i32
  %sel_pred_not.17 = xor i1 %lop3_pred_cmp.125, true
  %sel.35 = select i1 %sel_pred_not.17, i32 0, i32 1
  %.6231 = xor i32 %sel.35, -1
  %.6233 = xor i32 %shf_result.113, -1
  %.6234 = and i32 %.6231, 1
  %.6235 = and i32 %.6234, %shf_result.113
  %.6243 = and i32 %sel.35, %.6233
  %.6244 = or i32 %.6235, %.6243
  %.6246 = and i32 %sel.35, %shf_result.113
  %.6247 = or i32 %.6244, %.6246
  %.6251 = and i32 %.6247, %shf_result.112
  %imad.82 = add i32 %shf_result.113, %.6251
  %.6256 = xor i32 %imad.82, -1
  %.6257 = xor i32 %.6173, -1
  %.6259 = and i32 %.6256, %.6173
  %.6264 = and i32 %imad.82, %.6257
  %.6266 = or i32 %.6259, %.6264
  %.6270 = and i32 %imad.82, %.6173
  %.6272 = or i32 %.6266, %.6270
  %phi_cast_R40_bitcast = bitcast i32 %.6272 to float
  %phi_cast_R2167_bitcast = bitcast i32 %.6198 to float
  br label %BB_3130_7590

BB_3130_74b0:                                     ; preds = %BB_3130_72f0
  %.6280 = and i32 %shf_hi_bitcast.53, -2147483648
  %.6295 = or i32 2139095040, %.6280
  %phi_cast_R44_bitcast = bitcast i32 %.6295 to float
  %phi_cast_R2165_bitcast = bitcast i32 %iadd3_n1.183 to float
  br label %BB_3130_7590

BB_3130_74e0:                                     ; preds = %BB_3130_72d0
  %.6306 = zext i32 %iadd3_n1.183 to i64
  %.6309 = shl i64 %.6306, 23
  %.6310 = and i64 %.6309, 4294967295
  %.6311 = add i64 %.6310, %.6153
  %.6312 = trunc i64 %.6311 to i32
  %phi_cast_R45_bitcast = bitcast i32 %.6312 to float
  %phi_cast_R2165_bitcast.1 = bitcast i32 %iadd3_n1.183 to float
  br label %BB_3130_7590

BB_3130_7590:                                     ; preds = %BB_3130_74e0, %BB_3130_74b0, %BB_3130_7350, %BB_3130_7340, %BB_3130_7310, %BB_3130_7580, %BB_3130_7560, %BB_3130_7540, %BB_3130_7510
  %phi.292 = phi float [ %phi_cast_R40_bitcast, %BB_3130_7350 ], [ %phi_cast_R44_bitcast, %BB_3130_74b0 ], [ %phi_cast_R45_bitcast, %BB_3130_74e0 ], [ %ffma.318, %BB_3130_7310 ], [ %phi_cast_R39_bitcast, %BB_3130_7340 ], [ %phi_cast_R29_bitcast, %BB_3130_7510 ], [ %phi_cast_R31_bitcast, %BB_3130_7540 ], [ %mufu_rsq.17, %BB_3130_7560 ], [ %fadd.34, %BB_3130_7580 ]
  %phi.293 = phi float [ %phi_cast_R2167_bitcast, %BB_3130_7350 ], [ %phi_cast_R2165_bitcast, %BB_3130_74b0 ], [ %phi_cast_R2165_bitcast.1, %BB_3130_74e0 ], [ %phi_cast_R2165_bitcast.2, %BB_3130_7310 ], [ %phi_cast_R2165_bitcast.2, %BB_3130_7340 ], [ %phi.282, %BB_3130_7510 ], [ %phi.282, %BB_3130_7540 ], [ %phi.282, %BB_3130_7560 ], [ %phi.282, %BB_3130_7580 ]
  br label %BB_3150

BB_3150:                                          ; preds = %BB_3130_7590, %BB_3100
  %phi.294 = phi float [ %phi.292, %BB_3130_7590 ], [ %ffma.309, %BB_3100 ]
  %phi.295 = phi float [ %phi.293, %BB_3130_7590 ], [ %phi.282, %BB_3100 ]
  br label %BB_3170

BB_3170:                                          ; preds = %BB_3150, %BB_3010
  %phi.296 = phi float [ %phi.294, %BB_3150 ], [ %phi.281, %BB_3010 ]
  %phi.297 = phi float [ %phi.295, %BB_3150 ], [ %phi.282, %BB_3010 ]
  %phi.298 = phi i32 [ %.75, %BB_3150 ], [ %phi.283, %BB_3010 ]
  %phi.299 = phi float [ %phi.294, %BB_3150 ], [ %phi.284, %BB_3010 ]
  br label %BB_31a0

BB_31a0:                                          ; preds = %BB_3170
  %shfl_activemask.49 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.49 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.49, float %phi.299, i32 17, i32 31)
  br label %BB_31b0

BB_31b0:                                          ; preds = %BB_31a0
  %isetrp_cmp1.241 = icmp uge i32 %tid_x, 18
  %isetrp_cmp1.242 = icmp ne i32 %tid_x, 18
  br label %BB_31e0

BB_31e0:                                          ; preds = %BB_31b0
  %292 = zext i1 %isetrp_cmp1.241 to i32
  %293 = icmp ne i32 %292, 0
  br i1 %293, label %BB_800031e0, label %BB_3200

BB_800031e0:                                      ; preds = %BB_31e0
  %lds_addr_memaddr_offset_add.64 = add i32 %.88, 2244
  %.6320 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.64
  %lds.67 = load volatile float, ptr addrspace(3) %.6320, align 4
  %ffma.319 = call float @llvm.fma.f32(float %shfl_idx.49, float %lds.67, float %phi.285)
  br label %BB_3200

BB_3200:                                          ; preds = %BB_800031e0, %BB_31e0
  %phi.300 = phi float [ %ffma.319, %BB_800031e0 ], [ %phi.285, %BB_31e0 ]
  %warp_reconv_mask.17 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.17)
  br i1 %isetrp_cmp1.242, label %BB_3360, label %BB_3210

BB_3210:                                          ; preds = %BB_3200
  %ffma_addend_fneg.18 = fneg float %phi.300
  %ffma.320 = call float @llvm.fma.f32(float %phi.296, float %phi, float %ffma_addend_fneg.18)
  %lds_addr_memaddr_offset_add.65 = add i32 %.75, 2448
  %.6330 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.65
  %lds.68 = load volatile float, ptr addrspace(3) %.6330, align 4
  %mufu_rcp.36 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.68)
  %fchk_num_bits.18 = bitcast float %ffma.320 to i32
  %fchk_den_bits.18 = bitcast float %lds.68 to i32
  %fchk_aden.18 = and i32 %fchk_den_bits.18, 2147483647
  %fchk_anum.18 = and i32 %fchk_num_bits.18, 2147483647
  %fchk_den_subz.18 = icmp ult i32 %fchk_aden.18, 8388608
  %fchk_den_infnan.18 = icmp uge i32 %fchk_aden.18, 2139095040
  %fchk_num_infnan.18 = icmp uge i32 %fchk_anum.18, 2139095040
  %fchk_den_bad.18 = or i1 %fchk_den_subz.18, %fchk_den_infnan.18
  %fchk_px.18 = or i1 %fchk_den_bad.18, %fchk_num_infnan.18
  %ffma_lhs_fneg.36 = fneg float %lds.68
  %ffma.321 = call float @llvm.fma.f32(float %ffma_lhs_fneg.36, float %mufu_rcp.36, float 1.000000e+00)
  %ffma.322 = call float @llvm.fma.f32(float %mufu_rcp.36, float %ffma.321, float %mufu_rcp.36)
  %ffma.323 = call float @llvm.fma.f32(float %ffma.320, float %ffma.322, float 0.000000e+00)
  %ffma.324 = call float @llvm.fma.f32(float %ffma_lhs_fneg.36, float %ffma.323, float %ffma.320)
  %ffma.325 = call float @llvm.fma.f32(float %ffma.322, float %ffma.324, float %ffma.323)
  br label %BB_32f0

BB_32f0:                                          ; preds = %BB_3210
  %cond_not.153 = xor i1 %fchk_px.18, true
  br i1 %cond_not.153, label %BB_3340, label %BB_3320_6f40

BB_3320_6f40:                                     ; preds = %BB_32f0
  %.6334 = zext i32 %fchk_den_bits.18 to i64
  %.6335 = shl i64 %.6334, 32
  %.6336 = lshr i64 %.6335, 23
  %shf_hi.95 = lshr i64 %.6336, 32
  %shf_result.114 = trunc i64 %shf_hi.95 to i32
  %.6338 = zext i32 %fchk_num_bits.18 to i64
  %.6339 = shl i64 %.6338, 32
  %.6340 = lshr i64 %.6339, 23
  %shf_hi.96 = lshr i64 %.6340, 32
  %shf_result.115 = trunc i64 %shf_hi.96 to i32
  %.6344 = and i32 %shf_result.114, 255
  %.6352 = and i32 %shf_result.115, 255
  %iadd3_n1.187 = add i32 %.6344, -1
  %iadd3_n1.188 = add i32 %.6352, -1
  %isetrp_cmp1.243 = icmp ugt i32 %iadd3_n1.187, 253
  %isetrp_cmp1.244 = icmp ugt i32 %iadd3_n1.188, 253
  %isetrp_cmp2.244 = or i1 %isetrp_cmp1.244, %isetrp_cmp1.243
  br label %BB_3320_6fd0

BB_3320_6fd0:                                     ; preds = %BB_3320_6f40
  %cond_not.154 = xor i1 %isetrp_cmp2.244, true
  br i1 %cond_not.154, label %BB_3320_80006fd0, label %BB_3320_6ff0

BB_3320_6ff0:                                     ; preds = %BB_3320_6fd0
  %fsetrp_lhs_fabs.90 = call float @llvm.nvvm.fabs.f(float %ffma.320)
  %fsetrp_cmp1.108 = fcmp ugt float %fsetrp_lhs_fabs.90, 0x7FF0000000000000
  %fsetrp_lhs_fabs.91 = call float @llvm.nvvm.fabs.f(float %lds.68)
  %fsetrp_cmp1.109 = fcmp ugt float %fsetrp_lhs_fabs.91, 0x7FF0000000000000
  %lop3_a_cast_zext.72 = zext i1 %fsetrp_cmp1.108 to i32
  %lop3_b_cast_zext.72 = zext i1 %fsetrp_cmp1.109 to i32
  %plop3_a_bit.72 = and i32 %lop3_a_cast_zext.72, 1
  %plop3_b_bit.72 = and i32 %lop3_b_cast_zext.72, 1
  %.6359 = xor i32 %plop3_a_bit.72, 1
  %.6360 = xor i32 %plop3_b_bit.72, 1
  %.6362 = and i32 %.6359, %plop3_b_bit.72
  %.6364 = and i32 %plop3_a_bit.72, %.6360
  %.6366 = or i32 %.6362, %.6364
  %.6367 = and i32 %plop3_a_bit.72, %plop3_b_bit.72
  %.6369 = or i32 %.6366, %.6367
  %lop3_pred_cmp.126 = icmp ne i32 %.6369, 0
  br label %BB_3320_7020

BB_3320_7020:                                     ; preds = %BB_3320_6ff0
  %294 = zext i1 %lop3_pred_cmp.126 to i32
  %295 = icmp ne i32 %294, 0
  br i1 %295, label %BB_3320_7580, label %BB_3320_7030

BB_3320_7030:                                     ; preds = %BB_3320_7020
  %.6372 = xor i32 %fchk_den_bits.18, -1
  %.6374 = xor i32 %fchk_num_bits.18, -1
  %.6375 = and i32 %.6372, 2147483647
  %.6376 = and i32 %.6375, %fchk_num_bits.18
  %.6378 = and i32 %fchk_aden.18, %.6374
  %.6379 = or i32 %.6376, %.6378
  %.6381 = and i32 %fchk_aden.18, %fchk_num_bits.18
  %.6382 = or i32 %.6379, %.6381
  %lop3_pred_cmp.127 = icmp ne i32 %.6382, 0
  br label %BB_3320_7040

BB_3320_7040:                                     ; preds = %BB_3320_7030
  %cond_not.155 = xor i1 %lop3_pred_cmp.127, true
  br i1 %cond_not.155, label %BB_3320_7560, label %BB_3320_7050

BB_3320_7050:                                     ; preds = %BB_3320_7040
  %fsetrp_cmp1.110 = fcmp une float %fsetrp_lhs_fabs.90, 0x7FF0000000000000
  %fsetrp_cmp1.111 = fcmp une float %fsetrp_lhs_fabs.91, 0x7FF0000000000000
  br label %BB_3320_7080

BB_3320_7080:                                     ; preds = %BB_3320_7050
  %cond_not.156 = xor i1 %fsetrp_cmp1.111, true
  br i1 %cond_not.156, label %BB_3320_80007080, label %BB_3320_7090

BB_3320_80007080:                                 ; preds = %BB_3320_7080
  %bra_cond_not.18 = xor i1 %fsetrp_cmp1.110, true
  br i1 %bra_cond_not.18, label %BB_3320_7560, label %BB_3320_7090

BB_3320_7090:                                     ; preds = %BB_3320_80007080, %BB_3320_7080
  %lop3_pred_cmp.128 = icmp ne i32 %fchk_anum.18, 0
  %lop3_a_cast_zext.73 = zext i1 %fsetrp_cmp1.111 to i32
  %lop3_b_cast_zext.73 = zext i1 %lop3_pred_cmp.128 to i32
  %plop3_a_bit.73 = and i32 %lop3_a_cast_zext.73, 1
  %plop3_b_bit.73 = and i32 %lop3_b_cast_zext.73, 1
  %.6396 = xor i32 %plop3_a_bit.73, 1
  %.6397 = xor i32 %plop3_b_bit.73, 1
  %.6399 = and i32 %.6396, %.6397
  %.6401 = and i32 %.6396, %plop3_b_bit.73
  %.6403 = or i32 %.6399, %.6401
  %.6404 = and i32 %plop3_a_bit.73, %.6397
  %.6406 = or i32 %.6403, %.6404
  %lop3_pred_cmp.129 = icmp ne i32 %.6406, 0
  br label %BB_3320_70b0

BB_3320_70b0:                                     ; preds = %BB_3320_7090
  %296 = zext i1 %lop3_pred_cmp.129 to i32
  %297 = icmp ne i32 %296, 0
  br i1 %297, label %BB_3320_7540, label %BB_3320_70c0

BB_3320_70c0:                                     ; preds = %BB_3320_70b0
  %lop3_pred_cmp.130 = icmp ne i32 %fchk_aden.18, 0
  %lop3_a_cast_zext.74 = zext i1 %fsetrp_cmp1.110 to i32
  %lop3_b_cast_zext.74 = zext i1 %lop3_pred_cmp.130 to i32
  %plop3_a_bit.74 = and i32 %lop3_a_cast_zext.74, 1
  %plop3_b_bit.74 = and i32 %lop3_b_cast_zext.74, 1
  %.6417 = xor i32 %plop3_a_bit.74, 1
  %.6418 = xor i32 %plop3_b_bit.74, 1
  %.6420 = and i32 %.6417, %.6418
  %.6422 = and i32 %.6417, %plop3_b_bit.74
  %.6424 = or i32 %.6420, %.6422
  %.6425 = and i32 %plop3_a_bit.74, %.6418
  %.6427 = or i32 %.6424, %.6425
  %lop3_pred_cmp.131 = icmp ne i32 %.6427, 0
  br label %BB_3320_70e0

BB_3320_70e0:                                     ; preds = %BB_3320_70c0
  %298 = zext i1 %lop3_pred_cmp.131 to i32
  %299 = icmp ne i32 %298, 0
  br i1 %299, label %BB_3320_7510, label %BB_3320_70f0

BB_3320_70f0:                                     ; preds = %BB_3320_70e0
  %isetrp_cmp1.245 = icmp sge i32 %iadd3_n1.188, 0
  %isetrp_cmp1.246 = icmp sge i32 %iadd3_n1.187, 0
  br label %BB_3320_7130

BB_3320_7130:                                     ; preds = %BB_3320_70f0
  %300 = zext i1 %isetrp_cmp1.245 to i32
  %301 = icmp ne i32 %300, 0
  br i1 %301, label %BB_3320_80007130, label %BB_3320_7140

BB_3320_80007130:                                 ; preds = %BB_3320_7130
  br label %BB_3320_7140

BB_3320_7140:                                     ; preds = %BB_3320_80007130, %BB_3320_7130
  %phi.301 = phi i32 [ 0, %BB_3320_80007130 ], [ %iadd3_n1.187, %BB_3320_7130 ]
  %cond_not.157 = xor i1 %isetrp_cmp1.245, true
  br i1 %cond_not.157, label %BB_3320_80007140, label %BB_3320_7160

BB_3320_80007140:                                 ; preds = %BB_3320_7140
  %ffma.326 = call float @llvm.fma.f32(float %ffma.320, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R49_bitcast = bitcast float %ffma.326 to i32
  br label %BB_3320_7160

BB_3320_7160:                                     ; preds = %BB_3320_80007140, %BB_3320_7140
  %phi.302 = phi i32 [ %phi_cast_R49_bitcast, %BB_3320_80007140 ], [ %fchk_num_bits.18, %BB_3320_7140 ]
  %phi.303 = phi i32 [ -64, %BB_3320_80007140 ], [ %phi.301, %BB_3320_7140 ]
  %cond_not.158 = xor i1 %isetrp_cmp1.246, true
  br i1 %cond_not.158, label %BB_3320_80007160, label %BB_3320_7180

BB_3320_80007160:                                 ; preds = %BB_3320_7160
  %ffma.327 = call float @llvm.fma.f32(float %lds.68, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.37 = add i32 %phi.303, 64
  %phi_cast_R648_bitcast = bitcast float %ffma.327 to i32
  br label %BB_3320_7180

BB_3320_7510:                                     ; preds = %BB_3320_70e0
  %.6440 = and i32 %.6372, -2147483648
  %.6441 = and i32 %.6440, %fchk_num_bits.18
  %.6442 = and i32 %fchk_den_bits.18, -2147483648
  %.6443 = and i32 %.6442, %.6374
  %.6444 = or i32 %.6441, %.6443
  %.6445 = xor i32 %.6444, -1
  %.6448 = and i32 %.6445, 2139095040
  %.6455 = or i32 %.6448, %.6444
  %phi_cast_R52_bitcast = bitcast i32 %.6455 to float
  br label %BB_3320_7590

BB_3320_7540:                                     ; preds = %BB_3320_70b0
  %.6469 = and i32 %.6372, -2147483648
  %.6470 = and i32 %.6469, %fchk_num_bits.18
  %.6471 = and i32 %fchk_den_bits.18, -2147483648
  %.6472 = and i32 %.6471, %.6374
  %.6473 = or i32 %.6470, %.6472
  %phi_cast_R55_bitcast = bitcast i32 %.6473 to float
  br label %BB_3320_7590

BB_3320_7560:                                     ; preds = %BB_3320_80007080, %BB_3320_7040
  %mufu_rsq.18 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_3320_7590

BB_3320_7580:                                     ; preds = %BB_3320_7020
  %fadd.36 = fadd float %ffma.320, %lds.68
  br label %BB_3320_7590

BB_3320_80006fd0:                                 ; preds = %BB_3320_6fd0
  br label %BB_3320_7180

BB_3320_7180:                                     ; preds = %BB_3320_80006fd0, %BB_3320_80007160, %BB_3320_7160
  %phi.304 = phi i32 [ %fchk_den_bits.18, %BB_3320_80006fd0 ], [ %phi_cast_R648_bitcast, %BB_3320_80007160 ], [ %fchk_den_bits.18, %BB_3320_7160 ]
  %phi.305 = phi i32 [ %fchk_num_bits.18, %BB_3320_80006fd0 ], [ %phi.302, %BB_3320_80007160 ], [ %phi.302, %BB_3320_7160 ]
  %phi.306 = phi i32 [ 0, %BB_3320_80006fd0 ], [ %viadd.37, %BB_3320_80007160 ], [ %phi.303, %BB_3320_7160 ]
  %.6478 = zext i32 %.6344 to i64
  %.6481 = shl i64 %.6478, 23
  %.6482 = and i64 %.6481, 4294967295
  %.6483 = add i64 %.6482, 3229614080
  %.6484 = trunc i64 %.6483 to i32
  %iadd3_n1.190 = add i32 %.6352, -127
  %iadd3_o1_not.36 = xor i32 %.6484, -1
  %iadd3_o1_neg.36 = add i32 %iadd3_o1_not.36, 1
  %iadd3_n1.191 = add i32 %iadd3_o1_neg.36, %phi.304
  %imad_tmp.72 = mul i32 %iadd3_n1.190, -8388608
  %imad.83 = add i32 %imad_tmp.72, %phi.305
  %mufu_src_bitcast.18 = bitcast i32 %iadd3_n1.191 to float
  %mufu_rcp.37 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.18)
  %fadd_lhs_fneg.18 = fneg float %mufu_src_bitcast.18
  %fadd.37 = fadd float %fadd_lhs_fneg.18, 0.000000e+00
  %iadd3_o3_not.18 = xor i32 %.6344, -1
  %iadd3_o3_neg.18 = add i32 %iadd3_o3_not.18, 1
  %iadd3_n2.192 = add i32 %.6352, %iadd3_o3_neg.18
  %iadd3_n1.193 = add i32 %iadd3_n2.192, %phi.306
  %ffma.328 = call float @llvm.fma.f32(float %mufu_rcp.37, float %fadd.37, float 1.000000e+00)
  %ffma.329 = call float @llvm.fma.f32(float %mufu_rcp.37, float %ffma.328, float %mufu_rcp.37)
  %ffma_lhs_bitcast.18 = bitcast i32 %imad.83 to float
  %ffma.330 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.18, float %ffma.329, float 0.000000e+00)
  %ffma.331 = call float @llvm.fma.f32(float %fadd.37, float %ffma.330, float %ffma_lhs_bitcast.18)
  %ffma.332 = call float @llvm.fma.f32(float %ffma.329, float %ffma.331, float %ffma.330)
  %ffma.333 = call float @llvm.fma.f32(float %fadd.37, float %ffma.332, float %ffma_lhs_bitcast.18)
  %ffma.334 = call float @llvm.fma.f32(float %ffma.329, float %ffma.333, float %ffma.332)
  %shf_hi_bitcast.56 = bitcast float %ffma.334 to i32
  %.6486 = zext i32 %shf_hi_bitcast.56 to i64
  %.6487 = shl i64 %.6486, 32
  %.6488 = lshr i64 %.6487, 23
  %shf_hi.97 = lshr i64 %.6488, 32
  %shf_result.116 = trunc i64 %shf_hi.97 to i32
  %.6492 = and i32 %shf_result.116, 255
  %imad.84 = add i32 %.6492, %iadd3_n1.193
  %iadd3_n1.194 = add i32 %imad.84, -1
  %isetrp_cmp1.247 = icmp uge i32 %iadd3_n1.194, 254
  br label %BB_3320_72d0

BB_3320_72d0:                                     ; preds = %BB_3320_7180
  %cond_not.159 = xor i1 %isetrp_cmp1.247, true
  br i1 %cond_not.159, label %BB_3320_74e0, label %BB_3320_72e0

BB_3320_72e0:                                     ; preds = %BB_3320_72d0
  %isetrp_cmp1.248 = icmp sgt i32 %imad.84, 254
  br label %BB_3320_72f0

BB_3320_72f0:                                     ; preds = %BB_3320_72e0
  %302 = zext i1 %isetrp_cmp1.248 to i32
  %303 = icmp ne i32 %302, 0
  br i1 %303, label %BB_3320_74b0, label %BB_3320_7300

BB_3320_7300:                                     ; preds = %BB_3320_72f0
  %isetrp_cmp1.249 = icmp sge i32 %imad.84, 1
  br label %BB_3320_7310

BB_3320_7310:                                     ; preds = %BB_3320_7300
  %phi_cast_R2175_bitcast.2 = bitcast i32 %iadd3_n1.193 to float
  br i1 %isetrp_cmp1.249, label %BB_3320_7590, label %BB_3320_7320

BB_3320_7320:                                     ; preds = %BB_3320_7310
  %isetrp_cmp1.250 = icmp sge i32 %imad.84, -24
  %.6506 = and i32 %shf_hi_bitcast.56, -2147483648
  br label %BB_3320_7340

BB_3320_7340:                                     ; preds = %BB_3320_7320
  %cond_not.160 = xor i1 %isetrp_cmp1.250, true
  %phi_cast_R62_bitcast = bitcast i32 %.6506 to float
  br i1 %cond_not.160, label %BB_3320_7590, label %BB_3320_7350

BB_3320_7350:                                     ; preds = %BB_3320_7340
  %ffma_rz.18 = call float @llvm.nvvm.fma.rz.f(float %ffma.329, float %ffma.333, float %ffma.332)
  %iadd3_n1.195 = add i32 %imad.84, 32
  %lop3_a_bitcast.150 = bitcast float %ffma_rz.18 to i32
  %.6516 = and i32 %lop3_a_bitcast.150, 8388607
  %ffma_rp.18 = call float @llvm.nvvm.fma.rp.f(float %ffma.329, float %ffma.333, float %ffma.332)
  %ffma_rm.18 = call float @llvm.nvvm.fma.rm.f(float %ffma.329, float %ffma.333, float %ffma.332)
  %isetrp_cmp1.252 = icmp ne i32 %imad.84, 0
  %.6531 = or i32 8388608, %.6516
  %iadd3_o1_not.37 = xor i32 %imad.84, -1
  %iadd3_o1_neg.37 = add i32 %iadd3_o1_not.37, 1
  %.6541 = zext i32 %.6531 to i64
  %shf_shift_64.117 = zext i32 %iadd3_n1.195 to i64
  %.6544 = shl i64 %.6541, %shf_shift_64.117
  %shf_result.117 = trunc i64 %.6544 to i32
  %fsetrp_cmp1.113 = fcmp une float %ffma_rp.18, %ffma_rm.18
  %isetrp_cmp1.253 = icmp ne i32 %shf_result.117, 0
  %isetrp_cmp2.253 = and i1 %isetrp_cmp1.253, %isetrp_cmp1.252
  %.6547 = shl i64 %.6541, 32
  %shf_shift_64.118 = zext i32 %iadd3_o1_neg.37 to i64
  %.6548 = lshr i64 %.6547, %shf_shift_64.118
  %shf_hi.98 = lshr i64 %.6548, 32
  %shf_result.118 = trunc i64 %shf_hi.98 to i32
  %lop3_a_cast_zext.75 = zext i1 %fsetrp_cmp1.113 to i32
  %lop3_b_cast_zext.75 = zext i1 %isetrp_cmp2.253 to i32
  %plop3_a_bit.75 = and i32 %lop3_a_cast_zext.75, 1
  %plop3_b_bit.75 = and i32 %lop3_b_cast_zext.75, 1
  %.6549 = xor i32 %plop3_a_bit.75, 1
  %.6550 = xor i32 %plop3_b_bit.75, 1
  %.6552 = and i32 %.6549, %plop3_b_bit.75
  %.6554 = and i32 %plop3_a_bit.75, %.6550
  %.6556 = or i32 %.6552, %.6554
  %.6557 = and i32 %plop3_a_bit.75, %plop3_b_bit.75
  %.6559 = or i32 %.6556, %.6557
  %lop3_pred_cmp.132 = icmp ne i32 %.6559, 0
  %.6561 = zext i32 %shf_result.118 to i64
  %.6562 = shl i64 %.6561, 32
  %.6563 = lshr i64 %.6562, 1
  %shf_hi.99 = lshr i64 %.6563, 32
  %shf_result.119 = trunc i64 %shf_hi.99 to i32
  %sel_pred_not.18 = xor i1 %lop3_pred_cmp.132, true
  %sel.37 = select i1 %sel_pred_not.18, i32 0, i32 1
  %.6564 = xor i32 %sel.37, -1
  %.6566 = xor i32 %shf_result.119, -1
  %.6567 = and i32 %.6564, 1
  %.6568 = and i32 %.6567, %shf_result.119
  %.6576 = and i32 %sel.37, %.6566
  %.6577 = or i32 %.6568, %.6576
  %.6579 = and i32 %sel.37, %shf_result.119
  %.6580 = or i32 %.6577, %.6579
  %.6584 = and i32 %.6580, %shf_result.118
  %imad.85 = add i32 %shf_result.119, %.6584
  %.6589 = xor i32 %imad.85, -1
  %.6590 = xor i32 %.6506, -1
  %.6592 = and i32 %.6589, %.6506
  %.6597 = and i32 %imad.85, %.6590
  %.6599 = or i32 %.6592, %.6597
  %.6603 = and i32 %imad.85, %.6506
  %.6605 = or i32 %.6599, %.6603
  %phi_cast_R63_bitcast = bitcast i32 %.6605 to float
  %phi_cast_R2177_bitcast = bitcast i32 %.6531 to float
  br label %BB_3320_7590

BB_3320_74b0:                                     ; preds = %BB_3320_72f0
  %.6613 = and i32 %shf_hi_bitcast.56, -2147483648
  %.6628 = or i32 2139095040, %.6613
  %phi_cast_R66_bitcast = bitcast i32 %.6628 to float
  %phi_cast_R2175_bitcast = bitcast i32 %iadd3_n1.193 to float
  br label %BB_3320_7590

BB_3320_74e0:                                     ; preds = %BB_3320_72d0
  %.6639 = zext i32 %iadd3_n1.193 to i64
  %.6642 = shl i64 %.6639, 23
  %.6643 = and i64 %.6642, 4294967295
  %.6644 = add i64 %.6643, %.6486
  %.6645 = trunc i64 %.6644 to i32
  %phi_cast_R68_bitcast = bitcast i32 %.6645 to float
  %phi_cast_R2175_bitcast.1 = bitcast i32 %iadd3_n1.193 to float
  br label %BB_3320_7590

BB_3320_7590:                                     ; preds = %BB_3320_74e0, %BB_3320_74b0, %BB_3320_7350, %BB_3320_7340, %BB_3320_7310, %BB_3320_7580, %BB_3320_7560, %BB_3320_7540, %BB_3320_7510
  %phi.307 = phi float [ %phi_cast_R63_bitcast, %BB_3320_7350 ], [ %phi_cast_R66_bitcast, %BB_3320_74b0 ], [ %phi_cast_R68_bitcast, %BB_3320_74e0 ], [ %ffma.334, %BB_3320_7310 ], [ %phi_cast_R62_bitcast, %BB_3320_7340 ], [ %phi_cast_R52_bitcast, %BB_3320_7510 ], [ %phi_cast_R55_bitcast, %BB_3320_7540 ], [ %mufu_rsq.18, %BB_3320_7560 ], [ %fadd.36, %BB_3320_7580 ]
  %phi.308 = phi float [ %phi_cast_R2177_bitcast, %BB_3320_7350 ], [ %phi_cast_R2175_bitcast, %BB_3320_74b0 ], [ %phi_cast_R2175_bitcast.1, %BB_3320_74e0 ], [ %phi_cast_R2175_bitcast.2, %BB_3320_7310 ], [ %phi_cast_R2175_bitcast.2, %BB_3320_7340 ], [ %phi.297, %BB_3320_7510 ], [ %phi.297, %BB_3320_7540 ], [ %phi.297, %BB_3320_7560 ], [ %phi.297, %BB_3320_7580 ]
  br label %BB_3340

BB_3340:                                          ; preds = %BB_3320_7590, %BB_32f0
  %phi.309 = phi float [ %phi.307, %BB_3320_7590 ], [ %ffma.325, %BB_32f0 ]
  %phi.310 = phi float [ %phi.308, %BB_3320_7590 ], [ %phi.297, %BB_32f0 ]
  br label %BB_3360

BB_3360:                                          ; preds = %BB_3340, %BB_3200
  %phi.311 = phi float [ %phi.309, %BB_3340 ], [ %phi.296, %BB_3200 ]
  %phi.312 = phi float [ %phi.310, %BB_3340 ], [ %phi.297, %BB_3200 ]
  %phi.313 = phi i32 [ %.75, %BB_3340 ], [ %phi.298, %BB_3200 ]
  %phi.314 = phi float [ %phi.309, %BB_3340 ], [ %phi.299, %BB_3200 ]
  br label %BB_3390

BB_3390:                                          ; preds = %BB_3360
  %shfl_activemask.50 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.50 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.50, float %phi.314, i32 18, i32 31)
  br label %BB_33a0

BB_33a0:                                          ; preds = %BB_3390
  %isetrp_cmp1.254 = icmp uge i32 %tid_x, 19
  %isetrp_cmp1.255 = icmp ne i32 %tid_x, 19
  br label %BB_33d0

BB_33d0:                                          ; preds = %BB_33a0
  %304 = zext i1 %isetrp_cmp1.254 to i32
  %305 = icmp ne i32 %304, 0
  br i1 %305, label %BB_800033d0, label %BB_33f0

BB_800033d0:                                      ; preds = %BB_33d0
  %lds_addr_memaddr_offset_add.66 = add i32 %.88, 2376
  %.6653 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.66
  %lds.69 = load volatile float, ptr addrspace(3) %.6653, align 4
  %ffma.335 = call float @llvm.fma.f32(float %shfl_idx.50, float %lds.69, float %phi.300)
  br label %BB_33f0

BB_33f0:                                          ; preds = %BB_800033d0, %BB_33d0
  %phi.315 = phi float [ %ffma.335, %BB_800033d0 ], [ %phi.300, %BB_33d0 ]
  %warp_reconv_mask.18 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.18)
  br i1 %isetrp_cmp1.255, label %BB_3550, label %BB_3400

BB_3400:                                          ; preds = %BB_33f0
  %ffma_addend_fneg.19 = fneg float %phi.315
  %ffma.336 = call float @llvm.fma.f32(float %phi.311, float %phi, float %ffma_addend_fneg.19)
  %lds_addr_memaddr_offset_add.67 = add i32 %.75, 2584
  %.6663 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.67
  %lds.70 = load volatile float, ptr addrspace(3) %.6663, align 4
  %mufu_rcp.38 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.70)
  %fchk_num_bits.19 = bitcast float %ffma.336 to i32
  %fchk_den_bits.19 = bitcast float %lds.70 to i32
  %fchk_aden.19 = and i32 %fchk_den_bits.19, 2147483647
  %fchk_anum.19 = and i32 %fchk_num_bits.19, 2147483647
  %fchk_den_subz.19 = icmp ult i32 %fchk_aden.19, 8388608
  %fchk_den_infnan.19 = icmp uge i32 %fchk_aden.19, 2139095040
  %fchk_num_infnan.19 = icmp uge i32 %fchk_anum.19, 2139095040
  %fchk_den_bad.19 = or i1 %fchk_den_subz.19, %fchk_den_infnan.19
  %fchk_px.19 = or i1 %fchk_den_bad.19, %fchk_num_infnan.19
  %ffma_lhs_fneg.38 = fneg float %lds.70
  %ffma.337 = call float @llvm.fma.f32(float %ffma_lhs_fneg.38, float %mufu_rcp.38, float 1.000000e+00)
  %ffma.338 = call float @llvm.fma.f32(float %mufu_rcp.38, float %ffma.337, float %mufu_rcp.38)
  %ffma.339 = call float @llvm.fma.f32(float %ffma.336, float %ffma.338, float 0.000000e+00)
  %ffma.340 = call float @llvm.fma.f32(float %ffma_lhs_fneg.38, float %ffma.339, float %ffma.336)
  %ffma.341 = call float @llvm.fma.f32(float %ffma.338, float %ffma.340, float %ffma.339)
  br label %BB_34e0

BB_34e0:                                          ; preds = %BB_3400
  %cond_not.161 = xor i1 %fchk_px.19, true
  br i1 %cond_not.161, label %BB_3530, label %BB_3510_6f40

BB_3510_6f40:                                     ; preds = %BB_34e0
  %.6667 = zext i32 %fchk_den_bits.19 to i64
  %.6668 = shl i64 %.6667, 32
  %.6669 = lshr i64 %.6668, 23
  %shf_hi.100 = lshr i64 %.6669, 32
  %shf_result.120 = trunc i64 %shf_hi.100 to i32
  %.6671 = zext i32 %fchk_num_bits.19 to i64
  %.6672 = shl i64 %.6671, 32
  %.6673 = lshr i64 %.6672, 23
  %shf_hi.101 = lshr i64 %.6673, 32
  %shf_result.121 = trunc i64 %shf_hi.101 to i32
  %.6677 = and i32 %shf_result.120, 255
  %.6685 = and i32 %shf_result.121, 255
  %iadd3_n1.197 = add i32 %.6677, -1
  %iadd3_n1.198 = add i32 %.6685, -1
  %isetrp_cmp1.256 = icmp ugt i32 %iadd3_n1.197, 253
  %isetrp_cmp1.257 = icmp ugt i32 %iadd3_n1.198, 253
  %isetrp_cmp2.257 = or i1 %isetrp_cmp1.257, %isetrp_cmp1.256
  br label %BB_3510_6fd0

BB_3510_6fd0:                                     ; preds = %BB_3510_6f40
  %cond_not.162 = xor i1 %isetrp_cmp2.257, true
  br i1 %cond_not.162, label %BB_3510_80006fd0, label %BB_3510_6ff0

BB_3510_6ff0:                                     ; preds = %BB_3510_6fd0
  %fsetrp_lhs_fabs.95 = call float @llvm.nvvm.fabs.f(float %ffma.336)
  %fsetrp_cmp1.114 = fcmp ugt float %fsetrp_lhs_fabs.95, 0x7FF0000000000000
  %fsetrp_lhs_fabs.96 = call float @llvm.nvvm.fabs.f(float %lds.70)
  %fsetrp_cmp1.115 = fcmp ugt float %fsetrp_lhs_fabs.96, 0x7FF0000000000000
  %lop3_a_cast_zext.76 = zext i1 %fsetrp_cmp1.114 to i32
  %lop3_b_cast_zext.76 = zext i1 %fsetrp_cmp1.115 to i32
  %plop3_a_bit.76 = and i32 %lop3_a_cast_zext.76, 1
  %plop3_b_bit.76 = and i32 %lop3_b_cast_zext.76, 1
  %.6692 = xor i32 %plop3_a_bit.76, 1
  %.6693 = xor i32 %plop3_b_bit.76, 1
  %.6695 = and i32 %.6692, %plop3_b_bit.76
  %.6697 = and i32 %plop3_a_bit.76, %.6693
  %.6699 = or i32 %.6695, %.6697
  %.6700 = and i32 %plop3_a_bit.76, %plop3_b_bit.76
  %.6702 = or i32 %.6699, %.6700
  %lop3_pred_cmp.133 = icmp ne i32 %.6702, 0
  br label %BB_3510_7020

BB_3510_7020:                                     ; preds = %BB_3510_6ff0
  %306 = zext i1 %lop3_pred_cmp.133 to i32
  %307 = icmp ne i32 %306, 0
  br i1 %307, label %BB_3510_7580, label %BB_3510_7030

BB_3510_7030:                                     ; preds = %BB_3510_7020
  %.6705 = xor i32 %fchk_den_bits.19, -1
  %.6707 = xor i32 %fchk_num_bits.19, -1
  %.6708 = and i32 %.6705, 2147483647
  %.6709 = and i32 %.6708, %fchk_num_bits.19
  %.6711 = and i32 %fchk_aden.19, %.6707
  %.6712 = or i32 %.6709, %.6711
  %.6714 = and i32 %fchk_aden.19, %fchk_num_bits.19
  %.6715 = or i32 %.6712, %.6714
  %lop3_pred_cmp.134 = icmp ne i32 %.6715, 0
  br label %BB_3510_7040

BB_3510_7040:                                     ; preds = %BB_3510_7030
  %cond_not.163 = xor i1 %lop3_pred_cmp.134, true
  br i1 %cond_not.163, label %BB_3510_7560, label %BB_3510_7050

BB_3510_7050:                                     ; preds = %BB_3510_7040
  %fsetrp_cmp1.116 = fcmp une float %fsetrp_lhs_fabs.95, 0x7FF0000000000000
  %fsetrp_cmp1.117 = fcmp une float %fsetrp_lhs_fabs.96, 0x7FF0000000000000
  br label %BB_3510_7080

BB_3510_7080:                                     ; preds = %BB_3510_7050
  %cond_not.164 = xor i1 %fsetrp_cmp1.117, true
  br i1 %cond_not.164, label %BB_3510_80007080, label %BB_3510_7090

BB_3510_80007080:                                 ; preds = %BB_3510_7080
  %bra_cond_not.19 = xor i1 %fsetrp_cmp1.116, true
  br i1 %bra_cond_not.19, label %BB_3510_7560, label %BB_3510_7090

BB_3510_7090:                                     ; preds = %BB_3510_80007080, %BB_3510_7080
  %lop3_pred_cmp.135 = icmp ne i32 %fchk_anum.19, 0
  %lop3_a_cast_zext.77 = zext i1 %fsetrp_cmp1.117 to i32
  %lop3_b_cast_zext.77 = zext i1 %lop3_pred_cmp.135 to i32
  %plop3_a_bit.77 = and i32 %lop3_a_cast_zext.77, 1
  %plop3_b_bit.77 = and i32 %lop3_b_cast_zext.77, 1
  %.6729 = xor i32 %plop3_a_bit.77, 1
  %.6730 = xor i32 %plop3_b_bit.77, 1
  %.6732 = and i32 %.6729, %.6730
  %.6734 = and i32 %.6729, %plop3_b_bit.77
  %.6736 = or i32 %.6732, %.6734
  %.6737 = and i32 %plop3_a_bit.77, %.6730
  %.6739 = or i32 %.6736, %.6737
  %lop3_pred_cmp.136 = icmp ne i32 %.6739, 0
  br label %BB_3510_70b0

BB_3510_70b0:                                     ; preds = %BB_3510_7090
  %308 = zext i1 %lop3_pred_cmp.136 to i32
  %309 = icmp ne i32 %308, 0
  br i1 %309, label %BB_3510_7540, label %BB_3510_70c0

BB_3510_70c0:                                     ; preds = %BB_3510_70b0
  %lop3_pred_cmp.137 = icmp ne i32 %fchk_aden.19, 0
  %lop3_a_cast_zext.78 = zext i1 %fsetrp_cmp1.116 to i32
  %lop3_b_cast_zext.78 = zext i1 %lop3_pred_cmp.137 to i32
  %plop3_a_bit.78 = and i32 %lop3_a_cast_zext.78, 1
  %plop3_b_bit.78 = and i32 %lop3_b_cast_zext.78, 1
  %.6750 = xor i32 %plop3_a_bit.78, 1
  %.6751 = xor i32 %plop3_b_bit.78, 1
  %.6753 = and i32 %.6750, %.6751
  %.6755 = and i32 %.6750, %plop3_b_bit.78
  %.6757 = or i32 %.6753, %.6755
  %.6758 = and i32 %plop3_a_bit.78, %.6751
  %.6760 = or i32 %.6757, %.6758
  %lop3_pred_cmp.138 = icmp ne i32 %.6760, 0
  br label %BB_3510_70e0

BB_3510_70e0:                                     ; preds = %BB_3510_70c0
  %310 = zext i1 %lop3_pred_cmp.138 to i32
  %311 = icmp ne i32 %310, 0
  br i1 %311, label %BB_3510_7510, label %BB_3510_70f0

BB_3510_70f0:                                     ; preds = %BB_3510_70e0
  %isetrp_cmp1.258 = icmp sge i32 %iadd3_n1.198, 0
  %isetrp_cmp1.259 = icmp sge i32 %iadd3_n1.197, 0
  br label %BB_3510_7130

BB_3510_7130:                                     ; preds = %BB_3510_70f0
  %312 = zext i1 %isetrp_cmp1.258 to i32
  %313 = icmp ne i32 %312, 0
  br i1 %313, label %BB_3510_80007130, label %BB_3510_7140

BB_3510_80007130:                                 ; preds = %BB_3510_7130
  br label %BB_3510_7140

BB_3510_7140:                                     ; preds = %BB_3510_80007130, %BB_3510_7130
  %phi.316 = phi i32 [ 0, %BB_3510_80007130 ], [ %iadd3_n1.197, %BB_3510_7130 ]
  %cond_not.165 = xor i1 %isetrp_cmp1.258, true
  br i1 %cond_not.165, label %BB_3510_80007140, label %BB_3510_7160

BB_3510_80007140:                                 ; preds = %BB_3510_7140
  %ffma.342 = call float @llvm.fma.f32(float %ffma.336, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R72_bitcast = bitcast float %ffma.342 to i32
  br label %BB_3510_7160

BB_3510_7160:                                     ; preds = %BB_3510_80007140, %BB_3510_7140
  %phi.317 = phi i32 [ %phi_cast_R72_bitcast, %BB_3510_80007140 ], [ %fchk_num_bits.19, %BB_3510_7140 ]
  %phi.318 = phi i32 [ -64, %BB_3510_80007140 ], [ %phi.316, %BB_3510_7140 ]
  %cond_not.166 = xor i1 %isetrp_cmp1.259, true
  br i1 %cond_not.166, label %BB_3510_80007160, label %BB_3510_7180

BB_3510_80007160:                                 ; preds = %BB_3510_7160
  %ffma.343 = call float @llvm.fma.f32(float %lds.70, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.39 = add i32 %phi.318, 64
  %phi_cast_R672_bitcast = bitcast float %ffma.343 to i32
  br label %BB_3510_7180

BB_3510_7510:                                     ; preds = %BB_3510_70e0
  %.6773 = and i32 %.6705, -2147483648
  %.6774 = and i32 %.6773, %fchk_num_bits.19
  %.6775 = and i32 %fchk_den_bits.19, -2147483648
  %.6776 = and i32 %.6775, %.6707
  %.6777 = or i32 %.6774, %.6776
  %.6778 = xor i32 %.6777, -1
  %.6781 = and i32 %.6778, 2139095040
  %.6788 = or i32 %.6781, %.6777
  %phi_cast_R77_bitcast = bitcast i32 %.6788 to float
  br label %BB_3510_7590

BB_3510_7540:                                     ; preds = %BB_3510_70b0
  %.6802 = and i32 %.6705, -2147483648
  %.6803 = and i32 %.6802, %fchk_num_bits.19
  %.6804 = and i32 %fchk_den_bits.19, -2147483648
  %.6805 = and i32 %.6804, %.6707
  %.6806 = or i32 %.6803, %.6805
  %phi_cast_R78_bitcast = bitcast i32 %.6806 to float
  br label %BB_3510_7590

BB_3510_7560:                                     ; preds = %BB_3510_80007080, %BB_3510_7040
  %mufu_rsq.19 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_3510_7590

BB_3510_7580:                                     ; preds = %BB_3510_7020
  %fadd.38 = fadd float %ffma.336, %lds.70
  br label %BB_3510_7590

BB_3510_80006fd0:                                 ; preds = %BB_3510_6fd0
  br label %BB_3510_7180

BB_3510_7180:                                     ; preds = %BB_3510_80006fd0, %BB_3510_80007160, %BB_3510_7160
  %phi.319 = phi i32 [ %fchk_den_bits.19, %BB_3510_80006fd0 ], [ %phi_cast_R672_bitcast, %BB_3510_80007160 ], [ %fchk_den_bits.19, %BB_3510_7160 ]
  %phi.320 = phi i32 [ %fchk_num_bits.19, %BB_3510_80006fd0 ], [ %phi.317, %BB_3510_80007160 ], [ %phi.317, %BB_3510_7160 ]
  %phi.321 = phi i32 [ 0, %BB_3510_80006fd0 ], [ %viadd.39, %BB_3510_80007160 ], [ %phi.318, %BB_3510_7160 ]
  %.6811 = zext i32 %.6677 to i64
  %.6814 = shl i64 %.6811, 23
  %.6815 = and i64 %.6814, 4294967295
  %.6816 = add i64 %.6815, 3229614080
  %.6817 = trunc i64 %.6816 to i32
  %iadd3_n1.200 = add i32 %.6685, -127
  %iadd3_o1_not.38 = xor i32 %.6817, -1
  %iadd3_o1_neg.38 = add i32 %iadd3_o1_not.38, 1
  %iadd3_n1.201 = add i32 %iadd3_o1_neg.38, %phi.319
  %imad_tmp.76 = mul i32 %iadd3_n1.200, -8388608
  %imad.87 = add i32 %imad_tmp.76, %phi.320
  %mufu_src_bitcast.19 = bitcast i32 %iadd3_n1.201 to float
  %mufu_rcp.39 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.19)
  %fadd_lhs_fneg.19 = fneg float %mufu_src_bitcast.19
  %fadd.39 = fadd float %fadd_lhs_fneg.19, 0.000000e+00
  %iadd3_o3_not.19 = xor i32 %.6677, -1
  %iadd3_o3_neg.19 = add i32 %iadd3_o3_not.19, 1
  %iadd3_n2.202 = add i32 %.6685, %iadd3_o3_neg.19
  %iadd3_n1.203 = add i32 %iadd3_n2.202, %phi.321
  %ffma.344 = call float @llvm.fma.f32(float %mufu_rcp.39, float %fadd.39, float 1.000000e+00)
  %ffma.345 = call float @llvm.fma.f32(float %mufu_rcp.39, float %ffma.344, float %mufu_rcp.39)
  %ffma_lhs_bitcast.19 = bitcast i32 %imad.87 to float
  %ffma.346 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.19, float %ffma.345, float 0.000000e+00)
  %ffma.347 = call float @llvm.fma.f32(float %fadd.39, float %ffma.346, float %ffma_lhs_bitcast.19)
  %ffma.348 = call float @llvm.fma.f32(float %ffma.345, float %ffma.347, float %ffma.346)
  %ffma.349 = call float @llvm.fma.f32(float %fadd.39, float %ffma.348, float %ffma_lhs_bitcast.19)
  %ffma.350 = call float @llvm.fma.f32(float %ffma.345, float %ffma.349, float %ffma.348)
  %shf_hi_bitcast.59 = bitcast float %ffma.350 to i32
  %.6819 = zext i32 %shf_hi_bitcast.59 to i64
  %.6820 = shl i64 %.6819, 32
  %.6821 = lshr i64 %.6820, 23
  %shf_hi.102 = lshr i64 %.6821, 32
  %shf_result.122 = trunc i64 %shf_hi.102 to i32
  %.6825 = and i32 %shf_result.122, 255
  %imad.88 = add i32 %.6825, %iadd3_n1.203
  %iadd3_n1.204 = add i32 %imad.88, -1
  %isetrp_cmp1.260 = icmp uge i32 %iadd3_n1.204, 254
  br label %BB_3510_72d0

BB_3510_72d0:                                     ; preds = %BB_3510_7180
  %cond_not.167 = xor i1 %isetrp_cmp1.260, true
  br i1 %cond_not.167, label %BB_3510_74e0, label %BB_3510_72e0

BB_3510_72e0:                                     ; preds = %BB_3510_72d0
  %isetrp_cmp1.261 = icmp sgt i32 %imad.88, 254
  br label %BB_3510_72f0

BB_3510_72f0:                                     ; preds = %BB_3510_72e0
  %314 = zext i1 %isetrp_cmp1.261 to i32
  %315 = icmp ne i32 %314, 0
  br i1 %315, label %BB_3510_74b0, label %BB_3510_7300

BB_3510_7300:                                     ; preds = %BB_3510_72f0
  %isetrp_cmp1.262 = icmp sge i32 %imad.88, 1
  br label %BB_3510_7310

BB_3510_7310:                                     ; preds = %BB_3510_7300
  %phi_cast_R2187_bitcast.2 = bitcast i32 %iadd3_n1.203 to float
  br i1 %isetrp_cmp1.262, label %BB_3510_7590, label %BB_3510_7320

BB_3510_7320:                                     ; preds = %BB_3510_7310
  %isetrp_cmp1.263 = icmp sge i32 %imad.88, -24
  %.6839 = and i32 %shf_hi_bitcast.59, -2147483648
  br label %BB_3510_7340

BB_3510_7340:                                     ; preds = %BB_3510_7320
  %cond_not.168 = xor i1 %isetrp_cmp1.263, true
  %phi_cast_R85_bitcast = bitcast i32 %.6839 to float
  br i1 %cond_not.168, label %BB_3510_7590, label %BB_3510_7350

BB_3510_7350:                                     ; preds = %BB_3510_7340
  %ffma_rz.19 = call float @llvm.nvvm.fma.rz.f(float %ffma.345, float %ffma.349, float %ffma.348)
  %iadd3_n1.205 = add i32 %imad.88, 32
  %lop3_a_bitcast.158 = bitcast float %ffma_rz.19 to i32
  %.6849 = and i32 %lop3_a_bitcast.158, 8388607
  %ffma_rp.19 = call float @llvm.nvvm.fma.rp.f(float %ffma.345, float %ffma.349, float %ffma.348)
  %ffma_rm.19 = call float @llvm.nvvm.fma.rm.f(float %ffma.345, float %ffma.349, float %ffma.348)
  %isetrp_cmp1.265 = icmp ne i32 %imad.88, 0
  %.6864 = or i32 8388608, %.6849
  %iadd3_o1_not.39 = xor i32 %imad.88, -1
  %iadd3_o1_neg.39 = add i32 %iadd3_o1_not.39, 1
  %.6874 = zext i32 %.6864 to i64
  %shf_shift_64.123 = zext i32 %iadd3_n1.205 to i64
  %.6877 = shl i64 %.6874, %shf_shift_64.123
  %shf_result.123 = trunc i64 %.6877 to i32
  %fsetrp_cmp1.119 = fcmp une float %ffma_rp.19, %ffma_rm.19
  %isetrp_cmp1.266 = icmp ne i32 %shf_result.123, 0
  %isetrp_cmp2.266 = and i1 %isetrp_cmp1.266, %isetrp_cmp1.265
  %.6880 = shl i64 %.6874, 32
  %shf_shift_64.124 = zext i32 %iadd3_o1_neg.39 to i64
  %.6881 = lshr i64 %.6880, %shf_shift_64.124
  %shf_hi.103 = lshr i64 %.6881, 32
  %shf_result.124 = trunc i64 %shf_hi.103 to i32
  %lop3_a_cast_zext.79 = zext i1 %fsetrp_cmp1.119 to i32
  %lop3_b_cast_zext.79 = zext i1 %isetrp_cmp2.266 to i32
  %plop3_a_bit.79 = and i32 %lop3_a_cast_zext.79, 1
  %plop3_b_bit.79 = and i32 %lop3_b_cast_zext.79, 1
  %.6882 = xor i32 %plop3_a_bit.79, 1
  %.6883 = xor i32 %plop3_b_bit.79, 1
  %.6885 = and i32 %.6882, %plop3_b_bit.79
  %.6887 = and i32 %plop3_a_bit.79, %.6883
  %.6889 = or i32 %.6885, %.6887
  %.6890 = and i32 %plop3_a_bit.79, %plop3_b_bit.79
  %.6892 = or i32 %.6889, %.6890
  %lop3_pred_cmp.139 = icmp ne i32 %.6892, 0
  %.6894 = zext i32 %shf_result.124 to i64
  %.6895 = shl i64 %.6894, 32
  %.6896 = lshr i64 %.6895, 1
  %shf_hi.104 = lshr i64 %.6896, 32
  %shf_result.125 = trunc i64 %shf_hi.104 to i32
  %sel_pred_not.19 = xor i1 %lop3_pred_cmp.139, true
  %sel.39 = select i1 %sel_pred_not.19, i32 0, i32 1
  %.6897 = xor i32 %sel.39, -1
  %.6899 = xor i32 %shf_result.125, -1
  %.6900 = and i32 %.6897, 1
  %.6901 = and i32 %.6900, %shf_result.125
  %.6909 = and i32 %sel.39, %.6899
  %.6910 = or i32 %.6901, %.6909
  %.6912 = and i32 %sel.39, %shf_result.125
  %.6913 = or i32 %.6910, %.6912
  %.6917 = and i32 %.6913, %shf_result.124
  %imad.89 = add i32 %shf_result.125, %.6917
  %.6922 = xor i32 %imad.89, -1
  %.6923 = xor i32 %.6839, -1
  %.6925 = and i32 %.6922, %.6839
  %.6930 = and i32 %imad.89, %.6923
  %.6932 = or i32 %.6925, %.6930
  %.6936 = and i32 %imad.89, %.6839
  %.6938 = or i32 %.6932, %.6936
  %phi_cast_R86_bitcast = bitcast i32 %.6938 to float
  %phi_cast_R2189_bitcast = bitcast i32 %.6864 to float
  br label %BB_3510_7590

BB_3510_74b0:                                     ; preds = %BB_3510_72f0
  %.6946 = and i32 %shf_hi_bitcast.59, -2147483648
  %.6961 = or i32 2139095040, %.6946
  %phi_cast_R89_bitcast = bitcast i32 %.6961 to float
  %phi_cast_R2187_bitcast = bitcast i32 %iadd3_n1.203 to float
  br label %BB_3510_7590

BB_3510_74e0:                                     ; preds = %BB_3510_72d0
  %.6972 = zext i32 %iadd3_n1.203 to i64
  %.6975 = shl i64 %.6972, 23
  %.6976 = and i64 %.6975, 4294967295
  %.6977 = add i64 %.6976, %.6819
  %.6978 = trunc i64 %.6977 to i32
  %phi_cast_R90_bitcast = bitcast i32 %.6978 to float
  %phi_cast_R2187_bitcast.1 = bitcast i32 %iadd3_n1.203 to float
  br label %BB_3510_7590

BB_3510_7590:                                     ; preds = %BB_3510_74e0, %BB_3510_74b0, %BB_3510_7350, %BB_3510_7340, %BB_3510_7310, %BB_3510_7580, %BB_3510_7560, %BB_3510_7540, %BB_3510_7510
  %phi.322 = phi float [ %phi_cast_R86_bitcast, %BB_3510_7350 ], [ %phi_cast_R89_bitcast, %BB_3510_74b0 ], [ %phi_cast_R90_bitcast, %BB_3510_74e0 ], [ %ffma.350, %BB_3510_7310 ], [ %phi_cast_R85_bitcast, %BB_3510_7340 ], [ %phi_cast_R77_bitcast, %BB_3510_7510 ], [ %phi_cast_R78_bitcast, %BB_3510_7540 ], [ %mufu_rsq.19, %BB_3510_7560 ], [ %fadd.38, %BB_3510_7580 ]
  %phi.323 = phi float [ %phi_cast_R2189_bitcast, %BB_3510_7350 ], [ %phi_cast_R2187_bitcast, %BB_3510_74b0 ], [ %phi_cast_R2187_bitcast.1, %BB_3510_74e0 ], [ %phi_cast_R2187_bitcast.2, %BB_3510_7310 ], [ %phi_cast_R2187_bitcast.2, %BB_3510_7340 ], [ %phi.312, %BB_3510_7510 ], [ %phi.312, %BB_3510_7540 ], [ %phi.312, %BB_3510_7560 ], [ %phi.312, %BB_3510_7580 ]
  br label %BB_3530

BB_3530:                                          ; preds = %BB_3510_7590, %BB_34e0
  %phi.324 = phi float [ %phi.322, %BB_3510_7590 ], [ %ffma.341, %BB_34e0 ]
  %phi.325 = phi float [ %phi.323, %BB_3510_7590 ], [ %phi.312, %BB_34e0 ]
  br label %BB_3550

BB_3550:                                          ; preds = %BB_3530, %BB_33f0
  %phi.326 = phi float [ %phi.324, %BB_3530 ], [ %phi.311, %BB_33f0 ]
  %phi.327 = phi float [ %phi.325, %BB_3530 ], [ %phi.312, %BB_33f0 ]
  %phi.328 = phi i32 [ %.75, %BB_3530 ], [ %phi.313, %BB_33f0 ]
  %phi.329 = phi float [ %phi.324, %BB_3530 ], [ %phi.314, %BB_33f0 ]
  br label %BB_3580

BB_3580:                                          ; preds = %BB_3550
  %shfl_activemask.51 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.51 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.51, float %phi.329, i32 19, i32 31)
  br label %BB_3590

BB_3590:                                          ; preds = %BB_3580
  %isetrp_cmp1.267 = icmp uge i32 %tid_x, 20
  %isetrp_cmp1.268 = icmp ne i32 %tid_x, 20
  br label %BB_35c0

BB_35c0:                                          ; preds = %BB_3590
  %316 = zext i1 %isetrp_cmp1.267 to i32
  %317 = icmp ne i32 %316, 0
  br i1 %317, label %BB_800035c0, label %BB_35e0

BB_800035c0:                                      ; preds = %BB_35c0
  %lds_addr_memaddr_offset_add.68 = add i32 %.88, 2508
  %.6986 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.68
  %lds.71 = load volatile float, ptr addrspace(3) %.6986, align 4
  %ffma.351 = call float @llvm.fma.f32(float %shfl_idx.51, float %lds.71, float %phi.315)
  br label %BB_35e0

BB_35e0:                                          ; preds = %BB_800035c0, %BB_35c0
  %phi.330 = phi float [ %ffma.351, %BB_800035c0 ], [ %phi.315, %BB_35c0 ]
  %warp_reconv_mask.19 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.19)
  br i1 %isetrp_cmp1.268, label %BB_3740, label %BB_35f0

BB_35f0:                                          ; preds = %BB_35e0
  %ffma_addend_fneg.20 = fneg float %phi.330
  %ffma.352 = call float @llvm.fma.f32(float %phi.326, float %phi, float %ffma_addend_fneg.20)
  %lds_addr_memaddr_offset_add.69 = add i32 %.75, 2720
  %.6996 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.69
  %lds.72 = load volatile float, ptr addrspace(3) %.6996, align 4
  %mufu_rcp.40 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.72)
  %fchk_num_bits.20 = bitcast float %ffma.352 to i32
  %fchk_den_bits.20 = bitcast float %lds.72 to i32
  %fchk_aden.20 = and i32 %fchk_den_bits.20, 2147483647
  %fchk_anum.20 = and i32 %fchk_num_bits.20, 2147483647
  %fchk_den_subz.20 = icmp ult i32 %fchk_aden.20, 8388608
  %fchk_den_infnan.20 = icmp uge i32 %fchk_aden.20, 2139095040
  %fchk_num_infnan.20 = icmp uge i32 %fchk_anum.20, 2139095040
  %fchk_den_bad.20 = or i1 %fchk_den_subz.20, %fchk_den_infnan.20
  %fchk_px.20 = or i1 %fchk_den_bad.20, %fchk_num_infnan.20
  %ffma_lhs_fneg.40 = fneg float %lds.72
  %ffma.353 = call float @llvm.fma.f32(float %ffma_lhs_fneg.40, float %mufu_rcp.40, float 1.000000e+00)
  %ffma.354 = call float @llvm.fma.f32(float %mufu_rcp.40, float %ffma.353, float %mufu_rcp.40)
  %ffma.355 = call float @llvm.fma.f32(float %ffma.352, float %ffma.354, float 0.000000e+00)
  %ffma.356 = call float @llvm.fma.f32(float %ffma_lhs_fneg.40, float %ffma.355, float %ffma.352)
  %ffma.357 = call float @llvm.fma.f32(float %ffma.354, float %ffma.356, float %ffma.355)
  br label %BB_36d0

BB_36d0:                                          ; preds = %BB_35f0
  %cond_not.169 = xor i1 %fchk_px.20, true
  br i1 %cond_not.169, label %BB_3720, label %BB_3700_6f40

BB_3700_6f40:                                     ; preds = %BB_36d0
  %.7000 = zext i32 %fchk_den_bits.20 to i64
  %.7001 = shl i64 %.7000, 32
  %.7002 = lshr i64 %.7001, 23
  %shf_hi.105 = lshr i64 %.7002, 32
  %shf_result.126 = trunc i64 %shf_hi.105 to i32
  %.7004 = zext i32 %fchk_num_bits.20 to i64
  %.7005 = shl i64 %.7004, 32
  %.7006 = lshr i64 %.7005, 23
  %shf_hi.106 = lshr i64 %.7006, 32
  %shf_result.127 = trunc i64 %shf_hi.106 to i32
  %.7010 = and i32 %shf_result.126, 255
  %.7018 = and i32 %shf_result.127, 255
  %iadd3_n1.207 = add i32 %.7010, -1
  %iadd3_n1.208 = add i32 %.7018, -1
  %isetrp_cmp1.269 = icmp ugt i32 %iadd3_n1.207, 253
  %isetrp_cmp1.270 = icmp ugt i32 %iadd3_n1.208, 253
  %isetrp_cmp2.270 = or i1 %isetrp_cmp1.270, %isetrp_cmp1.269
  br label %BB_3700_6fd0

BB_3700_6fd0:                                     ; preds = %BB_3700_6f40
  %cond_not.170 = xor i1 %isetrp_cmp2.270, true
  br i1 %cond_not.170, label %BB_3700_80006fd0, label %BB_3700_6ff0

BB_3700_6ff0:                                     ; preds = %BB_3700_6fd0
  %fsetrp_lhs_fabs.100 = call float @llvm.nvvm.fabs.f(float %ffma.352)
  %fsetrp_cmp1.120 = fcmp ugt float %fsetrp_lhs_fabs.100, 0x7FF0000000000000
  %fsetrp_lhs_fabs.101 = call float @llvm.nvvm.fabs.f(float %lds.72)
  %fsetrp_cmp1.121 = fcmp ugt float %fsetrp_lhs_fabs.101, 0x7FF0000000000000
  %lop3_a_cast_zext.80 = zext i1 %fsetrp_cmp1.120 to i32
  %lop3_b_cast_zext.80 = zext i1 %fsetrp_cmp1.121 to i32
  %plop3_a_bit.80 = and i32 %lop3_a_cast_zext.80, 1
  %plop3_b_bit.80 = and i32 %lop3_b_cast_zext.80, 1
  %.7025 = xor i32 %plop3_a_bit.80, 1
  %.7026 = xor i32 %plop3_b_bit.80, 1
  %.7028 = and i32 %.7025, %plop3_b_bit.80
  %.7030 = and i32 %plop3_a_bit.80, %.7026
  %.7032 = or i32 %.7028, %.7030
  %.7033 = and i32 %plop3_a_bit.80, %plop3_b_bit.80
  %.7035 = or i32 %.7032, %.7033
  %lop3_pred_cmp.140 = icmp ne i32 %.7035, 0
  br label %BB_3700_7020

BB_3700_7020:                                     ; preds = %BB_3700_6ff0
  %318 = zext i1 %lop3_pred_cmp.140 to i32
  %319 = icmp ne i32 %318, 0
  br i1 %319, label %BB_3700_7580, label %BB_3700_7030

BB_3700_7030:                                     ; preds = %BB_3700_7020
  %.7038 = xor i32 %fchk_den_bits.20, -1
  %.7040 = xor i32 %fchk_num_bits.20, -1
  %.7041 = and i32 %.7038, 2147483647
  %.7042 = and i32 %.7041, %fchk_num_bits.20
  %.7044 = and i32 %fchk_aden.20, %.7040
  %.7045 = or i32 %.7042, %.7044
  %.7047 = and i32 %fchk_aden.20, %fchk_num_bits.20
  %.7048 = or i32 %.7045, %.7047
  %lop3_pred_cmp.141 = icmp ne i32 %.7048, 0
  br label %BB_3700_7040

BB_3700_7040:                                     ; preds = %BB_3700_7030
  %cond_not.171 = xor i1 %lop3_pred_cmp.141, true
  br i1 %cond_not.171, label %BB_3700_7560, label %BB_3700_7050

BB_3700_7050:                                     ; preds = %BB_3700_7040
  %fsetrp_cmp1.122 = fcmp une float %fsetrp_lhs_fabs.100, 0x7FF0000000000000
  %fsetrp_cmp1.123 = fcmp une float %fsetrp_lhs_fabs.101, 0x7FF0000000000000
  br label %BB_3700_7080

BB_3700_7080:                                     ; preds = %BB_3700_7050
  %cond_not.172 = xor i1 %fsetrp_cmp1.123, true
  br i1 %cond_not.172, label %BB_3700_80007080, label %BB_3700_7090

BB_3700_80007080:                                 ; preds = %BB_3700_7080
  %bra_cond_not.20 = xor i1 %fsetrp_cmp1.122, true
  br i1 %bra_cond_not.20, label %BB_3700_7560, label %BB_3700_7090

BB_3700_7090:                                     ; preds = %BB_3700_80007080, %BB_3700_7080
  %lop3_pred_cmp.142 = icmp ne i32 %fchk_anum.20, 0
  %lop3_a_cast_zext.81 = zext i1 %fsetrp_cmp1.123 to i32
  %lop3_b_cast_zext.81 = zext i1 %lop3_pred_cmp.142 to i32
  %plop3_a_bit.81 = and i32 %lop3_a_cast_zext.81, 1
  %plop3_b_bit.81 = and i32 %lop3_b_cast_zext.81, 1
  %.7062 = xor i32 %plop3_a_bit.81, 1
  %.7063 = xor i32 %plop3_b_bit.81, 1
  %.7065 = and i32 %.7062, %.7063
  %.7067 = and i32 %.7062, %plop3_b_bit.81
  %.7069 = or i32 %.7065, %.7067
  %.7070 = and i32 %plop3_a_bit.81, %.7063
  %.7072 = or i32 %.7069, %.7070
  %lop3_pred_cmp.143 = icmp ne i32 %.7072, 0
  br label %BB_3700_70b0

BB_3700_70b0:                                     ; preds = %BB_3700_7090
  %320 = zext i1 %lop3_pred_cmp.143 to i32
  %321 = icmp ne i32 %320, 0
  br i1 %321, label %BB_3700_7540, label %BB_3700_70c0

BB_3700_70c0:                                     ; preds = %BB_3700_70b0
  %lop3_pred_cmp.144 = icmp ne i32 %fchk_aden.20, 0
  %lop3_a_cast_zext.82 = zext i1 %fsetrp_cmp1.122 to i32
  %lop3_b_cast_zext.82 = zext i1 %lop3_pred_cmp.144 to i32
  %plop3_a_bit.82 = and i32 %lop3_a_cast_zext.82, 1
  %plop3_b_bit.82 = and i32 %lop3_b_cast_zext.82, 1
  %.7083 = xor i32 %plop3_a_bit.82, 1
  %.7084 = xor i32 %plop3_b_bit.82, 1
  %.7086 = and i32 %.7083, %.7084
  %.7088 = and i32 %.7083, %plop3_b_bit.82
  %.7090 = or i32 %.7086, %.7088
  %.7091 = and i32 %plop3_a_bit.82, %.7084
  %.7093 = or i32 %.7090, %.7091
  %lop3_pred_cmp.145 = icmp ne i32 %.7093, 0
  br label %BB_3700_70e0

BB_3700_70e0:                                     ; preds = %BB_3700_70c0
  %322 = zext i1 %lop3_pred_cmp.145 to i32
  %323 = icmp ne i32 %322, 0
  br i1 %323, label %BB_3700_7510, label %BB_3700_70f0

BB_3700_70f0:                                     ; preds = %BB_3700_70e0
  %isetrp_cmp1.271 = icmp sge i32 %iadd3_n1.208, 0
  %isetrp_cmp1.272 = icmp sge i32 %iadd3_n1.207, 0
  br label %BB_3700_7130

BB_3700_7130:                                     ; preds = %BB_3700_70f0
  %324 = zext i1 %isetrp_cmp1.271 to i32
  %325 = icmp ne i32 %324, 0
  br i1 %325, label %BB_3700_80007130, label %BB_3700_7140

BB_3700_80007130:                                 ; preds = %BB_3700_7130
  br label %BB_3700_7140

BB_3700_7140:                                     ; preds = %BB_3700_80007130, %BB_3700_7130
  %phi.331 = phi i32 [ 0, %BB_3700_80007130 ], [ %iadd3_n1.207, %BB_3700_7130 ]
  %cond_not.173 = xor i1 %isetrp_cmp1.271, true
  br i1 %cond_not.173, label %BB_3700_80007140, label %BB_3700_7160

BB_3700_80007140:                                 ; preds = %BB_3700_7140
  %ffma.358 = call float @llvm.fma.f32(float %ffma.352, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R97_bitcast = bitcast float %ffma.358 to i32
  br label %BB_3700_7160

BB_3700_7160:                                     ; preds = %BB_3700_80007140, %BB_3700_7140
  %phi.332 = phi i32 [ %phi_cast_R97_bitcast, %BB_3700_80007140 ], [ %fchk_num_bits.20, %BB_3700_7140 ]
  %phi.333 = phi i32 [ -64, %BB_3700_80007140 ], [ %phi.331, %BB_3700_7140 ]
  %cond_not.174 = xor i1 %isetrp_cmp1.272, true
  br i1 %cond_not.174, label %BB_3700_80007160, label %BB_3700_7180

BB_3700_80007160:                                 ; preds = %BB_3700_7160
  %ffma.359 = call float @llvm.fma.f32(float %lds.72, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.41 = add i32 %phi.333, 64
  %phi_cast_R689_bitcast = bitcast float %ffma.359 to i32
  br label %BB_3700_7180

BB_3700_7510:                                     ; preds = %BB_3700_70e0
  %.7106 = and i32 %.7038, -2147483648
  %.7107 = and i32 %.7106, %fchk_num_bits.20
  %.7108 = and i32 %fchk_den_bits.20, -2147483648
  %.7109 = and i32 %.7108, %.7040
  %.7110 = or i32 %.7107, %.7109
  %.7111 = xor i32 %.7110, -1
  %.7114 = and i32 %.7111, 2139095040
  %.7121 = or i32 %.7114, %.7110
  %phi_cast_R101_bitcast = bitcast i32 %.7121 to float
  br label %BB_3700_7590

BB_3700_7540:                                     ; preds = %BB_3700_70b0
  %.7135 = and i32 %.7038, -2147483648
  %.7136 = and i32 %.7135, %fchk_num_bits.20
  %.7137 = and i32 %fchk_den_bits.20, -2147483648
  %.7138 = and i32 %.7137, %.7040
  %.7139 = or i32 %.7136, %.7138
  %phi_cast_R103_bitcast = bitcast i32 %.7139 to float
  br label %BB_3700_7590

BB_3700_7560:                                     ; preds = %BB_3700_80007080, %BB_3700_7040
  %mufu_rsq.20 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_3700_7590

BB_3700_7580:                                     ; preds = %BB_3700_7020
  %fadd.40 = fadd float %ffma.352, %lds.72
  br label %BB_3700_7590

BB_3700_80006fd0:                                 ; preds = %BB_3700_6fd0
  br label %BB_3700_7180

BB_3700_7180:                                     ; preds = %BB_3700_80006fd0, %BB_3700_80007160, %BB_3700_7160
  %phi.334 = phi i32 [ %fchk_den_bits.20, %BB_3700_80006fd0 ], [ %phi_cast_R689_bitcast, %BB_3700_80007160 ], [ %fchk_den_bits.20, %BB_3700_7160 ]
  %phi.335 = phi i32 [ %fchk_num_bits.20, %BB_3700_80006fd0 ], [ %phi.332, %BB_3700_80007160 ], [ %phi.332, %BB_3700_7160 ]
  %phi.336 = phi i32 [ 0, %BB_3700_80006fd0 ], [ %viadd.41, %BB_3700_80007160 ], [ %phi.333, %BB_3700_7160 ]
  %.7144 = zext i32 %.7010 to i64
  %.7147 = shl i64 %.7144, 23
  %.7148 = and i64 %.7147, 4294967295
  %.7149 = add i64 %.7148, 3229614080
  %.7150 = trunc i64 %.7149 to i32
  %iadd3_n1.210 = add i32 %.7018, -127
  %iadd3_o1_not.40 = xor i32 %.7150, -1
  %iadd3_o1_neg.40 = add i32 %iadd3_o1_not.40, 1
  %iadd3_n1.211 = add i32 %iadd3_o1_neg.40, %phi.334
  %imad_tmp.79 = mul i32 %iadd3_n1.210, -8388608
  %imad.90 = add i32 %imad_tmp.79, %phi.335
  %mufu_src_bitcast.20 = bitcast i32 %iadd3_n1.211 to float
  %mufu_rcp.41 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.20)
  %fadd_lhs_fneg.20 = fneg float %mufu_src_bitcast.20
  %fadd.41 = fadd float %fadd_lhs_fneg.20, 0.000000e+00
  %iadd3_o3_not.20 = xor i32 %.7010, -1
  %iadd3_o3_neg.20 = add i32 %iadd3_o3_not.20, 1
  %iadd3_n2.212 = add i32 %.7018, %iadd3_o3_neg.20
  %iadd3_n1.213 = add i32 %iadd3_n2.212, %phi.336
  %ffma.360 = call float @llvm.fma.f32(float %mufu_rcp.41, float %fadd.41, float 1.000000e+00)
  %ffma.361 = call float @llvm.fma.f32(float %mufu_rcp.41, float %ffma.360, float %mufu_rcp.41)
  %ffma_lhs_bitcast.20 = bitcast i32 %imad.90 to float
  %ffma.362 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.20, float %ffma.361, float 0.000000e+00)
  %ffma.363 = call float @llvm.fma.f32(float %fadd.41, float %ffma.362, float %ffma_lhs_bitcast.20)
  %ffma.364 = call float @llvm.fma.f32(float %ffma.361, float %ffma.363, float %ffma.362)
  %ffma.365 = call float @llvm.fma.f32(float %fadd.41, float %ffma.364, float %ffma_lhs_bitcast.20)
  %ffma.366 = call float @llvm.fma.f32(float %ffma.361, float %ffma.365, float %ffma.364)
  %shf_hi_bitcast.62 = bitcast float %ffma.366 to i32
  %.7152 = zext i32 %shf_hi_bitcast.62 to i64
  %.7153 = shl i64 %.7152, 32
  %.7154 = lshr i64 %.7153, 23
  %shf_hi.107 = lshr i64 %.7154, 32
  %shf_result.128 = trunc i64 %shf_hi.107 to i32
  %.7158 = and i32 %shf_result.128, 255
  %imad.91 = add i32 %.7158, %iadd3_n1.213
  %iadd3_n1.214 = add i32 %imad.91, -1
  %isetrp_cmp1.273 = icmp uge i32 %iadd3_n1.214, 254
  br label %BB_3700_72d0

BB_3700_72d0:                                     ; preds = %BB_3700_7180
  %cond_not.175 = xor i1 %isetrp_cmp1.273, true
  br i1 %cond_not.175, label %BB_3700_74e0, label %BB_3700_72e0

BB_3700_72e0:                                     ; preds = %BB_3700_72d0
  %isetrp_cmp1.274 = icmp sgt i32 %imad.91, 254
  br label %BB_3700_72f0

BB_3700_72f0:                                     ; preds = %BB_3700_72e0
  %326 = zext i1 %isetrp_cmp1.274 to i32
  %327 = icmp ne i32 %326, 0
  br i1 %327, label %BB_3700_74b0, label %BB_3700_7300

BB_3700_7300:                                     ; preds = %BB_3700_72f0
  %isetrp_cmp1.275 = icmp sge i32 %imad.91, 1
  br label %BB_3700_7310

BB_3700_7310:                                     ; preds = %BB_3700_7300
  %phi_cast_R2198_bitcast.2 = bitcast i32 %iadd3_n1.213 to float
  br i1 %isetrp_cmp1.275, label %BB_3700_7590, label %BB_3700_7320

BB_3700_7320:                                     ; preds = %BB_3700_7310
  %isetrp_cmp1.276 = icmp sge i32 %imad.91, -24
  %.7172 = and i32 %shf_hi_bitcast.62, -2147483648
  br label %BB_3700_7340

BB_3700_7340:                                     ; preds = %BB_3700_7320
  %cond_not.176 = xor i1 %isetrp_cmp1.276, true
  %phi_cast_R110_bitcast = bitcast i32 %.7172 to float
  br i1 %cond_not.176, label %BB_3700_7590, label %BB_3700_7350

BB_3700_7350:                                     ; preds = %BB_3700_7340
  %ffma_rz.20 = call float @llvm.nvvm.fma.rz.f(float %ffma.361, float %ffma.365, float %ffma.364)
  %iadd3_n1.215 = add i32 %imad.91, 32
  %lop3_a_bitcast.166 = bitcast float %ffma_rz.20 to i32
  %.7182 = and i32 %lop3_a_bitcast.166, 8388607
  %ffma_rp.20 = call float @llvm.nvvm.fma.rp.f(float %ffma.361, float %ffma.365, float %ffma.364)
  %ffma_rm.20 = call float @llvm.nvvm.fma.rm.f(float %ffma.361, float %ffma.365, float %ffma.364)
  %isetrp_cmp1.278 = icmp ne i32 %imad.91, 0
  %.7197 = or i32 8388608, %.7182
  %iadd3_o1_not.41 = xor i32 %imad.91, -1
  %iadd3_o1_neg.41 = add i32 %iadd3_o1_not.41, 1
  %.7207 = zext i32 %.7197 to i64
  %shf_shift_64.129 = zext i32 %iadd3_n1.215 to i64
  %.7210 = shl i64 %.7207, %shf_shift_64.129
  %shf_result.129 = trunc i64 %.7210 to i32
  %fsetrp_cmp1.125 = fcmp une float %ffma_rp.20, %ffma_rm.20
  %isetrp_cmp1.279 = icmp ne i32 %shf_result.129, 0
  %isetrp_cmp2.279 = and i1 %isetrp_cmp1.279, %isetrp_cmp1.278
  %.7213 = shl i64 %.7207, 32
  %shf_shift_64.130 = zext i32 %iadd3_o1_neg.41 to i64
  %.7214 = lshr i64 %.7213, %shf_shift_64.130
  %shf_hi.108 = lshr i64 %.7214, 32
  %shf_result.130 = trunc i64 %shf_hi.108 to i32
  %lop3_a_cast_zext.83 = zext i1 %fsetrp_cmp1.125 to i32
  %lop3_b_cast_zext.83 = zext i1 %isetrp_cmp2.279 to i32
  %plop3_a_bit.83 = and i32 %lop3_a_cast_zext.83, 1
  %plop3_b_bit.83 = and i32 %lop3_b_cast_zext.83, 1
  %.7215 = xor i32 %plop3_a_bit.83, 1
  %.7216 = xor i32 %plop3_b_bit.83, 1
  %.7218 = and i32 %.7215, %plop3_b_bit.83
  %.7220 = and i32 %plop3_a_bit.83, %.7216
  %.7222 = or i32 %.7218, %.7220
  %.7223 = and i32 %plop3_a_bit.83, %plop3_b_bit.83
  %.7225 = or i32 %.7222, %.7223
  %lop3_pred_cmp.146 = icmp ne i32 %.7225, 0
  %.7227 = zext i32 %shf_result.130 to i64
  %.7228 = shl i64 %.7227, 32
  %.7229 = lshr i64 %.7228, 1
  %shf_hi.109 = lshr i64 %.7229, 32
  %shf_result.131 = trunc i64 %shf_hi.109 to i32
  %sel_pred_not.20 = xor i1 %lop3_pred_cmp.146, true
  %sel.41 = select i1 %sel_pred_not.20, i32 0, i32 1
  %.7230 = xor i32 %sel.41, -1
  %.7232 = xor i32 %shf_result.131, -1
  %.7233 = and i32 %.7230, 1
  %.7234 = and i32 %.7233, %shf_result.131
  %.7242 = and i32 %sel.41, %.7232
  %.7243 = or i32 %.7234, %.7242
  %.7245 = and i32 %sel.41, %shf_result.131
  %.7246 = or i32 %.7243, %.7245
  %.7250 = and i32 %.7246, %shf_result.130
  %imad.92 = add i32 %shf_result.131, %.7250
  %.7255 = xor i32 %imad.92, -1
  %.7256 = xor i32 %.7172, -1
  %.7258 = and i32 %.7255, %.7172
  %.7263 = and i32 %imad.92, %.7256
  %.7265 = or i32 %.7258, %.7263
  %.7269 = and i32 %imad.92, %.7172
  %.7271 = or i32 %.7265, %.7269
  %phi_cast_R111_bitcast = bitcast i32 %.7271 to float
  %phi_cast_R2200_bitcast = bitcast i32 %.7197 to float
  br label %BB_3700_7590

BB_3700_74b0:                                     ; preds = %BB_3700_72f0
  %.7279 = and i32 %shf_hi_bitcast.62, -2147483648
  %.7294 = or i32 2139095040, %.7279
  %phi_cast_R115_bitcast = bitcast i32 %.7294 to float
  %phi_cast_R2198_bitcast = bitcast i32 %iadd3_n1.213 to float
  br label %BB_3700_7590

BB_3700_74e0:                                     ; preds = %BB_3700_72d0
  %.7305 = zext i32 %iadd3_n1.213 to i64
  %.7308 = shl i64 %.7305, 23
  %.7309 = and i64 %.7308, 4294967295
  %.7310 = add i64 %.7309, %.7152
  %.7311 = trunc i64 %.7310 to i32
  %phi_cast_R116_bitcast = bitcast i32 %.7311 to float
  %phi_cast_R2198_bitcast.1 = bitcast i32 %iadd3_n1.213 to float
  br label %BB_3700_7590

BB_3700_7590:                                     ; preds = %BB_3700_74e0, %BB_3700_74b0, %BB_3700_7350, %BB_3700_7340, %BB_3700_7310, %BB_3700_7580, %BB_3700_7560, %BB_3700_7540, %BB_3700_7510
  %phi.337 = phi float [ %phi_cast_R111_bitcast, %BB_3700_7350 ], [ %phi_cast_R115_bitcast, %BB_3700_74b0 ], [ %phi_cast_R116_bitcast, %BB_3700_74e0 ], [ %ffma.366, %BB_3700_7310 ], [ %phi_cast_R110_bitcast, %BB_3700_7340 ], [ %phi_cast_R101_bitcast, %BB_3700_7510 ], [ %phi_cast_R103_bitcast, %BB_3700_7540 ], [ %mufu_rsq.20, %BB_3700_7560 ], [ %fadd.40, %BB_3700_7580 ]
  %phi.338 = phi float [ %phi_cast_R2200_bitcast, %BB_3700_7350 ], [ %phi_cast_R2198_bitcast, %BB_3700_74b0 ], [ %phi_cast_R2198_bitcast.1, %BB_3700_74e0 ], [ %phi_cast_R2198_bitcast.2, %BB_3700_7310 ], [ %phi_cast_R2198_bitcast.2, %BB_3700_7340 ], [ %phi.327, %BB_3700_7510 ], [ %phi.327, %BB_3700_7540 ], [ %phi.327, %BB_3700_7560 ], [ %phi.327, %BB_3700_7580 ]
  br label %BB_3720

BB_3720:                                          ; preds = %BB_3700_7590, %BB_36d0
  %phi.339 = phi float [ %phi.337, %BB_3700_7590 ], [ %ffma.357, %BB_36d0 ]
  %phi.340 = phi float [ %phi.338, %BB_3700_7590 ], [ %phi.327, %BB_36d0 ]
  br label %BB_3740

BB_3740:                                          ; preds = %BB_3720, %BB_35e0
  %phi.341 = phi float [ %phi.339, %BB_3720 ], [ %phi.326, %BB_35e0 ]
  %phi.342 = phi float [ %phi.340, %BB_3720 ], [ %phi.327, %BB_35e0 ]
  %phi.343 = phi i32 [ %.75, %BB_3720 ], [ %phi.328, %BB_35e0 ]
  %phi.344 = phi float [ %phi.339, %BB_3720 ], [ %phi.329, %BB_35e0 ]
  br label %BB_3770

BB_3770:                                          ; preds = %BB_3740
  %shfl_activemask.52 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.52 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.52, float %phi.344, i32 20, i32 31)
  br label %BB_3780

BB_3780:                                          ; preds = %BB_3770
  %isetrp_cmp1.280 = icmp uge i32 %tid_x, 21
  %isetrp_cmp1.281 = icmp ne i32 %tid_x, 21
  br label %BB_37b0

BB_37b0:                                          ; preds = %BB_3780
  %328 = zext i1 %isetrp_cmp1.280 to i32
  %329 = icmp ne i32 %328, 0
  br i1 %329, label %BB_800037b0, label %BB_37d0

BB_800037b0:                                      ; preds = %BB_37b0
  %lds_addr_memaddr_offset_add.70 = add i32 %.88, 2640
  %.7319 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.70
  %lds.73 = load volatile float, ptr addrspace(3) %.7319, align 4
  %ffma.367 = call float @llvm.fma.f32(float %shfl_idx.52, float %lds.73, float %phi.330)
  br label %BB_37d0

BB_37d0:                                          ; preds = %BB_800037b0, %BB_37b0
  %phi.345 = phi float [ %ffma.367, %BB_800037b0 ], [ %phi.330, %BB_37b0 ]
  %warp_reconv_mask.20 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.20)
  br i1 %isetrp_cmp1.281, label %BB_3930, label %BB_37e0

BB_37e0:                                          ; preds = %BB_37d0
  %ffma_addend_fneg.21 = fneg float %phi.345
  %ffma.368 = call float @llvm.fma.f32(float %phi.341, float %phi, float %ffma_addend_fneg.21)
  %lds_addr_memaddr_offset_add.71 = add i32 %.75, 2856
  %.7329 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.71
  %lds.74 = load volatile float, ptr addrspace(3) %.7329, align 4
  %mufu_rcp.42 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.74)
  %fchk_num_bits.21 = bitcast float %ffma.368 to i32
  %fchk_den_bits.21 = bitcast float %lds.74 to i32
  %fchk_aden.21 = and i32 %fchk_den_bits.21, 2147483647
  %fchk_anum.21 = and i32 %fchk_num_bits.21, 2147483647
  %fchk_den_subz.21 = icmp ult i32 %fchk_aden.21, 8388608
  %fchk_den_infnan.21 = icmp uge i32 %fchk_aden.21, 2139095040
  %fchk_num_infnan.21 = icmp uge i32 %fchk_anum.21, 2139095040
  %fchk_den_bad.21 = or i1 %fchk_den_subz.21, %fchk_den_infnan.21
  %fchk_px.21 = or i1 %fchk_den_bad.21, %fchk_num_infnan.21
  %ffma_lhs_fneg.42 = fneg float %lds.74
  %ffma.369 = call float @llvm.fma.f32(float %ffma_lhs_fneg.42, float %mufu_rcp.42, float 1.000000e+00)
  %ffma.370 = call float @llvm.fma.f32(float %mufu_rcp.42, float %ffma.369, float %mufu_rcp.42)
  %ffma.371 = call float @llvm.fma.f32(float %ffma.368, float %ffma.370, float 0.000000e+00)
  %ffma.372 = call float @llvm.fma.f32(float %ffma_lhs_fneg.42, float %ffma.371, float %ffma.368)
  %ffma.373 = call float @llvm.fma.f32(float %ffma.370, float %ffma.372, float %ffma.371)
  br label %BB_38c0

BB_38c0:                                          ; preds = %BB_37e0
  %cond_not.177 = xor i1 %fchk_px.21, true
  br i1 %cond_not.177, label %BB_3910, label %BB_38f0_6f40

BB_38f0_6f40:                                     ; preds = %BB_38c0
  %.7333 = zext i32 %fchk_den_bits.21 to i64
  %.7334 = shl i64 %.7333, 32
  %.7335 = lshr i64 %.7334, 23
  %shf_hi.110 = lshr i64 %.7335, 32
  %shf_result.132 = trunc i64 %shf_hi.110 to i32
  %.7337 = zext i32 %fchk_num_bits.21 to i64
  %.7338 = shl i64 %.7337, 32
  %.7339 = lshr i64 %.7338, 23
  %shf_hi.111 = lshr i64 %.7339, 32
  %shf_result.133 = trunc i64 %shf_hi.111 to i32
  %.7343 = and i32 %shf_result.132, 255
  %.7351 = and i32 %shf_result.133, 255
  %iadd3_n1.217 = add i32 %.7343, -1
  %iadd3_n1.218 = add i32 %.7351, -1
  %isetrp_cmp1.282 = icmp ugt i32 %iadd3_n1.217, 253
  %isetrp_cmp1.283 = icmp ugt i32 %iadd3_n1.218, 253
  %isetrp_cmp2.283 = or i1 %isetrp_cmp1.283, %isetrp_cmp1.282
  br label %BB_38f0_6fd0

BB_38f0_6fd0:                                     ; preds = %BB_38f0_6f40
  %cond_not.178 = xor i1 %isetrp_cmp2.283, true
  br i1 %cond_not.178, label %BB_38f0_80006fd0, label %BB_38f0_6ff0

BB_38f0_6ff0:                                     ; preds = %BB_38f0_6fd0
  %fsetrp_lhs_fabs.105 = call float @llvm.nvvm.fabs.f(float %ffma.368)
  %fsetrp_cmp1.126 = fcmp ugt float %fsetrp_lhs_fabs.105, 0x7FF0000000000000
  %fsetrp_lhs_fabs.106 = call float @llvm.nvvm.fabs.f(float %lds.74)
  %fsetrp_cmp1.127 = fcmp ugt float %fsetrp_lhs_fabs.106, 0x7FF0000000000000
  %lop3_a_cast_zext.84 = zext i1 %fsetrp_cmp1.126 to i32
  %lop3_b_cast_zext.84 = zext i1 %fsetrp_cmp1.127 to i32
  %plop3_a_bit.84 = and i32 %lop3_a_cast_zext.84, 1
  %plop3_b_bit.84 = and i32 %lop3_b_cast_zext.84, 1
  %.7358 = xor i32 %plop3_a_bit.84, 1
  %.7359 = xor i32 %plop3_b_bit.84, 1
  %.7361 = and i32 %.7358, %plop3_b_bit.84
  %.7363 = and i32 %plop3_a_bit.84, %.7359
  %.7365 = or i32 %.7361, %.7363
  %.7366 = and i32 %plop3_a_bit.84, %plop3_b_bit.84
  %.7368 = or i32 %.7365, %.7366
  %lop3_pred_cmp.147 = icmp ne i32 %.7368, 0
  br label %BB_38f0_7020

BB_38f0_7020:                                     ; preds = %BB_38f0_6ff0
  %330 = zext i1 %lop3_pred_cmp.147 to i32
  %331 = icmp ne i32 %330, 0
  br i1 %331, label %BB_38f0_7580, label %BB_38f0_7030

BB_38f0_7030:                                     ; preds = %BB_38f0_7020
  %.7371 = xor i32 %fchk_den_bits.21, -1
  %.7373 = xor i32 %fchk_num_bits.21, -1
  %.7374 = and i32 %.7371, 2147483647
  %.7375 = and i32 %.7374, %fchk_num_bits.21
  %.7377 = and i32 %fchk_aden.21, %.7373
  %.7378 = or i32 %.7375, %.7377
  %.7380 = and i32 %fchk_aden.21, %fchk_num_bits.21
  %.7381 = or i32 %.7378, %.7380
  %lop3_pred_cmp.148 = icmp ne i32 %.7381, 0
  br label %BB_38f0_7040

BB_38f0_7040:                                     ; preds = %BB_38f0_7030
  %cond_not.179 = xor i1 %lop3_pred_cmp.148, true
  br i1 %cond_not.179, label %BB_38f0_7560, label %BB_38f0_7050

BB_38f0_7050:                                     ; preds = %BB_38f0_7040
  %fsetrp_cmp1.128 = fcmp une float %fsetrp_lhs_fabs.105, 0x7FF0000000000000
  %fsetrp_cmp1.129 = fcmp une float %fsetrp_lhs_fabs.106, 0x7FF0000000000000
  br label %BB_38f0_7080

BB_38f0_7080:                                     ; preds = %BB_38f0_7050
  %cond_not.180 = xor i1 %fsetrp_cmp1.129, true
  br i1 %cond_not.180, label %BB_38f0_80007080, label %BB_38f0_7090

BB_38f0_80007080:                                 ; preds = %BB_38f0_7080
  %bra_cond_not.21 = xor i1 %fsetrp_cmp1.128, true
  br i1 %bra_cond_not.21, label %BB_38f0_7560, label %BB_38f0_7090

BB_38f0_7090:                                     ; preds = %BB_38f0_80007080, %BB_38f0_7080
  %lop3_pred_cmp.149 = icmp ne i32 %fchk_anum.21, 0
  %lop3_a_cast_zext.85 = zext i1 %fsetrp_cmp1.129 to i32
  %lop3_b_cast_zext.85 = zext i1 %lop3_pred_cmp.149 to i32
  %plop3_a_bit.85 = and i32 %lop3_a_cast_zext.85, 1
  %plop3_b_bit.85 = and i32 %lop3_b_cast_zext.85, 1
  %.7395 = xor i32 %plop3_a_bit.85, 1
  %.7396 = xor i32 %plop3_b_bit.85, 1
  %.7398 = and i32 %.7395, %.7396
  %.7400 = and i32 %.7395, %plop3_b_bit.85
  %.7402 = or i32 %.7398, %.7400
  %.7403 = and i32 %plop3_a_bit.85, %.7396
  %.7405 = or i32 %.7402, %.7403
  %lop3_pred_cmp.150 = icmp ne i32 %.7405, 0
  br label %BB_38f0_70b0

BB_38f0_70b0:                                     ; preds = %BB_38f0_7090
  %332 = zext i1 %lop3_pred_cmp.150 to i32
  %333 = icmp ne i32 %332, 0
  br i1 %333, label %BB_38f0_7540, label %BB_38f0_70c0

BB_38f0_70c0:                                     ; preds = %BB_38f0_70b0
  %lop3_pred_cmp.151 = icmp ne i32 %fchk_aden.21, 0
  %lop3_a_cast_zext.86 = zext i1 %fsetrp_cmp1.128 to i32
  %lop3_b_cast_zext.86 = zext i1 %lop3_pred_cmp.151 to i32
  %plop3_a_bit.86 = and i32 %lop3_a_cast_zext.86, 1
  %plop3_b_bit.86 = and i32 %lop3_b_cast_zext.86, 1
  %.7416 = xor i32 %plop3_a_bit.86, 1
  %.7417 = xor i32 %plop3_b_bit.86, 1
  %.7419 = and i32 %.7416, %.7417
  %.7421 = and i32 %.7416, %plop3_b_bit.86
  %.7423 = or i32 %.7419, %.7421
  %.7424 = and i32 %plop3_a_bit.86, %.7417
  %.7426 = or i32 %.7423, %.7424
  %lop3_pred_cmp.152 = icmp ne i32 %.7426, 0
  br label %BB_38f0_70e0

BB_38f0_70e0:                                     ; preds = %BB_38f0_70c0
  %334 = zext i1 %lop3_pred_cmp.152 to i32
  %335 = icmp ne i32 %334, 0
  br i1 %335, label %BB_38f0_7510, label %BB_38f0_70f0

BB_38f0_70f0:                                     ; preds = %BB_38f0_70e0
  %isetrp_cmp1.284 = icmp sge i32 %iadd3_n1.218, 0
  %isetrp_cmp1.285 = icmp sge i32 %iadd3_n1.217, 0
  br label %BB_38f0_7130

BB_38f0_7130:                                     ; preds = %BB_38f0_70f0
  %336 = zext i1 %isetrp_cmp1.284 to i32
  %337 = icmp ne i32 %336, 0
  br i1 %337, label %BB_38f0_80007130, label %BB_38f0_7140

BB_38f0_80007130:                                 ; preds = %BB_38f0_7130
  br label %BB_38f0_7140

BB_38f0_7140:                                     ; preds = %BB_38f0_80007130, %BB_38f0_7130
  %phi.346 = phi i32 [ 0, %BB_38f0_80007130 ], [ %iadd3_n1.217, %BB_38f0_7130 ]
  %cond_not.181 = xor i1 %isetrp_cmp1.284, true
  br i1 %cond_not.181, label %BB_38f0_80007140, label %BB_38f0_7160

BB_38f0_80007140:                                 ; preds = %BB_38f0_7140
  %ffma.374 = call float @llvm.fma.f32(float %ffma.368, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R121_bitcast = bitcast float %ffma.374 to i32
  br label %BB_38f0_7160

BB_38f0_7160:                                     ; preds = %BB_38f0_80007140, %BB_38f0_7140
  %phi.347 = phi i32 [ %phi_cast_R121_bitcast, %BB_38f0_80007140 ], [ %fchk_num_bits.21, %BB_38f0_7140 ]
  %phi.348 = phi i32 [ -64, %BB_38f0_80007140 ], [ %phi.346, %BB_38f0_7140 ]
  %cond_not.182 = xor i1 %isetrp_cmp1.285, true
  br i1 %cond_not.182, label %BB_38f0_80007160, label %BB_38f0_7180

BB_38f0_80007160:                                 ; preds = %BB_38f0_7160
  %ffma.375 = call float @llvm.fma.f32(float %lds.74, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.43 = add i32 %phi.348, 64
  %phi_cast_R705_bitcast = bitcast float %ffma.375 to i32
  br label %BB_38f0_7180

BB_38f0_7510:                                     ; preds = %BB_38f0_70e0
  %.7439 = and i32 %.7371, -2147483648
  %.7440 = and i32 %.7439, %fchk_num_bits.21
  %.7441 = and i32 %fchk_den_bits.21, -2147483648
  %.7442 = and i32 %.7441, %.7373
  %.7443 = or i32 %.7440, %.7442
  %.7444 = xor i32 %.7443, -1
  %.7447 = and i32 %.7444, 2139095040
  %.7454 = or i32 %.7447, %.7443
  %phi_cast_R124_bitcast = bitcast i32 %.7454 to float
  br label %BB_38f0_7590

BB_38f0_7540:                                     ; preds = %BB_38f0_70b0
  %.7468 = and i32 %.7371, -2147483648
  %.7469 = and i32 %.7468, %fchk_num_bits.21
  %.7470 = and i32 %fchk_den_bits.21, -2147483648
  %.7471 = and i32 %.7470, %.7373
  %.7472 = or i32 %.7469, %.7471
  %phi_cast_R126_bitcast = bitcast i32 %.7472 to float
  br label %BB_38f0_7590

BB_38f0_7560:                                     ; preds = %BB_38f0_80007080, %BB_38f0_7040
  %mufu_rsq.21 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_38f0_7590

BB_38f0_7580:                                     ; preds = %BB_38f0_7020
  %fadd.42 = fadd float %ffma.368, %lds.74
  br label %BB_38f0_7590

BB_38f0_80006fd0:                                 ; preds = %BB_38f0_6fd0
  br label %BB_38f0_7180

BB_38f0_7180:                                     ; preds = %BB_38f0_80006fd0, %BB_38f0_80007160, %BB_38f0_7160
  %phi.349 = phi i32 [ %fchk_den_bits.21, %BB_38f0_80006fd0 ], [ %phi_cast_R705_bitcast, %BB_38f0_80007160 ], [ %fchk_den_bits.21, %BB_38f0_7160 ]
  %phi.350 = phi i32 [ %fchk_num_bits.21, %BB_38f0_80006fd0 ], [ %phi.347, %BB_38f0_80007160 ], [ %phi.347, %BB_38f0_7160 ]
  %phi.351 = phi i32 [ 0, %BB_38f0_80006fd0 ], [ %viadd.43, %BB_38f0_80007160 ], [ %phi.348, %BB_38f0_7160 ]
  %.7477 = zext i32 %.7343 to i64
  %.7480 = shl i64 %.7477, 23
  %.7481 = and i64 %.7480, 4294967295
  %.7482 = add i64 %.7481, 3229614080
  %.7483 = trunc i64 %.7482 to i32
  %iadd3_n1.220 = add i32 %.7351, -127
  %iadd3_o1_not.42 = xor i32 %.7483, -1
  %iadd3_o1_neg.42 = add i32 %iadd3_o1_not.42, 1
  %iadd3_n1.221 = add i32 %iadd3_o1_neg.42, %phi.349
  %imad_tmp.82 = mul i32 %iadd3_n1.220, -8388608
  %imad.93 = add i32 %imad_tmp.82, %phi.350
  %mufu_src_bitcast.21 = bitcast i32 %iadd3_n1.221 to float
  %mufu_rcp.43 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.21)
  %fadd_lhs_fneg.21 = fneg float %mufu_src_bitcast.21
  %fadd.43 = fadd float %fadd_lhs_fneg.21, 0.000000e+00
  %iadd3_o3_not.21 = xor i32 %.7343, -1
  %iadd3_o3_neg.21 = add i32 %iadd3_o3_not.21, 1
  %iadd3_n2.222 = add i32 %.7351, %iadd3_o3_neg.21
  %iadd3_n1.223 = add i32 %iadd3_n2.222, %phi.351
  %ffma.376 = call float @llvm.fma.f32(float %mufu_rcp.43, float %fadd.43, float 1.000000e+00)
  %ffma.377 = call float @llvm.fma.f32(float %mufu_rcp.43, float %ffma.376, float %mufu_rcp.43)
  %ffma_lhs_bitcast.21 = bitcast i32 %imad.93 to float
  %ffma.378 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.21, float %ffma.377, float 0.000000e+00)
  %ffma.379 = call float @llvm.fma.f32(float %fadd.43, float %ffma.378, float %ffma_lhs_bitcast.21)
  %ffma.380 = call float @llvm.fma.f32(float %ffma.377, float %ffma.379, float %ffma.378)
  %ffma.381 = call float @llvm.fma.f32(float %fadd.43, float %ffma.380, float %ffma_lhs_bitcast.21)
  %ffma.382 = call float @llvm.fma.f32(float %ffma.377, float %ffma.381, float %ffma.380)
  %shf_hi_bitcast.65 = bitcast float %ffma.382 to i32
  %.7485 = zext i32 %shf_hi_bitcast.65 to i64
  %.7486 = shl i64 %.7485, 32
  %.7487 = lshr i64 %.7486, 23
  %shf_hi.112 = lshr i64 %.7487, 32
  %shf_result.134 = trunc i64 %shf_hi.112 to i32
  %.7491 = and i32 %shf_result.134, 255
  %imad.94 = add i32 %.7491, %iadd3_n1.223
  %iadd3_n1.224 = add i32 %imad.94, -1
  %isetrp_cmp1.286 = icmp uge i32 %iadd3_n1.224, 254
  br label %BB_38f0_72d0

BB_38f0_72d0:                                     ; preds = %BB_38f0_7180
  %cond_not.183 = xor i1 %isetrp_cmp1.286, true
  br i1 %cond_not.183, label %BB_38f0_74e0, label %BB_38f0_72e0

BB_38f0_72e0:                                     ; preds = %BB_38f0_72d0
  %isetrp_cmp1.287 = icmp sgt i32 %imad.94, 254
  br label %BB_38f0_72f0

BB_38f0_72f0:                                     ; preds = %BB_38f0_72e0
  %338 = zext i1 %isetrp_cmp1.287 to i32
  %339 = icmp ne i32 %338, 0
  br i1 %339, label %BB_38f0_74b0, label %BB_38f0_7300

BB_38f0_7300:                                     ; preds = %BB_38f0_72f0
  %isetrp_cmp1.288 = icmp sge i32 %imad.94, 1
  br label %BB_38f0_7310

BB_38f0_7310:                                     ; preds = %BB_38f0_7300
  %phi_cast_R2210_bitcast.2 = bitcast i32 %iadd3_n1.223 to float
  br i1 %isetrp_cmp1.288, label %BB_38f0_7590, label %BB_38f0_7320

BB_38f0_7320:                                     ; preds = %BB_38f0_7310
  %isetrp_cmp1.289 = icmp sge i32 %imad.94, -24
  %.7505 = and i32 %shf_hi_bitcast.65, -2147483648
  br label %BB_38f0_7340

BB_38f0_7340:                                     ; preds = %BB_38f0_7320
  %cond_not.184 = xor i1 %isetrp_cmp1.289, true
  %phi_cast_R134_bitcast = bitcast i32 %.7505 to float
  br i1 %cond_not.184, label %BB_38f0_7590, label %BB_38f0_7350

BB_38f0_7350:                                     ; preds = %BB_38f0_7340
  %ffma_rz.21 = call float @llvm.nvvm.fma.rz.f(float %ffma.377, float %ffma.381, float %ffma.380)
  %iadd3_n1.225 = add i32 %imad.94, 32
  %lop3_a_bitcast.174 = bitcast float %ffma_rz.21 to i32
  %.7515 = and i32 %lop3_a_bitcast.174, 8388607
  %ffma_rp.21 = call float @llvm.nvvm.fma.rp.f(float %ffma.377, float %ffma.381, float %ffma.380)
  %ffma_rm.21 = call float @llvm.nvvm.fma.rm.f(float %ffma.377, float %ffma.381, float %ffma.380)
  %isetrp_cmp1.291 = icmp ne i32 %imad.94, 0
  %.7530 = or i32 8388608, %.7515
  %iadd3_o1_not.43 = xor i32 %imad.94, -1
  %iadd3_o1_neg.43 = add i32 %iadd3_o1_not.43, 1
  %.7540 = zext i32 %.7530 to i64
  %shf_shift_64.135 = zext i32 %iadd3_n1.225 to i64
  %.7543 = shl i64 %.7540, %shf_shift_64.135
  %shf_result.135 = trunc i64 %.7543 to i32
  %fsetrp_cmp1.131 = fcmp une float %ffma_rp.21, %ffma_rm.21
  %isetrp_cmp1.292 = icmp ne i32 %shf_result.135, 0
  %isetrp_cmp2.292 = and i1 %isetrp_cmp1.292, %isetrp_cmp1.291
  %.7546 = shl i64 %.7540, 32
  %shf_shift_64.136 = zext i32 %iadd3_o1_neg.43 to i64
  %.7547 = lshr i64 %.7546, %shf_shift_64.136
  %shf_hi.113 = lshr i64 %.7547, 32
  %shf_result.136 = trunc i64 %shf_hi.113 to i32
  %lop3_a_cast_zext.87 = zext i1 %fsetrp_cmp1.131 to i32
  %lop3_b_cast_zext.87 = zext i1 %isetrp_cmp2.292 to i32
  %plop3_a_bit.87 = and i32 %lop3_a_cast_zext.87, 1
  %plop3_b_bit.87 = and i32 %lop3_b_cast_zext.87, 1
  %.7548 = xor i32 %plop3_a_bit.87, 1
  %.7549 = xor i32 %plop3_b_bit.87, 1
  %.7551 = and i32 %.7548, %plop3_b_bit.87
  %.7553 = and i32 %plop3_a_bit.87, %.7549
  %.7555 = or i32 %.7551, %.7553
  %.7556 = and i32 %plop3_a_bit.87, %plop3_b_bit.87
  %.7558 = or i32 %.7555, %.7556
  %lop3_pred_cmp.153 = icmp ne i32 %.7558, 0
  %.7560 = zext i32 %shf_result.136 to i64
  %.7561 = shl i64 %.7560, 32
  %.7562 = lshr i64 %.7561, 1
  %shf_hi.114 = lshr i64 %.7562, 32
  %shf_result.137 = trunc i64 %shf_hi.114 to i32
  %sel_pred_not.21 = xor i1 %lop3_pred_cmp.153, true
  %sel.43 = select i1 %sel_pred_not.21, i32 0, i32 1
  %.7563 = xor i32 %sel.43, -1
  %.7565 = xor i32 %shf_result.137, -1
  %.7566 = and i32 %.7563, 1
  %.7567 = and i32 %.7566, %shf_result.137
  %.7575 = and i32 %sel.43, %.7565
  %.7576 = or i32 %.7567, %.7575
  %.7578 = and i32 %sel.43, %shf_result.137
  %.7579 = or i32 %.7576, %.7578
  %.7583 = and i32 %.7579, %shf_result.136
  %imad.95 = add i32 %shf_result.137, %.7583
  %.7588 = xor i32 %imad.95, -1
  %.7589 = xor i32 %.7505, -1
  %.7591 = and i32 %.7588, %.7505
  %.7596 = and i32 %imad.95, %.7589
  %.7598 = or i32 %.7591, %.7596
  %.7602 = and i32 %imad.95, %.7505
  %.7604 = or i32 %.7598, %.7602
  %phi_cast_R135_bitcast = bitcast i32 %.7604 to float
  %phi_cast_R2214_bitcast = bitcast i32 %.7530 to float
  br label %BB_38f0_7590

BB_38f0_74b0:                                     ; preds = %BB_38f0_72f0
  %.7612 = and i32 %shf_hi_bitcast.65, -2147483648
  %.7627 = or i32 2139095040, %.7612
  %phi_cast_R138_bitcast = bitcast i32 %.7627 to float
  %phi_cast_R2210_bitcast = bitcast i32 %iadd3_n1.223 to float
  br label %BB_38f0_7590

BB_38f0_74e0:                                     ; preds = %BB_38f0_72d0
  %.7638 = zext i32 %iadd3_n1.223 to i64
  %.7641 = shl i64 %.7638, 23
  %.7642 = and i64 %.7641, 4294967295
  %.7643 = add i64 %.7642, %.7485
  %.7644 = trunc i64 %.7643 to i32
  %phi_cast_R139_bitcast = bitcast i32 %.7644 to float
  %phi_cast_R2210_bitcast.1 = bitcast i32 %iadd3_n1.223 to float
  br label %BB_38f0_7590

BB_38f0_7590:                                     ; preds = %BB_38f0_74e0, %BB_38f0_74b0, %BB_38f0_7350, %BB_38f0_7340, %BB_38f0_7310, %BB_38f0_7580, %BB_38f0_7560, %BB_38f0_7540, %BB_38f0_7510
  %phi.352 = phi float [ %phi_cast_R135_bitcast, %BB_38f0_7350 ], [ %phi_cast_R138_bitcast, %BB_38f0_74b0 ], [ %phi_cast_R139_bitcast, %BB_38f0_74e0 ], [ %ffma.382, %BB_38f0_7310 ], [ %phi_cast_R134_bitcast, %BB_38f0_7340 ], [ %phi_cast_R124_bitcast, %BB_38f0_7510 ], [ %phi_cast_R126_bitcast, %BB_38f0_7540 ], [ %mufu_rsq.21, %BB_38f0_7560 ], [ %fadd.42, %BB_38f0_7580 ]
  %phi.353 = phi float [ %phi_cast_R2214_bitcast, %BB_38f0_7350 ], [ %phi_cast_R2210_bitcast, %BB_38f0_74b0 ], [ %phi_cast_R2210_bitcast.1, %BB_38f0_74e0 ], [ %phi_cast_R2210_bitcast.2, %BB_38f0_7310 ], [ %phi_cast_R2210_bitcast.2, %BB_38f0_7340 ], [ %phi.342, %BB_38f0_7510 ], [ %phi.342, %BB_38f0_7540 ], [ %phi.342, %BB_38f0_7560 ], [ %phi.342, %BB_38f0_7580 ]
  br label %BB_3910

BB_3910:                                          ; preds = %BB_38f0_7590, %BB_38c0
  %phi.354 = phi float [ %phi.352, %BB_38f0_7590 ], [ %ffma.373, %BB_38c0 ]
  %phi.355 = phi float [ %phi.353, %BB_38f0_7590 ], [ %phi.342, %BB_38c0 ]
  br label %BB_3930

BB_3930:                                          ; preds = %BB_3910, %BB_37d0
  %phi.356 = phi float [ %phi.354, %BB_3910 ], [ %phi.341, %BB_37d0 ]
  %phi.357 = phi float [ %phi.355, %BB_3910 ], [ %phi.342, %BB_37d0 ]
  %phi.358 = phi i32 [ %.75, %BB_3910 ], [ %phi.343, %BB_37d0 ]
  %phi.359 = phi float [ %phi.354, %BB_3910 ], [ %phi.344, %BB_37d0 ]
  br label %BB_3960

BB_3960:                                          ; preds = %BB_3930
  %shfl_activemask.53 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.53 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.53, float %phi.359, i32 21, i32 31)
  br label %BB_3970

BB_3970:                                          ; preds = %BB_3960
  %isetrp_cmp1.293 = icmp uge i32 %tid_x, 22
  %isetrp_cmp1.294 = icmp ne i32 %tid_x, 22
  br label %BB_39a0

BB_39a0:                                          ; preds = %BB_3970
  %340 = zext i1 %isetrp_cmp1.293 to i32
  %341 = icmp ne i32 %340, 0
  br i1 %341, label %BB_800039a0, label %BB_39c0

BB_800039a0:                                      ; preds = %BB_39a0
  %lds_addr_memaddr_offset_add.72 = add i32 %.88, 2772
  %.7652 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.72
  %lds.75 = load volatile float, ptr addrspace(3) %.7652, align 4
  %ffma.383 = call float @llvm.fma.f32(float %shfl_idx.53, float %lds.75, float %phi.345)
  br label %BB_39c0

BB_39c0:                                          ; preds = %BB_800039a0, %BB_39a0
  %phi.360 = phi float [ %ffma.383, %BB_800039a0 ], [ %phi.345, %BB_39a0 ]
  %warp_reconv_mask.21 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.21)
  br i1 %isetrp_cmp1.294, label %BB_3b20, label %BB_39d0

BB_39d0:                                          ; preds = %BB_39c0
  %ffma_addend_fneg.22 = fneg float %phi.360
  %ffma.384 = call float @llvm.fma.f32(float %phi.356, float %phi, float %ffma_addend_fneg.22)
  %lds_addr_memaddr_offset_add.73 = add i32 %.75, 2992
  %.7662 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.73
  %lds.76 = load volatile float, ptr addrspace(3) %.7662, align 4
  %mufu_rcp.44 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.76)
  %fchk_num_bits.22 = bitcast float %ffma.384 to i32
  %fchk_den_bits.22 = bitcast float %lds.76 to i32
  %fchk_aden.22 = and i32 %fchk_den_bits.22, 2147483647
  %fchk_anum.22 = and i32 %fchk_num_bits.22, 2147483647
  %fchk_den_subz.22 = icmp ult i32 %fchk_aden.22, 8388608
  %fchk_den_infnan.22 = icmp uge i32 %fchk_aden.22, 2139095040
  %fchk_num_infnan.22 = icmp uge i32 %fchk_anum.22, 2139095040
  %fchk_den_bad.22 = or i1 %fchk_den_subz.22, %fchk_den_infnan.22
  %fchk_px.22 = or i1 %fchk_den_bad.22, %fchk_num_infnan.22
  %ffma_lhs_fneg.44 = fneg float %lds.76
  %ffma.385 = call float @llvm.fma.f32(float %ffma_lhs_fneg.44, float %mufu_rcp.44, float 1.000000e+00)
  %ffma.386 = call float @llvm.fma.f32(float %mufu_rcp.44, float %ffma.385, float %mufu_rcp.44)
  %ffma.387 = call float @llvm.fma.f32(float %ffma.384, float %ffma.386, float 0.000000e+00)
  %ffma.388 = call float @llvm.fma.f32(float %ffma_lhs_fneg.44, float %ffma.387, float %ffma.384)
  %ffma.389 = call float @llvm.fma.f32(float %ffma.386, float %ffma.388, float %ffma.387)
  br label %BB_3ab0

BB_3ab0:                                          ; preds = %BB_39d0
  %cond_not.185 = xor i1 %fchk_px.22, true
  br i1 %cond_not.185, label %BB_3b00, label %BB_3ae0_6f40

BB_3ae0_6f40:                                     ; preds = %BB_3ab0
  %.7666 = zext i32 %fchk_den_bits.22 to i64
  %.7667 = shl i64 %.7666, 32
  %.7668 = lshr i64 %.7667, 23
  %shf_hi.115 = lshr i64 %.7668, 32
  %shf_result.138 = trunc i64 %shf_hi.115 to i32
  %.7670 = zext i32 %fchk_num_bits.22 to i64
  %.7671 = shl i64 %.7670, 32
  %.7672 = lshr i64 %.7671, 23
  %shf_hi.116 = lshr i64 %.7672, 32
  %shf_result.139 = trunc i64 %shf_hi.116 to i32
  %.7676 = and i32 %shf_result.138, 255
  %.7684 = and i32 %shf_result.139, 255
  %iadd3_n1.227 = add i32 %.7676, -1
  %iadd3_n1.228 = add i32 %.7684, -1
  %isetrp_cmp1.295 = icmp ugt i32 %iadd3_n1.227, 253
  %isetrp_cmp1.296 = icmp ugt i32 %iadd3_n1.228, 253
  %isetrp_cmp2.296 = or i1 %isetrp_cmp1.296, %isetrp_cmp1.295
  br label %BB_3ae0_6fd0

BB_3ae0_6fd0:                                     ; preds = %BB_3ae0_6f40
  %cond_not.186 = xor i1 %isetrp_cmp2.296, true
  br i1 %cond_not.186, label %BB_3ae0_80006fd0, label %BB_3ae0_6ff0

BB_3ae0_6ff0:                                     ; preds = %BB_3ae0_6fd0
  %fsetrp_lhs_fabs.110 = call float @llvm.nvvm.fabs.f(float %ffma.384)
  %fsetrp_cmp1.132 = fcmp ugt float %fsetrp_lhs_fabs.110, 0x7FF0000000000000
  %fsetrp_lhs_fabs.111 = call float @llvm.nvvm.fabs.f(float %lds.76)
  %fsetrp_cmp1.133 = fcmp ugt float %fsetrp_lhs_fabs.111, 0x7FF0000000000000
  %lop3_a_cast_zext.88 = zext i1 %fsetrp_cmp1.132 to i32
  %lop3_b_cast_zext.88 = zext i1 %fsetrp_cmp1.133 to i32
  %plop3_a_bit.88 = and i32 %lop3_a_cast_zext.88, 1
  %plop3_b_bit.88 = and i32 %lop3_b_cast_zext.88, 1
  %.7691 = xor i32 %plop3_a_bit.88, 1
  %.7692 = xor i32 %plop3_b_bit.88, 1
  %.7694 = and i32 %.7691, %plop3_b_bit.88
  %.7696 = and i32 %plop3_a_bit.88, %.7692
  %.7698 = or i32 %.7694, %.7696
  %.7699 = and i32 %plop3_a_bit.88, %plop3_b_bit.88
  %.7701 = or i32 %.7698, %.7699
  %lop3_pred_cmp.154 = icmp ne i32 %.7701, 0
  br label %BB_3ae0_7020

BB_3ae0_7020:                                     ; preds = %BB_3ae0_6ff0
  %342 = zext i1 %lop3_pred_cmp.154 to i32
  %343 = icmp ne i32 %342, 0
  br i1 %343, label %BB_3ae0_7580, label %BB_3ae0_7030

BB_3ae0_7030:                                     ; preds = %BB_3ae0_7020
  %.7704 = xor i32 %fchk_den_bits.22, -1
  %.7706 = xor i32 %fchk_num_bits.22, -1
  %.7707 = and i32 %.7704, 2147483647
  %.7708 = and i32 %.7707, %fchk_num_bits.22
  %.7710 = and i32 %fchk_aden.22, %.7706
  %.7711 = or i32 %.7708, %.7710
  %.7713 = and i32 %fchk_aden.22, %fchk_num_bits.22
  %.7714 = or i32 %.7711, %.7713
  %lop3_pred_cmp.155 = icmp ne i32 %.7714, 0
  br label %BB_3ae0_7040

BB_3ae0_7040:                                     ; preds = %BB_3ae0_7030
  %cond_not.187 = xor i1 %lop3_pred_cmp.155, true
  br i1 %cond_not.187, label %BB_3ae0_7560, label %BB_3ae0_7050

BB_3ae0_7050:                                     ; preds = %BB_3ae0_7040
  %fsetrp_cmp1.134 = fcmp une float %fsetrp_lhs_fabs.110, 0x7FF0000000000000
  %fsetrp_cmp1.135 = fcmp une float %fsetrp_lhs_fabs.111, 0x7FF0000000000000
  br label %BB_3ae0_7080

BB_3ae0_7080:                                     ; preds = %BB_3ae0_7050
  %cond_not.188 = xor i1 %fsetrp_cmp1.135, true
  br i1 %cond_not.188, label %BB_3ae0_80007080, label %BB_3ae0_7090

BB_3ae0_80007080:                                 ; preds = %BB_3ae0_7080
  %bra_cond_not.22 = xor i1 %fsetrp_cmp1.134, true
  br i1 %bra_cond_not.22, label %BB_3ae0_7560, label %BB_3ae0_7090

BB_3ae0_7090:                                     ; preds = %BB_3ae0_80007080, %BB_3ae0_7080
  %lop3_pred_cmp.156 = icmp ne i32 %fchk_anum.22, 0
  %lop3_a_cast_zext.89 = zext i1 %fsetrp_cmp1.135 to i32
  %lop3_b_cast_zext.89 = zext i1 %lop3_pred_cmp.156 to i32
  %plop3_a_bit.89 = and i32 %lop3_a_cast_zext.89, 1
  %plop3_b_bit.89 = and i32 %lop3_b_cast_zext.89, 1
  %.7728 = xor i32 %plop3_a_bit.89, 1
  %.7729 = xor i32 %plop3_b_bit.89, 1
  %.7731 = and i32 %.7728, %.7729
  %.7733 = and i32 %.7728, %plop3_b_bit.89
  %.7735 = or i32 %.7731, %.7733
  %.7736 = and i32 %plop3_a_bit.89, %.7729
  %.7738 = or i32 %.7735, %.7736
  %lop3_pred_cmp.157 = icmp ne i32 %.7738, 0
  br label %BB_3ae0_70b0

BB_3ae0_70b0:                                     ; preds = %BB_3ae0_7090
  %344 = zext i1 %lop3_pred_cmp.157 to i32
  %345 = icmp ne i32 %344, 0
  br i1 %345, label %BB_3ae0_7540, label %BB_3ae0_70c0

BB_3ae0_70c0:                                     ; preds = %BB_3ae0_70b0
  %lop3_pred_cmp.158 = icmp ne i32 %fchk_aden.22, 0
  %lop3_a_cast_zext.90 = zext i1 %fsetrp_cmp1.134 to i32
  %lop3_b_cast_zext.90 = zext i1 %lop3_pred_cmp.158 to i32
  %plop3_a_bit.90 = and i32 %lop3_a_cast_zext.90, 1
  %plop3_b_bit.90 = and i32 %lop3_b_cast_zext.90, 1
  %.7749 = xor i32 %plop3_a_bit.90, 1
  %.7750 = xor i32 %plop3_b_bit.90, 1
  %.7752 = and i32 %.7749, %.7750
  %.7754 = and i32 %.7749, %plop3_b_bit.90
  %.7756 = or i32 %.7752, %.7754
  %.7757 = and i32 %plop3_a_bit.90, %.7750
  %.7759 = or i32 %.7756, %.7757
  %lop3_pred_cmp.159 = icmp ne i32 %.7759, 0
  br label %BB_3ae0_70e0

BB_3ae0_70e0:                                     ; preds = %BB_3ae0_70c0
  %346 = zext i1 %lop3_pred_cmp.159 to i32
  %347 = icmp ne i32 %346, 0
  br i1 %347, label %BB_3ae0_7510, label %BB_3ae0_70f0

BB_3ae0_70f0:                                     ; preds = %BB_3ae0_70e0
  %isetrp_cmp1.297 = icmp sge i32 %iadd3_n1.228, 0
  %isetrp_cmp1.298 = icmp sge i32 %iadd3_n1.227, 0
  br label %BB_3ae0_7130

BB_3ae0_7130:                                     ; preds = %BB_3ae0_70f0
  %348 = zext i1 %isetrp_cmp1.297 to i32
  %349 = icmp ne i32 %348, 0
  br i1 %349, label %BB_3ae0_80007130, label %BB_3ae0_7140

BB_3ae0_80007130:                                 ; preds = %BB_3ae0_7130
  br label %BB_3ae0_7140

BB_3ae0_7140:                                     ; preds = %BB_3ae0_80007130, %BB_3ae0_7130
  %phi.361 = phi i32 [ 0, %BB_3ae0_80007130 ], [ %iadd3_n1.227, %BB_3ae0_7130 ]
  %cond_not.189 = xor i1 %isetrp_cmp1.297, true
  br i1 %cond_not.189, label %BB_3ae0_80007140, label %BB_3ae0_7160

BB_3ae0_80007140:                                 ; preds = %BB_3ae0_7140
  %ffma.390 = call float @llvm.fma.f32(float %ffma.384, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R144_bitcast = bitcast float %ffma.390 to i32
  br label %BB_3ae0_7160

BB_3ae0_7160:                                     ; preds = %BB_3ae0_80007140, %BB_3ae0_7140
  %phi.362 = phi i32 [ %phi_cast_R144_bitcast, %BB_3ae0_80007140 ], [ %fchk_num_bits.22, %BB_3ae0_7140 ]
  %phi.363 = phi i32 [ -64, %BB_3ae0_80007140 ], [ %phi.361, %BB_3ae0_7140 ]
  %cond_not.190 = xor i1 %isetrp_cmp1.298, true
  br i1 %cond_not.190, label %BB_3ae0_80007160, label %BB_3ae0_7180

BB_3ae0_80007160:                                 ; preds = %BB_3ae0_7160
  %ffma.391 = call float @llvm.fma.f32(float %lds.76, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.45 = add i32 %phi.363, 64
  %phi_cast_R721_bitcast = bitcast float %ffma.391 to i32
  br label %BB_3ae0_7180

BB_3ae0_7510:                                     ; preds = %BB_3ae0_70e0
  %.7772 = and i32 %.7704, -2147483648
  %.7773 = and i32 %.7772, %fchk_num_bits.22
  %.7774 = and i32 %fchk_den_bits.22, -2147483648
  %.7775 = and i32 %.7774, %.7706
  %.7776 = or i32 %.7773, %.7775
  %.7777 = xor i32 %.7776, -1
  %.7780 = and i32 %.7777, 2139095040
  %.7787 = or i32 %.7780, %.7776
  %phi_cast_R148_bitcast = bitcast i32 %.7787 to float
  br label %BB_3ae0_7590

BB_3ae0_7540:                                     ; preds = %BB_3ae0_70b0
  %.7801 = and i32 %.7704, -2147483648
  %.7802 = and i32 %.7801, %fchk_num_bits.22
  %.7803 = and i32 %fchk_den_bits.22, -2147483648
  %.7804 = and i32 %.7803, %.7706
  %.7805 = or i32 %.7802, %.7804
  %phi_cast_R149_bitcast = bitcast i32 %.7805 to float
  br label %BB_3ae0_7590

BB_3ae0_7560:                                     ; preds = %BB_3ae0_80007080, %BB_3ae0_7040
  %mufu_rsq.22 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_3ae0_7590

BB_3ae0_7580:                                     ; preds = %BB_3ae0_7020
  %fadd.44 = fadd float %ffma.384, %lds.76
  br label %BB_3ae0_7590

BB_3ae0_80006fd0:                                 ; preds = %BB_3ae0_6fd0
  br label %BB_3ae0_7180

BB_3ae0_7180:                                     ; preds = %BB_3ae0_80006fd0, %BB_3ae0_80007160, %BB_3ae0_7160
  %phi.364 = phi i32 [ %fchk_den_bits.22, %BB_3ae0_80006fd0 ], [ %phi_cast_R721_bitcast, %BB_3ae0_80007160 ], [ %fchk_den_bits.22, %BB_3ae0_7160 ]
  %phi.365 = phi i32 [ %fchk_num_bits.22, %BB_3ae0_80006fd0 ], [ %phi.362, %BB_3ae0_80007160 ], [ %phi.362, %BB_3ae0_7160 ]
  %phi.366 = phi i32 [ 0, %BB_3ae0_80006fd0 ], [ %viadd.45, %BB_3ae0_80007160 ], [ %phi.363, %BB_3ae0_7160 ]
  %.7810 = zext i32 %.7676 to i64
  %.7813 = shl i64 %.7810, 23
  %.7814 = and i64 %.7813, 4294967295
  %.7815 = add i64 %.7814, 3229614080
  %.7816 = trunc i64 %.7815 to i32
  %iadd3_n1.230 = add i32 %.7684, -127
  %iadd3_o1_not.44 = xor i32 %.7816, -1
  %iadd3_o1_neg.44 = add i32 %iadd3_o1_not.44, 1
  %iadd3_n1.231 = add i32 %iadd3_o1_neg.44, %phi.364
  %imad_tmp.86 = mul i32 %iadd3_n1.230, -8388608
  %imad.97 = add i32 %imad_tmp.86, %phi.365
  %mufu_src_bitcast.22 = bitcast i32 %iadd3_n1.231 to float
  %mufu_rcp.45 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.22)
  %fadd_lhs_fneg.22 = fneg float %mufu_src_bitcast.22
  %fadd.45 = fadd float %fadd_lhs_fneg.22, 0.000000e+00
  %iadd3_o3_not.22 = xor i32 %.7676, -1
  %iadd3_o3_neg.22 = add i32 %iadd3_o3_not.22, 1
  %iadd3_n2.232 = add i32 %.7684, %iadd3_o3_neg.22
  %iadd3_n1.233 = add i32 %iadd3_n2.232, %phi.366
  %ffma.392 = call float @llvm.fma.f32(float %mufu_rcp.45, float %fadd.45, float 1.000000e+00)
  %ffma.393 = call float @llvm.fma.f32(float %mufu_rcp.45, float %ffma.392, float %mufu_rcp.45)
  %ffma_lhs_bitcast.22 = bitcast i32 %imad.97 to float
  %ffma.394 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.22, float %ffma.393, float 0.000000e+00)
  %ffma.395 = call float @llvm.fma.f32(float %fadd.45, float %ffma.394, float %ffma_lhs_bitcast.22)
  %ffma.396 = call float @llvm.fma.f32(float %ffma.393, float %ffma.395, float %ffma.394)
  %ffma.397 = call float @llvm.fma.f32(float %fadd.45, float %ffma.396, float %ffma_lhs_bitcast.22)
  %ffma.398 = call float @llvm.fma.f32(float %ffma.393, float %ffma.397, float %ffma.396)
  %shf_hi_bitcast.68 = bitcast float %ffma.398 to i32
  %.7818 = zext i32 %shf_hi_bitcast.68 to i64
  %.7819 = shl i64 %.7818, 32
  %.7820 = lshr i64 %.7819, 23
  %shf_hi.117 = lshr i64 %.7820, 32
  %shf_result.140 = trunc i64 %shf_hi.117 to i32
  %.7824 = and i32 %shf_result.140, 255
  %imad.98 = add i32 %.7824, %iadd3_n1.233
  %iadd3_n1.234 = add i32 %imad.98, -1
  %isetrp_cmp1.299 = icmp uge i32 %iadd3_n1.234, 254
  br label %BB_3ae0_72d0

BB_3ae0_72d0:                                     ; preds = %BB_3ae0_7180
  %cond_not.191 = xor i1 %isetrp_cmp1.299, true
  br i1 %cond_not.191, label %BB_3ae0_74e0, label %BB_3ae0_72e0

BB_3ae0_72e0:                                     ; preds = %BB_3ae0_72d0
  %isetrp_cmp1.300 = icmp sgt i32 %imad.98, 254
  br label %BB_3ae0_72f0

BB_3ae0_72f0:                                     ; preds = %BB_3ae0_72e0
  %350 = zext i1 %isetrp_cmp1.300 to i32
  %351 = icmp ne i32 %350, 0
  br i1 %351, label %BB_3ae0_74b0, label %BB_3ae0_7300

BB_3ae0_7300:                                     ; preds = %BB_3ae0_72f0
  %isetrp_cmp1.301 = icmp sge i32 %imad.98, 1
  br label %BB_3ae0_7310

BB_3ae0_7310:                                     ; preds = %BB_3ae0_7300
  %phi_cast_R2221_bitcast.2 = bitcast i32 %iadd3_n1.233 to float
  br i1 %isetrp_cmp1.301, label %BB_3ae0_7590, label %BB_3ae0_7320

BB_3ae0_7320:                                     ; preds = %BB_3ae0_7310
  %isetrp_cmp1.302 = icmp sge i32 %imad.98, -24
  %.7838 = and i32 %shf_hi_bitcast.68, -2147483648
  br label %BB_3ae0_7340

BB_3ae0_7340:                                     ; preds = %BB_3ae0_7320
  %cond_not.192 = xor i1 %isetrp_cmp1.302, true
  %phi_cast_R157_bitcast = bitcast i32 %.7838 to float
  br i1 %cond_not.192, label %BB_3ae0_7590, label %BB_3ae0_7350

BB_3ae0_7350:                                     ; preds = %BB_3ae0_7340
  %ffma_rz.22 = call float @llvm.nvvm.fma.rz.f(float %ffma.393, float %ffma.397, float %ffma.396)
  %iadd3_n1.235 = add i32 %imad.98, 32
  %lop3_a_bitcast.182 = bitcast float %ffma_rz.22 to i32
  %.7848 = and i32 %lop3_a_bitcast.182, 8388607
  %ffma_rp.22 = call float @llvm.nvvm.fma.rp.f(float %ffma.393, float %ffma.397, float %ffma.396)
  %ffma_rm.22 = call float @llvm.nvvm.fma.rm.f(float %ffma.393, float %ffma.397, float %ffma.396)
  %isetrp_cmp1.304 = icmp ne i32 %imad.98, 0
  %.7863 = or i32 8388608, %.7848
  %iadd3_o1_not.45 = xor i32 %imad.98, -1
  %iadd3_o1_neg.45 = add i32 %iadd3_o1_not.45, 1
  %.7873 = zext i32 %.7863 to i64
  %shf_shift_64.141 = zext i32 %iadd3_n1.235 to i64
  %.7876 = shl i64 %.7873, %shf_shift_64.141
  %shf_result.141 = trunc i64 %.7876 to i32
  %fsetrp_cmp1.137 = fcmp une float %ffma_rp.22, %ffma_rm.22
  %isetrp_cmp1.305 = icmp ne i32 %shf_result.141, 0
  %isetrp_cmp2.305 = and i1 %isetrp_cmp1.305, %isetrp_cmp1.304
  %.7879 = shl i64 %.7873, 32
  %shf_shift_64.142 = zext i32 %iadd3_o1_neg.45 to i64
  %.7880 = lshr i64 %.7879, %shf_shift_64.142
  %shf_hi.118 = lshr i64 %.7880, 32
  %shf_result.142 = trunc i64 %shf_hi.118 to i32
  %lop3_a_cast_zext.91 = zext i1 %fsetrp_cmp1.137 to i32
  %lop3_b_cast_zext.91 = zext i1 %isetrp_cmp2.305 to i32
  %plop3_a_bit.91 = and i32 %lop3_a_cast_zext.91, 1
  %plop3_b_bit.91 = and i32 %lop3_b_cast_zext.91, 1
  %.7881 = xor i32 %plop3_a_bit.91, 1
  %.7882 = xor i32 %plop3_b_bit.91, 1
  %.7884 = and i32 %.7881, %plop3_b_bit.91
  %.7886 = and i32 %plop3_a_bit.91, %.7882
  %.7888 = or i32 %.7884, %.7886
  %.7889 = and i32 %plop3_a_bit.91, %plop3_b_bit.91
  %.7891 = or i32 %.7888, %.7889
  %lop3_pred_cmp.160 = icmp ne i32 %.7891, 0
  %.7893 = zext i32 %shf_result.142 to i64
  %.7894 = shl i64 %.7893, 32
  %.7895 = lshr i64 %.7894, 1
  %shf_hi.119 = lshr i64 %.7895, 32
  %shf_result.143 = trunc i64 %shf_hi.119 to i32
  %sel_pred_not.22 = xor i1 %lop3_pred_cmp.160, true
  %sel.45 = select i1 %sel_pred_not.22, i32 0, i32 1
  %.7896 = xor i32 %sel.45, -1
  %.7898 = xor i32 %shf_result.143, -1
  %.7899 = and i32 %.7896, 1
  %.7900 = and i32 %.7899, %shf_result.143
  %.7908 = and i32 %sel.45, %.7898
  %.7909 = or i32 %.7900, %.7908
  %.7911 = and i32 %sel.45, %shf_result.143
  %.7912 = or i32 %.7909, %.7911
  %.7916 = and i32 %.7912, %shf_result.142
  %imad.99 = add i32 %shf_result.143, %.7916
  %.7921 = xor i32 %imad.99, -1
  %.7922 = xor i32 %.7838, -1
  %.7924 = and i32 %.7921, %.7838
  %.7929 = and i32 %imad.99, %.7922
  %.7931 = or i32 %.7924, %.7929
  %.7935 = and i32 %imad.99, %.7838
  %.7937 = or i32 %.7931, %.7935
  %phi_cast_R159_bitcast = bitcast i32 %.7937 to float
  %phi_cast_R2227_bitcast = bitcast i32 %.7863 to float
  br label %BB_3ae0_7590

BB_3ae0_74b0:                                     ; preds = %BB_3ae0_72f0
  %.7945 = and i32 %shf_hi_bitcast.68, -2147483648
  %.7960 = or i32 2139095040, %.7945
  %phi_cast_R161_bitcast = bitcast i32 %.7960 to float
  %phi_cast_R2221_bitcast = bitcast i32 %iadd3_n1.233 to float
  br label %BB_3ae0_7590

BB_3ae0_74e0:                                     ; preds = %BB_3ae0_72d0
  %.7971 = zext i32 %iadd3_n1.233 to i64
  %.7974 = shl i64 %.7971, 23
  %.7975 = and i64 %.7974, 4294967295
  %.7976 = add i64 %.7975, %.7818
  %.7977 = trunc i64 %.7976 to i32
  %phi_cast_R162_bitcast = bitcast i32 %.7977 to float
  %phi_cast_R2221_bitcast.1 = bitcast i32 %iadd3_n1.233 to float
  br label %BB_3ae0_7590

BB_3ae0_7590:                                     ; preds = %BB_3ae0_74e0, %BB_3ae0_74b0, %BB_3ae0_7350, %BB_3ae0_7340, %BB_3ae0_7310, %BB_3ae0_7580, %BB_3ae0_7560, %BB_3ae0_7540, %BB_3ae0_7510
  %phi.367 = phi float [ %phi_cast_R159_bitcast, %BB_3ae0_7350 ], [ %phi_cast_R161_bitcast, %BB_3ae0_74b0 ], [ %phi_cast_R162_bitcast, %BB_3ae0_74e0 ], [ %ffma.398, %BB_3ae0_7310 ], [ %phi_cast_R157_bitcast, %BB_3ae0_7340 ], [ %phi_cast_R148_bitcast, %BB_3ae0_7510 ], [ %phi_cast_R149_bitcast, %BB_3ae0_7540 ], [ %mufu_rsq.22, %BB_3ae0_7560 ], [ %fadd.44, %BB_3ae0_7580 ]
  %phi.368 = phi float [ %phi_cast_R2227_bitcast, %BB_3ae0_7350 ], [ %phi_cast_R2221_bitcast, %BB_3ae0_74b0 ], [ %phi_cast_R2221_bitcast.1, %BB_3ae0_74e0 ], [ %phi_cast_R2221_bitcast.2, %BB_3ae0_7310 ], [ %phi_cast_R2221_bitcast.2, %BB_3ae0_7340 ], [ %phi.357, %BB_3ae0_7510 ], [ %phi.357, %BB_3ae0_7540 ], [ %phi.357, %BB_3ae0_7560 ], [ %phi.357, %BB_3ae0_7580 ]
  br label %BB_3b00

BB_3b00:                                          ; preds = %BB_3ae0_7590, %BB_3ab0
  %phi.369 = phi float [ %phi.367, %BB_3ae0_7590 ], [ %ffma.389, %BB_3ab0 ]
  %phi.370 = phi float [ %phi.368, %BB_3ae0_7590 ], [ %phi.357, %BB_3ab0 ]
  br label %BB_3b20

BB_3b20:                                          ; preds = %BB_3b00, %BB_39c0
  %phi.371 = phi float [ %phi.369, %BB_3b00 ], [ %phi.356, %BB_39c0 ]
  %phi.372 = phi float [ %phi.370, %BB_3b00 ], [ %phi.357, %BB_39c0 ]
  %phi.373 = phi i32 [ %.75, %BB_3b00 ], [ %phi.358, %BB_39c0 ]
  %phi.374 = phi float [ %phi.369, %BB_3b00 ], [ %phi.359, %BB_39c0 ]
  br label %BB_3b50

BB_3b50:                                          ; preds = %BB_3b20
  %shfl_activemask.54 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.54 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.54, float %phi.374, i32 22, i32 31)
  br label %BB_3b60

BB_3b60:                                          ; preds = %BB_3b50
  %isetrp_cmp1.306 = icmp uge i32 %tid_x, 23
  %isetrp_cmp1.307 = icmp ne i32 %tid_x, 23
  br label %BB_3b90

BB_3b90:                                          ; preds = %BB_3b60
  %352 = zext i1 %isetrp_cmp1.306 to i32
  %353 = icmp ne i32 %352, 0
  br i1 %353, label %BB_80003b90, label %BB_3bb0

BB_80003b90:                                      ; preds = %BB_3b90
  %lds_addr_memaddr_offset_add.74 = add i32 %.88, 2904
  %.7985 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.74
  %lds.77 = load volatile float, ptr addrspace(3) %.7985, align 4
  %ffma.399 = call float @llvm.fma.f32(float %shfl_idx.54, float %lds.77, float %phi.360)
  br label %BB_3bb0

BB_3bb0:                                          ; preds = %BB_80003b90, %BB_3b90
  %phi.375 = phi float [ %ffma.399, %BB_80003b90 ], [ %phi.360, %BB_3b90 ]
  %warp_reconv_mask.22 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.22)
  br i1 %isetrp_cmp1.307, label %BB_3d10, label %BB_3bc0

BB_3bc0:                                          ; preds = %BB_3bb0
  %ffma_addend_fneg.23 = fneg float %phi.375
  %ffma.400 = call float @llvm.fma.f32(float %phi.371, float %phi, float %ffma_addend_fneg.23)
  %lds_addr_memaddr_offset_add.75 = add i32 %.75, 3128
  %.7995 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.75
  %lds.78 = load volatile float, ptr addrspace(3) %.7995, align 4
  %mufu_rcp.46 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.78)
  %fchk_num_bits.23 = bitcast float %ffma.400 to i32
  %fchk_den_bits.23 = bitcast float %lds.78 to i32
  %fchk_aden.23 = and i32 %fchk_den_bits.23, 2147483647
  %fchk_anum.23 = and i32 %fchk_num_bits.23, 2147483647
  %fchk_den_subz.23 = icmp ult i32 %fchk_aden.23, 8388608
  %fchk_den_infnan.23 = icmp uge i32 %fchk_aden.23, 2139095040
  %fchk_num_infnan.23 = icmp uge i32 %fchk_anum.23, 2139095040
  %fchk_den_bad.23 = or i1 %fchk_den_subz.23, %fchk_den_infnan.23
  %fchk_px.23 = or i1 %fchk_den_bad.23, %fchk_num_infnan.23
  %ffma_lhs_fneg.46 = fneg float %lds.78
  %ffma.401 = call float @llvm.fma.f32(float %ffma_lhs_fneg.46, float %mufu_rcp.46, float 1.000000e+00)
  %ffma.402 = call float @llvm.fma.f32(float %mufu_rcp.46, float %ffma.401, float %mufu_rcp.46)
  %ffma.403 = call float @llvm.fma.f32(float %ffma.400, float %ffma.402, float 0.000000e+00)
  %ffma.404 = call float @llvm.fma.f32(float %ffma_lhs_fneg.46, float %ffma.403, float %ffma.400)
  %ffma.405 = call float @llvm.fma.f32(float %ffma.402, float %ffma.404, float %ffma.403)
  br label %BB_3ca0

BB_3ca0:                                          ; preds = %BB_3bc0
  %cond_not.193 = xor i1 %fchk_px.23, true
  br i1 %cond_not.193, label %BB_3cf0, label %BB_3cd0_6f40

BB_3cd0_6f40:                                     ; preds = %BB_3ca0
  %.7999 = zext i32 %fchk_den_bits.23 to i64
  %.8000 = shl i64 %.7999, 32
  %.8001 = lshr i64 %.8000, 23
  %shf_hi.120 = lshr i64 %.8001, 32
  %shf_result.144 = trunc i64 %shf_hi.120 to i32
  %.8003 = zext i32 %fchk_num_bits.23 to i64
  %.8004 = shl i64 %.8003, 32
  %.8005 = lshr i64 %.8004, 23
  %shf_hi.121 = lshr i64 %.8005, 32
  %shf_result.145 = trunc i64 %shf_hi.121 to i32
  %.8009 = and i32 %shf_result.144, 255
  %.8017 = and i32 %shf_result.145, 255
  %iadd3_n1.237 = add i32 %.8009, -1
  %iadd3_n1.238 = add i32 %.8017, -1
  %isetrp_cmp1.308 = icmp ugt i32 %iadd3_n1.237, 253
  %isetrp_cmp1.309 = icmp ugt i32 %iadd3_n1.238, 253
  %isetrp_cmp2.309 = or i1 %isetrp_cmp1.309, %isetrp_cmp1.308
  br label %BB_3cd0_6fd0

BB_3cd0_6fd0:                                     ; preds = %BB_3cd0_6f40
  %cond_not.194 = xor i1 %isetrp_cmp2.309, true
  br i1 %cond_not.194, label %BB_3cd0_80006fd0, label %BB_3cd0_6ff0

BB_3cd0_6ff0:                                     ; preds = %BB_3cd0_6fd0
  %fsetrp_lhs_fabs.115 = call float @llvm.nvvm.fabs.f(float %ffma.400)
  %fsetrp_cmp1.138 = fcmp ugt float %fsetrp_lhs_fabs.115, 0x7FF0000000000000
  %fsetrp_lhs_fabs.116 = call float @llvm.nvvm.fabs.f(float %lds.78)
  %fsetrp_cmp1.139 = fcmp ugt float %fsetrp_lhs_fabs.116, 0x7FF0000000000000
  %lop3_a_cast_zext.92 = zext i1 %fsetrp_cmp1.138 to i32
  %lop3_b_cast_zext.92 = zext i1 %fsetrp_cmp1.139 to i32
  %plop3_a_bit.92 = and i32 %lop3_a_cast_zext.92, 1
  %plop3_b_bit.92 = and i32 %lop3_b_cast_zext.92, 1
  %.8024 = xor i32 %plop3_a_bit.92, 1
  %.8025 = xor i32 %plop3_b_bit.92, 1
  %.8027 = and i32 %.8024, %plop3_b_bit.92
  %.8029 = and i32 %plop3_a_bit.92, %.8025
  %.8031 = or i32 %.8027, %.8029
  %.8032 = and i32 %plop3_a_bit.92, %plop3_b_bit.92
  %.8034 = or i32 %.8031, %.8032
  %lop3_pred_cmp.161 = icmp ne i32 %.8034, 0
  br label %BB_3cd0_7020

BB_3cd0_7020:                                     ; preds = %BB_3cd0_6ff0
  %354 = zext i1 %lop3_pred_cmp.161 to i32
  %355 = icmp ne i32 %354, 0
  br i1 %355, label %BB_3cd0_7580, label %BB_3cd0_7030

BB_3cd0_7030:                                     ; preds = %BB_3cd0_7020
  %.8037 = xor i32 %fchk_den_bits.23, -1
  %.8039 = xor i32 %fchk_num_bits.23, -1
  %.8040 = and i32 %.8037, 2147483647
  %.8041 = and i32 %.8040, %fchk_num_bits.23
  %.8043 = and i32 %fchk_aden.23, %.8039
  %.8044 = or i32 %.8041, %.8043
  %.8046 = and i32 %fchk_aden.23, %fchk_num_bits.23
  %.8047 = or i32 %.8044, %.8046
  %lop3_pred_cmp.162 = icmp ne i32 %.8047, 0
  br label %BB_3cd0_7040

BB_3cd0_7040:                                     ; preds = %BB_3cd0_7030
  %cond_not.195 = xor i1 %lop3_pred_cmp.162, true
  br i1 %cond_not.195, label %BB_3cd0_7560, label %BB_3cd0_7050

BB_3cd0_7050:                                     ; preds = %BB_3cd0_7040
  %fsetrp_cmp1.140 = fcmp une float %fsetrp_lhs_fabs.115, 0x7FF0000000000000
  %fsetrp_cmp1.141 = fcmp une float %fsetrp_lhs_fabs.116, 0x7FF0000000000000
  br label %BB_3cd0_7080

BB_3cd0_7080:                                     ; preds = %BB_3cd0_7050
  %cond_not.196 = xor i1 %fsetrp_cmp1.141, true
  br i1 %cond_not.196, label %BB_3cd0_80007080, label %BB_3cd0_7090

BB_3cd0_80007080:                                 ; preds = %BB_3cd0_7080
  %bra_cond_not.23 = xor i1 %fsetrp_cmp1.140, true
  br i1 %bra_cond_not.23, label %BB_3cd0_7560, label %BB_3cd0_7090

BB_3cd0_7090:                                     ; preds = %BB_3cd0_80007080, %BB_3cd0_7080
  %lop3_pred_cmp.163 = icmp ne i32 %fchk_anum.23, 0
  %lop3_a_cast_zext.93 = zext i1 %fsetrp_cmp1.141 to i32
  %lop3_b_cast_zext.93 = zext i1 %lop3_pred_cmp.163 to i32
  %plop3_a_bit.93 = and i32 %lop3_a_cast_zext.93, 1
  %plop3_b_bit.93 = and i32 %lop3_b_cast_zext.93, 1
  %.8061 = xor i32 %plop3_a_bit.93, 1
  %.8062 = xor i32 %plop3_b_bit.93, 1
  %.8064 = and i32 %.8061, %.8062
  %.8066 = and i32 %.8061, %plop3_b_bit.93
  %.8068 = or i32 %.8064, %.8066
  %.8069 = and i32 %plop3_a_bit.93, %.8062
  %.8071 = or i32 %.8068, %.8069
  %lop3_pred_cmp.164 = icmp ne i32 %.8071, 0
  br label %BB_3cd0_70b0

BB_3cd0_70b0:                                     ; preds = %BB_3cd0_7090
  %356 = zext i1 %lop3_pred_cmp.164 to i32
  %357 = icmp ne i32 %356, 0
  br i1 %357, label %BB_3cd0_7540, label %BB_3cd0_70c0

BB_3cd0_70c0:                                     ; preds = %BB_3cd0_70b0
  %lop3_pred_cmp.165 = icmp ne i32 %fchk_aden.23, 0
  %lop3_a_cast_zext.94 = zext i1 %fsetrp_cmp1.140 to i32
  %lop3_b_cast_zext.94 = zext i1 %lop3_pred_cmp.165 to i32
  %plop3_a_bit.94 = and i32 %lop3_a_cast_zext.94, 1
  %plop3_b_bit.94 = and i32 %lop3_b_cast_zext.94, 1
  %.8082 = xor i32 %plop3_a_bit.94, 1
  %.8083 = xor i32 %plop3_b_bit.94, 1
  %.8085 = and i32 %.8082, %.8083
  %.8087 = and i32 %.8082, %plop3_b_bit.94
  %.8089 = or i32 %.8085, %.8087
  %.8090 = and i32 %plop3_a_bit.94, %.8083
  %.8092 = or i32 %.8089, %.8090
  %lop3_pred_cmp.166 = icmp ne i32 %.8092, 0
  br label %BB_3cd0_70e0

BB_3cd0_70e0:                                     ; preds = %BB_3cd0_70c0
  %358 = zext i1 %lop3_pred_cmp.166 to i32
  %359 = icmp ne i32 %358, 0
  br i1 %359, label %BB_3cd0_7510, label %BB_3cd0_70f0

BB_3cd0_70f0:                                     ; preds = %BB_3cd0_70e0
  %isetrp_cmp1.310 = icmp sge i32 %iadd3_n1.238, 0
  %isetrp_cmp1.311 = icmp sge i32 %iadd3_n1.237, 0
  br label %BB_3cd0_7130

BB_3cd0_7130:                                     ; preds = %BB_3cd0_70f0
  %360 = zext i1 %isetrp_cmp1.310 to i32
  %361 = icmp ne i32 %360, 0
  br i1 %361, label %BB_3cd0_80007130, label %BB_3cd0_7140

BB_3cd0_80007130:                                 ; preds = %BB_3cd0_7130
  br label %BB_3cd0_7140

BB_3cd0_7140:                                     ; preds = %BB_3cd0_80007130, %BB_3cd0_7130
  %phi.376 = phi i32 [ 0, %BB_3cd0_80007130 ], [ %iadd3_n1.237, %BB_3cd0_7130 ]
  %cond_not.197 = xor i1 %isetrp_cmp1.310, true
  br i1 %cond_not.197, label %BB_3cd0_80007140, label %BB_3cd0_7160

BB_3cd0_80007140:                                 ; preds = %BB_3cd0_7140
  %ffma.406 = call float @llvm.fma.f32(float %ffma.400, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R166_bitcast = bitcast float %ffma.406 to i32
  br label %BB_3cd0_7160

BB_3cd0_7160:                                     ; preds = %BB_3cd0_80007140, %BB_3cd0_7140
  %phi.377 = phi i32 [ %phi_cast_R166_bitcast, %BB_3cd0_80007140 ], [ %fchk_num_bits.23, %BB_3cd0_7140 ]
  %phi.378 = phi i32 [ -64, %BB_3cd0_80007140 ], [ %phi.376, %BB_3cd0_7140 ]
  %cond_not.198 = xor i1 %isetrp_cmp1.311, true
  br i1 %cond_not.198, label %BB_3cd0_80007160, label %BB_3cd0_7180

BB_3cd0_80007160:                                 ; preds = %BB_3cd0_7160
  %ffma.407 = call float @llvm.fma.f32(float %lds.78, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.47 = add i32 %phi.378, 64
  %phi_cast_R738_bitcast = bitcast float %ffma.407 to i32
  br label %BB_3cd0_7180

BB_3cd0_7510:                                     ; preds = %BB_3cd0_70e0
  %.8105 = and i32 %.8037, -2147483648
  %.8106 = and i32 %.8105, %fchk_num_bits.23
  %.8107 = and i32 %fchk_den_bits.23, -2147483648
  %.8108 = and i32 %.8107, %.8039
  %.8109 = or i32 %.8106, %.8108
  %.8110 = xor i32 %.8109, -1
  %.8113 = and i32 %.8110, 2139095040
  %.8120 = or i32 %.8113, %.8109
  %phi_cast_R170_bitcast = bitcast i32 %.8120 to float
  br label %BB_3cd0_7590

BB_3cd0_7540:                                     ; preds = %BB_3cd0_70b0
  %.8134 = and i32 %.8037, -2147483648
  %.8135 = and i32 %.8134, %fchk_num_bits.23
  %.8136 = and i32 %fchk_den_bits.23, -2147483648
  %.8137 = and i32 %.8136, %.8039
  %.8138 = or i32 %.8135, %.8137
  %phi_cast_R171_bitcast = bitcast i32 %.8138 to float
  br label %BB_3cd0_7590

BB_3cd0_7560:                                     ; preds = %BB_3cd0_80007080, %BB_3cd0_7040
  %mufu_rsq.23 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_3cd0_7590

BB_3cd0_7580:                                     ; preds = %BB_3cd0_7020
  %fadd.46 = fadd float %ffma.400, %lds.78
  br label %BB_3cd0_7590

BB_3cd0_80006fd0:                                 ; preds = %BB_3cd0_6fd0
  br label %BB_3cd0_7180

BB_3cd0_7180:                                     ; preds = %BB_3cd0_80006fd0, %BB_3cd0_80007160, %BB_3cd0_7160
  %phi.379 = phi i32 [ %fchk_den_bits.23, %BB_3cd0_80006fd0 ], [ %phi_cast_R738_bitcast, %BB_3cd0_80007160 ], [ %fchk_den_bits.23, %BB_3cd0_7160 ]
  %phi.380 = phi i32 [ %fchk_num_bits.23, %BB_3cd0_80006fd0 ], [ %phi.377, %BB_3cd0_80007160 ], [ %phi.377, %BB_3cd0_7160 ]
  %phi.381 = phi i32 [ 0, %BB_3cd0_80006fd0 ], [ %viadd.47, %BB_3cd0_80007160 ], [ %phi.378, %BB_3cd0_7160 ]
  %.8143 = zext i32 %.8009 to i64
  %.8146 = shl i64 %.8143, 23
  %.8147 = and i64 %.8146, 4294967295
  %.8148 = add i64 %.8147, 3229614080
  %.8149 = trunc i64 %.8148 to i32
  %iadd3_n1.240 = add i32 %.8017, -127
  %iadd3_o1_not.46 = xor i32 %.8149, -1
  %iadd3_o1_neg.46 = add i32 %iadd3_o1_not.46, 1
  %iadd3_n1.241 = add i32 %iadd3_o1_neg.46, %phi.379
  %imad_tmp.89 = mul i32 %iadd3_n1.240, -8388608
  %imad.100 = add i32 %imad_tmp.89, %phi.380
  %mufu_src_bitcast.23 = bitcast i32 %iadd3_n1.241 to float
  %mufu_rcp.47 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.23)
  %fadd_lhs_fneg.23 = fneg float %mufu_src_bitcast.23
  %fadd.47 = fadd float %fadd_lhs_fneg.23, 0.000000e+00
  %iadd3_o3_not.23 = xor i32 %.8009, -1
  %iadd3_o3_neg.23 = add i32 %iadd3_o3_not.23, 1
  %iadd3_n2.242 = add i32 %.8017, %iadd3_o3_neg.23
  %iadd3_n1.243 = add i32 %iadd3_n2.242, %phi.381
  %ffma.408 = call float @llvm.fma.f32(float %mufu_rcp.47, float %fadd.47, float 1.000000e+00)
  %ffma.409 = call float @llvm.fma.f32(float %mufu_rcp.47, float %ffma.408, float %mufu_rcp.47)
  %ffma_lhs_bitcast.23 = bitcast i32 %imad.100 to float
  %ffma.410 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.23, float %ffma.409, float 0.000000e+00)
  %ffma.411 = call float @llvm.fma.f32(float %fadd.47, float %ffma.410, float %ffma_lhs_bitcast.23)
  %ffma.412 = call float @llvm.fma.f32(float %ffma.409, float %ffma.411, float %ffma.410)
  %ffma.413 = call float @llvm.fma.f32(float %fadd.47, float %ffma.412, float %ffma_lhs_bitcast.23)
  %ffma.414 = call float @llvm.fma.f32(float %ffma.409, float %ffma.413, float %ffma.412)
  %shf_hi_bitcast.71 = bitcast float %ffma.414 to i32
  %.8151 = zext i32 %shf_hi_bitcast.71 to i64
  %.8152 = shl i64 %.8151, 32
  %.8153 = lshr i64 %.8152, 23
  %shf_hi.122 = lshr i64 %.8153, 32
  %shf_result.146 = trunc i64 %shf_hi.122 to i32
  %.8157 = and i32 %shf_result.146, 255
  %imad.101 = add i32 %.8157, %iadd3_n1.243
  %iadd3_n1.244 = add i32 %imad.101, -1
  %isetrp_cmp1.312 = icmp uge i32 %iadd3_n1.244, 254
  br label %BB_3cd0_72d0

BB_3cd0_72d0:                                     ; preds = %BB_3cd0_7180
  %cond_not.199 = xor i1 %isetrp_cmp1.312, true
  br i1 %cond_not.199, label %BB_3cd0_74e0, label %BB_3cd0_72e0

BB_3cd0_72e0:                                     ; preds = %BB_3cd0_72d0
  %isetrp_cmp1.313 = icmp sgt i32 %imad.101, 254
  br label %BB_3cd0_72f0

BB_3cd0_72f0:                                     ; preds = %BB_3cd0_72e0
  %362 = zext i1 %isetrp_cmp1.313 to i32
  %363 = icmp ne i32 %362, 0
  br i1 %363, label %BB_3cd0_74b0, label %BB_3cd0_7300

BB_3cd0_7300:                                     ; preds = %BB_3cd0_72f0
  %isetrp_cmp1.314 = icmp sge i32 %imad.101, 1
  br label %BB_3cd0_7310

BB_3cd0_7310:                                     ; preds = %BB_3cd0_7300
  %phi_cast_R2237_bitcast.2 = bitcast i32 %iadd3_n1.243 to float
  br i1 %isetrp_cmp1.314, label %BB_3cd0_7590, label %BB_3cd0_7320

BB_3cd0_7320:                                     ; preds = %BB_3cd0_7310
  %isetrp_cmp1.315 = icmp sge i32 %imad.101, -24
  %.8171 = and i32 %shf_hi_bitcast.71, -2147483648
  br label %BB_3cd0_7340

BB_3cd0_7340:                                     ; preds = %BB_3cd0_7320
  %cond_not.200 = xor i1 %isetrp_cmp1.315, true
  %phi_cast_R179_bitcast = bitcast i32 %.8171 to float
  br i1 %cond_not.200, label %BB_3cd0_7590, label %BB_3cd0_7350

BB_3cd0_7350:                                     ; preds = %BB_3cd0_7340
  %ffma_rz.23 = call float @llvm.nvvm.fma.rz.f(float %ffma.409, float %ffma.413, float %ffma.412)
  %iadd3_n1.245 = add i32 %imad.101, 32
  %lop3_a_bitcast.190 = bitcast float %ffma_rz.23 to i32
  %.8181 = and i32 %lop3_a_bitcast.190, 8388607
  %ffma_rp.23 = call float @llvm.nvvm.fma.rp.f(float %ffma.409, float %ffma.413, float %ffma.412)
  %ffma_rm.23 = call float @llvm.nvvm.fma.rm.f(float %ffma.409, float %ffma.413, float %ffma.412)
  %isetrp_cmp1.317 = icmp ne i32 %imad.101, 0
  %.8196 = or i32 8388608, %.8181
  %iadd3_o1_not.47 = xor i32 %imad.101, -1
  %iadd3_o1_neg.47 = add i32 %iadd3_o1_not.47, 1
  %.8206 = zext i32 %.8196 to i64
  %shf_shift_64.147 = zext i32 %iadd3_n1.245 to i64
  %.8209 = shl i64 %.8206, %shf_shift_64.147
  %shf_result.147 = trunc i64 %.8209 to i32
  %fsetrp_cmp1.143 = fcmp une float %ffma_rp.23, %ffma_rm.23
  %isetrp_cmp1.318 = icmp ne i32 %shf_result.147, 0
  %isetrp_cmp2.318 = and i1 %isetrp_cmp1.318, %isetrp_cmp1.317
  %.8212 = shl i64 %.8206, 32
  %shf_shift_64.148 = zext i32 %iadd3_o1_neg.47 to i64
  %.8213 = lshr i64 %.8212, %shf_shift_64.148
  %shf_hi.123 = lshr i64 %.8213, 32
  %shf_result.148 = trunc i64 %shf_hi.123 to i32
  %lop3_a_cast_zext.95 = zext i1 %fsetrp_cmp1.143 to i32
  %lop3_b_cast_zext.95 = zext i1 %isetrp_cmp2.318 to i32
  %plop3_a_bit.95 = and i32 %lop3_a_cast_zext.95, 1
  %plop3_b_bit.95 = and i32 %lop3_b_cast_zext.95, 1
  %.8214 = xor i32 %plop3_a_bit.95, 1
  %.8215 = xor i32 %plop3_b_bit.95, 1
  %.8217 = and i32 %.8214, %plop3_b_bit.95
  %.8219 = and i32 %plop3_a_bit.95, %.8215
  %.8221 = or i32 %.8217, %.8219
  %.8222 = and i32 %plop3_a_bit.95, %plop3_b_bit.95
  %.8224 = or i32 %.8221, %.8222
  %lop3_pred_cmp.167 = icmp ne i32 %.8224, 0
  %.8226 = zext i32 %shf_result.148 to i64
  %.8227 = shl i64 %.8226, 32
  %.8228 = lshr i64 %.8227, 1
  %shf_hi.124 = lshr i64 %.8228, 32
  %shf_result.149 = trunc i64 %shf_hi.124 to i32
  %sel_pred_not.23 = xor i1 %lop3_pred_cmp.167, true
  %sel.47 = select i1 %sel_pred_not.23, i32 0, i32 1
  %.8229 = xor i32 %sel.47, -1
  %.8231 = xor i32 %shf_result.149, -1
  %.8232 = and i32 %.8229, 1
  %.8233 = and i32 %.8232, %shf_result.149
  %.8241 = and i32 %sel.47, %.8231
  %.8242 = or i32 %.8233, %.8241
  %.8244 = and i32 %sel.47, %shf_result.149
  %.8245 = or i32 %.8242, %.8244
  %.8249 = and i32 %.8245, %shf_result.148
  %imad.102 = add i32 %shf_result.149, %.8249
  %.8254 = xor i32 %imad.102, -1
  %.8255 = xor i32 %.8171, -1
  %.8257 = and i32 %.8254, %.8171
  %.8262 = and i32 %imad.102, %.8255
  %.8264 = or i32 %.8257, %.8262
  %.8268 = and i32 %imad.102, %.8171
  %.8270 = or i32 %.8264, %.8268
  %phi_cast_R181_bitcast = bitcast i32 %.8270 to float
  %phi_cast_R2240_bitcast = bitcast i32 %.8196 to float
  br label %BB_3cd0_7590

BB_3cd0_74b0:                                     ; preds = %BB_3cd0_72f0
  %.8278 = and i32 %shf_hi_bitcast.71, -2147483648
  %.8293 = or i32 2139095040, %.8278
  %phi_cast_R183_bitcast = bitcast i32 %.8293 to float
  %phi_cast_R2237_bitcast = bitcast i32 %iadd3_n1.243 to float
  br label %BB_3cd0_7590

BB_3cd0_74e0:                                     ; preds = %BB_3cd0_72d0
  %.8304 = zext i32 %iadd3_n1.243 to i64
  %.8307 = shl i64 %.8304, 23
  %.8308 = and i64 %.8307, 4294967295
  %.8309 = add i64 %.8308, %.8151
  %.8310 = trunc i64 %.8309 to i32
  %phi_cast_R184_bitcast = bitcast i32 %.8310 to float
  %phi_cast_R2237_bitcast.1 = bitcast i32 %iadd3_n1.243 to float
  br label %BB_3cd0_7590

BB_3cd0_7590:                                     ; preds = %BB_3cd0_74e0, %BB_3cd0_74b0, %BB_3cd0_7350, %BB_3cd0_7340, %BB_3cd0_7310, %BB_3cd0_7580, %BB_3cd0_7560, %BB_3cd0_7540, %BB_3cd0_7510
  %phi.382 = phi float [ %phi_cast_R181_bitcast, %BB_3cd0_7350 ], [ %phi_cast_R183_bitcast, %BB_3cd0_74b0 ], [ %phi_cast_R184_bitcast, %BB_3cd0_74e0 ], [ %ffma.414, %BB_3cd0_7310 ], [ %phi_cast_R179_bitcast, %BB_3cd0_7340 ], [ %phi_cast_R170_bitcast, %BB_3cd0_7510 ], [ %phi_cast_R171_bitcast, %BB_3cd0_7540 ], [ %mufu_rsq.23, %BB_3cd0_7560 ], [ %fadd.46, %BB_3cd0_7580 ]
  %phi.383 = phi float [ %phi_cast_R2240_bitcast, %BB_3cd0_7350 ], [ %phi_cast_R2237_bitcast, %BB_3cd0_74b0 ], [ %phi_cast_R2237_bitcast.1, %BB_3cd0_74e0 ], [ %phi_cast_R2237_bitcast.2, %BB_3cd0_7310 ], [ %phi_cast_R2237_bitcast.2, %BB_3cd0_7340 ], [ %phi.372, %BB_3cd0_7510 ], [ %phi.372, %BB_3cd0_7540 ], [ %phi.372, %BB_3cd0_7560 ], [ %phi.372, %BB_3cd0_7580 ]
  br label %BB_3cf0

BB_3cf0:                                          ; preds = %BB_3cd0_7590, %BB_3ca0
  %phi.384 = phi float [ %phi.382, %BB_3cd0_7590 ], [ %ffma.405, %BB_3ca0 ]
  %phi.385 = phi float [ %phi.383, %BB_3cd0_7590 ], [ %phi.372, %BB_3ca0 ]
  br label %BB_3d10

BB_3d10:                                          ; preds = %BB_3cf0, %BB_3bb0
  %phi.386 = phi float [ %phi.384, %BB_3cf0 ], [ %phi.371, %BB_3bb0 ]
  %phi.387 = phi float [ %phi.385, %BB_3cf0 ], [ %phi.372, %BB_3bb0 ]
  %phi.388 = phi i32 [ %.75, %BB_3cf0 ], [ %phi.373, %BB_3bb0 ]
  %phi.389 = phi float [ %phi.384, %BB_3cf0 ], [ %phi.374, %BB_3bb0 ]
  br label %BB_3d40

BB_3d40:                                          ; preds = %BB_3d10
  %shfl_activemask.55 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.55 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.55, float %phi.389, i32 23, i32 31)
  br label %BB_3d50

BB_3d50:                                          ; preds = %BB_3d40
  %isetrp_cmp1.319 = icmp uge i32 %tid_x, 24
  %isetrp_cmp1.320 = icmp ne i32 %tid_x, 24
  br label %BB_3d80

BB_3d80:                                          ; preds = %BB_3d50
  %364 = zext i1 %isetrp_cmp1.319 to i32
  %365 = icmp ne i32 %364, 0
  br i1 %365, label %BB_80003d80, label %BB_3da0

BB_80003d80:                                      ; preds = %BB_3d80
  %lds_addr_memaddr_offset_add.76 = add i32 %.88, 3036
  %.8318 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.76
  %lds.79 = load volatile float, ptr addrspace(3) %.8318, align 4
  %ffma.415 = call float @llvm.fma.f32(float %shfl_idx.55, float %lds.79, float %phi.375)
  br label %BB_3da0

BB_3da0:                                          ; preds = %BB_80003d80, %BB_3d80
  %phi.390 = phi float [ %ffma.415, %BB_80003d80 ], [ %phi.375, %BB_3d80 ]
  %warp_reconv_mask.23 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.23)
  br i1 %isetrp_cmp1.320, label %BB_3f00, label %BB_3db0

BB_3db0:                                          ; preds = %BB_3da0
  %ffma_addend_fneg.24 = fneg float %phi.390
  %ffma.416 = call float @llvm.fma.f32(float %phi.386, float %phi, float %ffma_addend_fneg.24)
  %lds_addr_memaddr_offset_add.77 = add i32 %.75, 3264
  %.8328 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.77
  %lds.80 = load volatile float, ptr addrspace(3) %.8328, align 4
  %mufu_rcp.48 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.80)
  %fchk_num_bits.24 = bitcast float %ffma.416 to i32
  %fchk_den_bits.24 = bitcast float %lds.80 to i32
  %fchk_aden.24 = and i32 %fchk_den_bits.24, 2147483647
  %fchk_anum.24 = and i32 %fchk_num_bits.24, 2147483647
  %fchk_den_subz.24 = icmp ult i32 %fchk_aden.24, 8388608
  %fchk_den_infnan.24 = icmp uge i32 %fchk_aden.24, 2139095040
  %fchk_num_infnan.24 = icmp uge i32 %fchk_anum.24, 2139095040
  %fchk_den_bad.24 = or i1 %fchk_den_subz.24, %fchk_den_infnan.24
  %fchk_px.24 = or i1 %fchk_den_bad.24, %fchk_num_infnan.24
  %ffma_lhs_fneg.48 = fneg float %lds.80
  %ffma.417 = call float @llvm.fma.f32(float %ffma_lhs_fneg.48, float %mufu_rcp.48, float 1.000000e+00)
  %ffma.418 = call float @llvm.fma.f32(float %mufu_rcp.48, float %ffma.417, float %mufu_rcp.48)
  %ffma.419 = call float @llvm.fma.f32(float %ffma.416, float %ffma.418, float 0.000000e+00)
  %ffma.420 = call float @llvm.fma.f32(float %ffma_lhs_fneg.48, float %ffma.419, float %ffma.416)
  %ffma.421 = call float @llvm.fma.f32(float %ffma.418, float %ffma.420, float %ffma.419)
  br label %BB_3e90

BB_3e90:                                          ; preds = %BB_3db0
  %cond_not.201 = xor i1 %fchk_px.24, true
  br i1 %cond_not.201, label %BB_3ee0, label %BB_3ec0_6f40

BB_3ec0_6f40:                                     ; preds = %BB_3e90
  %.8332 = zext i32 %fchk_den_bits.24 to i64
  %.8333 = shl i64 %.8332, 32
  %.8334 = lshr i64 %.8333, 23
  %shf_hi.125 = lshr i64 %.8334, 32
  %shf_result.150 = trunc i64 %shf_hi.125 to i32
  %.8336 = zext i32 %fchk_num_bits.24 to i64
  %.8337 = shl i64 %.8336, 32
  %.8338 = lshr i64 %.8337, 23
  %shf_hi.126 = lshr i64 %.8338, 32
  %shf_result.151 = trunc i64 %shf_hi.126 to i32
  %.8342 = and i32 %shf_result.150, 255
  %.8350 = and i32 %shf_result.151, 255
  %iadd3_n1.247 = add i32 %.8342, -1
  %iadd3_n1.248 = add i32 %.8350, -1
  %isetrp_cmp1.321 = icmp ugt i32 %iadd3_n1.247, 253
  %isetrp_cmp1.322 = icmp ugt i32 %iadd3_n1.248, 253
  %isetrp_cmp2.322 = or i1 %isetrp_cmp1.322, %isetrp_cmp1.321
  br label %BB_3ec0_6fd0

BB_3ec0_6fd0:                                     ; preds = %BB_3ec0_6f40
  %cond_not.202 = xor i1 %isetrp_cmp2.322, true
  br i1 %cond_not.202, label %BB_3ec0_80006fd0, label %BB_3ec0_6ff0

BB_3ec0_6ff0:                                     ; preds = %BB_3ec0_6fd0
  %fsetrp_lhs_fabs.120 = call float @llvm.nvvm.fabs.f(float %ffma.416)
  %fsetrp_cmp1.144 = fcmp ugt float %fsetrp_lhs_fabs.120, 0x7FF0000000000000
  %fsetrp_lhs_fabs.121 = call float @llvm.nvvm.fabs.f(float %lds.80)
  %fsetrp_cmp1.145 = fcmp ugt float %fsetrp_lhs_fabs.121, 0x7FF0000000000000
  %lop3_a_cast_zext.96 = zext i1 %fsetrp_cmp1.144 to i32
  %lop3_b_cast_zext.96 = zext i1 %fsetrp_cmp1.145 to i32
  %plop3_a_bit.96 = and i32 %lop3_a_cast_zext.96, 1
  %plop3_b_bit.96 = and i32 %lop3_b_cast_zext.96, 1
  %.8357 = xor i32 %plop3_a_bit.96, 1
  %.8358 = xor i32 %plop3_b_bit.96, 1
  %.8360 = and i32 %.8357, %plop3_b_bit.96
  %.8362 = and i32 %plop3_a_bit.96, %.8358
  %.8364 = or i32 %.8360, %.8362
  %.8365 = and i32 %plop3_a_bit.96, %plop3_b_bit.96
  %.8367 = or i32 %.8364, %.8365
  %lop3_pred_cmp.168 = icmp ne i32 %.8367, 0
  br label %BB_3ec0_7020

BB_3ec0_7020:                                     ; preds = %BB_3ec0_6ff0
  %366 = zext i1 %lop3_pred_cmp.168 to i32
  %367 = icmp ne i32 %366, 0
  br i1 %367, label %BB_3ec0_7580, label %BB_3ec0_7030

BB_3ec0_7030:                                     ; preds = %BB_3ec0_7020
  %.8370 = xor i32 %fchk_den_bits.24, -1
  %.8372 = xor i32 %fchk_num_bits.24, -1
  %.8373 = and i32 %.8370, 2147483647
  %.8374 = and i32 %.8373, %fchk_num_bits.24
  %.8376 = and i32 %fchk_aden.24, %.8372
  %.8377 = or i32 %.8374, %.8376
  %.8379 = and i32 %fchk_aden.24, %fchk_num_bits.24
  %.8380 = or i32 %.8377, %.8379
  %lop3_pred_cmp.169 = icmp ne i32 %.8380, 0
  br label %BB_3ec0_7040

BB_3ec0_7040:                                     ; preds = %BB_3ec0_7030
  %cond_not.203 = xor i1 %lop3_pred_cmp.169, true
  br i1 %cond_not.203, label %BB_3ec0_7560, label %BB_3ec0_7050

BB_3ec0_7050:                                     ; preds = %BB_3ec0_7040
  %fsetrp_cmp1.146 = fcmp une float %fsetrp_lhs_fabs.120, 0x7FF0000000000000
  %fsetrp_cmp1.147 = fcmp une float %fsetrp_lhs_fabs.121, 0x7FF0000000000000
  br label %BB_3ec0_7080

BB_3ec0_7080:                                     ; preds = %BB_3ec0_7050
  %cond_not.204 = xor i1 %fsetrp_cmp1.147, true
  br i1 %cond_not.204, label %BB_3ec0_80007080, label %BB_3ec0_7090

BB_3ec0_80007080:                                 ; preds = %BB_3ec0_7080
  %bra_cond_not.24 = xor i1 %fsetrp_cmp1.146, true
  br i1 %bra_cond_not.24, label %BB_3ec0_7560, label %BB_3ec0_7090

BB_3ec0_7090:                                     ; preds = %BB_3ec0_80007080, %BB_3ec0_7080
  %lop3_pred_cmp.170 = icmp ne i32 %fchk_anum.24, 0
  %lop3_a_cast_zext.97 = zext i1 %fsetrp_cmp1.147 to i32
  %lop3_b_cast_zext.97 = zext i1 %lop3_pred_cmp.170 to i32
  %plop3_a_bit.97 = and i32 %lop3_a_cast_zext.97, 1
  %plop3_b_bit.97 = and i32 %lop3_b_cast_zext.97, 1
  %.8394 = xor i32 %plop3_a_bit.97, 1
  %.8395 = xor i32 %plop3_b_bit.97, 1
  %.8397 = and i32 %.8394, %.8395
  %.8399 = and i32 %.8394, %plop3_b_bit.97
  %.8401 = or i32 %.8397, %.8399
  %.8402 = and i32 %plop3_a_bit.97, %.8395
  %.8404 = or i32 %.8401, %.8402
  %lop3_pred_cmp.171 = icmp ne i32 %.8404, 0
  br label %BB_3ec0_70b0

BB_3ec0_70b0:                                     ; preds = %BB_3ec0_7090
  %368 = zext i1 %lop3_pred_cmp.171 to i32
  %369 = icmp ne i32 %368, 0
  br i1 %369, label %BB_3ec0_7540, label %BB_3ec0_70c0

BB_3ec0_70c0:                                     ; preds = %BB_3ec0_70b0
  %lop3_pred_cmp.172 = icmp ne i32 %fchk_aden.24, 0
  %lop3_a_cast_zext.98 = zext i1 %fsetrp_cmp1.146 to i32
  %lop3_b_cast_zext.98 = zext i1 %lop3_pred_cmp.172 to i32
  %plop3_a_bit.98 = and i32 %lop3_a_cast_zext.98, 1
  %plop3_b_bit.98 = and i32 %lop3_b_cast_zext.98, 1
  %.8415 = xor i32 %plop3_a_bit.98, 1
  %.8416 = xor i32 %plop3_b_bit.98, 1
  %.8418 = and i32 %.8415, %.8416
  %.8420 = and i32 %.8415, %plop3_b_bit.98
  %.8422 = or i32 %.8418, %.8420
  %.8423 = and i32 %plop3_a_bit.98, %.8416
  %.8425 = or i32 %.8422, %.8423
  %lop3_pred_cmp.173 = icmp ne i32 %.8425, 0
  br label %BB_3ec0_70e0

BB_3ec0_70e0:                                     ; preds = %BB_3ec0_70c0
  %370 = zext i1 %lop3_pred_cmp.173 to i32
  %371 = icmp ne i32 %370, 0
  br i1 %371, label %BB_3ec0_7510, label %BB_3ec0_70f0

BB_3ec0_70f0:                                     ; preds = %BB_3ec0_70e0
  %isetrp_cmp1.323 = icmp sge i32 %iadd3_n1.248, 0
  %isetrp_cmp1.324 = icmp sge i32 %iadd3_n1.247, 0
  br label %BB_3ec0_7130

BB_3ec0_7130:                                     ; preds = %BB_3ec0_70f0
  %372 = zext i1 %isetrp_cmp1.323 to i32
  %373 = icmp ne i32 %372, 0
  br i1 %373, label %BB_3ec0_80007130, label %BB_3ec0_7140

BB_3ec0_80007130:                                 ; preds = %BB_3ec0_7130
  br label %BB_3ec0_7140

BB_3ec0_7140:                                     ; preds = %BB_3ec0_80007130, %BB_3ec0_7130
  %phi.391 = phi i32 [ 0, %BB_3ec0_80007130 ], [ %iadd3_n1.247, %BB_3ec0_7130 ]
  %cond_not.205 = xor i1 %isetrp_cmp1.323, true
  br i1 %cond_not.205, label %BB_3ec0_80007140, label %BB_3ec0_7160

BB_3ec0_80007140:                                 ; preds = %BB_3ec0_7140
  %ffma.422 = call float @llvm.fma.f32(float %ffma.416, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R188_bitcast = bitcast float %ffma.422 to i32
  br label %BB_3ec0_7160

BB_3ec0_7160:                                     ; preds = %BB_3ec0_80007140, %BB_3ec0_7140
  %phi.392 = phi i32 [ %phi_cast_R188_bitcast, %BB_3ec0_80007140 ], [ %fchk_num_bits.24, %BB_3ec0_7140 ]
  %phi.393 = phi i32 [ -64, %BB_3ec0_80007140 ], [ %phi.391, %BB_3ec0_7140 ]
  %cond_not.206 = xor i1 %isetrp_cmp1.324, true
  br i1 %cond_not.206, label %BB_3ec0_80007160, label %BB_3ec0_7180

BB_3ec0_80007160:                                 ; preds = %BB_3ec0_7160
  %ffma.423 = call float @llvm.fma.f32(float %lds.80, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.49 = add i32 %phi.393, 64
  %phi_cast_R758_bitcast = bitcast float %ffma.423 to i32
  br label %BB_3ec0_7180

BB_3ec0_7510:                                     ; preds = %BB_3ec0_70e0
  %.8438 = and i32 %.8370, -2147483648
  %.8439 = and i32 %.8438, %fchk_num_bits.24
  %.8440 = and i32 %fchk_den_bits.24, -2147483648
  %.8441 = and i32 %.8440, %.8372
  %.8442 = or i32 %.8439, %.8441
  %.8443 = xor i32 %.8442, -1
  %.8446 = and i32 %.8443, 2139095040
  %.8453 = or i32 %.8446, %.8442
  %phi_cast_R192_bitcast = bitcast i32 %.8453 to float
  br label %BB_3ec0_7590

BB_3ec0_7540:                                     ; preds = %BB_3ec0_70b0
  %.8467 = and i32 %.8370, -2147483648
  %.8468 = and i32 %.8467, %fchk_num_bits.24
  %.8469 = and i32 %fchk_den_bits.24, -2147483648
  %.8470 = and i32 %.8469, %.8372
  %.8471 = or i32 %.8468, %.8470
  %phi_cast_R193_bitcast = bitcast i32 %.8471 to float
  br label %BB_3ec0_7590

BB_3ec0_7560:                                     ; preds = %BB_3ec0_80007080, %BB_3ec0_7040
  %mufu_rsq.24 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_3ec0_7590

BB_3ec0_7580:                                     ; preds = %BB_3ec0_7020
  %fadd.48 = fadd float %ffma.416, %lds.80
  br label %BB_3ec0_7590

BB_3ec0_80006fd0:                                 ; preds = %BB_3ec0_6fd0
  br label %BB_3ec0_7180

BB_3ec0_7180:                                     ; preds = %BB_3ec0_80006fd0, %BB_3ec0_80007160, %BB_3ec0_7160
  %phi.394 = phi i32 [ %fchk_den_bits.24, %BB_3ec0_80006fd0 ], [ %phi_cast_R758_bitcast, %BB_3ec0_80007160 ], [ %fchk_den_bits.24, %BB_3ec0_7160 ]
  %phi.395 = phi i32 [ %fchk_num_bits.24, %BB_3ec0_80006fd0 ], [ %phi.392, %BB_3ec0_80007160 ], [ %phi.392, %BB_3ec0_7160 ]
  %phi.396 = phi i32 [ 0, %BB_3ec0_80006fd0 ], [ %viadd.49, %BB_3ec0_80007160 ], [ %phi.393, %BB_3ec0_7160 ]
  %.8476 = zext i32 %.8342 to i64
  %.8479 = shl i64 %.8476, 23
  %.8480 = and i64 %.8479, 4294967295
  %.8481 = add i64 %.8480, 3229614080
  %.8482 = trunc i64 %.8481 to i32
  %iadd3_n1.250 = add i32 %.8350, -127
  %iadd3_o1_not.48 = xor i32 %.8482, -1
  %iadd3_o1_neg.48 = add i32 %iadd3_o1_not.48, 1
  %iadd3_n1.251 = add i32 %iadd3_o1_neg.48, %phi.394
  %imad_tmp.92 = mul i32 %iadd3_n1.250, -8388608
  %imad.103 = add i32 %imad_tmp.92, %phi.395
  %mufu_src_bitcast.24 = bitcast i32 %iadd3_n1.251 to float
  %mufu_rcp.49 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.24)
  %fadd_lhs_fneg.24 = fneg float %mufu_src_bitcast.24
  %fadd.49 = fadd float %fadd_lhs_fneg.24, 0.000000e+00
  %iadd3_o3_not.24 = xor i32 %.8342, -1
  %iadd3_o3_neg.24 = add i32 %iadd3_o3_not.24, 1
  %iadd3_n2.252 = add i32 %.8350, %iadd3_o3_neg.24
  %iadd3_n1.253 = add i32 %iadd3_n2.252, %phi.396
  %ffma.424 = call float @llvm.fma.f32(float %mufu_rcp.49, float %fadd.49, float 1.000000e+00)
  %ffma.425 = call float @llvm.fma.f32(float %mufu_rcp.49, float %ffma.424, float %mufu_rcp.49)
  %ffma_lhs_bitcast.24 = bitcast i32 %imad.103 to float
  %ffma.426 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.24, float %ffma.425, float 0.000000e+00)
  %ffma.427 = call float @llvm.fma.f32(float %fadd.49, float %ffma.426, float %ffma_lhs_bitcast.24)
  %ffma.428 = call float @llvm.fma.f32(float %ffma.425, float %ffma.427, float %ffma.426)
  %ffma.429 = call float @llvm.fma.f32(float %fadd.49, float %ffma.428, float %ffma_lhs_bitcast.24)
  %ffma.430 = call float @llvm.fma.f32(float %ffma.425, float %ffma.429, float %ffma.428)
  %shf_hi_bitcast.74 = bitcast float %ffma.430 to i32
  %.8484 = zext i32 %shf_hi_bitcast.74 to i64
  %.8485 = shl i64 %.8484, 32
  %.8486 = lshr i64 %.8485, 23
  %shf_hi.127 = lshr i64 %.8486, 32
  %shf_result.152 = trunc i64 %shf_hi.127 to i32
  %.8490 = and i32 %shf_result.152, 255
  %imad.104 = add i32 %.8490, %iadd3_n1.253
  %iadd3_n1.254 = add i32 %imad.104, -1
  %isetrp_cmp1.325 = icmp uge i32 %iadd3_n1.254, 254
  br label %BB_3ec0_72d0

BB_3ec0_72d0:                                     ; preds = %BB_3ec0_7180
  %cond_not.207 = xor i1 %isetrp_cmp1.325, true
  br i1 %cond_not.207, label %BB_3ec0_74e0, label %BB_3ec0_72e0

BB_3ec0_72e0:                                     ; preds = %BB_3ec0_72d0
  %isetrp_cmp1.326 = icmp sgt i32 %imad.104, 254
  br label %BB_3ec0_72f0

BB_3ec0_72f0:                                     ; preds = %BB_3ec0_72e0
  %374 = zext i1 %isetrp_cmp1.326 to i32
  %375 = icmp ne i32 %374, 0
  br i1 %375, label %BB_3ec0_74b0, label %BB_3ec0_7300

BB_3ec0_7300:                                     ; preds = %BB_3ec0_72f0
  %isetrp_cmp1.327 = icmp sge i32 %imad.104, 1
  br label %BB_3ec0_7310

BB_3ec0_7310:                                     ; preds = %BB_3ec0_7300
  %phi_cast_R2248_bitcast.2 = bitcast i32 %iadd3_n1.253 to float
  br i1 %isetrp_cmp1.327, label %BB_3ec0_7590, label %BB_3ec0_7320

BB_3ec0_7320:                                     ; preds = %BB_3ec0_7310
  %isetrp_cmp1.328 = icmp sge i32 %imad.104, -24
  %.8504 = and i32 %shf_hi_bitcast.74, -2147483648
  br label %BB_3ec0_7340

BB_3ec0_7340:                                     ; preds = %BB_3ec0_7320
  %cond_not.208 = xor i1 %isetrp_cmp1.328, true
  %phi_cast_R201_bitcast = bitcast i32 %.8504 to float
  br i1 %cond_not.208, label %BB_3ec0_7590, label %BB_3ec0_7350

BB_3ec0_7350:                                     ; preds = %BB_3ec0_7340
  %ffma_rz.24 = call float @llvm.nvvm.fma.rz.f(float %ffma.425, float %ffma.429, float %ffma.428)
  %iadd3_n1.255 = add i32 %imad.104, 32
  %lop3_a_bitcast.198 = bitcast float %ffma_rz.24 to i32
  %.8514 = and i32 %lop3_a_bitcast.198, 8388607
  %ffma_rp.24 = call float @llvm.nvvm.fma.rp.f(float %ffma.425, float %ffma.429, float %ffma.428)
  %ffma_rm.24 = call float @llvm.nvvm.fma.rm.f(float %ffma.425, float %ffma.429, float %ffma.428)
  %isetrp_cmp1.330 = icmp ne i32 %imad.104, 0
  %.8529 = or i32 8388608, %.8514
  %iadd3_o1_not.49 = xor i32 %imad.104, -1
  %iadd3_o1_neg.49 = add i32 %iadd3_o1_not.49, 1
  %.8539 = zext i32 %.8529 to i64
  %shf_shift_64.153 = zext i32 %iadd3_n1.255 to i64
  %.8542 = shl i64 %.8539, %shf_shift_64.153
  %shf_result.153 = trunc i64 %.8542 to i32
  %fsetrp_cmp1.149 = fcmp une float %ffma_rp.24, %ffma_rm.24
  %isetrp_cmp1.331 = icmp ne i32 %shf_result.153, 0
  %isetrp_cmp2.331 = and i1 %isetrp_cmp1.331, %isetrp_cmp1.330
  %.8545 = shl i64 %.8539, 32
  %shf_shift_64.154 = zext i32 %iadd3_o1_neg.49 to i64
  %.8546 = lshr i64 %.8545, %shf_shift_64.154
  %shf_hi.128 = lshr i64 %.8546, 32
  %shf_result.154 = trunc i64 %shf_hi.128 to i32
  %lop3_a_cast_zext.99 = zext i1 %fsetrp_cmp1.149 to i32
  %lop3_b_cast_zext.99 = zext i1 %isetrp_cmp2.331 to i32
  %plop3_a_bit.99 = and i32 %lop3_a_cast_zext.99, 1
  %plop3_b_bit.99 = and i32 %lop3_b_cast_zext.99, 1
  %.8547 = xor i32 %plop3_a_bit.99, 1
  %.8548 = xor i32 %plop3_b_bit.99, 1
  %.8550 = and i32 %.8547, %plop3_b_bit.99
  %.8552 = and i32 %plop3_a_bit.99, %.8548
  %.8554 = or i32 %.8550, %.8552
  %.8555 = and i32 %plop3_a_bit.99, %plop3_b_bit.99
  %.8557 = or i32 %.8554, %.8555
  %lop3_pred_cmp.174 = icmp ne i32 %.8557, 0
  %.8559 = zext i32 %shf_result.154 to i64
  %.8560 = shl i64 %.8559, 32
  %.8561 = lshr i64 %.8560, 1
  %shf_hi.129 = lshr i64 %.8561, 32
  %shf_result.155 = trunc i64 %shf_hi.129 to i32
  %sel_pred_not.24 = xor i1 %lop3_pred_cmp.174, true
  %sel.49 = select i1 %sel_pred_not.24, i32 0, i32 1
  %.8562 = xor i32 %sel.49, -1
  %.8564 = xor i32 %shf_result.155, -1
  %.8565 = and i32 %.8562, 1
  %.8566 = and i32 %.8565, %shf_result.155
  %.8574 = and i32 %sel.49, %.8564
  %.8575 = or i32 %.8566, %.8574
  %.8577 = and i32 %sel.49, %shf_result.155
  %.8578 = or i32 %.8575, %.8577
  %.8582 = and i32 %.8578, %shf_result.154
  %imad.105 = add i32 %shf_result.155, %.8582
  %.8587 = xor i32 %imad.105, -1
  %.8588 = xor i32 %.8504, -1
  %.8590 = and i32 %.8587, %.8504
  %.8595 = and i32 %imad.105, %.8588
  %.8597 = or i32 %.8590, %.8595
  %.8601 = and i32 %imad.105, %.8504
  %.8603 = or i32 %.8597, %.8601
  %phi_cast_R203_bitcast = bitcast i32 %.8603 to float
  %phi_cast_R2251_bitcast = bitcast i32 %.8529 to float
  br label %BB_3ec0_7590

BB_3ec0_74b0:                                     ; preds = %BB_3ec0_72f0
  %.8611 = and i32 %shf_hi_bitcast.74, -2147483648
  %.8626 = or i32 2139095040, %.8611
  %phi_cast_R205_bitcast = bitcast i32 %.8626 to float
  %phi_cast_R2248_bitcast = bitcast i32 %iadd3_n1.253 to float
  br label %BB_3ec0_7590

BB_3ec0_74e0:                                     ; preds = %BB_3ec0_72d0
  %.8637 = zext i32 %iadd3_n1.253 to i64
  %.8640 = shl i64 %.8637, 23
  %.8641 = and i64 %.8640, 4294967295
  %.8642 = add i64 %.8641, %.8484
  %.8643 = trunc i64 %.8642 to i32
  %phi_cast_R206_bitcast = bitcast i32 %.8643 to float
  %phi_cast_R2248_bitcast.1 = bitcast i32 %iadd3_n1.253 to float
  br label %BB_3ec0_7590

BB_3ec0_7590:                                     ; preds = %BB_3ec0_74e0, %BB_3ec0_74b0, %BB_3ec0_7350, %BB_3ec0_7340, %BB_3ec0_7310, %BB_3ec0_7580, %BB_3ec0_7560, %BB_3ec0_7540, %BB_3ec0_7510
  %phi.397 = phi float [ %phi_cast_R203_bitcast, %BB_3ec0_7350 ], [ %phi_cast_R205_bitcast, %BB_3ec0_74b0 ], [ %phi_cast_R206_bitcast, %BB_3ec0_74e0 ], [ %ffma.430, %BB_3ec0_7310 ], [ %phi_cast_R201_bitcast, %BB_3ec0_7340 ], [ %phi_cast_R192_bitcast, %BB_3ec0_7510 ], [ %phi_cast_R193_bitcast, %BB_3ec0_7540 ], [ %mufu_rsq.24, %BB_3ec0_7560 ], [ %fadd.48, %BB_3ec0_7580 ]
  %phi.398 = phi float [ %phi_cast_R2251_bitcast, %BB_3ec0_7350 ], [ %phi_cast_R2248_bitcast, %BB_3ec0_74b0 ], [ %phi_cast_R2248_bitcast.1, %BB_3ec0_74e0 ], [ %phi_cast_R2248_bitcast.2, %BB_3ec0_7310 ], [ %phi_cast_R2248_bitcast.2, %BB_3ec0_7340 ], [ %phi.387, %BB_3ec0_7510 ], [ %phi.387, %BB_3ec0_7540 ], [ %phi.387, %BB_3ec0_7560 ], [ %phi.387, %BB_3ec0_7580 ]
  br label %BB_3ee0

BB_3ee0:                                          ; preds = %BB_3ec0_7590, %BB_3e90
  %phi.399 = phi float [ %phi.397, %BB_3ec0_7590 ], [ %ffma.421, %BB_3e90 ]
  %phi.400 = phi float [ %phi.398, %BB_3ec0_7590 ], [ %phi.387, %BB_3e90 ]
  br label %BB_3f00

BB_3f00:                                          ; preds = %BB_3ee0, %BB_3da0
  %phi.401 = phi float [ %phi.399, %BB_3ee0 ], [ %phi.386, %BB_3da0 ]
  %phi.402 = phi float [ %phi.400, %BB_3ee0 ], [ %phi.387, %BB_3da0 ]
  %phi.403 = phi i32 [ %.75, %BB_3ee0 ], [ %phi.388, %BB_3da0 ]
  %phi.404 = phi float [ %phi.399, %BB_3ee0 ], [ %phi.389, %BB_3da0 ]
  br label %BB_3f30

BB_3f30:                                          ; preds = %BB_3f00
  %shfl_activemask.56 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.56 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.56, float %phi.404, i32 24, i32 31)
  br label %BB_3f40

BB_3f40:                                          ; preds = %BB_3f30
  %isetrp_cmp1.332 = icmp uge i32 %tid_x, 25
  %isetrp_cmp1.333 = icmp ne i32 %tid_x, 25
  br label %BB_3f70

BB_3f70:                                          ; preds = %BB_3f40
  %376 = zext i1 %isetrp_cmp1.332 to i32
  %377 = icmp ne i32 %376, 0
  br i1 %377, label %BB_80003f70, label %BB_3f90

BB_80003f70:                                      ; preds = %BB_3f70
  %lds_addr_memaddr_offset_add.78 = add i32 %.88, 3168
  %.8651 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.78
  %lds.81 = load volatile float, ptr addrspace(3) %.8651, align 4
  %ffma.431 = call float @llvm.fma.f32(float %shfl_idx.56, float %lds.81, float %phi.390)
  br label %BB_3f90

BB_3f90:                                          ; preds = %BB_80003f70, %BB_3f70
  %phi.405 = phi float [ %ffma.431, %BB_80003f70 ], [ %phi.390, %BB_3f70 ]
  %warp_reconv_mask.24 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.24)
  br i1 %isetrp_cmp1.333, label %BB_40f0, label %BB_3fa0

BB_3fa0:                                          ; preds = %BB_3f90
  %ffma_addend_fneg.25 = fneg float %phi.405
  %ffma.432 = call float @llvm.fma.f32(float %phi.401, float %phi, float %ffma_addend_fneg.25)
  %lds_addr_memaddr_offset_add.79 = add i32 %.75, 3400
  %.8661 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.79
  %lds.82 = load volatile float, ptr addrspace(3) %.8661, align 4
  %mufu_rcp.50 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.82)
  %fchk_num_bits.25 = bitcast float %ffma.432 to i32
  %fchk_den_bits.25 = bitcast float %lds.82 to i32
  %fchk_aden.25 = and i32 %fchk_den_bits.25, 2147483647
  %fchk_anum.25 = and i32 %fchk_num_bits.25, 2147483647
  %fchk_den_subz.25 = icmp ult i32 %fchk_aden.25, 8388608
  %fchk_den_infnan.25 = icmp uge i32 %fchk_aden.25, 2139095040
  %fchk_num_infnan.25 = icmp uge i32 %fchk_anum.25, 2139095040
  %fchk_den_bad.25 = or i1 %fchk_den_subz.25, %fchk_den_infnan.25
  %fchk_px.25 = or i1 %fchk_den_bad.25, %fchk_num_infnan.25
  %ffma_lhs_fneg.50 = fneg float %lds.82
  %ffma.433 = call float @llvm.fma.f32(float %ffma_lhs_fneg.50, float %mufu_rcp.50, float 1.000000e+00)
  %ffma.434 = call float @llvm.fma.f32(float %mufu_rcp.50, float %ffma.433, float %mufu_rcp.50)
  %ffma.435 = call float @llvm.fma.f32(float %ffma.432, float %ffma.434, float 0.000000e+00)
  %ffma.436 = call float @llvm.fma.f32(float %ffma_lhs_fneg.50, float %ffma.435, float %ffma.432)
  %ffma.437 = call float @llvm.fma.f32(float %ffma.434, float %ffma.436, float %ffma.435)
  br label %BB_4080

BB_4080:                                          ; preds = %BB_3fa0
  %cond_not.209 = xor i1 %fchk_px.25, true
  br i1 %cond_not.209, label %BB_40d0, label %BB_40b0_6f40

BB_40b0_6f40:                                     ; preds = %BB_4080
  %.8665 = zext i32 %fchk_den_bits.25 to i64
  %.8666 = shl i64 %.8665, 32
  %.8667 = lshr i64 %.8666, 23
  %shf_hi.130 = lshr i64 %.8667, 32
  %shf_result.156 = trunc i64 %shf_hi.130 to i32
  %.8669 = zext i32 %fchk_num_bits.25 to i64
  %.8670 = shl i64 %.8669, 32
  %.8671 = lshr i64 %.8670, 23
  %shf_hi.131 = lshr i64 %.8671, 32
  %shf_result.157 = trunc i64 %shf_hi.131 to i32
  %.8675 = and i32 %shf_result.156, 255
  %.8683 = and i32 %shf_result.157, 255
  %iadd3_n1.257 = add i32 %.8675, -1
  %iadd3_n1.258 = add i32 %.8683, -1
  %isetrp_cmp1.334 = icmp ugt i32 %iadd3_n1.257, 253
  %isetrp_cmp1.335 = icmp ugt i32 %iadd3_n1.258, 253
  %isetrp_cmp2.335 = or i1 %isetrp_cmp1.335, %isetrp_cmp1.334
  br label %BB_40b0_6fd0

BB_40b0_6fd0:                                     ; preds = %BB_40b0_6f40
  %cond_not.210 = xor i1 %isetrp_cmp2.335, true
  br i1 %cond_not.210, label %BB_40b0_80006fd0, label %BB_40b0_6ff0

BB_40b0_6ff0:                                     ; preds = %BB_40b0_6fd0
  %fsetrp_lhs_fabs.125 = call float @llvm.nvvm.fabs.f(float %ffma.432)
  %fsetrp_cmp1.150 = fcmp ugt float %fsetrp_lhs_fabs.125, 0x7FF0000000000000
  %fsetrp_lhs_fabs.126 = call float @llvm.nvvm.fabs.f(float %lds.82)
  %fsetrp_cmp1.151 = fcmp ugt float %fsetrp_lhs_fabs.126, 0x7FF0000000000000
  %lop3_a_cast_zext.100 = zext i1 %fsetrp_cmp1.150 to i32
  %lop3_b_cast_zext.100 = zext i1 %fsetrp_cmp1.151 to i32
  %plop3_a_bit.100 = and i32 %lop3_a_cast_zext.100, 1
  %plop3_b_bit.100 = and i32 %lop3_b_cast_zext.100, 1
  %.8690 = xor i32 %plop3_a_bit.100, 1
  %.8691 = xor i32 %plop3_b_bit.100, 1
  %.8693 = and i32 %.8690, %plop3_b_bit.100
  %.8695 = and i32 %plop3_a_bit.100, %.8691
  %.8697 = or i32 %.8693, %.8695
  %.8698 = and i32 %plop3_a_bit.100, %plop3_b_bit.100
  %.8700 = or i32 %.8697, %.8698
  %lop3_pred_cmp.175 = icmp ne i32 %.8700, 0
  br label %BB_40b0_7020

BB_40b0_7020:                                     ; preds = %BB_40b0_6ff0
  %378 = zext i1 %lop3_pred_cmp.175 to i32
  %379 = icmp ne i32 %378, 0
  br i1 %379, label %BB_40b0_7580, label %BB_40b0_7030

BB_40b0_7030:                                     ; preds = %BB_40b0_7020
  %.8703 = xor i32 %fchk_den_bits.25, -1
  %.8705 = xor i32 %fchk_num_bits.25, -1
  %.8706 = and i32 %.8703, 2147483647
  %.8707 = and i32 %.8706, %fchk_num_bits.25
  %.8709 = and i32 %fchk_aden.25, %.8705
  %.8710 = or i32 %.8707, %.8709
  %.8712 = and i32 %fchk_aden.25, %fchk_num_bits.25
  %.8713 = or i32 %.8710, %.8712
  %lop3_pred_cmp.176 = icmp ne i32 %.8713, 0
  br label %BB_40b0_7040

BB_40b0_7040:                                     ; preds = %BB_40b0_7030
  %cond_not.211 = xor i1 %lop3_pred_cmp.176, true
  br i1 %cond_not.211, label %BB_40b0_7560, label %BB_40b0_7050

BB_40b0_7050:                                     ; preds = %BB_40b0_7040
  %fsetrp_cmp1.152 = fcmp une float %fsetrp_lhs_fabs.125, 0x7FF0000000000000
  %fsetrp_cmp1.153 = fcmp une float %fsetrp_lhs_fabs.126, 0x7FF0000000000000
  br label %BB_40b0_7080

BB_40b0_7080:                                     ; preds = %BB_40b0_7050
  %cond_not.212 = xor i1 %fsetrp_cmp1.153, true
  br i1 %cond_not.212, label %BB_40b0_80007080, label %BB_40b0_7090

BB_40b0_80007080:                                 ; preds = %BB_40b0_7080
  %bra_cond_not.25 = xor i1 %fsetrp_cmp1.152, true
  br i1 %bra_cond_not.25, label %BB_40b0_7560, label %BB_40b0_7090

BB_40b0_7090:                                     ; preds = %BB_40b0_80007080, %BB_40b0_7080
  %lop3_pred_cmp.177 = icmp ne i32 %fchk_anum.25, 0
  %lop3_a_cast_zext.101 = zext i1 %fsetrp_cmp1.153 to i32
  %lop3_b_cast_zext.101 = zext i1 %lop3_pred_cmp.177 to i32
  %plop3_a_bit.101 = and i32 %lop3_a_cast_zext.101, 1
  %plop3_b_bit.101 = and i32 %lop3_b_cast_zext.101, 1
  %.8727 = xor i32 %plop3_a_bit.101, 1
  %.8728 = xor i32 %plop3_b_bit.101, 1
  %.8730 = and i32 %.8727, %.8728
  %.8732 = and i32 %.8727, %plop3_b_bit.101
  %.8734 = or i32 %.8730, %.8732
  %.8735 = and i32 %plop3_a_bit.101, %.8728
  %.8737 = or i32 %.8734, %.8735
  %lop3_pred_cmp.178 = icmp ne i32 %.8737, 0
  br label %BB_40b0_70b0

BB_40b0_70b0:                                     ; preds = %BB_40b0_7090
  %380 = zext i1 %lop3_pred_cmp.178 to i32
  %381 = icmp ne i32 %380, 0
  br i1 %381, label %BB_40b0_7540, label %BB_40b0_70c0

BB_40b0_70c0:                                     ; preds = %BB_40b0_70b0
  %lop3_pred_cmp.179 = icmp ne i32 %fchk_aden.25, 0
  %lop3_a_cast_zext.102 = zext i1 %fsetrp_cmp1.152 to i32
  %lop3_b_cast_zext.102 = zext i1 %lop3_pred_cmp.179 to i32
  %plop3_a_bit.102 = and i32 %lop3_a_cast_zext.102, 1
  %plop3_b_bit.102 = and i32 %lop3_b_cast_zext.102, 1
  %.8748 = xor i32 %plop3_a_bit.102, 1
  %.8749 = xor i32 %plop3_b_bit.102, 1
  %.8751 = and i32 %.8748, %.8749
  %.8753 = and i32 %.8748, %plop3_b_bit.102
  %.8755 = or i32 %.8751, %.8753
  %.8756 = and i32 %plop3_a_bit.102, %.8749
  %.8758 = or i32 %.8755, %.8756
  %lop3_pred_cmp.180 = icmp ne i32 %.8758, 0
  br label %BB_40b0_70e0

BB_40b0_70e0:                                     ; preds = %BB_40b0_70c0
  %382 = zext i1 %lop3_pred_cmp.180 to i32
  %383 = icmp ne i32 %382, 0
  br i1 %383, label %BB_40b0_7510, label %BB_40b0_70f0

BB_40b0_70f0:                                     ; preds = %BB_40b0_70e0
  %isetrp_cmp1.336 = icmp sge i32 %iadd3_n1.258, 0
  %isetrp_cmp1.337 = icmp sge i32 %iadd3_n1.257, 0
  br label %BB_40b0_7130

BB_40b0_7130:                                     ; preds = %BB_40b0_70f0
  %384 = zext i1 %isetrp_cmp1.336 to i32
  %385 = icmp ne i32 %384, 0
  br i1 %385, label %BB_40b0_80007130, label %BB_40b0_7140

BB_40b0_80007130:                                 ; preds = %BB_40b0_7130
  br label %BB_40b0_7140

BB_40b0_7140:                                     ; preds = %BB_40b0_80007130, %BB_40b0_7130
  %phi.406 = phi i32 [ 0, %BB_40b0_80007130 ], [ %iadd3_n1.257, %BB_40b0_7130 ]
  %cond_not.213 = xor i1 %isetrp_cmp1.336, true
  br i1 %cond_not.213, label %BB_40b0_80007140, label %BB_40b0_7160

BB_40b0_80007140:                                 ; preds = %BB_40b0_7140
  %ffma.438 = call float @llvm.fma.f32(float %ffma.432, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R210_bitcast = bitcast float %ffma.438 to i32
  br label %BB_40b0_7160

BB_40b0_7160:                                     ; preds = %BB_40b0_80007140, %BB_40b0_7140
  %phi.407 = phi i32 [ %phi_cast_R210_bitcast, %BB_40b0_80007140 ], [ %fchk_num_bits.25, %BB_40b0_7140 ]
  %phi.408 = phi i32 [ -64, %BB_40b0_80007140 ], [ %phi.406, %BB_40b0_7140 ]
  %cond_not.214 = xor i1 %isetrp_cmp1.337, true
  br i1 %cond_not.214, label %BB_40b0_80007160, label %BB_40b0_7180

BB_40b0_80007160:                                 ; preds = %BB_40b0_7160
  %ffma.439 = call float @llvm.fma.f32(float %lds.82, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.51 = add i32 %phi.408, 64
  %phi_cast_R777_bitcast = bitcast float %ffma.439 to i32
  br label %BB_40b0_7180

BB_40b0_7510:                                     ; preds = %BB_40b0_70e0
  %.8771 = and i32 %.8703, -2147483648
  %.8772 = and i32 %.8771, %fchk_num_bits.25
  %.8773 = and i32 %fchk_den_bits.25, -2147483648
  %.8774 = and i32 %.8773, %.8705
  %.8775 = or i32 %.8772, %.8774
  %.8776 = xor i32 %.8775, -1
  %.8779 = and i32 %.8776, 2139095040
  %.8786 = or i32 %.8779, %.8775
  %phi_cast_R217_bitcast = bitcast i32 %.8786 to float
  br label %BB_40b0_7590

BB_40b0_7540:                                     ; preds = %BB_40b0_70b0
  %.8800 = and i32 %.8703, -2147483648
  %.8801 = and i32 %.8800, %fchk_num_bits.25
  %.8802 = and i32 %fchk_den_bits.25, -2147483648
  %.8803 = and i32 %.8802, %.8705
  %.8804 = or i32 %.8801, %.8803
  %phi_cast_R218_bitcast = bitcast i32 %.8804 to float
  br label %BB_40b0_7590

BB_40b0_7560:                                     ; preds = %BB_40b0_80007080, %BB_40b0_7040
  %mufu_rsq.25 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_40b0_7590

BB_40b0_7580:                                     ; preds = %BB_40b0_7020
  %fadd.50 = fadd float %ffma.432, %lds.82
  br label %BB_40b0_7590

BB_40b0_80006fd0:                                 ; preds = %BB_40b0_6fd0
  br label %BB_40b0_7180

BB_40b0_7180:                                     ; preds = %BB_40b0_80006fd0, %BB_40b0_80007160, %BB_40b0_7160
  %phi.409 = phi i32 [ %fchk_den_bits.25, %BB_40b0_80006fd0 ], [ %phi_cast_R777_bitcast, %BB_40b0_80007160 ], [ %fchk_den_bits.25, %BB_40b0_7160 ]
  %phi.410 = phi i32 [ %fchk_num_bits.25, %BB_40b0_80006fd0 ], [ %phi.407, %BB_40b0_80007160 ], [ %phi.407, %BB_40b0_7160 ]
  %phi.411 = phi i32 [ 0, %BB_40b0_80006fd0 ], [ %viadd.51, %BB_40b0_80007160 ], [ %phi.408, %BB_40b0_7160 ]
  %.8809 = zext i32 %.8675 to i64
  %.8812 = shl i64 %.8809, 23
  %.8813 = and i64 %.8812, 4294967295
  %.8814 = add i64 %.8813, 3229614080
  %.8815 = trunc i64 %.8814 to i32
  %iadd3_n1.260 = add i32 %.8683, -127
  %iadd3_o1_not.50 = xor i32 %.8815, -1
  %iadd3_o1_neg.50 = add i32 %iadd3_o1_not.50, 1
  %iadd3_n1.261 = add i32 %iadd3_o1_neg.50, %phi.409
  %imad_tmp.96 = mul i32 %iadd3_n1.260, -8388608
  %imad.107 = add i32 %imad_tmp.96, %phi.410
  %mufu_src_bitcast.25 = bitcast i32 %iadd3_n1.261 to float
  %mufu_rcp.51 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.25)
  %fadd_lhs_fneg.25 = fneg float %mufu_src_bitcast.25
  %fadd.51 = fadd float %fadd_lhs_fneg.25, 0.000000e+00
  %iadd3_o3_not.25 = xor i32 %.8675, -1
  %iadd3_o3_neg.25 = add i32 %iadd3_o3_not.25, 1
  %iadd3_n2.262 = add i32 %.8683, %iadd3_o3_neg.25
  %iadd3_n1.263 = add i32 %iadd3_n2.262, %phi.411
  %ffma.440 = call float @llvm.fma.f32(float %mufu_rcp.51, float %fadd.51, float 1.000000e+00)
  %ffma.441 = call float @llvm.fma.f32(float %mufu_rcp.51, float %ffma.440, float %mufu_rcp.51)
  %ffma_lhs_bitcast.25 = bitcast i32 %imad.107 to float
  %ffma.442 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.25, float %ffma.441, float 0.000000e+00)
  %ffma.443 = call float @llvm.fma.f32(float %fadd.51, float %ffma.442, float %ffma_lhs_bitcast.25)
  %ffma.444 = call float @llvm.fma.f32(float %ffma.441, float %ffma.443, float %ffma.442)
  %ffma.445 = call float @llvm.fma.f32(float %fadd.51, float %ffma.444, float %ffma_lhs_bitcast.25)
  %ffma.446 = call float @llvm.fma.f32(float %ffma.441, float %ffma.445, float %ffma.444)
  %shf_hi_bitcast.77 = bitcast float %ffma.446 to i32
  %.8817 = zext i32 %shf_hi_bitcast.77 to i64
  %.8818 = shl i64 %.8817, 32
  %.8819 = lshr i64 %.8818, 23
  %shf_hi.132 = lshr i64 %.8819, 32
  %shf_result.158 = trunc i64 %shf_hi.132 to i32
  %.8823 = and i32 %shf_result.158, 255
  %imad.108 = add i32 %.8823, %iadd3_n1.263
  %iadd3_n1.264 = add i32 %imad.108, -1
  %isetrp_cmp1.338 = icmp uge i32 %iadd3_n1.264, 254
  br label %BB_40b0_72d0

BB_40b0_72d0:                                     ; preds = %BB_40b0_7180
  %cond_not.215 = xor i1 %isetrp_cmp1.338, true
  br i1 %cond_not.215, label %BB_40b0_74e0, label %BB_40b0_72e0

BB_40b0_72e0:                                     ; preds = %BB_40b0_72d0
  %isetrp_cmp1.339 = icmp sgt i32 %imad.108, 254
  br label %BB_40b0_72f0

BB_40b0_72f0:                                     ; preds = %BB_40b0_72e0
  %386 = zext i1 %isetrp_cmp1.339 to i32
  %387 = icmp ne i32 %386, 0
  br i1 %387, label %BB_40b0_74b0, label %BB_40b0_7300

BB_40b0_7300:                                     ; preds = %BB_40b0_72f0
  %isetrp_cmp1.340 = icmp sge i32 %imad.108, 1
  br label %BB_40b0_7310

BB_40b0_7310:                                     ; preds = %BB_40b0_7300
  %phi_cast_R2259_bitcast.2 = bitcast i32 %iadd3_n1.263 to float
  br i1 %isetrp_cmp1.340, label %BB_40b0_7590, label %BB_40b0_7320

BB_40b0_7320:                                     ; preds = %BB_40b0_7310
  %isetrp_cmp1.341 = icmp sge i32 %imad.108, -24
  %.8837 = and i32 %shf_hi_bitcast.77, -2147483648
  br label %BB_40b0_7340

BB_40b0_7340:                                     ; preds = %BB_40b0_7320
  %cond_not.216 = xor i1 %isetrp_cmp1.341, true
  %phi_cast_R227_bitcast = bitcast i32 %.8837 to float
  br i1 %cond_not.216, label %BB_40b0_7590, label %BB_40b0_7350

BB_40b0_7350:                                     ; preds = %BB_40b0_7340
  %ffma_rz.25 = call float @llvm.nvvm.fma.rz.f(float %ffma.441, float %ffma.445, float %ffma.444)
  %iadd3_n1.265 = add i32 %imad.108, 32
  %lop3_a_bitcast.206 = bitcast float %ffma_rz.25 to i32
  %.8847 = and i32 %lop3_a_bitcast.206, 8388607
  %ffma_rp.25 = call float @llvm.nvvm.fma.rp.f(float %ffma.441, float %ffma.445, float %ffma.444)
  %ffma_rm.25 = call float @llvm.nvvm.fma.rm.f(float %ffma.441, float %ffma.445, float %ffma.444)
  %isetrp_cmp1.343 = icmp ne i32 %imad.108, 0
  %.8862 = or i32 8388608, %.8847
  %iadd3_o1_not.51 = xor i32 %imad.108, -1
  %iadd3_o1_neg.51 = add i32 %iadd3_o1_not.51, 1
  %.8872 = zext i32 %.8862 to i64
  %shf_shift_64.159 = zext i32 %iadd3_n1.265 to i64
  %.8875 = shl i64 %.8872, %shf_shift_64.159
  %shf_result.159 = trunc i64 %.8875 to i32
  %fsetrp_cmp1.155 = fcmp une float %ffma_rp.25, %ffma_rm.25
  %isetrp_cmp1.344 = icmp ne i32 %shf_result.159, 0
  %isetrp_cmp2.344 = and i1 %isetrp_cmp1.344, %isetrp_cmp1.343
  %.8878 = shl i64 %.8872, 32
  %shf_shift_64.160 = zext i32 %iadd3_o1_neg.51 to i64
  %.8879 = lshr i64 %.8878, %shf_shift_64.160
  %shf_hi.133 = lshr i64 %.8879, 32
  %shf_result.160 = trunc i64 %shf_hi.133 to i32
  %lop3_a_cast_zext.103 = zext i1 %fsetrp_cmp1.155 to i32
  %lop3_b_cast_zext.103 = zext i1 %isetrp_cmp2.344 to i32
  %plop3_a_bit.103 = and i32 %lop3_a_cast_zext.103, 1
  %plop3_b_bit.103 = and i32 %lop3_b_cast_zext.103, 1
  %.8880 = xor i32 %plop3_a_bit.103, 1
  %.8881 = xor i32 %plop3_b_bit.103, 1
  %.8883 = and i32 %.8880, %plop3_b_bit.103
  %.8885 = and i32 %plop3_a_bit.103, %.8881
  %.8887 = or i32 %.8883, %.8885
  %.8888 = and i32 %plop3_a_bit.103, %plop3_b_bit.103
  %.8890 = or i32 %.8887, %.8888
  %lop3_pred_cmp.181 = icmp ne i32 %.8890, 0
  %.8892 = zext i32 %shf_result.160 to i64
  %.8893 = shl i64 %.8892, 32
  %.8894 = lshr i64 %.8893, 1
  %shf_hi.134 = lshr i64 %.8894, 32
  %shf_result.161 = trunc i64 %shf_hi.134 to i32
  %sel_pred_not.25 = xor i1 %lop3_pred_cmp.181, true
  %sel.51 = select i1 %sel_pred_not.25, i32 0, i32 1
  %.8895 = xor i32 %sel.51, -1
  %.8897 = xor i32 %shf_result.161, -1
  %.8898 = and i32 %.8895, 1
  %.8899 = and i32 %.8898, %shf_result.161
  %.8907 = and i32 %sel.51, %.8897
  %.8908 = or i32 %.8899, %.8907
  %.8910 = and i32 %sel.51, %shf_result.161
  %.8911 = or i32 %.8908, %.8910
  %.8915 = and i32 %.8911, %shf_result.160
  %imad.109 = add i32 %shf_result.161, %.8915
  %.8920 = xor i32 %imad.109, -1
  %.8921 = xor i32 %.8837, -1
  %.8923 = and i32 %.8920, %.8837
  %.8928 = and i32 %imad.109, %.8921
  %.8930 = or i32 %.8923, %.8928
  %.8934 = and i32 %imad.109, %.8837
  %.8936 = or i32 %.8930, %.8934
  %phi_cast_R229_bitcast = bitcast i32 %.8936 to float
  %phi_cast_R2261_bitcast = bitcast i32 %.8862 to float
  br label %BB_40b0_7590

BB_40b0_74b0:                                     ; preds = %BB_40b0_72f0
  %.8944 = and i32 %shf_hi_bitcast.77, -2147483648
  %.8959 = or i32 2139095040, %.8944
  %phi_cast_R231_bitcast = bitcast i32 %.8959 to float
  %phi_cast_R2259_bitcast = bitcast i32 %iadd3_n1.263 to float
  br label %BB_40b0_7590

BB_40b0_74e0:                                     ; preds = %BB_40b0_72d0
  %.8970 = zext i32 %iadd3_n1.263 to i64
  %.8973 = shl i64 %.8970, 23
  %.8974 = and i64 %.8973, 4294967295
  %.8975 = add i64 %.8974, %.8817
  %.8976 = trunc i64 %.8975 to i32
  %phi_cast_R233_bitcast = bitcast i32 %.8976 to float
  %phi_cast_R2259_bitcast.1 = bitcast i32 %iadd3_n1.263 to float
  br label %BB_40b0_7590

BB_40b0_7590:                                     ; preds = %BB_40b0_74e0, %BB_40b0_74b0, %BB_40b0_7350, %BB_40b0_7340, %BB_40b0_7310, %BB_40b0_7580, %BB_40b0_7560, %BB_40b0_7540, %BB_40b0_7510
  %phi.412 = phi float [ %phi_cast_R229_bitcast, %BB_40b0_7350 ], [ %phi_cast_R231_bitcast, %BB_40b0_74b0 ], [ %phi_cast_R233_bitcast, %BB_40b0_74e0 ], [ %ffma.446, %BB_40b0_7310 ], [ %phi_cast_R227_bitcast, %BB_40b0_7340 ], [ %phi_cast_R217_bitcast, %BB_40b0_7510 ], [ %phi_cast_R218_bitcast, %BB_40b0_7540 ], [ %mufu_rsq.25, %BB_40b0_7560 ], [ %fadd.50, %BB_40b0_7580 ]
  %phi.413 = phi float [ %phi_cast_R2261_bitcast, %BB_40b0_7350 ], [ %phi_cast_R2259_bitcast, %BB_40b0_74b0 ], [ %phi_cast_R2259_bitcast.1, %BB_40b0_74e0 ], [ %phi_cast_R2259_bitcast.2, %BB_40b0_7310 ], [ %phi_cast_R2259_bitcast.2, %BB_40b0_7340 ], [ %phi.402, %BB_40b0_7510 ], [ %phi.402, %BB_40b0_7540 ], [ %phi.402, %BB_40b0_7560 ], [ %phi.402, %BB_40b0_7580 ]
  br label %BB_40d0

BB_40d0:                                          ; preds = %BB_40b0_7590, %BB_4080
  %phi.414 = phi float [ %phi.412, %BB_40b0_7590 ], [ %ffma.437, %BB_4080 ]
  %phi.415 = phi float [ %phi.413, %BB_40b0_7590 ], [ %phi.402, %BB_4080 ]
  br label %BB_40f0

BB_40f0:                                          ; preds = %BB_40d0, %BB_3f90
  %phi.416 = phi float [ %phi.414, %BB_40d0 ], [ %phi.401, %BB_3f90 ]
  %phi.417 = phi float [ %phi.415, %BB_40d0 ], [ %phi.402, %BB_3f90 ]
  %phi.418 = phi i32 [ %.75, %BB_40d0 ], [ %phi.403, %BB_3f90 ]
  %phi.419 = phi float [ %phi.414, %BB_40d0 ], [ %phi.404, %BB_3f90 ]
  br label %BB_4120

BB_4120:                                          ; preds = %BB_40f0
  %shfl_activemask.57 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.57 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.57, float %phi.419, i32 25, i32 31)
  br label %BB_4130

BB_4130:                                          ; preds = %BB_4120
  %isetrp_cmp1.345 = icmp uge i32 %tid_x, 26
  %isetrp_cmp1.346 = icmp ne i32 %tid_x, 26
  br label %BB_4160

BB_4160:                                          ; preds = %BB_4130
  %388 = zext i1 %isetrp_cmp1.345 to i32
  %389 = icmp ne i32 %388, 0
  br i1 %389, label %BB_80004160, label %BB_4180

BB_80004160:                                      ; preds = %BB_4160
  %lds_addr_memaddr_offset_add.80 = add i32 %.88, 3300
  %.8984 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.80
  %lds.83 = load volatile float, ptr addrspace(3) %.8984, align 4
  %ffma.447 = call float @llvm.fma.f32(float %shfl_idx.57, float %lds.83, float %phi.405)
  br label %BB_4180

BB_4180:                                          ; preds = %BB_80004160, %BB_4160
  %phi.420 = phi float [ %ffma.447, %BB_80004160 ], [ %phi.405, %BB_4160 ]
  %warp_reconv_mask.25 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.25)
  br i1 %isetrp_cmp1.346, label %BB_42e0, label %BB_4190

BB_4190:                                          ; preds = %BB_4180
  %ffma_addend_fneg.26 = fneg float %phi.420
  %ffma.448 = call float @llvm.fma.f32(float %phi.416, float %phi, float %ffma_addend_fneg.26)
  %lds_addr_memaddr_offset_add.81 = add i32 %.75, 3536
  %.8994 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.81
  %lds.84 = load volatile float, ptr addrspace(3) %.8994, align 4
  %mufu_rcp.52 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.84)
  %fchk_num_bits.26 = bitcast float %ffma.448 to i32
  %fchk_den_bits.26 = bitcast float %lds.84 to i32
  %fchk_aden.26 = and i32 %fchk_den_bits.26, 2147483647
  %fchk_anum.26 = and i32 %fchk_num_bits.26, 2147483647
  %fchk_den_subz.26 = icmp ult i32 %fchk_aden.26, 8388608
  %fchk_den_infnan.26 = icmp uge i32 %fchk_aden.26, 2139095040
  %fchk_num_infnan.26 = icmp uge i32 %fchk_anum.26, 2139095040
  %fchk_den_bad.26 = or i1 %fchk_den_subz.26, %fchk_den_infnan.26
  %fchk_px.26 = or i1 %fchk_den_bad.26, %fchk_num_infnan.26
  %ffma_lhs_fneg.52 = fneg float %lds.84
  %ffma.449 = call float @llvm.fma.f32(float %ffma_lhs_fneg.52, float %mufu_rcp.52, float 1.000000e+00)
  %ffma.450 = call float @llvm.fma.f32(float %mufu_rcp.52, float %ffma.449, float %mufu_rcp.52)
  %ffma.451 = call float @llvm.fma.f32(float %ffma.448, float %ffma.450, float 0.000000e+00)
  %ffma.452 = call float @llvm.fma.f32(float %ffma_lhs_fneg.52, float %ffma.451, float %ffma.448)
  %ffma.453 = call float @llvm.fma.f32(float %ffma.450, float %ffma.452, float %ffma.451)
  br label %BB_4270

BB_4270:                                          ; preds = %BB_4190
  %cond_not.217 = xor i1 %fchk_px.26, true
  br i1 %cond_not.217, label %BB_42c0, label %BB_42a0_6f40

BB_42a0_6f40:                                     ; preds = %BB_4270
  %.8998 = zext i32 %fchk_den_bits.26 to i64
  %.8999 = shl i64 %.8998, 32
  %.9000 = lshr i64 %.8999, 23
  %shf_hi.135 = lshr i64 %.9000, 32
  %shf_result.162 = trunc i64 %shf_hi.135 to i32
  %.9002 = zext i32 %fchk_num_bits.26 to i64
  %.9003 = shl i64 %.9002, 32
  %.9004 = lshr i64 %.9003, 23
  %shf_hi.136 = lshr i64 %.9004, 32
  %shf_result.163 = trunc i64 %shf_hi.136 to i32
  %.9008 = and i32 %shf_result.162, 255
  %.9016 = and i32 %shf_result.163, 255
  %iadd3_n1.267 = add i32 %.9008, -1
  %iadd3_n1.268 = add i32 %.9016, -1
  %isetrp_cmp1.347 = icmp ugt i32 %iadd3_n1.267, 253
  %isetrp_cmp1.348 = icmp ugt i32 %iadd3_n1.268, 253
  %isetrp_cmp2.348 = or i1 %isetrp_cmp1.348, %isetrp_cmp1.347
  br label %BB_42a0_6fd0

BB_42a0_6fd0:                                     ; preds = %BB_42a0_6f40
  %cond_not.218 = xor i1 %isetrp_cmp2.348, true
  br i1 %cond_not.218, label %BB_42a0_80006fd0, label %BB_42a0_6ff0

BB_42a0_6ff0:                                     ; preds = %BB_42a0_6fd0
  %fsetrp_lhs_fabs.130 = call float @llvm.nvvm.fabs.f(float %ffma.448)
  %fsetrp_cmp1.156 = fcmp ugt float %fsetrp_lhs_fabs.130, 0x7FF0000000000000
  %fsetrp_lhs_fabs.131 = call float @llvm.nvvm.fabs.f(float %lds.84)
  %fsetrp_cmp1.157 = fcmp ugt float %fsetrp_lhs_fabs.131, 0x7FF0000000000000
  %lop3_a_cast_zext.104 = zext i1 %fsetrp_cmp1.156 to i32
  %lop3_b_cast_zext.104 = zext i1 %fsetrp_cmp1.157 to i32
  %plop3_a_bit.104 = and i32 %lop3_a_cast_zext.104, 1
  %plop3_b_bit.104 = and i32 %lop3_b_cast_zext.104, 1
  %.9023 = xor i32 %plop3_a_bit.104, 1
  %.9024 = xor i32 %plop3_b_bit.104, 1
  %.9026 = and i32 %.9023, %plop3_b_bit.104
  %.9028 = and i32 %plop3_a_bit.104, %.9024
  %.9030 = or i32 %.9026, %.9028
  %.9031 = and i32 %plop3_a_bit.104, %plop3_b_bit.104
  %.9033 = or i32 %.9030, %.9031
  %lop3_pred_cmp.182 = icmp ne i32 %.9033, 0
  br label %BB_42a0_7020

BB_42a0_7020:                                     ; preds = %BB_42a0_6ff0
  %390 = zext i1 %lop3_pred_cmp.182 to i32
  %391 = icmp ne i32 %390, 0
  br i1 %391, label %BB_42a0_7580, label %BB_42a0_7030

BB_42a0_7030:                                     ; preds = %BB_42a0_7020
  %.9036 = xor i32 %fchk_den_bits.26, -1
  %.9038 = xor i32 %fchk_num_bits.26, -1
  %.9039 = and i32 %.9036, 2147483647
  %.9040 = and i32 %.9039, %fchk_num_bits.26
  %.9042 = and i32 %fchk_aden.26, %.9038
  %.9043 = or i32 %.9040, %.9042
  %.9045 = and i32 %fchk_aden.26, %fchk_num_bits.26
  %.9046 = or i32 %.9043, %.9045
  %lop3_pred_cmp.183 = icmp ne i32 %.9046, 0
  br label %BB_42a0_7040

BB_42a0_7040:                                     ; preds = %BB_42a0_7030
  %cond_not.219 = xor i1 %lop3_pred_cmp.183, true
  br i1 %cond_not.219, label %BB_42a0_7560, label %BB_42a0_7050

BB_42a0_7050:                                     ; preds = %BB_42a0_7040
  %fsetrp_cmp1.158 = fcmp une float %fsetrp_lhs_fabs.130, 0x7FF0000000000000
  %fsetrp_cmp1.159 = fcmp une float %fsetrp_lhs_fabs.131, 0x7FF0000000000000
  br label %BB_42a0_7080

BB_42a0_7080:                                     ; preds = %BB_42a0_7050
  %cond_not.220 = xor i1 %fsetrp_cmp1.159, true
  br i1 %cond_not.220, label %BB_42a0_80007080, label %BB_42a0_7090

BB_42a0_80007080:                                 ; preds = %BB_42a0_7080
  %bra_cond_not.26 = xor i1 %fsetrp_cmp1.158, true
  br i1 %bra_cond_not.26, label %BB_42a0_7560, label %BB_42a0_7090

BB_42a0_7090:                                     ; preds = %BB_42a0_80007080, %BB_42a0_7080
  %lop3_pred_cmp.184 = icmp ne i32 %fchk_anum.26, 0
  %lop3_a_cast_zext.105 = zext i1 %fsetrp_cmp1.159 to i32
  %lop3_b_cast_zext.105 = zext i1 %lop3_pred_cmp.184 to i32
  %plop3_a_bit.105 = and i32 %lop3_a_cast_zext.105, 1
  %plop3_b_bit.105 = and i32 %lop3_b_cast_zext.105, 1
  %.9060 = xor i32 %plop3_a_bit.105, 1
  %.9061 = xor i32 %plop3_b_bit.105, 1
  %.9063 = and i32 %.9060, %.9061
  %.9065 = and i32 %.9060, %plop3_b_bit.105
  %.9067 = or i32 %.9063, %.9065
  %.9068 = and i32 %plop3_a_bit.105, %.9061
  %.9070 = or i32 %.9067, %.9068
  %lop3_pred_cmp.185 = icmp ne i32 %.9070, 0
  br label %BB_42a0_70b0

BB_42a0_70b0:                                     ; preds = %BB_42a0_7090
  %392 = zext i1 %lop3_pred_cmp.185 to i32
  %393 = icmp ne i32 %392, 0
  br i1 %393, label %BB_42a0_7540, label %BB_42a0_70c0

BB_42a0_70c0:                                     ; preds = %BB_42a0_70b0
  %lop3_pred_cmp.186 = icmp ne i32 %fchk_aden.26, 0
  %lop3_a_cast_zext.106 = zext i1 %fsetrp_cmp1.158 to i32
  %lop3_b_cast_zext.106 = zext i1 %lop3_pred_cmp.186 to i32
  %plop3_a_bit.106 = and i32 %lop3_a_cast_zext.106, 1
  %plop3_b_bit.106 = and i32 %lop3_b_cast_zext.106, 1
  %.9081 = xor i32 %plop3_a_bit.106, 1
  %.9082 = xor i32 %plop3_b_bit.106, 1
  %.9084 = and i32 %.9081, %.9082
  %.9086 = and i32 %.9081, %plop3_b_bit.106
  %.9088 = or i32 %.9084, %.9086
  %.9089 = and i32 %plop3_a_bit.106, %.9082
  %.9091 = or i32 %.9088, %.9089
  %lop3_pred_cmp.187 = icmp ne i32 %.9091, 0
  br label %BB_42a0_70e0

BB_42a0_70e0:                                     ; preds = %BB_42a0_70c0
  %394 = zext i1 %lop3_pred_cmp.187 to i32
  %395 = icmp ne i32 %394, 0
  br i1 %395, label %BB_42a0_7510, label %BB_42a0_70f0

BB_42a0_70f0:                                     ; preds = %BB_42a0_70e0
  %isetrp_cmp1.349 = icmp sge i32 %iadd3_n1.268, 0
  %isetrp_cmp1.350 = icmp sge i32 %iadd3_n1.267, 0
  br label %BB_42a0_7130

BB_42a0_7130:                                     ; preds = %BB_42a0_70f0
  %396 = zext i1 %isetrp_cmp1.349 to i32
  %397 = icmp ne i32 %396, 0
  br i1 %397, label %BB_42a0_80007130, label %BB_42a0_7140

BB_42a0_80007130:                                 ; preds = %BB_42a0_7130
  br label %BB_42a0_7140

BB_42a0_7140:                                     ; preds = %BB_42a0_80007130, %BB_42a0_7130
  %phi.421 = phi i32 [ 0, %BB_42a0_80007130 ], [ %iadd3_n1.267, %BB_42a0_7130 ]
  %cond_not.221 = xor i1 %isetrp_cmp1.349, true
  br i1 %cond_not.221, label %BB_42a0_80007140, label %BB_42a0_7160

BB_42a0_80007140:                                 ; preds = %BB_42a0_7140
  %ffma.454 = call float @llvm.fma.f32(float %ffma.448, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R237_bitcast = bitcast float %ffma.454 to i32
  br label %BB_42a0_7160

BB_42a0_7160:                                     ; preds = %BB_42a0_80007140, %BB_42a0_7140
  %phi.422 = phi i32 [ %phi_cast_R237_bitcast, %BB_42a0_80007140 ], [ %fchk_num_bits.26, %BB_42a0_7140 ]
  %phi.423 = phi i32 [ -64, %BB_42a0_80007140 ], [ %phi.421, %BB_42a0_7140 ]
  %cond_not.222 = xor i1 %isetrp_cmp1.350, true
  br i1 %cond_not.222, label %BB_42a0_80007160, label %BB_42a0_7180

BB_42a0_80007160:                                 ; preds = %BB_42a0_7160
  %ffma.455 = call float @llvm.fma.f32(float %lds.84, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.53 = add i32 %phi.423, 64
  %phi_cast_R795_bitcast = bitcast float %ffma.455 to i32
  br label %BB_42a0_7180

BB_42a0_7510:                                     ; preds = %BB_42a0_70e0
  %.9104 = and i32 %.9036, -2147483648
  %.9105 = and i32 %.9104, %fchk_num_bits.26
  %.9106 = and i32 %fchk_den_bits.26, -2147483648
  %.9107 = and i32 %.9106, %.9038
  %.9108 = or i32 %.9105, %.9107
  %.9109 = xor i32 %.9108, -1
  %.9112 = and i32 %.9109, 2139095040
  %.9119 = or i32 %.9112, %.9108
  %phi_cast_R241_bitcast = bitcast i32 %.9119 to float
  br label %BB_42a0_7590

BB_42a0_7540:                                     ; preds = %BB_42a0_70b0
  %.9133 = and i32 %.9036, -2147483648
  %.9134 = and i32 %.9133, %fchk_num_bits.26
  %.9135 = and i32 %fchk_den_bits.26, -2147483648
  %.9136 = and i32 %.9135, %.9038
  %.9137 = or i32 %.9134, %.9136
  %phi_cast_R243_bitcast = bitcast i32 %.9137 to float
  br label %BB_42a0_7590

BB_42a0_7560:                                     ; preds = %BB_42a0_80007080, %BB_42a0_7040
  %mufu_rsq.26 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_42a0_7590

BB_42a0_7580:                                     ; preds = %BB_42a0_7020
  %fadd.52 = fadd float %ffma.448, %lds.84
  br label %BB_42a0_7590

BB_42a0_80006fd0:                                 ; preds = %BB_42a0_6fd0
  br label %BB_42a0_7180

BB_42a0_7180:                                     ; preds = %BB_42a0_80006fd0, %BB_42a0_80007160, %BB_42a0_7160
  %phi.424 = phi i32 [ %fchk_den_bits.26, %BB_42a0_80006fd0 ], [ %phi_cast_R795_bitcast, %BB_42a0_80007160 ], [ %fchk_den_bits.26, %BB_42a0_7160 ]
  %phi.425 = phi i32 [ %fchk_num_bits.26, %BB_42a0_80006fd0 ], [ %phi.422, %BB_42a0_80007160 ], [ %phi.422, %BB_42a0_7160 ]
  %phi.426 = phi i32 [ 0, %BB_42a0_80006fd0 ], [ %viadd.53, %BB_42a0_80007160 ], [ %phi.423, %BB_42a0_7160 ]
  %.9142 = zext i32 %.9008 to i64
  %.9145 = shl i64 %.9142, 23
  %.9146 = and i64 %.9145, 4294967295
  %.9147 = add i64 %.9146, 3229614080
  %.9148 = trunc i64 %.9147 to i32
  %iadd3_n1.270 = add i32 %.9016, -127
  %iadd3_o1_not.52 = xor i32 %.9148, -1
  %iadd3_o1_neg.52 = add i32 %iadd3_o1_not.52, 1
  %iadd3_n1.271 = add i32 %iadd3_o1_neg.52, %phi.424
  %imad_tmp.99 = mul i32 %iadd3_n1.270, -8388608
  %imad.110 = add i32 %imad_tmp.99, %phi.425
  %mufu_src_bitcast.26 = bitcast i32 %iadd3_n1.271 to float
  %mufu_rcp.53 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.26)
  %fadd_lhs_fneg.26 = fneg float %mufu_src_bitcast.26
  %fadd.53 = fadd float %fadd_lhs_fneg.26, 0.000000e+00
  %iadd3_o3_not.26 = xor i32 %.9008, -1
  %iadd3_o3_neg.26 = add i32 %iadd3_o3_not.26, 1
  %iadd3_n2.272 = add i32 %.9016, %iadd3_o3_neg.26
  %iadd3_n1.273 = add i32 %iadd3_n2.272, %phi.426
  %ffma.456 = call float @llvm.fma.f32(float %mufu_rcp.53, float %fadd.53, float 1.000000e+00)
  %ffma.457 = call float @llvm.fma.f32(float %mufu_rcp.53, float %ffma.456, float %mufu_rcp.53)
  %ffma_lhs_bitcast.26 = bitcast i32 %imad.110 to float
  %ffma.458 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.26, float %ffma.457, float 0.000000e+00)
  %ffma.459 = call float @llvm.fma.f32(float %fadd.53, float %ffma.458, float %ffma_lhs_bitcast.26)
  %ffma.460 = call float @llvm.fma.f32(float %ffma.457, float %ffma.459, float %ffma.458)
  %ffma.461 = call float @llvm.fma.f32(float %fadd.53, float %ffma.460, float %ffma_lhs_bitcast.26)
  %ffma.462 = call float @llvm.fma.f32(float %ffma.457, float %ffma.461, float %ffma.460)
  %shf_hi_bitcast.80 = bitcast float %ffma.462 to i32
  %.9150 = zext i32 %shf_hi_bitcast.80 to i64
  %.9151 = shl i64 %.9150, 32
  %.9152 = lshr i64 %.9151, 23
  %shf_hi.137 = lshr i64 %.9152, 32
  %shf_result.164 = trunc i64 %shf_hi.137 to i32
  %.9156 = and i32 %shf_result.164, 255
  %imad.111 = add i32 %.9156, %iadd3_n1.273
  %iadd3_n1.274 = add i32 %imad.111, -1
  %isetrp_cmp1.351 = icmp uge i32 %iadd3_n1.274, 254
  br label %BB_42a0_72d0

BB_42a0_72d0:                                     ; preds = %BB_42a0_7180
  %cond_not.223 = xor i1 %isetrp_cmp1.351, true
  br i1 %cond_not.223, label %BB_42a0_74e0, label %BB_42a0_72e0

BB_42a0_72e0:                                     ; preds = %BB_42a0_72d0
  %isetrp_cmp1.352 = icmp sgt i32 %imad.111, 254
  br label %BB_42a0_72f0

BB_42a0_72f0:                                     ; preds = %BB_42a0_72e0
  %398 = zext i1 %isetrp_cmp1.352 to i32
  %399 = icmp ne i32 %398, 0
  br i1 %399, label %BB_42a0_74b0, label %BB_42a0_7300

BB_42a0_7300:                                     ; preds = %BB_42a0_72f0
  %isetrp_cmp1.353 = icmp sge i32 %imad.111, 1
  br label %BB_42a0_7310

BB_42a0_7310:                                     ; preds = %BB_42a0_7300
  %phi_cast_R2270_bitcast.2 = bitcast i32 %iadd3_n1.273 to float
  br i1 %isetrp_cmp1.353, label %BB_42a0_7590, label %BB_42a0_7320

BB_42a0_7320:                                     ; preds = %BB_42a0_7310
  %isetrp_cmp1.354 = icmp sge i32 %imad.111, -24
  %.9170 = and i32 %shf_hi_bitcast.80, -2147483648
  br label %BB_42a0_7340

BB_42a0_7340:                                     ; preds = %BB_42a0_7320
  %cond_not.224 = xor i1 %isetrp_cmp1.354, true
  %phi_cast_R250_bitcast = bitcast i32 %.9170 to float
  br i1 %cond_not.224, label %BB_42a0_7590, label %BB_42a0_7350

BB_42a0_7350:                                     ; preds = %BB_42a0_7340
  %ffma_rz.26 = call float @llvm.nvvm.fma.rz.f(float %ffma.457, float %ffma.461, float %ffma.460)
  %iadd3_n1.275 = add i32 %imad.111, 32
  %lop3_a_bitcast.214 = bitcast float %ffma_rz.26 to i32
  %.9180 = and i32 %lop3_a_bitcast.214, 8388607
  %ffma_rp.26 = call float @llvm.nvvm.fma.rp.f(float %ffma.457, float %ffma.461, float %ffma.460)
  %ffma_rm.26 = call float @llvm.nvvm.fma.rm.f(float %ffma.457, float %ffma.461, float %ffma.460)
  %isetrp_cmp1.356 = icmp ne i32 %imad.111, 0
  %.9195 = or i32 8388608, %.9180
  %iadd3_o1_not.53 = xor i32 %imad.111, -1
  %iadd3_o1_neg.53 = add i32 %iadd3_o1_not.53, 1
  %.9205 = zext i32 %.9195 to i64
  %shf_shift_64.165 = zext i32 %iadd3_n1.275 to i64
  %.9208 = shl i64 %.9205, %shf_shift_64.165
  %shf_result.165 = trunc i64 %.9208 to i32
  %fsetrp_cmp1.161 = fcmp une float %ffma_rp.26, %ffma_rm.26
  %isetrp_cmp1.357 = icmp ne i32 %shf_result.165, 0
  %isetrp_cmp2.357 = and i1 %isetrp_cmp1.357, %isetrp_cmp1.356
  %.9211 = shl i64 %.9205, 32
  %shf_shift_64.166 = zext i32 %iadd3_o1_neg.53 to i64
  %.9212 = lshr i64 %.9211, %shf_shift_64.166
  %shf_hi.138 = lshr i64 %.9212, 32
  %shf_result.166 = trunc i64 %shf_hi.138 to i32
  %lop3_a_cast_zext.107 = zext i1 %fsetrp_cmp1.161 to i32
  %lop3_b_cast_zext.107 = zext i1 %isetrp_cmp2.357 to i32
  %plop3_a_bit.107 = and i32 %lop3_a_cast_zext.107, 1
  %plop3_b_bit.107 = and i32 %lop3_b_cast_zext.107, 1
  %.9213 = xor i32 %plop3_a_bit.107, 1
  %.9214 = xor i32 %plop3_b_bit.107, 1
  %.9216 = and i32 %.9213, %plop3_b_bit.107
  %.9218 = and i32 %plop3_a_bit.107, %.9214
  %.9220 = or i32 %.9216, %.9218
  %.9221 = and i32 %plop3_a_bit.107, %plop3_b_bit.107
  %.9223 = or i32 %.9220, %.9221
  %lop3_pred_cmp.188 = icmp ne i32 %.9223, 0
  %.9225 = zext i32 %shf_result.166 to i64
  %.9226 = shl i64 %.9225, 32
  %.9227 = lshr i64 %.9226, 1
  %shf_hi.139 = lshr i64 %.9227, 32
  %shf_result.167 = trunc i64 %shf_hi.139 to i32
  %sel_pred_not.26 = xor i1 %lop3_pred_cmp.188, true
  %sel.53 = select i1 %sel_pred_not.26, i32 0, i32 1
  %.9228 = xor i32 %sel.53, -1
  %.9230 = xor i32 %shf_result.167, -1
  %.9231 = and i32 %.9228, 1
  %.9232 = and i32 %.9231, %shf_result.167
  %.9240 = and i32 %sel.53, %.9230
  %.9241 = or i32 %.9232, %.9240
  %.9243 = and i32 %sel.53, %shf_result.167
  %.9244 = or i32 %.9241, %.9243
  %.9248 = and i32 %.9244, %shf_result.166
  %imad.112 = add i32 %shf_result.167, %.9248
  %.9253 = xor i32 %imad.112, -1
  %.9254 = xor i32 %.9170, -1
  %.9256 = and i32 %.9253, %.9170
  %.9261 = and i32 %imad.112, %.9254
  %.9263 = or i32 %.9256, %.9261
  %.9267 = and i32 %imad.112, %.9170
  %.9269 = or i32 %.9263, %.9267
  %phi_cast_R251_bitcast = bitcast i32 %.9269 to float
  %phi_cast_R2273_bitcast = bitcast i32 %.9195 to float
  br label %BB_42a0_7590

BB_42a0_74b0:                                     ; preds = %BB_42a0_72f0
  %.9277 = and i32 %shf_hi_bitcast.80, -2147483648
  %.9292 = or i32 2139095040, %.9277
  %phi_cast_R256_bitcast = bitcast i32 %.9292 to float
  %phi_cast_R2270_bitcast = bitcast i32 %iadd3_n1.273 to float
  br label %BB_42a0_7590

BB_42a0_74e0:                                     ; preds = %BB_42a0_72d0
  %.9303 = zext i32 %iadd3_n1.273 to i64
  %.9306 = shl i64 %.9303, 23
  %.9307 = and i64 %.9306, 4294967295
  %.9308 = add i64 %.9307, %.9150
  %.9309 = trunc i64 %.9308 to i32
  %phi_cast_R257_bitcast = bitcast i32 %.9309 to float
  %phi_cast_R2270_bitcast.1 = bitcast i32 %iadd3_n1.273 to float
  br label %BB_42a0_7590

BB_42a0_7590:                                     ; preds = %BB_42a0_74e0, %BB_42a0_74b0, %BB_42a0_7350, %BB_42a0_7340, %BB_42a0_7310, %BB_42a0_7580, %BB_42a0_7560, %BB_42a0_7540, %BB_42a0_7510
  %phi.427 = phi float [ %phi_cast_R251_bitcast, %BB_42a0_7350 ], [ %phi_cast_R256_bitcast, %BB_42a0_74b0 ], [ %phi_cast_R257_bitcast, %BB_42a0_74e0 ], [ %ffma.462, %BB_42a0_7310 ], [ %phi_cast_R250_bitcast, %BB_42a0_7340 ], [ %phi_cast_R241_bitcast, %BB_42a0_7510 ], [ %phi_cast_R243_bitcast, %BB_42a0_7540 ], [ %mufu_rsq.26, %BB_42a0_7560 ], [ %fadd.52, %BB_42a0_7580 ]
  %phi.428 = phi float [ %phi_cast_R2273_bitcast, %BB_42a0_7350 ], [ %phi_cast_R2270_bitcast, %BB_42a0_74b0 ], [ %phi_cast_R2270_bitcast.1, %BB_42a0_74e0 ], [ %phi_cast_R2270_bitcast.2, %BB_42a0_7310 ], [ %phi_cast_R2270_bitcast.2, %BB_42a0_7340 ], [ %phi.417, %BB_42a0_7510 ], [ %phi.417, %BB_42a0_7540 ], [ %phi.417, %BB_42a0_7560 ], [ %phi.417, %BB_42a0_7580 ]
  br label %BB_42c0

BB_42c0:                                          ; preds = %BB_42a0_7590, %BB_4270
  %phi.429 = phi float [ %phi.427, %BB_42a0_7590 ], [ %ffma.453, %BB_4270 ]
  %phi.430 = phi float [ %phi.428, %BB_42a0_7590 ], [ %phi.417, %BB_4270 ]
  br label %BB_42e0

BB_42e0:                                          ; preds = %BB_42c0, %BB_4180
  %phi.431 = phi float [ %phi.429, %BB_42c0 ], [ %phi.416, %BB_4180 ]
  %phi.432 = phi float [ %phi.430, %BB_42c0 ], [ %phi.417, %BB_4180 ]
  %phi.433 = phi i32 [ %.75, %BB_42c0 ], [ %phi.418, %BB_4180 ]
  %phi.434 = phi float [ %phi.429, %BB_42c0 ], [ %phi.419, %BB_4180 ]
  br label %BB_4310

BB_4310:                                          ; preds = %BB_42e0
  %shfl_activemask.58 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.58 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.58, float %phi.434, i32 26, i32 31)
  br label %BB_4320

BB_4320:                                          ; preds = %BB_4310
  %isetrp_cmp1.358 = icmp uge i32 %tid_x, 27
  %isetrp_cmp1.359 = icmp ne i32 %tid_x, 27
  br label %BB_4350

BB_4350:                                          ; preds = %BB_4320
  %400 = zext i1 %isetrp_cmp1.358 to i32
  %401 = icmp ne i32 %400, 0
  br i1 %401, label %BB_80004350, label %BB_4370

BB_80004350:                                      ; preds = %BB_4350
  %lds_addr_memaddr_offset_add.82 = add i32 %.88, 3432
  %.9317 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.82
  %lds.85 = load volatile float, ptr addrspace(3) %.9317, align 4
  %ffma.463 = call float @llvm.fma.f32(float %shfl_idx.58, float %lds.85, float %phi.420)
  br label %BB_4370

BB_4370:                                          ; preds = %BB_80004350, %BB_4350
  %phi.435 = phi float [ %ffma.463, %BB_80004350 ], [ %phi.420, %BB_4350 ]
  %warp_reconv_mask.26 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.26)
  br i1 %isetrp_cmp1.359, label %BB_44d0, label %BB_4380

BB_4380:                                          ; preds = %BB_4370
  %ffma_addend_fneg.27 = fneg float %phi.435
  %ffma.464 = call float @llvm.fma.f32(float %phi.431, float %phi, float %ffma_addend_fneg.27)
  %lds_addr_memaddr_offset_add.83 = add i32 %.75, 3672
  %.9327 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.83
  %lds.86 = load volatile float, ptr addrspace(3) %.9327, align 4
  %mufu_rcp.54 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.86)
  %fchk_num_bits.27 = bitcast float %ffma.464 to i32
  %fchk_den_bits.27 = bitcast float %lds.86 to i32
  %fchk_aden.27 = and i32 %fchk_den_bits.27, 2147483647
  %fchk_anum.27 = and i32 %fchk_num_bits.27, 2147483647
  %fchk_den_subz.27 = icmp ult i32 %fchk_aden.27, 8388608
  %fchk_den_infnan.27 = icmp uge i32 %fchk_aden.27, 2139095040
  %fchk_num_infnan.27 = icmp uge i32 %fchk_anum.27, 2139095040
  %fchk_den_bad.27 = or i1 %fchk_den_subz.27, %fchk_den_infnan.27
  %fchk_px.27 = or i1 %fchk_den_bad.27, %fchk_num_infnan.27
  %ffma_lhs_fneg.54 = fneg float %lds.86
  %ffma.465 = call float @llvm.fma.f32(float %ffma_lhs_fneg.54, float %mufu_rcp.54, float 1.000000e+00)
  %ffma.466 = call float @llvm.fma.f32(float %mufu_rcp.54, float %ffma.465, float %mufu_rcp.54)
  %ffma.467 = call float @llvm.fma.f32(float %ffma.464, float %ffma.466, float 0.000000e+00)
  %ffma.468 = call float @llvm.fma.f32(float %ffma_lhs_fneg.54, float %ffma.467, float %ffma.464)
  %ffma.469 = call float @llvm.fma.f32(float %ffma.466, float %ffma.468, float %ffma.467)
  br label %BB_4460

BB_4460:                                          ; preds = %BB_4380
  %cond_not.225 = xor i1 %fchk_px.27, true
  br i1 %cond_not.225, label %BB_44b0, label %BB_4490_6f40

BB_4490_6f40:                                     ; preds = %BB_4460
  %.9331 = zext i32 %fchk_den_bits.27 to i64
  %.9332 = shl i64 %.9331, 32
  %.9333 = lshr i64 %.9332, 23
  %shf_hi.140 = lshr i64 %.9333, 32
  %shf_result.168 = trunc i64 %shf_hi.140 to i32
  %.9335 = zext i32 %fchk_num_bits.27 to i64
  %.9336 = shl i64 %.9335, 32
  %.9337 = lshr i64 %.9336, 23
  %shf_hi.141 = lshr i64 %.9337, 32
  %shf_result.169 = trunc i64 %shf_hi.141 to i32
  %.9341 = and i32 %shf_result.168, 255
  %.9349 = and i32 %shf_result.169, 255
  %iadd3_n1.277 = add i32 %.9341, -1
  %iadd3_n1.278 = add i32 %.9349, -1
  %isetrp_cmp1.360 = icmp ugt i32 %iadd3_n1.277, 253
  %isetrp_cmp1.361 = icmp ugt i32 %iadd3_n1.278, 253
  %isetrp_cmp2.361 = or i1 %isetrp_cmp1.361, %isetrp_cmp1.360
  br label %BB_4490_6fd0

BB_4490_6fd0:                                     ; preds = %BB_4490_6f40
  %cond_not.226 = xor i1 %isetrp_cmp2.361, true
  br i1 %cond_not.226, label %BB_4490_80006fd0, label %BB_4490_6ff0

BB_4490_6ff0:                                     ; preds = %BB_4490_6fd0
  %fsetrp_lhs_fabs.135 = call float @llvm.nvvm.fabs.f(float %ffma.464)
  %fsetrp_cmp1.162 = fcmp ugt float %fsetrp_lhs_fabs.135, 0x7FF0000000000000
  %fsetrp_lhs_fabs.136 = call float @llvm.nvvm.fabs.f(float %lds.86)
  %fsetrp_cmp1.163 = fcmp ugt float %fsetrp_lhs_fabs.136, 0x7FF0000000000000
  %lop3_a_cast_zext.108 = zext i1 %fsetrp_cmp1.162 to i32
  %lop3_b_cast_zext.108 = zext i1 %fsetrp_cmp1.163 to i32
  %plop3_a_bit.108 = and i32 %lop3_a_cast_zext.108, 1
  %plop3_b_bit.108 = and i32 %lop3_b_cast_zext.108, 1
  %.9356 = xor i32 %plop3_a_bit.108, 1
  %.9357 = xor i32 %plop3_b_bit.108, 1
  %.9359 = and i32 %.9356, %plop3_b_bit.108
  %.9361 = and i32 %plop3_a_bit.108, %.9357
  %.9363 = or i32 %.9359, %.9361
  %.9364 = and i32 %plop3_a_bit.108, %plop3_b_bit.108
  %.9366 = or i32 %.9363, %.9364
  %lop3_pred_cmp.189 = icmp ne i32 %.9366, 0
  br label %BB_4490_7020

BB_4490_7020:                                     ; preds = %BB_4490_6ff0
  %402 = zext i1 %lop3_pred_cmp.189 to i32
  %403 = icmp ne i32 %402, 0
  br i1 %403, label %BB_4490_7580, label %BB_4490_7030

BB_4490_7030:                                     ; preds = %BB_4490_7020
  %.9369 = xor i32 %fchk_den_bits.27, -1
  %.9371 = xor i32 %fchk_num_bits.27, -1
  %.9372 = and i32 %.9369, 2147483647
  %.9373 = and i32 %.9372, %fchk_num_bits.27
  %.9375 = and i32 %fchk_aden.27, %.9371
  %.9376 = or i32 %.9373, %.9375
  %.9378 = and i32 %fchk_aden.27, %fchk_num_bits.27
  %.9379 = or i32 %.9376, %.9378
  %lop3_pred_cmp.190 = icmp ne i32 %.9379, 0
  br label %BB_4490_7040

BB_4490_7040:                                     ; preds = %BB_4490_7030
  %cond_not.227 = xor i1 %lop3_pred_cmp.190, true
  br i1 %cond_not.227, label %BB_4490_7560, label %BB_4490_7050

BB_4490_7050:                                     ; preds = %BB_4490_7040
  %fsetrp_cmp1.164 = fcmp une float %fsetrp_lhs_fabs.135, 0x7FF0000000000000
  %fsetrp_cmp1.165 = fcmp une float %fsetrp_lhs_fabs.136, 0x7FF0000000000000
  br label %BB_4490_7080

BB_4490_7080:                                     ; preds = %BB_4490_7050
  %cond_not.228 = xor i1 %fsetrp_cmp1.165, true
  br i1 %cond_not.228, label %BB_4490_80007080, label %BB_4490_7090

BB_4490_80007080:                                 ; preds = %BB_4490_7080
  %bra_cond_not.27 = xor i1 %fsetrp_cmp1.164, true
  br i1 %bra_cond_not.27, label %BB_4490_7560, label %BB_4490_7090

BB_4490_7090:                                     ; preds = %BB_4490_80007080, %BB_4490_7080
  %lop3_pred_cmp.191 = icmp ne i32 %fchk_anum.27, 0
  %lop3_a_cast_zext.109 = zext i1 %fsetrp_cmp1.165 to i32
  %lop3_b_cast_zext.109 = zext i1 %lop3_pred_cmp.191 to i32
  %plop3_a_bit.109 = and i32 %lop3_a_cast_zext.109, 1
  %plop3_b_bit.109 = and i32 %lop3_b_cast_zext.109, 1
  %.9393 = xor i32 %plop3_a_bit.109, 1
  %.9394 = xor i32 %plop3_b_bit.109, 1
  %.9396 = and i32 %.9393, %.9394
  %.9398 = and i32 %.9393, %plop3_b_bit.109
  %.9400 = or i32 %.9396, %.9398
  %.9401 = and i32 %plop3_a_bit.109, %.9394
  %.9403 = or i32 %.9400, %.9401
  %lop3_pred_cmp.192 = icmp ne i32 %.9403, 0
  br label %BB_4490_70b0

BB_4490_70b0:                                     ; preds = %BB_4490_7090
  %404 = zext i1 %lop3_pred_cmp.192 to i32
  %405 = icmp ne i32 %404, 0
  br i1 %405, label %BB_4490_7540, label %BB_4490_70c0

BB_4490_70c0:                                     ; preds = %BB_4490_70b0
  %lop3_pred_cmp.193 = icmp ne i32 %fchk_aden.27, 0
  %lop3_a_cast_zext.110 = zext i1 %fsetrp_cmp1.164 to i32
  %lop3_b_cast_zext.110 = zext i1 %lop3_pred_cmp.193 to i32
  %plop3_a_bit.110 = and i32 %lop3_a_cast_zext.110, 1
  %plop3_b_bit.110 = and i32 %lop3_b_cast_zext.110, 1
  %.9414 = xor i32 %plop3_a_bit.110, 1
  %.9415 = xor i32 %plop3_b_bit.110, 1
  %.9417 = and i32 %.9414, %.9415
  %.9419 = and i32 %.9414, %plop3_b_bit.110
  %.9421 = or i32 %.9417, %.9419
  %.9422 = and i32 %plop3_a_bit.110, %.9415
  %.9424 = or i32 %.9421, %.9422
  %lop3_pred_cmp.194 = icmp ne i32 %.9424, 0
  br label %BB_4490_70e0

BB_4490_70e0:                                     ; preds = %BB_4490_70c0
  %406 = zext i1 %lop3_pred_cmp.194 to i32
  %407 = icmp ne i32 %406, 0
  br i1 %407, label %BB_4490_7510, label %BB_4490_70f0

BB_4490_70f0:                                     ; preds = %BB_4490_70e0
  %isetrp_cmp1.362 = icmp sge i32 %iadd3_n1.278, 0
  %isetrp_cmp1.363 = icmp sge i32 %iadd3_n1.277, 0
  br label %BB_4490_7130

BB_4490_7130:                                     ; preds = %BB_4490_70f0
  %408 = zext i1 %isetrp_cmp1.362 to i32
  %409 = icmp ne i32 %408, 0
  br i1 %409, label %BB_4490_80007130, label %BB_4490_7140

BB_4490_80007130:                                 ; preds = %BB_4490_7130
  br label %BB_4490_7140

BB_4490_7140:                                     ; preds = %BB_4490_80007130, %BB_4490_7130
  %phi.436 = phi i32 [ 0, %BB_4490_80007130 ], [ %iadd3_n1.277, %BB_4490_7130 ]
  %cond_not.229 = xor i1 %isetrp_cmp1.362, true
  br i1 %cond_not.229, label %BB_4490_80007140, label %BB_4490_7160

BB_4490_80007140:                                 ; preds = %BB_4490_7140
  %ffma.470 = call float @llvm.fma.f32(float %ffma.464, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R261_bitcast = bitcast float %ffma.470 to i32
  br label %BB_4490_7160

BB_4490_7160:                                     ; preds = %BB_4490_80007140, %BB_4490_7140
  %phi.437 = phi i32 [ %phi_cast_R261_bitcast, %BB_4490_80007140 ], [ %fchk_num_bits.27, %BB_4490_7140 ]
  %phi.438 = phi i32 [ -64, %BB_4490_80007140 ], [ %phi.436, %BB_4490_7140 ]
  %cond_not.230 = xor i1 %isetrp_cmp1.363, true
  br i1 %cond_not.230, label %BB_4490_80007160, label %BB_4490_7180

BB_4490_80007160:                                 ; preds = %BB_4490_7160
  %ffma.471 = call float @llvm.fma.f32(float %lds.86, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.55 = add i32 %phi.438, 64
  %phi_cast_R814_bitcast = bitcast float %ffma.471 to i32
  br label %BB_4490_7180

BB_4490_7510:                                     ; preds = %BB_4490_70e0
  %.9437 = and i32 %.9369, -2147483648
  %.9438 = and i32 %.9437, %fchk_num_bits.27
  %.9439 = and i32 %fchk_den_bits.27, -2147483648
  %.9440 = and i32 %.9439, %.9371
  %.9441 = or i32 %.9438, %.9440
  %.9442 = xor i32 %.9441, -1
  %.9445 = and i32 %.9442, 2139095040
  %.9452 = or i32 %.9445, %.9441
  %phi_cast_R266_bitcast = bitcast i32 %.9452 to float
  br label %BB_4490_7590

BB_4490_7540:                                     ; preds = %BB_4490_70b0
  %.9466 = and i32 %.9369, -2147483648
  %.9467 = and i32 %.9466, %fchk_num_bits.27
  %.9468 = and i32 %fchk_den_bits.27, -2147483648
  %.9469 = and i32 %.9468, %.9371
  %.9470 = or i32 %.9467, %.9469
  %phi_cast_R267_bitcast = bitcast i32 %.9470 to float
  br label %BB_4490_7590

BB_4490_7560:                                     ; preds = %BB_4490_80007080, %BB_4490_7040
  %mufu_rsq.27 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_4490_7590

BB_4490_7580:                                     ; preds = %BB_4490_7020
  %fadd.54 = fadd float %ffma.464, %lds.86
  br label %BB_4490_7590

BB_4490_80006fd0:                                 ; preds = %BB_4490_6fd0
  br label %BB_4490_7180

BB_4490_7180:                                     ; preds = %BB_4490_80006fd0, %BB_4490_80007160, %BB_4490_7160
  %phi.439 = phi i32 [ %fchk_den_bits.27, %BB_4490_80006fd0 ], [ %phi_cast_R814_bitcast, %BB_4490_80007160 ], [ %fchk_den_bits.27, %BB_4490_7160 ]
  %phi.440 = phi i32 [ %fchk_num_bits.27, %BB_4490_80006fd0 ], [ %phi.437, %BB_4490_80007160 ], [ %phi.437, %BB_4490_7160 ]
  %phi.441 = phi i32 [ 0, %BB_4490_80006fd0 ], [ %viadd.55, %BB_4490_80007160 ], [ %phi.438, %BB_4490_7160 ]
  %.9475 = zext i32 %.9341 to i64
  %.9478 = shl i64 %.9475, 23
  %.9479 = and i64 %.9478, 4294967295
  %.9480 = add i64 %.9479, 3229614080
  %.9481 = trunc i64 %.9480 to i32
  %iadd3_n1.280 = add i32 %.9349, -127
  %iadd3_o1_not.54 = xor i32 %.9481, -1
  %iadd3_o1_neg.54 = add i32 %iadd3_o1_not.54, 1
  %iadd3_n1.281 = add i32 %iadd3_o1_neg.54, %phi.439
  %imad_tmp.102 = mul i32 %iadd3_n1.280, -8388608
  %imad.113 = add i32 %imad_tmp.102, %phi.440
  %mufu_src_bitcast.27 = bitcast i32 %iadd3_n1.281 to float
  %mufu_rcp.55 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.27)
  %fadd_lhs_fneg.27 = fneg float %mufu_src_bitcast.27
  %fadd.55 = fadd float %fadd_lhs_fneg.27, 0.000000e+00
  %iadd3_o3_not.27 = xor i32 %.9341, -1
  %iadd3_o3_neg.27 = add i32 %iadd3_o3_not.27, 1
  %iadd3_n2.282 = add i32 %.9349, %iadd3_o3_neg.27
  %iadd3_n1.283 = add i32 %iadd3_n2.282, %phi.441
  %ffma.472 = call float @llvm.fma.f32(float %mufu_rcp.55, float %fadd.55, float 1.000000e+00)
  %ffma.473 = call float @llvm.fma.f32(float %mufu_rcp.55, float %ffma.472, float %mufu_rcp.55)
  %ffma_lhs_bitcast.27 = bitcast i32 %imad.113 to float
  %ffma.474 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.27, float %ffma.473, float 0.000000e+00)
  %ffma.475 = call float @llvm.fma.f32(float %fadd.55, float %ffma.474, float %ffma_lhs_bitcast.27)
  %ffma.476 = call float @llvm.fma.f32(float %ffma.473, float %ffma.475, float %ffma.474)
  %ffma.477 = call float @llvm.fma.f32(float %fadd.55, float %ffma.476, float %ffma_lhs_bitcast.27)
  %ffma.478 = call float @llvm.fma.f32(float %ffma.473, float %ffma.477, float %ffma.476)
  %shf_hi_bitcast.83 = bitcast float %ffma.478 to i32
  %.9483 = zext i32 %shf_hi_bitcast.83 to i64
  %.9484 = shl i64 %.9483, 32
  %.9485 = lshr i64 %.9484, 23
  %shf_hi.142 = lshr i64 %.9485, 32
  %shf_result.170 = trunc i64 %shf_hi.142 to i32
  %.9489 = and i32 %shf_result.170, 255
  %imad.114 = add i32 %.9489, %iadd3_n1.283
  %iadd3_n1.284 = add i32 %imad.114, -1
  %isetrp_cmp1.364 = icmp uge i32 %iadd3_n1.284, 254
  br label %BB_4490_72d0

BB_4490_72d0:                                     ; preds = %BB_4490_7180
  %cond_not.231 = xor i1 %isetrp_cmp1.364, true
  br i1 %cond_not.231, label %BB_4490_74e0, label %BB_4490_72e0

BB_4490_72e0:                                     ; preds = %BB_4490_72d0
  %isetrp_cmp1.365 = icmp sgt i32 %imad.114, 254
  br label %BB_4490_72f0

BB_4490_72f0:                                     ; preds = %BB_4490_72e0
  %410 = zext i1 %isetrp_cmp1.365 to i32
  %411 = icmp ne i32 %410, 0
  br i1 %411, label %BB_4490_74b0, label %BB_4490_7300

BB_4490_7300:                                     ; preds = %BB_4490_72f0
  %isetrp_cmp1.366 = icmp sge i32 %imad.114, 1
  br label %BB_4490_7310

BB_4490_7310:                                     ; preds = %BB_4490_7300
  %phi_cast_R2281_bitcast.2 = bitcast i32 %iadd3_n1.283 to float
  br i1 %isetrp_cmp1.366, label %BB_4490_7590, label %BB_4490_7320

BB_4490_7320:                                     ; preds = %BB_4490_7310
  %isetrp_cmp1.367 = icmp sge i32 %imad.114, -24
  %.9503 = and i32 %shf_hi_bitcast.83, -2147483648
  br label %BB_4490_7340

BB_4490_7340:                                     ; preds = %BB_4490_7320
  %cond_not.232 = xor i1 %isetrp_cmp1.367, true
  %phi_cast_R274_bitcast = bitcast i32 %.9503 to float
  br i1 %cond_not.232, label %BB_4490_7590, label %BB_4490_7350

BB_4490_7350:                                     ; preds = %BB_4490_7340
  %ffma_rz.27 = call float @llvm.nvvm.fma.rz.f(float %ffma.473, float %ffma.477, float %ffma.476)
  %iadd3_n1.285 = add i32 %imad.114, 32
  %lop3_a_bitcast.222 = bitcast float %ffma_rz.27 to i32
  %.9513 = and i32 %lop3_a_bitcast.222, 8388607
  %ffma_rp.27 = call float @llvm.nvvm.fma.rp.f(float %ffma.473, float %ffma.477, float %ffma.476)
  %ffma_rm.27 = call float @llvm.nvvm.fma.rm.f(float %ffma.473, float %ffma.477, float %ffma.476)
  %isetrp_cmp1.369 = icmp ne i32 %imad.114, 0
  %.9528 = or i32 8388608, %.9513
  %iadd3_o1_not.55 = xor i32 %imad.114, -1
  %iadd3_o1_neg.55 = add i32 %iadd3_o1_not.55, 1
  %.9538 = zext i32 %.9528 to i64
  %shf_shift_64.171 = zext i32 %iadd3_n1.285 to i64
  %.9541 = shl i64 %.9538, %shf_shift_64.171
  %shf_result.171 = trunc i64 %.9541 to i32
  %fsetrp_cmp1.167 = fcmp une float %ffma_rp.27, %ffma_rm.27
  %isetrp_cmp1.370 = icmp ne i32 %shf_result.171, 0
  %isetrp_cmp2.370 = and i1 %isetrp_cmp1.370, %isetrp_cmp1.369
  %.9544 = shl i64 %.9538, 32
  %shf_shift_64.172 = zext i32 %iadd3_o1_neg.55 to i64
  %.9545 = lshr i64 %.9544, %shf_shift_64.172
  %shf_hi.143 = lshr i64 %.9545, 32
  %shf_result.172 = trunc i64 %shf_hi.143 to i32
  %lop3_a_cast_zext.111 = zext i1 %fsetrp_cmp1.167 to i32
  %lop3_b_cast_zext.111 = zext i1 %isetrp_cmp2.370 to i32
  %plop3_a_bit.111 = and i32 %lop3_a_cast_zext.111, 1
  %plop3_b_bit.111 = and i32 %lop3_b_cast_zext.111, 1
  %.9546 = xor i32 %plop3_a_bit.111, 1
  %.9547 = xor i32 %plop3_b_bit.111, 1
  %.9549 = and i32 %.9546, %plop3_b_bit.111
  %.9551 = and i32 %plop3_a_bit.111, %.9547
  %.9553 = or i32 %.9549, %.9551
  %.9554 = and i32 %plop3_a_bit.111, %plop3_b_bit.111
  %.9556 = or i32 %.9553, %.9554
  %lop3_pred_cmp.195 = icmp ne i32 %.9556, 0
  %.9558 = zext i32 %shf_result.172 to i64
  %.9559 = shl i64 %.9558, 32
  %.9560 = lshr i64 %.9559, 1
  %shf_hi.144 = lshr i64 %.9560, 32
  %shf_result.173 = trunc i64 %shf_hi.144 to i32
  %sel_pred_not.27 = xor i1 %lop3_pred_cmp.195, true
  %sel.55 = select i1 %sel_pred_not.27, i32 0, i32 1
  %.9561 = xor i32 %sel.55, -1
  %.9563 = xor i32 %shf_result.173, -1
  %.9564 = and i32 %.9561, 1
  %.9565 = and i32 %.9564, %shf_result.173
  %.9573 = and i32 %sel.55, %.9563
  %.9574 = or i32 %.9565, %.9573
  %.9576 = and i32 %sel.55, %shf_result.173
  %.9577 = or i32 %.9574, %.9576
  %.9581 = and i32 %.9577, %shf_result.172
  %imad.115 = add i32 %shf_result.173, %.9581
  %.9586 = xor i32 %imad.115, -1
  %.9587 = xor i32 %.9503, -1
  %.9589 = and i32 %.9586, %.9503
  %.9594 = and i32 %imad.115, %.9587
  %.9596 = or i32 %.9589, %.9594
  %.9600 = and i32 %imad.115, %.9503
  %.9602 = or i32 %.9596, %.9600
  %phi_cast_R275_bitcast = bitcast i32 %.9602 to float
  %phi_cast_R2283_bitcast = bitcast i32 %.9528 to float
  br label %BB_4490_7590

BB_4490_74b0:                                     ; preds = %BB_4490_72f0
  %.9610 = and i32 %shf_hi_bitcast.83, -2147483648
  %.9625 = or i32 2139095040, %.9610
  %phi_cast_R279_bitcast = bitcast i32 %.9625 to float
  %phi_cast_R2281_bitcast = bitcast i32 %iadd3_n1.283 to float
  br label %BB_4490_7590

BB_4490_74e0:                                     ; preds = %BB_4490_72d0
  %.9636 = zext i32 %iadd3_n1.283 to i64
  %.9639 = shl i64 %.9636, 23
  %.9640 = and i64 %.9639, 4294967295
  %.9641 = add i64 %.9640, %.9483
  %.9642 = trunc i64 %.9641 to i32
  %phi_cast_R281_bitcast = bitcast i32 %.9642 to float
  %phi_cast_R2281_bitcast.1 = bitcast i32 %iadd3_n1.283 to float
  br label %BB_4490_7590

BB_4490_7590:                                     ; preds = %BB_4490_74e0, %BB_4490_74b0, %BB_4490_7350, %BB_4490_7340, %BB_4490_7310, %BB_4490_7580, %BB_4490_7560, %BB_4490_7540, %BB_4490_7510
  %phi.442 = phi float [ %phi_cast_R275_bitcast, %BB_4490_7350 ], [ %phi_cast_R279_bitcast, %BB_4490_74b0 ], [ %phi_cast_R281_bitcast, %BB_4490_74e0 ], [ %ffma.478, %BB_4490_7310 ], [ %phi_cast_R274_bitcast, %BB_4490_7340 ], [ %phi_cast_R266_bitcast, %BB_4490_7510 ], [ %phi_cast_R267_bitcast, %BB_4490_7540 ], [ %mufu_rsq.27, %BB_4490_7560 ], [ %fadd.54, %BB_4490_7580 ]
  %phi.443 = phi float [ %phi_cast_R2283_bitcast, %BB_4490_7350 ], [ %phi_cast_R2281_bitcast, %BB_4490_74b0 ], [ %phi_cast_R2281_bitcast.1, %BB_4490_74e0 ], [ %phi_cast_R2281_bitcast.2, %BB_4490_7310 ], [ %phi_cast_R2281_bitcast.2, %BB_4490_7340 ], [ %phi.432, %BB_4490_7510 ], [ %phi.432, %BB_4490_7540 ], [ %phi.432, %BB_4490_7560 ], [ %phi.432, %BB_4490_7580 ]
  br label %BB_44b0

BB_44b0:                                          ; preds = %BB_4490_7590, %BB_4460
  %phi.444 = phi float [ %phi.442, %BB_4490_7590 ], [ %ffma.469, %BB_4460 ]
  %phi.445 = phi float [ %phi.443, %BB_4490_7590 ], [ %phi.432, %BB_4460 ]
  br label %BB_44d0

BB_44d0:                                          ; preds = %BB_44b0, %BB_4370
  %phi.446 = phi float [ %phi.444, %BB_44b0 ], [ %phi.431, %BB_4370 ]
  %phi.447 = phi float [ %phi.445, %BB_44b0 ], [ %phi.432, %BB_4370 ]
  %phi.448 = phi i32 [ %.75, %BB_44b0 ], [ %phi.433, %BB_4370 ]
  %phi.449 = phi float [ %phi.444, %BB_44b0 ], [ %phi.434, %BB_4370 ]
  br label %BB_4500

BB_4500:                                          ; preds = %BB_44d0
  %shfl_activemask.59 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.59 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.59, float %phi.449, i32 27, i32 31)
  br label %BB_4510

BB_4510:                                          ; preds = %BB_4500
  %isetrp_cmp1.371 = icmp uge i32 %tid_x, 28
  %isetrp_cmp1.372 = icmp ne i32 %tid_x, 28
  br label %BB_4540

BB_4540:                                          ; preds = %BB_4510
  %412 = zext i1 %isetrp_cmp1.371 to i32
  %413 = icmp ne i32 %412, 0
  br i1 %413, label %BB_80004540, label %BB_4560

BB_80004540:                                      ; preds = %BB_4540
  %lds_addr_memaddr_offset_add.84 = add i32 %.88, 3564
  %.9650 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.84
  %lds.87 = load volatile float, ptr addrspace(3) %.9650, align 4
  %ffma.479 = call float @llvm.fma.f32(float %shfl_idx.59, float %lds.87, float %phi.435)
  br label %BB_4560

BB_4560:                                          ; preds = %BB_80004540, %BB_4540
  %phi.450 = phi float [ %ffma.479, %BB_80004540 ], [ %phi.435, %BB_4540 ]
  %warp_reconv_mask.27 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.27)
  br i1 %isetrp_cmp1.372, label %BB_46c0, label %BB_4570

BB_4570:                                          ; preds = %BB_4560
  %ffma_addend_fneg.28 = fneg float %phi.450
  %ffma.480 = call float @llvm.fma.f32(float %phi.446, float %phi, float %ffma_addend_fneg.28)
  %lds_addr_memaddr_offset_add.85 = add i32 %.75, 3808
  %.9660 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.85
  %lds.88 = load volatile float, ptr addrspace(3) %.9660, align 4
  %mufu_rcp.56 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.88)
  %fchk_num_bits.28 = bitcast float %ffma.480 to i32
  %fchk_den_bits.28 = bitcast float %lds.88 to i32
  %fchk_aden.28 = and i32 %fchk_den_bits.28, 2147483647
  %fchk_anum.28 = and i32 %fchk_num_bits.28, 2147483647
  %fchk_den_subz.28 = icmp ult i32 %fchk_aden.28, 8388608
  %fchk_den_infnan.28 = icmp uge i32 %fchk_aden.28, 2139095040
  %fchk_num_infnan.28 = icmp uge i32 %fchk_anum.28, 2139095040
  %fchk_den_bad.28 = or i1 %fchk_den_subz.28, %fchk_den_infnan.28
  %fchk_px.28 = or i1 %fchk_den_bad.28, %fchk_num_infnan.28
  %ffma_lhs_fneg.56 = fneg float %lds.88
  %ffma.481 = call float @llvm.fma.f32(float %ffma_lhs_fneg.56, float %mufu_rcp.56, float 1.000000e+00)
  %ffma.482 = call float @llvm.fma.f32(float %mufu_rcp.56, float %ffma.481, float %mufu_rcp.56)
  %ffma.483 = call float @llvm.fma.f32(float %ffma.480, float %ffma.482, float 0.000000e+00)
  %ffma.484 = call float @llvm.fma.f32(float %ffma_lhs_fneg.56, float %ffma.483, float %ffma.480)
  %ffma.485 = call float @llvm.fma.f32(float %ffma.482, float %ffma.484, float %ffma.483)
  br label %BB_4650

BB_4650:                                          ; preds = %BB_4570
  %cond_not.233 = xor i1 %fchk_px.28, true
  br i1 %cond_not.233, label %BB_46a0, label %BB_4680_6f40

BB_4680_6f40:                                     ; preds = %BB_4650
  %.9664 = zext i32 %fchk_den_bits.28 to i64
  %.9665 = shl i64 %.9664, 32
  %.9666 = lshr i64 %.9665, 23
  %shf_hi.145 = lshr i64 %.9666, 32
  %shf_result.174 = trunc i64 %shf_hi.145 to i32
  %.9668 = zext i32 %fchk_num_bits.28 to i64
  %.9669 = shl i64 %.9668, 32
  %.9670 = lshr i64 %.9669, 23
  %shf_hi.146 = lshr i64 %.9670, 32
  %shf_result.175 = trunc i64 %shf_hi.146 to i32
  %.9674 = and i32 %shf_result.174, 255
  %.9682 = and i32 %shf_result.175, 255
  %iadd3_n1.287 = add i32 %.9674, -1
  %iadd3_n1.288 = add i32 %.9682, -1
  %isetrp_cmp1.373 = icmp ugt i32 %iadd3_n1.287, 253
  %isetrp_cmp1.374 = icmp ugt i32 %iadd3_n1.288, 253
  %isetrp_cmp2.374 = or i1 %isetrp_cmp1.374, %isetrp_cmp1.373
  br label %BB_4680_6fd0

BB_4680_6fd0:                                     ; preds = %BB_4680_6f40
  %cond_not.234 = xor i1 %isetrp_cmp2.374, true
  br i1 %cond_not.234, label %BB_4680_80006fd0, label %BB_4680_6ff0

BB_4680_6ff0:                                     ; preds = %BB_4680_6fd0
  %fsetrp_lhs_fabs.140 = call float @llvm.nvvm.fabs.f(float %ffma.480)
  %fsetrp_cmp1.168 = fcmp ugt float %fsetrp_lhs_fabs.140, 0x7FF0000000000000
  %fsetrp_lhs_fabs.141 = call float @llvm.nvvm.fabs.f(float %lds.88)
  %fsetrp_cmp1.169 = fcmp ugt float %fsetrp_lhs_fabs.141, 0x7FF0000000000000
  %lop3_a_cast_zext.112 = zext i1 %fsetrp_cmp1.168 to i32
  %lop3_b_cast_zext.112 = zext i1 %fsetrp_cmp1.169 to i32
  %plop3_a_bit.112 = and i32 %lop3_a_cast_zext.112, 1
  %plop3_b_bit.112 = and i32 %lop3_b_cast_zext.112, 1
  %.9689 = xor i32 %plop3_a_bit.112, 1
  %.9690 = xor i32 %plop3_b_bit.112, 1
  %.9692 = and i32 %.9689, %plop3_b_bit.112
  %.9694 = and i32 %plop3_a_bit.112, %.9690
  %.9696 = or i32 %.9692, %.9694
  %.9697 = and i32 %plop3_a_bit.112, %plop3_b_bit.112
  %.9699 = or i32 %.9696, %.9697
  %lop3_pred_cmp.196 = icmp ne i32 %.9699, 0
  br label %BB_4680_7020

BB_4680_7020:                                     ; preds = %BB_4680_6ff0
  %414 = zext i1 %lop3_pred_cmp.196 to i32
  %415 = icmp ne i32 %414, 0
  br i1 %415, label %BB_4680_7580, label %BB_4680_7030

BB_4680_7030:                                     ; preds = %BB_4680_7020
  %.9702 = xor i32 %fchk_den_bits.28, -1
  %.9704 = xor i32 %fchk_num_bits.28, -1
  %.9705 = and i32 %.9702, 2147483647
  %.9706 = and i32 %.9705, %fchk_num_bits.28
  %.9708 = and i32 %fchk_aden.28, %.9704
  %.9709 = or i32 %.9706, %.9708
  %.9711 = and i32 %fchk_aden.28, %fchk_num_bits.28
  %.9712 = or i32 %.9709, %.9711
  %lop3_pred_cmp.197 = icmp ne i32 %.9712, 0
  br label %BB_4680_7040

BB_4680_7040:                                     ; preds = %BB_4680_7030
  %cond_not.235 = xor i1 %lop3_pred_cmp.197, true
  br i1 %cond_not.235, label %BB_4680_7560, label %BB_4680_7050

BB_4680_7050:                                     ; preds = %BB_4680_7040
  %fsetrp_cmp1.170 = fcmp une float %fsetrp_lhs_fabs.140, 0x7FF0000000000000
  %fsetrp_cmp1.171 = fcmp une float %fsetrp_lhs_fabs.141, 0x7FF0000000000000
  br label %BB_4680_7080

BB_4680_7080:                                     ; preds = %BB_4680_7050
  %cond_not.236 = xor i1 %fsetrp_cmp1.171, true
  br i1 %cond_not.236, label %BB_4680_80007080, label %BB_4680_7090

BB_4680_80007080:                                 ; preds = %BB_4680_7080
  %bra_cond_not.28 = xor i1 %fsetrp_cmp1.170, true
  br i1 %bra_cond_not.28, label %BB_4680_7560, label %BB_4680_7090

BB_4680_7090:                                     ; preds = %BB_4680_80007080, %BB_4680_7080
  %lop3_pred_cmp.198 = icmp ne i32 %fchk_anum.28, 0
  %lop3_a_cast_zext.113 = zext i1 %fsetrp_cmp1.171 to i32
  %lop3_b_cast_zext.113 = zext i1 %lop3_pred_cmp.198 to i32
  %plop3_a_bit.113 = and i32 %lop3_a_cast_zext.113, 1
  %plop3_b_bit.113 = and i32 %lop3_b_cast_zext.113, 1
  %.9726 = xor i32 %plop3_a_bit.113, 1
  %.9727 = xor i32 %plop3_b_bit.113, 1
  %.9729 = and i32 %.9726, %.9727
  %.9731 = and i32 %.9726, %plop3_b_bit.113
  %.9733 = or i32 %.9729, %.9731
  %.9734 = and i32 %plop3_a_bit.113, %.9727
  %.9736 = or i32 %.9733, %.9734
  %lop3_pred_cmp.199 = icmp ne i32 %.9736, 0
  br label %BB_4680_70b0

BB_4680_70b0:                                     ; preds = %BB_4680_7090
  %416 = zext i1 %lop3_pred_cmp.199 to i32
  %417 = icmp ne i32 %416, 0
  br i1 %417, label %BB_4680_7540, label %BB_4680_70c0

BB_4680_70c0:                                     ; preds = %BB_4680_70b0
  %lop3_pred_cmp.200 = icmp ne i32 %fchk_aden.28, 0
  %lop3_a_cast_zext.114 = zext i1 %fsetrp_cmp1.170 to i32
  %lop3_b_cast_zext.114 = zext i1 %lop3_pred_cmp.200 to i32
  %plop3_a_bit.114 = and i32 %lop3_a_cast_zext.114, 1
  %plop3_b_bit.114 = and i32 %lop3_b_cast_zext.114, 1
  %.9747 = xor i32 %plop3_a_bit.114, 1
  %.9748 = xor i32 %plop3_b_bit.114, 1
  %.9750 = and i32 %.9747, %.9748
  %.9752 = and i32 %.9747, %plop3_b_bit.114
  %.9754 = or i32 %.9750, %.9752
  %.9755 = and i32 %plop3_a_bit.114, %.9748
  %.9757 = or i32 %.9754, %.9755
  %lop3_pred_cmp.201 = icmp ne i32 %.9757, 0
  br label %BB_4680_70e0

BB_4680_70e0:                                     ; preds = %BB_4680_70c0
  %418 = zext i1 %lop3_pred_cmp.201 to i32
  %419 = icmp ne i32 %418, 0
  br i1 %419, label %BB_4680_7510, label %BB_4680_70f0

BB_4680_70f0:                                     ; preds = %BB_4680_70e0
  %isetrp_cmp1.375 = icmp sge i32 %iadd3_n1.288, 0
  %isetrp_cmp1.376 = icmp sge i32 %iadd3_n1.287, 0
  br label %BB_4680_7130

BB_4680_7130:                                     ; preds = %BB_4680_70f0
  %420 = zext i1 %isetrp_cmp1.375 to i32
  %421 = icmp ne i32 %420, 0
  br i1 %421, label %BB_4680_80007130, label %BB_4680_7140

BB_4680_80007130:                                 ; preds = %BB_4680_7130
  br label %BB_4680_7140

BB_4680_7140:                                     ; preds = %BB_4680_80007130, %BB_4680_7130
  %phi.451 = phi i32 [ 0, %BB_4680_80007130 ], [ %iadd3_n1.287, %BB_4680_7130 ]
  %cond_not.237 = xor i1 %isetrp_cmp1.375, true
  br i1 %cond_not.237, label %BB_4680_80007140, label %BB_4680_7160

BB_4680_80007140:                                 ; preds = %BB_4680_7140
  %ffma.486 = call float @llvm.fma.f32(float %ffma.480, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R284_bitcast = bitcast float %ffma.486 to i32
  br label %BB_4680_7160

BB_4680_7160:                                     ; preds = %BB_4680_80007140, %BB_4680_7140
  %phi.452 = phi i32 [ %phi_cast_R284_bitcast, %BB_4680_80007140 ], [ %fchk_num_bits.28, %BB_4680_7140 ]
  %phi.453 = phi i32 [ -64, %BB_4680_80007140 ], [ %phi.451, %BB_4680_7140 ]
  %cond_not.238 = xor i1 %isetrp_cmp1.376, true
  br i1 %cond_not.238, label %BB_4680_80007160, label %BB_4680_7180

BB_4680_80007160:                                 ; preds = %BB_4680_7160
  %ffma.487 = call float @llvm.fma.f32(float %lds.88, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.57 = add i32 %phi.453, 64
  %phi_cast_R831_bitcast = bitcast float %ffma.487 to i32
  br label %BB_4680_7180

BB_4680_7510:                                     ; preds = %BB_4680_70e0
  %.9770 = and i32 %.9702, -2147483648
  %.9771 = and i32 %.9770, %fchk_num_bits.28
  %.9772 = and i32 %fchk_den_bits.28, -2147483648
  %.9773 = and i32 %.9772, %.9704
  %.9774 = or i32 %.9771, %.9773
  %.9775 = xor i32 %.9774, -1
  %.9778 = and i32 %.9775, 2139095040
  %.9785 = or i32 %.9778, %.9774
  %phi_cast_R288_bitcast = bitcast i32 %.9785 to float
  br label %BB_4680_7590

BB_4680_7540:                                     ; preds = %BB_4680_70b0
  %.9799 = and i32 %.9702, -2147483648
  %.9800 = and i32 %.9799, %fchk_num_bits.28
  %.9801 = and i32 %fchk_den_bits.28, -2147483648
  %.9802 = and i32 %.9801, %.9704
  %.9803 = or i32 %.9800, %.9802
  %phi_cast_R290_bitcast = bitcast i32 %.9803 to float
  br label %BB_4680_7590

BB_4680_7560:                                     ; preds = %BB_4680_80007080, %BB_4680_7040
  %mufu_rsq.28 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_4680_7590

BB_4680_7580:                                     ; preds = %BB_4680_7020
  %fadd.56 = fadd float %ffma.480, %lds.88
  br label %BB_4680_7590

BB_4680_80006fd0:                                 ; preds = %BB_4680_6fd0
  br label %BB_4680_7180

BB_4680_7180:                                     ; preds = %BB_4680_80006fd0, %BB_4680_80007160, %BB_4680_7160
  %phi.454 = phi i32 [ %fchk_den_bits.28, %BB_4680_80006fd0 ], [ %phi_cast_R831_bitcast, %BB_4680_80007160 ], [ %fchk_den_bits.28, %BB_4680_7160 ]
  %phi.455 = phi i32 [ %fchk_num_bits.28, %BB_4680_80006fd0 ], [ %phi.452, %BB_4680_80007160 ], [ %phi.452, %BB_4680_7160 ]
  %phi.456 = phi i32 [ 0, %BB_4680_80006fd0 ], [ %viadd.57, %BB_4680_80007160 ], [ %phi.453, %BB_4680_7160 ]
  %.9808 = zext i32 %.9674 to i64
  %.9811 = shl i64 %.9808, 23
  %.9812 = and i64 %.9811, 4294967295
  %.9813 = add i64 %.9812, 3229614080
  %.9814 = trunc i64 %.9813 to i32
  %iadd3_n1.290 = add i32 %.9682, -127
  %iadd3_o1_not.56 = xor i32 %.9814, -1
  %iadd3_o1_neg.56 = add i32 %iadd3_o1_not.56, 1
  %iadd3_n1.291 = add i32 %iadd3_o1_neg.56, %phi.454
  %imad_tmp.106 = mul i32 %iadd3_n1.290, -8388608
  %imad.117 = add i32 %imad_tmp.106, %phi.455
  %mufu_src_bitcast.28 = bitcast i32 %iadd3_n1.291 to float
  %mufu_rcp.57 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.28)
  %fadd_lhs_fneg.28 = fneg float %mufu_src_bitcast.28
  %fadd.57 = fadd float %fadd_lhs_fneg.28, 0.000000e+00
  %iadd3_o3_not.28 = xor i32 %.9674, -1
  %iadd3_o3_neg.28 = add i32 %iadd3_o3_not.28, 1
  %iadd3_n2.292 = add i32 %.9682, %iadd3_o3_neg.28
  %iadd3_n1.293 = add i32 %iadd3_n2.292, %phi.456
  %ffma.488 = call float @llvm.fma.f32(float %mufu_rcp.57, float %fadd.57, float 1.000000e+00)
  %ffma.489 = call float @llvm.fma.f32(float %mufu_rcp.57, float %ffma.488, float %mufu_rcp.57)
  %ffma_lhs_bitcast.28 = bitcast i32 %imad.117 to float
  %ffma.490 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.28, float %ffma.489, float 0.000000e+00)
  %ffma.491 = call float @llvm.fma.f32(float %fadd.57, float %ffma.490, float %ffma_lhs_bitcast.28)
  %ffma.492 = call float @llvm.fma.f32(float %ffma.489, float %ffma.491, float %ffma.490)
  %ffma.493 = call float @llvm.fma.f32(float %fadd.57, float %ffma.492, float %ffma_lhs_bitcast.28)
  %ffma.494 = call float @llvm.fma.f32(float %ffma.489, float %ffma.493, float %ffma.492)
  %shf_hi_bitcast.86 = bitcast float %ffma.494 to i32
  %.9816 = zext i32 %shf_hi_bitcast.86 to i64
  %.9817 = shl i64 %.9816, 32
  %.9818 = lshr i64 %.9817, 23
  %shf_hi.147 = lshr i64 %.9818, 32
  %shf_result.176 = trunc i64 %shf_hi.147 to i32
  %.9822 = and i32 %shf_result.176, 255
  %imad.118 = add i32 %.9822, %iadd3_n1.293
  %iadd3_n1.294 = add i32 %imad.118, -1
  %isetrp_cmp1.377 = icmp uge i32 %iadd3_n1.294, 254
  br label %BB_4680_72d0

BB_4680_72d0:                                     ; preds = %BB_4680_7180
  %cond_not.239 = xor i1 %isetrp_cmp1.377, true
  br i1 %cond_not.239, label %BB_4680_74e0, label %BB_4680_72e0

BB_4680_72e0:                                     ; preds = %BB_4680_72d0
  %isetrp_cmp1.378 = icmp sgt i32 %imad.118, 254
  br label %BB_4680_72f0

BB_4680_72f0:                                     ; preds = %BB_4680_72e0
  %422 = zext i1 %isetrp_cmp1.378 to i32
  %423 = icmp ne i32 %422, 0
  br i1 %423, label %BB_4680_74b0, label %BB_4680_7300

BB_4680_7300:                                     ; preds = %BB_4680_72f0
  %isetrp_cmp1.379 = icmp sge i32 %imad.118, 1
  br label %BB_4680_7310

BB_4680_7310:                                     ; preds = %BB_4680_7300
  %phi_cast_R2290_bitcast.2 = bitcast i32 %iadd3_n1.293 to float
  br i1 %isetrp_cmp1.379, label %BB_4680_7590, label %BB_4680_7320

BB_4680_7320:                                     ; preds = %BB_4680_7310
  %isetrp_cmp1.380 = icmp sge i32 %imad.118, -24
  %.9836 = and i32 %shf_hi_bitcast.86, -2147483648
  br label %BB_4680_7340

BB_4680_7340:                                     ; preds = %BB_4680_7320
  %cond_not.240 = xor i1 %isetrp_cmp1.380, true
  %phi_cast_R297_bitcast = bitcast i32 %.9836 to float
  br i1 %cond_not.240, label %BB_4680_7590, label %BB_4680_7350

BB_4680_7350:                                     ; preds = %BB_4680_7340
  %ffma_rz.28 = call float @llvm.nvvm.fma.rz.f(float %ffma.489, float %ffma.493, float %ffma.492)
  %iadd3_n1.295 = add i32 %imad.118, 32
  %lop3_a_bitcast.230 = bitcast float %ffma_rz.28 to i32
  %.9846 = and i32 %lop3_a_bitcast.230, 8388607
  %ffma_rp.28 = call float @llvm.nvvm.fma.rp.f(float %ffma.489, float %ffma.493, float %ffma.492)
  %ffma_rm.28 = call float @llvm.nvvm.fma.rm.f(float %ffma.489, float %ffma.493, float %ffma.492)
  %isetrp_cmp1.382 = icmp ne i32 %imad.118, 0
  %.9861 = or i32 8388608, %.9846
  %iadd3_o1_not.57 = xor i32 %imad.118, -1
  %iadd3_o1_neg.57 = add i32 %iadd3_o1_not.57, 1
  %.9871 = zext i32 %.9861 to i64
  %shf_shift_64.177 = zext i32 %iadd3_n1.295 to i64
  %.9874 = shl i64 %.9871, %shf_shift_64.177
  %shf_result.177 = trunc i64 %.9874 to i32
  %fsetrp_cmp1.173 = fcmp une float %ffma_rp.28, %ffma_rm.28
  %isetrp_cmp1.383 = icmp ne i32 %shf_result.177, 0
  %isetrp_cmp2.383 = and i1 %isetrp_cmp1.383, %isetrp_cmp1.382
  %.9877 = shl i64 %.9871, 32
  %shf_shift_64.178 = zext i32 %iadd3_o1_neg.57 to i64
  %.9878 = lshr i64 %.9877, %shf_shift_64.178
  %shf_hi.148 = lshr i64 %.9878, 32
  %shf_result.178 = trunc i64 %shf_hi.148 to i32
  %lop3_a_cast_zext.115 = zext i1 %fsetrp_cmp1.173 to i32
  %lop3_b_cast_zext.115 = zext i1 %isetrp_cmp2.383 to i32
  %plop3_a_bit.115 = and i32 %lop3_a_cast_zext.115, 1
  %plop3_b_bit.115 = and i32 %lop3_b_cast_zext.115, 1
  %.9879 = xor i32 %plop3_a_bit.115, 1
  %.9880 = xor i32 %plop3_b_bit.115, 1
  %.9882 = and i32 %.9879, %plop3_b_bit.115
  %.9884 = and i32 %plop3_a_bit.115, %.9880
  %.9886 = or i32 %.9882, %.9884
  %.9887 = and i32 %plop3_a_bit.115, %plop3_b_bit.115
  %.9889 = or i32 %.9886, %.9887
  %lop3_pred_cmp.202 = icmp ne i32 %.9889, 0
  %.9891 = zext i32 %shf_result.178 to i64
  %.9892 = shl i64 %.9891, 32
  %.9893 = lshr i64 %.9892, 1
  %shf_hi.149 = lshr i64 %.9893, 32
  %shf_result.179 = trunc i64 %shf_hi.149 to i32
  %sel_pred_not.28 = xor i1 %lop3_pred_cmp.202, true
  %sel.57 = select i1 %sel_pred_not.28, i32 0, i32 1
  %.9894 = xor i32 %sel.57, -1
  %.9896 = xor i32 %shf_result.179, -1
  %.9897 = and i32 %.9894, 1
  %.9898 = and i32 %.9897, %shf_result.179
  %.9906 = and i32 %sel.57, %.9896
  %.9907 = or i32 %.9898, %.9906
  %.9909 = and i32 %sel.57, %shf_result.179
  %.9910 = or i32 %.9907, %.9909
  %.9914 = and i32 %.9910, %shf_result.178
  %imad.119 = add i32 %shf_result.179, %.9914
  %.9919 = xor i32 %imad.119, -1
  %.9920 = xor i32 %.9836, -1
  %.9922 = and i32 %.9919, %.9836
  %.9927 = and i32 %imad.119, %.9920
  %.9929 = or i32 %.9922, %.9927
  %.9933 = and i32 %imad.119, %.9836
  %.9935 = or i32 %.9929, %.9933
  %phi_cast_R298_bitcast = bitcast i32 %.9935 to float
  %phi_cast_R2293_bitcast = bitcast i32 %.9861 to float
  br label %BB_4680_7590

BB_4680_74b0:                                     ; preds = %BB_4680_72f0
  %.9943 = and i32 %shf_hi_bitcast.86, -2147483648
  %.9958 = or i32 2139095040, %.9943
  %phi_cast_R301_bitcast = bitcast i32 %.9958 to float
  %phi_cast_R2290_bitcast = bitcast i32 %iadd3_n1.293 to float
  br label %BB_4680_7590

BB_4680_74e0:                                     ; preds = %BB_4680_72d0
  %.9969 = zext i32 %iadd3_n1.293 to i64
  %.9972 = shl i64 %.9969, 23
  %.9973 = and i64 %.9972, 4294967295
  %.9974 = add i64 %.9973, %.9816
  %.9975 = trunc i64 %.9974 to i32
  %phi_cast_R304_bitcast = bitcast i32 %.9975 to float
  %phi_cast_R2290_bitcast.1 = bitcast i32 %iadd3_n1.293 to float
  br label %BB_4680_7590

BB_4680_7590:                                     ; preds = %BB_4680_74e0, %BB_4680_74b0, %BB_4680_7350, %BB_4680_7340, %BB_4680_7310, %BB_4680_7580, %BB_4680_7560, %BB_4680_7540, %BB_4680_7510
  %phi.457 = phi float [ %phi_cast_R298_bitcast, %BB_4680_7350 ], [ %phi_cast_R301_bitcast, %BB_4680_74b0 ], [ %phi_cast_R304_bitcast, %BB_4680_74e0 ], [ %ffma.494, %BB_4680_7310 ], [ %phi_cast_R297_bitcast, %BB_4680_7340 ], [ %phi_cast_R288_bitcast, %BB_4680_7510 ], [ %phi_cast_R290_bitcast, %BB_4680_7540 ], [ %mufu_rsq.28, %BB_4680_7560 ], [ %fadd.56, %BB_4680_7580 ]
  %phi.458 = phi float [ %phi_cast_R2293_bitcast, %BB_4680_7350 ], [ %phi_cast_R2290_bitcast, %BB_4680_74b0 ], [ %phi_cast_R2290_bitcast.1, %BB_4680_74e0 ], [ %phi_cast_R2290_bitcast.2, %BB_4680_7310 ], [ %phi_cast_R2290_bitcast.2, %BB_4680_7340 ], [ %phi.447, %BB_4680_7510 ], [ %phi.447, %BB_4680_7540 ], [ %phi.447, %BB_4680_7560 ], [ %phi.447, %BB_4680_7580 ]
  br label %BB_46a0

BB_46a0:                                          ; preds = %BB_4680_7590, %BB_4650
  %phi.459 = phi float [ %phi.457, %BB_4680_7590 ], [ %ffma.485, %BB_4650 ]
  %phi.460 = phi float [ %phi.458, %BB_4680_7590 ], [ %phi.447, %BB_4650 ]
  br label %BB_46c0

BB_46c0:                                          ; preds = %BB_46a0, %BB_4560
  %phi.461 = phi float [ %phi.459, %BB_46a0 ], [ %phi.446, %BB_4560 ]
  %phi.462 = phi float [ %phi.460, %BB_46a0 ], [ %phi.447, %BB_4560 ]
  %phi.463 = phi i32 [ %.75, %BB_46a0 ], [ %phi.448, %BB_4560 ]
  %phi.464 = phi float [ %phi.459, %BB_46a0 ], [ %phi.449, %BB_4560 ]
  br label %BB_46f0

BB_46f0:                                          ; preds = %BB_46c0
  %shfl_activemask.60 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.60 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.60, float %phi.464, i32 28, i32 31)
  br label %BB_4700

BB_4700:                                          ; preds = %BB_46f0
  %isetrp_cmp1.384 = icmp uge i32 %tid_x, 29
  %isetrp_cmp1.385 = icmp ne i32 %tid_x, 29
  br label %BB_4730

BB_4730:                                          ; preds = %BB_4700
  %424 = zext i1 %isetrp_cmp1.384 to i32
  %425 = icmp ne i32 %424, 0
  br i1 %425, label %BB_80004730, label %BB_4750

BB_80004730:                                      ; preds = %BB_4730
  %lds_addr_memaddr_offset_add.86 = add i32 %.88, 3696
  %.9983 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.86
  %lds.89 = load volatile float, ptr addrspace(3) %.9983, align 4
  %ffma.495 = call float @llvm.fma.f32(float %shfl_idx.60, float %lds.89, float %phi.450)
  br label %BB_4750

BB_4750:                                          ; preds = %BB_80004730, %BB_4730
  %phi.465 = phi float [ %ffma.495, %BB_80004730 ], [ %phi.450, %BB_4730 ]
  %warp_reconv_mask.28 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.28)
  br i1 %isetrp_cmp1.385, label %BB_48b0, label %BB_4760

BB_4760:                                          ; preds = %BB_4750
  %ffma_addend_fneg.29 = fneg float %phi.465
  %ffma.496 = call float @llvm.fma.f32(float %phi.461, float %phi, float %ffma_addend_fneg.29)
  %lds_addr_memaddr_offset_add.87 = add i32 %.75, 3944
  %.9993 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.87
  %lds.90 = load volatile float, ptr addrspace(3) %.9993, align 4
  %mufu_rcp.58 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.90)
  %fchk_num_bits.29 = bitcast float %ffma.496 to i32
  %fchk_den_bits.29 = bitcast float %lds.90 to i32
  %fchk_aden.29 = and i32 %fchk_den_bits.29, 2147483647
  %fchk_anum.29 = and i32 %fchk_num_bits.29, 2147483647
  %fchk_den_subz.29 = icmp ult i32 %fchk_aden.29, 8388608
  %fchk_den_infnan.29 = icmp uge i32 %fchk_aden.29, 2139095040
  %fchk_num_infnan.29 = icmp uge i32 %fchk_anum.29, 2139095040
  %fchk_den_bad.29 = or i1 %fchk_den_subz.29, %fchk_den_infnan.29
  %fchk_px.29 = or i1 %fchk_den_bad.29, %fchk_num_infnan.29
  %ffma_lhs_fneg.58 = fneg float %lds.90
  %ffma.497 = call float @llvm.fma.f32(float %ffma_lhs_fneg.58, float %mufu_rcp.58, float 1.000000e+00)
  %ffma.498 = call float @llvm.fma.f32(float %mufu_rcp.58, float %ffma.497, float %mufu_rcp.58)
  %ffma.499 = call float @llvm.fma.f32(float %ffma.496, float %ffma.498, float 0.000000e+00)
  %ffma.500 = call float @llvm.fma.f32(float %ffma_lhs_fneg.58, float %ffma.499, float %ffma.496)
  %ffma.501 = call float @llvm.fma.f32(float %ffma.498, float %ffma.500, float %ffma.499)
  br label %BB_4840

BB_4840:                                          ; preds = %BB_4760
  %cond_not.241 = xor i1 %fchk_px.29, true
  br i1 %cond_not.241, label %BB_4890, label %BB_4870_6f40

BB_4870_6f40:                                     ; preds = %BB_4840
  %.9997 = zext i32 %fchk_den_bits.29 to i64
  %.9998 = shl i64 %.9997, 32
  %.9999 = lshr i64 %.9998, 23
  %shf_hi.150 = lshr i64 %.9999, 32
  %shf_result.180 = trunc i64 %shf_hi.150 to i32
  %.10001 = zext i32 %fchk_num_bits.29 to i64
  %.10002 = shl i64 %.10001, 32
  %.10003 = lshr i64 %.10002, 23
  %shf_hi.151 = lshr i64 %.10003, 32
  %shf_result.181 = trunc i64 %shf_hi.151 to i32
  %.10007 = and i32 %shf_result.180, 255
  %.10015 = and i32 %shf_result.181, 255
  %iadd3_n1.297 = add i32 %.10007, -1
  %iadd3_n1.298 = add i32 %.10015, -1
  %isetrp_cmp1.386 = icmp ugt i32 %iadd3_n1.297, 253
  %isetrp_cmp1.387 = icmp ugt i32 %iadd3_n1.298, 253
  %isetrp_cmp2.387 = or i1 %isetrp_cmp1.387, %isetrp_cmp1.386
  br label %BB_4870_6fd0

BB_4870_6fd0:                                     ; preds = %BB_4870_6f40
  %cond_not.242 = xor i1 %isetrp_cmp2.387, true
  br i1 %cond_not.242, label %BB_4870_80006fd0, label %BB_4870_6ff0

BB_4870_6ff0:                                     ; preds = %BB_4870_6fd0
  %fsetrp_lhs_fabs.145 = call float @llvm.nvvm.fabs.f(float %ffma.496)
  %fsetrp_cmp1.174 = fcmp ugt float %fsetrp_lhs_fabs.145, 0x7FF0000000000000
  %fsetrp_lhs_fabs.146 = call float @llvm.nvvm.fabs.f(float %lds.90)
  %fsetrp_cmp1.175 = fcmp ugt float %fsetrp_lhs_fabs.146, 0x7FF0000000000000
  %lop3_a_cast_zext.116 = zext i1 %fsetrp_cmp1.174 to i32
  %lop3_b_cast_zext.116 = zext i1 %fsetrp_cmp1.175 to i32
  %plop3_a_bit.116 = and i32 %lop3_a_cast_zext.116, 1
  %plop3_b_bit.116 = and i32 %lop3_b_cast_zext.116, 1
  %.10022 = xor i32 %plop3_a_bit.116, 1
  %.10023 = xor i32 %plop3_b_bit.116, 1
  %.10025 = and i32 %.10022, %plop3_b_bit.116
  %.10027 = and i32 %plop3_a_bit.116, %.10023
  %.10029 = or i32 %.10025, %.10027
  %.10030 = and i32 %plop3_a_bit.116, %plop3_b_bit.116
  %.10032 = or i32 %.10029, %.10030
  %lop3_pred_cmp.203 = icmp ne i32 %.10032, 0
  br label %BB_4870_7020

BB_4870_7020:                                     ; preds = %BB_4870_6ff0
  %426 = zext i1 %lop3_pred_cmp.203 to i32
  %427 = icmp ne i32 %426, 0
  br i1 %427, label %BB_4870_7580, label %BB_4870_7030

BB_4870_7030:                                     ; preds = %BB_4870_7020
  %.10035 = xor i32 %fchk_den_bits.29, -1
  %.10037 = xor i32 %fchk_num_bits.29, -1
  %.10038 = and i32 %.10035, 2147483647
  %.10039 = and i32 %.10038, %fchk_num_bits.29
  %.10041 = and i32 %fchk_aden.29, %.10037
  %.10042 = or i32 %.10039, %.10041
  %.10044 = and i32 %fchk_aden.29, %fchk_num_bits.29
  %.10045 = or i32 %.10042, %.10044
  %lop3_pred_cmp.204 = icmp ne i32 %.10045, 0
  br label %BB_4870_7040

BB_4870_7040:                                     ; preds = %BB_4870_7030
  %cond_not.243 = xor i1 %lop3_pred_cmp.204, true
  br i1 %cond_not.243, label %BB_4870_7560, label %BB_4870_7050

BB_4870_7050:                                     ; preds = %BB_4870_7040
  %fsetrp_cmp1.176 = fcmp une float %fsetrp_lhs_fabs.145, 0x7FF0000000000000
  %fsetrp_cmp1.177 = fcmp une float %fsetrp_lhs_fabs.146, 0x7FF0000000000000
  br label %BB_4870_7080

BB_4870_7080:                                     ; preds = %BB_4870_7050
  %cond_not.244 = xor i1 %fsetrp_cmp1.177, true
  br i1 %cond_not.244, label %BB_4870_80007080, label %BB_4870_7090

BB_4870_80007080:                                 ; preds = %BB_4870_7080
  %bra_cond_not.29 = xor i1 %fsetrp_cmp1.176, true
  br i1 %bra_cond_not.29, label %BB_4870_7560, label %BB_4870_7090

BB_4870_7090:                                     ; preds = %BB_4870_80007080, %BB_4870_7080
  %lop3_pred_cmp.205 = icmp ne i32 %fchk_anum.29, 0
  %lop3_a_cast_zext.117 = zext i1 %fsetrp_cmp1.177 to i32
  %lop3_b_cast_zext.117 = zext i1 %lop3_pred_cmp.205 to i32
  %plop3_a_bit.117 = and i32 %lop3_a_cast_zext.117, 1
  %plop3_b_bit.117 = and i32 %lop3_b_cast_zext.117, 1
  %.10059 = xor i32 %plop3_a_bit.117, 1
  %.10060 = xor i32 %plop3_b_bit.117, 1
  %.10062 = and i32 %.10059, %.10060
  %.10064 = and i32 %.10059, %plop3_b_bit.117
  %.10066 = or i32 %.10062, %.10064
  %.10067 = and i32 %plop3_a_bit.117, %.10060
  %.10069 = or i32 %.10066, %.10067
  %lop3_pred_cmp.206 = icmp ne i32 %.10069, 0
  br label %BB_4870_70b0

BB_4870_70b0:                                     ; preds = %BB_4870_7090
  %428 = zext i1 %lop3_pred_cmp.206 to i32
  %429 = icmp ne i32 %428, 0
  br i1 %429, label %BB_4870_7540, label %BB_4870_70c0

BB_4870_70c0:                                     ; preds = %BB_4870_70b0
  %lop3_pred_cmp.207 = icmp ne i32 %fchk_aden.29, 0
  %lop3_a_cast_zext.118 = zext i1 %fsetrp_cmp1.176 to i32
  %lop3_b_cast_zext.118 = zext i1 %lop3_pred_cmp.207 to i32
  %plop3_a_bit.118 = and i32 %lop3_a_cast_zext.118, 1
  %plop3_b_bit.118 = and i32 %lop3_b_cast_zext.118, 1
  %.10080 = xor i32 %plop3_a_bit.118, 1
  %.10081 = xor i32 %plop3_b_bit.118, 1
  %.10083 = and i32 %.10080, %.10081
  %.10085 = and i32 %.10080, %plop3_b_bit.118
  %.10087 = or i32 %.10083, %.10085
  %.10088 = and i32 %plop3_a_bit.118, %.10081
  %.10090 = or i32 %.10087, %.10088
  %lop3_pred_cmp.208 = icmp ne i32 %.10090, 0
  br label %BB_4870_70e0

BB_4870_70e0:                                     ; preds = %BB_4870_70c0
  %430 = zext i1 %lop3_pred_cmp.208 to i32
  %431 = icmp ne i32 %430, 0
  br i1 %431, label %BB_4870_7510, label %BB_4870_70f0

BB_4870_70f0:                                     ; preds = %BB_4870_70e0
  %isetrp_cmp1.388 = icmp sge i32 %iadd3_n1.298, 0
  %isetrp_cmp1.389 = icmp sge i32 %iadd3_n1.297, 0
  br label %BB_4870_7130

BB_4870_7130:                                     ; preds = %BB_4870_70f0
  %432 = zext i1 %isetrp_cmp1.388 to i32
  %433 = icmp ne i32 %432, 0
  br i1 %433, label %BB_4870_80007130, label %BB_4870_7140

BB_4870_80007130:                                 ; preds = %BB_4870_7130
  br label %BB_4870_7140

BB_4870_7140:                                     ; preds = %BB_4870_80007130, %BB_4870_7130
  %phi.466 = phi i32 [ 0, %BB_4870_80007130 ], [ %iadd3_n1.297, %BB_4870_7130 ]
  %cond_not.245 = xor i1 %isetrp_cmp1.388, true
  br i1 %cond_not.245, label %BB_4870_80007140, label %BB_4870_7160

BB_4870_80007140:                                 ; preds = %BB_4870_7140
  %ffma.502 = call float @llvm.fma.f32(float %ffma.496, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R307_bitcast = bitcast float %ffma.502 to i32
  br label %BB_4870_7160

BB_4870_7160:                                     ; preds = %BB_4870_80007140, %BB_4870_7140
  %phi.467 = phi i32 [ %phi_cast_R307_bitcast, %BB_4870_80007140 ], [ %fchk_num_bits.29, %BB_4870_7140 ]
  %phi.468 = phi i32 [ -64, %BB_4870_80007140 ], [ %phi.466, %BB_4870_7140 ]
  %cond_not.246 = xor i1 %isetrp_cmp1.389, true
  br i1 %cond_not.246, label %BB_4870_80007160, label %BB_4870_7180

BB_4870_80007160:                                 ; preds = %BB_4870_7160
  %ffma.503 = call float @llvm.fma.f32(float %lds.90, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.59 = add i32 %phi.468, 64
  %phi_cast_R851_bitcast = bitcast float %ffma.503 to i32
  br label %BB_4870_7180

BB_4870_7510:                                     ; preds = %BB_4870_70e0
  %.10103 = and i32 %.10035, -2147483648
  %.10104 = and i32 %.10103, %fchk_num_bits.29
  %.10105 = and i32 %fchk_den_bits.29, -2147483648
  %.10106 = and i32 %.10105, %.10037
  %.10107 = or i32 %.10104, %.10106
  %.10108 = xor i32 %.10107, -1
  %.10111 = and i32 %.10108, 2139095040
  %.10118 = or i32 %.10111, %.10107
  %phi_cast_R311_bitcast = bitcast i32 %.10118 to float
  br label %BB_4870_7590

BB_4870_7540:                                     ; preds = %BB_4870_70b0
  %.10132 = and i32 %.10035, -2147483648
  %.10133 = and i32 %.10132, %fchk_num_bits.29
  %.10134 = and i32 %fchk_den_bits.29, -2147483648
  %.10135 = and i32 %.10134, %.10037
  %.10136 = or i32 %.10133, %.10135
  %phi_cast_R312_bitcast = bitcast i32 %.10136 to float
  br label %BB_4870_7590

BB_4870_7560:                                     ; preds = %BB_4870_80007080, %BB_4870_7040
  %mufu_rsq.29 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_4870_7590

BB_4870_7580:                                     ; preds = %BB_4870_7020
  %fadd.58 = fadd float %ffma.496, %lds.90
  br label %BB_4870_7590

BB_4870_80006fd0:                                 ; preds = %BB_4870_6fd0
  br label %BB_4870_7180

BB_4870_7180:                                     ; preds = %BB_4870_80006fd0, %BB_4870_80007160, %BB_4870_7160
  %phi.469 = phi i32 [ %fchk_den_bits.29, %BB_4870_80006fd0 ], [ %phi_cast_R851_bitcast, %BB_4870_80007160 ], [ %fchk_den_bits.29, %BB_4870_7160 ]
  %phi.470 = phi i32 [ %fchk_num_bits.29, %BB_4870_80006fd0 ], [ %phi.467, %BB_4870_80007160 ], [ %phi.467, %BB_4870_7160 ]
  %phi.471 = phi i32 [ 0, %BB_4870_80006fd0 ], [ %viadd.59, %BB_4870_80007160 ], [ %phi.468, %BB_4870_7160 ]
  %.10141 = zext i32 %.10007 to i64
  %.10144 = shl i64 %.10141, 23
  %.10145 = and i64 %.10144, 4294967295
  %.10146 = add i64 %.10145, 3229614080
  %.10147 = trunc i64 %.10146 to i32
  %iadd3_n1.300 = add i32 %.10015, -127
  %iadd3_o1_not.58 = xor i32 %.10147, -1
  %iadd3_o1_neg.58 = add i32 %iadd3_o1_not.58, 1
  %iadd3_n1.301 = add i32 %iadd3_o1_neg.58, %phi.469
  %imad_tmp.109 = mul i32 %iadd3_n1.300, -8388608
  %imad.120 = add i32 %imad_tmp.109, %phi.470
  %mufu_src_bitcast.29 = bitcast i32 %iadd3_n1.301 to float
  %mufu_rcp.59 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.29)
  %fadd_lhs_fneg.29 = fneg float %mufu_src_bitcast.29
  %fadd.59 = fadd float %fadd_lhs_fneg.29, 0.000000e+00
  %iadd3_o3_not.29 = xor i32 %.10007, -1
  %iadd3_o3_neg.29 = add i32 %iadd3_o3_not.29, 1
  %iadd3_n2.302 = add i32 %.10015, %iadd3_o3_neg.29
  %iadd3_n1.303 = add i32 %iadd3_n2.302, %phi.471
  %ffma.504 = call float @llvm.fma.f32(float %mufu_rcp.59, float %fadd.59, float 1.000000e+00)
  %ffma.505 = call float @llvm.fma.f32(float %mufu_rcp.59, float %ffma.504, float %mufu_rcp.59)
  %ffma_lhs_bitcast.29 = bitcast i32 %imad.120 to float
  %ffma.506 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.29, float %ffma.505, float 0.000000e+00)
  %ffma.507 = call float @llvm.fma.f32(float %fadd.59, float %ffma.506, float %ffma_lhs_bitcast.29)
  %ffma.508 = call float @llvm.fma.f32(float %ffma.505, float %ffma.507, float %ffma.506)
  %ffma.509 = call float @llvm.fma.f32(float %fadd.59, float %ffma.508, float %ffma_lhs_bitcast.29)
  %ffma.510 = call float @llvm.fma.f32(float %ffma.505, float %ffma.509, float %ffma.508)
  %shf_hi_bitcast.89 = bitcast float %ffma.510 to i32
  %.10149 = zext i32 %shf_hi_bitcast.89 to i64
  %.10150 = shl i64 %.10149, 32
  %.10151 = lshr i64 %.10150, 23
  %shf_hi.152 = lshr i64 %.10151, 32
  %shf_result.182 = trunc i64 %shf_hi.152 to i32
  %.10155 = and i32 %shf_result.182, 255
  %imad.121 = add i32 %.10155, %iadd3_n1.303
  %iadd3_n1.304 = add i32 %imad.121, -1
  %isetrp_cmp1.390 = icmp uge i32 %iadd3_n1.304, 254
  br label %BB_4870_72d0

BB_4870_72d0:                                     ; preds = %BB_4870_7180
  %cond_not.247 = xor i1 %isetrp_cmp1.390, true
  br i1 %cond_not.247, label %BB_4870_74e0, label %BB_4870_72e0

BB_4870_72e0:                                     ; preds = %BB_4870_72d0
  %isetrp_cmp1.391 = icmp sgt i32 %imad.121, 254
  br label %BB_4870_72f0

BB_4870_72f0:                                     ; preds = %BB_4870_72e0
  %434 = zext i1 %isetrp_cmp1.391 to i32
  %435 = icmp ne i32 %434, 0
  br i1 %435, label %BB_4870_74b0, label %BB_4870_7300

BB_4870_7300:                                     ; preds = %BB_4870_72f0
  %isetrp_cmp1.392 = icmp sge i32 %imad.121, 1
  br label %BB_4870_7310

BB_4870_7310:                                     ; preds = %BB_4870_7300
  %phi_cast_R2300_bitcast.2 = bitcast i32 %iadd3_n1.303 to float
  br i1 %isetrp_cmp1.392, label %BB_4870_7590, label %BB_4870_7320

BB_4870_7320:                                     ; preds = %BB_4870_7310
  %isetrp_cmp1.393 = icmp sge i32 %imad.121, -24
  %.10169 = and i32 %shf_hi_bitcast.89, -2147483648
  br label %BB_4870_7340

BB_4870_7340:                                     ; preds = %BB_4870_7320
  %cond_not.248 = xor i1 %isetrp_cmp1.393, true
  %phi_cast_R320_bitcast = bitcast i32 %.10169 to float
  br i1 %cond_not.248, label %BB_4870_7590, label %BB_4870_7350

BB_4870_7350:                                     ; preds = %BB_4870_7340
  %ffma_rz.29 = call float @llvm.nvvm.fma.rz.f(float %ffma.505, float %ffma.509, float %ffma.508)
  %iadd3_n1.305 = add i32 %imad.121, 32
  %lop3_a_bitcast.238 = bitcast float %ffma_rz.29 to i32
  %.10179 = and i32 %lop3_a_bitcast.238, 8388607
  %ffma_rp.29 = call float @llvm.nvvm.fma.rp.f(float %ffma.505, float %ffma.509, float %ffma.508)
  %ffma_rm.29 = call float @llvm.nvvm.fma.rm.f(float %ffma.505, float %ffma.509, float %ffma.508)
  %isetrp_cmp1.395 = icmp ne i32 %imad.121, 0
  %.10194 = or i32 8388608, %.10179
  %iadd3_o1_not.59 = xor i32 %imad.121, -1
  %iadd3_o1_neg.59 = add i32 %iadd3_o1_not.59, 1
  %.10204 = zext i32 %.10194 to i64
  %shf_shift_64.183 = zext i32 %iadd3_n1.305 to i64
  %.10207 = shl i64 %.10204, %shf_shift_64.183
  %shf_result.183 = trunc i64 %.10207 to i32
  %fsetrp_cmp1.179 = fcmp une float %ffma_rp.29, %ffma_rm.29
  %isetrp_cmp1.396 = icmp ne i32 %shf_result.183, 0
  %isetrp_cmp2.396 = and i1 %isetrp_cmp1.396, %isetrp_cmp1.395
  %.10210 = shl i64 %.10204, 32
  %shf_shift_64.184 = zext i32 %iadd3_o1_neg.59 to i64
  %.10211 = lshr i64 %.10210, %shf_shift_64.184
  %shf_hi.153 = lshr i64 %.10211, 32
  %shf_result.184 = trunc i64 %shf_hi.153 to i32
  %lop3_a_cast_zext.119 = zext i1 %fsetrp_cmp1.179 to i32
  %lop3_b_cast_zext.119 = zext i1 %isetrp_cmp2.396 to i32
  %plop3_a_bit.119 = and i32 %lop3_a_cast_zext.119, 1
  %plop3_b_bit.119 = and i32 %lop3_b_cast_zext.119, 1
  %.10212 = xor i32 %plop3_a_bit.119, 1
  %.10213 = xor i32 %plop3_b_bit.119, 1
  %.10215 = and i32 %.10212, %plop3_b_bit.119
  %.10217 = and i32 %plop3_a_bit.119, %.10213
  %.10219 = or i32 %.10215, %.10217
  %.10220 = and i32 %plop3_a_bit.119, %plop3_b_bit.119
  %.10222 = or i32 %.10219, %.10220
  %lop3_pred_cmp.209 = icmp ne i32 %.10222, 0
  %.10224 = zext i32 %shf_result.184 to i64
  %.10225 = shl i64 %.10224, 32
  %.10226 = lshr i64 %.10225, 1
  %shf_hi.154 = lshr i64 %.10226, 32
  %shf_result.185 = trunc i64 %shf_hi.154 to i32
  %sel_pred_not.29 = xor i1 %lop3_pred_cmp.209, true
  %sel.59 = select i1 %sel_pred_not.29, i32 0, i32 1
  %.10227 = xor i32 %sel.59, -1
  %.10229 = xor i32 %shf_result.185, -1
  %.10230 = and i32 %.10227, 1
  %.10231 = and i32 %.10230, %shf_result.185
  %.10239 = and i32 %sel.59, %.10229
  %.10240 = or i32 %.10231, %.10239
  %.10242 = and i32 %sel.59, %shf_result.185
  %.10243 = or i32 %.10240, %.10242
  %.10247 = and i32 %.10243, %shf_result.184
  %imad.122 = add i32 %shf_result.185, %.10247
  %.10252 = xor i32 %imad.122, -1
  %.10253 = xor i32 %.10169, -1
  %.10255 = and i32 %.10252, %.10169
  %.10260 = and i32 %imad.122, %.10253
  %.10262 = or i32 %.10255, %.10260
  %.10266 = and i32 %imad.122, %.10169
  %.10268 = or i32 %.10262, %.10266
  %phi_cast_R322_bitcast = bitcast i32 %.10268 to float
  %phi_cast_R2303_bitcast = bitcast i32 %.10194 to float
  br label %BB_4870_7590

BB_4870_74b0:                                     ; preds = %BB_4870_72f0
  %.10276 = and i32 %shf_hi_bitcast.89, -2147483648
  %.10291 = or i32 2139095040, %.10276
  %phi_cast_R325_bitcast = bitcast i32 %.10291 to float
  %phi_cast_R2300_bitcast = bitcast i32 %iadd3_n1.303 to float
  br label %BB_4870_7590

BB_4870_74e0:                                     ; preds = %BB_4870_72d0
  %.10302 = zext i32 %iadd3_n1.303 to i64
  %.10305 = shl i64 %.10302, 23
  %.10306 = and i64 %.10305, 4294967295
  %.10307 = add i64 %.10306, %.10149
  %.10308 = trunc i64 %.10307 to i32
  %phi_cast_R326_bitcast = bitcast i32 %.10308 to float
  %phi_cast_R2300_bitcast.1 = bitcast i32 %iadd3_n1.303 to float
  br label %BB_4870_7590

BB_4870_7590:                                     ; preds = %BB_4870_74e0, %BB_4870_74b0, %BB_4870_7350, %BB_4870_7340, %BB_4870_7310, %BB_4870_7580, %BB_4870_7560, %BB_4870_7540, %BB_4870_7510
  %phi.472 = phi float [ %phi_cast_R322_bitcast, %BB_4870_7350 ], [ %phi_cast_R325_bitcast, %BB_4870_74b0 ], [ %phi_cast_R326_bitcast, %BB_4870_74e0 ], [ %ffma.510, %BB_4870_7310 ], [ %phi_cast_R320_bitcast, %BB_4870_7340 ], [ %phi_cast_R311_bitcast, %BB_4870_7510 ], [ %phi_cast_R312_bitcast, %BB_4870_7540 ], [ %mufu_rsq.29, %BB_4870_7560 ], [ %fadd.58, %BB_4870_7580 ]
  %phi.473 = phi float [ %phi_cast_R2303_bitcast, %BB_4870_7350 ], [ %phi_cast_R2300_bitcast, %BB_4870_74b0 ], [ %phi_cast_R2300_bitcast.1, %BB_4870_74e0 ], [ %phi_cast_R2300_bitcast.2, %BB_4870_7310 ], [ %phi_cast_R2300_bitcast.2, %BB_4870_7340 ], [ %phi.462, %BB_4870_7510 ], [ %phi.462, %BB_4870_7540 ], [ %phi.462, %BB_4870_7560 ], [ %phi.462, %BB_4870_7580 ]
  br label %BB_4890

BB_4890:                                          ; preds = %BB_4870_7590, %BB_4840
  %phi.474 = phi float [ %phi.472, %BB_4870_7590 ], [ %ffma.501, %BB_4840 ]
  %phi.475 = phi float [ %phi.473, %BB_4870_7590 ], [ %phi.462, %BB_4840 ]
  br label %BB_48b0

BB_48b0:                                          ; preds = %BB_4890, %BB_4750
  %phi.476 = phi float [ %phi.474, %BB_4890 ], [ %phi.461, %BB_4750 ]
  %phi.477 = phi float [ %phi.475, %BB_4890 ], [ %phi.462, %BB_4750 ]
  %phi.478 = phi i32 [ %.75, %BB_4890 ], [ %phi.463, %BB_4750 ]
  %phi.479 = phi float [ %phi.474, %BB_4890 ], [ %phi.464, %BB_4750 ]
  br label %BB_48e0

BB_48e0:                                          ; preds = %BB_48b0
  %shfl_activemask.61 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.61 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.61, float %phi.479, i32 29, i32 31)
  br label %BB_48f0

BB_48f0:                                          ; preds = %BB_48e0
  %isetrp_cmp1.397 = icmp uge i32 %tid_x, 30
  %isetrp_cmp1.398 = icmp ne i32 %tid_x, 30
  br label %BB_4920

BB_4920:                                          ; preds = %BB_48f0
  %436 = zext i1 %isetrp_cmp1.397 to i32
  %437 = icmp ne i32 %436, 0
  br i1 %437, label %BB_80004920, label %BB_4940

BB_80004920:                                      ; preds = %BB_4920
  %lds_addr_memaddr_offset_add.88 = add i32 %.88, 3828
  %.10316 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.88
  %lds.91 = load volatile float, ptr addrspace(3) %.10316, align 4
  %ffma.511 = call float @llvm.fma.f32(float %shfl_idx.61, float %lds.91, float %phi.465)
  br label %BB_4940

BB_4940:                                          ; preds = %BB_80004920, %BB_4920
  %phi.480 = phi float [ %ffma.511, %BB_80004920 ], [ %phi.465, %BB_4920 ]
  %warp_reconv_mask.29 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.29)
  br i1 %isetrp_cmp1.398, label %BB_4aa0, label %BB_4950

BB_4950:                                          ; preds = %BB_4940
  %ffma_addend_fneg.30 = fneg float %phi.480
  %ffma.512 = call float @llvm.fma.f32(float %phi.476, float %phi, float %ffma_addend_fneg.30)
  %lds_addr_memaddr_offset_add.89 = add i32 %.75, 4080
  %.10326 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.89
  %lds.92 = load volatile float, ptr addrspace(3) %.10326, align 4
  %mufu_rcp.60 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.92)
  %fchk_num_bits.30 = bitcast float %ffma.512 to i32
  %fchk_den_bits.30 = bitcast float %lds.92 to i32
  %fchk_aden.30 = and i32 %fchk_den_bits.30, 2147483647
  %fchk_anum.30 = and i32 %fchk_num_bits.30, 2147483647
  %fchk_den_subz.30 = icmp ult i32 %fchk_aden.30, 8388608
  %fchk_den_infnan.30 = icmp uge i32 %fchk_aden.30, 2139095040
  %fchk_num_infnan.30 = icmp uge i32 %fchk_anum.30, 2139095040
  %fchk_den_bad.30 = or i1 %fchk_den_subz.30, %fchk_den_infnan.30
  %fchk_px.30 = or i1 %fchk_den_bad.30, %fchk_num_infnan.30
  %ffma_lhs_fneg.60 = fneg float %lds.92
  %ffma.513 = call float @llvm.fma.f32(float %ffma_lhs_fneg.60, float %mufu_rcp.60, float 1.000000e+00)
  %ffma.514 = call float @llvm.fma.f32(float %mufu_rcp.60, float %ffma.513, float %mufu_rcp.60)
  %ffma.515 = call float @llvm.fma.f32(float %ffma.512, float %ffma.514, float 0.000000e+00)
  %ffma.516 = call float @llvm.fma.f32(float %ffma_lhs_fneg.60, float %ffma.515, float %ffma.512)
  %ffma.517 = call float @llvm.fma.f32(float %ffma.514, float %ffma.516, float %ffma.515)
  br label %BB_4a30

BB_4a30:                                          ; preds = %BB_4950
  %cond_not.249 = xor i1 %fchk_px.30, true
  br i1 %cond_not.249, label %BB_4a80, label %BB_4a60_6f40

BB_4a60_6f40:                                     ; preds = %BB_4a30
  %.10330 = zext i32 %fchk_den_bits.30 to i64
  %.10331 = shl i64 %.10330, 32
  %.10332 = lshr i64 %.10331, 23
  %shf_hi.155 = lshr i64 %.10332, 32
  %shf_result.186 = trunc i64 %shf_hi.155 to i32
  %.10334 = zext i32 %fchk_num_bits.30 to i64
  %.10335 = shl i64 %.10334, 32
  %.10336 = lshr i64 %.10335, 23
  %shf_hi.156 = lshr i64 %.10336, 32
  %shf_result.187 = trunc i64 %shf_hi.156 to i32
  %.10340 = and i32 %shf_result.186, 255
  %.10348 = and i32 %shf_result.187, 255
  %iadd3_n1.307 = add i32 %.10340, -1
  %iadd3_n1.308 = add i32 %.10348, -1
  %isetrp_cmp1.399 = icmp ugt i32 %iadd3_n1.307, 253
  %isetrp_cmp1.400 = icmp ugt i32 %iadd3_n1.308, 253
  %isetrp_cmp2.400 = or i1 %isetrp_cmp1.400, %isetrp_cmp1.399
  br label %BB_4a60_6fd0

BB_4a60_6fd0:                                     ; preds = %BB_4a60_6f40
  %cond_not.250 = xor i1 %isetrp_cmp2.400, true
  br i1 %cond_not.250, label %BB_4a60_80006fd0, label %BB_4a60_6ff0

BB_4a60_6ff0:                                     ; preds = %BB_4a60_6fd0
  %fsetrp_lhs_fabs.150 = call float @llvm.nvvm.fabs.f(float %ffma.512)
  %fsetrp_cmp1.180 = fcmp ugt float %fsetrp_lhs_fabs.150, 0x7FF0000000000000
  %fsetrp_lhs_fabs.151 = call float @llvm.nvvm.fabs.f(float %lds.92)
  %fsetrp_cmp1.181 = fcmp ugt float %fsetrp_lhs_fabs.151, 0x7FF0000000000000
  %lop3_a_cast_zext.120 = zext i1 %fsetrp_cmp1.180 to i32
  %lop3_b_cast_zext.120 = zext i1 %fsetrp_cmp1.181 to i32
  %plop3_a_bit.120 = and i32 %lop3_a_cast_zext.120, 1
  %plop3_b_bit.120 = and i32 %lop3_b_cast_zext.120, 1
  %.10355 = xor i32 %plop3_a_bit.120, 1
  %.10356 = xor i32 %plop3_b_bit.120, 1
  %.10358 = and i32 %.10355, %plop3_b_bit.120
  %.10360 = and i32 %plop3_a_bit.120, %.10356
  %.10362 = or i32 %.10358, %.10360
  %.10363 = and i32 %plop3_a_bit.120, %plop3_b_bit.120
  %.10365 = or i32 %.10362, %.10363
  %lop3_pred_cmp.210 = icmp ne i32 %.10365, 0
  br label %BB_4a60_7020

BB_4a60_7020:                                     ; preds = %BB_4a60_6ff0
  %438 = zext i1 %lop3_pred_cmp.210 to i32
  %439 = icmp ne i32 %438, 0
  br i1 %439, label %BB_4a60_7580, label %BB_4a60_7030

BB_4a60_7030:                                     ; preds = %BB_4a60_7020
  %.10368 = xor i32 %fchk_den_bits.30, -1
  %.10370 = xor i32 %fchk_num_bits.30, -1
  %.10371 = and i32 %.10368, 2147483647
  %.10372 = and i32 %.10371, %fchk_num_bits.30
  %.10374 = and i32 %fchk_aden.30, %.10370
  %.10375 = or i32 %.10372, %.10374
  %.10377 = and i32 %fchk_aden.30, %fchk_num_bits.30
  %.10378 = or i32 %.10375, %.10377
  %lop3_pred_cmp.211 = icmp ne i32 %.10378, 0
  br label %BB_4a60_7040

BB_4a60_7040:                                     ; preds = %BB_4a60_7030
  %cond_not.251 = xor i1 %lop3_pred_cmp.211, true
  br i1 %cond_not.251, label %BB_4a60_7560, label %BB_4a60_7050

BB_4a60_7050:                                     ; preds = %BB_4a60_7040
  %fsetrp_cmp1.182 = fcmp une float %fsetrp_lhs_fabs.150, 0x7FF0000000000000
  %fsetrp_cmp1.183 = fcmp une float %fsetrp_lhs_fabs.151, 0x7FF0000000000000
  br label %BB_4a60_7080

BB_4a60_7080:                                     ; preds = %BB_4a60_7050
  %cond_not.252 = xor i1 %fsetrp_cmp1.183, true
  br i1 %cond_not.252, label %BB_4a60_80007080, label %BB_4a60_7090

BB_4a60_80007080:                                 ; preds = %BB_4a60_7080
  %bra_cond_not.30 = xor i1 %fsetrp_cmp1.182, true
  br i1 %bra_cond_not.30, label %BB_4a60_7560, label %BB_4a60_7090

BB_4a60_7090:                                     ; preds = %BB_4a60_80007080, %BB_4a60_7080
  %lop3_pred_cmp.212 = icmp ne i32 %fchk_anum.30, 0
  %lop3_a_cast_zext.121 = zext i1 %fsetrp_cmp1.183 to i32
  %lop3_b_cast_zext.121 = zext i1 %lop3_pred_cmp.212 to i32
  %plop3_a_bit.121 = and i32 %lop3_a_cast_zext.121, 1
  %plop3_b_bit.121 = and i32 %lop3_b_cast_zext.121, 1
  %.10392 = xor i32 %plop3_a_bit.121, 1
  %.10393 = xor i32 %plop3_b_bit.121, 1
  %.10395 = and i32 %.10392, %.10393
  %.10397 = and i32 %.10392, %plop3_b_bit.121
  %.10399 = or i32 %.10395, %.10397
  %.10400 = and i32 %plop3_a_bit.121, %.10393
  %.10402 = or i32 %.10399, %.10400
  %lop3_pred_cmp.213 = icmp ne i32 %.10402, 0
  br label %BB_4a60_70b0

BB_4a60_70b0:                                     ; preds = %BB_4a60_7090
  %440 = zext i1 %lop3_pred_cmp.213 to i32
  %441 = icmp ne i32 %440, 0
  br i1 %441, label %BB_4a60_7540, label %BB_4a60_70c0

BB_4a60_70c0:                                     ; preds = %BB_4a60_70b0
  %lop3_pred_cmp.214 = icmp ne i32 %fchk_aden.30, 0
  %lop3_a_cast_zext.122 = zext i1 %fsetrp_cmp1.182 to i32
  %lop3_b_cast_zext.122 = zext i1 %lop3_pred_cmp.214 to i32
  %plop3_a_bit.122 = and i32 %lop3_a_cast_zext.122, 1
  %plop3_b_bit.122 = and i32 %lop3_b_cast_zext.122, 1
  %.10413 = xor i32 %plop3_a_bit.122, 1
  %.10414 = xor i32 %plop3_b_bit.122, 1
  %.10416 = and i32 %.10413, %.10414
  %.10418 = and i32 %.10413, %plop3_b_bit.122
  %.10420 = or i32 %.10416, %.10418
  %.10421 = and i32 %plop3_a_bit.122, %.10414
  %.10423 = or i32 %.10420, %.10421
  %lop3_pred_cmp.215 = icmp ne i32 %.10423, 0
  br label %BB_4a60_70e0

BB_4a60_70e0:                                     ; preds = %BB_4a60_70c0
  %442 = zext i1 %lop3_pred_cmp.215 to i32
  %443 = icmp ne i32 %442, 0
  br i1 %443, label %BB_4a60_7510, label %BB_4a60_70f0

BB_4a60_70f0:                                     ; preds = %BB_4a60_70e0
  %isetrp_cmp1.401 = icmp sge i32 %iadd3_n1.308, 0
  %isetrp_cmp1.402 = icmp sge i32 %iadd3_n1.307, 0
  br label %BB_4a60_7130

BB_4a60_7130:                                     ; preds = %BB_4a60_70f0
  %444 = zext i1 %isetrp_cmp1.401 to i32
  %445 = icmp ne i32 %444, 0
  br i1 %445, label %BB_4a60_80007130, label %BB_4a60_7140

BB_4a60_80007130:                                 ; preds = %BB_4a60_7130
  br label %BB_4a60_7140

BB_4a60_7140:                                     ; preds = %BB_4a60_80007130, %BB_4a60_7130
  %phi.481 = phi i32 [ 0, %BB_4a60_80007130 ], [ %iadd3_n1.307, %BB_4a60_7130 ]
  %cond_not.253 = xor i1 %isetrp_cmp1.401, true
  br i1 %cond_not.253, label %BB_4a60_80007140, label %BB_4a60_7160

BB_4a60_80007140:                                 ; preds = %BB_4a60_7140
  %ffma.518 = call float @llvm.fma.f32(float %ffma.512, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R329_bitcast = bitcast float %ffma.518 to i32
  br label %BB_4a60_7160

BB_4a60_7160:                                     ; preds = %BB_4a60_80007140, %BB_4a60_7140
  %phi.482 = phi i32 [ %phi_cast_R329_bitcast, %BB_4a60_80007140 ], [ %fchk_num_bits.30, %BB_4a60_7140 ]
  %phi.483 = phi i32 [ -64, %BB_4a60_80007140 ], [ %phi.481, %BB_4a60_7140 ]
  %cond_not.254 = xor i1 %isetrp_cmp1.402, true
  br i1 %cond_not.254, label %BB_4a60_80007160, label %BB_4a60_7180

BB_4a60_80007160:                                 ; preds = %BB_4a60_7160
  %ffma.519 = call float @llvm.fma.f32(float %lds.92, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.61 = add i32 %phi.483, 64
  %phi_cast_R869_bitcast = bitcast float %ffma.519 to i32
  br label %BB_4a60_7180

BB_4a60_7510:                                     ; preds = %BB_4a60_70e0
  %.10436 = and i32 %.10368, -2147483648
  %.10437 = and i32 %.10436, %fchk_num_bits.30
  %.10438 = and i32 %fchk_den_bits.30, -2147483648
  %.10439 = and i32 %.10438, %.10370
  %.10440 = or i32 %.10437, %.10439
  %.10441 = xor i32 %.10440, -1
  %.10444 = and i32 %.10441, 2139095040
  %.10451 = or i32 %.10444, %.10440
  %phi_cast_R334_bitcast = bitcast i32 %.10451 to float
  br label %BB_4a60_7590

BB_4a60_7540:                                     ; preds = %BB_4a60_70b0
  %.10465 = and i32 %.10368, -2147483648
  %.10466 = and i32 %.10465, %fchk_num_bits.30
  %.10467 = and i32 %fchk_den_bits.30, -2147483648
  %.10468 = and i32 %.10467, %.10370
  %.10469 = or i32 %.10466, %.10468
  %phi_cast_R337_bitcast = bitcast i32 %.10469 to float
  br label %BB_4a60_7590

BB_4a60_7560:                                     ; preds = %BB_4a60_80007080, %BB_4a60_7040
  %mufu_rsq.30 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_4a60_7590

BB_4a60_7580:                                     ; preds = %BB_4a60_7020
  %fadd.60 = fadd float %ffma.512, %lds.92
  br label %BB_4a60_7590

BB_4a60_80006fd0:                                 ; preds = %BB_4a60_6fd0
  br label %BB_4a60_7180

BB_4a60_7180:                                     ; preds = %BB_4a60_80006fd0, %BB_4a60_80007160, %BB_4a60_7160
  %phi.484 = phi i32 [ %fchk_den_bits.30, %BB_4a60_80006fd0 ], [ %phi_cast_R869_bitcast, %BB_4a60_80007160 ], [ %fchk_den_bits.30, %BB_4a60_7160 ]
  %phi.485 = phi i32 [ %fchk_num_bits.30, %BB_4a60_80006fd0 ], [ %phi.482, %BB_4a60_80007160 ], [ %phi.482, %BB_4a60_7160 ]
  %phi.486 = phi i32 [ 0, %BB_4a60_80006fd0 ], [ %viadd.61, %BB_4a60_80007160 ], [ %phi.483, %BB_4a60_7160 ]
  %.10474 = zext i32 %.10340 to i64
  %.10477 = shl i64 %.10474, 23
  %.10478 = and i64 %.10477, 4294967295
  %.10479 = add i64 %.10478, 3229614080
  %.10480 = trunc i64 %.10479 to i32
  %iadd3_n1.310 = add i32 %.10348, -127
  %iadd3_o1_not.60 = xor i32 %.10480, -1
  %iadd3_o1_neg.60 = add i32 %iadd3_o1_not.60, 1
  %iadd3_n1.311 = add i32 %iadd3_o1_neg.60, %phi.484
  %imad_tmp.112 = mul i32 %iadd3_n1.310, -8388608
  %imad.123 = add i32 %imad_tmp.112, %phi.485
  %mufu_src_bitcast.30 = bitcast i32 %iadd3_n1.311 to float
  %mufu_rcp.61 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.30)
  %fadd_lhs_fneg.30 = fneg float %mufu_src_bitcast.30
  %fadd.61 = fadd float %fadd_lhs_fneg.30, 0.000000e+00
  %iadd3_o3_not.30 = xor i32 %.10340, -1
  %iadd3_o3_neg.30 = add i32 %iadd3_o3_not.30, 1
  %iadd3_n2.312 = add i32 %.10348, %iadd3_o3_neg.30
  %iadd3_n1.313 = add i32 %iadd3_n2.312, %phi.486
  %ffma.520 = call float @llvm.fma.f32(float %mufu_rcp.61, float %fadd.61, float 1.000000e+00)
  %ffma.521 = call float @llvm.fma.f32(float %mufu_rcp.61, float %ffma.520, float %mufu_rcp.61)
  %ffma_lhs_bitcast.30 = bitcast i32 %imad.123 to float
  %ffma.522 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.30, float %ffma.521, float 0.000000e+00)
  %ffma.523 = call float @llvm.fma.f32(float %fadd.61, float %ffma.522, float %ffma_lhs_bitcast.30)
  %ffma.524 = call float @llvm.fma.f32(float %ffma.521, float %ffma.523, float %ffma.522)
  %ffma.525 = call float @llvm.fma.f32(float %fadd.61, float %ffma.524, float %ffma_lhs_bitcast.30)
  %ffma.526 = call float @llvm.fma.f32(float %ffma.521, float %ffma.525, float %ffma.524)
  %shf_hi_bitcast.92 = bitcast float %ffma.526 to i32
  %.10482 = zext i32 %shf_hi_bitcast.92 to i64
  %.10483 = shl i64 %.10482, 32
  %.10484 = lshr i64 %.10483, 23
  %shf_hi.157 = lshr i64 %.10484, 32
  %shf_result.188 = trunc i64 %shf_hi.157 to i32
  %.10488 = and i32 %shf_result.188, 255
  %imad.124 = add i32 %.10488, %iadd3_n1.313
  %iadd3_n1.314 = add i32 %imad.124, -1
  %isetrp_cmp1.403 = icmp uge i32 %iadd3_n1.314, 254
  br label %BB_4a60_72d0

BB_4a60_72d0:                                     ; preds = %BB_4a60_7180
  %cond_not.255 = xor i1 %isetrp_cmp1.403, true
  br i1 %cond_not.255, label %BB_4a60_74e0, label %BB_4a60_72e0

BB_4a60_72e0:                                     ; preds = %BB_4a60_72d0
  %isetrp_cmp1.404 = icmp sgt i32 %imad.124, 254
  br label %BB_4a60_72f0

BB_4a60_72f0:                                     ; preds = %BB_4a60_72e0
  %446 = zext i1 %isetrp_cmp1.404 to i32
  %447 = icmp ne i32 %446, 0
  br i1 %447, label %BB_4a60_74b0, label %BB_4a60_7300

BB_4a60_7300:                                     ; preds = %BB_4a60_72f0
  %isetrp_cmp1.405 = icmp sge i32 %imad.124, 1
  br label %BB_4a60_7310

BB_4a60_7310:                                     ; preds = %BB_4a60_7300
  %phi_cast_R2311_bitcast.2 = bitcast i32 %iadd3_n1.313 to float
  br i1 %isetrp_cmp1.405, label %BB_4a60_7590, label %BB_4a60_7320

BB_4a60_7320:                                     ; preds = %BB_4a60_7310
  %isetrp_cmp1.406 = icmp sge i32 %imad.124, -24
  %.10502 = and i32 %shf_hi_bitcast.92, -2147483648
  br label %BB_4a60_7340

BB_4a60_7340:                                     ; preds = %BB_4a60_7320
  %cond_not.256 = xor i1 %isetrp_cmp1.406, true
  %phi_cast_R346_bitcast = bitcast i32 %.10502 to float
  br i1 %cond_not.256, label %BB_4a60_7590, label %BB_4a60_7350

BB_4a60_7350:                                     ; preds = %BB_4a60_7340
  %ffma_rz.30 = call float @llvm.nvvm.fma.rz.f(float %ffma.521, float %ffma.525, float %ffma.524)
  %iadd3_n1.315 = add i32 %imad.124, 32
  %lop3_a_bitcast.246 = bitcast float %ffma_rz.30 to i32
  %.10512 = and i32 %lop3_a_bitcast.246, 8388607
  %ffma_rp.30 = call float @llvm.nvvm.fma.rp.f(float %ffma.521, float %ffma.525, float %ffma.524)
  %ffma_rm.30 = call float @llvm.nvvm.fma.rm.f(float %ffma.521, float %ffma.525, float %ffma.524)
  %isetrp_cmp1.408 = icmp ne i32 %imad.124, 0
  %.10527 = or i32 8388608, %.10512
  %iadd3_o1_not.61 = xor i32 %imad.124, -1
  %iadd3_o1_neg.61 = add i32 %iadd3_o1_not.61, 1
  %.10537 = zext i32 %.10527 to i64
  %shf_shift_64.189 = zext i32 %iadd3_n1.315 to i64
  %.10540 = shl i64 %.10537, %shf_shift_64.189
  %shf_result.189 = trunc i64 %.10540 to i32
  %fsetrp_cmp1.185 = fcmp une float %ffma_rp.30, %ffma_rm.30
  %isetrp_cmp1.409 = icmp ne i32 %shf_result.189, 0
  %isetrp_cmp2.409 = and i1 %isetrp_cmp1.409, %isetrp_cmp1.408
  %.10543 = shl i64 %.10537, 32
  %shf_shift_64.190 = zext i32 %iadd3_o1_neg.61 to i64
  %.10544 = lshr i64 %.10543, %shf_shift_64.190
  %shf_hi.158 = lshr i64 %.10544, 32
  %shf_result.190 = trunc i64 %shf_hi.158 to i32
  %lop3_a_cast_zext.123 = zext i1 %fsetrp_cmp1.185 to i32
  %lop3_b_cast_zext.123 = zext i1 %isetrp_cmp2.409 to i32
  %plop3_a_bit.123 = and i32 %lop3_a_cast_zext.123, 1
  %plop3_b_bit.123 = and i32 %lop3_b_cast_zext.123, 1
  %.10545 = xor i32 %plop3_a_bit.123, 1
  %.10546 = xor i32 %plop3_b_bit.123, 1
  %.10548 = and i32 %.10545, %plop3_b_bit.123
  %.10550 = and i32 %plop3_a_bit.123, %.10546
  %.10552 = or i32 %.10548, %.10550
  %.10553 = and i32 %plop3_a_bit.123, %plop3_b_bit.123
  %.10555 = or i32 %.10552, %.10553
  %lop3_pred_cmp.216 = icmp ne i32 %.10555, 0
  %.10557 = zext i32 %shf_result.190 to i64
  %.10558 = shl i64 %.10557, 32
  %.10559 = lshr i64 %.10558, 1
  %shf_hi.159 = lshr i64 %.10559, 32
  %shf_result.191 = trunc i64 %shf_hi.159 to i32
  %sel_pred_not.30 = xor i1 %lop3_pred_cmp.216, true
  %sel.61 = select i1 %sel_pred_not.30, i32 0, i32 1
  %.10560 = xor i32 %sel.61, -1
  %.10562 = xor i32 %shf_result.191, -1
  %.10563 = and i32 %.10560, 1
  %.10564 = and i32 %.10563, %shf_result.191
  %.10572 = and i32 %sel.61, %.10562
  %.10573 = or i32 %.10564, %.10572
  %.10575 = and i32 %sel.61, %shf_result.191
  %.10576 = or i32 %.10573, %.10575
  %.10580 = and i32 %.10576, %shf_result.190
  %imad.125 = add i32 %shf_result.191, %.10580
  %.10585 = xor i32 %imad.125, -1
  %.10586 = xor i32 %.10502, -1
  %.10588 = and i32 %.10585, %.10502
  %.10593 = and i32 %imad.125, %.10586
  %.10595 = or i32 %.10588, %.10593
  %.10599 = and i32 %imad.125, %.10502
  %.10601 = or i32 %.10595, %.10599
  %phi_cast_R348_bitcast = bitcast i32 %.10601 to float
  %phi_cast_R2314_bitcast = bitcast i32 %.10527 to float
  br label %BB_4a60_7590

BB_4a60_74b0:                                     ; preds = %BB_4a60_72f0
  %.10609 = and i32 %shf_hi_bitcast.92, -2147483648
  %.10624 = or i32 2139095040, %.10609
  %phi_cast_R350_bitcast = bitcast i32 %.10624 to float
  %phi_cast_R2311_bitcast = bitcast i32 %iadd3_n1.313 to float
  br label %BB_4a60_7590

BB_4a60_74e0:                                     ; preds = %BB_4a60_72d0
  %.10635 = zext i32 %iadd3_n1.313 to i64
  %.10638 = shl i64 %.10635, 23
  %.10639 = and i64 %.10638, 4294967295
  %.10640 = add i64 %.10639, %.10482
  %.10641 = trunc i64 %.10640 to i32
  %phi_cast_R351_bitcast = bitcast i32 %.10641 to float
  %phi_cast_R2311_bitcast.1 = bitcast i32 %iadd3_n1.313 to float
  br label %BB_4a60_7590

BB_4a60_7590:                                     ; preds = %BB_4a60_74e0, %BB_4a60_74b0, %BB_4a60_7350, %BB_4a60_7340, %BB_4a60_7310, %BB_4a60_7580, %BB_4a60_7560, %BB_4a60_7540, %BB_4a60_7510
  %phi.487 = phi float [ %phi_cast_R348_bitcast, %BB_4a60_7350 ], [ %phi_cast_R350_bitcast, %BB_4a60_74b0 ], [ %phi_cast_R351_bitcast, %BB_4a60_74e0 ], [ %ffma.526, %BB_4a60_7310 ], [ %phi_cast_R346_bitcast, %BB_4a60_7340 ], [ %phi_cast_R334_bitcast, %BB_4a60_7510 ], [ %phi_cast_R337_bitcast, %BB_4a60_7540 ], [ %mufu_rsq.30, %BB_4a60_7560 ], [ %fadd.60, %BB_4a60_7580 ]
  %phi.488 = phi float [ %phi_cast_R2314_bitcast, %BB_4a60_7350 ], [ %phi_cast_R2311_bitcast, %BB_4a60_74b0 ], [ %phi_cast_R2311_bitcast.1, %BB_4a60_74e0 ], [ %phi_cast_R2311_bitcast.2, %BB_4a60_7310 ], [ %phi_cast_R2311_bitcast.2, %BB_4a60_7340 ], [ %phi.477, %BB_4a60_7510 ], [ %phi.477, %BB_4a60_7540 ], [ %phi.477, %BB_4a60_7560 ], [ %phi.477, %BB_4a60_7580 ]
  br label %BB_4a80

BB_4a80:                                          ; preds = %BB_4a60_7590, %BB_4a30
  %phi.489 = phi float [ %phi.487, %BB_4a60_7590 ], [ %ffma.517, %BB_4a30 ]
  %phi.490 = phi float [ %phi.488, %BB_4a60_7590 ], [ %phi.477, %BB_4a30 ]
  br label %BB_4aa0

BB_4aa0:                                          ; preds = %BB_4a80, %BB_4940
  %phi.491 = phi float [ %phi.489, %BB_4a80 ], [ %phi.476, %BB_4940 ]
  %phi.492 = phi float [ %phi.490, %BB_4a80 ], [ %phi.477, %BB_4940 ]
  %phi.493 = phi i32 [ %.75, %BB_4a80 ], [ %phi.478, %BB_4940 ]
  %phi.494 = phi float [ %phi.489, %BB_4a80 ], [ %phi.479, %BB_4940 ]
  br label %BB_4ad0

BB_4ad0:                                          ; preds = %BB_4aa0
  %shfl_activemask.62 = call i32 @llvm.nvvm.activemask()
  %shfl_idx.62 = call float @llvm.nvvm.shfl.sync.idx.f32(i32 %shfl_activemask.62, float %phi.494, i32 30, i32 31)
  br label %BB_4ae0

BB_4ae0:                                          ; preds = %BB_4ad0
  %isetrp_cmp1.410 = icmp uge i32 %tid_x, 31
  %isetrp_cmp1.411 = icmp ne i32 %tid_x, 31
  br label %BB_4b10

BB_4b10:                                          ; preds = %BB_4ae0
  %448 = zext i1 %isetrp_cmp1.410 to i32
  %449 = icmp ne i32 %448, 0
  br i1 %449, label %BB_80004b10, label %BB_4b30

BB_80004b10:                                      ; preds = %BB_4b10
  %lds_addr_memaddr_offset_add.90 = add i32 %.88, 3960
  %.10649 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.90
  %lds.93 = load volatile float, ptr addrspace(3) %.10649, align 4
  %ffma.527 = call float @llvm.fma.f32(float %shfl_idx.62, float %lds.93, float %phi.480)
  br label %BB_4b30

BB_4b30:                                          ; preds = %BB_80004b10, %BB_4b10
  %phi.495 = phi float [ %ffma.527, %BB_80004b10 ], [ %phi.480, %BB_4b10 ]
  %warp_reconv_mask.30 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.30)
  %phi_cast_R2317_bitcast.5 = bitcast float %phi.492 to i32
  br i1 %isetrp_cmp1.411, label %BB_4c90, label %BB_4b40

BB_4b40:                                          ; preds = %BB_4b30
  %ffma_addend_fneg.31 = fneg float %phi.495
  %ffma.528 = call float @llvm.fma.f32(float %phi.491, float %phi, float %ffma_addend_fneg.31)
  %lds_addr_memaddr_offset_add.91 = add i32 %.75, 4216
  %.10659 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.91
  %lds.94 = load volatile float, ptr addrspace(3) %.10659, align 4
  %mufu_rcp.62 = call float @llvm.nvvm.rcp.approx.ftz.f(float %lds.94)
  %fchk_num_bits.31 = bitcast float %ffma.528 to i32
  %fchk_den_bits.31 = bitcast float %lds.94 to i32
  %fchk_aden.31 = and i32 %fchk_den_bits.31, 2147483647
  %fchk_anum.31 = and i32 %fchk_num_bits.31, 2147483647
  %fchk_den_subz.31 = icmp ult i32 %fchk_aden.31, 8388608
  %fchk_den_infnan.31 = icmp uge i32 %fchk_aden.31, 2139095040
  %fchk_num_infnan.31 = icmp uge i32 %fchk_anum.31, 2139095040
  %fchk_den_bad.31 = or i1 %fchk_den_subz.31, %fchk_den_infnan.31
  %fchk_px.31 = or i1 %fchk_den_bad.31, %fchk_num_infnan.31
  %ffma_lhs_fneg.62 = fneg float %lds.94
  %ffma.529 = call float @llvm.fma.f32(float %ffma_lhs_fneg.62, float %mufu_rcp.62, float 1.000000e+00)
  %ffma.530 = call float @llvm.fma.f32(float %mufu_rcp.62, float %ffma.529, float %mufu_rcp.62)
  %ffma.531 = call float @llvm.fma.f32(float %ffma.528, float %ffma.530, float 0.000000e+00)
  %ffma.532 = call float @llvm.fma.f32(float %ffma_lhs_fneg.62, float %ffma.531, float %ffma.528)
  %ffma.533 = call float @llvm.fma.f32(float %ffma.530, float %ffma.532, float %ffma.531)
  br label %BB_4c20

BB_4c20:                                          ; preds = %BB_4b40
  %cond_not.257 = xor i1 %fchk_px.31, true
  br i1 %cond_not.257, label %BB_4c70, label %BB_4c50_6f40

BB_4c50_6f40:                                     ; preds = %BB_4c20
  %.10663 = zext i32 %fchk_den_bits.31 to i64
  %.10664 = shl i64 %.10663, 32
  %.10665 = lshr i64 %.10664, 23
  %shf_hi.160 = lshr i64 %.10665, 32
  %shf_result.192 = trunc i64 %shf_hi.160 to i32
  %.10667 = zext i32 %fchk_num_bits.31 to i64
  %.10668 = shl i64 %.10667, 32
  %.10669 = lshr i64 %.10668, 23
  %shf_hi.161 = lshr i64 %.10669, 32
  %shf_result.193 = trunc i64 %shf_hi.161 to i32
  %.10673 = and i32 %shf_result.192, 255
  %.10681 = and i32 %shf_result.193, 255
  %iadd3_n1.317 = add i32 %.10673, -1
  %iadd3_n1.318 = add i32 %.10681, -1
  %isetrp_cmp1.412 = icmp ugt i32 %iadd3_n1.317, 253
  %isetrp_cmp1.413 = icmp ugt i32 %iadd3_n1.318, 253
  %isetrp_cmp2.413 = or i1 %isetrp_cmp1.413, %isetrp_cmp1.412
  br label %BB_4c50_6fd0

BB_4c50_6fd0:                                     ; preds = %BB_4c50_6f40
  %cond_not.258 = xor i1 %isetrp_cmp2.413, true
  br i1 %cond_not.258, label %BB_4c50_80006fd0, label %BB_4c50_6ff0

BB_4c50_6ff0:                                     ; preds = %BB_4c50_6fd0
  %fsetrp_lhs_fabs.155 = call float @llvm.nvvm.fabs.f(float %ffma.528)
  %fsetrp_cmp1.186 = fcmp ugt float %fsetrp_lhs_fabs.155, 0x7FF0000000000000
  %fsetrp_lhs_fabs.156 = call float @llvm.nvvm.fabs.f(float %lds.94)
  %fsetrp_cmp1.187 = fcmp ugt float %fsetrp_lhs_fabs.156, 0x7FF0000000000000
  %lop3_a_cast_zext.124 = zext i1 %fsetrp_cmp1.186 to i32
  %lop3_b_cast_zext.124 = zext i1 %fsetrp_cmp1.187 to i32
  %plop3_a_bit.124 = and i32 %lop3_a_cast_zext.124, 1
  %plop3_b_bit.124 = and i32 %lop3_b_cast_zext.124, 1
  %.10688 = xor i32 %plop3_a_bit.124, 1
  %.10689 = xor i32 %plop3_b_bit.124, 1
  %.10691 = and i32 %.10688, %plop3_b_bit.124
  %.10693 = and i32 %plop3_a_bit.124, %.10689
  %.10695 = or i32 %.10691, %.10693
  %.10696 = and i32 %plop3_a_bit.124, %plop3_b_bit.124
  %.10698 = or i32 %.10695, %.10696
  %lop3_pred_cmp.217 = icmp ne i32 %.10698, 0
  br label %BB_4c50_7020

BB_4c50_7020:                                     ; preds = %BB_4c50_6ff0
  %450 = zext i1 %lop3_pred_cmp.217 to i32
  %451 = icmp ne i32 %450, 0
  br i1 %451, label %BB_4c50_7580, label %BB_4c50_7030

BB_4c50_7030:                                     ; preds = %BB_4c50_7020
  %.10701 = xor i32 %fchk_den_bits.31, -1
  %.10703 = xor i32 %fchk_num_bits.31, -1
  %.10704 = and i32 %.10701, 2147483647
  %.10705 = and i32 %.10704, %fchk_num_bits.31
  %.10707 = and i32 %fchk_aden.31, %.10703
  %.10708 = or i32 %.10705, %.10707
  %.10710 = and i32 %fchk_aden.31, %fchk_num_bits.31
  %.10711 = or i32 %.10708, %.10710
  %lop3_pred_cmp.218 = icmp ne i32 %.10711, 0
  br label %BB_4c50_7040

BB_4c50_7040:                                     ; preds = %BB_4c50_7030
  %cond_not.259 = xor i1 %lop3_pred_cmp.218, true
  br i1 %cond_not.259, label %BB_4c50_7560, label %BB_4c50_7050

BB_4c50_7050:                                     ; preds = %BB_4c50_7040
  %fsetrp_cmp1.188 = fcmp une float %fsetrp_lhs_fabs.155, 0x7FF0000000000000
  %fsetrp_cmp1.189 = fcmp une float %fsetrp_lhs_fabs.156, 0x7FF0000000000000
  br label %BB_4c50_7080

BB_4c50_7080:                                     ; preds = %BB_4c50_7050
  %cond_not.260 = xor i1 %fsetrp_cmp1.189, true
  br i1 %cond_not.260, label %BB_4c50_80007080, label %BB_4c50_7090

BB_4c50_80007080:                                 ; preds = %BB_4c50_7080
  %bra_cond_not.31 = xor i1 %fsetrp_cmp1.188, true
  br i1 %bra_cond_not.31, label %BB_4c50_7560, label %BB_4c50_7090

BB_4c50_7090:                                     ; preds = %BB_4c50_80007080, %BB_4c50_7080
  %lop3_pred_cmp.219 = icmp ne i32 %fchk_anum.31, 0
  %lop3_a_cast_zext.125 = zext i1 %fsetrp_cmp1.189 to i32
  %lop3_b_cast_zext.125 = zext i1 %lop3_pred_cmp.219 to i32
  %plop3_a_bit.125 = and i32 %lop3_a_cast_zext.125, 1
  %plop3_b_bit.125 = and i32 %lop3_b_cast_zext.125, 1
  %.10725 = xor i32 %plop3_a_bit.125, 1
  %.10726 = xor i32 %plop3_b_bit.125, 1
  %.10728 = and i32 %.10725, %.10726
  %.10730 = and i32 %.10725, %plop3_b_bit.125
  %.10732 = or i32 %.10728, %.10730
  %.10733 = and i32 %plop3_a_bit.125, %.10726
  %.10735 = or i32 %.10732, %.10733
  %lop3_pred_cmp.220 = icmp ne i32 %.10735, 0
  br label %BB_4c50_70b0

BB_4c50_70b0:                                     ; preds = %BB_4c50_7090
  %452 = zext i1 %lop3_pred_cmp.220 to i32
  %453 = icmp ne i32 %452, 0
  br i1 %453, label %BB_4c50_7540, label %BB_4c50_70c0

BB_4c50_70c0:                                     ; preds = %BB_4c50_70b0
  %lop3_pred_cmp.221 = icmp ne i32 %fchk_aden.31, 0
  %lop3_a_cast_zext.126 = zext i1 %fsetrp_cmp1.188 to i32
  %lop3_b_cast_zext.126 = zext i1 %lop3_pred_cmp.221 to i32
  %plop3_a_bit.126 = and i32 %lop3_a_cast_zext.126, 1
  %plop3_b_bit.126 = and i32 %lop3_b_cast_zext.126, 1
  %.10746 = xor i32 %plop3_a_bit.126, 1
  %.10747 = xor i32 %plop3_b_bit.126, 1
  %.10749 = and i32 %.10746, %.10747
  %.10751 = and i32 %.10746, %plop3_b_bit.126
  %.10753 = or i32 %.10749, %.10751
  %.10754 = and i32 %plop3_a_bit.126, %.10747
  %.10756 = or i32 %.10753, %.10754
  %lop3_pred_cmp.222 = icmp ne i32 %.10756, 0
  br label %BB_4c50_70e0

BB_4c50_70e0:                                     ; preds = %BB_4c50_70c0
  %454 = zext i1 %lop3_pred_cmp.222 to i32
  %455 = icmp ne i32 %454, 0
  br i1 %455, label %BB_4c50_7510, label %BB_4c50_70f0

BB_4c50_70f0:                                     ; preds = %BB_4c50_70e0
  %isetrp_cmp1.414 = icmp sge i32 %iadd3_n1.318, 0
  %isetrp_cmp1.415 = icmp sge i32 %iadd3_n1.317, 0
  br label %BB_4c50_7130

BB_4c50_7130:                                     ; preds = %BB_4c50_70f0
  %456 = zext i1 %isetrp_cmp1.414 to i32
  %457 = icmp ne i32 %456, 0
  br i1 %457, label %BB_4c50_80007130, label %BB_4c50_7140

BB_4c50_80007130:                                 ; preds = %BB_4c50_7130
  br label %BB_4c50_7140

BB_4c50_7140:                                     ; preds = %BB_4c50_80007130, %BB_4c50_7130
  %phi.496 = phi i32 [ 0, %BB_4c50_80007130 ], [ %iadd3_n1.317, %BB_4c50_7130 ]
  %cond_not.261 = xor i1 %isetrp_cmp1.414, true
  br i1 %cond_not.261, label %BB_4c50_80007140, label %BB_4c50_7160

BB_4c50_80007140:                                 ; preds = %BB_4c50_7140
  %ffma.534 = call float @llvm.fma.f32(float %ffma.528, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R356_bitcast = bitcast float %ffma.534 to i32
  br label %BB_4c50_7160

BB_4c50_7160:                                     ; preds = %BB_4c50_80007140, %BB_4c50_7140
  %phi.497 = phi i32 [ %phi_cast_R356_bitcast, %BB_4c50_80007140 ], [ %fchk_num_bits.31, %BB_4c50_7140 ]
  %phi.498 = phi i32 [ -64, %BB_4c50_80007140 ], [ %phi.496, %BB_4c50_7140 ]
  %cond_not.262 = xor i1 %isetrp_cmp1.415, true
  br i1 %cond_not.262, label %BB_4c50_80007160, label %BB_4c50_7180

BB_4c50_80007160:                                 ; preds = %BB_4c50_7160
  %ffma.535 = call float @llvm.fma.f32(float %lds.94, float 0x43F0000000000000, float 0.000000e+00)
  %viadd.63 = add i32 %phi.498, 64
  %phi_cast_R887_bitcast = bitcast float %ffma.535 to i32
  br label %BB_4c50_7180

BB_4c50_7510:                                     ; preds = %BB_4c50_70e0
  %.10769 = and i32 %.10701, -2147483648
  %.10770 = and i32 %.10769, %fchk_num_bits.31
  %.10771 = and i32 %fchk_den_bits.31, -2147483648
  %.10772 = and i32 %.10771, %.10703
  %.10773 = or i32 %.10770, %.10772
  %.10774 = xor i32 %.10773, -1
  %.10777 = and i32 %.10774, 2139095040
  %.10784 = or i32 %.10777, %.10773
  %phi_cast_R360_bitcast = bitcast i32 %.10784 to float
  br label %BB_4c50_7590

BB_4c50_7540:                                     ; preds = %BB_4c50_70b0
  %.10798 = and i32 %.10701, -2147483648
  %.10799 = and i32 %.10798, %fchk_num_bits.31
  %.10800 = and i32 %fchk_den_bits.31, -2147483648
  %.10801 = and i32 %.10800, %.10703
  %.10802 = or i32 %.10799, %.10801
  %phi_cast_R361_bitcast = bitcast i32 %.10802 to float
  br label %BB_4c50_7590

BB_4c50_7560:                                     ; preds = %BB_4c50_80007080, %BB_4c50_7040
  %mufu_rsq.31 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_4c50_7590

BB_4c50_7580:                                     ; preds = %BB_4c50_7020
  %fadd.62 = fadd float %ffma.528, %lds.94
  br label %BB_4c50_7590

BB_4c50_80006fd0:                                 ; preds = %BB_4c50_6fd0
  br label %BB_4c50_7180

BB_4c50_7180:                                     ; preds = %BB_4c50_80006fd0, %BB_4c50_80007160, %BB_4c50_7160
  %phi.499 = phi i32 [ %fchk_den_bits.31, %BB_4c50_80006fd0 ], [ %phi_cast_R887_bitcast, %BB_4c50_80007160 ], [ %fchk_den_bits.31, %BB_4c50_7160 ]
  %phi.500 = phi i32 [ %fchk_num_bits.31, %BB_4c50_80006fd0 ], [ %phi.497, %BB_4c50_80007160 ], [ %phi.497, %BB_4c50_7160 ]
  %phi.501 = phi i32 [ 0, %BB_4c50_80006fd0 ], [ %viadd.63, %BB_4c50_80007160 ], [ %phi.498, %BB_4c50_7160 ]
  %.10807 = zext i32 %.10673 to i64
  %.10810 = shl i64 %.10807, 23
  %.10811 = and i64 %.10810, 4294967295
  %.10812 = add i64 %.10811, 3229614080
  %.10813 = trunc i64 %.10812 to i32
  %iadd3_n1.320 = add i32 %.10681, -127
  %iadd3_o1_not.62 = xor i32 %.10813, -1
  %iadd3_o1_neg.62 = add i32 %iadd3_o1_not.62, 1
  %iadd3_n1.321 = add i32 %iadd3_o1_neg.62, %phi.499
  %imad_tmp.116 = mul i32 %iadd3_n1.320, -8388608
  %imad.127 = add i32 %imad_tmp.116, %phi.500
  %mufu_src_bitcast.31 = bitcast i32 %iadd3_n1.321 to float
  %mufu_rcp.63 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.31)
  %fadd_lhs_fneg.31 = fneg float %mufu_src_bitcast.31
  %fadd.63 = fadd float %fadd_lhs_fneg.31, 0.000000e+00
  %iadd3_o3_not.31 = xor i32 %.10673, -1
  %iadd3_o3_neg.31 = add i32 %iadd3_o3_not.31, 1
  %iadd3_n2.322 = add i32 %.10681, %iadd3_o3_neg.31
  %iadd3_n1.323 = add i32 %iadd3_n2.322, %phi.501
  %ffma.536 = call float @llvm.fma.f32(float %mufu_rcp.63, float %fadd.63, float 1.000000e+00)
  %ffma.537 = call float @llvm.fma.f32(float %mufu_rcp.63, float %ffma.536, float %mufu_rcp.63)
  %ffma_lhs_bitcast.31 = bitcast i32 %imad.127 to float
  %ffma.538 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.31, float %ffma.537, float 0.000000e+00)
  %ffma.539 = call float @llvm.fma.f32(float %fadd.63, float %ffma.538, float %ffma_lhs_bitcast.31)
  %ffma.540 = call float @llvm.fma.f32(float %ffma.537, float %ffma.539, float %ffma.538)
  %ffma.541 = call float @llvm.fma.f32(float %fadd.63, float %ffma.540, float %ffma_lhs_bitcast.31)
  %ffma.542 = call float @llvm.fma.f32(float %ffma.537, float %ffma.541, float %ffma.540)
  %shf_hi_bitcast.95 = bitcast float %ffma.542 to i32
  %.10815 = zext i32 %shf_hi_bitcast.95 to i64
  %.10816 = shl i64 %.10815, 32
  %.10817 = lshr i64 %.10816, 23
  %shf_hi.162 = lshr i64 %.10817, 32
  %shf_result.194 = trunc i64 %shf_hi.162 to i32
  %.10821 = and i32 %shf_result.194, 255
  %imad.128 = add i32 %.10821, %iadd3_n1.323
  %iadd3_n1.324 = add i32 %imad.128, -1
  %isetrp_cmp1.416 = icmp uge i32 %iadd3_n1.324, 254
  br label %BB_4c50_72d0

BB_4c50_72d0:                                     ; preds = %BB_4c50_7180
  %cond_not.263 = xor i1 %isetrp_cmp1.416, true
  br i1 %cond_not.263, label %BB_4c50_74e0, label %BB_4c50_72e0

BB_4c50_72e0:                                     ; preds = %BB_4c50_72d0
  %isetrp_cmp1.417 = icmp sgt i32 %imad.128, 254
  br label %BB_4c50_72f0

BB_4c50_72f0:                                     ; preds = %BB_4c50_72e0
  %458 = zext i1 %isetrp_cmp1.417 to i32
  %459 = icmp ne i32 %458, 0
  br i1 %459, label %BB_4c50_74b0, label %BB_4c50_7300

BB_4c50_7300:                                     ; preds = %BB_4c50_72f0
  %isetrp_cmp1.418 = icmp sge i32 %imad.128, 1
  br label %BB_4c50_7310

BB_4c50_7310:                                     ; preds = %BB_4c50_7300
  %460 = zext i1 %isetrp_cmp1.418 to i32
  %461 = icmp ne i32 %460, 0
  br i1 %461, label %BB_4c50_7590, label %BB_4c50_7320

BB_4c50_7320:                                     ; preds = %BB_4c50_7310
  %isetrp_cmp1.419 = icmp sge i32 %imad.128, -24
  %.10835 = and i32 %shf_hi_bitcast.95, -2147483648
  br label %BB_4c50_7340

BB_4c50_7340:                                     ; preds = %BB_4c50_7320
  %cond_not.264 = xor i1 %isetrp_cmp1.419, true
  %phi_cast_R371_bitcast = bitcast i32 %.10835 to float
  br i1 %cond_not.264, label %BB_4c50_7590, label %BB_4c50_7350

BB_4c50_7350:                                     ; preds = %BB_4c50_7340
  %ffma_rz.31 = call float @llvm.nvvm.fma.rz.f(float %ffma.537, float %ffma.541, float %ffma.540)
  %iadd3_n1.325 = add i32 %imad.128, 32
  %lop3_a_bitcast.254 = bitcast float %ffma_rz.31 to i32
  %.10845 = and i32 %lop3_a_bitcast.254, 8388607
  %ffma_rp.31 = call float @llvm.nvvm.fma.rp.f(float %ffma.537, float %ffma.541, float %ffma.540)
  %ffma_rm.31 = call float @llvm.nvvm.fma.rm.f(float %ffma.537, float %ffma.541, float %ffma.540)
  %isetrp_cmp1.421 = icmp ne i32 %imad.128, 0
  %.10860 = or i32 8388608, %.10845
  %iadd3_o1_not.63 = xor i32 %imad.128, -1
  %iadd3_o1_neg.63 = add i32 %iadd3_o1_not.63, 1
  %.10870 = zext i32 %.10860 to i64
  %shf_shift_64.195 = zext i32 %iadd3_n1.325 to i64
  %.10873 = shl i64 %.10870, %shf_shift_64.195
  %shf_result.195 = trunc i64 %.10873 to i32
  %fsetrp_cmp1.191 = fcmp une float %ffma_rp.31, %ffma_rm.31
  %isetrp_cmp1.422 = icmp ne i32 %shf_result.195, 0
  %isetrp_cmp2.422 = and i1 %isetrp_cmp1.422, %isetrp_cmp1.421
  %.10876 = shl i64 %.10870, 32
  %shf_shift_64.196 = zext i32 %iadd3_o1_neg.63 to i64
  %.10877 = lshr i64 %.10876, %shf_shift_64.196
  %shf_hi.163 = lshr i64 %.10877, 32
  %shf_result.196 = trunc i64 %shf_hi.163 to i32
  %lop3_a_cast_zext.127 = zext i1 %fsetrp_cmp1.191 to i32
  %lop3_b_cast_zext.127 = zext i1 %isetrp_cmp2.422 to i32
  %plop3_a_bit.127 = and i32 %lop3_a_cast_zext.127, 1
  %plop3_b_bit.127 = and i32 %lop3_b_cast_zext.127, 1
  %.10878 = xor i32 %plop3_a_bit.127, 1
  %.10879 = xor i32 %plop3_b_bit.127, 1
  %.10881 = and i32 %.10878, %plop3_b_bit.127
  %.10883 = and i32 %plop3_a_bit.127, %.10879
  %.10885 = or i32 %.10881, %.10883
  %.10886 = and i32 %plop3_a_bit.127, %plop3_b_bit.127
  %.10888 = or i32 %.10885, %.10886
  %lop3_pred_cmp.223 = icmp ne i32 %.10888, 0
  %.10890 = zext i32 %shf_result.196 to i64
  %.10891 = shl i64 %.10890, 32
  %.10892 = lshr i64 %.10891, 1
  %shf_hi.164 = lshr i64 %.10892, 32
  %shf_result.197 = trunc i64 %shf_hi.164 to i32
  %sel_pred_not.31 = xor i1 %lop3_pred_cmp.223, true
  %sel.63 = select i1 %sel_pred_not.31, i32 0, i32 1
  %.10893 = xor i32 %sel.63, -1
  %.10895 = xor i32 %shf_result.197, -1
  %.10896 = and i32 %.10893, 1
  %.10897 = and i32 %.10896, %shf_result.197
  %.10905 = and i32 %sel.63, %.10895
  %.10906 = or i32 %.10897, %.10905
  %.10908 = and i32 %sel.63, %shf_result.197
  %.10909 = or i32 %.10906, %.10908
  %.10913 = and i32 %.10909, %shf_result.196
  %imad.129 = add i32 %shf_result.197, %.10913
  %.10918 = xor i32 %imad.129, -1
  %.10919 = xor i32 %.10835, -1
  %.10921 = and i32 %.10918, %.10835
  %.10926 = and i32 %imad.129, %.10919
  %.10928 = or i32 %.10921, %.10926
  %.10932 = and i32 %imad.129, %.10835
  %.10934 = or i32 %.10928, %.10932
  %phi_cast_R372_bitcast = bitcast i32 %.10934 to float
  br label %BB_4c50_7590

BB_4c50_74b0:                                     ; preds = %BB_4c50_72f0
  %.10942 = and i32 %shf_hi_bitcast.95, -2147483648
  %.10957 = or i32 2139095040, %.10942
  %phi_cast_R374_bitcast = bitcast i32 %.10957 to float
  br label %BB_4c50_7590

BB_4c50_74e0:                                     ; preds = %BB_4c50_72d0
  %.10968 = zext i32 %iadd3_n1.323 to i64
  %.10971 = shl i64 %.10968, 23
  %.10972 = and i64 %.10971, 4294967295
  %.10973 = add i64 %.10972, %.10815
  %.10974 = trunc i64 %.10973 to i32
  %phi_cast_R375_bitcast = bitcast i32 %.10974 to float
  br label %BB_4c50_7590

BB_4c50_7590:                                     ; preds = %BB_4c50_74e0, %BB_4c50_74b0, %BB_4c50_7350, %BB_4c50_7340, %BB_4c50_7310, %BB_4c50_7580, %BB_4c50_7560, %BB_4c50_7540, %BB_4c50_7510
  %phi.502 = phi float [ %phi_cast_R372_bitcast, %BB_4c50_7350 ], [ %phi_cast_R374_bitcast, %BB_4c50_74b0 ], [ %phi_cast_R375_bitcast, %BB_4c50_74e0 ], [ %ffma.542, %BB_4c50_7310 ], [ %phi_cast_R371_bitcast, %BB_4c50_7340 ], [ %phi_cast_R360_bitcast, %BB_4c50_7510 ], [ %phi_cast_R361_bitcast, %BB_4c50_7540 ], [ %mufu_rsq.31, %BB_4c50_7560 ], [ %fadd.62, %BB_4c50_7580 ]
  %phi.503 = phi i32 [ %.10860, %BB_4c50_7350 ], [ %iadd3_n1.323, %BB_4c50_74b0 ], [ %iadd3_n1.323, %BB_4c50_74e0 ], [ %iadd3_n1.323, %BB_4c50_7310 ], [ %iadd3_n1.323, %BB_4c50_7340 ], [ %phi_cast_R2317_bitcast.5, %BB_4c50_7510 ], [ %phi_cast_R2317_bitcast.5, %BB_4c50_7540 ], [ %phi_cast_R2317_bitcast.5, %BB_4c50_7560 ], [ %phi_cast_R2317_bitcast.5, %BB_4c50_7580 ]
  br label %BB_4c70

BB_4c70:                                          ; preds = %BB_4c50_7590, %BB_4c20
  %phi.504 = phi float [ %phi.502, %BB_4c50_7590 ], [ %ffma.533, %BB_4c20 ]
  %phi.505 = phi i32 [ %phi.503, %BB_4c50_7590 ], [ %phi_cast_R2317_bitcast.5, %BB_4c20 ]
  br label %BB_4c90

BB_4c90:                                          ; preds = %BB_4c70, %BB_4b30
  %phi.506 = phi float [ %phi.504, %BB_4c70 ], [ %phi.491, %BB_4b30 ]
  %phi.507 = phi i32 [ %phi.505, %BB_4c70 ], [ %phi_cast_R2317_bitcast.5, %BB_4b30 ]
  %phi.508 = phi i32 [ %.75, %BB_4c70 ], [ %phi.493, %BB_4b30 ]
  %"R2733:R2592_addr_ptr.1" = inttoptr i64 %71 to ptr addrspace(1)
  store float %phi.506, ptr addrspace(1) %"R2733:R2592_addr_ptr.1", align 4
  br label %BB_4cd0

BB_4cd0:                                          ; preds = %BB_4c90, %BB_0ee0
  %phi.509 = phi float [ %phi.506, %BB_4c90 ], [ %phi.35, %BB_0ee0 ]
  %phi.510 = phi i32 [ %phi.507, %BB_4c90 ], [ %"R21:R20_r1.1", %BB_0ee0 ]
  %phi.511 = phi float [ %phi.495, %BB_4c90 ], [ %ldg.9, %BB_0ee0 ]
  %phi.512 = phi i32 [ %phi.508, %BB_4c90 ], [ %phi.12, %BB_0ee0 ]
  %iadd3_n1.327 = add i32 %phi.9, 1
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.423 = icmp sge i32 %iadd3_n1.327, %shf_result.1
  %462 = add i64 %11, 1
  br label %BB_4d30

BB_4d30:                                          ; preds = %BB_4cd0
  %cond_not.265 = xor i1 %isetrp_cmp1.423, true
  br i1 %cond_not.265, label %BB_0330, label %BB_4d40

BB_4d40:                                          ; preds = %BB_4d30, %BB_0230
  %phi.513 = phi float [ %phi.2, %BB_0230 ], [ %phi.509, %BB_4d30 ]
  %phi.514 = phi i32 [ %phi.3, %BB_0230 ], [ %phi.510, %BB_4d30 ]
  %phi.515 = phi float [ %phi.4, %BB_0230 ], [ %phi.511, %BB_4d30 ]
  %phi.516 = phi i32 [ %phi.5, %BB_0230 ], [ %phi.512, %BB_4d30 ]
  %ldc_const.19 = load i32, ptr %.14, align 4
  %nctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %.10984 = zext i32 %nctaid_x to i64
  %.10987 = shl i64 %.10984, 3
  %.10988 = and i64 %.10987, 4294967295
  %.10989 = add i64 %.10988, %.93
  %.10990 = trunc i64 %.10989 to i32
  %isetrp_cmp1.424 = icmp sle i32 %ldc_const.19, %.10990
  br label %BB_4d80

BB_4d80:                                          ; preds = %BB_4d40
  %cond_not.266 = xor i1 %isetrp_cmp1.424, true
  br i1 %cond_not.266, label %BB_01c0, label %BB_4d90

BB_4d90:                                          ; preds = %BB_4d80
  ret void

BB_80000200:                                      ; preds = %BB_0200
  ret void

BB_800000b0:                                      ; preds = %BB_00b0
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #1

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.activemask() #2

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare float @llvm.nvvm.shfl.sync.idx.f32(i32, float, i32, i32) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rcp.approx.ftz.f(float) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.nvvm.fabs.f(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rsqrt.approx.ftz.f(float) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.nvvm.fma.rz.f(float, float, float) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.nvvm.fma.rp.f(float, float, float) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.nvvm.fma.rm.f(float, float, float) #0

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #0

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { convergent nocallback nounwind }
attributes #2 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1, !2, !3, !4}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z19kernel_trsm_l_mul32IfLi8ELb0ELb0ELb0ELb0EEviiPKT_S2_iPS0_iS0_i, !"kernel", i32 1}
!2 = !{ptr @_Z19kernel_trsm_l_mul32IfLi8ELb0ELb0ELb0ELb0EEviiPKT_S2_iPS0_iS0_i, !"maxntidx", i32 256}
!3 = !{ptr @_Z19kernel_trsm_l_mul32IfLi8ELb0ELb0ELb0ELb0EEviiPKT_S2_iPS0_iS0_i, !"maxntidy", i32 1}
!4 = !{ptr @_Z19kernel_trsm_l_mul32IfLi8ELb0ELb0ELb0ELb0EEviiPKT_S2_iPS0_iS0_i, !"maxntidz", i32 1}
