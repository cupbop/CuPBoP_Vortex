; ModuleID = "tcgen05_tf32_pair_sm100a_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [11280 x i8], align 16
@"__slifter_nv_global" = addrspace(1) global [1 x i8] zeroinitializer, align 16
define void @"_Z8mma_caseILj100624EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"UR13:UR12_r0" = trunc i64 %"ldc_const" to i32
  %"UR13:UR12_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR13:UR12_r1" = trunc i64 %"UR13:UR12_r1_shift" to i32
  %"imad_tmp" = mul i32 %"s2ur_cluster_ctarank", 2816
  %"imad" = add i32 %"imad_tmp", 0
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.1" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"UR5:UR4_r0" = trunc i64 %"imad.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"imad.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"UR5:UR4_r0"
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"UR5:UR4_r1"
  %"imad_addend_r0_ext.1" = zext i32 %"imad.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"imad.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.4", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0" to i64
  %"iadd3_o2_64" = zext i32 %"UR13:UR12_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"iadd3_n1" = add i32 %"R3:R2_r1", %"UR13:UR12_r1"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P1_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"iadd3_cin2_add", %"EntryBB_0000"], [%"imad_with_cin", %"BB_01b0"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_01b0"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_01b0"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"EntryBB_0000"], [%"iadd3_trunc.1", %"BB_01b0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R82:R89_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R82:R89_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P8_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.3", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P8_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.5", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc" = trunc i32 %"P26_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0130", label %"BB_01c0"
BB_01c0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 511
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.1" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0300", label %"BB_0210"
BB_0210:
  %"iadd3_n1.1" = add i32 1024, 8192
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_64.2" = zext i32 %"iadd3_trunc" to i64
  %"iadd3_o2_64.2" = zext i32 8192 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2.1" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.4", %"iadd3_cin2_add"
  %"imad_cin_trunc.1" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.6", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0270"
BB_0270:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_0210"], [%"imad_with_cin.2", %"BB_02f0"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_0210"], [%"viadd.2", %"BB_02f0"]
  %"phi.6" = phi  i32 [%".58", %"BB_0210"], [%"viadd.3", %"BB_02f0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.2", %"BB_0210"], [%"iadd3_trunc.3", %"BB_02f0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R85:R2_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R85:R2_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 384
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.3" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.3" = zext i32 512 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.5", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.7", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02f0"
BB_02f0:
  %"cond_trunc.2" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0270", label %"BB_0300"
BB_0300:
  %"vote_pred_trunc" = trunc i32 %"P27_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P17_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0340"
BB_0340:
  %"cond_trunc.3" = trunc i32 %"P17_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000340", label %"BB_0390"
BB_80000340:
  %"iadd3_n1.2" = add i32 1024, 10240
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.3" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".66" = zext i32 %"iadd3_n2.3" to i64
  %".67" = zext i32 0 to i64
  %".68" = shl i64 %".67", 32
  %"shf_concat" = or i64 %".66", %".68"
  %"shf_shift_64" = zext i32 11 to i64
  %".69" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".69" to i32
  %".70" = zext i32 %"iadd3_n2.3" to i64
  %".71" = zext i32 0 to i64
  %".72" = shl i64 %".71", 32
  %"shf_concat.1" = or i64 %".70", %".72"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".73" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".73" to i32
  %".74" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".75" = zext i32 %"iadd3_n2.2" to i64
  %".76" = zext i32 24 to i64
  %".77" = shl i64 %".74", %".76"
  %".78" = and i64 %".77", 4294967295
  %".79" = add i64 %".78", %".75"
  %".80" = trunc i64 %".79" to i32
  br label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%".80", %"BB_80000340"], [0, %"BB_0340"]
  %"phi.9" = phi  i32 [%"shf_result", %"BB_80000340"], [%"UR5:UR4_r1", %"BB_0340"]
  %"phi.10" = phi  i32 [%"shf_result.1", %"BB_80000340"], [1, %"BB_0340"]
  %"vote_pred_trunc.1" = trunc i32 %"P27_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P18_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.4" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800003b0", label %"BB_03c0"
BB_800003b0:
  %"mbar_shared_winoff" = and i32 %"phi.8", 16777215
  %".85" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".85" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".86" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".86" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_03c0"
BB_03c0:
  %"cond_trunc.5" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800003c0", label %"BB_03d0"
BB_800003c0:
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.6" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0a50", label %"BB_03e0"
BB_03e0:
  %".92" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".93" = zext i32 64 to i64
  %".94" = zext i32 24 to i64
  %".95" = shl i64 %".92", %".94"
  %".96" = and i64 %".95", 4294967295
  %".97" = add i64 %".96", %".93"
  %".98" = trunc i64 %".97" to i32
  %"lds_shared_addr_winoff" = and i32 %".98", 16777215
  %".99" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".99"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0440"
BB_0440:
  %"cond_trunc.7" = trunc i32 %"P12_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_09f0", label %"BB_0450"
BB_0450:
  %"pair_shared_winoff" = and i32 11272, 16777215
  %".102" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"pair_shared_winoff"
  %".103" = ptrtoint i8 addrspace(3)* %".102" to i32
  call void asm sideeffect "tcgen05.alloc.cta_group::2.sync.aligned.shared::cta.b32 [$0], $1;", "r,r,~{memory}"(i32 %".103", i32 64) convergent
  br label %"BB_0a50"
BB_09f0:
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.6", -1
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 10248
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  call void @"llvm.trap"()
  br label %"BB_0a50"
BB_0a50:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %".109" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".110" = zext i32 1024 to i64
  %".111" = zext i32 24 to i64
  %".112" = shl i64 %".109", %".111"
  %".113" = and i64 %".112", 4294967295
  %".114" = add i64 %".113", %".110"
  %".115" = trunc i64 %".114" to i32
  %".116" = xor i32 %"tid_x.1", -1
  %".117" = xor i32 %"s2ur_cluster_ctarank.1", -1
  %".118" = xor i32 0, -1
  %".119" = and i32 %".116", %"s2ur_cluster_ctarank.1"
  %".120" = and i32 %".119", %".118"
  %".121" = and i32 %".116", %"s2ur_cluster_ctarank.1"
  %".122" = and i32 %".121", 0
  %".123" = or i32 %".120", %".122"
  %".124" = and i32 %"tid_x.1", %".117"
  %".125" = and i32 %".124", %".118"
  %".126" = or i32 %".123", %".125"
  %".127" = and i32 %"tid_x.1", %".117"
  %".128" = and i32 %".127", 0
  %".129" = or i32 %".126", %".128"
  %".130" = and i32 %"tid_x.1", %"s2ur_cluster_ctarank.1"
  %".131" = and i32 %".130", %".118"
  %".132" = or i32 %".129", %".131"
  %".133" = and i32 %"tid_x.1", %"s2ur_cluster_ctarank.1"
  %".134" = and i32 %".133", 0
  %".135" = or i32 %".132", %".134"
  %"lop3_pred_cmp" = icmp ne i32 %".135", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P28_to_i32" = zext i1 %"lop3_p" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".115", 10248
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".136" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".136" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0b90"
BB_0b90:
  %"cond_trunc.8" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0d80", label %"BB_0ba0"
BB_0ba0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".115", 10248
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".142" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".142" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.4" = add i32 1024, 8192
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".143" = xor i32 %"plop3_a_bit", 1
  %".144" = xor i32 %"plop3_b_bit", 1
  %".145" = xor i32 %"plop3_c_bit", 1
  %".146" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".147" = and i32 %".146", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".147", 0
  %"P29_to_i32" = zext i1 %"plop3_pred" to i32
  %".148" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".149" = zext i32 %"iadd3_n2.4" to i64
  %".150" = zext i32 24 to i64
  %".151" = shl i64 %".148", %".150"
  %".152" = and i64 %".151", 4294967295
  %".153" = add i64 %".152", %".149"
  %".154" = trunc i64 %".153" to i32
  %"iadd3_n1.5" = add i32 %".154", 32
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".155" = zext i32 0 to i64
  %".156" = zext i32 %".115" to i64
  %".157" = shl i64 %".156", 32
  %"shf_concat.2" = or i64 %".155", %".157"
  %"shf_shift_64.2" = zext i32 4 to i64
  %".158" = lshr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi" = lshr i64 %".158", 32
  %"shf_result.2" = trunc i64 %"shf_hi" to i32
  %".159" = zext i32 0 to i64
  %".160" = zext i32 %"iadd3_n2.5" to i64
  %".161" = shl i64 %".160", 32
  %"shf_concat.3" = or i64 %".159", %".161"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".162" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".162", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".163" = xor i32 %"shf_result.2", -1
  %".164" = xor i32 16376, -1
  %".165" = xor i32 0, -1
  %".166" = and i32 %"shf_result.2", 16376
  %".167" = and i32 %".166", %".165"
  %".168" = and i32 %"shf_result.2", 16376
  %".169" = and i32 %".168", 0
  %".170" = or i32 %".167", %".169"
  %".171" = xor i32 %"shf_result.3", -1
  %".172" = xor i32 16378, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"shf_result.3", 16378
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"shf_result.3", 16378
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = xor i32 %".170", -1
  %".180" = xor i32 4194304, -1
  %".181" = xor i32 0, -1
  %".182" = and i32 %".179", 4194304
  %".183" = and i32 %".182", %".181"
  %".184" = and i32 %".179", 4194304
  %".185" = and i32 %".184", 0
  %".186" = or i32 %".183", %".185"
  %".187" = and i32 %".170", %".180"
  %".188" = and i32 %".187", %".181"
  %".189" = or i32 %".186", %".188"
  %".190" = and i32 %".170", %".180"
  %".191" = and i32 %".190", 0
  %".192" = or i32 %".189", %".191"
  %".193" = and i32 %".170", 4194304
  %".194" = and i32 %".193", %".181"
  %".195" = or i32 %".192", %".194"
  %".196" = and i32 %".170", 4194304
  %".197" = and i32 %".196", 0
  %".198" = or i32 %".195", %".197"
  %".199" = xor i32 %".178", -1
  %".200" = xor i32 4194304, -1
  %".201" = xor i32 0, -1
  %".202" = and i32 %".199", 4194304
  %".203" = and i32 %".202", %".201"
  %".204" = and i32 %".199", 4194304
  %".205" = and i32 %".204", 0
  %".206" = or i32 %".203", %".205"
  %".207" = and i32 %".178", %".200"
  %".208" = and i32 %".207", %".201"
  %".209" = or i32 %".206", %".208"
  %".210" = and i32 %".178", %".200"
  %".211" = and i32 %".210", 0
  %".212" = or i32 %".209", %".211"
  %".213" = and i32 %".178", 4194304
  %".214" = and i32 %".213", %".201"
  %".215" = or i32 %".212", %".214"
  %".216" = and i32 %".178", 4194304
  %".217" = and i32 %".216", 0
  %".218" = or i32 %".215", %".217"
  br label %"BB_0ca0"
BB_0ca0:
  %"phi.11" = phi  i32 [%"P13_to_i32", %"BB_0ba0"], [%"P2_to_i32", %"BB_0cd0"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0ba0"], [%"phi.14", %"BB_0cd0"]
  %"cond_trunc.9" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000ca0", label %"BB_0cb0"
BB_80000ca0:
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P31_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0cb0"
BB_0cb0:
  %"phi.13" = phi  i32 [%"P31_to_i32", %"BB_80000ca0"], [%"phi.11", %"BB_0ca0"]
  %"mma_a_r0_ext" = zext i32 %".198" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 536887328 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".222" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".223" = sub i64 %".222", 0
  %".224" = lshr i64 %".223", 4
  %".225" = add i64 %"mma_a_packed_1", %".224"
  %".226" = and i64 %".225", 16383
  %".227" = and i64 %"mma_a_packed_1", -16384
  %".228" = or i64 %".227", %".226"
  %"mma_b_r0_ext" = zext i32 %".218" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 536887328 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".229" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".230" = sub i64 %".229", 0
  %".231" = lshr i64 %".230", 4
  %".232" = add i64 %"mma_b_packed_1", %".231"
  %".233" = and i64 %".232", 16383
  %".234" = and i64 %"mma_b_packed_1", -16384
  %".235" = or i64 %".234", %".233"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::2.kind::tf32 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.2", i64 %".228", i64 %".235", i32 269060368, i32 %"mma_arg_zext")
  br label %"BB_0cc0"
BB_0cc0:
  %"cond_trunc.10" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000cc0", label %"BB_0cd0"
BB_80000cc0:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".239" = xor i32 %"plop3_a_bit.1", 1
  %".240" = xor i32 %"plop3_b_bit.1", 1
  %".241" = xor i32 %"plop3_c_bit.1", 1
  %".242" = and i32 %".239", %"plop3_b_bit.1"
  %".243" = and i32 %".242", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".243", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0cd0"
BB_0cd0:
  %"phi.14" = phi  i32 [%"P23_to_i32", %"BB_80000cc0"], [%"phi.12", %"BB_0cc0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".245" = xor i32 %"plop3_a_bit.2", 1
  %".246" = xor i32 %"plop3_b_bit.2", 1
  %".247" = xor i32 %"plop3_c_bit.2", 1
  %".248" = and i32 %".245", %"plop3_b_bit.2"
  %".249" = and i32 %".248", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".249", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0ca0", label %"BB_0cf0"
BB_0cf0:
  %"iadd3_n1.6" = add i32 1024, 10240
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".251" = xor i32 %"plop3_a_bit.3", 1
  %".252" = xor i32 %"plop3_b_bit.3", 1
  %".253" = xor i32 %"plop3_c_bit.3", 1
  %".254" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".255" = and i32 %".254", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".255", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".256" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".257" = zext i32 %"iadd3_n2.6" to i64
  %".258" = zext i32 24 to i64
  %".259" = shl i64 %".256", %".258"
  %".260" = and i64 %".259", 4294967295
  %".261" = add i64 %".260", %".257"
  %".262" = trunc i64 %".261" to i32
  br label %"BB_0d30"
BB_0d30:
  %"phi.15" = phi  i32 [%"P2_to_i32", %"BB_0cf0"], [%"P7_to_i32", %"BB_0d60"]
  %"phi.16" = phi  i32 [%"P14_to_i32", %"BB_0cf0"], [%"phi.18", %"BB_0d60"]
  %"cond_trunc.11" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000d30", label %"BB_0d40"
BB_80000d30:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P4_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0d40"
BB_0d40:
  %"phi.17" = phi  i32 [%"P4_to_i32", %"BB_80000d30"], [%"phi.15", %"BB_0d30"]
  %"utcbar_local_winoff" = and i32 %".262", 16777215
  %".266" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".267" = ptrtoint i8 addrspace(3)* %".266" to i32
  %".268" = lshr i32 %".262", 24
  %"utcbar_mask16_trunc" = trunc i32 3 to i16
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], $2; } }", "r,r,h,~{memory}"(i32 %".267", i32 %".268", i16 %"utcbar_mask16_trunc")
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.12" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000d50", label %"BB_0d60"
BB_80000d50:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".272" = xor i32 %"plop3_a_bit.4", 1
  %".273" = xor i32 %"plop3_b_bit.4", 1
  %".274" = xor i32 %"plop3_c_bit.4", 1
  %".275" = and i32 %".272", %"plop3_b_bit.4"
  %".276" = and i32 %".275", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".276", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0d60"
BB_0d60:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_80000d50"], [%"phi.16", %"BB_0d50"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".278" = xor i32 %"plop3_a_bit.5", 1
  %".279" = xor i32 %"plop3_b_bit.5", 1
  %".280" = xor i32 %"plop3_c_bit.5", 1
  %".281" = and i32 %".278", %"plop3_b_bit.5"
  %".282" = and i32 %".281", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".282", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0d30", label %"BB_0d80"
BB_0d80:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"isetrp_cmp1.6" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.7" = mul i32 %"tid_x.1", 65536
  %"imad.9" = add i32 %"imad_tmp.7", 0
  %".284" = xor i32 %"imad.9", -1
  %".285" = xor i32 65011712, -1
  %".286" = xor i32 0, -1
  %".287" = and i32 %"imad.9", 65011712
  %".288" = and i32 %".287", %".286"
  %".289" = and i32 %"imad.9", 65011712
  %".290" = and i32 %".289", 0
  %".291" = or i32 %".288", %".290"
  %"imad_tmp.8" = mul i32 %"lds.1", 1
  %"imad.10" = add i32 %"imad_tmp.8", %".291"
  br label %"BB_0e00"
BB_0e00:
  %"cond_trunc.13" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0e70", label %"BB_0e10"
BB_0e10:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.7" = add i32 1024, 10240
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.9", %"iadd3_n2.7"
  %".294" = zext i32 %"cluster_ctarank.1" to i64
  %".295" = zext i32 %"imad.11" to i64
  %".296" = zext i32 24 to i64
  %".297" = shl i64 %".294", %".296"
  %".298" = and i64 %".297", 4294967295
  %".299" = add i64 %".298", %".295"
  %".300" = trunc i64 %".299" to i32
  %"iadd3_n1.8" = add i32 %".300", 0
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"mbar_shared_winoff.1" = and i32 %"iadd3_n2.8", 16777215
  %".301" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".301" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P33_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0e60"
BB_0e60:
  %"cond_trunc.14" = trunc i32 %"P33_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_1670", label %"BB_0e70"
BB_1670:
  %"iadd3_n1.9" = add i32 %".300", 0
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"mbar_shared_winoff.2" = and i32 %"iadd3_n2.9", 16777215
  %".304" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".304" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P24_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1690"
BB_1690:
  %"cond_trunc.15" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1670", label %"BB_0e70"
BB_0e70:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.10" = mul i32 %"cluster_ctarank", 128
  %"imad.12" = add i32 %"imad_tmp.10", %"tid_x.1"
  %"isetrp_cmp1.7" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".307" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".308" = bitcast i8* %".307" to i64*
  %"ldc_const.1" = load i64, i64* %".308"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.11" = mul i32 %"imad.12", 32
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.10")
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.10", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".314" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".315" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".316" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.1" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R88:R68_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R88:R68_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R88:R68_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R88:R68_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R88:R68_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R88:R68_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R88:R68_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R88:R68_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R88:R68_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R88:R68_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.10", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R88:R68_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".314", i32 addrspace(1)* %"R88:R68_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R88:R68_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".315", i32 addrspace(1)* %"R88:R68_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R88:R68_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".316", i32 addrspace(1)* %"R88:R68_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.10", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".331" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".332" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R88:R68_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R88:R68_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R88:R68_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R88:R68_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R88:R68_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R88:R68_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R88:R68_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R88:R68_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R88:R68_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R88:R68_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.10", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".338" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R88:R68_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R88:R68_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R88:R68_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".331", i32 addrspace(1)* %"R88:R68_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R88:R68_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".332", i32 addrspace(1)* %"R88:R68_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.10", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".345" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".346" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".347" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".348" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R88:R68_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".338", i32 addrspace(1)* %"R88:R68_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R88:R68_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R88:R68_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R88:R68_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R88:R68_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R88:R68_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R88:R68_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R88:R68_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".345", i32 addrspace(1)* %"R88:R68_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.10", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R88:R68_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".346", i32 addrspace(1)* %"R88:R68_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R88:R68_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".347", i32 addrspace(1)* %"R88:R68_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R88:R68_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".348", i32 addrspace(1)* %"R88:R68_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.10", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R88:R68_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R88:R68_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R88:R68_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R88:R68_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R88:R68_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R88:R68_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R88:R68_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R88:R68_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R88:R68_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R88:R68_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R88:R68_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R88:R68_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R88:R68_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R88:R68_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R88:R68_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R88:R68_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_1310"
BB_1310:
  %"cond_trunc.16" = trunc i32 %"P25_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80001310", label %"BB_1320"
BB_1320:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".115", 10248
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".377" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".377" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  call void asm sideeffect "tcgen05.dealloc.cta_group::2.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %"lds.3", i32 64) convergent
  ret void
BB_80001310:
  ret void
}

define void @"_Z8mma_caseILj10517EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"UR15:UR14_r0" = trunc i64 %"ldc_const" to i32
  %"UR15:UR14_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR15:UR14_r1" = trunc i64 %"UR15:UR14_r1_shift" to i32
  %"imad_tmp" = mul i32 %"s2ur_cluster_ctarank", 2816
  %"imad" = add i32 %"imad_tmp", 0
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.1" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"UR5:UR4_r0" = trunc i64 %"imad.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"imad.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"UR5:UR4_r0"
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"UR5:UR4_r1"
  %"imad_addend_r0_ext.1" = zext i32 %"imad.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"imad.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.4", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0" to i64
  %"iadd3_o2_64" = zext i32 %"UR15:UR14_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"iadd3_n1" = add i32 %"R3:R2_r1", %"UR15:UR14_r1"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P1_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"iadd3_cin2_add", %"EntryBB_0000"], [%"imad_with_cin", %"BB_01b0"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_01b0"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_01b0"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"EntryBB_0000"], [%"iadd3_trunc.1", %"BB_01b0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R11:R60_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R11:R60_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P8_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.3", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P8_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.5", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0130", label %"BB_01c0"
BB_01c0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 511
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.1" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0300", label %"BB_0210"
BB_0210:
  %"iadd3_n1.1" = add i32 1024, 8192
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_64.2" = zext i32 %"iadd3_trunc" to i64
  %"iadd3_o2_64.2" = zext i32 8192 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2.1" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.4", %"iadd3_cin2_add"
  %"imad_cin_trunc.1" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.6", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0270"
BB_0270:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_0210"], [%"imad_with_cin.2", %"BB_02f0"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_0210"], [%"viadd.2", %"BB_02f0"]
  %"phi.6" = phi  i32 [%".58", %"BB_0210"], [%"viadd.3", %"BB_02f0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.2", %"BB_0210"], [%"iadd3_trunc.3", %"BB_02f0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R44:R64_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R44:R64_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 384
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.3" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.3" = zext i32 512 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.5", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.7", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02f0"
BB_02f0:
  %"cond_trunc.2" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0270", label %"BB_0300"
BB_0300:
  %"vote_pred_trunc" = trunc i32 %"P28_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P17_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0340"
BB_0340:
  %"cond_trunc.3" = trunc i32 %"P17_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000340", label %"BB_0390"
BB_80000340:
  %"iadd3_n1.2" = add i32 1024, 10240
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.3" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".66" = zext i32 %"iadd3_n2.3" to i64
  %".67" = zext i32 0 to i64
  %".68" = shl i64 %".67", 32
  %"shf_concat" = or i64 %".66", %".68"
  %"shf_shift_64" = zext i32 11 to i64
  %".69" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".69" to i32
  %".70" = zext i32 %"iadd3_n2.3" to i64
  %".71" = zext i32 0 to i64
  %".72" = shl i64 %".71", 32
  %"shf_concat.1" = or i64 %".70", %".72"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".73" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".73" to i32
  %".74" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".75" = zext i32 %"iadd3_n2.2" to i64
  %".76" = zext i32 24 to i64
  %".77" = shl i64 %".74", %".76"
  %".78" = and i64 %".77", 4294967295
  %".79" = add i64 %".78", %".75"
  %".80" = trunc i64 %".79" to i32
  br label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%".80", %"BB_80000340"], [0, %"BB_0340"]
  %"phi.9" = phi  i32 [%"shf_result", %"BB_80000340"], [%"UR5:UR4_r1", %"BB_0340"]
  %"phi.10" = phi  i32 [%"shf_result.1", %"BB_80000340"], [1, %"BB_0340"]
  %"vote_pred_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P18_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.4" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800003b0", label %"BB_03c0"
BB_800003b0:
  %"mbar_shared_winoff" = and i32 %"phi.8", 16777215
  %".85" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".85" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".86" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".86" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_03c0"
BB_03c0:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800003c0", label %"BB_03d0"
BB_800003c0:
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.6" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0a50", label %"BB_03e0"
BB_03e0:
  %".92" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".93" = zext i32 64 to i64
  %".94" = zext i32 24 to i64
  %".95" = shl i64 %".92", %".94"
  %".96" = and i64 %".95", 4294967295
  %".97" = add i64 %".96", %".93"
  %".98" = trunc i64 %".97" to i32
  %"lds_shared_addr_winoff" = and i32 %".98", 16777215
  %".99" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".99"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0440"
BB_0440:
  %"cond_trunc.7" = trunc i32 %"P12_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_09f0", label %"BB_0450"
BB_0450:
  %"pair_shared_winoff" = and i32 11272, 16777215
  %".102" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"pair_shared_winoff"
  %".103" = ptrtoint i8 addrspace(3)* %".102" to i32
  call void asm sideeffect "tcgen05.alloc.cta_group::2.sync.aligned.shared::cta.b32 [$0], $1;", "r,r,~{memory}"(i32 %".103", i32 64) convergent
  br label %"BB_0a50"
BB_09f0:
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.6", -1
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 10248
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  call void @"llvm.trap"()
  br label %"BB_0a50"
BB_0a50:
  %".109" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".110" = bitcast i8* %".109" to i64*
  %"ldc_const.1" = load i64, i64* %".110"
  %"UR5:UR4_r0.1" = trunc i64 %"ldc_const.1" to i32
  %"UR5:UR4_r1_shift.1" = lshr i64 %"ldc_const.1", 32
  %"UR5:UR4_r1.1" = trunc i64 %"UR5:UR4_r1_shift.1" to i32
  %"imad_tmp.7" = mul i32 %"tid_x.1", 2
  %"imad.9" = add i32 %"imad_tmp.7", 0
  %".111" = zext i32 %"imad" to i64
  %".112" = zext i32 %"UR5:UR4_r0.1" to i64
  %".113" = zext i32 2 to i64
  %".114" = shl i64 %".111", %".113"
  %".115" = and i64 %".114", 4294967295
  %".116" = add i64 %".115", %".112"
  %".117" = trunc i64 %".116" to i32
  %".118" = lshr i64 %".116", 32
  %".119" = trunc i64 %".118" to i1
  %"P19_to_i32" = zext i1 %".119" to i32
  %".120" = zext i32 %"imad" to i64
  %".121" = zext i32 0 to i64
  %".122" = shl i64 %".121", 32
  %"lea_funnel" = or i64 %".120", %".122"
  %".123" = zext i32 %"UR5:UR4_r1.1" to i64
  %".124" = zext i32 2 to i64
  %".125" = shl i64 %"lea_funnel", %".124"
  %".126" = lshr i64 %".125", 32
  %".127" = add i64 %".126", %".123"
  %"lea_cin_trunc" = trunc i32 %"P19_to_i32" to i1
  %".128" = zext i1 %"lea_cin_trunc" to i64
  %".129" = add i64 %".127", %".128"
  %".130" = trunc i64 %".129" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.8", %".117"
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.9", %".130"
  %"imad_addend_r0_ext.2" = zext i32 %"imad.10" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"imad.11" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.12" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R9:R8_r0" = trunc i64 %"imad.12" to i32
  %"R9:R8_r1_shift" = lshr i64 %"imad.12", 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R9:R8_r0" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R9:R8_r1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 10240
  %"R120:R99_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R120:R99_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R9:R8_r0" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R9:R8_r1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 10244
  %"R120:R99_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R120:R99_addr_ptr.1"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.10" = mul i32 %"tid_x.1", 65536
  %"imad.13" = add i32 %"imad_tmp.10", 0
  %"R7:R6_r0" = trunc i64 0 to i32
  %"R7:R6_r1_shift" = lshr i64 0, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %".131" = xor i32 %"imad.13", -1
  %".132" = xor i32 65011712, -1
  %".133" = xor i32 0, -1
  %".134" = and i32 %"imad.13", 65011712
  %".135" = and i32 %".134", %".133"
  %".136" = and i32 %"imad.13", 65011712
  %".137" = and i32 %".136", 0
  %".138" = or i32 %".135", %".137"
  %".139" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".140" = zext i32 1024 to i64
  %".141" = zext i32 24 to i64
  %".142" = shl i64 %".139", %".141"
  %".143" = and i64 %".142", 4294967295
  %".144" = add i64 %".143", %".140"
  %".145" = trunc i64 %".144" to i32
  %".146" = xor i32 %"tid_x.1", -1
  %".147" = xor i32 %"s2ur_cluster_ctarank.1", -1
  %".148" = xor i32 0, -1
  %".149" = and i32 %".146", %"s2ur_cluster_ctarank.1"
  %".150" = and i32 %".149", %".148"
  %".151" = and i32 %".146", %"s2ur_cluster_ctarank.1"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %".154" = and i32 %"tid_x.1", %".147"
  %".155" = and i32 %".154", %".148"
  %".156" = or i32 %".153", %".155"
  %".157" = and i32 %"tid_x.1", %".147"
  %".158" = and i32 %".157", 0
  %".159" = or i32 %".156", %".158"
  %".160" = and i32 %"tid_x.1", %"s2ur_cluster_ctarank.1"
  %".161" = and i32 %".160", %".148"
  %".162" = or i32 %".159", %".161"
  %".163" = and i32 %"tid_x.1", %"s2ur_cluster_ctarank.1"
  %".164" = and i32 %".163", 0
  %".165" = or i32 %".162", %".164"
  %"lop3_pred_cmp" = icmp ne i32 %".165", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P29_to_i32" = zext i1 %"lop3_p" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".145", 10248
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.11" = mul i32 %"lds.1", 1
  %"imad.14" = add i32 %"imad_tmp.11", %".138"
  %"sttm_memaddr_offset_add" = add i32 %"imad.14", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"R7:R6_r0", i32 %"R7:R6_r1")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0c90"
BB_0c90:
  %"cond_trunc.8" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0e80", label %"BB_0ca0"
BB_0ca0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".145", 10248
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".174" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".174" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.4" = add i32 1024, 8192
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"viadd.4" = add i32 %"lds.1", 32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".175" = xor i32 %"plop3_a_bit", 1
  %".176" = xor i32 %"plop3_b_bit", 1
  %".177" = xor i32 %"plop3_c_bit", 1
  %".178" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".179" = and i32 %".178", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".179", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".180" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".181" = zext i32 %"iadd3_n2.4" to i64
  %".182" = zext i32 24 to i64
  %".183" = shl i64 %".180", %".182"
  %".184" = and i64 %".183", 4294967295
  %".185" = add i64 %".184", %".181"
  %".186" = trunc i64 %".185" to i32
  %".187" = zext i32 0 to i64
  %".188" = zext i32 %".145" to i64
  %".189" = shl i64 %".188", 32
  %"shf_concat.2" = or i64 %".187", %".189"
  %"shf_shift_64.2" = zext i32 4 to i64
  %".190" = lshr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi" = lshr i64 %".190", 32
  %"shf_result.2" = trunc i64 %"shf_hi" to i32
  %".191" = zext i32 0 to i64
  %".192" = zext i32 %".186" to i64
  %".193" = shl i64 %".192", 32
  %"shf_concat.3" = or i64 %".191", %".193"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".194" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".194", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".195" = xor i32 %"shf_result.2", -1
  %".196" = xor i32 16376, -1
  %".197" = xor i32 0, -1
  %".198" = and i32 %"shf_result.2", 16376
  %".199" = and i32 %".198", %".197"
  %".200" = and i32 %"shf_result.2", 16376
  %".201" = and i32 %".200", 0
  %".202" = or i32 %".199", %".201"
  %".203" = xor i32 %"shf_result.3", -1
  %".204" = xor i32 16376, -1
  %".205" = xor i32 0, -1
  %".206" = and i32 %"shf_result.3", 16376
  %".207" = and i32 %".206", %".205"
  %".208" = and i32 %"shf_result.3", 16376
  %".209" = and i32 %".208", 0
  %".210" = or i32 %".207", %".209"
  %".211" = xor i32 %".202", -1
  %".212" = xor i32 524288, -1
  %".213" = xor i32 0, -1
  %".214" = and i32 %".211", 524288
  %".215" = and i32 %".214", %".213"
  %".216" = and i32 %".211", 524288
  %".217" = and i32 %".216", 0
  %".218" = or i32 %".215", %".217"
  %".219" = and i32 %".202", %".212"
  %".220" = and i32 %".219", %".213"
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".202", %".212"
  %".223" = and i32 %".222", 0
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".202", 524288
  %".226" = and i32 %".225", %".213"
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".202", 524288
  %".229" = and i32 %".228", 0
  %".230" = or i32 %".227", %".229"
  %".231" = xor i32 %".210", -1
  %".232" = xor i32 524288, -1
  %".233" = xor i32 0, -1
  %".234" = and i32 %".231", 524288
  %".235" = and i32 %".234", %".233"
  %".236" = and i32 %".231", 524288
  %".237" = and i32 %".236", 0
  %".238" = or i32 %".235", %".237"
  %".239" = and i32 %".210", %".232"
  %".240" = and i32 %".239", %".233"
  %".241" = or i32 %".238", %".240"
  %".242" = and i32 %".210", %".232"
  %".243" = and i32 %".242", 0
  %".244" = or i32 %".241", %".243"
  %".245" = and i32 %".210", 524288
  %".246" = and i32 %".245", %".233"
  %".247" = or i32 %".244", %".246"
  %".248" = and i32 %".210", 524288
  %".249" = and i32 %".248", 0
  %".250" = or i32 %".247", %".249"
  br label %"BB_0da0"
BB_0da0:
  %"phi.11" = phi  i32 [%"P13_to_i32", %"BB_0ca0"], [%"P2_to_i32", %"BB_0dd0"]
  %"phi.12" = phi  i32 [%"P30_to_i32", %"BB_0ca0"], [%"phi.14", %"BB_0dd0"]
  %"cond_trunc.9" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000da0", label %"BB_0db0"
BB_80000da0:
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P32_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0db0"
BB_0db0:
  %"phi.13" = phi  i32 [%"P32_to_i32", %"BB_80000da0"], [%"phi.11", %"BB_0da0"]
  %"mma_a_r0_ext" = zext i32 %".230" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".254" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".255" = sub i64 %".254", 0
  %".256" = lshr i64 %".255", 4
  %".257" = add i64 %"mma_a_packed_1", %".256"
  %".258" = and i64 %".257", 16383
  %".259" = and i64 %"mma_a_packed_1", -16384
  %".260" = or i64 %".259", %".258"
  %"mma_b_r0_ext" = zext i32 %".250" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16416 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".261" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".262" = sub i64 %".261", 0
  %".263" = lshr i64 %".262", 4
  %".264" = add i64 %"mma_b_packed_1", %".263"
  %".265" = and i64 %".264", 16383
  %".266" = and i64 %"mma_b_packed_1", -16384
  %".267" = or i64 %".266", %".265"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.sp.cta_group::2.kind::tf32 [$0], $1, $2, [$5], $3, use_d; } }", "r,l,l,r,r,r,~{memory}"(i32 %"lds.2", i64 %".260", i64 %".267", i32 268970261, i32 %"mma_arg_zext", i32 %"viadd.4")
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.10" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000dc0", label %"BB_0dd0"
BB_80000dc0:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".271" = xor i32 %"plop3_a_bit.1", 1
  %".272" = xor i32 %"plop3_b_bit.1", 1
  %".273" = xor i32 %"plop3_c_bit.1", 1
  %".274" = and i32 %".271", %"plop3_b_bit.1"
  %".275" = and i32 %".274", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".275", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0dd0"
BB_0dd0:
  %"phi.14" = phi  i32 [%"P23_to_i32", %"BB_80000dc0"], [%"phi.12", %"BB_0dc0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".277" = xor i32 %"plop3_a_bit.2", 1
  %".278" = xor i32 %"plop3_b_bit.2", 1
  %".279" = xor i32 %"plop3_c_bit.2", 1
  %".280" = and i32 %".277", %"plop3_b_bit.2"
  %".281" = and i32 %".280", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".281", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0da0", label %"BB_0df0"
BB_0df0:
  %"iadd3_n1.5" = add i32 1024, 10240
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".283" = xor i32 %"plop3_a_bit.3", 1
  %".284" = xor i32 %"plop3_b_bit.3", 1
  %".285" = xor i32 %"plop3_c_bit.3", 1
  %".286" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".287" = and i32 %".286", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".287", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".288" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".289" = zext i32 %"iadd3_n2.5" to i64
  %".290" = zext i32 24 to i64
  %".291" = shl i64 %".288", %".290"
  %".292" = and i64 %".291", 4294967295
  %".293" = add i64 %".292", %".289"
  %".294" = trunc i64 %".293" to i32
  br label %"BB_0e30"
BB_0e30:
  %"phi.15" = phi  i32 [%"P2_to_i32", %"BB_0df0"], [%"P7_to_i32", %"BB_0e60"]
  %"phi.16" = phi  i32 [%"P14_to_i32", %"BB_0df0"], [%"phi.18", %"BB_0e60"]
  %"cond_trunc.11" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000e30", label %"BB_0e40"
BB_80000e30:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P4_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0e40"
BB_0e40:
  %"phi.17" = phi  i32 [%"P4_to_i32", %"BB_80000e30"], [%"phi.15", %"BB_0e30"]
  %"utcbar_local_winoff" = and i32 %".294", 16777215
  %".298" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".299" = ptrtoint i8 addrspace(3)* %".298" to i32
  %".300" = lshr i32 %".294", 24
  %"utcbar_mask16_trunc" = trunc i32 3 to i16
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], $2; } }", "r,r,h,~{memory}"(i32 %".299", i32 %".300", i16 %"utcbar_mask16_trunc")
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.12" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000e50", label %"BB_0e60"
BB_80000e50:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".304" = xor i32 %"plop3_a_bit.4", 1
  %".305" = xor i32 %"plop3_b_bit.4", 1
  %".306" = xor i32 %"plop3_c_bit.4", 1
  %".307" = and i32 %".304", %"plop3_b_bit.4"
  %".308" = and i32 %".307", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".308", 0
  %"P21_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0e60"
BB_0e60:
  %"phi.18" = phi  i32 [%"P21_to_i32", %"BB_80000e50"], [%"phi.16", %"BB_0e50"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".310" = xor i32 %"plop3_a_bit.5", 1
  %".311" = xor i32 %"plop3_b_bit.5", 1
  %".312" = xor i32 %"plop3_c_bit.5", 1
  %".313" = and i32 %".310", %"plop3_b_bit.5"
  %".314" = and i32 %".313", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".314", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0e30", label %"BB_0e80"
BB_0e80:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"isetrp_cmp1.6" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0ed0"
BB_0ed0:
  %"cond_trunc.13" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0f40", label %"BB_0ee0"
BB_0ee0:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.6" = add i32 1024, 10240
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %"iadd3_n2.6"
  %".318" = zext i32 %"cluster_ctarank.1" to i64
  %".319" = zext i32 %"imad.15" to i64
  %".320" = zext i32 24 to i64
  %".321" = shl i64 %".318", %".320"
  %".322" = and i64 %".321", 4294967295
  %".323" = add i64 %".322", %".319"
  %".324" = trunc i64 %".323" to i32
  %"iadd3_n1.7" = add i32 %".324", 0
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"mbar_shared_winoff.1" = and i32 %"iadd3_n2.7", 16777215
  %".325" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".325" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P34_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0f30"
BB_0f30:
  %"cond_trunc.14" = trunc i32 %"P34_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_1740", label %"BB_0f40"
BB_1740:
  %"iadd3_n1.8" = add i32 %".324", 0
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"mbar_shared_winoff.2" = and i32 %"iadd3_n2.8", 16777215
  %".328" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".328" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P25_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1760"
BB_1760:
  %"cond_trunc.15" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1740", label %"BB_0f40"
BB_0f40:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.13" = mul i32 %"cluster_ctarank", 128
  %"imad.16" = add i32 %"imad_tmp.13", %"tid_x.1"
  %"isetrp_cmp1.7" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".331" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".332" = bitcast i8* %".331" to i64*
  %"ldc_const.2" = load i64, i64* %".332"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.14" = mul i32 %"imad.16", 32
  %"imad.17" = add i32 %"imad_tmp.14", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.14")
  %".333" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".334" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".335" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".336" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.14", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".337" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".338" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.3" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.3" = or i64 0, %"imad_addend_r0_ext.3"
  %"imad_addend_r1_ext.3" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.3" = shl i64 %"imad_addend_r1_ext.3", 32
  %"imad_addend_packed_1.3" = or i64 %"imad_addend_packed_0.3", %"imad_addend_r1_shift.3"
  %"imad_lhs_64.3" = zext i32 %"imad.17" to i64
  %"imad_rhs_64.3" = zext i32 4 to i64
  %"imad_tmp_64.3" = mul i64 %"imad_lhs_64.3", %"imad_rhs_64.3"
  %"imad.18" = add i64 %"imad_tmp_64.3", %"imad_addend_packed_1.3"
  %"R13:R12_r0.1" = trunc i64 %"imad.18" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.18", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R118:R95_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".333", i32 addrspace(1)* %"R118:R95_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R118:R95_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".334", i32 addrspace(1)* %"R118:R95_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R118:R95_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".335", i32 addrspace(1)* %"R118:R95_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R118:R95_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".336", i32 addrspace(1)* %"R118:R95_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R118:R95_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".337", i32 addrspace(1)* %"R118:R95_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.14", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".346" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".347" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".348" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R118:R95_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".338", i32 addrspace(1)* %"R118:R95_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R118:R95_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R118:R95_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R118:R95_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R118:R95_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.14", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".353" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R118:R95_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".346", i32 addrspace(1)* %"R118:R95_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R118:R95_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".347", i32 addrspace(1)* %"R118:R95_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R118:R95_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".348", i32 addrspace(1)* %"R118:R95_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R118:R95_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R118:R95_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R118:R95_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".353", i32 addrspace(1)* %"R118:R95_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.14", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".365" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R118:R95_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R118:R95_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R118:R95_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R118:R95_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R118:R95_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R118:R95_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.14", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".371" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R118:R95_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R118:R95_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R118:R95_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R118:R95_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R118:R95_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R118:R95_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R118:R95_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".365", i32 addrspace(1)* %"R118:R95_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R118:R95_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R118:R95_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.14", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".379" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".380" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".381" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R118:R95_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R118:R95_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R118:R95_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".371", i32 addrspace(1)* %"R118:R95_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R118:R95_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R118:R95_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.14", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".385" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".386" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".387" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".388" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R118:R95_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R118:R95_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R118:R95_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".379", i32 addrspace(1)* %"R118:R95_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R118:R95_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".380", i32 addrspace(1)* %"R118:R95_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R118:R95_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".381", i32 addrspace(1)* %"R118:R95_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R118:R95_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".385", i32 addrspace(1)* %"R118:R95_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R118:R95_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".386", i32 addrspace(1)* %"R118:R95_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R118:R95_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".387", i32 addrspace(1)* %"R118:R95_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R118:R95_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".388", i32 addrspace(1)* %"R118:R95_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_13e0"
BB_13e0:
  %"cond_trunc.16" = trunc i32 %"P26_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800013e0", label %"BB_13f0"
BB_13f0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".145", 10248
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".401" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".401" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  call void asm sideeffect "tcgen05.dealloc.cta_group::2.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %"lds.3", i32 64) convergent
  ret void
BB_800013e0:
  ret void
}

define void @"_Z8mma_caseILj2320EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"UR13:UR12_r0" = trunc i64 %"ldc_const" to i32
  %"UR13:UR12_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR13:UR12_r1" = trunc i64 %"UR13:UR12_r1_shift" to i32
  %"imad_tmp" = mul i32 %"s2ur_cluster_ctarank", 2816
  %"imad" = add i32 %"imad_tmp", 0
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.1" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"UR5:UR4_r0" = trunc i64 %"imad.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"imad.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"UR5:UR4_r0"
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"UR5:UR4_r1"
  %"imad_addend_r0_ext.1" = zext i32 %"imad.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"imad.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.4", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0" to i64
  %"iadd3_o2_64" = zext i32 %"UR13:UR12_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"iadd3_n1" = add i32 %"R3:R2_r1", %"UR13:UR12_r1"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P1_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"iadd3_cin2_add", %"EntryBB_0000"], [%"imad_with_cin", %"BB_01b0"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_01b0"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_01b0"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"EntryBB_0000"], [%"iadd3_trunc.1", %"BB_01b0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R80:R77_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R80:R77_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P8_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.3", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P8_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.5", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc" = trunc i32 %"P26_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0130", label %"BB_01c0"
BB_01c0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 511
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.1" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0300", label %"BB_0210"
BB_0210:
  %"iadd3_n1.1" = add i32 1024, 8192
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_64.2" = zext i32 %"iadd3_trunc" to i64
  %"iadd3_o2_64.2" = zext i32 8192 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2.1" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.4", %"iadd3_cin2_add"
  %"imad_cin_trunc.1" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.6", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0270"
BB_0270:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_0210"], [%"imad_with_cin.2", %"BB_02f0"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_0210"], [%"viadd.2", %"BB_02f0"]
  %"phi.6" = phi  i32 [%".58", %"BB_0210"], [%"viadd.3", %"BB_02f0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.2", %"BB_0210"], [%"iadd3_trunc.3", %"BB_02f0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R83:R121_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R83:R121_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 384
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.3" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.3" = zext i32 512 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.5", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.7", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02f0"
BB_02f0:
  %"cond_trunc.2" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0270", label %"BB_0300"
BB_0300:
  %"vote_pred_trunc" = trunc i32 %"P27_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P17_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0340"
BB_0340:
  %"cond_trunc.3" = trunc i32 %"P17_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000340", label %"BB_0390"
BB_80000340:
  %"iadd3_n1.2" = add i32 1024, 10240
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.3" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".66" = zext i32 %"iadd3_n2.3" to i64
  %".67" = zext i32 0 to i64
  %".68" = shl i64 %".67", 32
  %"shf_concat" = or i64 %".66", %".68"
  %"shf_shift_64" = zext i32 11 to i64
  %".69" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".69" to i32
  %".70" = zext i32 %"iadd3_n2.3" to i64
  %".71" = zext i32 0 to i64
  %".72" = shl i64 %".71", 32
  %"shf_concat.1" = or i64 %".70", %".72"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".73" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".73" to i32
  %".74" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".75" = zext i32 %"iadd3_n2.2" to i64
  %".76" = zext i32 24 to i64
  %".77" = shl i64 %".74", %".76"
  %".78" = and i64 %".77", 4294967295
  %".79" = add i64 %".78", %".75"
  %".80" = trunc i64 %".79" to i32
  br label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%".80", %"BB_80000340"], [0, %"BB_0340"]
  %"phi.9" = phi  i32 [%"shf_result", %"BB_80000340"], [%"UR5:UR4_r1", %"BB_0340"]
  %"phi.10" = phi  i32 [%"shf_result.1", %"BB_80000340"], [1, %"BB_0340"]
  %"vote_pred_trunc.1" = trunc i32 %"P27_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P18_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.4" = trunc i32 %"P18_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800003b0", label %"BB_03c0"
BB_800003b0:
  %"mbar_shared_winoff" = and i32 %"phi.8", 16777215
  %".85" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".85" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".86" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".86" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_03c0"
BB_03c0:
  %"cond_trunc.5" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800003c0", label %"BB_03d0"
BB_800003c0:
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.6" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0a50", label %"BB_03e0"
BB_03e0:
  %".92" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".93" = zext i32 64 to i64
  %".94" = zext i32 24 to i64
  %".95" = shl i64 %".92", %".94"
  %".96" = and i64 %".95", 4294967295
  %".97" = add i64 %".96", %".93"
  %".98" = trunc i64 %".97" to i32
  %"lds_shared_addr_winoff" = and i32 %".98", 16777215
  %".99" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".99"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0440"
BB_0440:
  %"cond_trunc.7" = trunc i32 %"P12_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_09f0", label %"BB_0450"
BB_0450:
  %"pair_shared_winoff" = and i32 11272, 16777215
  %".102" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"pair_shared_winoff"
  %".103" = ptrtoint i8 addrspace(3)* %".102" to i32
  call void asm sideeffect "tcgen05.alloc.cta_group::2.sync.aligned.shared::cta.b32 [$0], $1;", "r,r,~{memory}"(i32 %".103", i32 64) convergent
  br label %"BB_0a50"
BB_09f0:
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.6", -1
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 10248
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  call void @"llvm.trap"()
  br label %"BB_0a50"
BB_0a50:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %".109" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".110" = zext i32 1024 to i64
  %".111" = zext i32 24 to i64
  %".112" = shl i64 %".109", %".111"
  %".113" = and i64 %".112", 4294967295
  %".114" = add i64 %".113", %".110"
  %".115" = trunc i64 %".114" to i32
  %".116" = xor i32 %"tid_x.1", -1
  %".117" = xor i32 %"s2ur_cluster_ctarank.1", -1
  %".118" = xor i32 0, -1
  %".119" = and i32 %".116", %"s2ur_cluster_ctarank.1"
  %".120" = and i32 %".119", %".118"
  %".121" = and i32 %".116", %"s2ur_cluster_ctarank.1"
  %".122" = and i32 %".121", 0
  %".123" = or i32 %".120", %".122"
  %".124" = and i32 %"tid_x.1", %".117"
  %".125" = and i32 %".124", %".118"
  %".126" = or i32 %".123", %".125"
  %".127" = and i32 %"tid_x.1", %".117"
  %".128" = and i32 %".127", 0
  %".129" = or i32 %".126", %".128"
  %".130" = and i32 %"tid_x.1", %"s2ur_cluster_ctarank.1"
  %".131" = and i32 %".130", %".118"
  %".132" = or i32 %".129", %".131"
  %".133" = and i32 %"tid_x.1", %"s2ur_cluster_ctarank.1"
  %".134" = and i32 %".133", 0
  %".135" = or i32 %".132", %".134"
  %"lop3_pred_cmp" = icmp ne i32 %".135", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P28_to_i32" = zext i1 %"lop3_p" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".115", 10248
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".136" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".136" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0b90"
BB_0b90:
  %"cond_trunc.8" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0d70", label %"BB_0ba0"
BB_0ba0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".115", 10248
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".142" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".142" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.4" = add i32 1024, 8192
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".143" = xor i32 %"plop3_a_bit", 1
  %".144" = xor i32 %"plop3_b_bit", 1
  %".145" = xor i32 %"plop3_c_bit", 1
  %".146" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".147" = and i32 %".146", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".147", 0
  %"P29_to_i32" = zext i1 %"plop3_pred" to i32
  %".148" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".149" = zext i32 %"iadd3_n2.4" to i64
  %".150" = zext i32 24 to i64
  %".151" = shl i64 %".148", %".150"
  %".152" = and i64 %".151", 4294967295
  %".153" = add i64 %".152", %".149"
  %".154" = trunc i64 %".153" to i32
  %".155" = zext i32 0 to i64
  %".156" = zext i32 %".115" to i64
  %".157" = shl i64 %".156", 32
  %"shf_concat.2" = or i64 %".155", %".157"
  %"shf_shift_64.2" = zext i32 4 to i64
  %".158" = lshr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi" = lshr i64 %".158", 32
  %"shf_result.2" = trunc i64 %"shf_hi" to i32
  %".159" = zext i32 0 to i64
  %".160" = zext i32 %".154" to i64
  %".161" = shl i64 %".160", 32
  %"shf_concat.3" = or i64 %".159", %".161"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".162" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".162", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".163" = xor i32 %"shf_result.2", -1
  %".164" = xor i32 16376, -1
  %".165" = xor i32 0, -1
  %".166" = and i32 %"shf_result.2", 16376
  %".167" = and i32 %".166", %".165"
  %".168" = and i32 %"shf_result.2", 16376
  %".169" = and i32 %".168", 0
  %".170" = or i32 %".167", %".169"
  %".171" = xor i32 %"shf_result.3", -1
  %".172" = xor i32 16376, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"shf_result.3", 16376
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"shf_result.3", 16376
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = xor i32 %".170", -1
  %".180" = xor i32 524288, -1
  %".181" = xor i32 0, -1
  %".182" = and i32 %".179", 524288
  %".183" = and i32 %".182", %".181"
  %".184" = and i32 %".179", 524288
  %".185" = and i32 %".184", 0
  %".186" = or i32 %".183", %".185"
  %".187" = and i32 %".170", %".180"
  %".188" = and i32 %".187", %".181"
  %".189" = or i32 %".186", %".188"
  %".190" = and i32 %".170", %".180"
  %".191" = and i32 %".190", 0
  %".192" = or i32 %".189", %".191"
  %".193" = and i32 %".170", 524288
  %".194" = and i32 %".193", %".181"
  %".195" = or i32 %".192", %".194"
  %".196" = and i32 %".170", 524288
  %".197" = and i32 %".196", 0
  %".198" = or i32 %".195", %".197"
  %".199" = xor i32 %".178", -1
  %".200" = xor i32 524288, -1
  %".201" = xor i32 0, -1
  %".202" = and i32 %".199", 524288
  %".203" = and i32 %".202", %".201"
  %".204" = and i32 %".199", 524288
  %".205" = and i32 %".204", 0
  %".206" = or i32 %".203", %".205"
  %".207" = and i32 %".178", %".200"
  %".208" = and i32 %".207", %".201"
  %".209" = or i32 %".206", %".208"
  %".210" = and i32 %".178", %".200"
  %".211" = and i32 %".210", 0
  %".212" = or i32 %".209", %".211"
  %".213" = and i32 %".178", 524288
  %".214" = and i32 %".213", %".201"
  %".215" = or i32 %".212", %".214"
  %".216" = and i32 %".178", 524288
  %".217" = and i32 %".216", 0
  %".218" = or i32 %".215", %".217"
  br label %"BB_0c90"
BB_0c90:
  %"phi.11" = phi  i32 [%"P13_to_i32", %"BB_0ba0"], [%"P2_to_i32", %"BB_0cc0"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0ba0"], [%"phi.14", %"BB_0cc0"]
  %"cond_trunc.9" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000c90", label %"BB_0ca0"
BB_80000c90:
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P31_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0ca0"
BB_0ca0:
  %"phi.13" = phi  i32 [%"P31_to_i32", %"BB_80000c90"], [%"phi.11", %"BB_0c90"]
  %"mma_a_r0_ext" = zext i32 %".198" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".222" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".223" = sub i64 %".222", 0
  %".224" = lshr i64 %".223", 4
  %".225" = add i64 %"mma_a_packed_1", %".224"
  %".226" = and i64 %".225", 16383
  %".227" = and i64 %"mma_a_packed_1", -16384
  %".228" = or i64 %".227", %".226"
  %"mma_b_r0_ext" = zext i32 %".218" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".229" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".230" = sub i64 %".229", 0
  %".231" = lshr i64 %".230", 4
  %".232" = add i64 %"mma_b_packed_1", %".231"
  %".233" = and i64 %".232", 16383
  %".234" = and i64 %"mma_b_packed_1", -16384
  %".235" = or i64 %".234", %".233"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::2.kind::tf32 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.2", i64 %".228", i64 %".235", i32 268962064, i32 %"mma_arg_zext")
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.10" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000cb0", label %"BB_0cc0"
BB_80000cb0:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".239" = xor i32 %"plop3_a_bit.1", 1
  %".240" = xor i32 %"plop3_b_bit.1", 1
  %".241" = xor i32 %"plop3_c_bit.1", 1
  %".242" = and i32 %".239", %"plop3_b_bit.1"
  %".243" = and i32 %".242", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".243", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0cc0"
BB_0cc0:
  %"phi.14" = phi  i32 [%"P23_to_i32", %"BB_80000cb0"], [%"phi.12", %"BB_0cb0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".245" = xor i32 %"plop3_a_bit.2", 1
  %".246" = xor i32 %"plop3_b_bit.2", 1
  %".247" = xor i32 %"plop3_c_bit.2", 1
  %".248" = and i32 %".245", %"plop3_b_bit.2"
  %".249" = and i32 %".248", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".249", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0c90", label %"BB_0ce0"
BB_0ce0:
  %"iadd3_n1.5" = add i32 1024, 10240
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".251" = xor i32 %"plop3_a_bit.3", 1
  %".252" = xor i32 %"plop3_b_bit.3", 1
  %".253" = xor i32 %"plop3_c_bit.3", 1
  %".254" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".255" = and i32 %".254", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".255", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".256" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".257" = zext i32 %"iadd3_n2.5" to i64
  %".258" = zext i32 24 to i64
  %".259" = shl i64 %".256", %".258"
  %".260" = and i64 %".259", 4294967295
  %".261" = add i64 %".260", %".257"
  %".262" = trunc i64 %".261" to i32
  br label %"BB_0d20"
BB_0d20:
  %"phi.15" = phi  i32 [%"P2_to_i32", %"BB_0ce0"], [%"P7_to_i32", %"BB_0d50"]
  %"phi.16" = phi  i32 [%"P14_to_i32", %"BB_0ce0"], [%"phi.18", %"BB_0d50"]
  %"cond_trunc.11" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000d20", label %"BB_0d30"
BB_80000d20:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P4_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0d30"
BB_0d30:
  %"phi.17" = phi  i32 [%"P4_to_i32", %"BB_80000d20"], [%"phi.15", %"BB_0d20"]
  %"utcbar_local_winoff" = and i32 %".262", 16777215
  %".266" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".267" = ptrtoint i8 addrspace(3)* %".266" to i32
  %".268" = lshr i32 %".262", 24
  %"utcbar_mask16_trunc" = trunc i32 3 to i16
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], $2; } }", "r,r,h,~{memory}"(i32 %".267", i32 %".268", i16 %"utcbar_mask16_trunc")
  br label %"BB_0d40"
BB_0d40:
  %"cond_trunc.12" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000d40", label %"BB_0d50"
BB_80000d40:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".272" = xor i32 %"plop3_a_bit.4", 1
  %".273" = xor i32 %"plop3_b_bit.4", 1
  %".274" = xor i32 %"plop3_c_bit.4", 1
  %".275" = and i32 %".272", %"plop3_b_bit.4"
  %".276" = and i32 %".275", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".276", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0d50"
BB_0d50:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_80000d40"], [%"phi.16", %"BB_0d40"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".278" = xor i32 %"plop3_a_bit.5", 1
  %".279" = xor i32 %"plop3_b_bit.5", 1
  %".280" = xor i32 %"plop3_c_bit.5", 1
  %".281" = and i32 %".278", %"plop3_b_bit.5"
  %".282" = and i32 %".281", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".282", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0d20", label %"BB_0d70"
BB_0d70:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"isetrp_cmp1.6" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.7" = mul i32 %"tid_x.1", 65536
  %"imad.9" = add i32 %"imad_tmp.7", 0
  %".284" = xor i32 %"imad.9", -1
  %".285" = xor i32 65011712, -1
  %".286" = xor i32 0, -1
  %".287" = and i32 %"imad.9", 65011712
  %".288" = and i32 %".287", %".286"
  %".289" = and i32 %"imad.9", 65011712
  %".290" = and i32 %".289", 0
  %".291" = or i32 %".288", %".290"
  %"imad_tmp.8" = mul i32 %"lds.1", 1
  %"imad.10" = add i32 %"imad_tmp.8", %".291"
  br label %"BB_0df0"
BB_0df0:
  %"cond_trunc.13" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0e60", label %"BB_0e00"
BB_0e00:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.6" = add i32 1024, 10240
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.9", %"iadd3_n2.6"
  %".294" = zext i32 %"cluster_ctarank.1" to i64
  %".295" = zext i32 %"imad.11" to i64
  %".296" = zext i32 24 to i64
  %".297" = shl i64 %".294", %".296"
  %".298" = and i64 %".297", 4294967295
  %".299" = add i64 %".298", %".295"
  %".300" = trunc i64 %".299" to i32
  %"iadd3_n1.7" = add i32 %".300", 0
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"mbar_shared_winoff.1" = and i32 %"iadd3_n2.7", 16777215
  %".301" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".301" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P33_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.14" = trunc i32 %"P33_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_1660", label %"BB_0e60"
BB_1660:
  %"iadd3_n1.8" = add i32 %".300", 0
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"mbar_shared_winoff.2" = and i32 %"iadd3_n2.8", 16777215
  %".304" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".304" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P24_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1680"
BB_1680:
  %"cond_trunc.15" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1660", label %"BB_0e60"
BB_0e60:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.10" = mul i32 %"cluster_ctarank", 128
  %"imad.12" = add i32 %"imad_tmp.10", %"tid_x.1"
  %"isetrp_cmp1.7" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".307" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".308" = bitcast i8* %".307" to i64*
  %"ldc_const.1" = load i64, i64* %".308"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.11" = mul i32 %"imad.12", 32
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.10")
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.10", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".314" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".315" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".316" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.1" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R86:R64_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R86:R64_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R86:R64_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R86:R64_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R86:R64_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R86:R64_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R86:R64_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R86:R64_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R86:R64_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R86:R64_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.10", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R86:R64_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".314", i32 addrspace(1)* %"R86:R64_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R86:R64_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".315", i32 addrspace(1)* %"R86:R64_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R86:R64_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".316", i32 addrspace(1)* %"R86:R64_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.10", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".331" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".332" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R86:R64_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R86:R64_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R86:R64_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R86:R64_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R86:R64_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R86:R64_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R86:R64_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R86:R64_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R86:R64_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R86:R64_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.10", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".338" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R86:R64_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R86:R64_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R86:R64_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".331", i32 addrspace(1)* %"R86:R64_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R86:R64_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".332", i32 addrspace(1)* %"R86:R64_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.10", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".345" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".346" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".347" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".348" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R86:R64_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".338", i32 addrspace(1)* %"R86:R64_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R86:R64_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R86:R64_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R86:R64_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R86:R64_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R86:R64_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R86:R64_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R86:R64_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".345", i32 addrspace(1)* %"R86:R64_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.10", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R86:R64_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".346", i32 addrspace(1)* %"R86:R64_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R86:R64_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".347", i32 addrspace(1)* %"R86:R64_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R86:R64_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".348", i32 addrspace(1)* %"R86:R64_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.10", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R86:R64_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R86:R64_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R86:R64_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R86:R64_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R86:R64_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R86:R64_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R86:R64_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R86:R64_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R86:R64_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R86:R64_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R86:R64_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R86:R64_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R86:R64_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R86:R64_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R86:R64_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R86:R64_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_1300"
BB_1300:
  %"cond_trunc.16" = trunc i32 %"P25_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80001300", label %"BB_1310"
BB_1310:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".115", 10248
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".377" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".377" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  call void asm sideeffect "tcgen05.dealloc.cta_group::2.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %"lds.3", i32 64) convergent
  ret void
BB_80001300:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.membar.cta"()

declare void @"llvm.nvvm.membar.gl"()

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4, !5, !6, !7, !8, !9, !10, !11, !12 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z8mma_caseILj100624EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z8mma_caseILj100624EEvPKjPj", !"cluster_dim_x", i32 2 }
!3 = !{ void (i64, i64)* @"_Z8mma_caseILj100624EEvPKjPj", !"cluster_dim_y", i32 1 }
!4 = !{ void (i64, i64)* @"_Z8mma_caseILj100624EEvPKjPj", !"cluster_dim_z", i32 1 }
!5 = !{ void (i64, i64)* @"_Z8mma_caseILj10517EEvPKjPj", !"kernel", i32 1 }
!6 = !{ void (i64, i64)* @"_Z8mma_caseILj10517EEvPKjPj", !"cluster_dim_x", i32 2 }
!7 = !{ void (i64, i64)* @"_Z8mma_caseILj10517EEvPKjPj", !"cluster_dim_y", i32 1 }
!8 = !{ void (i64, i64)* @"_Z8mma_caseILj10517EEvPKjPj", !"cluster_dim_z", i32 1 }
!9 = !{ void (i64, i64)* @"_Z8mma_caseILj2320EEvPKjPj", !"kernel", i32 1 }
!10 = !{ void (i64, i64)* @"_Z8mma_caseILj2320EEvPKjPj", !"cluster_dim_x", i32 2 }
!11 = !{ void (i64, i64)* @"_Z8mma_caseILj2320EEvPKjPj", !"cluster_dim_y", i32 1 }
!12 = !{ void (i64, i64)* @"_Z8mma_caseILj2320EEvPKjPj", !"cluster_dim_z", i32 1 }
