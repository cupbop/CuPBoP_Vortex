; ModuleID = "/tmp/cupbop-ampere-recover/pipe"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [3072 x i8], align 16
define void @"_Z5pipe3PKfPfii"(i64 %"arg_352", i64 %"arg_360", i32 %"arg_368", i32 %"arg_372")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [384 x i8], align 16
  %".6" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 352
  %".7" = bitcast i8* %".6" to i64*
  store i64 %"arg_352", i64* %".7", align 32
  %".9" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 360
  %".10" = bitcast i8* %".9" to i64*
  store i64 %"arg_360", i64* %".10", align 8
  %".12" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".13" = bitcast i8* %".12" to i32*
  store i32 %"arg_368", i32* %".13", align 16
  %".15" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 372
  %".16" = bitcast i8* %".15" to i32*
  store i32 %"arg_372", i32* %".16", align 4
  %"ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  %".18" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 372
  %".19" = bitcast i8* %".18" to i32*
  %"imad_addend" = load i32, i32* %".19"
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", %"imad_addend"
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp sge i32 %"imad", 1
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp sge i32 %"imad", 2
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"imad_tmp.1" = mul i32 %"ctaid_x", 256
  %"imad.1" = add i32 %"imad_tmp.1", 0
  %"imad_tmp.2" = mul i32 %"tid_x", 4
  %"imad.2" = add i32 %"imad_tmp.2", 0
  %".20" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 372
  %".21" = bitcast i8* %".20" to i32*
  %"imad_rhs" = load i32, i32* %".21"
  %"imad_tmp.3" = mul i32 %"imad.1", %"imad_rhs"
  %"imad.3" = add i32 %"imad_tmp.3", %"imad.2"
  br label %"BB_00a0"
BB_00a0:
  %"cond_trunc" = trunc i32 %"P11_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0120", label %"BB_00b0"
BB_00b0:
  %".24" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".25" = bitcast i8* %".24" to i32*
  %"isetrp_rhs" = load i32, i32* %".25"
  %"isetrp_cmp1.2" = icmp sge i32 %"imad.3", %"isetrp_rhs"
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P4_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.4", 4
  %"imad_tmp.5" = mul i32 %"tid_x", 16
  %"imad.5" = add i32 %"imad_tmp.5", 0
  %"sel_pred_trunc" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 %"imad.3", i32 0
  %".26" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 352
  %".27" = bitcast i8* %".26" to i64*
  %"imad_addend.1" = load i64, i64* %".27"
  %"imad_lhs_64" = sext i32 %"sel" to i64
  %"imad_rhs_64" = sext i32 %"imad.4" to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.6" = add i64 %"imad_tmp_64", %"imad_addend.1"
  %"R5:R4_r0" = trunc i64 %"imad.6" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad.6", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_0100"
BB_0100:
  %"cond_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_80000100", label %"BB_0110"
BB_80000100:
  %"cpa_smem_gep_winoff" = and i32 %"imad.5", 16777215
  %".30" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"cpa_smem_gep_winoff"
  %"cpa_smem_ptr" = ptrtoint i8 addrspace(3)* %".30" to i64
  %"cpa_gbl_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"cpa_gbl_packed_0" = or i64 0, %"cpa_gbl_r0_ext"
  %"cpa_gbl_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"cpa_gbl_r1_shift" = shl i64 %"cpa_gbl_r1_ext", 32
  %"cpa_gbl_packed_1" = or i64 %"cpa_gbl_packed_0", %"cpa_gbl_r1_shift"
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %"cpa_smem_ptr", i64 %"cpa_gbl_packed_1", i32 0)
  br label %"BB_0110"
BB_0110:
  %"cond_trunc.2" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_80000110", label %"BB_0120"
BB_80000110:
  %"cpa_smem_gep_winoff.1" = and i32 %"imad.5", 16777215
  %".34" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"cpa_smem_gep_winoff.1"
  %"cpa_smem_ptr.1" = ptrtoint i8 addrspace(3)* %".34" to i64
  %"cpa_gbl_r0_ext.1" = zext i32 %"R5:R4_r0" to i64
  %"cpa_gbl_packed_0.1" = or i64 0, %"cpa_gbl_r0_ext.1"
  %"cpa_gbl_r1_ext.1" = zext i32 %"R5:R4_r1" to i64
  %"cpa_gbl_r1_shift.1" = shl i64 %"cpa_gbl_r1_ext.1", 32
  %"cpa_gbl_packed_1.1" = or i64 %"cpa_gbl_packed_0.1", %"cpa_gbl_r1_shift.1"
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16;", "l,l,~{memory}"(i64 %"cpa_smem_ptr.1", i64 %"cpa_gbl_packed_1.1")
  br label %"BB_0120"
BB_0120:
  call void asm sideeffect "cp.async.commit_group;", "~{memory}"() convergent
  br label %"BB_0130"
BB_0130:
  %"cond_trunc.3" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_01f0", label %"BB_0140"
BB_0140:
  %"iadd3_n1" = add i32 %"imad.3", 256
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", 4
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 1024 to i64
  %".42" = zext i32 4 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  %".47" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".48" = bitcast i8* %".47" to i32*
  %"isetrp_rhs.1" = load i32, i32* %".48"
  %"isetrp_cmp1.3" = icmp sge i32 %"iadd3_n2", %"isetrp_rhs.1"
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 %"iadd3_n2", i32 0
  %".49" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 352
  %".50" = bitcast i8* %".49" to i64*
  %"imad_addend.2" = load i64, i64* %".50"
  %"imad_lhs_64.1" = sext i32 %"sel.1" to i64
  %"imad_rhs_64.1" = sext i32 %"imad.7" to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.8" = add i64 %"imad_tmp_64.1", %"imad_addend.2"
  %"R5:R4_r0.1" = trunc i64 %"imad.8" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.8", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  br label %"BB_01a0"
BB_01a0:
  %"pbra_cond_to_i32.4" = zext i1 0 to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800001a0", label %"BB_01d0"
BB_800001a0:
  br label %"BB_01d0"
BB_01d0:
  %"warp_reconv_mask" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask")
  %"cond_trunc.4" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800001d0", label %"BB_01e0"
BB_800001d0:
  %"cpa_smem_gep_winoff.2" = and i32 %".46", 16777215
  %".55" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"cpa_smem_gep_winoff.2"
  %"cpa_smem_ptr.2" = ptrtoint i8 addrspace(3)* %".55" to i64
  %"cpa_gbl_r0_ext.2" = zext i32 %"R5:R4_r0.1" to i64
  %"cpa_gbl_packed_0.2" = or i64 0, %"cpa_gbl_r0_ext.2"
  %"cpa_gbl_r1_ext.2" = zext i32 %"R5:R4_r1.1" to i64
  %"cpa_gbl_r1_shift.2" = shl i64 %"cpa_gbl_r1_ext.2", 32
  %"cpa_gbl_packed_1.2" = or i64 %"cpa_gbl_packed_0.2", %"cpa_gbl_r1_shift.2"
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %"cpa_smem_ptr.2", i64 %"cpa_gbl_packed_1.2", i32 0)
  br label %"BB_01e0"
BB_01e0:
  %"cond_trunc.5" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_800001e0", label %"BB_01f0"
BB_800001e0:
  %"cpa_smem_gep_winoff.3" = and i32 %".46", 16777215
  %".59" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"cpa_smem_gep_winoff.3"
  %"cpa_smem_ptr.3" = ptrtoint i8 addrspace(3)* %".59" to i64
  %"cpa_gbl_r0_ext.3" = zext i32 %"R5:R4_r0.1" to i64
  %"cpa_gbl_packed_0.3" = or i64 0, %"cpa_gbl_r0_ext.3"
  %"cpa_gbl_r1_ext.3" = zext i32 %"R5:R4_r1.1" to i64
  %"cpa_gbl_r1_shift.3" = shl i64 %"cpa_gbl_r1_ext.3", 32
  %"cpa_gbl_packed_1.3" = or i64 %"cpa_gbl_packed_0.3", %"cpa_gbl_r1_shift.3"
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16;", "l,l,~{memory}"(i64 %"cpa_smem_ptr.3", i64 %"cpa_gbl_packed_1.3")
  br label %"BB_01f0"
BB_01f0:
  call void asm sideeffect "cp.async.commit_group;", "~{memory}"() convergent
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.6" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_80000200", label %"BB_0210"
BB_0210:
  %"iadd3_n1.1" = add i32 %"imad.2", 5
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"imad.2", 6
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"imad.2", 7
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"imad.2", 8
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %".65" = zext i32 0 to i64
  %".66" = zext i32 %"iadd3_n2.1" to i64
  %".67" = shl i64 %".66", 32
  %"shf_concat" = or i64 %".65", %".67"
  %"shf_shift_64" = zext i32 31 to i64
  %".68" = ashr i64 %"shf_concat", %"shf_shift_64"
  %"shf_hi" = lshr i64 %".68", 32
  %"shf_result" = trunc i64 %"shf_hi" to i32
  %".69" = zext i32 0 to i64
  %".70" = zext i32 %"iadd3_n2.2" to i64
  %".71" = shl i64 %".70", 32
  %"shf_concat.1" = or i64 %".69", %".71"
  %"shf_shift_64.1" = zext i32 31 to i64
  %".72" = ashr i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_hi.1" = lshr i64 %".72", 32
  %"shf_result.1" = trunc i64 %"shf_hi.1" to i32
  %".73" = zext i32 0 to i64
  %".74" = zext i32 %"iadd3_n2.3" to i64
  %".75" = shl i64 %".74", 32
  %"shf_concat.2" = or i64 %".73", %".75"
  %"shf_shift_64.2" = zext i32 31 to i64
  %".76" = ashr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi.2" = lshr i64 %".76", 32
  %"shf_result.2" = trunc i64 %"shf_hi.2" to i32
  %".77" = zext i32 0 to i64
  %".78" = zext i32 %"iadd3_n2.4" to i64
  %".79" = shl i64 %".78", 32
  %"shf_concat.3" = or i64 %".77", %".79"
  %"shf_shift_64.3" = zext i32 31 to i64
  %".80" = ashr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.3" = lshr i64 %".80", 32
  %"shf_result.3" = trunc i64 %"shf_hi.3" to i32
  %".81" = zext i32 %"shf_result" to i64
  %".82" = zext i32 0 to i64
  %".83" = shl i64 %".82", 32
  %"lea_funnel" = or i64 %".81", %".83"
  %".84" = zext i32 %"iadd3_n2.1" to i64
  %".85" = zext i32 8 to i64
  %".86" = shl i64 %"lea_funnel", %".85"
  %".87" = lshr i64 %".86", 32
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %".90" = zext i32 %"shf_result.1" to i64
  %".91" = zext i32 0 to i64
  %".92" = shl i64 %".91", 32
  %"lea_funnel.1" = or i64 %".90", %".92"
  %".93" = zext i32 %"iadd3_n2.2" to i64
  %".94" = zext i32 8 to i64
  %".95" = shl i64 %"lea_funnel.1", %".94"
  %".96" = lshr i64 %".95", 32
  %".97" = add i64 %".96", %".93"
  %".98" = trunc i64 %".97" to i32
  %".99" = zext i32 %"shf_result.2" to i64
  %".100" = zext i32 0 to i64
  %".101" = shl i64 %".100", 32
  %"lea_funnel.2" = or i64 %".99", %".101"
  %".102" = zext i32 %"iadd3_n2.3" to i64
  %".103" = zext i32 8 to i64
  %".104" = shl i64 %"lea_funnel.2", %".103"
  %".105" = lshr i64 %".104", 32
  %".106" = add i64 %".105", %".102"
  %".107" = trunc i64 %".106" to i32
  %".108" = zext i32 %"shf_result.3" to i64
  %".109" = zext i32 0 to i64
  %".110" = shl i64 %".109", 32
  %"lea_funnel.3" = or i64 %".108", %".110"
  %".111" = zext i32 %"iadd3_n2.4" to i64
  %".112" = zext i32 8 to i64
  %".113" = shl i64 %"lea_funnel.3", %".112"
  %".114" = lshr i64 %".113", 32
  %".115" = add i64 %".114", %".111"
  %".116" = trunc i64 %".115" to i32
  %".117" = xor i32 %".89", -1
  %".118" = xor i32 1073741568, -1
  %".119" = xor i32 0, -1
  %".120" = and i32 %".89", 1073741568
  %".121" = and i32 %".120", %".119"
  %".122" = and i32 %".89", 1073741568
  %".123" = and i32 %".122", 0
  %".124" = or i32 %".121", %".123"
  %".125" = xor i32 %".98", -1
  %".126" = xor i32 1073741568, -1
  %".127" = xor i32 0, -1
  %".128" = and i32 %".98", 1073741568
  %".129" = and i32 %".128", %".127"
  %".130" = and i32 %".98", 1073741568
  %".131" = and i32 %".130", 0
  %".132" = or i32 %".129", %".131"
  %".133" = xor i32 %".107", -1
  %".134" = xor i32 1073741568, -1
  %".135" = xor i32 0, -1
  %".136" = and i32 %".107", 1073741568
  %".137" = and i32 %".136", %".135"
  %".138" = and i32 %".107", 1073741568
  %".139" = and i32 %".138", 0
  %".140" = or i32 %".137", %".139"
  %"imad_addend_neg" = sub i32 0, %".124"
  %"imad_tmp.7" = mul i32 %"iadd3_n2.1", 1
  %"imad.9" = add i32 %"imad_tmp.7", %"imad_addend_neg"
  %".141" = xor i32 %".116", -1
  %".142" = xor i32 1073741568, -1
  %".143" = xor i32 0, -1
  %".144" = and i32 %".116", 1073741568
  %".145" = and i32 %".144", %".143"
  %".146" = and i32 %".116", 1073741568
  %".147" = and i32 %".146", 0
  %".148" = or i32 %".145", %".147"
  %"imad_addend_neg.1" = sub i32 0, %".132"
  %"imad_tmp.8" = mul i32 %"iadd3_n2.2", 1
  %"imad.10" = add i32 %"imad_tmp.8", %"imad_addend_neg.1"
  %"imad_addend_neg.2" = sub i32 0, %".140"
  %"imad_tmp.9" = mul i32 %"iadd3_n2.3", 1
  %"imad.11" = add i32 %"imad_tmp.9", %"imad_addend_neg.2"
  %".149" = zext i32 %"tid_x" to i64
  %".150" = zext i32 2048 to i64
  %".151" = zext i32 4 to i64
  %".152" = shl i64 %".149", %".151"
  %".153" = and i64 %".152", 4294967295
  %".154" = add i64 %".153", %".150"
  %".155" = trunc i64 %".154" to i32
  %"imad_addend_neg.3" = sub i32 0, %".148"
  %"imad_tmp.10" = mul i32 %"iadd3_n2.4", 1
  %"imad.12" = add i32 %"imad_tmp.10", %"imad_addend_neg.3"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 2
  br label %"BB_0390"
BB_0390:
  %"phi" = phi  i32 [0, %"BB_0210"], [%"iadd3_n2.18", %"BB_0730"]
  %"phi.1" = phi  i32 [%"imad.13", %"BB_0210"], [%"iadd3_n2.11", %"BB_0730"]
  %"phi.2" = phi  float [0x0, %"BB_0210"], [%"phi.25", %"BB_0730"]
  %"phi.3" = phi  float [0x0, %"BB_0210"], [%"phi.22", %"BB_0730"]
  %"phi.4" = phi  float [0x0, %"BB_0210"], [%"phi.23", %"BB_0730"]
  %"phi.5" = phi  float [0x0, %"BB_0210"], [%"phi.21", %"BB_0730"]
  %"phi.6" = phi  float [0x0, %"BB_0210"], [%"phi.18", %"BB_0730"]
  %"phi.7" = phi  i32 [0, %"BB_0210"], [%"iadd3_n2.12", %"BB_0730"]
  %"phi.8" = phi  i32 [%"imad.3", %"BB_0210"], [%"iadd3_n2.16", %"BB_0730"]
  %"iadd3_n1.5" = add i32 %"phi.7", 2
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"phi.8", 1
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %".157" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 372
  %".158" = bitcast i8* %".157" to i32*
  %"isetrp_rhs.2" = load i32, i32* %".158"
  %"isetrp_cmp1.4" = icmp sge i32 %"iadd3_n2.5", %"isetrp_rhs.2"
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"iadd3_n1.7" = add i32 %"phi.8", 2
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".159" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".160" = bitcast i8* %".159" to i32*
  %"isetrp_rhs.3" = load i32, i32* %".160"
  %"isetrp_cmp1.5" = icmp sge i32 %"iadd3_n2.6", %"isetrp_rhs.3"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %".161" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".162" = bitcast i8* %".161" to i32*
  %"isetrp_rhs.4" = load i32, i32* %".162"
  %"isetrp_cmp1.6" = icmp sge i32 %"iadd3_n2.7", %"isetrp_rhs.4"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %".163" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".164" = bitcast i8* %".163" to i32*
  %"isetrp_rhs.5" = load i32, i32* %".164"
  %"isetrp_cmp1.7" = icmp sge i32 %"phi.8", %"isetrp_rhs.5"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"iadd3_n1.8" = add i32 %"phi.8", 3
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  br label %"BB_0410"
BB_0410:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0500", label %"BB_0420"
BB_0420:
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64.2" = zext i32 %"phi.1" to i64
  %"imad_rhs_64.2" = zext i32 -1431655765 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1"
  %"R9:R8_r0" = trunc i64 %"imad.14" to i32
  %"R9:R8_r1_shift" = lshr i64 %"imad.14", 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %"iadd3_n1.9" = add i32 %"phi.8", 512
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 4
  %".167" = zext i32 0 to i64
  %".168" = zext i32 %"R9:R8_r1" to i64
  %".169" = shl i64 %".168", 32
  %"shf_concat.4" = or i64 %".167", %".169"
  %"shf_shift_64.4" = zext i32 1 to i64
  %".170" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.4" = lshr i64 %".170", 32
  %"shf_result.4" = trunc i64 %"shf_hi.4" to i32
  %".171" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".172" = bitcast i8* %".171" to i32*
  %"isetrp_rhs.6" = load i32, i32* %".172"
  %"isetrp_cmp1.8" = icmp sge i32 %"iadd3_n2.9", %"isetrp_rhs.6"
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"imad_tmp.13" = mul i32 %"shf_result.4", -3072
  %"imad.16" = add i32 %"imad_tmp.13", %".155"
  %"sel_pred_trunc.2" = trunc i32 %"P1_to_i32" to i1
  %"sel_pred_not.2" = xor i1 %"sel_pred_trunc.2", -1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_not.2" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 %"iadd3_n2.9", i32 0
  %"iadd3_n1.10" = add i32 %"imad.16", %"phi"
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %".173" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 352
  %".174" = bitcast i8* %".173" to i64*
  %"imad_addend.3" = load i64, i64* %".174"
  %"imad_lhs_64.3" = sext i32 %"sel.2" to i64
  %"imad_rhs_64.3" = sext i32 %"imad.15" to i64
  %"imad_tmp_64.3" = mul i64 %"imad_lhs_64.3", %"imad_rhs_64.3"
  %"imad.17" = add i64 %"imad_tmp_64.3", %"imad_addend.3"
  %"R9:R8_r0.1" = trunc i64 %"imad.17" to i32
  %"R9:R8_r1_shift.1" = lshr i64 %"imad.17", 32
  %"R9:R8_r1.1" = trunc i64 %"R9:R8_r1_shift.1" to i32
  br label %"BB_04b0"
BB_04b0:
  %"pbra_cond_to_i32.9" = zext i1 0 to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800004b0", label %"BB_04e0"
BB_800004b0:
  br label %"BB_04e0"
BB_04e0:
  %"warp_reconv_mask.1" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.1")
  %"cond_trunc.8" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_800004e0", label %"BB_04f0"
BB_800004e0:
  %"cpa_smem_gep_winoff.4" = and i32 %"iadd3_n2.10", 16777215
  %".179" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"cpa_smem_gep_winoff.4"
  %"cpa_smem_ptr.4" = ptrtoint i8 addrspace(3)* %".179" to i64
  %"cpa_gbl_r0_ext.4" = zext i32 %"R9:R8_r0.1" to i64
  %"cpa_gbl_packed_0.4" = or i64 0, %"cpa_gbl_r0_ext.4"
  %"cpa_gbl_r1_ext.4" = zext i32 %"R9:R8_r1.1" to i64
  %"cpa_gbl_r1_shift.4" = shl i64 %"cpa_gbl_r1_ext.4", 32
  %"cpa_gbl_packed_1.4" = or i64 %"cpa_gbl_packed_0.4", %"cpa_gbl_r1_shift.4"
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %"cpa_smem_ptr.4", i64 %"cpa_gbl_packed_1.4", i32 0)
  br label %"BB_04f0"
BB_04f0:
  %"cond_trunc.9" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  %"phi_cast_R113_bitcast.1" = bitcast i32 %"imad.15" to float
  br i1 %"pbra_cond_to_i1.11", label %"BB_800004f0", label %"BB_0500"
BB_800004f0:
  %"cpa_smem_gep_winoff.5" = and i32 %"iadd3_n2.10", 16777215
  %".183" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"cpa_smem_gep_winoff.5"
  %"cpa_smem_ptr.5" = ptrtoint i8 addrspace(3)* %".183" to i64
  %"cpa_gbl_r0_ext.5" = zext i32 %"R9:R8_r0.1" to i64
  %"cpa_gbl_packed_0.5" = or i64 0, %"cpa_gbl_r0_ext.5"
  %"cpa_gbl_r1_ext.5" = zext i32 %"R9:R8_r1.1" to i64
  %"cpa_gbl_r1_shift.5" = shl i64 %"cpa_gbl_r1_ext.5", 32
  %"cpa_gbl_packed_1.5" = or i64 %"cpa_gbl_packed_0.5", %"cpa_gbl_r1_shift.5"
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16;", "l,l,~{memory}"(i64 %"cpa_smem_ptr.5", i64 %"cpa_gbl_packed_1.5")
  %"phi_cast_R113_bitcast" = bitcast i32 %"imad.15" to float
  br label %"BB_0500"
BB_0500:
  %"phi.9" = phi  float [%"phi.6", %"BB_0410"], [%"phi_cast_R113_bitcast", %"BB_800004f0"], [%"phi_cast_R113_bitcast.1", %"BB_04f0"]
  %"phi.10" = phi  i32 [%"iadd3_n2.7", %"BB_0410"], [%"iadd3_n2.10", %"BB_800004f0"], [%"iadd3_n2.10", %"BB_04f0"]
  call void asm sideeffect "cp.async.commit_group;", "~{memory}"() convergent
  %"imad_addend_r0_ext.1" = zext i32 0 to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 0 to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.4" = zext i32 %"phi.7" to i64
  %"imad_rhs_64.4" = zext i32 -1431655765 to i64
  %"imad_tmp_64.4" = mul i64 %"imad_lhs_64.4", %"imad_rhs_64.4"
  %"imad.18" = add i64 %"imad_tmp_64.4", %"imad_addend_packed_1.1"
  %"R9:R8_r0.2" = trunc i64 %"imad.18" to i32
  %"R9:R8_r1_shift.2" = lshr i64 %"imad.18", 32
  %"R9:R8_r1.2" = trunc i64 %"R9:R8_r1_shift.2" to i32
  %".187" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 368
  %".188" = bitcast i8* %".187" to i32*
  %"isetrp_rhs.7" = load i32, i32* %".188"
  %"isetrp_cmp1.9" = icmp sge i32 %"iadd3_n2.8", %"isetrp_rhs.7"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"i2f" = sitofp i32 %"phi.7" to float
  %"iadd3_n1.11" = add i32 %"phi.1", 1
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %".189" = zext i32 0 to i64
  %".190" = zext i32 %"R9:R8_r1.2" to i64
  %".191" = shl i64 %".190", 32
  %"shf_concat.5" = or i64 %".189", %".191"
  %"shf_shift_64.5" = zext i32 1 to i64
  %".192" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.5" = lshr i64 %".192", 32
  %"shf_result.5" = trunc i64 %"shf_hi.5" to i32
  br label %"BB_0560"
BB_0560:
  %"cond_trunc.10" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000560", label %"BB_0570"
BB_80000560:
  %"imad_tmp.14" = mul i32 %"shf_result.5", -3072
  %"imad.19" = add i32 %"imad_tmp.14", 0
  br label %"BB_0570"
BB_0570:
  %"phi.11" = phi  i32 [%"imad.19", %"BB_80000560"], [%"iadd3_n2.8", %"BB_0560"]
  %"iadd3_n1.12" = add i32 %"phi.7", 1
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", 0
  br label %"BB_0580"
BB_0580:
  %"cond_trunc.11" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000580", label %"BB_0590"
BB_80000580:
  %"imad_tmp.15" = mul i32 %"shf_result.5", -3072
  %"imad.20" = add i32 %"imad_tmp.15", 0
  br label %"BB_0590"
BB_0590:
  %"phi.12" = phi  i32 [%"imad.20", %"BB_80000580"], [%"R9:R8_r0.2", %"BB_0580"]
  %"cond_trunc.12" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  %"phi_cast_R114_bitcast" = bitcast float %"phi.9" to i32
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000590", label %"BB_05a0"
BB_80000590:
  %"imad_tmp.16" = mul i32 %"imad.10", 4
  %"imad.21" = add i32 %"imad_tmp.16", %"phi.11"
  br label %"BB_05a0"
BB_05a0:
  %"phi.13" = phi  i32 [%"imad.21", %"BB_80000590"], [%"phi_cast_R114_bitcast", %"BB_0590"]
  %"cond_trunc.13" = trunc i32 %"P10_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  %"phi_cast_R16_bitcast" = bitcast float %"phi.5" to i32
  br i1 %"pbra_cond_to_i1.15", label %"BB_800005a0", label %"BB_05b0"
BB_800005a0:
  %"imad_tmp.17" = mul i32 %"shf_result.5", -3072
  %"imad.22" = add i32 %"imad_tmp.17", 0
  br label %"BB_05b0"
BB_05b0:
  %"phi.14" = phi  i32 [%"imad.22", %"BB_800005a0"], [%"phi_cast_R16_bitcast", %"BB_05a0"]
  %"cond_trunc.14" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800005b0", label %"BB_05c0"
BB_800005b0:
  %"imad_tmp.18" = mul i32 %"shf_result.5", -3072
  %"imad.23" = add i32 %"imad_tmp.18", 0
  br label %"BB_05c0"
BB_05c0:
  %"phi.15" = phi  i32 [%"imad.23", %"BB_800005b0"], [%"shf_result.5", %"BB_05b0"]
  %"cond_trunc.15" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_800005c0", label %"BB_05d0"
BB_800005c0:
  %"imad_tmp.19" = mul i32 %"imad.9", 4
  %"imad.24" = add i32 %"imad_tmp.19", %"phi.12"
  br label %"BB_05d0"
BB_05d0:
  %"phi.16" = phi  i32 [%"imad.24", %"BB_800005c0"], [%"phi.10", %"BB_05c0"]
  %"cond_trunc.16" = trunc i32 %"P10_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_800005d0", label %"BB_05e0"
BB_800005d0:
  %"imad_tmp.20" = mul i32 %"imad.11", 4
  %"imad.25" = add i32 %"imad_tmp.20", %"phi.14"
  br label %"BB_05e0"
BB_05e0:
  %"phi.17" = phi  i32 [%"imad.25", %"BB_800005d0"], [%"phi.14", %"BB_05d0"]
  call void asm sideeffect "cp.async.wait_group 2;", "~{memory}"() convergent
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0600"
BB_0600:
  %"cond_trunc.17" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  %"phi_cast_R117_bitcast" = bitcast i32 %"phi.13" to float
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000600", label %"BB_0610"
BB_80000600:
  %"iadd3_n1.13" = add i32 %"phi.13", %"phi"
  %"iadd3_n2.13" = add i32 %"iadd3_n1.13", 0
  %"lds_shared_addr_winoff" = and i32 %"iadd3_n2.13", 16777215
  %".212" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".212" to float addrspace(3)*
  %"lds" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast"
  br label %"BB_0610"
BB_0610:
  %"phi.18" = phi  float [%"lds", %"BB_80000600"], [%"phi_cast_R117_bitcast", %"BB_0600"]
  %"warp_reconv_mask.2" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.2")
  %"cond_trunc.18" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  %"phi_cast_R22_bitcast" = bitcast float %"phi.3" to i32
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000610", label %"BB_0620"
BB_80000610:
  %"imad_tmp.21" = mul i32 %"imad.12", 4
  %"imad.26" = add i32 %"imad_tmp.21", %"phi.15"
  br label %"BB_0620"
BB_0620:
  %"phi.19" = phi  i32 [%"imad.26", %"BB_80000610"], [%"phi_cast_R22_bitcast", %"BB_0610"]
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.22", 4
  br label %"BB_0630"
BB_0630:
  %"cond_trunc.19" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.15" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.15" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  %"phi_cast_R105_bitcast" = bitcast i32 %"phi.16" to float
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000630", label %"BB_0640"
BB_80000630:
  %"iadd3_n1.14" = add i32 %"phi.16", %"phi"
  %"iadd3_n2.14" = add i32 %"iadd3_n1.14", 0
  %"lds_shared_addr_winoff.1" = and i32 %"iadd3_n2.14", 16777215
  %".218" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".218" to float addrspace(3)*
  %"lds.1" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.1"
  br label %"BB_0640"
BB_0640:
  %"phi.20" = phi  float [%"lds.1", %"BB_80000630"], [%"phi_cast_R105_bitcast", %"BB_0630"]
  %"warp_reconv_mask.3" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.3")
  %".220" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 360
  %".221" = bitcast i8* %".220" to i64*
  %"imad_addend.4" = load i64, i64* %".221"
  %"imad_lhs_64.5" = sext i32 %"phi.8" to i64
  %"imad_rhs_64.5" = sext i32 %"imad.27" to i64
  %"imad_tmp_64.5" = mul i64 %"imad_lhs_64.5", %"imad_rhs_64.5"
  %"imad.28" = add i64 %"imad_tmp_64.5", %"imad_addend.4"
  %"R9:R8_r0.3" = trunc i64 %"imad.28" to i32
  %"R9:R8_r1_shift.3" = lshr i64 %"imad.28", 32
  %"R9:R8_r1.3" = trunc i64 %"R9:R8_r1_shift.3" to i32
  br label %"BB_0650"
BB_0650:
  %"cond_trunc.20" = trunc i32 %"P10_to_i32" to i1
  %"cond_not.16" = xor i1 %"cond_trunc.20", -1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_not.16" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  %"phi_cast_R21_bitcast" = bitcast i32 %"phi.17" to float
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000650", label %"BB_0660"
BB_80000650:
  %"iadd3_n1.15" = add i32 %"phi.17", %"phi"
  %"iadd3_n2.15" = add i32 %"iadd3_n1.15", 0
  %"lds_shared_addr_winoff.2" = and i32 %"iadd3_n2.15", 16777215
  %".224" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".224" to float addrspace(3)*
  %"lds.2" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.2"
  br label %"BB_0660"
BB_0660:
  %"phi.21" = phi  float [%"lds.2", %"BB_80000650"], [%"phi_cast_R21_bitcast", %"BB_0650"]
  %"warp_reconv_mask.4" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.4")
  %"iadd3_n1.16" = add i32 %"phi.8", 256
  %"iadd3_n2.16" = add i32 %"iadd3_n1.16", 0
  br label %"BB_0670"
BB_0670:
  %"cond_trunc.21" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.17" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_not.17" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  %"phi_cast_R24_bitcast" = bitcast i32 %"phi.19" to float
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000670", label %"BB_0680"
BB_80000670:
  %"iadd3_n1.17" = add i32 %"phi.19", %"phi"
  %"iadd3_n2.17" = add i32 %"iadd3_n1.17", 0
  %"lds_shared_addr_winoff.3" = and i32 %"iadd3_n2.17", 16777215
  %".228" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".228" to float addrspace(3)*
  %"lds.3" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.3"
  br label %"BB_0680"
BB_0680:
  %"phi.22" = phi  float [%"lds.3", %"BB_80000670"], [%"phi_cast_R24_bitcast", %"BB_0670"]
  %"warp_reconv_mask.5" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.5")
  %"iadd3_n1.18" = add i32 %"phi", 1024
  %"iadd3_n2.18" = add i32 %"iadd3_n1.18", 0
  br label %"BB_0690"
BB_0690:
  %"cond_trunc.22" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.18" = xor i1 %"cond_trunc.22", -1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_not.18" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80000690", label %"BB_06a0"
BB_80000690:
  %"ffma" = call float @"llvm.fma.f32"(float %"phi.18", float 0x4000000000000000, float %"i2f")
  br label %"BB_06a0"
BB_06a0:
  %"phi.23" = phi  float [%"ffma", %"BB_80000690"], [%"phi.4", %"BB_0690"]
  %"cond_trunc.23" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.19" = xor i1 %"cond_trunc.23", -1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_not.19" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  %"phi_cast_R11_bitcast" = bitcast i32 %"phi.11" to float
  br i1 %"pbra_cond_to_i1.25", label %"BB_800006a0", label %"BB_06b0"
BB_800006a0:
  %"ffma.1" = call float @"llvm.fma.f32"(float %"phi.20", float 0x4000000000000000, float %"i2f")
  br label %"BB_06b0"
BB_06b0:
  %"phi.24" = phi  float [%"ffma.1", %"BB_800006a0"], [%"phi_cast_R11_bitcast", %"BB_06a0"]
  %"cond_trunc.24" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.20" = xor i1 %"cond_trunc.24", -1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_not.20" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_800006b0", label %"BB_06c0"
BB_800006b0:
  %"stg_addr_r0_ext" = zext i32 %"R9:R8_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R9:R8_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1", 4
  %"R88:R75_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add" to float addrspace(1)*
  store float %"phi.23", float addrspace(1)* %"R88:R75_addr_ptr"
  br label %"BB_06c0"
BB_06c0:
  %".238" = getelementptr inbounds [384 x i8], [384 x i8]* %"param_local", i64 0, i64 372
  %".239" = bitcast i8* %".238" to i32*
  %"isetrp_rhs.8" = load i32, i32* %".239"
  %"isetrp_cmp1.10" = icmp sge i32 %"iadd3_n2.12", %"isetrp_rhs.8"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_06d0"
BB_06d0:
  %"cond_trunc.25" = trunc i32 %"P10_to_i32" to i1
  %"cond_not.21" = xor i1 %"cond_trunc.25", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.21" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_800006d0", label %"BB_06e0"
BB_800006d0:
  %"ffma.2" = call float @"llvm.fma.f32"(float %"phi.21", float 0x4000000000000000, float %"i2f")
  br label %"BB_06e0"
BB_06e0:
  %"phi.25" = phi  float [%"ffma.2", %"BB_800006d0"], [%"phi.2", %"BB_06d0"]
  %"cond_trunc.26" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.22" = xor i1 %"cond_trunc.26", -1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_not.22" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_800006e0", label %"BB_06f0"
BB_800006e0:
  %"stg_addr_r0_ext.1" = zext i32 %"R9:R8_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R9:R8_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"R88:R75_addr_ptr.1" = inttoptr i64 %"stg_addr_packed_1.1" to float addrspace(1)*
  store float %"phi.24", float addrspace(1)* %"R88:R75_addr_ptr.1"
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.27" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.23" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_not.23" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_800006f0", label %"BB_0700"
BB_800006f0:
  %"ffma.3" = call float @"llvm.fma.f32"(float %"phi.22", float 0x4000000000000000, float %"i2f")
  br label %"BB_0700"
BB_0700:
  %"phi.26" = phi  float [%"ffma.3", %"BB_800006f0"], [%"i2f", %"BB_06f0"]
  %"cond_trunc.28" = trunc i32 %"P10_to_i32" to i1
  %"cond_not.24" = xor i1 %"cond_trunc.28", -1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_not.24" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_80000700", label %"BB_0710"
BB_80000700:
  %"stg_addr_r0_ext.2" = zext i32 %"R9:R8_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R9:R8_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R88:R75_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to float addrspace(1)*
  store float %"phi.25", float addrspace(1)* %"R88:R75_addr_ptr.2"
  br label %"BB_0710"
BB_0710:
  %"cond_trunc.29" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.25" = xor i1 %"cond_trunc.29", -1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_not.25" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_80000710", label %"BB_0720"
BB_80000710:
  %"stg_addr_r0_ext.3" = zext i32 %"R9:R8_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R9:R8_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R88:R75_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to float addrspace(1)*
  store float %"phi.26", float addrspace(1)* %"R88:R75_addr_ptr.3"
  br label %"BB_0720"
BB_0720:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0730"
BB_0730:
  %"cond_trunc.30" = trunc i32 %"P8_to_i32" to i1
  %"cond_not.26" = xor i1 %"cond_trunc.30", -1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_not.26" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_0390", label %"BB_0740"
BB_0740:
  ret void
BB_80000200:
  ret void
}

@"const_mem" = global [5 x [376 x i8]] [[376 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [376 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [376 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [376 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [376 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.activemask"()

declare void @"llvm.nvvm.bar.warp.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare float @"llvm.fma.f32"(float %".1", float %".2", float %".3")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64, i32, i32)* @"_Z5pipe3PKfPfii", !"kernel", i32 1 }
