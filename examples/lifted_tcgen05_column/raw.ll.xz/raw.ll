; ModuleID = "tcgen05_column_sm100a"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [9232 x i8], align 16
define void @"_Z10column_opsPjj"(i64 %"arg_896", i32 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i32*
  store i32 %"arg_904", i32* %".8", align 8
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".11" = bitcast i8* %".10" to i32*
  %"ldc_const" = load i32, i32* %".11"
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", 1073758208
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", -2122219135
  %"iadd3_n1" = add i32 1024, 4096
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"isetrp_cmp1" = icmp ne i32 %"ldc_const", 1
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"imad_tmp.2" = mul i32 %"tid_x", 16
  %"imad.2" = add i32 %"imad_tmp.2", 0
  %".12" = xor i32 %"tid_x", -1
  %".13" = xor i32 1, -1
  %".14" = xor i32 0, -1
  %".15" = and i32 %"tid_x", 1
  %".16" = and i32 %".15", %".14"
  %".17" = and i32 %"tid_x", 1
  %".18" = and i32 %".17", 0
  %".19" = or i32 %".16", %".18"
  %"lop3_pred_cmp" = icmp ne i32 %".19", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P8_to_i32" = zext i1 %"lop3_p" to i32
  %"imad_tmp.3" = mul i32 %"tid_x", 32
  %"imad.3" = add i32 %"imad_tmp.3", 0
  %".20" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".21" = zext i32 %"iadd3_n2" to i64
  %".22" = zext i32 24 to i64
  %".23" = shl i64 %".20", %".22"
  %".24" = and i64 %".23", 4294967295
  %".25" = add i64 %".24", %".21"
  %".26" = trunc i64 %".25" to i32
  %"sel_pred_trunc" = trunc i32 %"P8_to_i32" to i1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_trunc" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 %"imad", i32 1006648320
  %".27" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".28" = zext i32 1024 to i64
  %".29" = zext i32 24 to i64
  %".30" = shl i64 %".27", %".29"
  %".31" = and i64 %".30", 4294967295
  %".32" = add i64 %".31", %".28"
  %".33" = trunc i64 %".32" to i32
  %".34" = xor i32 %"imad.2", -1
  %".35" = xor i32 112, -1
  %".36" = xor i32 0, -1
  %".37" = and i32 %"imad.2", 112
  %".38" = and i32 %".37", %".36"
  %".39" = and i32 %"imad.2", 112
  %".40" = and i32 %".39", 0
  %".41" = or i32 %".38", %".40"
  br label %"BB_0120"
BB_0120:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000120", label %"BB_0130"
BB_80000120:
  %"sel_pred_trunc.1" = trunc i32 %"P8_to_i32" to i1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_trunc.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 %"imad", i32 1065369472
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"sel.1", %"BB_80000120"], [%"sel", %"BB_0120"]
  %"isetrp_cmp1.2" = icmp ne i32 %"ldc_const", 2
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"vote_pred_trunc" = trunc i32 %"P10_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P63_to_i32" = zext i1 %"vote_all" to i32
  %"sel_pred_trunc.2" = trunc i32 %"P8_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc.2", -1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 %"imad.1", i32 2155905152
  %"vote_pred_trunc.1" = trunc i32 %"P10_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P72_to_i32" = zext i1 %"vote_all.1" to i32
  %".45" = xor i32 %".41", -1
  %".46" = xor i32 32512, -1
  %".47" = xor i32 %"imad.3", -1
  %".48" = and i32 %".45", 32512
  %".49" = and i32 %".48", %"imad.3"
  %".50" = and i32 %".41", %".46"
  %".51" = and i32 %".50", %".47"
  %".52" = or i32 %".49", %".51"
  %".53" = and i32 %".41", %".46"
  %".54" = and i32 %".53", %"imad.3"
  %".55" = or i32 %".52", %".54"
  %".56" = and i32 %".41", 32512
  %".57" = and i32 %".56", %".47"
  %".58" = or i32 %".55", %".57"
  %".59" = and i32 %".41", 32512
  %".60" = and i32 %".59", %"imad.3"
  %".61" = or i32 %".58", %".60"
  %"imad_tmp.4" = mul i32 %"tid_x", 1000
  %"imad.4" = add i32 %"imad_tmp.4", 0
  br label %"BB_0190"
BB_0190:
  %"cond_trunc.1" = trunc i32 %"P63_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_80000190", label %"BB_01a0"
BB_80000190:
  %"iadd3_n1.1" = add i32 1024, 8200
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_01a0"
BB_01a0:
  %"phi.1" = phi  i32 [%"iadd3_n2.1", %"BB_80000190"], [0, %"BB_0190"]
  %"sel_pred_trunc.3" = trunc i32 %"P25_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.3", -1
  %"sel_pred_to_i32.3" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.3" = icmp ne i32 %"sel_pred_to_i32.3", 0
  %"sel.3" = select  i1 %"sel_pred_to_i1.3", i32 %"sel.2", i32 %"phi"
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.2" = trunc i32 %"P63_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_800001b0", label %"BB_01e0"
BB_800001b0:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".67" = zext i32 %"iadd3_n2.2" to i64
  %".68" = zext i32 0 to i64
  %".69" = shl i64 %".68", 32
  %"shf_concat" = or i64 %".67", %".69"
  %"shf_shift_64" = zext i32 11 to i64
  %".70" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".70" to i32
  %".71" = zext i32 %"iadd3_n2.2" to i64
  %".72" = zext i32 0 to i64
  %".73" = shl i64 %".72", 32
  %"shf_concat.1" = or i64 %".71", %".73"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".74" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".74" to i32
  br label %"BB_01e0"
BB_01e0:
  %"phi.2" = phi  i32 [%"shf_result", %"BB_800001b0"], [1, %"BB_01b0"]
  %"phi.3" = phi  i32 [%"shf_result.1", %"BB_800001b0"], [%"iadd3_n2", %"BB_01b0"]
  %"viadd" = add i32 %"imad.4", 1
  br label %"BB_01f0"
BB_01f0:
  %"cond_trunc.3" = trunc i32 %"P63_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800001f0", label %"BB_0200"
BB_800001f0:
  %".78" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".79" = zext i32 %"phi.1" to i64
  %".80" = zext i32 24 to i64
  %".81" = shl i64 %".78", %".80"
  %".82" = and i64 %".81", 4294967295
  %".83" = add i64 %".82", %".79"
  %".84" = trunc i64 %".83" to i32
  br label %"BB_0200"
BB_0200:
  %"phi.4" = phi  i32 [%".84", %"BB_800001f0"], [%"phi.1", %"BB_01f0"]
  %"viadd.1" = add i32 %"imad.4", 2
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"imad.4", 3
  %"viadd.3" = add i32 %"imad.4", 4
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.4" = trunc i32 %"P72_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.4", 16777215
  %".88" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.3" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.2" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"viadd.4" = add i32 %"imad.4", 5
  %"iadd3_n1.3" = add i32 %".61", %".33"
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"sts_val_r0_ext" = zext i32 %"imad.4" to i128
  %"sts_val_packed_0" = or i128 0, %"sts_val_r0_ext"
  %"sts_val_r1_ext" = zext i32 %"viadd" to i128
  %"sts_val_r1_shift" = shl i128 %"sts_val_r1_ext", 32
  %"sts_val_packed_1" = or i128 %"sts_val_packed_0", %"sts_val_r1_shift"
  %"sts_val_r2_ext" = zext i32 %"viadd.1" to i128
  %"sts_val_r2_shift" = shl i128 %"sts_val_r2_ext", 64
  %"sts_val_packed_2" = or i128 %"sts_val_packed_1", %"sts_val_r2_shift"
  %"sts_val_r3_ext" = zext i32 %"viadd.2" to i128
  %"sts_val_r3_shift" = shl i128 %"sts_val_r3_ext", 96
  %"sts_val_packed_3" = or i128 %"sts_val_packed_2", %"sts_val_r3_shift"
  %"sts_shared_addr_winoff" = and i32 %"iadd3_n2.3", 16777215
  %".92" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".92" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3", i128 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.5" = add i32 %"imad.4", 6
  %"viadd.6" = add i32 %"imad.4", 7
  %"iadd3_n1.4" = add i32 %".61", %".26"
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"sts_val_r0_ext.1" = zext i32 %"sel.3" to i128
  %"sts_val_packed_0.1" = or i128 0, %"sts_val_r0_ext.1"
  %"sts_val_r1_ext.1" = zext i32 %"sel.3" to i128
  %"sts_val_r1_shift.1" = shl i128 %"sts_val_r1_ext.1", 32
  %"sts_val_packed_1.1" = or i128 %"sts_val_packed_0.1", %"sts_val_r1_shift.1"
  %"sts_val_r2_ext.1" = zext i32 %"sel.3" to i128
  %"sts_val_r2_shift.1" = shl i128 %"sts_val_r2_ext.1", 64
  %"sts_val_packed_2.1" = or i128 %"sts_val_packed_1.1", %"sts_val_r2_shift.1"
  %"sts_val_r3_ext.1" = zext i32 %"sel.3" to i128
  %"sts_val_r3_shift.1" = shl i128 %"sts_val_r3_ext.1", 96
  %"sts_val_packed_3.1" = or i128 %"sts_val_packed_2.1", %"sts_val_r3_shift.1"
  %"sts_shared_addr_winoff.1" = and i32 %"iadd3_n2.4", 16777215
  %".94" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".94" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.1", i128 addrspace(3)* %"sts_shared_addr_cast.1"
  %"iadd3_n1.5" = add i32 %".61", %".33"
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"sts_addr_memaddr_offset_add" = add i32 %"iadd3_n2.5", 128
  %"sts_val_r0_ext.2" = zext i32 %"viadd.3" to i128
  %"sts_val_packed_0.2" = or i128 0, %"sts_val_r0_ext.2"
  %"sts_val_r1_ext.2" = zext i32 %"viadd.4" to i128
  %"sts_val_r1_shift.2" = shl i128 %"sts_val_r1_ext.2", 32
  %"sts_val_packed_1.2" = or i128 %"sts_val_packed_0.2", %"sts_val_r1_shift.2"
  %"sts_val_r2_ext.2" = zext i32 %"viadd.5" to i128
  %"sts_val_r2_shift.2" = shl i128 %"sts_val_r2_ext.2", 64
  %"sts_val_packed_2.2" = or i128 %"sts_val_packed_1.2", %"sts_val_r2_shift.2"
  %"sts_val_r3_ext.2" = zext i32 %"viadd.6" to i128
  %"sts_val_r3_shift.2" = shl i128 %"sts_val_r3_ext.2", 96
  %"sts_val_packed_3.2" = or i128 %"sts_val_packed_2.2", %"sts_val_r3_shift.2"
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".96" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".96" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.2", i128 addrspace(3)* %"sts_shared_addr_cast.2"
  %"iadd3_n1.6" = add i32 %".61", %".26"
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"sts_addr_memaddr_offset_add.1" = add i32 %"iadd3_n2.6", 128
  %"sts_val_r0_ext.3" = zext i32 %"sel.3" to i128
  %"sts_val_packed_0.3" = or i128 0, %"sts_val_r0_ext.3"
  %"sts_val_r1_ext.3" = zext i32 %"sel.3" to i128
  %"sts_val_r1_shift.3" = shl i128 %"sts_val_r1_ext.3", 32
  %"sts_val_packed_1.3" = or i128 %"sts_val_packed_0.3", %"sts_val_r1_shift.3"
  %"sts_val_r2_ext.3" = zext i32 %"sel.3" to i128
  %"sts_val_r2_shift.3" = shl i128 %"sts_val_r2_ext.3", 64
  %"sts_val_packed_2.3" = or i128 %"sts_val_packed_1.3", %"sts_val_r2_shift.3"
  %"sts_val_r3_ext.3" = zext i32 %"sel.3" to i128
  %"sts_val_r3_shift.3" = shl i128 %"sts_val_r3_ext.3", 96
  %"sts_val_packed_3.3" = or i128 %"sts_val_packed_2.3", %"sts_val_r3_shift.3"
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".98" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".98" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.3", i128 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.5" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_04d0", label %"BB_0340"
BB_0340:
  %"allocation_dst_memaddr_offset_add" = add i32 %".33", 8192
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".102" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".103" = ptrtoint i8 addrspace(3)* %".102" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".103", i32 128) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P35_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_04d0", label %"BB_0370"
BB_0370:
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.5", 15
  %".107" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".108" = zext i32 64 to i64
  %".109" = zext i32 24 to i64
  %".110" = shl i64 %".107", %".109"
  %".111" = and i64 %".110", 4294967295
  %".112" = add i64 %".111", %".108"
  %".113" = trunc i64 %".112" to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.6", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".33", 8192
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".114" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".115" = bitcast i8 addrspace(3)* %".114" to i32 addrspace(3)*
  %".116" = load i32, i32 addrspace(3)* %".115"
  %".117" = lshr i32 %".116", 5
  %"P66_to_i32" = zext i1 1 to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.7", %".117"
  %"bra_cond_trunc" = trunc i32 %"P66_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_0460", label %"BB_0400"
BB_0400:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".33", 8192
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".119" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P68_to_i32" = zext i1 1 to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.8", %".122"
  %"bra_cond_trunc.1" = trunc i32 %"P68_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0400", label %"BB_0460"
BB_0460:
  %"phi.5" = phi  i32 [%"imad.7", %"BB_0370"], [%"imad.8", %"BB_0400"]
  %".124" = zext i32 %"imad.5" to i64
  %".125" = zext i32 0 to i64
  %".126" = shl i64 %".125", 32
  %"shf_concat.2" = or i64 %".124", %".126"
  %"shf_shift_64.2" = zext i32 %"phi.5" to i64
  %".127" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".127" to i32
  %".128" = zext i32 %"imad.6" to i64
  %".129" = zext i32 0 to i64
  %".130" = shl i64 %".129", 32
  %"shf_concat.3" = or i64 %".128", %".130"
  %"shf_shift_64.3" = zext i32 %"phi.5" to i64
  %".131" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".131" to i32
  %"imad_tmp.9" = mul i32 %"phi.5", 32
  %"imad.9" = add i32 %"imad_tmp.9", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".113", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".132" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".132" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".113", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".133" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".133" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add.2" = add i32 %".33", 8192
  %"sts_shared_addr_winoff.4" = and i32 %"sts_addr_memaddr_offset_add.2", 16777215
  %".134" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".134" to i32 addrspace(3)*
  store volatile i32 %"imad.9", i32 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_04d0"
BB_04d0:
  call void @"llvm.nvvm.barrier0"()
  %".137" = zext i32 0 to i64
  %".138" = zext i32 %".26" to i64
  %".139" = shl i64 %".138", 32
  %"shf_concat.4" = or i64 %".137", %".139"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".140" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".140", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".141" = xor i32 %"plop3_a_bit", 1
  %".142" = xor i32 %"plop3_b_bit", 1
  %".143" = xor i32 %"plop3_c_bit", 1
  %".144" = and i32 %".141", %"plop3_b_bit"
  %".145" = and i32 %".144", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".145", 0
  %"P46_to_i32" = zext i1 %"plop3_pred" to i32
  %".146" = zext i32 0 to i64
  %".147" = zext i32 %".33" to i64
  %".148" = shl i64 %".147", 32
  %"shf_concat.5" = or i64 %".146", %".148"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".149" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".149", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"lop3_a_trunc" = trunc i32 %"P10_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".150" = xor i32 %"plop3_a_bit.1", 1
  %".151" = xor i32 %"plop3_b_bit.1", 1
  %".152" = xor i32 %"plop3_c_bit.1", 1
  %".153" = and i32 %".150", %"plop3_b_bit.1"
  %".154" = and i32 %".153", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".154", 0
  %"P54_to_i32" = zext i1 %"plop3_pred.1" to i32
  %".155" = xor i32 %"shf_result.4", -1
  %".156" = xor i32 16376, -1
  %".157" = xor i32 0, -1
  %".158" = and i32 %"shf_result.4", 16376
  %".159" = and i32 %".158", %".157"
  %".160" = and i32 %"shf_result.4", 16376
  %".161" = and i32 %".160", 0
  %".162" = or i32 %".159", %".161"
  %"vote_pred_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"vote_all.2" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.2")
  %"P69_to_i32" = zext i1 %"vote_all.2" to i32
  %".163" = xor i32 %"shf_result.5", -1
  %".164" = xor i32 16376, -1
  %".165" = xor i32 0, -1
  %".166" = and i32 %"shf_result.5", 16376
  %".167" = and i32 %".166", %".165"
  %".168" = and i32 %"shf_result.5", 16376
  %".169" = and i32 %".168", 0
  %".170" = or i32 %".167", %".169"
  %".171" = xor i32 %".162", -1
  %".172" = xor i32 524288, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %".171", 524288
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %".171", 524288
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = and i32 %".162", %".172"
  %".180" = and i32 %".179", %".173"
  %".181" = or i32 %".178", %".180"
  %".182" = and i32 %".162", %".172"
  %".183" = and i32 %".182", 0
  %".184" = or i32 %".181", %".183"
  %".185" = and i32 %".162", 524288
  %".186" = and i32 %".185", %".173"
  %".187" = or i32 %".184", %".186"
  %".188" = and i32 %".162", 524288
  %".189" = and i32 %".188", 0
  %".190" = or i32 %".187", %".189"
  %".191" = xor i32 %".170", -1
  %".192" = xor i32 524288, -1
  %".193" = xor i32 0, -1
  %".194" = and i32 %".191", 524288
  %".195" = and i32 %".194", %".193"
  %".196" = and i32 %".191", 524288
  %".197" = and i32 %".196", 0
  %".198" = or i32 %".195", %".197"
  %".199" = and i32 %".170", %".192"
  %".200" = and i32 %".199", %".193"
  %".201" = or i32 %".198", %".200"
  %".202" = and i32 %".170", %".192"
  %".203" = and i32 %".202", 0
  %".204" = or i32 %".201", %".203"
  %".205" = and i32 %".170", 524288
  %".206" = and i32 %".205", %".193"
  %".207" = or i32 %".204", %".206"
  %".208" = and i32 %".170", 524288
  %".209" = and i32 %".208", 0
  %".210" = or i32 %".207", %".209"
  %"lds_addr_memaddr_offset_add" = add i32 %".33", 8192
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".211" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".211" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_05e0"
BB_05e0:
  %"cond_trunc.7" = trunc i32 %"P10_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.7", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_800005e0", label %"BB_0600"
BB_800005e0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".33", 8192
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".215" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".215" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  br label %"BB_0600"
BB_0600:
  %"phi.6" = phi  i32 [%"lds.1", %"BB_800005e0"], [0, %"BB_05e0"]
  %"warp_reconv_mask" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask")
  %"imad_tmp.10" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.10", 0
  %".217" = xor i32 %"imad.10", -1
  %".218" = xor i32 65011712, -1
  %".219" = xor i32 0, -1
  %".220" = and i32 %"imad.10", 65011712
  %".221" = and i32 %".220", %".219"
  %".222" = and i32 %"imad.10", 65011712
  %".223" = and i32 %".222", 0
  %".224" = or i32 %".221", %".223"
  %"imad_tmp.11" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.11", %".224"
  br label %"BB_0630"
BB_0630:
  %"phi.7" = phi  i32 [%"P54_to_i32", %"BB_0600"], [%"phi.10", %"BB_0660"]
  %"phi.8" = phi  i32 [%"P46_to_i32", %"BB_0600"], [%"P50_to_i32", %"BB_0660"]
  %"cond_trunc.8" = trunc i32 %"phi.7" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000630", label %"BB_0640"
BB_80000630:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P48_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0640"
BB_0640:
  %"phi.9" = phi  i32 [%"P48_to_i32", %"BB_80000630"], [%"phi.8", %"BB_0630"]
  %"cond_trunc.9" = trunc i32 %"P69_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000640", label %"BB_0650"
BB_80000640:
  %"copy_desc_r0_ext" = zext i32 %".210" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".229" = ptrtoint [9232 x i8] addrspace(3)* @"shared_mem" to i64
  %".230" = sub i64 %".229", 0
  %".231" = lshr i64 %".230", 4
  %".232" = add i64 %"copy_desc_packed_1", %".231"
  %".233" = and i64 %".232", 16383
  %".234" = and i64 %"copy_desc_packed_1", -16384
  %".235" = or i64 %".234", %".233"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"phi.6", i64 %".235")
  br label %"BB_0650"
BB_0650:
  %"cond_trunc.10" = trunc i32 %"phi.9" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000650", label %"BB_0660"
BB_80000650:
  %"lop3_a_trunc.1" = trunc i32 %"phi.9" to i1
  %"lop3_a_cast_zext.2" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".239" = xor i32 %"plop3_a_bit.2", 1
  %".240" = xor i32 %"plop3_b_bit.2", 1
  %".241" = xor i32 %"plop3_c_bit.2", 1
  %".242" = and i32 %".239", %"plop3_b_bit.2"
  %".243" = and i32 %".242", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".243", 0
  %"P57_to_i32" = zext i1 %"plop3_pred.2" to i32
  br label %"BB_0660"
BB_0660:
  %"phi.10" = phi  i32 [%"P57_to_i32", %"BB_80000650"], [%"phi.7", %"BB_0650"]
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".245" = xor i32 %"plop3_a_bit.3", 1
  %".246" = xor i32 %"plop3_b_bit.3", 1
  %".247" = xor i32 %"plop3_c_bit.3", 1
  %".248" = and i32 %".245", %"plop3_b_bit.3"
  %".249" = and i32 %".248", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".249", 0
  %"P50_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.10" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0630", label %"BB_0680"
BB_0680:
  %"iadd3_n1.7" = add i32 1024, 8200
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".251" = xor i32 %"plop3_a_bit.4", 1
  %".252" = xor i32 %"plop3_b_bit.4", 1
  %".253" = xor i32 %"plop3_c_bit.4", 1
  %".254" = and i32 %".251", %"plop3_b_bit.4"
  %".255" = and i32 %".254", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".255", 0
  %"P51_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"vote_pred_trunc.3" = trunc i32 %"P10_to_i32" to i1
  %"vote_all.3" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.3")
  %"P70_to_i32" = zext i1 %"vote_all.3" to i32
  %"lop3_a_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"lop3_a_cast_zext.5" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".256" = xor i32 %"plop3_a_bit.5", 1
  %".257" = xor i32 %"plop3_b_bit.5", 1
  %".258" = xor i32 %"plop3_c_bit.5", 1
  %".259" = and i32 %".256", %"plop3_b_bit.5"
  %".260" = and i32 %".259", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".260", 0
  %"P59_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".261" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".262" = zext i32 %"iadd3_n2.7" to i64
  %".263" = zext i32 24 to i64
  %".264" = shl i64 %".261", %".263"
  %".265" = and i64 %".264", 4294967295
  %".266" = add i64 %".265", %".262"
  %".267" = trunc i64 %".266" to i32
  br label %"BB_06d0"
BB_06d0:
  %"phi.11" = phi  i32 [%"P59_to_i32", %"BB_0680"], [%"phi.14", %"BB_0700"]
  %"phi.12" = phi  i32 [%"P51_to_i32", %"BB_0680"], [%"P39_to_i32", %"BB_0700"]
  %"cond_trunc.11" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_800006d0", label %"BB_06e0"
BB_800006d0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P37_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_06e0"
BB_06e0:
  %"phi.13" = phi  i32 [%"P37_to_i32", %"BB_800006d0"], [%"phi.12", %"BB_06d0"]
  %"cond_trunc.12" = trunc i32 %"P70_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_800006e0", label %"BB_06f0"
BB_800006e0:
  %"utcbar_local_winoff" = and i32 %".267", 16777215
  %".272" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".273" = ptrtoint i8 addrspace(3)* %".272" to i32
  %".274" = lshr i32 %".267", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".273", i32 %".274")
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_800006f0", label %"BB_0700"
BB_800006f0:
  %"lop3_a_trunc.3" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".278" = xor i32 %"plop3_a_bit.6", 1
  %".279" = xor i32 %"plop3_b_bit.6", 1
  %".280" = xor i32 %"plop3_c_bit.6", 1
  %".281" = and i32 %".278", %"plop3_b_bit.6"
  %".282" = and i32 %".281", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".282", 0
  %"P61_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_0700"
BB_0700:
  %"phi.14" = phi  i32 [%"P61_to_i32", %"BB_800006f0"], [%"phi.11", %"BB_06f0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".284" = xor i32 %"plop3_a_bit.7", 1
  %".285" = xor i32 %"plop3_b_bit.7", 1
  %".286" = xor i32 %"plop3_c_bit.7", 1
  %".287" = and i32 %".284", %"plop3_b_bit.7"
  %".288" = and i32 %".287", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".288", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_06d0", label %"BB_0720"
BB_0720:
  call void @"llvm.nvvm.barrier0"()
  %".290" = zext i32 0 to i64
  %".291" = zext i32 0 to i64
  %".292" = shl i64 %".291", 32
  %"shf_concat.6" = or i64 %".290", %".292"
  %"shf_shift_64.6" = zext i32 31 to i64
  %".293" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".293" to i32
  %".294" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".295" = bitcast i8* %".294" to i64*
  %"ldc_const.1" = load i64, i64* %".295"
  %"R19:R18_r0" = trunc i64 %"ldc_const.1" to i32
  %"R19:R18_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"mbar_shared_winoff.1" = and i32 %".267", 16777215
  %".296" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".296" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P40_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0780"
BB_0780:
  %"cond_trunc.14" = trunc i32 %"P40_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_1660", label %"BB_0790"
BB_1660:
  %"mbar_shared_winoff.2" = and i32 %".267", 16777215
  %".299" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P41_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1670"
BB_1670:
  %"cond_trunc.15" = trunc i32 %"P41_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1660", label %"BB_0790"
BB_0790:
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".302" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".303" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad.2" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.12" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R25:R24_r0" = trunc i64 %"imad.12" to i32
  %"R25:R24_r1_shift" = lshr i64 %"imad.12", 32
  %"R25:R24_r1" = trunc i64 %"R25:R24_r1_shift" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %".19", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P43_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"viadd.7" = add i32 %"tid_x", 1
  %"viadd.8" = add i32 %"tid_x", 2
  %"viadd.9" = add i32 %"tid_x", 3
  %"stg_addr_r0_ext" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R31:R30_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".302", i32 addrspace(1)* %"R31:R30_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R31:R30_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".303", i32 addrspace(1)* %"R31:R30_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R31:R30_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R31:R30_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R31:R30_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R31:R30_addr_ptr.3"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"tid_x", i32 %"viadd.7", i32 %"viadd.8", i32 %"viadd.9")
  %"stg_addr_r0_ext.4" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R31:R30_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R31:R30_addr_ptr.4"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", -1
  %"stg_addr_r0_ext.5" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R31:R30_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R31:R30_addr_ptr.5"
  %"sel_pred_trunc.4" = trunc i32 %"P43_to_i32" to i1
  %"sel_pred_not.2" = xor i1 %"sel_pred_trunc.4", -1
  %"sel_pred_to_i32.4" = zext i1 %"sel_pred_not.2" to i32
  %"sel_pred_to_i1.4" = icmp ne i32 %"sel_pred_to_i32.4", 0
  %"sel.4" = select  i1 %"sel_pred_to_i1.4", i32 %"imad.13", i32 4278124286
  %"stg_addr_r0_ext.6" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R31:R30_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R31:R30_addr_ptr.6"
  %"sel_pred_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"sel_pred_not.3" = xor i1 %"sel_pred_trunc.5", -1
  %"sel_pred_to_i32.5" = zext i1 %"sel_pred_not.3" to i32
  %"sel_pred_to_i1.5" = icmp ne i32 %"sel_pred_to_i32.5", 0
  %"sel.5" = select  i1 %"sel_pred_to_i1.5", i32 %"sel.4", i32 %"phi"
  %"stg_addr_r0_ext.7" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R31:R30_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R31:R30_addr_ptr.7"
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 12
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".321" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"iadd3_n1.8" = add i32 %".61", %".33"
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"sts_val_r0_ext.4" = zext i32 %"sel.5" to i128
  %"sts_val_packed_0.4" = or i128 0, %"sts_val_r0_ext.4"
  %"sts_val_r1_ext.4" = zext i32 %"sel.5" to i128
  %"sts_val_r1_shift.4" = shl i128 %"sts_val_r1_ext.4", 32
  %"sts_val_packed_1.4" = or i128 %"sts_val_packed_0.4", %"sts_val_r1_shift.4"
  %"sts_val_r2_ext.4" = zext i32 %"sel.5" to i128
  %"sts_val_r2_shift.4" = shl i128 %"sts_val_r2_ext.4", 64
  %"sts_val_packed_2.4" = or i128 %"sts_val_packed_1.4", %"sts_val_r2_shift.4"
  %"sts_val_r3_ext.4" = zext i32 %"sel.5" to i128
  %"sts_val_r3_shift.4" = shl i128 %"sts_val_r3_ext.4", 96
  %"sts_val_packed_3.4" = or i128 %"sts_val_packed_2.4", %"sts_val_r3_shift.4"
  %"sts_shared_addr_winoff.5" = and i32 %"iadd3_n2.8", 16777215
  %".324" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".324" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.4", i128 addrspace(3)* %"sts_shared_addr_cast.5"
  %"iadd3_n1.9" = add i32 %".61", %".33"
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"sts_addr_memaddr_offset_add.3" = add i32 %"iadd3_n2.9", 128
  %"sts_val_r0_ext.5" = zext i32 %"sel.5" to i128
  %"sts_val_packed_0.5" = or i128 0, %"sts_val_r0_ext.5"
  %"sts_val_r1_ext.5" = zext i32 %"sel.5" to i128
  %"sts_val_r1_shift.5" = shl i128 %"sts_val_r1_ext.5", 32
  %"sts_val_packed_1.5" = or i128 %"sts_val_packed_0.5", %"sts_val_r1_shift.5"
  %"sts_val_r2_ext.5" = zext i32 %"sel.5" to i128
  %"sts_val_r2_shift.5" = shl i128 %"sts_val_r2_ext.5", 64
  %"sts_val_packed_2.5" = or i128 %"sts_val_packed_1.5", %"sts_val_r2_shift.5"
  %"sts_val_r3_ext.5" = zext i32 %"sel.5" to i128
  %"sts_val_r3_shift.5" = shl i128 %"sts_val_r3_ext.5", 96
  %"sts_val_packed_3.5" = or i128 %"sts_val_packed_2.5", %"sts_val_r3_shift.5"
  %"sts_shared_addr_winoff.6" = and i32 %"sts_addr_memaddr_offset_add.3", 16777215
  %".326" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.6"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".326" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.5", i128 addrspace(3)* %"sts_shared_addr_cast.6"
  %"stg_addr_r0_ext.8" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R31:R30_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R31:R30_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R31:R30_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".321", i32 addrspace(1)* %"R31:R30_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R31:R30_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R31:R30_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R25:R24_r0" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R25:R24_r1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R31:R30_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R31:R30_addr_ptr.11"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.16" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0cf0", label %"BB_0a70"
BB_0a70:
  %"cond_trunc.17" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0bf0", label %"BB_0a80"
BB_0a80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".33", 8192
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".336" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".336" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".337" = xor i32 %"plop3_a_bit.8", 1
  %".338" = xor i32 %"plop3_b_bit.8", 1
  %".339" = xor i32 %"plop3_c_bit.8", 1
  %".340" = and i32 %".337", %"plop3_b_bit.8"
  %".341" = and i32 %".340", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".341", 0
  %"P67_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"ldc_const", 1
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P71_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"lop3_c_trunc" = trunc i32 %"P71_to_i32" to i1
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".342" = xor i32 %"plop3_a_bit.9", 1
  %".343" = xor i32 %"plop3_b_bit.9", 1
  %".344" = xor i32 %"plop3_c_bit.9", 1
  %".345" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".346" = and i32 %".345", %".344"
  %"plop3_pred.9" = icmp ne i32 %".346", 0
  %"P24_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0ad0"
BB_0ad0:
  %"cond_trunc.18" = trunc i32 %"P71_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000ad0", label %"BB_0af0"
BB_80000ad0:
  br label %"BB_0af0"
BB_0af0:
  br label %"BB_0b00"
BB_0b00:
  %"phi.15" = phi  i32 [%"P24_to_i32", %"BB_0af0"], [%"phi.18", %"BB_0b30"]
  %"phi.16" = phi  i32 [%"P67_to_i32", %"BB_0af0"], [%"P4_to_i32", %"BB_0b30"]
  %"cond_trunc.19" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000b00", label %"BB_0b10"
BB_80000b00:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P74_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0b10"
BB_0b10:
  %"phi.17" = phi  i32 [%"P74_to_i32", %"BB_80000b00"], [%"phi.16", %"BB_0b00"]
  %"cond_trunc.20" = trunc i32 %"P71_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.20", -1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000b10", label %"BB_0b20"
BB_80000b10:
  %"mma_a_r0_ext" = zext i32 %".210" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".354" = ptrtoint [9232 x i8] addrspace(3)* @"shared_mem" to i64
  %".355" = sub i64 %".354", 0
  %".356" = lshr i64 %".355", 4
  %".357" = add i64 %"mma_a_packed_1", %".356"
  %".358" = and i64 %".357", 16383
  %".359" = and i64 %"mma_a_packed_1", -16384
  %".360" = or i64 %".359", %".358"
  %"mma_b_r0_ext" = zext i32 %".190" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".361" = ptrtoint [9232 x i8] addrspace(3)* @"shared_mem" to i64
  %".362" = sub i64 %".361", 0
  %".363" = lshr i64 %".362", 4
  %".364" = add i64 %"mma_b_packed_1", %".363"
  %".365" = and i64 %".364", 16383
  %".366" = and i64 %"mma_b_packed_1", -16384
  %".367" = or i64 %".366", %".365"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f16 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.2", i64 %".360", i64 %".367", i32 135267472, i32 %"mma_arg_zext")
  br label %"BB_0b20"
BB_0b20:
  %"cond_trunc.21" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000b20", label %"BB_0b30"
BB_80000b20:
  %"lop3_a_trunc.4" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.4" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".371" = xor i32 %"plop3_a_bit.10", 1
  %".372" = xor i32 %"plop3_b_bit.10", 1
  %".373" = xor i32 %"plop3_c_bit.10", 1
  %".374" = and i32 %".371", %"plop3_b_bit.10"
  %".375" = and i32 %".374", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".375", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_0b30"
BB_0b30:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_80000b20"], [%"phi.15", %"BB_0b20"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".377" = xor i32 %"plop3_a_bit.11", 1
  %".378" = xor i32 %"plop3_b_bit.11", 1
  %".379" = xor i32 %"plop3_c_bit.11", 1
  %".380" = and i32 %".377", %"plop3_b_bit.11"
  %".381" = and i32 %".380", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".381", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.4" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.4")
  br i1 %"branch_any.2", label %"BB_0b00", label %"BB_0b50"
BB_0b50:
  %"lop3_a_cast_zext.12" = zext i1 1 to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".383" = xor i32 %"plop3_a_bit.12", 1
  %".384" = xor i32 %"plop3_b_bit.12", 1
  %".385" = xor i32 %"plop3_c_bit.12", 1
  %".386" = and i32 %".383", %"plop3_b_bit.12"
  %".387" = and i32 %".386", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".387", 0
  %"P5_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_0b60"
BB_0b60:
  %"cond_trunc.22" = trunc i32 %"P71_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000b60", label %"BB_0b70"
BB_80000b60:
  br label %"BB_0b70"
BB_0b70:
  %"lop3_c_trunc.1" = trunc i32 %"P71_to_i32" to i1
  %"lop3_a_cast_zext.13" = zext i1 1 to i32
  %"lop3_b_cast_zext.13" = zext i1 1 to i32
  %"lop3_c_cast_zext.13" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.13" = and i32 %"lop3_a_cast_zext.13", 1
  %"plop3_b_bit.13" = and i32 %"lop3_b_cast_zext.13", 1
  %"plop3_c_bit.13" = and i32 %"lop3_c_cast_zext.13", 1
  %".391" = xor i32 %"plop3_a_bit.13", 1
  %".392" = xor i32 %"plop3_b_bit.13", 1
  %".393" = xor i32 %"plop3_c_bit.13", 1
  %".394" = and i32 %"plop3_a_bit.13", %"plop3_b_bit.13"
  %".395" = and i32 %".394", %"plop3_c_bit.13"
  %"plop3_pred.13" = icmp ne i32 %".395", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.13" to i32
  br label %"BB_0b80"
BB_0b80:
  %"cond_trunc.23" = trunc i32 %"P71_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000b80", label %"BB_0b90"
BB_80000b80:
  br label %"BB_0b90"
BB_0b90:
  %"phi.19" = phi  i32 [%"phi.22", %"BB_0bc0"], [%"P29_to_i32", %"BB_80000b80"], [%"P29_to_i32", %"BB_0b80"]
  %"phi.20" = phi  i32 [%"P19_to_i32", %"BB_0bc0"], [%"P5_to_i32", %"BB_80000b80"], [%"P5_to_i32", %"BB_0b80"]
  %"cond_trunc.24" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P23_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.21" = phi  i32 [%"P23_to_i32", %"BB_80000b90"], [%"phi.20", %"BB_0b90"]
  %"cond_trunc.25" = trunc i32 %"P71_to_i32" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80000ba0", label %"BB_0bb0"
BB_80000ba0:
  %"mma_a_r0_ext.1" = zext i32 %".210" to i64
  %"mma_a_packed_0.1" = or i64 0, %"mma_a_r0_ext.1"
  %"mma_a_r1_ext.1" = zext i32 16400 to i64
  %"mma_a_r1_shift.1" = shl i64 %"mma_a_r1_ext.1", 32
  %"mma_a_packed_1.1" = or i64 %"mma_a_packed_0.1", %"mma_a_r1_shift.1"
  %".402" = ptrtoint [9232 x i8] addrspace(3)* @"shared_mem" to i64
  %".403" = sub i64 %".402", 0
  %".404" = lshr i64 %".403", 4
  %".405" = add i64 %"mma_a_packed_1.1", %".404"
  %".406" = and i64 %".405", 16383
  %".407" = and i64 %"mma_a_packed_1.1", -16384
  %".408" = or i64 %".407", %".406"
  %"mma_b_r0_ext.1" = zext i32 %".190" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".409" = ptrtoint [9232 x i8] addrspace(3)* @"shared_mem" to i64
  %".410" = sub i64 %".409", 0
  %".411" = lshr i64 %".410", 4
  %".412" = add i64 %"mma_b_packed_1.1", %".411"
  %".413" = and i64 %".412", 16383
  %".414" = and i64 %"mma_b_packed_1.1", -16384
  %".415" = or i64 %".414", %".413"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f16 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.2", i64 %".408", i64 %".415", i32 135266320, i32 %"mma_arg_zext.1")
  br label %"BB_0bb0"
BB_0bb0:
  %"cond_trunc.26" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_trunc.26" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_80000bb0", label %"BB_0bc0"
BB_80000bb0:
  %"lop3_a_trunc.5" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.14" = zext i1 %"lop3_a_trunc.5" to i32
  %"lop3_b_cast_zext.14" = zext i1 1 to i32
  %"lop3_c_cast_zext.14" = zext i1 1 to i32
  %"plop3_a_bit.14" = and i32 %"lop3_a_cast_zext.14", 1
  %"plop3_b_bit.14" = and i32 %"lop3_b_cast_zext.14", 1
  %"plop3_c_bit.14" = and i32 %"lop3_c_cast_zext.14", 1
  %".419" = xor i32 %"plop3_a_bit.14", 1
  %".420" = xor i32 %"plop3_b_bit.14", 1
  %".421" = xor i32 %"plop3_c_bit.14", 1
  %".422" = and i32 %".419", %"plop3_b_bit.14"
  %".423" = and i32 %".422", %"plop3_c_bit.14"
  %"plop3_pred.14" = icmp ne i32 %".423", 0
  %"P32_to_i32" = zext i1 %"plop3_pred.14" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"phi.22" = phi  i32 [%"P32_to_i32", %"BB_80000bb0"], [%"phi.19", %"BB_0bb0"]
  %"lop3_a_cast_zext.15" = zext i1 1 to i32
  %"lop3_b_cast_zext.15" = zext i1 1 to i32
  %"lop3_c_cast_zext.15" = zext i1 1 to i32
  %"plop3_a_bit.15" = and i32 %"lop3_a_cast_zext.15", 1
  %"plop3_b_bit.15" = and i32 %"lop3_b_cast_zext.15", 1
  %"plop3_c_bit.15" = and i32 %"lop3_c_cast_zext.15", 1
  %".425" = xor i32 %"plop3_a_bit.15", 1
  %".426" = xor i32 %"plop3_b_bit.15", 1
  %".427" = xor i32 %"plop3_c_bit.15", 1
  %".428" = and i32 %".425", %"plop3_b_bit.15"
  %".429" = and i32 %".428", %"plop3_c_bit.15"
  %"plop3_pred.15" = icmp ne i32 %".429", 0
  %"P19_to_i32" = zext i1 %"plop3_pred.15" to i32
  %"bra_cond_trunc.5" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_trunc.5" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.5")
  br i1 %"branch_any.3", label %"BB_0b90", label %"BB_0c90"
BB_0bf0:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".33", 8192
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".431" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".431" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.16" = zext i1 1 to i32
  %"lop3_b_cast_zext.16" = zext i1 1 to i32
  %"lop3_c_cast_zext.16" = zext i1 1 to i32
  %"plop3_a_bit.16" = and i32 %"lop3_a_cast_zext.16", 1
  %"plop3_b_bit.16" = and i32 %"lop3_b_cast_zext.16", 1
  %"plop3_c_bit.16" = and i32 %"lop3_c_cast_zext.16", 1
  %".432" = xor i32 %"plop3_a_bit.16", 1
  %".433" = xor i32 %"plop3_b_bit.16", 1
  %".434" = xor i32 %"plop3_c_bit.16", 1
  %".435" = and i32 %"plop3_a_bit.16", %"plop3_b_bit.16"
  %".436" = and i32 %".435", %"plop3_c_bit.16"
  %"plop3_pred.16" = icmp ne i32 %".436", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.16" to i32
  br label %"BB_0c40"
BB_0c40:
  %"phi.23" = phi  i32 [%"P10_to_i32", %"BB_0bf0"], [%"P16_to_i32", %"BB_0c70"]
  %"phi.24" = phi  i32 [%"P31_to_i32", %"BB_0bf0"], [%"phi.26", %"BB_0c70"]
  %"cond_trunc.27" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_trunc.27" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_80000c40", label %"BB_0c50"
BB_80000c40:
  %"elect_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"election.5" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.5")
  %"elect_p.5" = extractvalue {i32, i1} %"election.5", 1
  %"P13_to_i32" = zext i1 %"elect_p.5" to i32
  br label %"BB_0c50"
BB_0c50:
  %"phi.25" = phi  i32 [%"P13_to_i32", %"BB_80000c40"], [%"phi.23", %"BB_0c40"]
  %"mma_a_r0_ext.2" = zext i32 %".210" to i64
  %"mma_a_packed_0.2" = or i64 0, %"mma_a_r0_ext.2"
  %"mma_a_r1_ext.2" = zext i32 16400 to i64
  %"mma_a_r1_shift.2" = shl i64 %"mma_a_r1_ext.2", 32
  %"mma_a_packed_1.2" = or i64 %"mma_a_packed_0.2", %"mma_a_r1_shift.2"
  %".440" = ptrtoint [9232 x i8] addrspace(3)* @"shared_mem" to i64
  %".441" = sub i64 %".440", 0
  %".442" = lshr i64 %".441", 4
  %".443" = add i64 %"mma_a_packed_1.2", %".442"
  %".444" = and i64 %".443", 16383
  %".445" = and i64 %"mma_a_packed_1.2", -16384
  %".446" = or i64 %".445", %".444"
  %"mma_b_r0_ext.2" = zext i32 %".190" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".447" = ptrtoint [9232 x i8] addrspace(3)* @"shared_mem" to i64
  %".448" = sub i64 %".447", 0
  %".449" = lshr i64 %".448", 4
  %".450" = add i64 %"mma_b_packed_1.2", %".449"
  %".451" = and i64 %".450", 16383
  %".452" = and i64 %"mma_b_packed_1.2", -16384
  %".453" = or i64 %".452", %".451"
  %"mma_arg_zext.2" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::i8 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.3", i64 %".446", i64 %".453", i32 135266336, i32 %"mma_arg_zext.2")
  br label %"BB_0c60"
BB_0c60:
  %"cond_trunc.28" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_80000c60", label %"BB_0c70"
BB_80000c60:
  %"lop3_a_trunc.6" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.17" = zext i1 %"lop3_a_trunc.6" to i32
  %"lop3_b_cast_zext.17" = zext i1 1 to i32
  %"lop3_c_cast_zext.17" = zext i1 1 to i32
  %"plop3_a_bit.17" = and i32 %"lop3_a_cast_zext.17", 1
  %"plop3_b_bit.17" = and i32 %"lop3_b_cast_zext.17", 1
  %"plop3_c_bit.17" = and i32 %"lop3_c_cast_zext.17", 1
  %".457" = xor i32 %"plop3_a_bit.17", 1
  %".458" = xor i32 %"plop3_b_bit.17", 1
  %".459" = xor i32 %"plop3_c_bit.17", 1
  %".460" = and i32 %".457", %"plop3_b_bit.17"
  %".461" = and i32 %".460", %"plop3_c_bit.17"
  %"plop3_pred.17" = icmp ne i32 %".461", 0
  %"P53_to_i32" = zext i1 %"plop3_pred.17" to i32
  br label %"BB_0c70"
BB_0c70:
  %"phi.26" = phi  i32 [%"P53_to_i32", %"BB_80000c60"], [%"phi.24", %"BB_0c60"]
  %"lop3_a_cast_zext.18" = zext i1 1 to i32
  %"lop3_b_cast_zext.18" = zext i1 1 to i32
  %"lop3_c_cast_zext.18" = zext i1 1 to i32
  %"plop3_a_bit.18" = and i32 %"lop3_a_cast_zext.18", 1
  %"plop3_b_bit.18" = and i32 %"lop3_b_cast_zext.18", 1
  %"plop3_c_bit.18" = and i32 %"lop3_c_cast_zext.18", 1
  %".463" = xor i32 %"plop3_a_bit.18", 1
  %".464" = xor i32 %"plop3_b_bit.18", 1
  %".465" = xor i32 %"plop3_c_bit.18", 1
  %".466" = and i32 %".463", %"plop3_b_bit.18"
  %".467" = and i32 %".466", %"plop3_c_bit.18"
  %"plop3_pred.18" = icmp ne i32 %".467", 0
  %"P16_to_i32" = zext i1 %"plop3_pred.18" to i32
  %"bra_cond_trunc.6" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.6" = zext i1 %"bra_cond_trunc.6" to i32
  %"bra_cond_to_i1.6" = icmp ne i32 %"bra_cond_to_i32.6", 0
  %"branch_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.4" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.4", i1 %"bra_cond_to_i1.6")
  br i1 %"branch_any.4", label %"BB_0c40", label %"BB_0c90"
BB_0c90:
  %"phi.27" = phi  i32 [%"phi.22", %"BB_0bc0"], [%"P16_to_i32", %"BB_0c70"]
  %"lop3_a_cast_zext.19" = zext i1 1 to i32
  %"lop3_b_cast_zext.19" = zext i1 1 to i32
  %"lop3_c_cast_zext.19" = zext i1 1 to i32
  %"plop3_a_bit.19" = and i32 %"lop3_a_cast_zext.19", 1
  %"plop3_b_bit.19" = and i32 %"lop3_b_cast_zext.19", 1
  %"plop3_c_bit.19" = and i32 %"lop3_c_cast_zext.19", 1
  %".469" = xor i32 %"plop3_a_bit.19", 1
  %".470" = xor i32 %"plop3_b_bit.19", 1
  %".471" = xor i32 %"plop3_c_bit.19", 1
  %".472" = and i32 %"plop3_a_bit.19", %"plop3_b_bit.19"
  %".473" = and i32 %".472", %"plop3_c_bit.19"
  %"plop3_pred.19" = icmp ne i32 %".473", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.19" to i32
  br label %"BB_0ca0"
BB_0ca0:
  %"phi.28" = phi  i32 [%"phi.27", %"BB_0c90"], [%"P22_to_i32", %"BB_0cd0"]
  %"phi.29" = phi  i32 [%"P2_to_i32", %"BB_0c90"], [%"phi.31", %"BB_0cd0"]
  %"cond_trunc.29" = trunc i32 %"phi.29" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_80000ca0", label %"BB_0cb0"
BB_80000ca0:
  %"elect_mask.6" = call i32 @"llvm.nvvm.activemask"()
  %"election.6" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.6")
  %"elect_p.6" = extractvalue {i32, i1} %"election.6", 1
  %"P20_to_i32" = zext i1 %"elect_p.6" to i32
  br label %"BB_0cb0"
BB_0cb0:
  %"phi.30" = phi  i32 [%"P20_to_i32", %"BB_80000ca0"], [%"phi.28", %"BB_0ca0"]
  %"utcbar_local_winoff.1" = and i32 %".267", 16777215
  %".477" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff.1"
  %".478" = ptrtoint i8 addrspace(3)* %".477" to i32
  %".479" = lshr i32 %".267", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".478", i32 %".479")
  br label %"BB_0cc0"
BB_0cc0:
  %"cond_trunc.30" = trunc i32 %"phi.30" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_80000cc0", label %"BB_0cd0"
BB_80000cc0:
  %"lop3_a_trunc.7" = trunc i32 %"phi.30" to i1
  %"lop3_a_cast_zext.20" = zext i1 %"lop3_a_trunc.7" to i32
  %"lop3_b_cast_zext.20" = zext i1 1 to i32
  %"lop3_c_cast_zext.20" = zext i1 1 to i32
  %"plop3_a_bit.20" = and i32 %"lop3_a_cast_zext.20", 1
  %"plop3_b_bit.20" = and i32 %"lop3_b_cast_zext.20", 1
  %"plop3_c_bit.20" = and i32 %"lop3_c_cast_zext.20", 1
  %".483" = xor i32 %"plop3_a_bit.20", 1
  %".484" = xor i32 %"plop3_b_bit.20", 1
  %".485" = xor i32 %"plop3_c_bit.20", 1
  %".486" = and i32 %".483", %"plop3_b_bit.20"
  %".487" = and i32 %".486", %"plop3_c_bit.20"
  %"plop3_pred.20" = icmp ne i32 %".487", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.20" to i32
  br label %"BB_0cd0"
BB_0cd0:
  %"phi.31" = phi  i32 [%"P36_to_i32", %"BB_80000cc0"], [%"phi.29", %"BB_0cc0"]
  %"lop3_a_cast_zext.21" = zext i1 1 to i32
  %"lop3_b_cast_zext.21" = zext i1 1 to i32
  %"lop3_c_cast_zext.21" = zext i1 1 to i32
  %"plop3_a_bit.21" = and i32 %"lop3_a_cast_zext.21", 1
  %"plop3_b_bit.21" = and i32 %"lop3_b_cast_zext.21", 1
  %"plop3_c_bit.21" = and i32 %"lop3_c_cast_zext.21", 1
  %".489" = xor i32 %"plop3_a_bit.21", 1
  %".490" = xor i32 %"plop3_b_bit.21", 1
  %".491" = xor i32 %"plop3_c_bit.21", 1
  %".492" = and i32 %".489", %"plop3_b_bit.21"
  %".493" = and i32 %".492", %"plop3_c_bit.21"
  %"plop3_pred.21" = icmp ne i32 %".493", 0
  %"P22_to_i32" = zext i1 %"plop3_pred.21" to i32
  %"bra_cond_trunc.7" = trunc i32 %"phi.31" to i1
  %"bra_cond_to_i32.7" = zext i1 %"bra_cond_trunc.7" to i32
  %"bra_cond_to_i1.7" = icmp ne i32 %"bra_cond_to_i32.7", 0
  %"branch_mask.5" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.5" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.5", i1 %"bra_cond_to_i1.7")
  br i1 %"branch_any.5", label %"BB_0ca0", label %"BB_0cf0"
BB_0cf0:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", 1
  %".495" = zext i32 %"imad.14" to i64
  %".496" = zext i32 0 to i64
  %".497" = shl i64 %".496", 32
  %"shf_concat.7" = or i64 %".495", %".497"
  %"shf_shift_64.7" = zext i32 31 to i64
  %".498" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".498" to i32
  %"mbar_shared_winoff.3" = and i32 %".267", 16777215
  %".499" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.3"
  %"mbar_ptr.3" = ptrtoint i8 addrspace(3)* %".499" to i64
  %"mbar_par_bit.2" = lshr i32 %"shf_result.7", 31
  %"mbar_phasechk.2" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.3", i32 %"mbar_par_bit.2")
  %"mbar_ready.2" = icmp ne i32 %"mbar_phasechk.2", 0
  %"P65_to_i32" = zext i1 %"mbar_ready.2" to i32
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.31" = trunc i32 %"P65_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.31", -1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_1690", label %"BB_0d60"
BB_1690:
  %"mbar_shared_winoff.4" = and i32 %".267", 16777215
  %".502" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.4"
  %"mbar_ptr.4" = ptrtoint i8 addrspace(3)* %".502" to i64
  %"mbar_par_bit.3" = lshr i32 %"shf_result.7", 31
  %"mbar_phasechk.3" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.4", i32 %"mbar_par_bit.3")
  %"mbar_ready.3" = icmp ne i32 %"mbar_phasechk.3", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.3" to i32
  br label %"BB_16a0"
BB_16a0:
  %"cond_trunc.32" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.15" = xor i1 %"cond_trunc.32", -1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_not.15" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_1690", label %"BB_0d60"
BB_0d60:
  %"imad_tmp.14" = mul i32 %"tid_x", 64
  %"imad.15" = add i32 %"imad_tmp.14", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R19:R18_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R19:R18_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.15" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.16" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R19:R18_r0.1" = trunc i64 %"imad.16" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"imad.16", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".505" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".506" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".507" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".508" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 4
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".509" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".510" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".511" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".512" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.12" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 8192
  %"R203:R200_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".505", i32 addrspace(1)* %"R203:R200_addr_ptr"
  %"stg_addr_r0_ext.13" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 8196
  %"R203:R200_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".506", i32 addrspace(1)* %"R203:R200_addr_ptr.1"
  %"stg_addr_r0_ext.14" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 8200
  %"R203:R200_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".507", i32 addrspace(1)* %"R203:R200_addr_ptr.2"
  %"stg_addr_r0_ext.15" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 8204
  %"R203:R200_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".508", i32 addrspace(1)* %"R203:R200_addr_ptr.3"
  %"stg_addr_r0_ext.16" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 8208
  %"R203:R200_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".509", i32 addrspace(1)* %"R203:R200_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.11", 8
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".518" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".519" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".520" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".521" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.17" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 8212
  %"R203:R200_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".510", i32 addrspace(1)* %"R203:R200_addr_ptr.5"
  %"stg_addr_r0_ext.18" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 8216
  %"R203:R200_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".511", i32 addrspace(1)* %"R203:R200_addr_ptr.6"
  %"stg_addr_r0_ext.19" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 8220
  %"R203:R200_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".512", i32 addrspace(1)* %"R203:R200_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.11", 12
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".525" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".526" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".527" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".528" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.20" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 8224
  %"R203:R200_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".518", i32 addrspace(1)* %"R203:R200_addr_ptr.8"
  %"stg_addr_r0_ext.21" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 8228
  %"R203:R200_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".519", i32 addrspace(1)* %"R203:R200_addr_ptr.9"
  %"stg_addr_r0_ext.22" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 8232
  %"R203:R200_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".520", i32 addrspace(1)* %"R203:R200_addr_ptr.10"
  %"stg_addr_r0_ext.23" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 8236
  %"R203:R200_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".521", i32 addrspace(1)* %"R203:R200_addr_ptr.11"
  %"stg_addr_r0_ext.24" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 8240
  %"R203:R200_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".525", i32 addrspace(1)* %"R203:R200_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.11", 16
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".534" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".535" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".536" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".537" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.25" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 8244
  %"R203:R200_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".526", i32 addrspace(1)* %"R203:R200_addr_ptr.13"
  %"stg_addr_r0_ext.26" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 8248
  %"R203:R200_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".527", i32 addrspace(1)* %"R203:R200_addr_ptr.14"
  %"stg_addr_r0_ext.27" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 8252
  %"R203:R200_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".528", i32 addrspace(1)* %"R203:R200_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.11", 20
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".541" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".542" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".543" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".544" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.28" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 8256
  %"R203:R200_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".534", i32 addrspace(1)* %"R203:R200_addr_ptr.16"
  %"stg_addr_r0_ext.29" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 8260
  %"R203:R200_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".535", i32 addrspace(1)* %"R203:R200_addr_ptr.17"
  %"stg_addr_r0_ext.30" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 8264
  %"R203:R200_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".536", i32 addrspace(1)* %"R203:R200_addr_ptr.18"
  %"stg_addr_r0_ext.31" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 8268
  %"R203:R200_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".537", i32 addrspace(1)* %"R203:R200_addr_ptr.19"
  %"stg_addr_r0_ext.32" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 8272
  %"R203:R200_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".541", i32 addrspace(1)* %"R203:R200_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.11", 24
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".550" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".551" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".552" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".553" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.33" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 8276
  %"R203:R200_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".542", i32 addrspace(1)* %"R203:R200_addr_ptr.21"
  %"stg_addr_r0_ext.34" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 8280
  %"R203:R200_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".543", i32 addrspace(1)* %"R203:R200_addr_ptr.22"
  %"stg_addr_r0_ext.35" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 8284
  %"R203:R200_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".544", i32 addrspace(1)* %"R203:R200_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.11", 28
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".557" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".558" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".559" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".560" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.36" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 8288
  %"R203:R200_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".550", i32 addrspace(1)* %"R203:R200_addr_ptr.24"
  %"stg_addr_r0_ext.37" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 8292
  %"R203:R200_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".551", i32 addrspace(1)* %"R203:R200_addr_ptr.25"
  %"stg_addr_r0_ext.38" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 8296
  %"R203:R200_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".552", i32 addrspace(1)* %"R203:R200_addr_ptr.26"
  %"stg_addr_r0_ext.39" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 8300
  %"R203:R200_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".553", i32 addrspace(1)* %"R203:R200_addr_ptr.27"
  %"stg_addr_r0_ext.40" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 8304
  %"R203:R200_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".557", i32 addrspace(1)* %"R203:R200_addr_ptr.28"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.11", 32
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".566" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".567" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".568" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".569" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.41" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.41" = or i64 0, %"stg_addr_r0_ext.41"
  %"stg_addr_r1_ext.41" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.41" = shl i64 %"stg_addr_r1_ext.41", 32
  %"stg_addr_packed_1.41" = or i64 %"stg_addr_packed_0.41", %"stg_addr_r1_shift.41"
  %"stg_addr_memaddr_offset_add.40" = add i64 %"stg_addr_packed_1.41", 8308
  %"R203:R200_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  store i32 %".558", i32 addrspace(1)* %"R203:R200_addr_ptr.29"
  %"stg_addr_r0_ext.42" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.42" = or i64 0, %"stg_addr_r0_ext.42"
  %"stg_addr_r1_ext.42" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.42" = shl i64 %"stg_addr_r1_ext.42", 32
  %"stg_addr_packed_1.42" = or i64 %"stg_addr_packed_0.42", %"stg_addr_r1_shift.42"
  %"stg_addr_memaddr_offset_add.41" = add i64 %"stg_addr_packed_1.42", 8312
  %"R203:R200_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  store i32 %".559", i32 addrspace(1)* %"R203:R200_addr_ptr.30"
  %"stg_addr_r0_ext.43" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.43" = or i64 0, %"stg_addr_r0_ext.43"
  %"stg_addr_r1_ext.43" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.43" = shl i64 %"stg_addr_r1_ext.43", 32
  %"stg_addr_packed_1.43" = or i64 %"stg_addr_packed_0.43", %"stg_addr_r1_shift.43"
  %"stg_addr_memaddr_offset_add.42" = add i64 %"stg_addr_packed_1.43", 8316
  %"R203:R200_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.42" to i32 addrspace(1)*
  store i32 %".560", i32 addrspace(1)* %"R203:R200_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.11", 36
  %"ldtm.12" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".573" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 0
  %".574" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 1
  %".575" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 2
  %".576" = extractvalue {i32, i32, i32, i32} %"ldtm.12", 3
  %"stg_addr_r0_ext.44" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.44" = or i64 0, %"stg_addr_r0_ext.44"
  %"stg_addr_r1_ext.44" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.44" = shl i64 %"stg_addr_r1_ext.44", 32
  %"stg_addr_packed_1.44" = or i64 %"stg_addr_packed_0.44", %"stg_addr_r1_shift.44"
  %"stg_addr_memaddr_offset_add.43" = add i64 %"stg_addr_packed_1.44", 8320
  %"R203:R200_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.43" to i32 addrspace(1)*
  store i32 %".566", i32 addrspace(1)* %"R203:R200_addr_ptr.32"
  %"stg_addr_r0_ext.45" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.45" = or i64 0, %"stg_addr_r0_ext.45"
  %"stg_addr_r1_ext.45" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.45" = shl i64 %"stg_addr_r1_ext.45", 32
  %"stg_addr_packed_1.45" = or i64 %"stg_addr_packed_0.45", %"stg_addr_r1_shift.45"
  %"stg_addr_memaddr_offset_add.44" = add i64 %"stg_addr_packed_1.45", 8324
  %"R203:R200_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.44" to i32 addrspace(1)*
  store i32 %".567", i32 addrspace(1)* %"R203:R200_addr_ptr.33"
  %"stg_addr_r0_ext.46" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.46" = or i64 0, %"stg_addr_r0_ext.46"
  %"stg_addr_r1_ext.46" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.46" = shl i64 %"stg_addr_r1_ext.46", 32
  %"stg_addr_packed_1.46" = or i64 %"stg_addr_packed_0.46", %"stg_addr_r1_shift.46"
  %"stg_addr_memaddr_offset_add.45" = add i64 %"stg_addr_packed_1.46", 8328
  %"R203:R200_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.45" to i32 addrspace(1)*
  store i32 %".568", i32 addrspace(1)* %"R203:R200_addr_ptr.34"
  %"stg_addr_r0_ext.47" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.47" = or i64 0, %"stg_addr_r0_ext.47"
  %"stg_addr_r1_ext.47" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.47" = shl i64 %"stg_addr_r1_ext.47", 32
  %"stg_addr_packed_1.47" = or i64 %"stg_addr_packed_0.47", %"stg_addr_r1_shift.47"
  %"stg_addr_memaddr_offset_add.46" = add i64 %"stg_addr_packed_1.47", 8332
  %"R203:R200_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.46" to i32 addrspace(1)*
  store i32 %".569", i32 addrspace(1)* %"R203:R200_addr_ptr.35"
  %"stg_addr_r0_ext.48" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.48" = or i64 0, %"stg_addr_r0_ext.48"
  %"stg_addr_r1_ext.48" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.48" = shl i64 %"stg_addr_r1_ext.48", 32
  %"stg_addr_packed_1.48" = or i64 %"stg_addr_packed_0.48", %"stg_addr_r1_shift.48"
  %"stg_addr_memaddr_offset_add.47" = add i64 %"stg_addr_packed_1.48", 8336
  %"R203:R200_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.47" to i32 addrspace(1)*
  store i32 %".573", i32 addrspace(1)* %"R203:R200_addr_ptr.36"
  %"ldtm_addr_memaddr_offset_add.11" = add i32 %"imad.11", 40
  %"ldtm.13" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.11")
  %".582" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 0
  %".583" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 1
  %".584" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 2
  %".585" = extractvalue {i32, i32, i32, i32} %"ldtm.13", 3
  %"stg_addr_r0_ext.49" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.49" = or i64 0, %"stg_addr_r0_ext.49"
  %"stg_addr_r1_ext.49" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.49" = shl i64 %"stg_addr_r1_ext.49", 32
  %"stg_addr_packed_1.49" = or i64 %"stg_addr_packed_0.49", %"stg_addr_r1_shift.49"
  %"stg_addr_memaddr_offset_add.48" = add i64 %"stg_addr_packed_1.49", 8340
  %"R203:R200_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.48" to i32 addrspace(1)*
  store i32 %".574", i32 addrspace(1)* %"R203:R200_addr_ptr.37"
  %"stg_addr_r0_ext.50" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.50" = or i64 0, %"stg_addr_r0_ext.50"
  %"stg_addr_r1_ext.50" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.50" = shl i64 %"stg_addr_r1_ext.50", 32
  %"stg_addr_packed_1.50" = or i64 %"stg_addr_packed_0.50", %"stg_addr_r1_shift.50"
  %"stg_addr_memaddr_offset_add.49" = add i64 %"stg_addr_packed_1.50", 8344
  %"R203:R200_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.49" to i32 addrspace(1)*
  store i32 %".575", i32 addrspace(1)* %"R203:R200_addr_ptr.38"
  %"stg_addr_r0_ext.51" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.51" = or i64 0, %"stg_addr_r0_ext.51"
  %"stg_addr_r1_ext.51" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.51" = shl i64 %"stg_addr_r1_ext.51", 32
  %"stg_addr_packed_1.51" = or i64 %"stg_addr_packed_0.51", %"stg_addr_r1_shift.51"
  %"stg_addr_memaddr_offset_add.50" = add i64 %"stg_addr_packed_1.51", 8348
  %"R203:R200_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.50" to i32 addrspace(1)*
  store i32 %".576", i32 addrspace(1)* %"R203:R200_addr_ptr.39"
  %"ldtm_addr_memaddr_offset_add.12" = add i32 %"imad.11", 44
  %"ldtm.14" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.12")
  %".589" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 0
  %".590" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 1
  %".591" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 2
  %".592" = extractvalue {i32, i32, i32, i32} %"ldtm.14", 3
  %"stg_addr_r0_ext.52" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.52" = or i64 0, %"stg_addr_r0_ext.52"
  %"stg_addr_r1_ext.52" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.52" = shl i64 %"stg_addr_r1_ext.52", 32
  %"stg_addr_packed_1.52" = or i64 %"stg_addr_packed_0.52", %"stg_addr_r1_shift.52"
  %"stg_addr_memaddr_offset_add.51" = add i64 %"stg_addr_packed_1.52", 8352
  %"R203:R200_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.51" to i32 addrspace(1)*
  store i32 %".582", i32 addrspace(1)* %"R203:R200_addr_ptr.40"
  %"stg_addr_r0_ext.53" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.53" = or i64 0, %"stg_addr_r0_ext.53"
  %"stg_addr_r1_ext.53" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.53" = shl i64 %"stg_addr_r1_ext.53", 32
  %"stg_addr_packed_1.53" = or i64 %"stg_addr_packed_0.53", %"stg_addr_r1_shift.53"
  %"stg_addr_memaddr_offset_add.52" = add i64 %"stg_addr_packed_1.53", 8356
  %"R203:R200_addr_ptr.41" = inttoptr i64 %"stg_addr_memaddr_offset_add.52" to i32 addrspace(1)*
  store i32 %".583", i32 addrspace(1)* %"R203:R200_addr_ptr.41"
  %"stg_addr_r0_ext.54" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.54" = or i64 0, %"stg_addr_r0_ext.54"
  %"stg_addr_r1_ext.54" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.54" = shl i64 %"stg_addr_r1_ext.54", 32
  %"stg_addr_packed_1.54" = or i64 %"stg_addr_packed_0.54", %"stg_addr_r1_shift.54"
  %"stg_addr_memaddr_offset_add.53" = add i64 %"stg_addr_packed_1.54", 8360
  %"R203:R200_addr_ptr.42" = inttoptr i64 %"stg_addr_memaddr_offset_add.53" to i32 addrspace(1)*
  store i32 %".584", i32 addrspace(1)* %"R203:R200_addr_ptr.42"
  %"stg_addr_r0_ext.55" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.55" = or i64 0, %"stg_addr_r0_ext.55"
  %"stg_addr_r1_ext.55" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.55" = shl i64 %"stg_addr_r1_ext.55", 32
  %"stg_addr_packed_1.55" = or i64 %"stg_addr_packed_0.55", %"stg_addr_r1_shift.55"
  %"stg_addr_memaddr_offset_add.54" = add i64 %"stg_addr_packed_1.55", 8364
  %"R203:R200_addr_ptr.43" = inttoptr i64 %"stg_addr_memaddr_offset_add.54" to i32 addrspace(1)*
  store i32 %".585", i32 addrspace(1)* %"R203:R200_addr_ptr.43"
  %"stg_addr_r0_ext.56" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.56" = or i64 0, %"stg_addr_r0_ext.56"
  %"stg_addr_r1_ext.56" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.56" = shl i64 %"stg_addr_r1_ext.56", 32
  %"stg_addr_packed_1.56" = or i64 %"stg_addr_packed_0.56", %"stg_addr_r1_shift.56"
  %"stg_addr_memaddr_offset_add.55" = add i64 %"stg_addr_packed_1.56", 8368
  %"R203:R200_addr_ptr.44" = inttoptr i64 %"stg_addr_memaddr_offset_add.55" to i32 addrspace(1)*
  store i32 %".589", i32 addrspace(1)* %"R203:R200_addr_ptr.44"
  %"ldtm_addr_memaddr_offset_add.13" = add i32 %"imad.11", 48
  %"ldtm.15" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.13")
  %".598" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 0
  %".599" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 1
  %".600" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 2
  %".601" = extractvalue {i32, i32, i32, i32} %"ldtm.15", 3
  %"stg_addr_r0_ext.57" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.57" = or i64 0, %"stg_addr_r0_ext.57"
  %"stg_addr_r1_ext.57" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.57" = shl i64 %"stg_addr_r1_ext.57", 32
  %"stg_addr_packed_1.57" = or i64 %"stg_addr_packed_0.57", %"stg_addr_r1_shift.57"
  %"stg_addr_memaddr_offset_add.56" = add i64 %"stg_addr_packed_1.57", 8372
  %"R203:R200_addr_ptr.45" = inttoptr i64 %"stg_addr_memaddr_offset_add.56" to i32 addrspace(1)*
  store i32 %".590", i32 addrspace(1)* %"R203:R200_addr_ptr.45"
  %"stg_addr_r0_ext.58" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.58" = or i64 0, %"stg_addr_r0_ext.58"
  %"stg_addr_r1_ext.58" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.58" = shl i64 %"stg_addr_r1_ext.58", 32
  %"stg_addr_packed_1.58" = or i64 %"stg_addr_packed_0.58", %"stg_addr_r1_shift.58"
  %"stg_addr_memaddr_offset_add.57" = add i64 %"stg_addr_packed_1.58", 8376
  %"R203:R200_addr_ptr.46" = inttoptr i64 %"stg_addr_memaddr_offset_add.57" to i32 addrspace(1)*
  store i32 %".591", i32 addrspace(1)* %"R203:R200_addr_ptr.46"
  %"stg_addr_r0_ext.59" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.59" = or i64 0, %"stg_addr_r0_ext.59"
  %"stg_addr_r1_ext.59" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.59" = shl i64 %"stg_addr_r1_ext.59", 32
  %"stg_addr_packed_1.59" = or i64 %"stg_addr_packed_0.59", %"stg_addr_r1_shift.59"
  %"stg_addr_memaddr_offset_add.58" = add i64 %"stg_addr_packed_1.59", 8380
  %"R203:R200_addr_ptr.47" = inttoptr i64 %"stg_addr_memaddr_offset_add.58" to i32 addrspace(1)*
  store i32 %".592", i32 addrspace(1)* %"R203:R200_addr_ptr.47"
  %"ldtm_addr_memaddr_offset_add.14" = add i32 %"imad.11", 52
  %"ldtm.16" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.14")
  %".605" = extractvalue {i32, i32, i32, i32} %"ldtm.16", 0
  %".606" = extractvalue {i32, i32, i32, i32} %"ldtm.16", 1
  %".607" = extractvalue {i32, i32, i32, i32} %"ldtm.16", 2
  %".608" = extractvalue {i32, i32, i32, i32} %"ldtm.16", 3
  %"stg_addr_r0_ext.60" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.60" = or i64 0, %"stg_addr_r0_ext.60"
  %"stg_addr_r1_ext.60" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.60" = shl i64 %"stg_addr_r1_ext.60", 32
  %"stg_addr_packed_1.60" = or i64 %"stg_addr_packed_0.60", %"stg_addr_r1_shift.60"
  %"stg_addr_memaddr_offset_add.59" = add i64 %"stg_addr_packed_1.60", 8384
  %"R203:R200_addr_ptr.48" = inttoptr i64 %"stg_addr_memaddr_offset_add.59" to i32 addrspace(1)*
  store i32 %".598", i32 addrspace(1)* %"R203:R200_addr_ptr.48"
  %"stg_addr_r0_ext.61" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.61" = or i64 0, %"stg_addr_r0_ext.61"
  %"stg_addr_r1_ext.61" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.61" = shl i64 %"stg_addr_r1_ext.61", 32
  %"stg_addr_packed_1.61" = or i64 %"stg_addr_packed_0.61", %"stg_addr_r1_shift.61"
  %"stg_addr_memaddr_offset_add.60" = add i64 %"stg_addr_packed_1.61", 8388
  %"R203:R200_addr_ptr.49" = inttoptr i64 %"stg_addr_memaddr_offset_add.60" to i32 addrspace(1)*
  store i32 %".599", i32 addrspace(1)* %"R203:R200_addr_ptr.49"
  %"stg_addr_r0_ext.62" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.62" = or i64 0, %"stg_addr_r0_ext.62"
  %"stg_addr_r1_ext.62" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.62" = shl i64 %"stg_addr_r1_ext.62", 32
  %"stg_addr_packed_1.62" = or i64 %"stg_addr_packed_0.62", %"stg_addr_r1_shift.62"
  %"stg_addr_memaddr_offset_add.61" = add i64 %"stg_addr_packed_1.62", 8392
  %"R203:R200_addr_ptr.50" = inttoptr i64 %"stg_addr_memaddr_offset_add.61" to i32 addrspace(1)*
  store i32 %".600", i32 addrspace(1)* %"R203:R200_addr_ptr.50"
  %"stg_addr_r0_ext.63" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.63" = or i64 0, %"stg_addr_r0_ext.63"
  %"stg_addr_r1_ext.63" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.63" = shl i64 %"stg_addr_r1_ext.63", 32
  %"stg_addr_packed_1.63" = or i64 %"stg_addr_packed_0.63", %"stg_addr_r1_shift.63"
  %"stg_addr_memaddr_offset_add.62" = add i64 %"stg_addr_packed_1.63", 8396
  %"R203:R200_addr_ptr.51" = inttoptr i64 %"stg_addr_memaddr_offset_add.62" to i32 addrspace(1)*
  store i32 %".601", i32 addrspace(1)* %"R203:R200_addr_ptr.51"
  %"stg_addr_r0_ext.64" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.64" = or i64 0, %"stg_addr_r0_ext.64"
  %"stg_addr_r1_ext.64" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.64" = shl i64 %"stg_addr_r1_ext.64", 32
  %"stg_addr_packed_1.64" = or i64 %"stg_addr_packed_0.64", %"stg_addr_r1_shift.64"
  %"stg_addr_memaddr_offset_add.63" = add i64 %"stg_addr_packed_1.64", 8400
  %"R203:R200_addr_ptr.52" = inttoptr i64 %"stg_addr_memaddr_offset_add.63" to i32 addrspace(1)*
  store i32 %".605", i32 addrspace(1)* %"R203:R200_addr_ptr.52"
  %"ldtm_addr_memaddr_offset_add.15" = add i32 %"imad.11", 56
  %"ldtm.17" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.15")
  %".614" = extractvalue {i32, i32, i32, i32} %"ldtm.17", 0
  %".615" = extractvalue {i32, i32, i32, i32} %"ldtm.17", 1
  %".616" = extractvalue {i32, i32, i32, i32} %"ldtm.17", 2
  %".617" = extractvalue {i32, i32, i32, i32} %"ldtm.17", 3
  %"stg_addr_r0_ext.65" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.65" = or i64 0, %"stg_addr_r0_ext.65"
  %"stg_addr_r1_ext.65" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.65" = shl i64 %"stg_addr_r1_ext.65", 32
  %"stg_addr_packed_1.65" = or i64 %"stg_addr_packed_0.65", %"stg_addr_r1_shift.65"
  %"stg_addr_memaddr_offset_add.64" = add i64 %"stg_addr_packed_1.65", 8404
  %"R203:R200_addr_ptr.53" = inttoptr i64 %"stg_addr_memaddr_offset_add.64" to i32 addrspace(1)*
  store i32 %".606", i32 addrspace(1)* %"R203:R200_addr_ptr.53"
  %"stg_addr_r0_ext.66" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.66" = or i64 0, %"stg_addr_r0_ext.66"
  %"stg_addr_r1_ext.66" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.66" = shl i64 %"stg_addr_r1_ext.66", 32
  %"stg_addr_packed_1.66" = or i64 %"stg_addr_packed_0.66", %"stg_addr_r1_shift.66"
  %"stg_addr_memaddr_offset_add.65" = add i64 %"stg_addr_packed_1.66", 8408
  %"R203:R200_addr_ptr.54" = inttoptr i64 %"stg_addr_memaddr_offset_add.65" to i32 addrspace(1)*
  store i32 %".607", i32 addrspace(1)* %"R203:R200_addr_ptr.54"
  %"stg_addr_r0_ext.67" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.67" = or i64 0, %"stg_addr_r0_ext.67"
  %"stg_addr_r1_ext.67" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.67" = shl i64 %"stg_addr_r1_ext.67", 32
  %"stg_addr_packed_1.67" = or i64 %"stg_addr_packed_0.67", %"stg_addr_r1_shift.67"
  %"stg_addr_memaddr_offset_add.66" = add i64 %"stg_addr_packed_1.67", 8412
  %"R203:R200_addr_ptr.55" = inttoptr i64 %"stg_addr_memaddr_offset_add.66" to i32 addrspace(1)*
  store i32 %".608", i32 addrspace(1)* %"R203:R200_addr_ptr.55"
  %"ldtm_addr_memaddr_offset_add.16" = add i32 %"imad.11", 60
  %"ldtm.18" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.16")
  %".621" = extractvalue {i32, i32, i32, i32} %"ldtm.18", 0
  %".622" = extractvalue {i32, i32, i32, i32} %"ldtm.18", 1
  %".623" = extractvalue {i32, i32, i32, i32} %"ldtm.18", 2
  %".624" = extractvalue {i32, i32, i32, i32} %"ldtm.18", 3
  %"stg_addr_r0_ext.68" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.68" = or i64 0, %"stg_addr_r0_ext.68"
  %"stg_addr_r1_ext.68" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.68" = shl i64 %"stg_addr_r1_ext.68", 32
  %"stg_addr_packed_1.68" = or i64 %"stg_addr_packed_0.68", %"stg_addr_r1_shift.68"
  %"stg_addr_memaddr_offset_add.67" = add i64 %"stg_addr_packed_1.68", 8416
  %"R203:R200_addr_ptr.56" = inttoptr i64 %"stg_addr_memaddr_offset_add.67" to i32 addrspace(1)*
  store i32 %".614", i32 addrspace(1)* %"R203:R200_addr_ptr.56"
  %"stg_addr_r0_ext.69" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.69" = or i64 0, %"stg_addr_r0_ext.69"
  %"stg_addr_r1_ext.69" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.69" = shl i64 %"stg_addr_r1_ext.69", 32
  %"stg_addr_packed_1.69" = or i64 %"stg_addr_packed_0.69", %"stg_addr_r1_shift.69"
  %"stg_addr_memaddr_offset_add.68" = add i64 %"stg_addr_packed_1.69", 8420
  %"R203:R200_addr_ptr.57" = inttoptr i64 %"stg_addr_memaddr_offset_add.68" to i32 addrspace(1)*
  store i32 %".615", i32 addrspace(1)* %"R203:R200_addr_ptr.57"
  %"stg_addr_r0_ext.70" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.70" = or i64 0, %"stg_addr_r0_ext.70"
  %"stg_addr_r1_ext.70" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.70" = shl i64 %"stg_addr_r1_ext.70", 32
  %"stg_addr_packed_1.70" = or i64 %"stg_addr_packed_0.70", %"stg_addr_r1_shift.70"
  %"stg_addr_memaddr_offset_add.69" = add i64 %"stg_addr_packed_1.70", 8424
  %"R203:R200_addr_ptr.58" = inttoptr i64 %"stg_addr_memaddr_offset_add.69" to i32 addrspace(1)*
  store i32 %".616", i32 addrspace(1)* %"R203:R200_addr_ptr.58"
  %"stg_addr_r0_ext.71" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.71" = or i64 0, %"stg_addr_r0_ext.71"
  %"stg_addr_r1_ext.71" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.71" = shl i64 %"stg_addr_r1_ext.71", 32
  %"stg_addr_packed_1.71" = or i64 %"stg_addr_packed_0.71", %"stg_addr_r1_shift.71"
  %"stg_addr_memaddr_offset_add.70" = add i64 %"stg_addr_packed_1.71", 8428
  %"R203:R200_addr_ptr.59" = inttoptr i64 %"stg_addr_memaddr_offset_add.70" to i32 addrspace(1)*
  store i32 %".617", i32 addrspace(1)* %"R203:R200_addr_ptr.59"
  %"stg_addr_r0_ext.72" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.72" = or i64 0, %"stg_addr_r0_ext.72"
  %"stg_addr_r1_ext.72" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.72" = shl i64 %"stg_addr_r1_ext.72", 32
  %"stg_addr_packed_1.72" = or i64 %"stg_addr_packed_0.72", %"stg_addr_r1_shift.72"
  %"stg_addr_memaddr_offset_add.71" = add i64 %"stg_addr_packed_1.72", 8432
  %"R203:R200_addr_ptr.60" = inttoptr i64 %"stg_addr_memaddr_offset_add.71" to i32 addrspace(1)*
  store i32 %".621", i32 addrspace(1)* %"R203:R200_addr_ptr.60"
  %"stg_addr_r0_ext.73" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.73" = or i64 0, %"stg_addr_r0_ext.73"
  %"stg_addr_r1_ext.73" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.73" = shl i64 %"stg_addr_r1_ext.73", 32
  %"stg_addr_packed_1.73" = or i64 %"stg_addr_packed_0.73", %"stg_addr_r1_shift.73"
  %"stg_addr_memaddr_offset_add.72" = add i64 %"stg_addr_packed_1.73", 8436
  %"R203:R200_addr_ptr.61" = inttoptr i64 %"stg_addr_memaddr_offset_add.72" to i32 addrspace(1)*
  store i32 %".622", i32 addrspace(1)* %"R203:R200_addr_ptr.61"
  %"stg_addr_r0_ext.74" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.74" = or i64 0, %"stg_addr_r0_ext.74"
  %"stg_addr_r1_ext.74" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.74" = shl i64 %"stg_addr_r1_ext.74", 32
  %"stg_addr_packed_1.74" = or i64 %"stg_addr_packed_0.74", %"stg_addr_r1_shift.74"
  %"stg_addr_memaddr_offset_add.73" = add i64 %"stg_addr_packed_1.74", 8440
  %"R203:R200_addr_ptr.62" = inttoptr i64 %"stg_addr_memaddr_offset_add.73" to i32 addrspace(1)*
  store i32 %".623", i32 addrspace(1)* %"R203:R200_addr_ptr.62"
  %"stg_addr_r0_ext.75" = zext i32 %"R19:R18_r0.1" to i64
  %"stg_addr_packed_0.75" = or i64 0, %"stg_addr_r0_ext.75"
  %"stg_addr_r1_ext.75" = zext i32 %"R19:R18_r1.1" to i64
  %"stg_addr_r1_shift.75" = shl i64 %"stg_addr_r1_ext.75", 32
  %"stg_addr_packed_1.75" = or i64 %"stg_addr_packed_0.75", %"stg_addr_r1_shift.75"
  %"stg_addr_memaddr_offset_add.74" = add i64 %"stg_addr_packed_1.75", 8444
  %"R203:R200_addr_ptr.63" = inttoptr i64 %"stg_addr_memaddr_offset_add.74" to i32 addrspace(1)*
  store i32 %".624", i32 addrspace(1)* %"R203:R200_addr_ptr.63"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_13c0"
BB_13c0:
  %"cond_trunc.33" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_800013c0", label %"BB_13d0"
BB_13d0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".33", 8192
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".635" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".635" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.15", 15
  %".636" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".637" = zext i32 64 to i64
  %".638" = zext i32 24 to i64
  %".639" = shl i64 %".636", %".638"
  %".640" = and i64 %".639", 4294967295
  %".641" = add i64 %".640", %".637"
  %".642" = trunc i64 %".641" to i32
  %"lds_addr_memaddr_offset_add.5" = add i32 %".642", 20
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".643" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".643" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".644" = xor i32 %"lds.4", -1
  %".645" = xor i32 65535, -1
  %".646" = xor i32 0, -1
  %".647" = and i32 %"lds.4", 65535
  %".648" = and i32 %".647", %".646"
  %".649" = and i32 %"lds.4", 65535
  %".650" = and i32 %".649", 0
  %".651" = or i32 %".648", %".650"
  %".652" = zext i32 0 to i64
  %".653" = zext i32 %".651" to i64
  %".654" = shl i64 %".653", 32
  %"shf_concat.8" = or i64 %".652", %".654"
  %"shf_shift_64.8" = zext i32 5 to i64
  %".655" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".655", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".656" = zext i32 %"imad.17" to i64
  %".657" = zext i32 0 to i64
  %".658" = shl i64 %".657", 32
  %"shf_concat.9" = or i64 %".656", %".658"
  %"shf_shift_64.9" = zext i32 %"shf_result.8" to i64
  %".659" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".659" to i32
  %".660" = xor i32 %"lds.5", -1
  %".661" = xor i32 %"shf_result.9", -1
  %".662" = xor i32 0, -1
  %".663" = and i32 %"lds.5", %"shf_result.9"
  %".664" = and i32 %".663", %".662"
  %".665" = and i32 %"lds.5", %"shf_result.9"
  %".666" = and i32 %".665", 0
  %".667" = or i32 %".664", %".666"
  %"isetrp_cmp1.6" = icmp ne i32 %".667", %"shf_result.9"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.16", 1
  %".668" = zext i32 %"imad.18" to i64
  %".669" = zext i32 0 to i64
  %".670" = shl i64 %".669", 32
  %"shf_concat.10" = or i64 %".668", %".670"
  %"shf_shift_64.10" = zext i32 %"shf_result.8" to i64
  %".671" = shl i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_result.10" = trunc i64 %".671" to i32
  br label %"BB_14a0"
BB_14a0:
  %"cond_trunc.34" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_1630_16f0", label %"BB_14b0"
BB_14b0:
  %"lds_addr_memaddr_offset_add.6" = add i32 %".642", 24
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".674" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".674" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %".675" = xor i32 %"lds.6", -1
  %".676" = xor i32 %"shf_result.10", -1
  %".677" = xor i32 0, -1
  %".678" = and i32 %"lds.6", %"shf_result.10"
  %".679" = and i32 %".678", %".677"
  %".680" = and i32 %"lds.6", %"shf_result.10"
  %".681" = and i32 %".680", 0
  %".682" = or i32 %".679", %".681"
  %"isetrp_cmp1.7" = icmp ne i32 %".682", %"shf_result.10"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  br label %"BB_14e0"
BB_14e0:
  %"cond_trunc.35" = trunc i32 %"P45_to_i32" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_1600_16c0", label %"BB_14f0"
BB_14f0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".685" = xor i32 0, -1
  %".686" = xor i32 %"shf_result.10", -1
  %".687" = xor i32 0, -1
  %".688" = and i32 %".685", %".686"
  %".689" = and i32 %".688", %".687"
  %".690" = and i32 %".685", %".686"
  %".691" = and i32 %".690", 0
  %".692" = or i32 %".689", %".691"
  %".693" = and i32 0, %".686"
  %".694" = and i32 %".693", %".687"
  %".695" = or i32 %".692", %".694"
  %".696" = and i32 0, %".686"
  %".697" = and i32 %".696", 0
  %".698" = or i32 %".695", %".697"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".698", i32 %"redux_mask")
  %".699" = xor i32 0, -1
  %".700" = xor i32 %"shf_result.9", -1
  %".701" = xor i32 0, -1
  %".702" = and i32 %".699", %".700"
  %".703" = and i32 %".702", %".701"
  %".704" = and i32 %".699", %".700"
  %".705" = and i32 %".704", 0
  %".706" = or i32 %".703", %".705"
  %".707" = and i32 0, %".700"
  %".708" = and i32 %".707", %".701"
  %".709" = or i32 %".706", %".708"
  %".710" = and i32 0, %".700"
  %".711" = and i32 %".710", 0
  %".712" = or i32 %".709", %".711"
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.17", %".712"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.19", i32 %"redux_mask.1")
  %".713" = xor i32 %".712", -1
  %".714" = call i32 @"llvm.cttz.i32"(i32 %".713", i1 0)
  %".715" = shl i32 %".714", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".715") convergent
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.18", %"redux_sync_and"
  %"isetrp_cmp1.8" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.19", %"redux_sync_and.1"
  br label %"BB_15c0"
BB_15c0:
  %"cond_trunc.36" = trunc i32 %"P56_to_i32" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_800015c0", label %"BB_1640"
BB_800015c0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".642", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".719" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".719" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.21" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".642", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".720" = getelementptr inbounds [9232 x i8], [9232 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".720" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.20" monotonic
  br label %"BB_1640"
BB_1600_16c0:
  call void @"llvm.trap"()
  br label %"BB_1640"
BB_1630_16f0:
  call void @"llvm.trap"()
  br label %"BB_1640"
BB_1640:
  ret void
BB_800013c0:
  ret void
}

@"const_mem" = global [5 x [908 x i8]] [[908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare void @"llvm.nvvm.bar.warp.sync"(i32 %".1")

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i32)* @"_Z10column_opsPjj", !"kernel", i32 1 }
