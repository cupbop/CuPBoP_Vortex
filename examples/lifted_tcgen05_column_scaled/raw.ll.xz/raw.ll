; ModuleID = "tcgen05_column_scaled_cuda13"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [10256 x i8], align 16
define void @"_Z13column_scaledIL4Case6EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P4_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.1" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.2" = phi  i32 [%"R5:R4_r0", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R5:R4_r1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R120:R100_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R120:R100_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi", 128
  %"iadd3_o1_64" = zext i32 %"phi.2" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi.3"
  %"imad_cin_trunc" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R5:R4_r1"
  %"imad_cin_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R55:R80_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R55:R80_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P4_to_i32", %"BB_01b0"], [%"P10_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P29_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P21_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P22_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P14_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P24_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P14_to_i32", %"BB_04a0"], [%"P14_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 10
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R65:R56_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R65:R56_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R65:R56_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R65:R56_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R65:R56_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R65:R56_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R65:R56_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R65:R56_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.7"
  %"ldg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.10", 9248
  %"R65:R56_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.11", 9252
  %"R65:R56_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R65:R56_addr_ptr.9"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".110" = xor i32 %"imad.10", -1
  %".111" = xor i32 65011712, -1
  %".112" = xor i32 0, -1
  %".113" = and i32 %"imad.10", 65011712
  %".114" = and i32 %".113", %".112"
  %".115" = and i32 %"imad.10", 65011712
  %".116" = and i32 %".115", 0
  %".117" = or i32 %".114", %".116"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".117"
  %"R7:R6_r0" = trunc i64 0 to i32
  %"R7:R6_r1_shift" = lshr i64 0, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.11", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.10", i32 %"ldg.11", i32 %"R7:R6_r0", i32 %"R7:R6_r1")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_08e0", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".125" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".125" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".126" = xor i32 %"plop3_a_bit", 1
  %".127" = xor i32 %"plop3_b_bit", 1
  %".128" = xor i32 %"plop3_c_bit", 1
  %".129" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".130" = and i32 %".129", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".130", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".131" = zext i32 0 to i64
  %".132" = zext i32 %".18" to i64
  %".133" = shl i64 %".132", 32
  %"shf_concat.3" = or i64 %".131", %".133"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".134" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".134", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".135" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".136" = zext i32 %"iadd3_n2.3" to i64
  %".137" = zext i32 24 to i64
  %".138" = shl i64 %".135", %".137"
  %".139" = and i64 %".138", 4294967295
  %".140" = add i64 %".139", %".136"
  %".141" = trunc i64 %".140" to i32
  %".142" = xor i32 %"shf_result.3", -1
  %".143" = xor i32 16376, -1
  %".144" = xor i32 0, -1
  %".145" = and i32 %"shf_result.3", 16376
  %".146" = and i32 %".145", %".144"
  %".147" = and i32 %"shf_result.3", 16376
  %".148" = and i32 %".147", 0
  %".149" = or i32 %".146", %".148"
  %".150" = zext i32 0 to i64
  %".151" = zext i32 %".141" to i64
  %".152" = shl i64 %".151", 32
  %"shf_concat.4" = or i64 %".150", %".152"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".153" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".153", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".154" = xor i32 %".149", -1
  %".155" = xor i32 524288, -1
  %".156" = xor i32 0, -1
  %".157" = and i32 %".154", 524288
  %".158" = and i32 %".157", %".156"
  %".159" = and i32 %".154", 524288
  %".160" = and i32 %".159", 0
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %".149", %".155"
  %".163" = and i32 %".162", %".156"
  %".164" = or i32 %".161", %".163"
  %".165" = and i32 %".149", %".155"
  %".166" = and i32 %".165", 0
  %".167" = or i32 %".164", %".166"
  %".168" = and i32 %".149", 524288
  %".169" = and i32 %".168", %".156"
  %".170" = or i32 %".167", %".169"
  %".171" = and i32 %".149", 524288
  %".172" = and i32 %".171", 0
  %".173" = or i32 %".170", %".172"
  %".174" = xor i32 %"shf_result.4", -1
  %".175" = xor i32 16376, -1
  %".176" = xor i32 0, -1
  %".177" = and i32 %"shf_result.4", 16376
  %".178" = and i32 %".177", %".176"
  %".179" = and i32 %"shf_result.4", 16376
  %".180" = and i32 %".179", 0
  %".181" = or i32 %".178", %".180"
  %".182" = xor i32 %".181", -1
  %".183" = xor i32 524288, -1
  %".184" = xor i32 0, -1
  %".185" = and i32 %".182", 524288
  %".186" = and i32 %".185", %".184"
  %".187" = and i32 %".182", 524288
  %".188" = and i32 %".187", 0
  %".189" = or i32 %".186", %".188"
  %".190" = and i32 %".181", %".183"
  %".191" = and i32 %".190", %".184"
  %".192" = or i32 %".189", %".191"
  %".193" = and i32 %".181", %".183"
  %".194" = and i32 %".193", 0
  %".195" = or i32 %".192", %".194"
  %".196" = and i32 %".181", 524288
  %".197" = and i32 %".196", %".184"
  %".198" = or i32 %".195", %".197"
  %".199" = and i32 %".181", 524288
  %".200" = and i32 %".199", 0
  %".201" = or i32 %".198", %".200"
  %"iadd3_n1.4" = add i32 %"lds.1", 24
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.1", 16
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.1", 20
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  br label %"BB_0810"
BB_0810:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_0700"], [%"P20_to_i32", %"BB_0840"]
  %"phi.15" = phi  i32 [%"P30_to_i32", %"BB_0700"], [%"phi.17", %"BB_0840"]
  %"cond_trunc.8" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000810", label %"BB_0820"
BB_80000810:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0820"
BB_0820:
  %"phi.16" = phi  i32 [%"P17_to_i32", %"BB_80000810"], [%"phi.14", %"BB_0810"]
  %"mma_a_r0_ext" = zext i32 %".173" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".205" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".206" = sub i64 %".205", 0
  %".207" = lshr i64 %".206", 4
  %".208" = add i64 %"mma_a_packed_1", %".207"
  %".209" = and i64 %".208", 16383
  %".210" = and i64 %"mma_a_packed_1", -16384
  %".211" = or i64 %".210", %".209"
  %"mma_b_r0_ext" = zext i32 %".201" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16416 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".212" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".213" = sub i64 %".212", 0
  %".214" = lshr i64 %".213", 4
  %".215" = add i64 %"mma_b_packed_1", %".214"
  %".216" = and i64 %".215", 16383
  %".217" = and i64 %"mma_b_packed_1", -16384
  %".218" = or i64 %".217", %".216"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.sp.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], $1, $2, [$5], $3, [$6], [$7], use_d; } }", "r,l,l,r,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".211", i64 %".218", i32 134481028, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5", i32 %"iadd3_n2.6")
  br label %"BB_0830"
BB_0830:
  %"cond_trunc.9" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000830", label %"BB_0840"
BB_80000830:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".222" = xor i32 %"plop3_a_bit.1", 1
  %".223" = xor i32 %"plop3_b_bit.1", 1
  %".224" = xor i32 %"plop3_c_bit.1", 1
  %".225" = and i32 %".222", %"plop3_b_bit.1"
  %".226" = and i32 %".225", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".226", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0840"
BB_0840:
  %"phi.17" = phi  i32 [%"P1_to_i32", %"BB_80000830"], [%"phi.15", %"BB_0830"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".228" = xor i32 %"plop3_a_bit.2", 1
  %".229" = xor i32 %"plop3_b_bit.2", 1
  %".230" = xor i32 %"plop3_c_bit.2", 1
  %".231" = and i32 %".228", %"plop3_b_bit.2"
  %".232" = and i32 %".231", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".232", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0810", label %"BB_0860"
BB_0860:
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".234" = xor i32 %"plop3_a_bit.3", 1
  %".235" = xor i32 %"plop3_b_bit.3", 1
  %".236" = xor i32 %"plop3_c_bit.3", 1
  %".237" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".238" = and i32 %".237", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".238", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".239" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".240" = zext i32 %"iadd3_n2.7" to i64
  %".241" = zext i32 24 to i64
  %".242" = shl i64 %".239", %".241"
  %".243" = and i64 %".242", 4294967295
  %".244" = add i64 %".243", %".240"
  %".245" = trunc i64 %".244" to i32
  br label %"BB_0890"
BB_0890:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_0860"], [%"P9_to_i32", %"BB_08c0"]
  %"phi.19" = phi  i32 [%"P23_to_i32", %"BB_0860"], [%"phi.21", %"BB_08c0"]
  %"cond_trunc.10" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P6_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.20" = phi  i32 [%"P6_to_i32", %"BB_80000890"], [%"phi.18", %"BB_0890"]
  %"utcbar_local_winoff" = and i32 %".245", 16777215
  %".249" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".250" = ptrtoint i8 addrspace(3)* %".249" to i32
  %".251" = lshr i32 %".245", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".250", i32 %".251")
  br label %"BB_08b0"
BB_08b0:
  %"cond_trunc.11" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_800008b0", label %"BB_08c0"
BB_800008b0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".255" = xor i32 %"plop3_a_bit.4", 1
  %".256" = xor i32 %"plop3_b_bit.4", 1
  %".257" = xor i32 %"plop3_c_bit.4", 1
  %".258" = and i32 %".255", %"plop3_b_bit.4"
  %".259" = and i32 %".258", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".259", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_08c0"
BB_08c0:
  %"phi.21" = phi  i32 [%"P2_to_i32", %"BB_800008b0"], [%"phi.19", %"BB_08b0"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".261" = xor i32 %"plop3_a_bit.5", 1
  %".262" = xor i32 %"plop3_b_bit.5", 1
  %".263" = xor i32 %"plop3_c_bit.5", 1
  %".264" = and i32 %".261", %"plop3_b_bit.5"
  %".265" = and i32 %".264", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".265", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0890", label %"BB_08e0"
BB_08e0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.8" = add i32 1024, 9216
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".267" = zext i32 0 to i64
  %".268" = zext i32 0 to i64
  %".269" = shl i64 %".268", 32
  %"shf_concat.5" = or i64 %".267", %".269"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".270" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".270" to i32
  %".271" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".272" = zext i32 %"iadd3_n2.8" to i64
  %".273" = zext i32 24 to i64
  %".274" = shl i64 %".271", %".273"
  %".275" = and i64 %".274", 4294967295
  %".276" = add i64 %".275", %".272"
  %".277" = trunc i64 %".276" to i32
  %"mbar_shared_winoff.1" = and i32 %".277", 16777215
  %".278" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".278" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P26_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0950"
BB_0950:
  %"cond_trunc.12" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0da0", label %"BB_0960"
BB_0da0:
  %"mbar_shared_winoff.2" = and i32 %".277", 16777215
  %".281" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".281" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P28_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0db0"
BB_0db0:
  %"cond_trunc.13" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0da0", label %"BB_0960"
BB_0960:
  %".284" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".285" = bitcast i8* %".284" to i64*
  %"ldc_const.1" = load i64, i64* %".285"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".286" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".287" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".288" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".289" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".290" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".291" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".292" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".293" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.3" = trunc i64 %"imad.13" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R67:R60_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".286", i32 addrspace(1)* %"R67:R60_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R67:R60_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".287", i32 addrspace(1)* %"R67:R60_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R67:R60_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".288", i32 addrspace(1)* %"R67:R60_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R67:R60_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".289", i32 addrspace(1)* %"R67:R60_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R67:R60_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".290", i32 addrspace(1)* %"R67:R60_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".299" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".300" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".301" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".302" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R67:R60_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".291", i32 addrspace(1)* %"R67:R60_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R67:R60_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".292", i32 addrspace(1)* %"R67:R60_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R67:R60_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".293", i32 addrspace(1)* %"R67:R60_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R67:R60_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".299", i32 addrspace(1)* %"R67:R60_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R67:R60_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".300", i32 addrspace(1)* %"R67:R60_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R67:R60_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".301", i32 addrspace(1)* %"R67:R60_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R67:R60_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".302", i32 addrspace(1)* %"R67:R60_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R67:R60_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R67:R60_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R67:R60_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R67:R60_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R67:R60_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R67:R60_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R67:R60_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R67:R60_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b50"
BB_0b50:
  %"cond_trunc.14" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000b50", label %"BB_0b60"
BB_0b60:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".320" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".320" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 1
  %".321" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".322" = zext i32 64 to i64
  %".323" = zext i32 24 to i64
  %".324" = shl i64 %".321", %".323"
  %".325" = and i64 %".324", 4294967295
  %".326" = add i64 %".325", %".322"
  %".327" = trunc i64 %".326" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".327", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".328" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".328" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".329" = xor i32 %"lds.2", -1
  %".330" = xor i32 65535, -1
  %".331" = xor i32 0, -1
  %".332" = and i32 %"lds.2", 65535
  %".333" = and i32 %".332", %".331"
  %".334" = and i32 %"lds.2", 65535
  %".335" = and i32 %".334", 0
  %".336" = or i32 %".333", %".335"
  %".337" = zext i32 0 to i64
  %".338" = zext i32 %".336" to i64
  %".339" = shl i64 %".338", 32
  %"shf_concat.6" = or i64 %".337", %".339"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".340" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".340", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".341" = zext i32 %"imad.14" to i64
  %".342" = zext i32 0 to i64
  %".343" = shl i64 %".342", 32
  %"shf_concat.7" = or i64 %".341", %".343"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".344" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".344" to i32
  %".345" = xor i32 %"lds.3", -1
  %".346" = xor i32 %"shf_result.7", -1
  %".347" = xor i32 0, -1
  %".348" = and i32 %"lds.3", %"shf_result.7"
  %".349" = and i32 %".348", %".347"
  %".350" = and i32 %"lds.3", %"shf_result.7"
  %".351" = and i32 %".350", 0
  %".352" = or i32 %".349", %".351"
  %"isetrp_cmp1.5" = icmp ne i32 %".352", %"shf_result.7"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0c10"
BB_0c10:
  %"cond_trunc.15" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0d70_0e00", label %"BB_0c20"
BB_0c20:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".327", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".355" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".355" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".356" = xor i32 %"lds.4", -1
  %".357" = xor i32 %"shf_result.7", -1
  %".358" = xor i32 0, -1
  %".359" = and i32 %"lds.4", %"shf_result.7"
  %".360" = and i32 %".359", %".358"
  %".361" = and i32 %"lds.4", %"shf_result.7"
  %".362" = and i32 %".361", 0
  %".363" = or i32 %".360", %".362"
  %"isetrp_cmp1.6" = icmp ne i32 %".363", %"shf_result.7"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0c50"
BB_0c50:
  %"cond_trunc.16" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0d40_0dd0", label %"BB_0c60"
BB_0c60:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".366" = xor i32 0, -1
  %".367" = xor i32 %"shf_result.7", -1
  %".368" = xor i32 0, -1
  %".369" = and i32 %".366", %".367"
  %".370" = and i32 %".369", %".368"
  %".371" = and i32 %".366", %".367"
  %".372" = and i32 %".371", 0
  %".373" = or i32 %".370", %".372"
  %".374" = and i32 0, %".367"
  %".375" = and i32 %".374", %".368"
  %".376" = or i32 %".373", %".375"
  %".377" = and i32 0, %".367"
  %".378" = and i32 %".377", 0
  %".379" = or i32 %".376", %".378"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %".379"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.15", i32 %"redux_mask")
  %".380" = xor i32 %".379", -1
  %".381" = call i32 @"llvm.cttz.i32"(i32 %".380", i1 0)
  %".382" = shl i32 %".381", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".382") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0d00"
BB_0d00:
  %"cond_trunc.17" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000d00", label %"BB_0d80"
BB_80000d00:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".327", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".386" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".386" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.16" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".327", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".387" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".387" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.16" monotonic
  br label %"BB_0d80"
BB_0d40_0dd0:
  call void @"llvm.trap"()
  br label %"BB_0d80"
BB_0d70_0e00:
  call void @"llvm.trap"()
  br label %"BB_0d80"
BB_0d80:
  ret void
BB_80000b50:
  ret void
}

define void @"_Z13column_scaledIL4Case5EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P4_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.1" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.2" = phi  i32 [%"R5:R4_r0", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R5:R4_r1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R107:R85_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R107:R85_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi", 128
  %"iadd3_o1_64" = zext i32 %"phi.2" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi.3"
  %"imad_cin_trunc" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R5:R4_r1"
  %"imad_cin_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R22:R67_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R22:R67_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P4_to_i32", %"BB_01b0"], [%"P10_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P29_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P21_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P22_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P14_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P24_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P14_to_i32", %"BB_04a0"], [%"P14_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 10
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R52:R42_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R52:R42_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R52:R42_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R52:R42_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R52:R42_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R52:R42_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R52:R42_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R52:R42_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".110" = xor i32 %"imad.10", -1
  %".111" = xor i32 65011712, -1
  %".112" = xor i32 0, -1
  %".113" = and i32 %"imad.10", 65011712
  %".114" = and i32 %".113", %".112"
  %".115" = and i32 %"imad.10", 65011712
  %".116" = and i32 %".115", 0
  %".117" = or i32 %".114", %".116"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".117"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0890", label %"BB_06b0"
BB_06b0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".124" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".124" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".125" = xor i32 %"plop3_a_bit", 1
  %".126" = xor i32 %"plop3_b_bit", 1
  %".127" = xor i32 %"plop3_c_bit", 1
  %".128" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".129" = and i32 %".128", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".129", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".18" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.3" = or i64 %".130", %".132"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".133", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 %"iadd3_n2.3" to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %".141" = xor i32 %"shf_result.3", -1
  %".142" = xor i32 16376, -1
  %".143" = xor i32 0, -1
  %".144" = and i32 %"shf_result.3", 16376
  %".145" = and i32 %".144", %".143"
  %".146" = and i32 %"shf_result.3", 16376
  %".147" = and i32 %".146", 0
  %".148" = or i32 %".145", %".147"
  %".149" = zext i32 0 to i64
  %".150" = zext i32 %".140" to i64
  %".151" = shl i64 %".150", 32
  %"shf_concat.4" = or i64 %".149", %".151"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".152" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".152", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".153" = xor i32 %".148", -1
  %".154" = xor i32 524288, -1
  %".155" = xor i32 0, -1
  %".156" = and i32 %".153", 524288
  %".157" = and i32 %".156", %".155"
  %".158" = and i32 %".153", 524288
  %".159" = and i32 %".158", 0
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %".148", %".154"
  %".162" = and i32 %".161", %".155"
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %".148", %".154"
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".148", 524288
  %".168" = and i32 %".167", %".155"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %".148", 524288
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %".173" = xor i32 %"shf_result.4", -1
  %".174" = xor i32 16376, -1
  %".175" = xor i32 0, -1
  %".176" = and i32 %"shf_result.4", 16376
  %".177" = and i32 %".176", %".175"
  %".178" = and i32 %"shf_result.4", 16376
  %".179" = and i32 %".178", 0
  %".180" = or i32 %".177", %".179"
  %".181" = xor i32 %".180", -1
  %".182" = xor i32 524288, -1
  %".183" = xor i32 0, -1
  %".184" = and i32 %".181", 524288
  %".185" = and i32 %".184", %".183"
  %".186" = and i32 %".181", 524288
  %".187" = and i32 %".186", 0
  %".188" = or i32 %".185", %".187"
  %".189" = and i32 %".180", %".182"
  %".190" = and i32 %".189", %".183"
  %".191" = or i32 %".188", %".190"
  %".192" = and i32 %".180", %".182"
  %".193" = and i32 %".192", 0
  %".194" = or i32 %".191", %".193"
  %".195" = and i32 %".180", 524288
  %".196" = and i32 %".195", %".183"
  %".197" = or i32 %".194", %".196"
  %".198" = and i32 %".180", 524288
  %".199" = and i32 %".198", 0
  %".200" = or i32 %".197", %".199"
  %"iadd3_n1.4" = add i32 %"lds.1", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.1", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_07c0"
BB_07c0:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_06b0"], [%"P20_to_i32", %"BB_07f0"]
  %"phi.15" = phi  i32 [%"P30_to_i32", %"BB_06b0"], [%"phi.17", %"BB_07f0"]
  %"cond_trunc.8" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_800007c0", label %"BB_07d0"
BB_800007c0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.16" = phi  i32 [%"P17_to_i32", %"BB_800007c0"], [%"phi.14", %"BB_07c0"]
  %"mma_a_r0_ext" = zext i32 %".172" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".204" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".205" = sub i64 %".204", 0
  %".206" = lshr i64 %".205", 4
  %".207" = add i64 %"mma_a_packed_1", %".206"
  %".208" = and i64 %".207", 16383
  %".209" = and i64 %"mma_a_packed_1", -16384
  %".210" = or i64 %".209", %".208"
  %"mma_b_r0_ext" = zext i32 %".200" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".211" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".212" = sub i64 %".211", 0
  %".213" = lshr i64 %".212", 4
  %".214" = add i64 %"mma_b_packed_1", %".213"
  %".215" = and i64 %".214", 16383
  %".216" = and i64 %"mma_b_packed_1", -16384
  %".217" = or i64 %".216", %".215"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".210", i64 %".217", i32 134481024, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_07e0"
BB_07e0:
  %"cond_trunc.9" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800007e0", label %"BB_07f0"
BB_800007e0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".221" = xor i32 %"plop3_a_bit.1", 1
  %".222" = xor i32 %"plop3_b_bit.1", 1
  %".223" = xor i32 %"plop3_c_bit.1", 1
  %".224" = and i32 %".221", %"plop3_b_bit.1"
  %".225" = and i32 %".224", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".225", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_07f0"
BB_07f0:
  %"phi.17" = phi  i32 [%"P1_to_i32", %"BB_800007e0"], [%"phi.15", %"BB_07e0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".227" = xor i32 %"plop3_a_bit.2", 1
  %".228" = xor i32 %"plop3_b_bit.2", 1
  %".229" = xor i32 %"plop3_c_bit.2", 1
  %".230" = and i32 %".227", %"plop3_b_bit.2"
  %".231" = and i32 %".230", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".231", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_07c0", label %"BB_0810"
BB_0810:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".233" = xor i32 %"plop3_a_bit.3", 1
  %".234" = xor i32 %"plop3_b_bit.3", 1
  %".235" = xor i32 %"plop3_c_bit.3", 1
  %".236" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".237" = and i32 %".236", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".237", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".238" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".239" = zext i32 %"iadd3_n2.6" to i64
  %".240" = zext i32 24 to i64
  %".241" = shl i64 %".238", %".240"
  %".242" = and i64 %".241", 4294967295
  %".243" = add i64 %".242", %".239"
  %".244" = trunc i64 %".243" to i32
  br label %"BB_0840"
BB_0840:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_0810"], [%"P9_to_i32", %"BB_0870"]
  %"phi.19" = phi  i32 [%"P23_to_i32", %"BB_0810"], [%"phi.21", %"BB_0870"]
  %"cond_trunc.10" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000840", label %"BB_0850"
BB_80000840:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P6_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0850"
BB_0850:
  %"phi.20" = phi  i32 [%"P6_to_i32", %"BB_80000840"], [%"phi.18", %"BB_0840"]
  %"utcbar_local_winoff" = and i32 %".244", 16777215
  %".248" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".249" = ptrtoint i8 addrspace(3)* %".248" to i32
  %".250" = lshr i32 %".244", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".249", i32 %".250")
  br label %"BB_0860"
BB_0860:
  %"cond_trunc.11" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000860", label %"BB_0870"
BB_80000860:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".254" = xor i32 %"plop3_a_bit.4", 1
  %".255" = xor i32 %"plop3_b_bit.4", 1
  %".256" = xor i32 %"plop3_c_bit.4", 1
  %".257" = and i32 %".254", %"plop3_b_bit.4"
  %".258" = and i32 %".257", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".258", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.21" = phi  i32 [%"P2_to_i32", %"BB_80000860"], [%"phi.19", %"BB_0860"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".260" = xor i32 %"plop3_a_bit.5", 1
  %".261" = xor i32 %"plop3_b_bit.5", 1
  %".262" = xor i32 %"plop3_c_bit.5", 1
  %".263" = and i32 %".260", %"plop3_b_bit.5"
  %".264" = and i32 %".263", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".264", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0840", label %"BB_0890"
BB_0890:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".266" = zext i32 0 to i64
  %".267" = zext i32 0 to i64
  %".268" = shl i64 %".267", 32
  %"shf_concat.5" = or i64 %".266", %".268"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".269" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".269" to i32
  %".270" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".271" = zext i32 %"iadd3_n2.7" to i64
  %".272" = zext i32 24 to i64
  %".273" = shl i64 %".270", %".272"
  %".274" = and i64 %".273", 4294967295
  %".275" = add i64 %".274", %".271"
  %".276" = trunc i64 %".275" to i32
  %"mbar_shared_winoff.1" = and i32 %".276", 16777215
  %".277" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".277" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P26_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0900"
BB_0900:
  %"cond_trunc.12" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0d50", label %"BB_0910"
BB_0d50:
  %"mbar_shared_winoff.2" = and i32 %".276", 16777215
  %".280" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".280" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P28_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0d60"
BB_0d60:
  %"cond_trunc.13" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0d50", label %"BB_0910"
BB_0910:
  %".283" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".284" = bitcast i8* %".283" to i64*
  %"ldc_const.1" = load i64, i64* %".284"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".285" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".286" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".287" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".288" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".289" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".290" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".291" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".292" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.3" = trunc i64 %"imad.13" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R54:R48_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".285", i32 addrspace(1)* %"R54:R48_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R54:R48_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".286", i32 addrspace(1)* %"R54:R48_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R54:R48_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".287", i32 addrspace(1)* %"R54:R48_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R54:R48_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".288", i32 addrspace(1)* %"R54:R48_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R54:R48_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".289", i32 addrspace(1)* %"R54:R48_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".299" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".300" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".301" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R54:R48_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".290", i32 addrspace(1)* %"R54:R48_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R54:R48_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".291", i32 addrspace(1)* %"R54:R48_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R54:R48_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".292", i32 addrspace(1)* %"R54:R48_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R54:R48_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R54:R48_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R54:R48_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".299", i32 addrspace(1)* %"R54:R48_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R54:R48_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".300", i32 addrspace(1)* %"R54:R48_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R54:R48_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".301", i32 addrspace(1)* %"R54:R48_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R54:R48_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R54:R48_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R54:R48_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R54:R48_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R54:R48_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R54:R48_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R54:R48_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R54:R48_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.14" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000b00", label %"BB_0b10"
BB_0b10:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".319" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".319" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 1
  %".320" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".321" = zext i32 64 to i64
  %".322" = zext i32 24 to i64
  %".323" = shl i64 %".320", %".322"
  %".324" = and i64 %".323", 4294967295
  %".325" = add i64 %".324", %".321"
  %".326" = trunc i64 %".325" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".326", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".327" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".327" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".328" = xor i32 %"lds.2", -1
  %".329" = xor i32 65535, -1
  %".330" = xor i32 0, -1
  %".331" = and i32 %"lds.2", 65535
  %".332" = and i32 %".331", %".330"
  %".333" = and i32 %"lds.2", 65535
  %".334" = and i32 %".333", 0
  %".335" = or i32 %".332", %".334"
  %".336" = zext i32 0 to i64
  %".337" = zext i32 %".335" to i64
  %".338" = shl i64 %".337", 32
  %"shf_concat.6" = or i64 %".336", %".338"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".339" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".339", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".340" = zext i32 %"imad.14" to i64
  %".341" = zext i32 0 to i64
  %".342" = shl i64 %".341", 32
  %"shf_concat.7" = or i64 %".340", %".342"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".343" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".343" to i32
  %".344" = xor i32 %"lds.3", -1
  %".345" = xor i32 %"shf_result.7", -1
  %".346" = xor i32 0, -1
  %".347" = and i32 %"lds.3", %"shf_result.7"
  %".348" = and i32 %".347", %".346"
  %".349" = and i32 %"lds.3", %"shf_result.7"
  %".350" = and i32 %".349", 0
  %".351" = or i32 %".348", %".350"
  %"isetrp_cmp1.5" = icmp ne i32 %".351", %"shf_result.7"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"cond_trunc.15" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0d20_0db0", label %"BB_0bd0"
BB_0bd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".326", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".354" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".354" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".355" = xor i32 %"lds.4", -1
  %".356" = xor i32 %"shf_result.7", -1
  %".357" = xor i32 0, -1
  %".358" = and i32 %"lds.4", %"shf_result.7"
  %".359" = and i32 %".358", %".357"
  %".360" = and i32 %"lds.4", %"shf_result.7"
  %".361" = and i32 %".360", 0
  %".362" = or i32 %".359", %".361"
  %"isetrp_cmp1.6" = icmp ne i32 %".362", %"shf_result.7"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0c00"
BB_0c00:
  %"cond_trunc.16" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0cf0_0d80", label %"BB_0c10"
BB_0c10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".365" = xor i32 0, -1
  %".366" = xor i32 %"shf_result.7", -1
  %".367" = xor i32 0, -1
  %".368" = and i32 %".365", %".366"
  %".369" = and i32 %".368", %".367"
  %".370" = and i32 %".365", %".366"
  %".371" = and i32 %".370", 0
  %".372" = or i32 %".369", %".371"
  %".373" = and i32 0, %".366"
  %".374" = and i32 %".373", %".367"
  %".375" = or i32 %".372", %".374"
  %".376" = and i32 0, %".366"
  %".377" = and i32 %".376", 0
  %".378" = or i32 %".375", %".377"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %".378"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.15", i32 %"redux_mask")
  %".379" = xor i32 %".378", -1
  %".380" = call i32 @"llvm.cttz.i32"(i32 %".379", i1 0)
  %".381" = shl i32 %".380", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".381") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.17" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000cb0", label %"BB_0d30"
BB_80000cb0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".326", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".385" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".385" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.16" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".326", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".386" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".386" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.16" monotonic
  br label %"BB_0d30"
BB_0cf0_0d80:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d20_0db0:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d30:
  ret void
BB_80000b00:
  ret void
}

define void @"_Z13column_scaledIL4Case4EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P4_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.1" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.2" = phi  i32 [%"R5:R4_r0", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R5:R4_r1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R107:R85_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R107:R85_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi", 128
  %"iadd3_o1_64" = zext i32 %"phi.2" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi.3"
  %"imad_cin_trunc" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R5:R4_r1"
  %"imad_cin_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R22:R67_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R22:R67_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P4_to_i32", %"BB_01b0"], [%"P10_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P29_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P21_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P22_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P14_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P24_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P14_to_i32", %"BB_04a0"], [%"P14_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 10
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R52:R42_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R52:R42_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R52:R42_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R52:R42_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R52:R42_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R52:R42_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R52:R42_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R52:R42_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".110" = xor i32 %"imad.10", -1
  %".111" = xor i32 65011712, -1
  %".112" = xor i32 0, -1
  %".113" = and i32 %"imad.10", 65011712
  %".114" = and i32 %".113", %".112"
  %".115" = and i32 %"imad.10", 65011712
  %".116" = and i32 %".115", 0
  %".117" = or i32 %".114", %".116"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".117"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0890", label %"BB_06b0"
BB_06b0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".124" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".124" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".125" = xor i32 %"plop3_a_bit", 1
  %".126" = xor i32 %"plop3_b_bit", 1
  %".127" = xor i32 %"plop3_c_bit", 1
  %".128" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".129" = and i32 %".128", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".129", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".18" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.3" = or i64 %".130", %".132"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".133", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 %"iadd3_n2.3" to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %".141" = xor i32 %"shf_result.3", -1
  %".142" = xor i32 16376, -1
  %".143" = xor i32 0, -1
  %".144" = and i32 %"shf_result.3", 16376
  %".145" = and i32 %".144", %".143"
  %".146" = and i32 %"shf_result.3", 16376
  %".147" = and i32 %".146", 0
  %".148" = or i32 %".145", %".147"
  %".149" = zext i32 0 to i64
  %".150" = zext i32 %".140" to i64
  %".151" = shl i64 %".150", 32
  %"shf_concat.4" = or i64 %".149", %".151"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".152" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".152", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".153" = xor i32 %".148", -1
  %".154" = xor i32 524288, -1
  %".155" = xor i32 0, -1
  %".156" = and i32 %".153", 524288
  %".157" = and i32 %".156", %".155"
  %".158" = and i32 %".153", 524288
  %".159" = and i32 %".158", 0
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %".148", %".154"
  %".162" = and i32 %".161", %".155"
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %".148", %".154"
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".148", 524288
  %".168" = and i32 %".167", %".155"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %".148", 524288
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %".173" = xor i32 %"shf_result.4", -1
  %".174" = xor i32 16376, -1
  %".175" = xor i32 0, -1
  %".176" = and i32 %"shf_result.4", 16376
  %".177" = and i32 %".176", %".175"
  %".178" = and i32 %"shf_result.4", 16376
  %".179" = and i32 %".178", 0
  %".180" = or i32 %".177", %".179"
  %".181" = xor i32 %".180", -1
  %".182" = xor i32 524288, -1
  %".183" = xor i32 0, -1
  %".184" = and i32 %".181", 524288
  %".185" = and i32 %".184", %".183"
  %".186" = and i32 %".181", 524288
  %".187" = and i32 %".186", 0
  %".188" = or i32 %".185", %".187"
  %".189" = and i32 %".180", %".182"
  %".190" = and i32 %".189", %".183"
  %".191" = or i32 %".188", %".190"
  %".192" = and i32 %".180", %".182"
  %".193" = and i32 %".192", 0
  %".194" = or i32 %".191", %".193"
  %".195" = and i32 %".180", 524288
  %".196" = and i32 %".195", %".183"
  %".197" = or i32 %".194", %".196"
  %".198" = and i32 %".180", 524288
  %".199" = and i32 %".198", 0
  %".200" = or i32 %".197", %".199"
  %"iadd3_n1.4" = add i32 %"lds.1", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.1", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_07c0"
BB_07c0:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_06b0"], [%"P20_to_i32", %"BB_07f0"]
  %"phi.15" = phi  i32 [%"P30_to_i32", %"BB_06b0"], [%"phi.17", %"BB_07f0"]
  %"cond_trunc.8" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_800007c0", label %"BB_07d0"
BB_800007c0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.16" = phi  i32 [%"P17_to_i32", %"BB_800007c0"], [%"phi.14", %"BB_07c0"]
  %"mma_a_r0_ext" = zext i32 %".172" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".204" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".205" = sub i64 %".204", 0
  %".206" = lshr i64 %".205", 4
  %".207" = add i64 %"mma_a_packed_1", %".206"
  %".208" = and i64 %".207", 16383
  %".209" = and i64 %"mma_a_packed_1", -16384
  %".210" = or i64 %".209", %".208"
  %"mma_b_r0_ext" = zext i32 %".200" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".211" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".212" = sub i64 %".211", 0
  %".213" = lshr i64 %".212", 4
  %".214" = add i64 %"mma_b_packed_1", %".213"
  %".215" = and i64 %".214", 16383
  %".216" = and i64 %"mma_b_packed_1", -16384
  %".217" = or i64 %".216", %".215"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::2X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".210", i64 %".217", i32 1216611456, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_07e0"
BB_07e0:
  %"cond_trunc.9" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800007e0", label %"BB_07f0"
BB_800007e0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".221" = xor i32 %"plop3_a_bit.1", 1
  %".222" = xor i32 %"plop3_b_bit.1", 1
  %".223" = xor i32 %"plop3_c_bit.1", 1
  %".224" = and i32 %".221", %"plop3_b_bit.1"
  %".225" = and i32 %".224", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".225", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_07f0"
BB_07f0:
  %"phi.17" = phi  i32 [%"P1_to_i32", %"BB_800007e0"], [%"phi.15", %"BB_07e0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".227" = xor i32 %"plop3_a_bit.2", 1
  %".228" = xor i32 %"plop3_b_bit.2", 1
  %".229" = xor i32 %"plop3_c_bit.2", 1
  %".230" = and i32 %".227", %"plop3_b_bit.2"
  %".231" = and i32 %".230", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".231", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_07c0", label %"BB_0810"
BB_0810:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".233" = xor i32 %"plop3_a_bit.3", 1
  %".234" = xor i32 %"plop3_b_bit.3", 1
  %".235" = xor i32 %"plop3_c_bit.3", 1
  %".236" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".237" = and i32 %".236", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".237", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".238" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".239" = zext i32 %"iadd3_n2.6" to i64
  %".240" = zext i32 24 to i64
  %".241" = shl i64 %".238", %".240"
  %".242" = and i64 %".241", 4294967295
  %".243" = add i64 %".242", %".239"
  %".244" = trunc i64 %".243" to i32
  br label %"BB_0840"
BB_0840:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_0810"], [%"P9_to_i32", %"BB_0870"]
  %"phi.19" = phi  i32 [%"P23_to_i32", %"BB_0810"], [%"phi.21", %"BB_0870"]
  %"cond_trunc.10" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000840", label %"BB_0850"
BB_80000840:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P6_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0850"
BB_0850:
  %"phi.20" = phi  i32 [%"P6_to_i32", %"BB_80000840"], [%"phi.18", %"BB_0840"]
  %"utcbar_local_winoff" = and i32 %".244", 16777215
  %".248" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".249" = ptrtoint i8 addrspace(3)* %".248" to i32
  %".250" = lshr i32 %".244", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".249", i32 %".250")
  br label %"BB_0860"
BB_0860:
  %"cond_trunc.11" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000860", label %"BB_0870"
BB_80000860:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".254" = xor i32 %"plop3_a_bit.4", 1
  %".255" = xor i32 %"plop3_b_bit.4", 1
  %".256" = xor i32 %"plop3_c_bit.4", 1
  %".257" = and i32 %".254", %"plop3_b_bit.4"
  %".258" = and i32 %".257", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".258", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.21" = phi  i32 [%"P2_to_i32", %"BB_80000860"], [%"phi.19", %"BB_0860"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".260" = xor i32 %"plop3_a_bit.5", 1
  %".261" = xor i32 %"plop3_b_bit.5", 1
  %".262" = xor i32 %"plop3_c_bit.5", 1
  %".263" = and i32 %".260", %"plop3_b_bit.5"
  %".264" = and i32 %".263", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".264", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0840", label %"BB_0890"
BB_0890:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".266" = zext i32 0 to i64
  %".267" = zext i32 0 to i64
  %".268" = shl i64 %".267", 32
  %"shf_concat.5" = or i64 %".266", %".268"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".269" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".269" to i32
  %".270" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".271" = zext i32 %"iadd3_n2.7" to i64
  %".272" = zext i32 24 to i64
  %".273" = shl i64 %".270", %".272"
  %".274" = and i64 %".273", 4294967295
  %".275" = add i64 %".274", %".271"
  %".276" = trunc i64 %".275" to i32
  %"mbar_shared_winoff.1" = and i32 %".276", 16777215
  %".277" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".277" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P26_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0900"
BB_0900:
  %"cond_trunc.12" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0d50", label %"BB_0910"
BB_0d50:
  %"mbar_shared_winoff.2" = and i32 %".276", 16777215
  %".280" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".280" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P28_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0d60"
BB_0d60:
  %"cond_trunc.13" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0d50", label %"BB_0910"
BB_0910:
  %".283" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".284" = bitcast i8* %".283" to i64*
  %"ldc_const.1" = load i64, i64* %".284"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".285" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".286" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".287" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".288" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".289" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".290" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".291" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".292" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.3" = trunc i64 %"imad.13" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R54:R48_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".285", i32 addrspace(1)* %"R54:R48_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R54:R48_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".286", i32 addrspace(1)* %"R54:R48_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R54:R48_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".287", i32 addrspace(1)* %"R54:R48_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R54:R48_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".288", i32 addrspace(1)* %"R54:R48_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R54:R48_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".289", i32 addrspace(1)* %"R54:R48_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".299" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".300" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".301" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R54:R48_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".290", i32 addrspace(1)* %"R54:R48_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R54:R48_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".291", i32 addrspace(1)* %"R54:R48_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R54:R48_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".292", i32 addrspace(1)* %"R54:R48_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R54:R48_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R54:R48_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R54:R48_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".299", i32 addrspace(1)* %"R54:R48_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R54:R48_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".300", i32 addrspace(1)* %"R54:R48_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R54:R48_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".301", i32 addrspace(1)* %"R54:R48_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R54:R48_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R54:R48_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R54:R48_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R54:R48_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R54:R48_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R54:R48_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R54:R48_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R54:R48_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.14" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000b00", label %"BB_0b10"
BB_0b10:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".319" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".319" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 1
  %".320" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".321" = zext i32 64 to i64
  %".322" = zext i32 24 to i64
  %".323" = shl i64 %".320", %".322"
  %".324" = and i64 %".323", 4294967295
  %".325" = add i64 %".324", %".321"
  %".326" = trunc i64 %".325" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".326", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".327" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".327" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".328" = xor i32 %"lds.2", -1
  %".329" = xor i32 65535, -1
  %".330" = xor i32 0, -1
  %".331" = and i32 %"lds.2", 65535
  %".332" = and i32 %".331", %".330"
  %".333" = and i32 %"lds.2", 65535
  %".334" = and i32 %".333", 0
  %".335" = or i32 %".332", %".334"
  %".336" = zext i32 0 to i64
  %".337" = zext i32 %".335" to i64
  %".338" = shl i64 %".337", 32
  %"shf_concat.6" = or i64 %".336", %".338"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".339" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".339", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".340" = zext i32 %"imad.14" to i64
  %".341" = zext i32 0 to i64
  %".342" = shl i64 %".341", 32
  %"shf_concat.7" = or i64 %".340", %".342"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".343" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".343" to i32
  %".344" = xor i32 %"lds.3", -1
  %".345" = xor i32 %"shf_result.7", -1
  %".346" = xor i32 0, -1
  %".347" = and i32 %"lds.3", %"shf_result.7"
  %".348" = and i32 %".347", %".346"
  %".349" = and i32 %"lds.3", %"shf_result.7"
  %".350" = and i32 %".349", 0
  %".351" = or i32 %".348", %".350"
  %"isetrp_cmp1.5" = icmp ne i32 %".351", %"shf_result.7"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"cond_trunc.15" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0d20_0db0", label %"BB_0bd0"
BB_0bd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".326", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".354" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".354" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".355" = xor i32 %"lds.4", -1
  %".356" = xor i32 %"shf_result.7", -1
  %".357" = xor i32 0, -1
  %".358" = and i32 %"lds.4", %"shf_result.7"
  %".359" = and i32 %".358", %".357"
  %".360" = and i32 %"lds.4", %"shf_result.7"
  %".361" = and i32 %".360", 0
  %".362" = or i32 %".359", %".361"
  %"isetrp_cmp1.6" = icmp ne i32 %".362", %"shf_result.7"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0c00"
BB_0c00:
  %"cond_trunc.16" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0cf0_0d80", label %"BB_0c10"
BB_0c10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".365" = xor i32 0, -1
  %".366" = xor i32 %"shf_result.7", -1
  %".367" = xor i32 0, -1
  %".368" = and i32 %".365", %".366"
  %".369" = and i32 %".368", %".367"
  %".370" = and i32 %".365", %".366"
  %".371" = and i32 %".370", 0
  %".372" = or i32 %".369", %".371"
  %".373" = and i32 0, %".366"
  %".374" = and i32 %".373", %".367"
  %".375" = or i32 %".372", %".374"
  %".376" = and i32 0, %".366"
  %".377" = and i32 %".376", 0
  %".378" = or i32 %".375", %".377"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %".378"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.15", i32 %"redux_mask")
  %".379" = xor i32 %".378", -1
  %".380" = call i32 @"llvm.cttz.i32"(i32 %".379", i1 0)
  %".381" = shl i32 %".380", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".381") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.17" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000cb0", label %"BB_0d30"
BB_80000cb0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".326", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".385" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".385" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.16" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".326", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".386" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".386" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.16" monotonic
  br label %"BB_0d30"
BB_0cf0_0d80:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d20_0db0:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d30:
  ret void
BB_80000b00:
  ret void
}

define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P4_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.1" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.2" = phi  i32 [%"R5:R4_r0", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R5:R4_r1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R107:R85_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R107:R85_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi", 128
  %"iadd3_o1_64" = zext i32 %"phi.2" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi.3"
  %"imad_cin_trunc" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R5:R4_r1"
  %"imad_cin_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R22:R67_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R22:R67_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P4_to_i32", %"BB_01b0"], [%"P10_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P29_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P21_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P22_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P14_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P24_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P14_to_i32", %"BB_04a0"], [%"P14_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 10
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R52:R42_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R52:R42_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R52:R42_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R52:R42_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R52:R42_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R52:R42_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R52:R42_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R52:R42_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".110" = xor i32 %"imad.10", -1
  %".111" = xor i32 65011712, -1
  %".112" = xor i32 0, -1
  %".113" = and i32 %"imad.10", 65011712
  %".114" = and i32 %".113", %".112"
  %".115" = and i32 %"imad.10", 65011712
  %".116" = and i32 %".115", 0
  %".117" = or i32 %".114", %".116"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".117"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0890", label %"BB_06b0"
BB_06b0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".124" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".124" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".125" = xor i32 %"plop3_a_bit", 1
  %".126" = xor i32 %"plop3_b_bit", 1
  %".127" = xor i32 %"plop3_c_bit", 1
  %".128" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".129" = and i32 %".128", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".129", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".18" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.3" = or i64 %".130", %".132"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".133", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 %"iadd3_n2.3" to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %".141" = xor i32 %"shf_result.3", -1
  %".142" = xor i32 16376, -1
  %".143" = xor i32 0, -1
  %".144" = and i32 %"shf_result.3", 16376
  %".145" = and i32 %".144", %".143"
  %".146" = and i32 %"shf_result.3", 16376
  %".147" = and i32 %".146", 0
  %".148" = or i32 %".145", %".147"
  %".149" = zext i32 0 to i64
  %".150" = zext i32 %".140" to i64
  %".151" = shl i64 %".150", 32
  %"shf_concat.4" = or i64 %".149", %".151"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".152" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".152", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".153" = xor i32 %".148", -1
  %".154" = xor i32 524288, -1
  %".155" = xor i32 0, -1
  %".156" = and i32 %".153", 524288
  %".157" = and i32 %".156", %".155"
  %".158" = and i32 %".153", 524288
  %".159" = and i32 %".158", 0
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %".148", %".154"
  %".162" = and i32 %".161", %".155"
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %".148", %".154"
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".148", 524288
  %".168" = and i32 %".167", %".155"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %".148", 524288
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %".173" = xor i32 %"shf_result.4", -1
  %".174" = xor i32 16376, -1
  %".175" = xor i32 0, -1
  %".176" = and i32 %"shf_result.4", 16376
  %".177" = and i32 %".176", %".175"
  %".178" = and i32 %"shf_result.4", 16376
  %".179" = and i32 %".178", 0
  %".180" = or i32 %".177", %".179"
  %".181" = xor i32 %".180", -1
  %".182" = xor i32 524288, -1
  %".183" = xor i32 0, -1
  %".184" = and i32 %".181", 524288
  %".185" = and i32 %".184", %".183"
  %".186" = and i32 %".181", 524288
  %".187" = and i32 %".186", 0
  %".188" = or i32 %".185", %".187"
  %".189" = and i32 %".180", %".182"
  %".190" = and i32 %".189", %".183"
  %".191" = or i32 %".188", %".190"
  %".192" = and i32 %".180", %".182"
  %".193" = and i32 %".192", 0
  %".194" = or i32 %".191", %".193"
  %".195" = and i32 %".180", 524288
  %".196" = and i32 %".195", %".183"
  %".197" = or i32 %".194", %".196"
  %".198" = and i32 %".180", 524288
  %".199" = and i32 %".198", 0
  %".200" = or i32 %".197", %".199"
  %"iadd3_n1.4" = add i32 %"lds.1", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.1", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_07c0"
BB_07c0:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_06b0"], [%"P20_to_i32", %"BB_07f0"]
  %"phi.15" = phi  i32 [%"P30_to_i32", %"BB_06b0"], [%"phi.17", %"BB_07f0"]
  %"cond_trunc.8" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_800007c0", label %"BB_07d0"
BB_800007c0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.16" = phi  i32 [%"P17_to_i32", %"BB_800007c0"], [%"phi.14", %"BB_07c0"]
  %"mma_a_r0_ext" = zext i32 %".172" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".204" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".205" = sub i64 %".204", 0
  %".206" = lshr i64 %".205", 4
  %".207" = add i64 %"mma_a_packed_1", %".206"
  %".208" = and i64 %".207", 16383
  %".209" = and i64 %"mma_a_packed_1", -16384
  %".210" = or i64 %".209", %".208"
  %"mma_b_r0_ext" = zext i32 %".200" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".211" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".212" = sub i64 %".211", 0
  %".213" = lshr i64 %".212", 4
  %".214" = add i64 %"mma_b_packed_1", %".213"
  %".215" = and i64 %".214", 16383
  %".216" = and i64 %"mma_b_packed_1", -16384
  %".217" = or i64 %".216", %".215"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".210", i64 %".217", i32 679743664, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_07e0"
BB_07e0:
  %"cond_trunc.9" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800007e0", label %"BB_07f0"
BB_800007e0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".221" = xor i32 %"plop3_a_bit.1", 1
  %".222" = xor i32 %"plop3_b_bit.1", 1
  %".223" = xor i32 %"plop3_c_bit.1", 1
  %".224" = and i32 %".221", %"plop3_b_bit.1"
  %".225" = and i32 %".224", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".225", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_07f0"
BB_07f0:
  %"phi.17" = phi  i32 [%"P1_to_i32", %"BB_800007e0"], [%"phi.15", %"BB_07e0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".227" = xor i32 %"plop3_a_bit.2", 1
  %".228" = xor i32 %"plop3_b_bit.2", 1
  %".229" = xor i32 %"plop3_c_bit.2", 1
  %".230" = and i32 %".227", %"plop3_b_bit.2"
  %".231" = and i32 %".230", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".231", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_07c0", label %"BB_0810"
BB_0810:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".233" = xor i32 %"plop3_a_bit.3", 1
  %".234" = xor i32 %"plop3_b_bit.3", 1
  %".235" = xor i32 %"plop3_c_bit.3", 1
  %".236" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".237" = and i32 %".236", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".237", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".238" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".239" = zext i32 %"iadd3_n2.6" to i64
  %".240" = zext i32 24 to i64
  %".241" = shl i64 %".238", %".240"
  %".242" = and i64 %".241", 4294967295
  %".243" = add i64 %".242", %".239"
  %".244" = trunc i64 %".243" to i32
  br label %"BB_0840"
BB_0840:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_0810"], [%"P9_to_i32", %"BB_0870"]
  %"phi.19" = phi  i32 [%"P23_to_i32", %"BB_0810"], [%"phi.21", %"BB_0870"]
  %"cond_trunc.10" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000840", label %"BB_0850"
BB_80000840:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P6_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0850"
BB_0850:
  %"phi.20" = phi  i32 [%"P6_to_i32", %"BB_80000840"], [%"phi.18", %"BB_0840"]
  %"utcbar_local_winoff" = and i32 %".244", 16777215
  %".248" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".249" = ptrtoint i8 addrspace(3)* %".248" to i32
  %".250" = lshr i32 %".244", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".249", i32 %".250")
  br label %"BB_0860"
BB_0860:
  %"cond_trunc.11" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000860", label %"BB_0870"
BB_80000860:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".254" = xor i32 %"plop3_a_bit.4", 1
  %".255" = xor i32 %"plop3_b_bit.4", 1
  %".256" = xor i32 %"plop3_c_bit.4", 1
  %".257" = and i32 %".254", %"plop3_b_bit.4"
  %".258" = and i32 %".257", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".258", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.21" = phi  i32 [%"P2_to_i32", %"BB_80000860"], [%"phi.19", %"BB_0860"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".260" = xor i32 %"plop3_a_bit.5", 1
  %".261" = xor i32 %"plop3_b_bit.5", 1
  %".262" = xor i32 %"plop3_c_bit.5", 1
  %".263" = and i32 %".260", %"plop3_b_bit.5"
  %".264" = and i32 %".263", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".264", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0840", label %"BB_0890"
BB_0890:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".266" = zext i32 0 to i64
  %".267" = zext i32 0 to i64
  %".268" = shl i64 %".267", 32
  %"shf_concat.5" = or i64 %".266", %".268"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".269" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".269" to i32
  %".270" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".271" = zext i32 %"iadd3_n2.7" to i64
  %".272" = zext i32 24 to i64
  %".273" = shl i64 %".270", %".272"
  %".274" = and i64 %".273", 4294967295
  %".275" = add i64 %".274", %".271"
  %".276" = trunc i64 %".275" to i32
  %"mbar_shared_winoff.1" = and i32 %".276", 16777215
  %".277" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".277" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P26_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0900"
BB_0900:
  %"cond_trunc.12" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0d50", label %"BB_0910"
BB_0d50:
  %"mbar_shared_winoff.2" = and i32 %".276", 16777215
  %".280" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".280" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P28_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0d60"
BB_0d60:
  %"cond_trunc.13" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0d50", label %"BB_0910"
BB_0910:
  %".283" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".284" = bitcast i8* %".283" to i64*
  %"ldc_const.1" = load i64, i64* %".284"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".285" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".286" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".287" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".288" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".289" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".290" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".291" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".292" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.3" = trunc i64 %"imad.13" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R54:R48_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".285", i32 addrspace(1)* %"R54:R48_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R54:R48_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".286", i32 addrspace(1)* %"R54:R48_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R54:R48_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".287", i32 addrspace(1)* %"R54:R48_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R54:R48_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".288", i32 addrspace(1)* %"R54:R48_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R54:R48_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".289", i32 addrspace(1)* %"R54:R48_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".299" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".300" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".301" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R54:R48_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".290", i32 addrspace(1)* %"R54:R48_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R54:R48_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".291", i32 addrspace(1)* %"R54:R48_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R54:R48_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".292", i32 addrspace(1)* %"R54:R48_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R54:R48_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R54:R48_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R54:R48_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".299", i32 addrspace(1)* %"R54:R48_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R54:R48_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".300", i32 addrspace(1)* %"R54:R48_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R54:R48_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".301", i32 addrspace(1)* %"R54:R48_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R54:R48_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R54:R48_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R54:R48_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R54:R48_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R54:R48_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R54:R48_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R54:R48_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R54:R48_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.14" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000b00", label %"BB_0b10"
BB_0b10:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".319" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".319" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 1
  %".320" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".321" = zext i32 64 to i64
  %".322" = zext i32 24 to i64
  %".323" = shl i64 %".320", %".322"
  %".324" = and i64 %".323", 4294967295
  %".325" = add i64 %".324", %".321"
  %".326" = trunc i64 %".325" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".326", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".327" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".327" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".328" = xor i32 %"lds.2", -1
  %".329" = xor i32 65535, -1
  %".330" = xor i32 0, -1
  %".331" = and i32 %"lds.2", 65535
  %".332" = and i32 %".331", %".330"
  %".333" = and i32 %"lds.2", 65535
  %".334" = and i32 %".333", 0
  %".335" = or i32 %".332", %".334"
  %".336" = zext i32 0 to i64
  %".337" = zext i32 %".335" to i64
  %".338" = shl i64 %".337", 32
  %"shf_concat.6" = or i64 %".336", %".338"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".339" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".339", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".340" = zext i32 %"imad.14" to i64
  %".341" = zext i32 0 to i64
  %".342" = shl i64 %".341", 32
  %"shf_concat.7" = or i64 %".340", %".342"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".343" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".343" to i32
  %".344" = xor i32 %"lds.3", -1
  %".345" = xor i32 %"shf_result.7", -1
  %".346" = xor i32 0, -1
  %".347" = and i32 %"lds.3", %"shf_result.7"
  %".348" = and i32 %".347", %".346"
  %".349" = and i32 %"lds.3", %"shf_result.7"
  %".350" = and i32 %".349", 0
  %".351" = or i32 %".348", %".350"
  %"isetrp_cmp1.5" = icmp ne i32 %".351", %"shf_result.7"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"cond_trunc.15" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0d20_0db0", label %"BB_0bd0"
BB_0bd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".326", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".354" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".354" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".355" = xor i32 %"lds.4", -1
  %".356" = xor i32 %"shf_result.7", -1
  %".357" = xor i32 0, -1
  %".358" = and i32 %"lds.4", %"shf_result.7"
  %".359" = and i32 %".358", %".357"
  %".360" = and i32 %"lds.4", %"shf_result.7"
  %".361" = and i32 %".360", 0
  %".362" = or i32 %".359", %".361"
  %"isetrp_cmp1.6" = icmp ne i32 %".362", %"shf_result.7"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0c00"
BB_0c00:
  %"cond_trunc.16" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0cf0_0d80", label %"BB_0c10"
BB_0c10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".365" = xor i32 0, -1
  %".366" = xor i32 %"shf_result.7", -1
  %".367" = xor i32 0, -1
  %".368" = and i32 %".365", %".366"
  %".369" = and i32 %".368", %".367"
  %".370" = and i32 %".365", %".366"
  %".371" = and i32 %".370", 0
  %".372" = or i32 %".369", %".371"
  %".373" = and i32 0, %".366"
  %".374" = and i32 %".373", %".367"
  %".375" = or i32 %".372", %".374"
  %".376" = and i32 0, %".366"
  %".377" = and i32 %".376", 0
  %".378" = or i32 %".375", %".377"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %".378"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.15", i32 %"redux_mask")
  %".379" = xor i32 %".378", -1
  %".380" = call i32 @"llvm.cttz.i32"(i32 %".379", i1 0)
  %".381" = shl i32 %".380", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".381") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.17" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000cb0", label %"BB_0d30"
BB_80000cb0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".326", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".385" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".385" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.16" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".326", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".386" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".386" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.16" monotonic
  br label %"BB_0d30"
BB_0cf0_0d80:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d20_0db0:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d30:
  ret void
BB_80000b00:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P4_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.1" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.2" = phi  i32 [%"R5:R4_r0", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R5:R4_r1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R107:R85_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R107:R85_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi", 128
  %"iadd3_o1_64" = zext i32 %"phi.2" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi.3"
  %"imad_cin_trunc" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R5:R4_r1"
  %"imad_cin_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R22:R67_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R22:R67_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P4_to_i32", %"BB_01b0"], [%"P10_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P29_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P21_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P22_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P14_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P24_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P14_to_i32", %"BB_04a0"], [%"P14_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 10
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R52:R42_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R52:R42_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R52:R42_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R52:R42_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R52:R42_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R52:R42_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R52:R42_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R52:R42_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R52:R42_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".110" = xor i32 %"imad.10", -1
  %".111" = xor i32 65011712, -1
  %".112" = xor i32 0, -1
  %".113" = and i32 %"imad.10", 65011712
  %".114" = and i32 %".113", %".112"
  %".115" = and i32 %"imad.10", 65011712
  %".116" = and i32 %".115", 0
  %".117" = or i32 %".114", %".116"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".117"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0890", label %"BB_06b0"
BB_06b0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".124" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".124" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".125" = xor i32 %"plop3_a_bit", 1
  %".126" = xor i32 %"plop3_b_bit", 1
  %".127" = xor i32 %"plop3_c_bit", 1
  %".128" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".129" = and i32 %".128", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".129", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".18" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.3" = or i64 %".130", %".132"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".133", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 %"iadd3_n2.3" to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %".141" = xor i32 %"shf_result.3", -1
  %".142" = xor i32 16376, -1
  %".143" = xor i32 0, -1
  %".144" = and i32 %"shf_result.3", 16376
  %".145" = and i32 %".144", %".143"
  %".146" = and i32 %"shf_result.3", 16376
  %".147" = and i32 %".146", 0
  %".148" = or i32 %".145", %".147"
  %".149" = zext i32 0 to i64
  %".150" = zext i32 %".140" to i64
  %".151" = shl i64 %".150", 32
  %"shf_concat.4" = or i64 %".149", %".151"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".152" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".152", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".153" = xor i32 %".148", -1
  %".154" = xor i32 524288, -1
  %".155" = xor i32 0, -1
  %".156" = and i32 %".153", 524288
  %".157" = and i32 %".156", %".155"
  %".158" = and i32 %".153", 524288
  %".159" = and i32 %".158", 0
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %".148", %".154"
  %".162" = and i32 %".161", %".155"
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %".148", %".154"
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".148", 524288
  %".168" = and i32 %".167", %".155"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %".148", 524288
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %".173" = xor i32 %"shf_result.4", -1
  %".174" = xor i32 16376, -1
  %".175" = xor i32 0, -1
  %".176" = and i32 %"shf_result.4", 16376
  %".177" = and i32 %".176", %".175"
  %".178" = and i32 %"shf_result.4", 16376
  %".179" = and i32 %".178", 0
  %".180" = or i32 %".177", %".179"
  %".181" = xor i32 %".180", -1
  %".182" = xor i32 524288, -1
  %".183" = xor i32 0, -1
  %".184" = and i32 %".181", 524288
  %".185" = and i32 %".184", %".183"
  %".186" = and i32 %".181", 524288
  %".187" = and i32 %".186", 0
  %".188" = or i32 %".185", %".187"
  %".189" = and i32 %".180", %".182"
  %".190" = and i32 %".189", %".183"
  %".191" = or i32 %".188", %".190"
  %".192" = and i32 %".180", %".182"
  %".193" = and i32 %".192", 0
  %".194" = or i32 %".191", %".193"
  %".195" = and i32 %".180", 524288
  %".196" = and i32 %".195", %".183"
  %".197" = or i32 %".194", %".196"
  %".198" = and i32 %".180", 524288
  %".199" = and i32 %".198", 0
  %".200" = or i32 %".197", %".199"
  %"iadd3_n1.4" = add i32 %"lds.1", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.1", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_07c0"
BB_07c0:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_06b0"], [%"P20_to_i32", %"BB_07f0"]
  %"phi.15" = phi  i32 [%"P30_to_i32", %"BB_06b0"], [%"phi.17", %"BB_07f0"]
  %"cond_trunc.8" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_800007c0", label %"BB_07d0"
BB_800007c0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.16" = phi  i32 [%"P17_to_i32", %"BB_800007c0"], [%"phi.14", %"BB_07c0"]
  %"mma_a_r0_ext" = zext i32 %".172" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".204" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".205" = sub i64 %".204", 0
  %".206" = lshr i64 %".205", 4
  %".207" = add i64 %"mma_a_packed_1", %".206"
  %".208" = and i64 %".207", 16383
  %".209" = and i64 %"mma_a_packed_1", -16384
  %".210" = or i64 %".209", %".208"
  %"mma_b_r0_ext" = zext i32 %".200" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".211" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".212" = sub i64 %".211", 0
  %".213" = lshr i64 %".212", 4
  %".214" = add i64 %"mma_b_packed_1", %".213"
  %".215" = and i64 %".214", 16383
  %".216" = and i64 %"mma_b_packed_1", -16384
  %".217" = or i64 %".216", %".215"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".210", i64 %".217", i32 679744944, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_07e0"
BB_07e0:
  %"cond_trunc.9" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800007e0", label %"BB_07f0"
BB_800007e0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".221" = xor i32 %"plop3_a_bit.1", 1
  %".222" = xor i32 %"plop3_b_bit.1", 1
  %".223" = xor i32 %"plop3_c_bit.1", 1
  %".224" = and i32 %".221", %"plop3_b_bit.1"
  %".225" = and i32 %".224", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".225", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_07f0"
BB_07f0:
  %"phi.17" = phi  i32 [%"P1_to_i32", %"BB_800007e0"], [%"phi.15", %"BB_07e0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".227" = xor i32 %"plop3_a_bit.2", 1
  %".228" = xor i32 %"plop3_b_bit.2", 1
  %".229" = xor i32 %"plop3_c_bit.2", 1
  %".230" = and i32 %".227", %"plop3_b_bit.2"
  %".231" = and i32 %".230", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".231", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_07c0", label %"BB_0810"
BB_0810:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".233" = xor i32 %"plop3_a_bit.3", 1
  %".234" = xor i32 %"plop3_b_bit.3", 1
  %".235" = xor i32 %"plop3_c_bit.3", 1
  %".236" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".237" = and i32 %".236", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".237", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".238" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".239" = zext i32 %"iadd3_n2.6" to i64
  %".240" = zext i32 24 to i64
  %".241" = shl i64 %".238", %".240"
  %".242" = and i64 %".241", 4294967295
  %".243" = add i64 %".242", %".239"
  %".244" = trunc i64 %".243" to i32
  br label %"BB_0840"
BB_0840:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_0810"], [%"P9_to_i32", %"BB_0870"]
  %"phi.19" = phi  i32 [%"P23_to_i32", %"BB_0810"], [%"phi.21", %"BB_0870"]
  %"cond_trunc.10" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000840", label %"BB_0850"
BB_80000840:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P6_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0850"
BB_0850:
  %"phi.20" = phi  i32 [%"P6_to_i32", %"BB_80000840"], [%"phi.18", %"BB_0840"]
  %"utcbar_local_winoff" = and i32 %".244", 16777215
  %".248" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".249" = ptrtoint i8 addrspace(3)* %".248" to i32
  %".250" = lshr i32 %".244", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".249", i32 %".250")
  br label %"BB_0860"
BB_0860:
  %"cond_trunc.11" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000860", label %"BB_0870"
BB_80000860:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".254" = xor i32 %"plop3_a_bit.4", 1
  %".255" = xor i32 %"plop3_b_bit.4", 1
  %".256" = xor i32 %"plop3_c_bit.4", 1
  %".257" = and i32 %".254", %"plop3_b_bit.4"
  %".258" = and i32 %".257", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".258", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.21" = phi  i32 [%"P2_to_i32", %"BB_80000860"], [%"phi.19", %"BB_0860"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".260" = xor i32 %"plop3_a_bit.5", 1
  %".261" = xor i32 %"plop3_b_bit.5", 1
  %".262" = xor i32 %"plop3_c_bit.5", 1
  %".263" = and i32 %".260", %"plop3_b_bit.5"
  %".264" = and i32 %".263", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".264", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0840", label %"BB_0890"
BB_0890:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".266" = zext i32 0 to i64
  %".267" = zext i32 0 to i64
  %".268" = shl i64 %".267", 32
  %"shf_concat.5" = or i64 %".266", %".268"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".269" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".269" to i32
  %".270" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".271" = zext i32 %"iadd3_n2.7" to i64
  %".272" = zext i32 24 to i64
  %".273" = shl i64 %".270", %".272"
  %".274" = and i64 %".273", 4294967295
  %".275" = add i64 %".274", %".271"
  %".276" = trunc i64 %".275" to i32
  %"mbar_shared_winoff.1" = and i32 %".276", 16777215
  %".277" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".277" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P26_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0900"
BB_0900:
  %"cond_trunc.12" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0d50", label %"BB_0910"
BB_0d50:
  %"mbar_shared_winoff.2" = and i32 %".276", 16777215
  %".280" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".280" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P28_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0d60"
BB_0d60:
  %"cond_trunc.13" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0d50", label %"BB_0910"
BB_0910:
  %".283" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".284" = bitcast i8* %".283" to i64*
  %"ldc_const.1" = load i64, i64* %".284"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".285" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".286" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".287" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".288" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".289" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".290" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".291" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".292" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.3" = trunc i64 %"imad.13" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R54:R48_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".285", i32 addrspace(1)* %"R54:R48_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R54:R48_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".286", i32 addrspace(1)* %"R54:R48_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R54:R48_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".287", i32 addrspace(1)* %"R54:R48_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R54:R48_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".288", i32 addrspace(1)* %"R54:R48_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R54:R48_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".289", i32 addrspace(1)* %"R54:R48_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".299" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".300" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".301" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R54:R48_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".290", i32 addrspace(1)* %"R54:R48_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R54:R48_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".291", i32 addrspace(1)* %"R54:R48_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R54:R48_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".292", i32 addrspace(1)* %"R54:R48_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R54:R48_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R54:R48_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R54:R48_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".299", i32 addrspace(1)* %"R54:R48_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R54:R48_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".300", i32 addrspace(1)* %"R54:R48_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R54:R48_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".301", i32 addrspace(1)* %"R54:R48_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R54:R48_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R54:R48_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R54:R48_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R54:R48_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R54:R48_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R54:R48_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R54:R48_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R54:R48_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.14" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000b00", label %"BB_0b10"
BB_0b10:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".319" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".319" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 1
  %".320" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".321" = zext i32 64 to i64
  %".322" = zext i32 24 to i64
  %".323" = shl i64 %".320", %".322"
  %".324" = and i64 %".323", 4294967295
  %".325" = add i64 %".324", %".321"
  %".326" = trunc i64 %".325" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".326", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".327" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".327" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".328" = xor i32 %"lds.2", -1
  %".329" = xor i32 65535, -1
  %".330" = xor i32 0, -1
  %".331" = and i32 %"lds.2", 65535
  %".332" = and i32 %".331", %".330"
  %".333" = and i32 %"lds.2", 65535
  %".334" = and i32 %".333", 0
  %".335" = or i32 %".332", %".334"
  %".336" = zext i32 0 to i64
  %".337" = zext i32 %".335" to i64
  %".338" = shl i64 %".337", 32
  %"shf_concat.6" = or i64 %".336", %".338"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".339" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".339", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".340" = zext i32 %"imad.14" to i64
  %".341" = zext i32 0 to i64
  %".342" = shl i64 %".341", 32
  %"shf_concat.7" = or i64 %".340", %".342"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".343" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".343" to i32
  %".344" = xor i32 %"lds.3", -1
  %".345" = xor i32 %"shf_result.7", -1
  %".346" = xor i32 0, -1
  %".347" = and i32 %"lds.3", %"shf_result.7"
  %".348" = and i32 %".347", %".346"
  %".349" = and i32 %"lds.3", %"shf_result.7"
  %".350" = and i32 %".349", 0
  %".351" = or i32 %".348", %".350"
  %"isetrp_cmp1.5" = icmp ne i32 %".351", %"shf_result.7"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"cond_trunc.15" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0d20_0db0", label %"BB_0bd0"
BB_0bd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".326", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".354" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".354" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".355" = xor i32 %"lds.4", -1
  %".356" = xor i32 %"shf_result.7", -1
  %".357" = xor i32 0, -1
  %".358" = and i32 %"lds.4", %"shf_result.7"
  %".359" = and i32 %".358", %".357"
  %".360" = and i32 %"lds.4", %"shf_result.7"
  %".361" = and i32 %".360", 0
  %".362" = or i32 %".359", %".361"
  %"isetrp_cmp1.6" = icmp ne i32 %".362", %"shf_result.7"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0c00"
BB_0c00:
  %"cond_trunc.16" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0cf0_0d80", label %"BB_0c10"
BB_0c10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".365" = xor i32 0, -1
  %".366" = xor i32 %"shf_result.7", -1
  %".367" = xor i32 0, -1
  %".368" = and i32 %".365", %".366"
  %".369" = and i32 %".368", %".367"
  %".370" = and i32 %".365", %".366"
  %".371" = and i32 %".370", 0
  %".372" = or i32 %".369", %".371"
  %".373" = and i32 0, %".366"
  %".374" = and i32 %".373", %".367"
  %".375" = or i32 %".372", %".374"
  %".376" = and i32 0, %".366"
  %".377" = and i32 %".376", 0
  %".378" = or i32 %".375", %".377"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %".378"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.15", i32 %"redux_mask")
  %".379" = xor i32 %".378", -1
  %".380" = call i32 @"llvm.cttz.i32"(i32 %".379", i1 0)
  %".381" = shl i32 %".380", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".381") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.17" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000cb0", label %"BB_0d30"
BB_80000cb0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".326", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".385" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".385" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.16" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".326", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".386" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".386" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.16" monotonic
  br label %"BB_0d30"
BB_0cf0_0d80:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d20_0db0:
  call void @"llvm.trap"()
  br label %"BB_0d30"
BB_0d30:
  ret void
BB_80000b00:
  ret void
}

define void @"_Z13column_scaledIL4Case1EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P4_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R65:R36_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R65:R36_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R60:R22_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R60:R22_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P4_to_i32", %"BB_01b0"], [%"P10_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P29_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P21_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P22_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P14_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P24_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P14_to_i32", %"BB_04a0"], [%"P14_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0580"
BB_0580:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0750", label %"BB_0590"
BB_0590:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".113" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".113" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".114" = xor i32 %"plop3_a_bit", 1
  %".115" = xor i32 %"plop3_b_bit", 1
  %".116" = xor i32 %"plop3_c_bit", 1
  %".117" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".118" = and i32 %".117", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".118", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".119" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".120" = zext i32 %"iadd3_n2.3" to i64
  %".121" = zext i32 24 to i64
  %".122" = shl i64 %".119", %".121"
  %".123" = and i64 %".122", 4294967295
  %".124" = add i64 %".123", %".120"
  %".125" = trunc i64 %".124" to i32
  %".126" = zext i32 0 to i64
  %".127" = zext i32 %".18" to i64
  %".128" = shl i64 %".127", 32
  %"shf_concat.3" = or i64 %".126", %".128"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".129" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".129", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".125" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.4" = or i64 %".130", %".132"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".133", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 16376, -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %"shf_result.3", 16376
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %"shf_result.3", 16376
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = xor i32 %"shf_result.4", -1
  %".143" = xor i32 16376, -1
  %".144" = xor i32 0, -1
  %".145" = and i32 %"shf_result.4", 16376
  %".146" = and i32 %".145", %".144"
  %".147" = and i32 %"shf_result.4", 16376
  %".148" = and i32 %".147", 0
  %".149" = or i32 %".146", %".148"
  %".150" = xor i32 %".141", -1
  %".151" = xor i32 524288, -1
  %".152" = xor i32 0, -1
  %".153" = and i32 %".150", 524288
  %".154" = and i32 %".153", %".152"
  %".155" = and i32 %".150", 524288
  %".156" = and i32 %".155", 0
  %".157" = or i32 %".154", %".156"
  %".158" = and i32 %".141", %".151"
  %".159" = and i32 %".158", %".152"
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %".141", %".151"
  %".162" = and i32 %".161", 0
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %".141", 524288
  %".165" = and i32 %".164", %".152"
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".141", 524288
  %".168" = and i32 %".167", 0
  %".169" = or i32 %".166", %".168"
  %".170" = xor i32 %".149", -1
  %".171" = xor i32 524288, -1
  %".172" = xor i32 0, -1
  %".173" = and i32 %".170", 524288
  %".174" = and i32 %".173", %".172"
  %".175" = and i32 %".170", 524288
  %".176" = and i32 %".175", 0
  %".177" = or i32 %".174", %".176"
  %".178" = and i32 %".149", %".171"
  %".179" = and i32 %".178", %".172"
  %".180" = or i32 %".177", %".179"
  %".181" = and i32 %".149", %".171"
  %".182" = and i32 %".181", 0
  %".183" = or i32 %".180", %".182"
  %".184" = and i32 %".149", 524288
  %".185" = and i32 %".184", %".172"
  %".186" = or i32 %".183", %".185"
  %".187" = and i32 %".149", 524288
  %".188" = and i32 %".187", 0
  %".189" = or i32 %".186", %".188"
  br label %"BB_0680"
BB_0680:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_0590"], [%"P20_to_i32", %"BB_06b0"]
  %"phi.15" = phi  i32 [%"P30_to_i32", %"BB_0590"], [%"phi.17", %"BB_06b0"]
  %"cond_trunc.8" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000680", label %"BB_0690"
BB_80000680:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0690"
BB_0690:
  %"phi.16" = phi  i32 [%"P17_to_i32", %"BB_80000680"], [%"phi.14", %"BB_0680"]
  %"mma_a_r0_ext" = zext i32 %".169" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".193" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".194" = sub i64 %".193", 0
  %".195" = lshr i64 %".194", 4
  %".196" = add i64 %"mma_a_packed_1", %".195"
  %".197" = and i64 %".196", 16383
  %".198" = and i64 %"mma_a_packed_1", -16384
  %".199" = or i64 %".198", %".197"
  %"mma_b_r0_ext" = zext i32 %".189" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".200" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".201" = sub i64 %".200", 0
  %".202" = lshr i64 %".201", 4
  %".203" = add i64 %"mma_b_packed_1", %".202"
  %".204" = and i64 %".203", 16383
  %".205" = and i64 %"mma_b_packed_1", -16384
  %".206" = or i64 %".205", %".204"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.1", i64 %".199", i64 %".206", i32 134484624, i32 %"mma_arg_zext")
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.9" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800006a0", label %"BB_06b0"
BB_800006a0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".210" = xor i32 %"plop3_a_bit.1", 1
  %".211" = xor i32 %"plop3_b_bit.1", 1
  %".212" = xor i32 %"plop3_c_bit.1", 1
  %".213" = and i32 %".210", %"plop3_b_bit.1"
  %".214" = and i32 %".213", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".214", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_06b0"
BB_06b0:
  %"phi.17" = phi  i32 [%"P1_to_i32", %"BB_800006a0"], [%"phi.15", %"BB_06a0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".216" = xor i32 %"plop3_a_bit.2", 1
  %".217" = xor i32 %"plop3_b_bit.2", 1
  %".218" = xor i32 %"plop3_c_bit.2", 1
  %".219" = and i32 %".216", %"plop3_b_bit.2"
  %".220" = and i32 %".219", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".220", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0680", label %"BB_06d0"
BB_06d0:
  %"iadd3_n1.4" = add i32 1024, 9216
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".222" = xor i32 %"plop3_a_bit.3", 1
  %".223" = xor i32 %"plop3_b_bit.3", 1
  %".224" = xor i32 %"plop3_c_bit.3", 1
  %".225" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".226" = and i32 %".225", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".226", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".227" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".228" = zext i32 %"iadd3_n2.4" to i64
  %".229" = zext i32 24 to i64
  %".230" = shl i64 %".227", %".229"
  %".231" = and i64 %".230", 4294967295
  %".232" = add i64 %".231", %".228"
  %".233" = trunc i64 %".232" to i32
  br label %"BB_0700"
BB_0700:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_06d0"], [%"P9_to_i32", %"BB_0730"]
  %"phi.19" = phi  i32 [%"P23_to_i32", %"BB_06d0"], [%"phi.21", %"BB_0730"]
  %"cond_trunc.10" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000700", label %"BB_0710"
BB_80000700:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P6_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0710"
BB_0710:
  %"phi.20" = phi  i32 [%"P6_to_i32", %"BB_80000700"], [%"phi.18", %"BB_0700"]
  %"utcbar_local_winoff" = and i32 %".233", 16777215
  %".237" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".238" = ptrtoint i8 addrspace(3)* %".237" to i32
  %".239" = lshr i32 %".233", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".238", i32 %".239")
  br label %"BB_0720"
BB_0720:
  %"cond_trunc.11" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000720", label %"BB_0730"
BB_80000720:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".243" = xor i32 %"plop3_a_bit.4", 1
  %".244" = xor i32 %"plop3_b_bit.4", 1
  %".245" = xor i32 %"plop3_c_bit.4", 1
  %".246" = and i32 %".243", %"plop3_b_bit.4"
  %".247" = and i32 %".246", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".247", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0730"
BB_0730:
  %"phi.21" = phi  i32 [%"P2_to_i32", %"BB_80000720"], [%"phi.19", %"BB_0720"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".249" = xor i32 %"plop3_a_bit.5", 1
  %".250" = xor i32 %"plop3_b_bit.5", 1
  %".251" = xor i32 %"plop3_c_bit.5", 1
  %".252" = and i32 %".249", %"plop3_b_bit.5"
  %".253" = and i32 %".252", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".253", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0700", label %"BB_0750"
BB_0750:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".255" = zext i32 0 to i64
  %".256" = zext i32 0 to i64
  %".257" = shl i64 %".256", 32
  %"shf_concat.5" = or i64 %".255", %".257"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".258" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".258" to i32
  %"imad_tmp.7" = mul i32 %"tid_x", 65536
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %".259" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".260" = zext i32 %"iadd3_n2.5" to i64
  %".261" = zext i32 24 to i64
  %".262" = shl i64 %".259", %".261"
  %".263" = and i64 %".262", 4294967295
  %".264" = add i64 %".263", %".260"
  %".265" = trunc i64 %".264" to i32
  %".266" = xor i32 %"imad.8", -1
  %".267" = xor i32 65011712, -1
  %".268" = xor i32 0, -1
  %".269" = and i32 %"imad.8", 65011712
  %".270" = and i32 %".269", %".268"
  %".271" = and i32 %"imad.8", 65011712
  %".272" = and i32 %".271", 0
  %".273" = or i32 %".270", %".272"
  %"imad_tmp.8" = mul i32 %"lds", 1
  %"imad.9" = add i32 %"imad_tmp.8", %".273"
  %"mbar_shared_winoff.1" = and i32 %".265", 16777215
  %".274" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".274" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P26_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_07f0"
BB_07f0:
  %"cond_trunc.12" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0c40", label %"BB_0800"
BB_0c40:
  %"mbar_shared_winoff.2" = and i32 %".265", 16777215
  %".277" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".277" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P28_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0c50"
BB_0c50:
  %"cond_trunc.13" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0c40", label %"BB_0800"
BB_0800:
  %".280" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".281" = bitcast i8* %".280" to i64*
  %"ldc_const.1" = load i64, i64* %".281"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.9" = mul i32 %"tid_x", 16
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.9")
  %".282" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".283" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".284" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".285" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.9", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".286" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".287" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".288" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".289" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.10" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.11" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.11" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.11", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R13:R17_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".282", i32 addrspace(1)* %"R13:R17_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R13:R17_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".283", i32 addrspace(1)* %"R13:R17_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R13:R17_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".284", i32 addrspace(1)* %"R13:R17_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R13:R17_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".285", i32 addrspace(1)* %"R13:R17_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R13:R17_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".286", i32 addrspace(1)* %"R13:R17_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.9", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".295" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".296" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".297" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R13:R17_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".287", i32 addrspace(1)* %"R13:R17_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R13:R17_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".288", i32 addrspace(1)* %"R13:R17_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R13:R17_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".289", i32 addrspace(1)* %"R13:R17_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.9", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".302" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".303" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R13:R17_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".295", i32 addrspace(1)* %"R13:R17_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R13:R17_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".296", i32 addrspace(1)* %"R13:R17_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R13:R17_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".297", i32 addrspace(1)* %"R13:R17_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R13:R17_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R13:R17_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R13:R17_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".302", i32 addrspace(1)* %"R13:R17_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R13:R17_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".303", i32 addrspace(1)* %"R13:R17_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R13:R17_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R13:R17_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R13:R17_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R13:R17_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_09f0"
BB_09f0:
  %"cond_trunc.14" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009f0", label %"BB_0a00"
BB_0a00:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".316" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".316" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.10", 1
  %".317" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".318" = zext i32 64 to i64
  %".319" = zext i32 24 to i64
  %".320" = shl i64 %".317", %".319"
  %".321" = and i64 %".320", 4294967295
  %".322" = add i64 %".321", %".318"
  %".323" = trunc i64 %".322" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".323", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".324" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".324" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".325" = xor i32 %"lds.2", -1
  %".326" = xor i32 65535, -1
  %".327" = xor i32 0, -1
  %".328" = and i32 %"lds.2", 65535
  %".329" = and i32 %".328", %".327"
  %".330" = and i32 %"lds.2", 65535
  %".331" = and i32 %".330", 0
  %".332" = or i32 %".329", %".331"
  %".333" = zext i32 0 to i64
  %".334" = zext i32 %".332" to i64
  %".335" = shl i64 %".334", 32
  %"shf_concat.6" = or i64 %".333", %".335"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".336" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".336", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".337" = zext i32 %"imad.12" to i64
  %".338" = zext i32 0 to i64
  %".339" = shl i64 %".338", 32
  %"shf_concat.7" = or i64 %".337", %".339"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".340" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".340" to i32
  %".341" = xor i32 %"lds.3", -1
  %".342" = xor i32 %"shf_result.7", -1
  %".343" = xor i32 0, -1
  %".344" = and i32 %"lds.3", %"shf_result.7"
  %".345" = and i32 %".344", %".343"
  %".346" = and i32 %"lds.3", %"shf_result.7"
  %".347" = and i32 %".346", 0
  %".348" = or i32 %".345", %".347"
  %"isetrp_cmp1.5" = icmp ne i32 %".348", %"shf_result.7"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0ab0"
BB_0ab0:
  %"cond_trunc.15" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0c10_0ca0", label %"BB_0ac0"
BB_0ac0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".323", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".351" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".351" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".352" = xor i32 %"lds.4", -1
  %".353" = xor i32 %"shf_result.7", -1
  %".354" = xor i32 0, -1
  %".355" = and i32 %"lds.4", %"shf_result.7"
  %".356" = and i32 %".355", %".354"
  %".357" = and i32 %"lds.4", %"shf_result.7"
  %".358" = and i32 %".357", 0
  %".359" = or i32 %".356", %".358"
  %"isetrp_cmp1.6" = icmp ne i32 %".359", %"shf_result.7"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0af0"
BB_0af0:
  %"cond_trunc.16" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0be0_0c70", label %"BB_0b00"
BB_0b00:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".362" = xor i32 0, -1
  %".363" = xor i32 %"shf_result.7", -1
  %".364" = xor i32 0, -1
  %".365" = and i32 %".362", %".363"
  %".366" = and i32 %".365", %".364"
  %".367" = and i32 %".362", %".363"
  %".368" = and i32 %".367", 0
  %".369" = or i32 %".366", %".368"
  %".370" = and i32 0, %".363"
  %".371" = and i32 %".370", %".364"
  %".372" = or i32 %".369", %".371"
  %".373" = and i32 0, %".363"
  %".374" = and i32 %".373", 0
  %".375" = or i32 %".372", %".374"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", %".375"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.13", i32 %"redux_mask")
  %".376" = xor i32 %".375", -1
  %".377" = call i32 @"llvm.cttz.i32"(i32 %".376", i1 0)
  %".378" = shl i32 %".377", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".378") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", %"redux_sync_and"
  br label %"BB_0ba0"
BB_0ba0:
  %"cond_trunc.17" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000ba0", label %"BB_0c20"
BB_80000ba0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".323", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".382" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".382" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.14" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".323", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".383" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".383" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.14" monotonic
  br label %"BB_0c20"
BB_0be0_0c70:
  call void @"llvm.trap"()
  br label %"BB_0c20"
BB_0c10_0ca0:
  call void @"llvm.trap"()
  br label %"BB_0c20"
BB_0c20:
  ret void
BB_800009f0:
  ret void
}

define void @"_Z13column_scaledIL4Case0EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P4_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R65:R36_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R65:R36_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P35_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R60:R22_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R60:R22_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P4_to_i32", %"BB_01b0"], [%"P10_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P29_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P21_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P22_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P14_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P24_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P14_to_i32", %"BB_04a0"], [%"P14_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0580"
BB_0580:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0750", label %"BB_0590"
BB_0590:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".113" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".113" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".114" = xor i32 %"plop3_a_bit", 1
  %".115" = xor i32 %"plop3_b_bit", 1
  %".116" = xor i32 %"plop3_c_bit", 1
  %".117" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".118" = and i32 %".117", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".118", 0
  %"P30_to_i32" = zext i1 %"plop3_pred" to i32
  %".119" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".120" = zext i32 %"iadd3_n2.3" to i64
  %".121" = zext i32 24 to i64
  %".122" = shl i64 %".119", %".121"
  %".123" = and i64 %".122", 4294967295
  %".124" = add i64 %".123", %".120"
  %".125" = trunc i64 %".124" to i32
  %".126" = zext i32 0 to i64
  %".127" = zext i32 %".18" to i64
  %".128" = shl i64 %".127", 32
  %"shf_concat.3" = or i64 %".126", %".128"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".129" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".129", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".125" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.4" = or i64 %".130", %".132"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".133", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 16376, -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %"shf_result.3", 16376
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %"shf_result.3", 16376
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = xor i32 %"shf_result.4", -1
  %".143" = xor i32 16376, -1
  %".144" = xor i32 0, -1
  %".145" = and i32 %"shf_result.4", 16376
  %".146" = and i32 %".145", %".144"
  %".147" = and i32 %"shf_result.4", 16376
  %".148" = and i32 %".147", 0
  %".149" = or i32 %".146", %".148"
  %".150" = xor i32 %".141", -1
  %".151" = xor i32 524288, -1
  %".152" = xor i32 0, -1
  %".153" = and i32 %".150", 524288
  %".154" = and i32 %".153", %".152"
  %".155" = and i32 %".150", 524288
  %".156" = and i32 %".155", 0
  %".157" = or i32 %".154", %".156"
  %".158" = and i32 %".141", %".151"
  %".159" = and i32 %".158", %".152"
  %".160" = or i32 %".157", %".159"
  %".161" = and i32 %".141", %".151"
  %".162" = and i32 %".161", 0
  %".163" = or i32 %".160", %".162"
  %".164" = and i32 %".141", 524288
  %".165" = and i32 %".164", %".152"
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".141", 524288
  %".168" = and i32 %".167", 0
  %".169" = or i32 %".166", %".168"
  %".170" = xor i32 %".149", -1
  %".171" = xor i32 524288, -1
  %".172" = xor i32 0, -1
  %".173" = and i32 %".170", 524288
  %".174" = and i32 %".173", %".172"
  %".175" = and i32 %".170", 524288
  %".176" = and i32 %".175", 0
  %".177" = or i32 %".174", %".176"
  %".178" = and i32 %".149", %".171"
  %".179" = and i32 %".178", %".172"
  %".180" = or i32 %".177", %".179"
  %".181" = and i32 %".149", %".171"
  %".182" = and i32 %".181", 0
  %".183" = or i32 %".180", %".182"
  %".184" = and i32 %".149", 524288
  %".185" = and i32 %".184", %".172"
  %".186" = or i32 %".183", %".185"
  %".187" = and i32 %".149", 524288
  %".188" = and i32 %".187", 0
  %".189" = or i32 %".186", %".188"
  br label %"BB_0680"
BB_0680:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_0590"], [%"P20_to_i32", %"BB_06b0"]
  %"phi.15" = phi  i32 [%"P30_to_i32", %"BB_0590"], [%"phi.17", %"BB_06b0"]
  %"cond_trunc.8" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000680", label %"BB_0690"
BB_80000680:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0690"
BB_0690:
  %"phi.16" = phi  i32 [%"P17_to_i32", %"BB_80000680"], [%"phi.14", %"BB_0680"]
  %"mma_a_r0_ext" = zext i32 %".169" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".193" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".194" = sub i64 %".193", 0
  %".195" = lshr i64 %".194", 4
  %".196" = add i64 %"mma_a_packed_1", %".195"
  %".197" = and i64 %".196", 16383
  %".198" = and i64 %"mma_a_packed_1", -16384
  %".199" = or i64 %".198", %".197"
  %"mma_b_r0_ext" = zext i32 %".189" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".200" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".201" = sub i64 %".200", 0
  %".202" = lshr i64 %".201", 4
  %".203" = add i64 %"mma_b_packed_1", %".202"
  %".204" = and i64 %".203", 16383
  %".205" = and i64 %"mma_b_packed_1", -16384
  %".206" = or i64 %".205", %".204"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.1", i64 %".199", i64 %".206", i32 134485392, i32 %"mma_arg_zext")
  br label %"BB_06a0"
BB_06a0:
  %"cond_trunc.9" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800006a0", label %"BB_06b0"
BB_800006a0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".210" = xor i32 %"plop3_a_bit.1", 1
  %".211" = xor i32 %"plop3_b_bit.1", 1
  %".212" = xor i32 %"plop3_c_bit.1", 1
  %".213" = and i32 %".210", %"plop3_b_bit.1"
  %".214" = and i32 %".213", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".214", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_06b0"
BB_06b0:
  %"phi.17" = phi  i32 [%"P1_to_i32", %"BB_800006a0"], [%"phi.15", %"BB_06a0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".216" = xor i32 %"plop3_a_bit.2", 1
  %".217" = xor i32 %"plop3_b_bit.2", 1
  %".218" = xor i32 %"plop3_c_bit.2", 1
  %".219" = and i32 %".216", %"plop3_b_bit.2"
  %".220" = and i32 %".219", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".220", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0680", label %"BB_06d0"
BB_06d0:
  %"iadd3_n1.4" = add i32 1024, 9216
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".222" = xor i32 %"plop3_a_bit.3", 1
  %".223" = xor i32 %"plop3_b_bit.3", 1
  %".224" = xor i32 %"plop3_c_bit.3", 1
  %".225" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".226" = and i32 %".225", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".226", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".227" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".228" = zext i32 %"iadd3_n2.4" to i64
  %".229" = zext i32 24 to i64
  %".230" = shl i64 %".227", %".229"
  %".231" = and i64 %".230", 4294967295
  %".232" = add i64 %".231", %".228"
  %".233" = trunc i64 %".232" to i32
  br label %"BB_0700"
BB_0700:
  %"phi.18" = phi  i32 [%"P20_to_i32", %"BB_06d0"], [%"P9_to_i32", %"BB_0730"]
  %"phi.19" = phi  i32 [%"P23_to_i32", %"BB_06d0"], [%"phi.21", %"BB_0730"]
  %"cond_trunc.10" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000700", label %"BB_0710"
BB_80000700:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P6_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0710"
BB_0710:
  %"phi.20" = phi  i32 [%"P6_to_i32", %"BB_80000700"], [%"phi.18", %"BB_0700"]
  %"utcbar_local_winoff" = and i32 %".233", 16777215
  %".237" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".238" = ptrtoint i8 addrspace(3)* %".237" to i32
  %".239" = lshr i32 %".233", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".238", i32 %".239")
  br label %"BB_0720"
BB_0720:
  %"cond_trunc.11" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000720", label %"BB_0730"
BB_80000720:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".243" = xor i32 %"plop3_a_bit.4", 1
  %".244" = xor i32 %"plop3_b_bit.4", 1
  %".245" = xor i32 %"plop3_c_bit.4", 1
  %".246" = and i32 %".243", %"plop3_b_bit.4"
  %".247" = and i32 %".246", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".247", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0730"
BB_0730:
  %"phi.21" = phi  i32 [%"P2_to_i32", %"BB_80000720"], [%"phi.19", %"BB_0720"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".249" = xor i32 %"plop3_a_bit.5", 1
  %".250" = xor i32 %"plop3_b_bit.5", 1
  %".251" = xor i32 %"plop3_c_bit.5", 1
  %".252" = and i32 %".249", %"plop3_b_bit.5"
  %".253" = and i32 %".252", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".253", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0700", label %"BB_0750"
BB_0750:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".255" = zext i32 0 to i64
  %".256" = zext i32 0 to i64
  %".257" = shl i64 %".256", 32
  %"shf_concat.5" = or i64 %".255", %".257"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".258" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".258" to i32
  %"imad_tmp.7" = mul i32 %"tid_x", 65536
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %".259" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".260" = zext i32 %"iadd3_n2.5" to i64
  %".261" = zext i32 24 to i64
  %".262" = shl i64 %".259", %".261"
  %".263" = and i64 %".262", 4294967295
  %".264" = add i64 %".263", %".260"
  %".265" = trunc i64 %".264" to i32
  %".266" = xor i32 %"imad.8", -1
  %".267" = xor i32 65011712, -1
  %".268" = xor i32 0, -1
  %".269" = and i32 %"imad.8", 65011712
  %".270" = and i32 %".269", %".268"
  %".271" = and i32 %"imad.8", 65011712
  %".272" = and i32 %".271", 0
  %".273" = or i32 %".270", %".272"
  %"imad_tmp.8" = mul i32 %"lds", 1
  %"imad.9" = add i32 %"imad_tmp.8", %".273"
  %"mbar_shared_winoff.1" = and i32 %".265", 16777215
  %".274" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".274" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P26_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_07f0"
BB_07f0:
  %"cond_trunc.12" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0c40", label %"BB_0800"
BB_0c40:
  %"mbar_shared_winoff.2" = and i32 %".265", 16777215
  %".277" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".277" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P28_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0c50"
BB_0c50:
  %"cond_trunc.13" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0c40", label %"BB_0800"
BB_0800:
  %".280" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".281" = bitcast i8* %".280" to i64*
  %"ldc_const.1" = load i64, i64* %".281"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.9" = mul i32 %"tid_x", 16
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.9")
  %".282" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".283" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".284" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".285" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.9", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".286" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".287" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".288" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".289" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.10" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.11" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.11" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.11", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R13:R17_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".282", i32 addrspace(1)* %"R13:R17_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R13:R17_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".283", i32 addrspace(1)* %"R13:R17_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R13:R17_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".284", i32 addrspace(1)* %"R13:R17_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R13:R17_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".285", i32 addrspace(1)* %"R13:R17_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R13:R17_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".286", i32 addrspace(1)* %"R13:R17_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.9", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".295" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".296" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".297" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R13:R17_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".287", i32 addrspace(1)* %"R13:R17_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R13:R17_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".288", i32 addrspace(1)* %"R13:R17_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R13:R17_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".289", i32 addrspace(1)* %"R13:R17_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.9", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".302" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".303" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R13:R17_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".295", i32 addrspace(1)* %"R13:R17_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R13:R17_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".296", i32 addrspace(1)* %"R13:R17_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R13:R17_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".297", i32 addrspace(1)* %"R13:R17_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R13:R17_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R13:R17_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R13:R17_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".302", i32 addrspace(1)* %"R13:R17_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R13:R17_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".303", i32 addrspace(1)* %"R13:R17_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R13:R17_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R13:R17_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R13:R17_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R13:R17_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_09f0"
BB_09f0:
  %"cond_trunc.14" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009f0", label %"BB_0a00"
BB_0a00:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".316" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".316" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.10", 1
  %".317" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".318" = zext i32 64 to i64
  %".319" = zext i32 24 to i64
  %".320" = shl i64 %".317", %".319"
  %".321" = and i64 %".320", 4294967295
  %".322" = add i64 %".321", %".318"
  %".323" = trunc i64 %".322" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".323", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".324" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".324" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".325" = xor i32 %"lds.2", -1
  %".326" = xor i32 65535, -1
  %".327" = xor i32 0, -1
  %".328" = and i32 %"lds.2", 65535
  %".329" = and i32 %".328", %".327"
  %".330" = and i32 %"lds.2", 65535
  %".331" = and i32 %".330", 0
  %".332" = or i32 %".329", %".331"
  %".333" = zext i32 0 to i64
  %".334" = zext i32 %".332" to i64
  %".335" = shl i64 %".334", 32
  %"shf_concat.6" = or i64 %".333", %".335"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".336" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".336", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".337" = zext i32 %"imad.12" to i64
  %".338" = zext i32 0 to i64
  %".339" = shl i64 %".338", 32
  %"shf_concat.7" = or i64 %".337", %".339"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".340" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".340" to i32
  %".341" = xor i32 %"lds.3", -1
  %".342" = xor i32 %"shf_result.7", -1
  %".343" = xor i32 0, -1
  %".344" = and i32 %"lds.3", %"shf_result.7"
  %".345" = and i32 %".344", %".343"
  %".346" = and i32 %"lds.3", %"shf_result.7"
  %".347" = and i32 %".346", 0
  %".348" = or i32 %".345", %".347"
  %"isetrp_cmp1.5" = icmp ne i32 %".348", %"shf_result.7"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0ab0"
BB_0ab0:
  %"cond_trunc.15" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0c10_0ca0", label %"BB_0ac0"
BB_0ac0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".323", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".351" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".351" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".352" = xor i32 %"lds.4", -1
  %".353" = xor i32 %"shf_result.7", -1
  %".354" = xor i32 0, -1
  %".355" = and i32 %"lds.4", %"shf_result.7"
  %".356" = and i32 %".355", %".354"
  %".357" = and i32 %"lds.4", %"shf_result.7"
  %".358" = and i32 %".357", 0
  %".359" = or i32 %".356", %".358"
  %"isetrp_cmp1.6" = icmp ne i32 %".359", %"shf_result.7"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0af0"
BB_0af0:
  %"cond_trunc.16" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0be0_0c70", label %"BB_0b00"
BB_0b00:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".362" = xor i32 0, -1
  %".363" = xor i32 %"shf_result.7", -1
  %".364" = xor i32 0, -1
  %".365" = and i32 %".362", %".363"
  %".366" = and i32 %".365", %".364"
  %".367" = and i32 %".362", %".363"
  %".368" = and i32 %".367", 0
  %".369" = or i32 %".366", %".368"
  %".370" = and i32 0, %".363"
  %".371" = and i32 %".370", %".364"
  %".372" = or i32 %".369", %".371"
  %".373" = and i32 0, %".363"
  %".374" = and i32 %".373", 0
  %".375" = or i32 %".372", %".374"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", %".375"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.13", i32 %"redux_mask")
  %".376" = xor i32 %".375", -1
  %".377" = call i32 @"llvm.cttz.i32"(i32 %".376", i1 0)
  %".378" = shl i32 %".377", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".378") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", %"redux_sync_and"
  br label %"BB_0ba0"
BB_0ba0:
  %"cond_trunc.17" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000ba0", label %"BB_0c20"
BB_80000ba0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".323", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".382" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".382" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.14" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".323", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".383" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".383" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.14" monotonic
  br label %"BB_0c20"
BB_0be0_0c70:
  call void @"llvm.trap"()
  br label %"BB_0c20"
BB_0c10_0ca0:
  call void @"llvm.trap"()
  br label %"BB_0c20"
BB_0c20:
  ret void
BB_800009f0:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4, !5, !6, !7 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case6EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case5EEvPKjPj", !"kernel", i32 1 }
!3 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case4EEvPKjPj", !"kernel", i32 1 }
!4 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!5 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
!6 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case1EEvPKjPj", !"kernel", i32 1 }
!7 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case0EEvPKjPj", !"kernel", i32 1 }
