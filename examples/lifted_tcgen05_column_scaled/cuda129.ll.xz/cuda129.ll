; ModuleID = "tcgen05_column_scaled_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [10256 x i8], align 16
define void @"_Z13column_scaledIL4Case6EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R19:R149_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R19:R149_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P25_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P19_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R10:R119_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R10:R119_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P18_to_i32", %"BB_01a0"], [%"P20_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P27_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P28_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P29_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P29_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P30_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0fb0"
BB_05f0_0fb0:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".173" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".174" = bitcast i8* %".173" to i64*
  %"ldc_const.1" = load i64, i64* %".174"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 10
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R130:R107_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R130:R107_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R130:R107_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R130:R107_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R130:R107_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R130:R107_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R130:R107_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R130:R107_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.7"
  %"ldg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.10", 9248
  %"R130:R107_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.11", 9252
  %"R130:R107_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R130:R107_addr_ptr.9"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".175" = xor i32 %"imad.11", -1
  %".176" = xor i32 65011712, -1
  %".177" = xor i32 0, -1
  %".178" = and i32 %"imad.11", 65011712
  %".179" = and i32 %".178", %".177"
  %".180" = and i32 %"imad.11", 65011712
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".184" = zext i32 1024 to i64
  %".185" = zext i32 24 to i64
  %".186" = shl i64 %".183", %".185"
  %".187" = and i64 %".186", 4294967295
  %".188" = add i64 %".187", %".184"
  %".189" = trunc i64 %".188" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".190" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".182"
  %"R7:R6_r0" = trunc i64 0 to i32
  %"R7:R6_r1_shift" = lshr i64 0, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.10", i32 %"ldg.11", i32 %"R7:R6_r0", i32 %"R7:R6_r1")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0870"
BB_0870:
  %"cond_trunc.11" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a60", label %"BB_0880"
BB_0880:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".198" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".198" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".199" = xor i32 %"plop3_a_bit.2", 1
  %".200" = xor i32 %"plop3_b_bit.2", 1
  %".201" = xor i32 %"plop3_c_bit.2", 1
  %".202" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".203" = and i32 %".202", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".203", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".204" = zext i32 0 to i64
  %".205" = zext i32 %".189" to i64
  %".206" = shl i64 %".205", 32
  %"shf_concat.4" = or i64 %".204", %".206"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".207" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".207", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".208" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".209" = zext i32 %"iadd3_n2.3" to i64
  %".210" = zext i32 24 to i64
  %".211" = shl i64 %".208", %".210"
  %".212" = and i64 %".211", 4294967295
  %".213" = add i64 %".212", %".209"
  %".214" = trunc i64 %".213" to i32
  %".215" = xor i32 %"shf_result.4", -1
  %".216" = xor i32 16376, -1
  %".217" = xor i32 0, -1
  %".218" = and i32 %"shf_result.4", 16376
  %".219" = and i32 %".218", %".217"
  %".220" = and i32 %"shf_result.4", 16376
  %".221" = and i32 %".220", 0
  %".222" = or i32 %".219", %".221"
  %".223" = zext i32 0 to i64
  %".224" = zext i32 %".214" to i64
  %".225" = shl i64 %".224", 32
  %"shf_concat.5" = or i64 %".223", %".225"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".226" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".226", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".227" = xor i32 %".222", -1
  %".228" = xor i32 524288, -1
  %".229" = xor i32 0, -1
  %".230" = and i32 %".227", 524288
  %".231" = and i32 %".230", %".229"
  %".232" = and i32 %".227", 524288
  %".233" = and i32 %".232", 0
  %".234" = or i32 %".231", %".233"
  %".235" = and i32 %".222", %".228"
  %".236" = and i32 %".235", %".229"
  %".237" = or i32 %".234", %".236"
  %".238" = and i32 %".222", %".228"
  %".239" = and i32 %".238", 0
  %".240" = or i32 %".237", %".239"
  %".241" = and i32 %".222", 524288
  %".242" = and i32 %".241", %".229"
  %".243" = or i32 %".240", %".242"
  %".244" = and i32 %".222", 524288
  %".245" = and i32 %".244", 0
  %".246" = or i32 %".243", %".245"
  %".247" = xor i32 %"shf_result.5", -1
  %".248" = xor i32 16376, -1
  %".249" = xor i32 0, -1
  %".250" = and i32 %"shf_result.5", 16376
  %".251" = and i32 %".250", %".249"
  %".252" = and i32 %"shf_result.5", 16376
  %".253" = and i32 %".252", 0
  %".254" = or i32 %".251", %".253"
  %".255" = xor i32 %".254", -1
  %".256" = xor i32 524288, -1
  %".257" = xor i32 0, -1
  %".258" = and i32 %".255", 524288
  %".259" = and i32 %".258", %".257"
  %".260" = and i32 %".255", 524288
  %".261" = and i32 %".260", 0
  %".262" = or i32 %".259", %".261"
  %".263" = and i32 %".254", %".256"
  %".264" = and i32 %".263", %".257"
  %".265" = or i32 %".262", %".264"
  %".266" = and i32 %".254", %".256"
  %".267" = and i32 %".266", 0
  %".268" = or i32 %".265", %".267"
  %".269" = and i32 %".254", 524288
  %".270" = and i32 %".269", %".257"
  %".271" = or i32 %".268", %".270"
  %".272" = and i32 %".254", 524288
  %".273" = and i32 %".272", 0
  %".274" = or i32 %".271", %".273"
  %"iadd3_n1.4" = add i32 %"lds.2", 24
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 16
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.2", 20
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  br label %"BB_0990"
BB_0990:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0880"], [%"P9_to_i32", %"BB_09c0"]
  %"phi.16" = phi  i32 [%"P33_to_i32", %"BB_0880"], [%"phi.18", %"BB_09c0"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.17" = phi  i32 [%"P24_to_i32", %"BB_80000990"], [%"phi.15", %"BB_0990"]
  %"mma_a_r0_ext" = zext i32 %".246" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".278" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".279" = sub i64 %".278", 0
  %".280" = lshr i64 %".279", 4
  %".281" = add i64 %"mma_a_packed_1", %".280"
  %".282" = and i64 %".281", 16383
  %".283" = and i64 %"mma_a_packed_1", -16384
  %".284" = or i64 %".283", %".282"
  %"mma_b_r0_ext" = zext i32 %".274" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16416 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".285" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".286" = sub i64 %".285", 0
  %".287" = lshr i64 %".286", 4
  %".288" = add i64 %"mma_b_packed_1", %".287"
  %".289" = and i64 %".288", 16383
  %".290" = and i64 %"mma_b_packed_1", -16384
  %".291" = or i64 %".290", %".289"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.sp.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], $1, $2, [$5], $3, [$6], [$7], use_d; } }", "r,l,l,r,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".284", i64 %".291", i32 134481028, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5", i32 %"iadd3_n2.6")
  br label %"BB_09b0"
BB_09b0:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".295" = xor i32 %"plop3_a_bit.3", 1
  %".296" = xor i32 %"plop3_b_bit.3", 1
  %".297" = xor i32 %"plop3_c_bit.3", 1
  %".298" = and i32 %".295", %"plop3_b_bit.3"
  %".299" = and i32 %".298", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".299", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.18" = phi  i32 [%"P7_to_i32", %"BB_800009b0"], [%"phi.16", %"BB_09b0"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".301" = xor i32 %"plop3_a_bit.4", 1
  %".302" = xor i32 %"plop3_b_bit.4", 1
  %".303" = xor i32 %"plop3_c_bit.4", 1
  %".304" = and i32 %".301", %"plop3_b_bit.4"
  %".305" = and i32 %".304", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".305", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0990", label %"BB_09e0"
BB_09e0:
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".307" = xor i32 %"plop3_a_bit.5", 1
  %".308" = xor i32 %"plop3_b_bit.5", 1
  %".309" = xor i32 %"plop3_c_bit.5", 1
  %".310" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".311" = and i32 %".310", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".311", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".312" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".313" = zext i32 %"iadd3_n2.7" to i64
  %".314" = zext i32 24 to i64
  %".315" = shl i64 %".312", %".314"
  %".316" = and i64 %".315", 4294967295
  %".317" = add i64 %".316", %".313"
  %".318" = trunc i64 %".317" to i32
  br label %"BB_0a10"
BB_0a10:
  %"phi.19" = phi  i32 [%"P9_to_i32", %"BB_09e0"], [%"P15_to_i32", %"BB_0a40"]
  %"phi.20" = phi  i32 [%"P31_to_i32", %"BB_09e0"], [%"phi.22", %"BB_0a40"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.21" = phi  i32 [%"P13_to_i32", %"BB_80000a10"], [%"phi.19", %"BB_0a10"]
  %"utcbar_local_winoff" = and i32 %".318", 16777215
  %".322" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".323" = ptrtoint i8 addrspace(3)* %".322" to i32
  %".324" = lshr i32 %".318", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".323", i32 %".324")
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000a30", label %"BB_0a40"
BB_80000a30:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".328" = xor i32 %"plop3_a_bit.6", 1
  %".329" = xor i32 %"plop3_b_bit.6", 1
  %".330" = xor i32 %"plop3_c_bit.6", 1
  %".331" = and i32 %".328", %"plop3_b_bit.6"
  %".332" = and i32 %".331", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".332", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.22" = phi  i32 [%"P36_to_i32", %"BB_80000a30"], [%"phi.20", %"BB_0a30"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".334" = xor i32 %"plop3_a_bit.7", 1
  %".335" = xor i32 %"plop3_b_bit.7", 1
  %".336" = xor i32 %"plop3_c_bit.7", 1
  %".337" = and i32 %".334", %"plop3_b_bit.7"
  %".338" = and i32 %".337", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".338", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0a10", label %"BB_0a60"
BB_0a60:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.8" = add i32 1024, 9216
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".340" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".341" = zext i32 %"iadd3_n2.8" to i64
  %".342" = zext i32 24 to i64
  %".343" = shl i64 %".340", %".342"
  %".344" = and i64 %".343", 4294967295
  %".345" = add i64 %".344", %".341"
  %".346" = trunc i64 %".345" to i32
  %"mbar_shared_winoff.1" = and i32 %".346", 16777215
  %".347" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".347" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0ab0"
BB_0ab0:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0f50", label %"BB_0ac0"
BB_0f50:
  %"mbar_shared_winoff.2" = and i32 %".346", 16777215
  %".350" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".350" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f60"
BB_0f60:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f50", label %"BB_0ac0"
BB_0ac0:
  %".353" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".354" = bitcast i8* %".353" to i64*
  %"ldc_const.2" = load i64, i64* %".354"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R132:R110_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R132:R110_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R132:R110_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R132:R110_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R132:R110_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R132:R110_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R132:R110_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R132:R110_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R132:R110_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R132:R110_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".368" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".371" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R132:R110_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R132:R110_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R132:R110_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R132:R110_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R132:R110_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R132:R110_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R132:R110_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".368", i32 addrspace(1)* %"R132:R110_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R132:R110_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R132:R110_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R132:R110_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R132:R110_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R132:R110_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".371", i32 addrspace(1)* %"R132:R110_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R132:R110_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R132:R110_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R132:R110_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R132:R110_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R132:R110_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R132:R110_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R132:R110_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R132:R110_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0cc0"
BB_0cc0:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000cc0", label %"BB_0cd0"
BB_0cd0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".389" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".389" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".390" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".391" = zext i32 80 to i64
  %".392" = zext i32 24 to i64
  %".393" = shl i64 %".390", %".392"
  %".394" = and i64 %".393", 4294967295
  %".395" = add i64 %".394", %".391"
  %".396" = trunc i64 %".395" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".396", 16777215
  %".397" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".397" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".398" = xor i32 %"lds.3", -1
  %".399" = xor i32 65535, -1
  %".400" = xor i32 0, -1
  %".401" = and i32 %"lds.3", 65535
  %".402" = and i32 %".401", %".400"
  %".403" = and i32 %"lds.3", 65535
  %".404" = and i32 %".403", 0
  %".405" = or i32 %".402", %".404"
  %".406" = zext i32 0 to i64
  %".407" = zext i32 %".405" to i64
  %".408" = shl i64 %".407", 32
  %"shf_concat.6" = or i64 %".406", %".408"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".409" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".409", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".410" = zext i32 %"imad.15" to i64
  %".411" = zext i32 0 to i64
  %".412" = shl i64 %".411", 32
  %"shf_concat.7" = or i64 %".410", %".412"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".413" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".413" to i32
  %".414" = zext i32 %"imad.15" to i64
  %".415" = zext i32 0 to i64
  %".416" = shl i64 %".415", 32
  %"shf_concat.8" = or i64 %".414", %".416"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".417" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".417" to i32
  %".418" = xor i32 %"shf_result.8", -1
  %".419" = xor i32 %"shf_result.7", -1
  %".420" = xor i32 0, -1
  %".421" = and i32 %".418", %"shf_result.7"
  %".422" = and i32 %".421", %".420"
  %".423" = and i32 %".418", %"shf_result.7"
  %".424" = and i32 %".423", 0
  %".425" = or i32 %".422", %".424"
  %".426" = and i32 %"shf_result.8", %".419"
  %".427" = and i32 %".426", %".420"
  %".428" = or i32 %".425", %".427"
  %".429" = and i32 %"shf_result.8", %".419"
  %".430" = and i32 %".429", 0
  %".431" = or i32 %".428", %".430"
  %".432" = and i32 %"shf_result.8", %"shf_result.7"
  %".433" = and i32 %".432", %".420"
  %".434" = or i32 %".431", %".433"
  %".435" = and i32 %"shf_result.8", %"shf_result.7"
  %".436" = and i32 %".435", 0
  %".437" = or i32 %".434", %".436"
  %".438" = xor i32 %".437", -1
  %".439" = xor i32 65535, -1
  %".440" = xor i32 0, -1
  %".441" = and i32 %".437", 65535
  %".442" = and i32 %".441", %".440"
  %".443" = and i32 %".437", 65535
  %".444" = and i32 %".443", 0
  %".445" = or i32 %".442", %".444"
  %".446" = xor i32 %".437", -1
  %".447" = xor i32 65535, -1
  %".448" = xor i32 %"lds.4", -1
  %".449" = and i32 %".437", 65535
  %".450" = and i32 %".449", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".450", %".445"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.19" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0f20_0fe0", label %"BB_0dd0"
BB_0dd0:
  %".453" = zext i32 0 to i64
  %".454" = zext i32 %"lds.4" to i64
  %".455" = shl i64 %".454", 32
  %"shf_concat.9" = or i64 %".453", %".455"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".456" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".456", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".457" = zext i32 0 to i64
  %".458" = zext i32 %".437" to i64
  %".459" = shl i64 %".458", 32
  %"shf_concat.10" = or i64 %".457", %".459"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".460" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".460", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".461" = xor i32 %"shf_result.9", -1
  %".462" = xor i32 %"shf_result.10", -1
  %".463" = xor i32 0, -1
  %".464" = and i32 %"shf_result.9", %"shf_result.10"
  %".465" = and i32 %".464", %".463"
  %".466" = and i32 %"shf_result.9", %"shf_result.10"
  %".467" = and i32 %".466", 0
  %".468" = or i32 %".465", %".467"
  %"isetrp_cmp1.11" = icmp ne i32 %".468", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0e10"
BB_0e10:
  %"cond_trunc.20" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0ef0_0f80", label %"BB_0e20"
BB_0e20:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".471" = xor i32 0, -1
  %".472" = xor i32 %".437", -1
  %".473" = xor i32 0, -1
  %".474" = and i32 %".471", %".472"
  %".475" = and i32 %".474", %".473"
  %".476" = and i32 %".471", %".472"
  %".477" = and i32 %".476", 0
  %".478" = or i32 %".475", %".477"
  %".479" = and i32 0, %".472"
  %".480" = and i32 %".479", %".473"
  %".481" = or i32 %".478", %".480"
  %".482" = and i32 0, %".472"
  %".483" = and i32 %".482", 0
  %".484" = or i32 %".481", %".483"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".484"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask")
  %".485" = xor i32 %".484", -1
  %".486" = call i32 @"llvm.cttz.i32"(i32 %".485", i1 0)
  %".487" = shl i32 %".486", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".487") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  br label %"BB_0ec0"
BB_0ec0:
  %"cond_trunc.21" = trunc i32 %"P41_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000ec0", label %"BB_0f30"
BB_80000ec0:
  %"atoms_shared_addr_winoff.1" = and i32 %".396", 16777215
  %".491" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".491" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.17" monotonic
  br label %"BB_0f30"
BB_0ef0_0f80:
  call void @"llvm.trap"()
  br label %"BB_0f30"
BB_0f20_0fe0:
  call void @"llvm.trap"()
  br label %"BB_0f30"
BB_0f30:
  ret void
BB_80000cc0:
  ret void
}

define void @"_Z13column_scaledIL4Case5EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R9:R136_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R9:R136_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P25_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P19_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R153:R108_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R153:R108_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P18_to_i32", %"BB_01a0"], [%"P20_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P27_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P28_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P29_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P29_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P30_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0f60"
BB_05f0_0f60:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".173" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".174" = bitcast i8* %".173" to i64*
  %"ldc_const.1" = load i64, i64* %".174"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 10
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R118:R95_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R118:R95_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R118:R95_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R118:R95_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R118:R95_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R118:R95_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R118:R95_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R118:R95_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".175" = xor i32 %"imad.11", -1
  %".176" = xor i32 65011712, -1
  %".177" = xor i32 0, -1
  %".178" = and i32 %"imad.11", 65011712
  %".179" = and i32 %".178", %".177"
  %".180" = and i32 %"imad.11", 65011712
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".184" = zext i32 1024 to i64
  %".185" = zext i32 24 to i64
  %".186" = shl i64 %".183", %".185"
  %".187" = and i64 %".186", 4294967295
  %".188" = add i64 %".187", %".184"
  %".189" = trunc i64 %".188" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".190" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".182"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0820"
BB_0820:
  %"cond_trunc.11" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a10", label %"BB_0830"
BB_0830:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".197" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".197" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".198" = xor i32 %"plop3_a_bit.2", 1
  %".199" = xor i32 %"plop3_b_bit.2", 1
  %".200" = xor i32 %"plop3_c_bit.2", 1
  %".201" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".202" = and i32 %".201", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".202", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".203" = zext i32 0 to i64
  %".204" = zext i32 %".189" to i64
  %".205" = shl i64 %".204", 32
  %"shf_concat.4" = or i64 %".203", %".205"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".206" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".206", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".207" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".208" = zext i32 %"iadd3_n2.3" to i64
  %".209" = zext i32 24 to i64
  %".210" = shl i64 %".207", %".209"
  %".211" = and i64 %".210", 4294967295
  %".212" = add i64 %".211", %".208"
  %".213" = trunc i64 %".212" to i32
  %".214" = xor i32 %"shf_result.4", -1
  %".215" = xor i32 16376, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %"shf_result.4", 16376
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %"shf_result.4", 16376
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = zext i32 0 to i64
  %".223" = zext i32 %".213" to i64
  %".224" = shl i64 %".223", 32
  %"shf_concat.5" = or i64 %".222", %".224"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".225" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".225", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".226" = xor i32 %".221", -1
  %".227" = xor i32 524288, -1
  %".228" = xor i32 0, -1
  %".229" = and i32 %".226", 524288
  %".230" = and i32 %".229", %".228"
  %".231" = and i32 %".226", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %".234" = and i32 %".221", %".227"
  %".235" = and i32 %".234", %".228"
  %".236" = or i32 %".233", %".235"
  %".237" = and i32 %".221", %".227"
  %".238" = and i32 %".237", 0
  %".239" = or i32 %".236", %".238"
  %".240" = and i32 %".221", 524288
  %".241" = and i32 %".240", %".228"
  %".242" = or i32 %".239", %".241"
  %".243" = and i32 %".221", 524288
  %".244" = and i32 %".243", 0
  %".245" = or i32 %".242", %".244"
  %".246" = xor i32 %"shf_result.5", -1
  %".247" = xor i32 16376, -1
  %".248" = xor i32 0, -1
  %".249" = and i32 %"shf_result.5", 16376
  %".250" = and i32 %".249", %".248"
  %".251" = and i32 %"shf_result.5", 16376
  %".252" = and i32 %".251", 0
  %".253" = or i32 %".250", %".252"
  %".254" = xor i32 %".253", -1
  %".255" = xor i32 524288, -1
  %".256" = xor i32 0, -1
  %".257" = and i32 %".254", 524288
  %".258" = and i32 %".257", %".256"
  %".259" = and i32 %".254", 524288
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = and i32 %".253", %".255"
  %".263" = and i32 %".262", %".256"
  %".264" = or i32 %".261", %".263"
  %".265" = and i32 %".253", %".255"
  %".266" = and i32 %".265", 0
  %".267" = or i32 %".264", %".266"
  %".268" = and i32 %".253", 524288
  %".269" = and i32 %".268", %".256"
  %".270" = or i32 %".267", %".269"
  %".271" = and i32 %".253", 524288
  %".272" = and i32 %".271", 0
  %".273" = or i32 %".270", %".272"
  %"iadd3_n1.4" = add i32 %"lds.2", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0940"
BB_0940:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0830"], [%"P9_to_i32", %"BB_0970"]
  %"phi.16" = phi  i32 [%"P33_to_i32", %"BB_0830"], [%"phi.18", %"BB_0970"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000940", label %"BB_0950"
BB_80000940:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0950"
BB_0950:
  %"phi.17" = phi  i32 [%"P24_to_i32", %"BB_80000940"], [%"phi.15", %"BB_0940"]
  %"mma_a_r0_ext" = zext i32 %".245" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".277" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".278" = sub i64 %".277", 0
  %".279" = lshr i64 %".278", 4
  %".280" = add i64 %"mma_a_packed_1", %".279"
  %".281" = and i64 %".280", 16383
  %".282" = and i64 %"mma_a_packed_1", -16384
  %".283" = or i64 %".282", %".281"
  %"mma_b_r0_ext" = zext i32 %".273" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".284" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".285" = sub i64 %".284", 0
  %".286" = lshr i64 %".285", 4
  %".287" = add i64 %"mma_b_packed_1", %".286"
  %".288" = and i64 %".287", 16383
  %".289" = and i64 %"mma_b_packed_1", -16384
  %".290" = or i64 %".289", %".288"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".283", i64 %".290", i32 134481024, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".294" = xor i32 %"plop3_a_bit.3", 1
  %".295" = xor i32 %"plop3_b_bit.3", 1
  %".296" = xor i32 %"plop3_c_bit.3", 1
  %".297" = and i32 %".294", %"plop3_b_bit.3"
  %".298" = and i32 %".297", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".298", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.18" = phi  i32 [%"P7_to_i32", %"BB_80000960"], [%"phi.16", %"BB_0960"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".300" = xor i32 %"plop3_a_bit.4", 1
  %".301" = xor i32 %"plop3_b_bit.4", 1
  %".302" = xor i32 %"plop3_c_bit.4", 1
  %".303" = and i32 %".300", %"plop3_b_bit.4"
  %".304" = and i32 %".303", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".304", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0940", label %"BB_0990"
BB_0990:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".306" = xor i32 %"plop3_a_bit.5", 1
  %".307" = xor i32 %"plop3_b_bit.5", 1
  %".308" = xor i32 %"plop3_c_bit.5", 1
  %".309" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".310" = and i32 %".309", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".310", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".311" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".312" = zext i32 %"iadd3_n2.6" to i64
  %".313" = zext i32 24 to i64
  %".314" = shl i64 %".311", %".313"
  %".315" = and i64 %".314", 4294967295
  %".316" = add i64 %".315", %".312"
  %".317" = trunc i64 %".316" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.19" = phi  i32 [%"P9_to_i32", %"BB_0990"], [%"P15_to_i32", %"BB_09f0"]
  %"phi.20" = phi  i32 [%"P31_to_i32", %"BB_0990"], [%"phi.22", %"BB_09f0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009c0", label %"BB_09d0"
BB_800009c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09d0"
BB_09d0:
  %"phi.21" = phi  i32 [%"P13_to_i32", %"BB_800009c0"], [%"phi.19", %"BB_09c0"]
  %"utcbar_local_winoff" = and i32 %".317", 16777215
  %".321" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".322" = ptrtoint i8 addrspace(3)* %".321" to i32
  %".323" = lshr i32 %".317", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".322", i32 %".323")
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".327" = xor i32 %"plop3_a_bit.6", 1
  %".328" = xor i32 %"plop3_b_bit.6", 1
  %".329" = xor i32 %"plop3_c_bit.6", 1
  %".330" = and i32 %".327", %"plop3_b_bit.6"
  %".331" = and i32 %".330", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".331", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.22" = phi  i32 [%"P36_to_i32", %"BB_800009e0"], [%"phi.20", %"BB_09e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".333" = xor i32 %"plop3_a_bit.7", 1
  %".334" = xor i32 %"plop3_b_bit.7", 1
  %".335" = xor i32 %"plop3_c_bit.7", 1
  %".336" = and i32 %".333", %"plop3_b_bit.7"
  %".337" = and i32 %".336", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".337", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09c0", label %"BB_0a10"
BB_0a10:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".339" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".340" = zext i32 %"iadd3_n2.7" to i64
  %".341" = zext i32 24 to i64
  %".342" = shl i64 %".339", %".341"
  %".343" = and i64 %".342", 4294967295
  %".344" = add i64 %".343", %".340"
  %".345" = trunc i64 %".344" to i32
  %"mbar_shared_winoff.1" = and i32 %".345", 16777215
  %".346" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".346" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0f00", label %"BB_0a70"
BB_0f00:
  %"mbar_shared_winoff.2" = and i32 %".345", 16777215
  %".349" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".349" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f00", label %"BB_0a70"
BB_0a70:
  %".352" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".353" = bitcast i8* %".352" to i64*
  %"ldc_const.2" = load i64, i64* %".353"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R120:R100_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R120:R100_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R120:R100_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R120:R100_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R120:R100_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R120:R100_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R120:R100_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R120:R100_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R120:R100_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R120:R100_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".367" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".368" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R120:R100_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R120:R100_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R120:R100_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R120:R100_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R120:R100_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R120:R100_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R120:R100_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".367", i32 addrspace(1)* %"R120:R100_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R120:R100_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".368", i32 addrspace(1)* %"R120:R100_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R120:R100_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R120:R100_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R120:R100_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R120:R100_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R120:R100_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R120:R100_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R120:R100_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R120:R100_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R120:R100_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R120:R100_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R120:R100_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R120:R100_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c70"
BB_0c70:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c70", label %"BB_0c80"
BB_0c80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".388" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".388" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".389" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".390" = zext i32 80 to i64
  %".391" = zext i32 24 to i64
  %".392" = shl i64 %".389", %".391"
  %".393" = and i64 %".392", 4294967295
  %".394" = add i64 %".393", %".390"
  %".395" = trunc i64 %".394" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".395", 16777215
  %".396" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".397" = xor i32 %"lds.3", -1
  %".398" = xor i32 65535, -1
  %".399" = xor i32 0, -1
  %".400" = and i32 %"lds.3", 65535
  %".401" = and i32 %".400", %".399"
  %".402" = and i32 %"lds.3", 65535
  %".403" = and i32 %".402", 0
  %".404" = or i32 %".401", %".403"
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %".404" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.6" = or i64 %".405", %".407"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".408" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".409" = zext i32 %"imad.15" to i64
  %".410" = zext i32 0 to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.7" = or i64 %".409", %".411"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".412" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".412" to i32
  %".413" = zext i32 %"imad.15" to i64
  %".414" = zext i32 0 to i64
  %".415" = shl i64 %".414", 32
  %"shf_concat.8" = or i64 %".413", %".415"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".416" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".416" to i32
  %".417" = xor i32 %"shf_result.8", -1
  %".418" = xor i32 %"shf_result.7", -1
  %".419" = xor i32 0, -1
  %".420" = and i32 %".417", %"shf_result.7"
  %".421" = and i32 %".420", %".419"
  %".422" = and i32 %".417", %"shf_result.7"
  %".423" = and i32 %".422", 0
  %".424" = or i32 %".421", %".423"
  %".425" = and i32 %"shf_result.8", %".418"
  %".426" = and i32 %".425", %".419"
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 %"shf_result.8", %".418"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 %"shf_result.8", %"shf_result.7"
  %".432" = and i32 %".431", %".419"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 %"shf_result.8", %"shf_result.7"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %".437" = xor i32 %".436", -1
  %".438" = xor i32 65535, -1
  %".439" = xor i32 0, -1
  %".440" = and i32 %".436", 65535
  %".441" = and i32 %".440", %".439"
  %".442" = and i32 %".436", 65535
  %".443" = and i32 %".442", 0
  %".444" = or i32 %".441", %".443"
  %".445" = xor i32 %".436", -1
  %".446" = xor i32 65535, -1
  %".447" = xor i32 %"lds.4", -1
  %".448" = and i32 %".436", 65535
  %".449" = and i32 %".448", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".449", %".444"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0d70"
BB_0d70:
  %"cond_trunc.19" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0ed0_0f90", label %"BB_0d80"
BB_0d80:
  %".452" = zext i32 0 to i64
  %".453" = zext i32 %"lds.4" to i64
  %".454" = shl i64 %".453", 32
  %"shf_concat.9" = or i64 %".452", %".454"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".455" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".455", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".456" = zext i32 0 to i64
  %".457" = zext i32 %".436" to i64
  %".458" = shl i64 %".457", 32
  %"shf_concat.10" = or i64 %".456", %".458"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".459" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".459", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".460" = xor i32 %"shf_result.9", -1
  %".461" = xor i32 %"shf_result.10", -1
  %".462" = xor i32 0, -1
  %".463" = and i32 %"shf_result.9", %"shf_result.10"
  %".464" = and i32 %".463", %".462"
  %".465" = and i32 %"shf_result.9", %"shf_result.10"
  %".466" = and i32 %".465", 0
  %".467" = or i32 %".464", %".466"
  %"isetrp_cmp1.11" = icmp ne i32 %".467", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.20" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0ea0_0f30", label %"BB_0dd0"
BB_0dd0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".470" = xor i32 0, -1
  %".471" = xor i32 %".436", -1
  %".472" = xor i32 0, -1
  %".473" = and i32 %".470", %".471"
  %".474" = and i32 %".473", %".472"
  %".475" = and i32 %".470", %".471"
  %".476" = and i32 %".475", 0
  %".477" = or i32 %".474", %".476"
  %".478" = and i32 0, %".471"
  %".479" = and i32 %".478", %".472"
  %".480" = or i32 %".477", %".479"
  %".481" = and i32 0, %".471"
  %".482" = and i32 %".481", 0
  %".483" = or i32 %".480", %".482"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".483"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask")
  %".484" = xor i32 %".483", -1
  %".485" = call i32 @"llvm.cttz.i32"(i32 %".484", i1 0)
  %".486" = shl i32 %".485", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".486") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.21" = trunc i32 %"P41_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e70", label %"BB_0ee0"
BB_80000e70:
  %"atoms_shared_addr_winoff.1" = and i32 %".395", 16777215
  %".490" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.17" monotonic
  br label %"BB_0ee0"
BB_0ea0_0f30:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ed0_0f90:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ee0:
  ret void
BB_80000c70:
  ret void
}

define void @"_Z13column_scaledIL4Case4EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R9:R136_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R9:R136_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P25_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P19_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R153:R108_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R153:R108_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P18_to_i32", %"BB_01a0"], [%"P20_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P27_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P28_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P29_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P29_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P30_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0f60"
BB_05f0_0f60:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".173" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".174" = bitcast i8* %".173" to i64*
  %"ldc_const.1" = load i64, i64* %".174"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 10
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R118:R95_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R118:R95_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R118:R95_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R118:R95_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R118:R95_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R118:R95_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R118:R95_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R118:R95_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".175" = xor i32 %"imad.11", -1
  %".176" = xor i32 65011712, -1
  %".177" = xor i32 0, -1
  %".178" = and i32 %"imad.11", 65011712
  %".179" = and i32 %".178", %".177"
  %".180" = and i32 %"imad.11", 65011712
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".184" = zext i32 1024 to i64
  %".185" = zext i32 24 to i64
  %".186" = shl i64 %".183", %".185"
  %".187" = and i64 %".186", 4294967295
  %".188" = add i64 %".187", %".184"
  %".189" = trunc i64 %".188" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".190" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".182"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0820"
BB_0820:
  %"cond_trunc.11" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a10", label %"BB_0830"
BB_0830:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".197" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".197" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".198" = xor i32 %"plop3_a_bit.2", 1
  %".199" = xor i32 %"plop3_b_bit.2", 1
  %".200" = xor i32 %"plop3_c_bit.2", 1
  %".201" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".202" = and i32 %".201", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".202", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".203" = zext i32 0 to i64
  %".204" = zext i32 %".189" to i64
  %".205" = shl i64 %".204", 32
  %"shf_concat.4" = or i64 %".203", %".205"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".206" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".206", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".207" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".208" = zext i32 %"iadd3_n2.3" to i64
  %".209" = zext i32 24 to i64
  %".210" = shl i64 %".207", %".209"
  %".211" = and i64 %".210", 4294967295
  %".212" = add i64 %".211", %".208"
  %".213" = trunc i64 %".212" to i32
  %".214" = xor i32 %"shf_result.4", -1
  %".215" = xor i32 16376, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %"shf_result.4", 16376
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %"shf_result.4", 16376
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = zext i32 0 to i64
  %".223" = zext i32 %".213" to i64
  %".224" = shl i64 %".223", 32
  %"shf_concat.5" = or i64 %".222", %".224"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".225" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".225", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".226" = xor i32 %".221", -1
  %".227" = xor i32 524288, -1
  %".228" = xor i32 0, -1
  %".229" = and i32 %".226", 524288
  %".230" = and i32 %".229", %".228"
  %".231" = and i32 %".226", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %".234" = and i32 %".221", %".227"
  %".235" = and i32 %".234", %".228"
  %".236" = or i32 %".233", %".235"
  %".237" = and i32 %".221", %".227"
  %".238" = and i32 %".237", 0
  %".239" = or i32 %".236", %".238"
  %".240" = and i32 %".221", 524288
  %".241" = and i32 %".240", %".228"
  %".242" = or i32 %".239", %".241"
  %".243" = and i32 %".221", 524288
  %".244" = and i32 %".243", 0
  %".245" = or i32 %".242", %".244"
  %".246" = xor i32 %"shf_result.5", -1
  %".247" = xor i32 16376, -1
  %".248" = xor i32 0, -1
  %".249" = and i32 %"shf_result.5", 16376
  %".250" = and i32 %".249", %".248"
  %".251" = and i32 %"shf_result.5", 16376
  %".252" = and i32 %".251", 0
  %".253" = or i32 %".250", %".252"
  %".254" = xor i32 %".253", -1
  %".255" = xor i32 524288, -1
  %".256" = xor i32 0, -1
  %".257" = and i32 %".254", 524288
  %".258" = and i32 %".257", %".256"
  %".259" = and i32 %".254", 524288
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = and i32 %".253", %".255"
  %".263" = and i32 %".262", %".256"
  %".264" = or i32 %".261", %".263"
  %".265" = and i32 %".253", %".255"
  %".266" = and i32 %".265", 0
  %".267" = or i32 %".264", %".266"
  %".268" = and i32 %".253", 524288
  %".269" = and i32 %".268", %".256"
  %".270" = or i32 %".267", %".269"
  %".271" = and i32 %".253", 524288
  %".272" = and i32 %".271", 0
  %".273" = or i32 %".270", %".272"
  %"iadd3_n1.4" = add i32 %"lds.2", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0940"
BB_0940:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0830"], [%"P9_to_i32", %"BB_0970"]
  %"phi.16" = phi  i32 [%"P33_to_i32", %"BB_0830"], [%"phi.18", %"BB_0970"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000940", label %"BB_0950"
BB_80000940:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0950"
BB_0950:
  %"phi.17" = phi  i32 [%"P24_to_i32", %"BB_80000940"], [%"phi.15", %"BB_0940"]
  %"mma_a_r0_ext" = zext i32 %".245" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".277" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".278" = sub i64 %".277", 0
  %".279" = lshr i64 %".278", 4
  %".280" = add i64 %"mma_a_packed_1", %".279"
  %".281" = and i64 %".280", 16383
  %".282" = and i64 %"mma_a_packed_1", -16384
  %".283" = or i64 %".282", %".281"
  %"mma_b_r0_ext" = zext i32 %".273" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".284" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".285" = sub i64 %".284", 0
  %".286" = lshr i64 %".285", 4
  %".287" = add i64 %"mma_b_packed_1", %".286"
  %".288" = and i64 %".287", 16383
  %".289" = and i64 %"mma_b_packed_1", -16384
  %".290" = or i64 %".289", %".288"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::2X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".283", i64 %".290", i32 1216611456, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".294" = xor i32 %"plop3_a_bit.3", 1
  %".295" = xor i32 %"plop3_b_bit.3", 1
  %".296" = xor i32 %"plop3_c_bit.3", 1
  %".297" = and i32 %".294", %"plop3_b_bit.3"
  %".298" = and i32 %".297", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".298", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.18" = phi  i32 [%"P7_to_i32", %"BB_80000960"], [%"phi.16", %"BB_0960"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".300" = xor i32 %"plop3_a_bit.4", 1
  %".301" = xor i32 %"plop3_b_bit.4", 1
  %".302" = xor i32 %"plop3_c_bit.4", 1
  %".303" = and i32 %".300", %"plop3_b_bit.4"
  %".304" = and i32 %".303", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".304", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0940", label %"BB_0990"
BB_0990:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".306" = xor i32 %"plop3_a_bit.5", 1
  %".307" = xor i32 %"plop3_b_bit.5", 1
  %".308" = xor i32 %"plop3_c_bit.5", 1
  %".309" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".310" = and i32 %".309", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".310", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".311" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".312" = zext i32 %"iadd3_n2.6" to i64
  %".313" = zext i32 24 to i64
  %".314" = shl i64 %".311", %".313"
  %".315" = and i64 %".314", 4294967295
  %".316" = add i64 %".315", %".312"
  %".317" = trunc i64 %".316" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.19" = phi  i32 [%"P9_to_i32", %"BB_0990"], [%"P15_to_i32", %"BB_09f0"]
  %"phi.20" = phi  i32 [%"P31_to_i32", %"BB_0990"], [%"phi.22", %"BB_09f0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009c0", label %"BB_09d0"
BB_800009c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09d0"
BB_09d0:
  %"phi.21" = phi  i32 [%"P13_to_i32", %"BB_800009c0"], [%"phi.19", %"BB_09c0"]
  %"utcbar_local_winoff" = and i32 %".317", 16777215
  %".321" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".322" = ptrtoint i8 addrspace(3)* %".321" to i32
  %".323" = lshr i32 %".317", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".322", i32 %".323")
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".327" = xor i32 %"plop3_a_bit.6", 1
  %".328" = xor i32 %"plop3_b_bit.6", 1
  %".329" = xor i32 %"plop3_c_bit.6", 1
  %".330" = and i32 %".327", %"plop3_b_bit.6"
  %".331" = and i32 %".330", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".331", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.22" = phi  i32 [%"P36_to_i32", %"BB_800009e0"], [%"phi.20", %"BB_09e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".333" = xor i32 %"plop3_a_bit.7", 1
  %".334" = xor i32 %"plop3_b_bit.7", 1
  %".335" = xor i32 %"plop3_c_bit.7", 1
  %".336" = and i32 %".333", %"plop3_b_bit.7"
  %".337" = and i32 %".336", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".337", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09c0", label %"BB_0a10"
BB_0a10:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".339" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".340" = zext i32 %"iadd3_n2.7" to i64
  %".341" = zext i32 24 to i64
  %".342" = shl i64 %".339", %".341"
  %".343" = and i64 %".342", 4294967295
  %".344" = add i64 %".343", %".340"
  %".345" = trunc i64 %".344" to i32
  %"mbar_shared_winoff.1" = and i32 %".345", 16777215
  %".346" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".346" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0f00", label %"BB_0a70"
BB_0f00:
  %"mbar_shared_winoff.2" = and i32 %".345", 16777215
  %".349" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".349" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f00", label %"BB_0a70"
BB_0a70:
  %".352" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".353" = bitcast i8* %".352" to i64*
  %"ldc_const.2" = load i64, i64* %".353"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R120:R100_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R120:R100_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R120:R100_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R120:R100_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R120:R100_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R120:R100_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R120:R100_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R120:R100_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R120:R100_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R120:R100_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".367" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".368" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R120:R100_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R120:R100_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R120:R100_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R120:R100_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R120:R100_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R120:R100_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R120:R100_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".367", i32 addrspace(1)* %"R120:R100_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R120:R100_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".368", i32 addrspace(1)* %"R120:R100_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R120:R100_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R120:R100_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R120:R100_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R120:R100_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R120:R100_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R120:R100_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R120:R100_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R120:R100_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R120:R100_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R120:R100_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R120:R100_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R120:R100_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c70"
BB_0c70:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c70", label %"BB_0c80"
BB_0c80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".388" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".388" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".389" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".390" = zext i32 80 to i64
  %".391" = zext i32 24 to i64
  %".392" = shl i64 %".389", %".391"
  %".393" = and i64 %".392", 4294967295
  %".394" = add i64 %".393", %".390"
  %".395" = trunc i64 %".394" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".395", 16777215
  %".396" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".397" = xor i32 %"lds.3", -1
  %".398" = xor i32 65535, -1
  %".399" = xor i32 0, -1
  %".400" = and i32 %"lds.3", 65535
  %".401" = and i32 %".400", %".399"
  %".402" = and i32 %"lds.3", 65535
  %".403" = and i32 %".402", 0
  %".404" = or i32 %".401", %".403"
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %".404" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.6" = or i64 %".405", %".407"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".408" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".409" = zext i32 %"imad.15" to i64
  %".410" = zext i32 0 to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.7" = or i64 %".409", %".411"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".412" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".412" to i32
  %".413" = zext i32 %"imad.15" to i64
  %".414" = zext i32 0 to i64
  %".415" = shl i64 %".414", 32
  %"shf_concat.8" = or i64 %".413", %".415"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".416" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".416" to i32
  %".417" = xor i32 %"shf_result.8", -1
  %".418" = xor i32 %"shf_result.7", -1
  %".419" = xor i32 0, -1
  %".420" = and i32 %".417", %"shf_result.7"
  %".421" = and i32 %".420", %".419"
  %".422" = and i32 %".417", %"shf_result.7"
  %".423" = and i32 %".422", 0
  %".424" = or i32 %".421", %".423"
  %".425" = and i32 %"shf_result.8", %".418"
  %".426" = and i32 %".425", %".419"
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 %"shf_result.8", %".418"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 %"shf_result.8", %"shf_result.7"
  %".432" = and i32 %".431", %".419"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 %"shf_result.8", %"shf_result.7"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %".437" = xor i32 %".436", -1
  %".438" = xor i32 65535, -1
  %".439" = xor i32 0, -1
  %".440" = and i32 %".436", 65535
  %".441" = and i32 %".440", %".439"
  %".442" = and i32 %".436", 65535
  %".443" = and i32 %".442", 0
  %".444" = or i32 %".441", %".443"
  %".445" = xor i32 %".436", -1
  %".446" = xor i32 65535, -1
  %".447" = xor i32 %"lds.4", -1
  %".448" = and i32 %".436", 65535
  %".449" = and i32 %".448", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".449", %".444"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0d70"
BB_0d70:
  %"cond_trunc.19" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0ed0_0f90", label %"BB_0d80"
BB_0d80:
  %".452" = zext i32 0 to i64
  %".453" = zext i32 %"lds.4" to i64
  %".454" = shl i64 %".453", 32
  %"shf_concat.9" = or i64 %".452", %".454"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".455" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".455", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".456" = zext i32 0 to i64
  %".457" = zext i32 %".436" to i64
  %".458" = shl i64 %".457", 32
  %"shf_concat.10" = or i64 %".456", %".458"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".459" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".459", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".460" = xor i32 %"shf_result.9", -1
  %".461" = xor i32 %"shf_result.10", -1
  %".462" = xor i32 0, -1
  %".463" = and i32 %"shf_result.9", %"shf_result.10"
  %".464" = and i32 %".463", %".462"
  %".465" = and i32 %"shf_result.9", %"shf_result.10"
  %".466" = and i32 %".465", 0
  %".467" = or i32 %".464", %".466"
  %"isetrp_cmp1.11" = icmp ne i32 %".467", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.20" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0ea0_0f30", label %"BB_0dd0"
BB_0dd0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".470" = xor i32 0, -1
  %".471" = xor i32 %".436", -1
  %".472" = xor i32 0, -1
  %".473" = and i32 %".470", %".471"
  %".474" = and i32 %".473", %".472"
  %".475" = and i32 %".470", %".471"
  %".476" = and i32 %".475", 0
  %".477" = or i32 %".474", %".476"
  %".478" = and i32 0, %".471"
  %".479" = and i32 %".478", %".472"
  %".480" = or i32 %".477", %".479"
  %".481" = and i32 0, %".471"
  %".482" = and i32 %".481", 0
  %".483" = or i32 %".480", %".482"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".483"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask")
  %".484" = xor i32 %".483", -1
  %".485" = call i32 @"llvm.cttz.i32"(i32 %".484", i1 0)
  %".486" = shl i32 %".485", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".486") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.21" = trunc i32 %"P41_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e70", label %"BB_0ee0"
BB_80000e70:
  %"atoms_shared_addr_winoff.1" = and i32 %".395", 16777215
  %".490" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.17" monotonic
  br label %"BB_0ee0"
BB_0ea0_0f30:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ed0_0f90:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ee0:
  ret void
BB_80000c70:
  ret void
}

define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R9:R136_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R9:R136_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P25_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P19_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R153:R108_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R153:R108_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P18_to_i32", %"BB_01a0"], [%"P20_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P27_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P28_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P29_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P29_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P30_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0f60"
BB_05f0_0f60:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".173" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".174" = bitcast i8* %".173" to i64*
  %"ldc_const.1" = load i64, i64* %".174"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 10
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R118:R95_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R118:R95_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R118:R95_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R118:R95_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R118:R95_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R118:R95_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R118:R95_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R118:R95_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".175" = xor i32 %"imad.11", -1
  %".176" = xor i32 65011712, -1
  %".177" = xor i32 0, -1
  %".178" = and i32 %"imad.11", 65011712
  %".179" = and i32 %".178", %".177"
  %".180" = and i32 %"imad.11", 65011712
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".184" = zext i32 1024 to i64
  %".185" = zext i32 24 to i64
  %".186" = shl i64 %".183", %".185"
  %".187" = and i64 %".186", 4294967295
  %".188" = add i64 %".187", %".184"
  %".189" = trunc i64 %".188" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".190" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".182"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0820"
BB_0820:
  %"cond_trunc.11" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a10", label %"BB_0830"
BB_0830:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".197" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".197" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".198" = xor i32 %"plop3_a_bit.2", 1
  %".199" = xor i32 %"plop3_b_bit.2", 1
  %".200" = xor i32 %"plop3_c_bit.2", 1
  %".201" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".202" = and i32 %".201", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".202", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".203" = zext i32 0 to i64
  %".204" = zext i32 %".189" to i64
  %".205" = shl i64 %".204", 32
  %"shf_concat.4" = or i64 %".203", %".205"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".206" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".206", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".207" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".208" = zext i32 %"iadd3_n2.3" to i64
  %".209" = zext i32 24 to i64
  %".210" = shl i64 %".207", %".209"
  %".211" = and i64 %".210", 4294967295
  %".212" = add i64 %".211", %".208"
  %".213" = trunc i64 %".212" to i32
  %".214" = xor i32 %"shf_result.4", -1
  %".215" = xor i32 16376, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %"shf_result.4", 16376
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %"shf_result.4", 16376
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = zext i32 0 to i64
  %".223" = zext i32 %".213" to i64
  %".224" = shl i64 %".223", 32
  %"shf_concat.5" = or i64 %".222", %".224"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".225" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".225", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".226" = xor i32 %".221", -1
  %".227" = xor i32 524288, -1
  %".228" = xor i32 0, -1
  %".229" = and i32 %".226", 524288
  %".230" = and i32 %".229", %".228"
  %".231" = and i32 %".226", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %".234" = and i32 %".221", %".227"
  %".235" = and i32 %".234", %".228"
  %".236" = or i32 %".233", %".235"
  %".237" = and i32 %".221", %".227"
  %".238" = and i32 %".237", 0
  %".239" = or i32 %".236", %".238"
  %".240" = and i32 %".221", 524288
  %".241" = and i32 %".240", %".228"
  %".242" = or i32 %".239", %".241"
  %".243" = and i32 %".221", 524288
  %".244" = and i32 %".243", 0
  %".245" = or i32 %".242", %".244"
  %".246" = xor i32 %"shf_result.5", -1
  %".247" = xor i32 16376, -1
  %".248" = xor i32 0, -1
  %".249" = and i32 %"shf_result.5", 16376
  %".250" = and i32 %".249", %".248"
  %".251" = and i32 %"shf_result.5", 16376
  %".252" = and i32 %".251", 0
  %".253" = or i32 %".250", %".252"
  %".254" = xor i32 %".253", -1
  %".255" = xor i32 524288, -1
  %".256" = xor i32 0, -1
  %".257" = and i32 %".254", 524288
  %".258" = and i32 %".257", %".256"
  %".259" = and i32 %".254", 524288
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = and i32 %".253", %".255"
  %".263" = and i32 %".262", %".256"
  %".264" = or i32 %".261", %".263"
  %".265" = and i32 %".253", %".255"
  %".266" = and i32 %".265", 0
  %".267" = or i32 %".264", %".266"
  %".268" = and i32 %".253", 524288
  %".269" = and i32 %".268", %".256"
  %".270" = or i32 %".267", %".269"
  %".271" = and i32 %".253", 524288
  %".272" = and i32 %".271", 0
  %".273" = or i32 %".270", %".272"
  %"iadd3_n1.4" = add i32 %"lds.2", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0940"
BB_0940:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0830"], [%"P9_to_i32", %"BB_0970"]
  %"phi.16" = phi  i32 [%"P33_to_i32", %"BB_0830"], [%"phi.18", %"BB_0970"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000940", label %"BB_0950"
BB_80000940:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0950"
BB_0950:
  %"phi.17" = phi  i32 [%"P24_to_i32", %"BB_80000940"], [%"phi.15", %"BB_0940"]
  %"mma_a_r0_ext" = zext i32 %".245" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".277" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".278" = sub i64 %".277", 0
  %".279" = lshr i64 %".278", 4
  %".280" = add i64 %"mma_a_packed_1", %".279"
  %".281" = and i64 %".280", 16383
  %".282" = and i64 %"mma_a_packed_1", -16384
  %".283" = or i64 %".282", %".281"
  %"mma_b_r0_ext" = zext i32 %".273" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".284" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".285" = sub i64 %".284", 0
  %".286" = lshr i64 %".285", 4
  %".287" = add i64 %"mma_b_packed_1", %".286"
  %".288" = and i64 %".287", 16383
  %".289" = and i64 %"mma_b_packed_1", -16384
  %".290" = or i64 %".289", %".288"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".283", i64 %".290", i32 679743664, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".294" = xor i32 %"plop3_a_bit.3", 1
  %".295" = xor i32 %"plop3_b_bit.3", 1
  %".296" = xor i32 %"plop3_c_bit.3", 1
  %".297" = and i32 %".294", %"plop3_b_bit.3"
  %".298" = and i32 %".297", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".298", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.18" = phi  i32 [%"P7_to_i32", %"BB_80000960"], [%"phi.16", %"BB_0960"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".300" = xor i32 %"plop3_a_bit.4", 1
  %".301" = xor i32 %"plop3_b_bit.4", 1
  %".302" = xor i32 %"plop3_c_bit.4", 1
  %".303" = and i32 %".300", %"plop3_b_bit.4"
  %".304" = and i32 %".303", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".304", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0940", label %"BB_0990"
BB_0990:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".306" = xor i32 %"plop3_a_bit.5", 1
  %".307" = xor i32 %"plop3_b_bit.5", 1
  %".308" = xor i32 %"plop3_c_bit.5", 1
  %".309" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".310" = and i32 %".309", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".310", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".311" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".312" = zext i32 %"iadd3_n2.6" to i64
  %".313" = zext i32 24 to i64
  %".314" = shl i64 %".311", %".313"
  %".315" = and i64 %".314", 4294967295
  %".316" = add i64 %".315", %".312"
  %".317" = trunc i64 %".316" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.19" = phi  i32 [%"P9_to_i32", %"BB_0990"], [%"P15_to_i32", %"BB_09f0"]
  %"phi.20" = phi  i32 [%"P31_to_i32", %"BB_0990"], [%"phi.22", %"BB_09f0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009c0", label %"BB_09d0"
BB_800009c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09d0"
BB_09d0:
  %"phi.21" = phi  i32 [%"P13_to_i32", %"BB_800009c0"], [%"phi.19", %"BB_09c0"]
  %"utcbar_local_winoff" = and i32 %".317", 16777215
  %".321" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".322" = ptrtoint i8 addrspace(3)* %".321" to i32
  %".323" = lshr i32 %".317", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".322", i32 %".323")
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".327" = xor i32 %"plop3_a_bit.6", 1
  %".328" = xor i32 %"plop3_b_bit.6", 1
  %".329" = xor i32 %"plop3_c_bit.6", 1
  %".330" = and i32 %".327", %"plop3_b_bit.6"
  %".331" = and i32 %".330", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".331", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.22" = phi  i32 [%"P36_to_i32", %"BB_800009e0"], [%"phi.20", %"BB_09e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".333" = xor i32 %"plop3_a_bit.7", 1
  %".334" = xor i32 %"plop3_b_bit.7", 1
  %".335" = xor i32 %"plop3_c_bit.7", 1
  %".336" = and i32 %".333", %"plop3_b_bit.7"
  %".337" = and i32 %".336", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".337", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09c0", label %"BB_0a10"
BB_0a10:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".339" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".340" = zext i32 %"iadd3_n2.7" to i64
  %".341" = zext i32 24 to i64
  %".342" = shl i64 %".339", %".341"
  %".343" = and i64 %".342", 4294967295
  %".344" = add i64 %".343", %".340"
  %".345" = trunc i64 %".344" to i32
  %"mbar_shared_winoff.1" = and i32 %".345", 16777215
  %".346" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".346" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0f00", label %"BB_0a70"
BB_0f00:
  %"mbar_shared_winoff.2" = and i32 %".345", 16777215
  %".349" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".349" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f00", label %"BB_0a70"
BB_0a70:
  %".352" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".353" = bitcast i8* %".352" to i64*
  %"ldc_const.2" = load i64, i64* %".353"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R120:R100_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R120:R100_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R120:R100_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R120:R100_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R120:R100_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R120:R100_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R120:R100_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R120:R100_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R120:R100_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R120:R100_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".367" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".368" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R120:R100_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R120:R100_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R120:R100_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R120:R100_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R120:R100_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R120:R100_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R120:R100_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".367", i32 addrspace(1)* %"R120:R100_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R120:R100_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".368", i32 addrspace(1)* %"R120:R100_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R120:R100_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R120:R100_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R120:R100_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R120:R100_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R120:R100_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R120:R100_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R120:R100_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R120:R100_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R120:R100_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R120:R100_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R120:R100_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R120:R100_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c70"
BB_0c70:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c70", label %"BB_0c80"
BB_0c80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".388" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".388" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".389" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".390" = zext i32 80 to i64
  %".391" = zext i32 24 to i64
  %".392" = shl i64 %".389", %".391"
  %".393" = and i64 %".392", 4294967295
  %".394" = add i64 %".393", %".390"
  %".395" = trunc i64 %".394" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".395", 16777215
  %".396" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".397" = xor i32 %"lds.3", -1
  %".398" = xor i32 65535, -1
  %".399" = xor i32 0, -1
  %".400" = and i32 %"lds.3", 65535
  %".401" = and i32 %".400", %".399"
  %".402" = and i32 %"lds.3", 65535
  %".403" = and i32 %".402", 0
  %".404" = or i32 %".401", %".403"
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %".404" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.6" = or i64 %".405", %".407"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".408" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".409" = zext i32 %"imad.15" to i64
  %".410" = zext i32 0 to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.7" = or i64 %".409", %".411"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".412" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".412" to i32
  %".413" = zext i32 %"imad.15" to i64
  %".414" = zext i32 0 to i64
  %".415" = shl i64 %".414", 32
  %"shf_concat.8" = or i64 %".413", %".415"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".416" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".416" to i32
  %".417" = xor i32 %"shf_result.8", -1
  %".418" = xor i32 %"shf_result.7", -1
  %".419" = xor i32 0, -1
  %".420" = and i32 %".417", %"shf_result.7"
  %".421" = and i32 %".420", %".419"
  %".422" = and i32 %".417", %"shf_result.7"
  %".423" = and i32 %".422", 0
  %".424" = or i32 %".421", %".423"
  %".425" = and i32 %"shf_result.8", %".418"
  %".426" = and i32 %".425", %".419"
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 %"shf_result.8", %".418"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 %"shf_result.8", %"shf_result.7"
  %".432" = and i32 %".431", %".419"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 %"shf_result.8", %"shf_result.7"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %".437" = xor i32 %".436", -1
  %".438" = xor i32 65535, -1
  %".439" = xor i32 0, -1
  %".440" = and i32 %".436", 65535
  %".441" = and i32 %".440", %".439"
  %".442" = and i32 %".436", 65535
  %".443" = and i32 %".442", 0
  %".444" = or i32 %".441", %".443"
  %".445" = xor i32 %".436", -1
  %".446" = xor i32 65535, -1
  %".447" = xor i32 %"lds.4", -1
  %".448" = and i32 %".436", 65535
  %".449" = and i32 %".448", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".449", %".444"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0d70"
BB_0d70:
  %"cond_trunc.19" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0ed0_0f90", label %"BB_0d80"
BB_0d80:
  %".452" = zext i32 0 to i64
  %".453" = zext i32 %"lds.4" to i64
  %".454" = shl i64 %".453", 32
  %"shf_concat.9" = or i64 %".452", %".454"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".455" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".455", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".456" = zext i32 0 to i64
  %".457" = zext i32 %".436" to i64
  %".458" = shl i64 %".457", 32
  %"shf_concat.10" = or i64 %".456", %".458"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".459" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".459", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".460" = xor i32 %"shf_result.9", -1
  %".461" = xor i32 %"shf_result.10", -1
  %".462" = xor i32 0, -1
  %".463" = and i32 %"shf_result.9", %"shf_result.10"
  %".464" = and i32 %".463", %".462"
  %".465" = and i32 %"shf_result.9", %"shf_result.10"
  %".466" = and i32 %".465", 0
  %".467" = or i32 %".464", %".466"
  %"isetrp_cmp1.11" = icmp ne i32 %".467", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.20" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0ea0_0f30", label %"BB_0dd0"
BB_0dd0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".470" = xor i32 0, -1
  %".471" = xor i32 %".436", -1
  %".472" = xor i32 0, -1
  %".473" = and i32 %".470", %".471"
  %".474" = and i32 %".473", %".472"
  %".475" = and i32 %".470", %".471"
  %".476" = and i32 %".475", 0
  %".477" = or i32 %".474", %".476"
  %".478" = and i32 0, %".471"
  %".479" = and i32 %".478", %".472"
  %".480" = or i32 %".477", %".479"
  %".481" = and i32 0, %".471"
  %".482" = and i32 %".481", 0
  %".483" = or i32 %".480", %".482"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".483"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask")
  %".484" = xor i32 %".483", -1
  %".485" = call i32 @"llvm.cttz.i32"(i32 %".484", i1 0)
  %".486" = shl i32 %".485", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".486") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.21" = trunc i32 %"P41_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e70", label %"BB_0ee0"
BB_80000e70:
  %"atoms_shared_addr_winoff.1" = and i32 %".395", 16777215
  %".490" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.17" monotonic
  br label %"BB_0ee0"
BB_0ea0_0f30:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ed0_0f90:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ee0:
  ret void
BB_80000c70:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R9:R136_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R9:R136_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P25_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P19_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R153:R108_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R153:R108_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P18_to_i32", %"BB_01a0"], [%"P20_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P27_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P28_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P29_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P29_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P30_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0f60"
BB_05f0_0f60:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".173" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".174" = bitcast i8* %".173" to i64*
  %"ldc_const.1" = load i64, i64* %".174"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 10
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R118:R95_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R118:R95_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R118:R95_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R118:R95_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R118:R95_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R118:R95_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R118:R95_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R118:R95_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R118:R95_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".175" = xor i32 %"imad.11", -1
  %".176" = xor i32 65011712, -1
  %".177" = xor i32 0, -1
  %".178" = and i32 %"imad.11", 65011712
  %".179" = and i32 %".178", %".177"
  %".180" = and i32 %"imad.11", 65011712
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".184" = zext i32 1024 to i64
  %".185" = zext i32 24 to i64
  %".186" = shl i64 %".183", %".185"
  %".187" = and i64 %".186", 4294967295
  %".188" = add i64 %".187", %".184"
  %".189" = trunc i64 %".188" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".190" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".190" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".182"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0820"
BB_0820:
  %"cond_trunc.11" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a10", label %"BB_0830"
BB_0830:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".197" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".197" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".198" = xor i32 %"plop3_a_bit.2", 1
  %".199" = xor i32 %"plop3_b_bit.2", 1
  %".200" = xor i32 %"plop3_c_bit.2", 1
  %".201" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".202" = and i32 %".201", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".202", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".203" = zext i32 0 to i64
  %".204" = zext i32 %".189" to i64
  %".205" = shl i64 %".204", 32
  %"shf_concat.4" = or i64 %".203", %".205"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".206" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".206", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".207" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".208" = zext i32 %"iadd3_n2.3" to i64
  %".209" = zext i32 24 to i64
  %".210" = shl i64 %".207", %".209"
  %".211" = and i64 %".210", 4294967295
  %".212" = add i64 %".211", %".208"
  %".213" = trunc i64 %".212" to i32
  %".214" = xor i32 %"shf_result.4", -1
  %".215" = xor i32 16376, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %"shf_result.4", 16376
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %"shf_result.4", 16376
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = zext i32 0 to i64
  %".223" = zext i32 %".213" to i64
  %".224" = shl i64 %".223", 32
  %"shf_concat.5" = or i64 %".222", %".224"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".225" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".225", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".226" = xor i32 %".221", -1
  %".227" = xor i32 524288, -1
  %".228" = xor i32 0, -1
  %".229" = and i32 %".226", 524288
  %".230" = and i32 %".229", %".228"
  %".231" = and i32 %".226", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %".234" = and i32 %".221", %".227"
  %".235" = and i32 %".234", %".228"
  %".236" = or i32 %".233", %".235"
  %".237" = and i32 %".221", %".227"
  %".238" = and i32 %".237", 0
  %".239" = or i32 %".236", %".238"
  %".240" = and i32 %".221", 524288
  %".241" = and i32 %".240", %".228"
  %".242" = or i32 %".239", %".241"
  %".243" = and i32 %".221", 524288
  %".244" = and i32 %".243", 0
  %".245" = or i32 %".242", %".244"
  %".246" = xor i32 %"shf_result.5", -1
  %".247" = xor i32 16376, -1
  %".248" = xor i32 0, -1
  %".249" = and i32 %"shf_result.5", 16376
  %".250" = and i32 %".249", %".248"
  %".251" = and i32 %"shf_result.5", 16376
  %".252" = and i32 %".251", 0
  %".253" = or i32 %".250", %".252"
  %".254" = xor i32 %".253", -1
  %".255" = xor i32 524288, -1
  %".256" = xor i32 0, -1
  %".257" = and i32 %".254", 524288
  %".258" = and i32 %".257", %".256"
  %".259" = and i32 %".254", 524288
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = and i32 %".253", %".255"
  %".263" = and i32 %".262", %".256"
  %".264" = or i32 %".261", %".263"
  %".265" = and i32 %".253", %".255"
  %".266" = and i32 %".265", 0
  %".267" = or i32 %".264", %".266"
  %".268" = and i32 %".253", 524288
  %".269" = and i32 %".268", %".256"
  %".270" = or i32 %".267", %".269"
  %".271" = and i32 %".253", 524288
  %".272" = and i32 %".271", 0
  %".273" = or i32 %".270", %".272"
  %"iadd3_n1.4" = add i32 %"lds.2", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0940"
BB_0940:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0830"], [%"P9_to_i32", %"BB_0970"]
  %"phi.16" = phi  i32 [%"P33_to_i32", %"BB_0830"], [%"phi.18", %"BB_0970"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000940", label %"BB_0950"
BB_80000940:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0950"
BB_0950:
  %"phi.17" = phi  i32 [%"P24_to_i32", %"BB_80000940"], [%"phi.15", %"BB_0940"]
  %"mma_a_r0_ext" = zext i32 %".245" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".277" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".278" = sub i64 %".277", 0
  %".279" = lshr i64 %".278", 4
  %".280" = add i64 %"mma_a_packed_1", %".279"
  %".281" = and i64 %".280", 16383
  %".282" = and i64 %"mma_a_packed_1", -16384
  %".283" = or i64 %".282", %".281"
  %"mma_b_r0_ext" = zext i32 %".273" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".284" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".285" = sub i64 %".284", 0
  %".286" = lshr i64 %".285", 4
  %".287" = add i64 %"mma_b_packed_1", %".286"
  %".288" = and i64 %".287", 16383
  %".289" = and i64 %"mma_b_packed_1", -16384
  %".290" = or i64 %".289", %".288"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".283", i64 %".290", i32 679744944, i32 %"mma_arg_zext", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".294" = xor i32 %"plop3_a_bit.3", 1
  %".295" = xor i32 %"plop3_b_bit.3", 1
  %".296" = xor i32 %"plop3_c_bit.3", 1
  %".297" = and i32 %".294", %"plop3_b_bit.3"
  %".298" = and i32 %".297", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".298", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.18" = phi  i32 [%"P7_to_i32", %"BB_80000960"], [%"phi.16", %"BB_0960"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".300" = xor i32 %"plop3_a_bit.4", 1
  %".301" = xor i32 %"plop3_b_bit.4", 1
  %".302" = xor i32 %"plop3_c_bit.4", 1
  %".303" = and i32 %".300", %"plop3_b_bit.4"
  %".304" = and i32 %".303", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".304", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0940", label %"BB_0990"
BB_0990:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".306" = xor i32 %"plop3_a_bit.5", 1
  %".307" = xor i32 %"plop3_b_bit.5", 1
  %".308" = xor i32 %"plop3_c_bit.5", 1
  %".309" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".310" = and i32 %".309", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".310", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".311" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".312" = zext i32 %"iadd3_n2.6" to i64
  %".313" = zext i32 24 to i64
  %".314" = shl i64 %".311", %".313"
  %".315" = and i64 %".314", 4294967295
  %".316" = add i64 %".315", %".312"
  %".317" = trunc i64 %".316" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.19" = phi  i32 [%"P9_to_i32", %"BB_0990"], [%"P15_to_i32", %"BB_09f0"]
  %"phi.20" = phi  i32 [%"P31_to_i32", %"BB_0990"], [%"phi.22", %"BB_09f0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009c0", label %"BB_09d0"
BB_800009c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09d0"
BB_09d0:
  %"phi.21" = phi  i32 [%"P13_to_i32", %"BB_800009c0"], [%"phi.19", %"BB_09c0"]
  %"utcbar_local_winoff" = and i32 %".317", 16777215
  %".321" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".322" = ptrtoint i8 addrspace(3)* %".321" to i32
  %".323" = lshr i32 %".317", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".322", i32 %".323")
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".327" = xor i32 %"plop3_a_bit.6", 1
  %".328" = xor i32 %"plop3_b_bit.6", 1
  %".329" = xor i32 %"plop3_c_bit.6", 1
  %".330" = and i32 %".327", %"plop3_b_bit.6"
  %".331" = and i32 %".330", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".331", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.22" = phi  i32 [%"P36_to_i32", %"BB_800009e0"], [%"phi.20", %"BB_09e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".333" = xor i32 %"plop3_a_bit.7", 1
  %".334" = xor i32 %"plop3_b_bit.7", 1
  %".335" = xor i32 %"plop3_c_bit.7", 1
  %".336" = and i32 %".333", %"plop3_b_bit.7"
  %".337" = and i32 %".336", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".337", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09c0", label %"BB_0a10"
BB_0a10:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".339" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".340" = zext i32 %"iadd3_n2.7" to i64
  %".341" = zext i32 24 to i64
  %".342" = shl i64 %".339", %".341"
  %".343" = and i64 %".342", 4294967295
  %".344" = add i64 %".343", %".340"
  %".345" = trunc i64 %".344" to i32
  %"mbar_shared_winoff.1" = and i32 %".345", 16777215
  %".346" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".346" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0f00", label %"BB_0a70"
BB_0f00:
  %"mbar_shared_winoff.2" = and i32 %".345", 16777215
  %".349" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".349" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f00", label %"BB_0a70"
BB_0a70:
  %".352" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".353" = bitcast i8* %".352" to i64*
  %"ldc_const.2" = load i64, i64* %".353"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R120:R100_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R120:R100_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R120:R100_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R120:R100_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R120:R100_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R120:R100_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R120:R100_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R120:R100_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R120:R100_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R120:R100_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".367" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".368" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R120:R100_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R120:R100_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R120:R100_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R120:R100_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R120:R100_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R120:R100_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R120:R100_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".367", i32 addrspace(1)* %"R120:R100_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R120:R100_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".368", i32 addrspace(1)* %"R120:R100_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R120:R100_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R120:R100_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R120:R100_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R120:R100_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R120:R100_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R120:R100_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R120:R100_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R120:R100_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R120:R100_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R120:R100_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R120:R100_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R120:R100_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c70"
BB_0c70:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c70", label %"BB_0c80"
BB_0c80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".189", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".388" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".388" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".389" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".390" = zext i32 80 to i64
  %".391" = zext i32 24 to i64
  %".392" = shl i64 %".389", %".391"
  %".393" = and i64 %".392", 4294967295
  %".394" = add i64 %".393", %".390"
  %".395" = trunc i64 %".394" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".395", 16777215
  %".396" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".397" = xor i32 %"lds.3", -1
  %".398" = xor i32 65535, -1
  %".399" = xor i32 0, -1
  %".400" = and i32 %"lds.3", 65535
  %".401" = and i32 %".400", %".399"
  %".402" = and i32 %"lds.3", 65535
  %".403" = and i32 %".402", 0
  %".404" = or i32 %".401", %".403"
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %".404" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.6" = or i64 %".405", %".407"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".408" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".409" = zext i32 %"imad.15" to i64
  %".410" = zext i32 0 to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.7" = or i64 %".409", %".411"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".412" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".412" to i32
  %".413" = zext i32 %"imad.15" to i64
  %".414" = zext i32 0 to i64
  %".415" = shl i64 %".414", 32
  %"shf_concat.8" = or i64 %".413", %".415"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".416" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".416" to i32
  %".417" = xor i32 %"shf_result.8", -1
  %".418" = xor i32 %"shf_result.7", -1
  %".419" = xor i32 0, -1
  %".420" = and i32 %".417", %"shf_result.7"
  %".421" = and i32 %".420", %".419"
  %".422" = and i32 %".417", %"shf_result.7"
  %".423" = and i32 %".422", 0
  %".424" = or i32 %".421", %".423"
  %".425" = and i32 %"shf_result.8", %".418"
  %".426" = and i32 %".425", %".419"
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 %"shf_result.8", %".418"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 %"shf_result.8", %"shf_result.7"
  %".432" = and i32 %".431", %".419"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 %"shf_result.8", %"shf_result.7"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %".437" = xor i32 %".436", -1
  %".438" = xor i32 65535, -1
  %".439" = xor i32 0, -1
  %".440" = and i32 %".436", 65535
  %".441" = and i32 %".440", %".439"
  %".442" = and i32 %".436", 65535
  %".443" = and i32 %".442", 0
  %".444" = or i32 %".441", %".443"
  %".445" = xor i32 %".436", -1
  %".446" = xor i32 65535, -1
  %".447" = xor i32 %"lds.4", -1
  %".448" = and i32 %".436", 65535
  %".449" = and i32 %".448", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".449", %".444"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0d70"
BB_0d70:
  %"cond_trunc.19" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0ed0_0f90", label %"BB_0d80"
BB_0d80:
  %".452" = zext i32 0 to i64
  %".453" = zext i32 %"lds.4" to i64
  %".454" = shl i64 %".453", 32
  %"shf_concat.9" = or i64 %".452", %".454"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".455" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".455", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".456" = zext i32 0 to i64
  %".457" = zext i32 %".436" to i64
  %".458" = shl i64 %".457", 32
  %"shf_concat.10" = or i64 %".456", %".458"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".459" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".459", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".460" = xor i32 %"shf_result.9", -1
  %".461" = xor i32 %"shf_result.10", -1
  %".462" = xor i32 0, -1
  %".463" = and i32 %"shf_result.9", %"shf_result.10"
  %".464" = and i32 %".463", %".462"
  %".465" = and i32 %"shf_result.9", %"shf_result.10"
  %".466" = and i32 %".465", 0
  %".467" = or i32 %".464", %".466"
  %"isetrp_cmp1.11" = icmp ne i32 %".467", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.20" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0ea0_0f30", label %"BB_0dd0"
BB_0dd0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".470" = xor i32 0, -1
  %".471" = xor i32 %".436", -1
  %".472" = xor i32 0, -1
  %".473" = and i32 %".470", %".471"
  %".474" = and i32 %".473", %".472"
  %".475" = and i32 %".470", %".471"
  %".476" = and i32 %".475", 0
  %".477" = or i32 %".474", %".476"
  %".478" = and i32 0, %".471"
  %".479" = and i32 %".478", %".472"
  %".480" = or i32 %".477", %".479"
  %".481" = and i32 0, %".471"
  %".482" = and i32 %".481", 0
  %".483" = or i32 %".480", %".482"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".483"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask")
  %".484" = xor i32 %".483", -1
  %".485" = call i32 @"llvm.cttz.i32"(i32 %".484", i1 0)
  %".486" = shl i32 %".485", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".486") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  br label %"BB_0e70"
BB_0e70:
  %"cond_trunc.21" = trunc i32 %"P41_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e70", label %"BB_0ee0"
BB_80000e70:
  %"atoms_shared_addr_winoff.1" = and i32 %".395", 16777215
  %".490" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.17" monotonic
  br label %"BB_0ee0"
BB_0ea0_0f30:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ed0_0f90:
  call void @"llvm.trap"()
  br label %"BB_0ee0"
BB_0ee0:
  ret void
BB_80000c70:
  ret void
}

define void @"_Z13column_scaledIL4Case1EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R108:R88_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R108:R88_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P25_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P19_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R68:R62_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R68:R62_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P18_to_i32", %"BB_01a0"], [%"P20_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P27_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P28_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P29_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P29_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P30_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0e40"
BB_05f0_0e40:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %".173" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".174" = zext i32 1024 to i64
  %".175" = zext i32 24 to i64
  %".176" = shl i64 %".173", %".175"
  %".177" = and i64 %".176", 4294967295
  %".178" = add i64 %".177", %".174"
  %".179" = trunc i64 %".178" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".180" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".180" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.11" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_08c0", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".184" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".184" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".185" = xor i32 %"plop3_a_bit.2", 1
  %".186" = xor i32 %"plop3_b_bit.2", 1
  %".187" = xor i32 %"plop3_c_bit.2", 1
  %".188" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".189" = and i32 %".188", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".189", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".190" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".191" = zext i32 %"iadd3_n2.3" to i64
  %".192" = zext i32 24 to i64
  %".193" = shl i64 %".190", %".192"
  %".194" = and i64 %".193", 4294967295
  %".195" = add i64 %".194", %".191"
  %".196" = trunc i64 %".195" to i32
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".179" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".201" = zext i32 0 to i64
  %".202" = zext i32 %".196" to i64
  %".203" = shl i64 %".202", 32
  %"shf_concat.5" = or i64 %".201", %".203"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".204" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".204", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".205" = xor i32 %"shf_result.4", -1
  %".206" = xor i32 16376, -1
  %".207" = xor i32 0, -1
  %".208" = and i32 %"shf_result.4", 16376
  %".209" = and i32 %".208", %".207"
  %".210" = and i32 %"shf_result.4", 16376
  %".211" = and i32 %".210", 0
  %".212" = or i32 %".209", %".211"
  %".213" = xor i32 %"shf_result.5", -1
  %".214" = xor i32 16376, -1
  %".215" = xor i32 0, -1
  %".216" = and i32 %"shf_result.5", 16376
  %".217" = and i32 %".216", %".215"
  %".218" = and i32 %"shf_result.5", 16376
  %".219" = and i32 %".218", 0
  %".220" = or i32 %".217", %".219"
  %".221" = xor i32 %".212", -1
  %".222" = xor i32 524288, -1
  %".223" = xor i32 0, -1
  %".224" = and i32 %".221", 524288
  %".225" = and i32 %".224", %".223"
  %".226" = and i32 %".221", 524288
  %".227" = and i32 %".226", 0
  %".228" = or i32 %".225", %".227"
  %".229" = and i32 %".212", %".222"
  %".230" = and i32 %".229", %".223"
  %".231" = or i32 %".228", %".230"
  %".232" = and i32 %".212", %".222"
  %".233" = and i32 %".232", 0
  %".234" = or i32 %".231", %".233"
  %".235" = and i32 %".212", 524288
  %".236" = and i32 %".235", %".223"
  %".237" = or i32 %".234", %".236"
  %".238" = and i32 %".212", 524288
  %".239" = and i32 %".238", 0
  %".240" = or i32 %".237", %".239"
  %".241" = xor i32 %".220", -1
  %".242" = xor i32 524288, -1
  %".243" = xor i32 0, -1
  %".244" = and i32 %".241", 524288
  %".245" = and i32 %".244", %".243"
  %".246" = and i32 %".241", 524288
  %".247" = and i32 %".246", 0
  %".248" = or i32 %".245", %".247"
  %".249" = and i32 %".220", %".242"
  %".250" = and i32 %".249", %".243"
  %".251" = or i32 %".248", %".250"
  %".252" = and i32 %".220", %".242"
  %".253" = and i32 %".252", 0
  %".254" = or i32 %".251", %".253"
  %".255" = and i32 %".220", 524288
  %".256" = and i32 %".255", %".243"
  %".257" = or i32 %".254", %".256"
  %".258" = and i32 %".220", 524288
  %".259" = and i32 %".258", 0
  %".260" = or i32 %".257", %".259"
  br label %"BB_07f0"
BB_07f0:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0700"], [%"P9_to_i32", %"BB_0820"]
  %"phi.16" = phi  i32 [%"P33_to_i32", %"BB_0700"], [%"phi.18", %"BB_0820"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_800007f0", label %"BB_0800"
BB_800007f0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0800"
BB_0800:
  %"phi.17" = phi  i32 [%"P24_to_i32", %"BB_800007f0"], [%"phi.15", %"BB_07f0"]
  %"mma_a_r0_ext" = zext i32 %".240" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".264" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".265" = sub i64 %".264", 0
  %".266" = lshr i64 %".265", 4
  %".267" = add i64 %"mma_a_packed_1", %".266"
  %".268" = and i64 %".267", 16383
  %".269" = and i64 %"mma_a_packed_1", -16384
  %".270" = or i64 %".269", %".268"
  %"mma_b_r0_ext" = zext i32 %".260" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".271" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".272" = sub i64 %".271", 0
  %".273" = lshr i64 %".272", 4
  %".274" = add i64 %"mma_b_packed_1", %".273"
  %".275" = and i64 %".274", 16383
  %".276" = and i64 %"mma_b_packed_1", -16384
  %".277" = or i64 %".276", %".275"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.2", i64 %".270", i64 %".277", i32 134484624, i32 %"mma_arg_zext")
  br label %"BB_0810"
BB_0810:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000810", label %"BB_0820"
BB_80000810:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".281" = xor i32 %"plop3_a_bit.3", 1
  %".282" = xor i32 %"plop3_b_bit.3", 1
  %".283" = xor i32 %"plop3_c_bit.3", 1
  %".284" = and i32 %".281", %"plop3_b_bit.3"
  %".285" = and i32 %".284", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".285", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0820"
BB_0820:
  %"phi.18" = phi  i32 [%"P7_to_i32", %"BB_80000810"], [%"phi.16", %"BB_0810"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".287" = xor i32 %"plop3_a_bit.4", 1
  %".288" = xor i32 %"plop3_b_bit.4", 1
  %".289" = xor i32 %"plop3_c_bit.4", 1
  %".290" = and i32 %".287", %"plop3_b_bit.4"
  %".291" = and i32 %".290", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".291", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_07f0", label %"BB_0840"
BB_0840:
  %"iadd3_n1.4" = add i32 1024, 9216
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".293" = xor i32 %"plop3_a_bit.5", 1
  %".294" = xor i32 %"plop3_b_bit.5", 1
  %".295" = xor i32 %"plop3_c_bit.5", 1
  %".296" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".297" = and i32 %".296", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".297", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".298" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".299" = zext i32 %"iadd3_n2.4" to i64
  %".300" = zext i32 24 to i64
  %".301" = shl i64 %".298", %".300"
  %".302" = and i64 %".301", 4294967295
  %".303" = add i64 %".302", %".299"
  %".304" = trunc i64 %".303" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.19" = phi  i32 [%"P9_to_i32", %"BB_0840"], [%"P15_to_i32", %"BB_08a0"]
  %"phi.20" = phi  i32 [%"P31_to_i32", %"BB_0840"], [%"phi.22", %"BB_08a0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000870", label %"BB_0880"
BB_80000870:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0880"
BB_0880:
  %"phi.21" = phi  i32 [%"P13_to_i32", %"BB_80000870"], [%"phi.19", %"BB_0870"]
  %"utcbar_local_winoff" = and i32 %".304", 16777215
  %".308" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".309" = ptrtoint i8 addrspace(3)* %".308" to i32
  %".310" = lshr i32 %".304", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".309", i32 %".310")
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".314" = xor i32 %"plop3_a_bit.6", 1
  %".315" = xor i32 %"plop3_b_bit.6", 1
  %".316" = xor i32 %"plop3_c_bit.6", 1
  %".317" = and i32 %".314", %"plop3_b_bit.6"
  %".318" = and i32 %".317", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".318", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.22" = phi  i32 [%"P36_to_i32", %"BB_80000890"], [%"phi.20", %"BB_0890"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".320" = xor i32 %"plop3_a_bit.7", 1
  %".321" = xor i32 %"plop3_b_bit.7", 1
  %".322" = xor i32 %"plop3_c_bit.7", 1
  %".323" = and i32 %".320", %"plop3_b_bit.7"
  %".324" = and i32 %".323", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".324", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0870", label %"BB_08c0"
BB_08c0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"imad_tmp.8" = mul i32 %"tid_x.1", 65536
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %".326" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".327" = zext i32 %"iadd3_n2.5" to i64
  %".328" = zext i32 24 to i64
  %".329" = shl i64 %".326", %".328"
  %".330" = and i64 %".329", 4294967295
  %".331" = add i64 %".330", %".327"
  %".332" = trunc i64 %".331" to i32
  %".333" = xor i32 %"imad.9", -1
  %".334" = xor i32 65011712, -1
  %".335" = xor i32 0, -1
  %".336" = and i32 %"imad.9", 65011712
  %".337" = and i32 %".336", %".335"
  %".338" = and i32 %"imad.9", 65011712
  %".339" = and i32 %".338", 0
  %".340" = or i32 %".337", %".339"
  %"imad_tmp.9" = mul i32 %"lds.1", 1
  %"imad.10" = add i32 %"imad_tmp.9", %".340"
  %"mbar_shared_winoff.1" = and i32 %".332", 16777215
  %".341" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".341" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0940"
BB_0940:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0de0", label %"BB_0950"
BB_0de0:
  %"mbar_shared_winoff.2" = and i32 %".332", 16777215
  %".344" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".344" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0df0"
BB_0df0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0de0", label %"BB_0950"
BB_0950:
  %".347" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".348" = bitcast i8* %".347" to i64*
  %"ldc_const.1" = load i64, i64* %".348"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x.1", 16
  %"imad.11" = add i32 %"imad_tmp.10", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.10")
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".350" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.10", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".353" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.11" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.12" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.12" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.12", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R75:R53_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R75:R53_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R75:R53_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".350", i32 addrspace(1)* %"R75:R53_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R75:R53_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R75:R53_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R75:R53_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R75:R53_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R75:R53_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".353", i32 addrspace(1)* %"R75:R53_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.10", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".365" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R75:R53_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R75:R53_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R75:R53_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R75:R53_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R75:R53_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R75:R53_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.10", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".371" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R75:R53_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R75:R53_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R75:R53_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R75:R53_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R75:R53_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R75:R53_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R75:R53_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".365", i32 addrspace(1)* %"R75:R53_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R75:R53_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R75:R53_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R75:R53_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R75:R53_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R75:R53_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".371", i32 addrspace(1)* %"R75:R53_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R75:R53_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R75:R53_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b50"
BB_0b50:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000b50", label %"BB_0b60"
BB_0b60:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".383" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".383" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 1
  %".384" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".385" = zext i32 80 to i64
  %".386" = zext i32 24 to i64
  %".387" = shl i64 %".384", %".386"
  %".388" = and i64 %".387", 4294967295
  %".389" = add i64 %".388", %".385"
  %".390" = trunc i64 %".389" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".390", 16777215
  %".391" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".391" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".392" = xor i32 %"lds.3", -1
  %".393" = xor i32 65535, -1
  %".394" = xor i32 0, -1
  %".395" = and i32 %"lds.3", 65535
  %".396" = and i32 %".395", %".394"
  %".397" = and i32 %"lds.3", 65535
  %".398" = and i32 %".397", 0
  %".399" = or i32 %".396", %".398"
  %".400" = zext i32 0 to i64
  %".401" = zext i32 %".399" to i64
  %".402" = shl i64 %".401", 32
  %"shf_concat.6" = or i64 %".400", %".402"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".403" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".403", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".404" = zext i32 %"imad.13" to i64
  %".405" = zext i32 0 to i64
  %".406" = shl i64 %".405", 32
  %"shf_concat.7" = or i64 %".404", %".406"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".407" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".407" to i32
  %".408" = zext i32 %"imad.13" to i64
  %".409" = zext i32 0 to i64
  %".410" = shl i64 %".409", 32
  %"shf_concat.8" = or i64 %".408", %".410"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".411" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".411" to i32
  %".412" = xor i32 %"shf_result.8", -1
  %".413" = xor i32 %"shf_result.7", -1
  %".414" = xor i32 0, -1
  %".415" = and i32 %".412", %"shf_result.7"
  %".416" = and i32 %".415", %".414"
  %".417" = and i32 %".412", %"shf_result.7"
  %".418" = and i32 %".417", 0
  %".419" = or i32 %".416", %".418"
  %".420" = and i32 %"shf_result.8", %".413"
  %".421" = and i32 %".420", %".414"
  %".422" = or i32 %".419", %".421"
  %".423" = and i32 %"shf_result.8", %".413"
  %".424" = and i32 %".423", 0
  %".425" = or i32 %".422", %".424"
  %".426" = and i32 %"shf_result.8", %"shf_result.7"
  %".427" = and i32 %".426", %".414"
  %".428" = or i32 %".425", %".427"
  %".429" = and i32 %"shf_result.8", %"shf_result.7"
  %".430" = and i32 %".429", 0
  %".431" = or i32 %".428", %".430"
  %".432" = xor i32 %".431", -1
  %".433" = xor i32 65535, -1
  %".434" = xor i32 0, -1
  %".435" = and i32 %".431", 65535
  %".436" = and i32 %".435", %".434"
  %".437" = and i32 %".431", 65535
  %".438" = and i32 %".437", 0
  %".439" = or i32 %".436", %".438"
  %".440" = xor i32 %".431", -1
  %".441" = xor i32 65535, -1
  %".442" = xor i32 %"lds.4", -1
  %".443" = and i32 %".431", 65535
  %".444" = and i32 %".443", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".444", %".439"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0c50"
BB_0c50:
  %"cond_trunc.19" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0db0_0e70", label %"BB_0c60"
BB_0c60:
  %".447" = zext i32 0 to i64
  %".448" = zext i32 %"lds.4" to i64
  %".449" = shl i64 %".448", 32
  %"shf_concat.9" = or i64 %".447", %".449"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".450" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".450", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".451" = zext i32 0 to i64
  %".452" = zext i32 %".431" to i64
  %".453" = shl i64 %".452", 32
  %"shf_concat.10" = or i64 %".451", %".453"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".454" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".454", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".455" = xor i32 %"shf_result.9", -1
  %".456" = xor i32 %"shf_result.10", -1
  %".457" = xor i32 0, -1
  %".458" = and i32 %"shf_result.9", %"shf_result.10"
  %".459" = and i32 %".458", %".457"
  %".460" = and i32 %"shf_result.9", %"shf_result.10"
  %".461" = and i32 %".460", 0
  %".462" = or i32 %".459", %".461"
  %"isetrp_cmp1.11" = icmp ne i32 %".462", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0ca0"
BB_0ca0:
  %"cond_trunc.20" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0d80_0e10", label %"BB_0cb0"
BB_0cb0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".465" = xor i32 0, -1
  %".466" = xor i32 %".431", -1
  %".467" = xor i32 0, -1
  %".468" = and i32 %".465", %".466"
  %".469" = and i32 %".468", %".467"
  %".470" = and i32 %".465", %".466"
  %".471" = and i32 %".470", 0
  %".472" = or i32 %".469", %".471"
  %".473" = and i32 0, %".466"
  %".474" = and i32 %".473", %".467"
  %".475" = or i32 %".472", %".474"
  %".476" = and i32 0, %".466"
  %".477" = and i32 %".476", 0
  %".478" = or i32 %".475", %".477"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", %".478"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.14", i32 %"redux_mask")
  %".479" = xor i32 %".478", -1
  %".480" = call i32 @"llvm.cttz.i32"(i32 %".479", i1 0)
  %".481" = shl i32 %".480", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".481") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.21" = trunc i32 %"P41_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000d50", label %"BB_0dc0"
BB_80000d50:
  %"atoms_shared_addr_winoff.1" = and i32 %".390", 16777215
  %".485" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".485" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.15" monotonic
  br label %"BB_0dc0"
BB_0d80_0e10:
  call void @"llvm.trap"()
  br label %"BB_0dc0"
BB_0db0_0e70:
  call void @"llvm.trap"()
  br label %"BB_0dc0"
BB_0dc0:
  ret void
BB_80000b50:
  ret void
}

define void @"_Z13column_scaledIL4Case0EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R108:R88_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R108:R88_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P16_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P16_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P25_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P19_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R68:R62_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R68:R62_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P26_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P26_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"P18_to_i32", %"BB_01a0"], [%"P20_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P27_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.10" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P27_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.10" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.11" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.10", %"BB_02e0"]
  %"phi.12" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.13" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P28_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.11", 16777215
  %".88" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.13" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.12" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".103" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0620", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".108" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P29_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P29_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".119" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P30_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.14" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.14", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.14" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.14", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0620"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_0e40"
BB_05f0_0e40:
  call void @"llvm.trap"()
  br label %"BB_0620"
BB_0620:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %".173" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".174" = zext i32 1024 to i64
  %".175" = zext i32 24 to i64
  %".176" = shl i64 %".173", %".175"
  %".177" = and i64 %".176", 4294967295
  %".178" = add i64 %".177", %".174"
  %".179" = trunc i64 %".178" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".180" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".180" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.11" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_08c0", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".184" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".184" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 8192
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".185" = xor i32 %"plop3_a_bit.2", 1
  %".186" = xor i32 %"plop3_b_bit.2", 1
  %".187" = xor i32 %"plop3_c_bit.2", 1
  %".188" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".189" = and i32 %".188", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".189", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".190" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".191" = zext i32 %"iadd3_n2.3" to i64
  %".192" = zext i32 24 to i64
  %".193" = shl i64 %".190", %".192"
  %".194" = and i64 %".193", 4294967295
  %".195" = add i64 %".194", %".191"
  %".196" = trunc i64 %".195" to i32
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".179" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".201" = zext i32 0 to i64
  %".202" = zext i32 %".196" to i64
  %".203" = shl i64 %".202", 32
  %"shf_concat.5" = or i64 %".201", %".203"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".204" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".204", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".205" = xor i32 %"shf_result.4", -1
  %".206" = xor i32 16376, -1
  %".207" = xor i32 0, -1
  %".208" = and i32 %"shf_result.4", 16376
  %".209" = and i32 %".208", %".207"
  %".210" = and i32 %"shf_result.4", 16376
  %".211" = and i32 %".210", 0
  %".212" = or i32 %".209", %".211"
  %".213" = xor i32 %"shf_result.5", -1
  %".214" = xor i32 16376, -1
  %".215" = xor i32 0, -1
  %".216" = and i32 %"shf_result.5", 16376
  %".217" = and i32 %".216", %".215"
  %".218" = and i32 %"shf_result.5", 16376
  %".219" = and i32 %".218", 0
  %".220" = or i32 %".217", %".219"
  %".221" = xor i32 %".212", -1
  %".222" = xor i32 524288, -1
  %".223" = xor i32 0, -1
  %".224" = and i32 %".221", 524288
  %".225" = and i32 %".224", %".223"
  %".226" = and i32 %".221", 524288
  %".227" = and i32 %".226", 0
  %".228" = or i32 %".225", %".227"
  %".229" = and i32 %".212", %".222"
  %".230" = and i32 %".229", %".223"
  %".231" = or i32 %".228", %".230"
  %".232" = and i32 %".212", %".222"
  %".233" = and i32 %".232", 0
  %".234" = or i32 %".231", %".233"
  %".235" = and i32 %".212", 524288
  %".236" = and i32 %".235", %".223"
  %".237" = or i32 %".234", %".236"
  %".238" = and i32 %".212", 524288
  %".239" = and i32 %".238", 0
  %".240" = or i32 %".237", %".239"
  %".241" = xor i32 %".220", -1
  %".242" = xor i32 524288, -1
  %".243" = xor i32 0, -1
  %".244" = and i32 %".241", 524288
  %".245" = and i32 %".244", %".243"
  %".246" = and i32 %".241", 524288
  %".247" = and i32 %".246", 0
  %".248" = or i32 %".245", %".247"
  %".249" = and i32 %".220", %".242"
  %".250" = and i32 %".249", %".243"
  %".251" = or i32 %".248", %".250"
  %".252" = and i32 %".220", %".242"
  %".253" = and i32 %".252", 0
  %".254" = or i32 %".251", %".253"
  %".255" = and i32 %".220", 524288
  %".256" = and i32 %".255", %".243"
  %".257" = or i32 %".254", %".256"
  %".258" = and i32 %".220", 524288
  %".259" = and i32 %".258", 0
  %".260" = or i32 %".257", %".259"
  br label %"BB_07f0"
BB_07f0:
  %"phi.15" = phi  i32 [%"phi.9", %"BB_0700"], [%"P9_to_i32", %"BB_0820"]
  %"phi.16" = phi  i32 [%"P33_to_i32", %"BB_0700"], [%"phi.18", %"BB_0820"]
  %"cond_trunc.12" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_800007f0", label %"BB_0800"
BB_800007f0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P24_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0800"
BB_0800:
  %"phi.17" = phi  i32 [%"P24_to_i32", %"BB_800007f0"], [%"phi.15", %"BB_07f0"]
  %"mma_a_r0_ext" = zext i32 %".240" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".264" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".265" = sub i64 %".264", 0
  %".266" = lshr i64 %".265", 4
  %".267" = add i64 %"mma_a_packed_1", %".266"
  %".268" = and i64 %".267", 16383
  %".269" = and i64 %"mma_a_packed_1", -16384
  %".270" = or i64 %".269", %".268"
  %"mma_b_r0_ext" = zext i32 %".260" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".271" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".272" = sub i64 %".271", 0
  %".273" = lshr i64 %".272", 4
  %".274" = add i64 %"mma_b_packed_1", %".273"
  %".275" = and i64 %".274", 16383
  %".276" = and i64 %"mma_b_packed_1", -16384
  %".277" = or i64 %".276", %".275"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,~{memory}"(i32 %"lds.2", i64 %".270", i64 %".277", i32 134485392, i32 %"mma_arg_zext")
  br label %"BB_0810"
BB_0810:
  %"cond_trunc.13" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000810", label %"BB_0820"
BB_80000810:
  %"lop3_a_trunc" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".281" = xor i32 %"plop3_a_bit.3", 1
  %".282" = xor i32 %"plop3_b_bit.3", 1
  %".283" = xor i32 %"plop3_c_bit.3", 1
  %".284" = and i32 %".281", %"plop3_b_bit.3"
  %".285" = and i32 %".284", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".285", 0
  %"P7_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0820"
BB_0820:
  %"phi.18" = phi  i32 [%"P7_to_i32", %"BB_80000810"], [%"phi.16", %"BB_0810"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".287" = xor i32 %"plop3_a_bit.4", 1
  %".288" = xor i32 %"plop3_b_bit.4", 1
  %".289" = xor i32 %"plop3_c_bit.4", 1
  %".290" = and i32 %".287", %"plop3_b_bit.4"
  %".291" = and i32 %".290", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".291", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_07f0", label %"BB_0840"
BB_0840:
  %"iadd3_n1.4" = add i32 1024, 9216
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".293" = xor i32 %"plop3_a_bit.5", 1
  %".294" = xor i32 %"plop3_b_bit.5", 1
  %".295" = xor i32 %"plop3_c_bit.5", 1
  %".296" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".297" = and i32 %".296", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".297", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".298" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".299" = zext i32 %"iadd3_n2.4" to i64
  %".300" = zext i32 24 to i64
  %".301" = shl i64 %".298", %".300"
  %".302" = and i64 %".301", 4294967295
  %".303" = add i64 %".302", %".299"
  %".304" = trunc i64 %".303" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.19" = phi  i32 [%"P9_to_i32", %"BB_0840"], [%"P15_to_i32", %"BB_08a0"]
  %"phi.20" = phi  i32 [%"P31_to_i32", %"BB_0840"], [%"phi.22", %"BB_08a0"]
  %"cond_trunc.14" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000870", label %"BB_0880"
BB_80000870:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0880"
BB_0880:
  %"phi.21" = phi  i32 [%"P13_to_i32", %"BB_80000870"], [%"phi.19", %"BB_0870"]
  %"utcbar_local_winoff" = and i32 %".304", 16777215
  %".308" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".309" = ptrtoint i8 addrspace(3)* %".308" to i32
  %".310" = lshr i32 %".304", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".309", i32 %".310")
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.15" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"lop3_a_trunc.1" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".314" = xor i32 %"plop3_a_bit.6", 1
  %".315" = xor i32 %"plop3_b_bit.6", 1
  %".316" = xor i32 %"plop3_c_bit.6", 1
  %".317" = and i32 %".314", %"plop3_b_bit.6"
  %".318" = and i32 %".317", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".318", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.22" = phi  i32 [%"P36_to_i32", %"BB_80000890"], [%"phi.20", %"BB_0890"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".320" = xor i32 %"plop3_a_bit.7", 1
  %".321" = xor i32 %"plop3_b_bit.7", 1
  %".322" = xor i32 %"plop3_c_bit.7", 1
  %".323" = and i32 %".320", %"plop3_b_bit.7"
  %".324" = and i32 %".323", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".324", 0
  %"P15_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0870", label %"BB_08c0"
BB_08c0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"imad_tmp.8" = mul i32 %"tid_x.1", 65536
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %".326" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".327" = zext i32 %"iadd3_n2.5" to i64
  %".328" = zext i32 24 to i64
  %".329" = shl i64 %".326", %".328"
  %".330" = and i64 %".329", 4294967295
  %".331" = add i64 %".330", %".327"
  %".332" = trunc i64 %".331" to i32
  %".333" = xor i32 %"imad.9", -1
  %".334" = xor i32 65011712, -1
  %".335" = xor i32 0, -1
  %".336" = and i32 %"imad.9", 65011712
  %".337" = and i32 %".336", %".335"
  %".338" = and i32 %"imad.9", 65011712
  %".339" = and i32 %".338", 0
  %".340" = or i32 %".337", %".339"
  %"imad_tmp.9" = mul i32 %"lds.1", 1
  %"imad.10" = add i32 %"imad_tmp.9", %".340"
  %"mbar_shared_winoff.1" = and i32 %".332", 16777215
  %".341" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".341" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0940"
BB_0940:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0de0", label %"BB_0950"
BB_0de0:
  %"mbar_shared_winoff.2" = and i32 %".332", 16777215
  %".344" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".344" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0df0"
BB_0df0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0de0", label %"BB_0950"
BB_0950:
  %".347" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".348" = bitcast i8* %".347" to i64*
  %"ldc_const.1" = load i64, i64* %".348"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x.1", 16
  %"imad.11" = add i32 %"imad_tmp.10", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.10")
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".350" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.10", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".353" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.11" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.12" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.12" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.12", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R75:R53_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R75:R53_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R75:R53_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".350", i32 addrspace(1)* %"R75:R53_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R75:R53_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R75:R53_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R75:R53_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R75:R53_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R75:R53_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".353", i32 addrspace(1)* %"R75:R53_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.10", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".365" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R75:R53_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R75:R53_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R75:R53_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R75:R53_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R75:R53_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R75:R53_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.10", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".371" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R75:R53_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R75:R53_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R75:R53_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R75:R53_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R75:R53_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R75:R53_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R75:R53_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".365", i32 addrspace(1)* %"R75:R53_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R75:R53_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R75:R53_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R75:R53_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R75:R53_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R75:R53_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".371", i32 addrspace(1)* %"R75:R53_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R75:R53_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R75:R53_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b50"
BB_0b50:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000b50", label %"BB_0b60"
BB_0b60:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".179", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".383" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".383" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 1
  %".384" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".385" = zext i32 80 to i64
  %".386" = zext i32 24 to i64
  %".387" = shl i64 %".384", %".386"
  %".388" = and i64 %".387", 4294967295
  %".389" = add i64 %".388", %".385"
  %".390" = trunc i64 %".389" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".390", 16777215
  %".391" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".391" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".392" = xor i32 %"lds.3", -1
  %".393" = xor i32 65535, -1
  %".394" = xor i32 0, -1
  %".395" = and i32 %"lds.3", 65535
  %".396" = and i32 %".395", %".394"
  %".397" = and i32 %"lds.3", 65535
  %".398" = and i32 %".397", 0
  %".399" = or i32 %".396", %".398"
  %".400" = zext i32 0 to i64
  %".401" = zext i32 %".399" to i64
  %".402" = shl i64 %".401", 32
  %"shf_concat.6" = or i64 %".400", %".402"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".403" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".403", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".404" = zext i32 %"imad.13" to i64
  %".405" = zext i32 0 to i64
  %".406" = shl i64 %".405", 32
  %"shf_concat.7" = or i64 %".404", %".406"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".407" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".407" to i32
  %".408" = zext i32 %"imad.13" to i64
  %".409" = zext i32 0 to i64
  %".410" = shl i64 %".409", 32
  %"shf_concat.8" = or i64 %".408", %".410"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".411" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".411" to i32
  %".412" = xor i32 %"shf_result.8", -1
  %".413" = xor i32 %"shf_result.7", -1
  %".414" = xor i32 0, -1
  %".415" = and i32 %".412", %"shf_result.7"
  %".416" = and i32 %".415", %".414"
  %".417" = and i32 %".412", %"shf_result.7"
  %".418" = and i32 %".417", 0
  %".419" = or i32 %".416", %".418"
  %".420" = and i32 %"shf_result.8", %".413"
  %".421" = and i32 %".420", %".414"
  %".422" = or i32 %".419", %".421"
  %".423" = and i32 %"shf_result.8", %".413"
  %".424" = and i32 %".423", 0
  %".425" = or i32 %".422", %".424"
  %".426" = and i32 %"shf_result.8", %"shf_result.7"
  %".427" = and i32 %".426", %".414"
  %".428" = or i32 %".425", %".427"
  %".429" = and i32 %"shf_result.8", %"shf_result.7"
  %".430" = and i32 %".429", 0
  %".431" = or i32 %".428", %".430"
  %".432" = xor i32 %".431", -1
  %".433" = xor i32 65535, -1
  %".434" = xor i32 0, -1
  %".435" = and i32 %".431", 65535
  %".436" = and i32 %".435", %".434"
  %".437" = and i32 %".431", 65535
  %".438" = and i32 %".437", 0
  %".439" = or i32 %".436", %".438"
  %".440" = xor i32 %".431", -1
  %".441" = xor i32 65535, -1
  %".442" = xor i32 %"lds.4", -1
  %".443" = and i32 %".431", 65535
  %".444" = and i32 %".443", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".444", %".439"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0c50"
BB_0c50:
  %"cond_trunc.19" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0db0_0e70", label %"BB_0c60"
BB_0c60:
  %".447" = zext i32 0 to i64
  %".448" = zext i32 %"lds.4" to i64
  %".449" = shl i64 %".448", 32
  %"shf_concat.9" = or i64 %".447", %".449"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".450" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".450", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".451" = zext i32 0 to i64
  %".452" = zext i32 %".431" to i64
  %".453" = shl i64 %".452", 32
  %"shf_concat.10" = or i64 %".451", %".453"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".454" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".454", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".455" = xor i32 %"shf_result.9", -1
  %".456" = xor i32 %"shf_result.10", -1
  %".457" = xor i32 0, -1
  %".458" = and i32 %"shf_result.9", %"shf_result.10"
  %".459" = and i32 %".458", %".457"
  %".460" = and i32 %"shf_result.9", %"shf_result.10"
  %".461" = and i32 %".460", 0
  %".462" = or i32 %".459", %".461"
  %"isetrp_cmp1.11" = icmp ne i32 %".462", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0ca0"
BB_0ca0:
  %"cond_trunc.20" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0d80_0e10", label %"BB_0cb0"
BB_0cb0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".465" = xor i32 0, -1
  %".466" = xor i32 %".431", -1
  %".467" = xor i32 0, -1
  %".468" = and i32 %".465", %".466"
  %".469" = and i32 %".468", %".467"
  %".470" = and i32 %".465", %".466"
  %".471" = and i32 %".470", 0
  %".472" = or i32 %".469", %".471"
  %".473" = and i32 0, %".466"
  %".474" = and i32 %".473", %".467"
  %".475" = or i32 %".472", %".474"
  %".476" = and i32 0, %".466"
  %".477" = and i32 %".476", 0
  %".478" = or i32 %".475", %".477"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", %".478"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.14", i32 %"redux_mask")
  %".479" = xor i32 %".478", -1
  %".480" = call i32 @"llvm.cttz.i32"(i32 %".479", i1 0)
  %".481" = shl i32 %".480", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".481") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.21" = trunc i32 %"P41_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000d50", label %"BB_0dc0"
BB_80000d50:
  %"atoms_shared_addr_winoff.1" = and i32 %".390", 16777215
  %".485" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".485" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.15" monotonic
  br label %"BB_0dc0"
BB_0d80_0e10:
  call void @"llvm.trap"()
  br label %"BB_0dc0"
BB_0db0_0e70:
  call void @"llvm.trap"()
  br label %"BB_0dc0"
BB_0dc0:
  ret void
BB_80000b50:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4, !5, !6, !7 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case6EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case5EEvPKjPj", !"kernel", i32 1 }
!3 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case4EEvPKjPj", !"kernel", i32 1 }
!4 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!5 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
!6 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case1EEvPKjPj", !"kernel", i32 1 }
!7 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case0EEvPKjPj", !"kernel", i32 1 }
