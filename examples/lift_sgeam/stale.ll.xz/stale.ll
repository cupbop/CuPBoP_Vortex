; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../p2f/ir/cublas_sgeam/012_sgeam.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/culifter_ml_library_nvvm_ir/cublas/sm90/012_sgeam.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16
@const_mem = global [5 x [616 x i8]] zeroinitializer, align 16

define void @_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_([36 x i8] %arg_528, i64 %arg_568, i64 %arg_576, i64 %arg_584, i64 %arg_592, i64 %arg_600) {
EntryBB_0000:
  %param_local = alloca [608 x i8], align 16
  %.8 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 528
  store [36 x i8] %arg_528, ptr %.8, align 16
  %.11 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 568
  store i64 %arg_568, ptr %.11, align 8
  %.14 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 576
  store i64 %arg_576, ptr %.14, align 64
  %.17 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 584
  store i64 %arg_584, ptr %.17, align 8
  %.20 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 592
  store i64 %arg_592, ptr %.20, align 16
  %.23 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 600
  store i64 %arg_600, ptr %.23, align 8
  %.26 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 556
  %ldc_const = load i32, ptr %.26, align 4
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %isetrp_cmp1 = icmp ne i32 0, %ldc_const
  %ldc_const.1 = load i64, ptr %.8, align 8
  %"UR5:UR4_r0" = trunc i64 %ldc_const.1 to i32
  %"UR5:UR4_r1_shift" = lshr i64 %ldc_const.1, 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %.30 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 536
  %ldc_const.2 = load i64, ptr %.30, align 8
  %"R13:R12_r0" = trunc i64 %ldc_const.2 to i32
  %"R13:R12_r1_shift" = lshr i64 %ldc_const.2, 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %s2ur_ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  br label %BB_00a0

BB_00a0:                                          ; preds = %EntryBB_0000
  %0 = zext i1 %isetrp_cmp1 to i32
  %1 = icmp ne i32 %0, 0
  br i1 %1, label %BB_800000a0, label %BB_00c0

BB_800000a0:                                      ; preds = %BB_00a0
  %ldc_const.3 = load i64, ptr %.20, align 8
  br label %BB_00c0

BB_00c0:                                          ; preds = %BB_800000a0, %BB_00a0
  %2 = phi i64 [ %arg_600, %BB_800000a0 ], [ poison, %BB_00a0 ]
  %3 = phi i64 [ %ldc_const.3, %BB_800000a0 ], [ poison, %BB_00a0 ]
  %s2ur_ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %.39 = zext i32 %s2ur_ctaid_x to i64
  %.42 = shl i64 %.39, 6
  %shf_result = trunc i64 %.42 to i32
  %s2ur_cluster_ctarank = call i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank()
  %.44 = xor i32 %shf_result, -1
  br label %BB_0100

BB_0100:                                          ; preds = %BB_00c0
  %phi_cast_R228_bitcast = bitcast i32 %"UR5:UR4_r0" to float
  br i1 %isetrp_cmp1, label %BB_80000100, label %BB_0110

BB_80000100:                                      ; preds = %BB_0100
  %"R104:R95_addr_ptr" = inttoptr i64 %3 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R104:R95_addr_ptr", align 4
  br label %BB_0110

BB_0110:                                          ; preds = %BB_80000100, %BB_0100
  %phi.4 = phi float [ %ldg, %BB_80000100 ], [ %phi_cast_R228_bitcast, %BB_0100 ]
  %.63 = and i32 %tid_x, 63
  br label %BB_0120

BB_0120:                                          ; preds = %BB_0110
  %phi_cast_R155_bitcast = bitcast i32 %"UR5:UR4_r1" to float
  br i1 %isetrp_cmp1, label %BB_80000120, label %BB_0130

BB_80000120:                                      ; preds = %BB_0120
  %"R130:R116_addr_ptr" = inttoptr i64 %2 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R130:R116_addr_ptr", align 4
  br label %BB_0130

BB_0130:                                          ; preds = %BB_80000120, %BB_0120
  %phi.5 = phi float [ %ldg.1, %BB_80000120 ], [ %phi_cast_R155_bitcast, %BB_0120 ]
  %.72 = zext i32 %tid_x to i64
  %.73 = shl i64 %.72, 32
  %.74 = ashr i64 %.73, 6
  %shf_hi = lshr i64 %.74, 32
  %shf_result.1 = trunc i64 %shf_hi to i32
  %viadd = add i32 %.63, %shf_result
  %viaddmnmx_sum = add i32 %.44, %"R13:R12_r0"
  %viaddmnmx_cmp = icmp slt i32 %viaddmnmx_sum, 63
  %viaddmnmx = select i1 %viaddmnmx_cmp, i32 %viaddmnmx_sum, i32 63
  %isetrp_cmp1.1 = icmp sgt i32 %.63, %viaddmnmx
  %.75 = zext i32 %s2ur_ctaid_y to i64
  %.78 = shl i64 %.75, 5
  %shf_result.2 = trunc i64 %.78 to i32
  %imad_tmp.2 = mul i32 %shf_result.1, 65
  %imad.2 = add i32 %imad_tmp.2, %.63
  %4 = sext i32 %viadd to i64
  %.84 = xor i32 %shf_result.2, -1
  %.97 = zext i32 %s2ur_cluster_ctarank to i64
  %.100 = shl i64 %.97, 24
  %.101 = and i64 %.100, 4294967295
  %.102 = add i64 %.101, 1024
  %.103 = trunc i64 %.102 to i32
  %5 = sext i32 %shf_result.2 to i64
  %viaddmnmx_sum.1 = add i32 %.84, %"R13:R12_r1"
  %viaddmnmx_cmp.1 = icmp slt i32 %viaddmnmx_sum.1, 31
  %viaddmnmx.1 = select i1 %viaddmnmx_cmp.1, i32 %viaddmnmx_sum.1, i32 31
  %.111 = ashr i64 %.73, 5
  %shf_hi.3 = lshr i64 %.111, 32
  %shf_result.5 = trunc i64 %shf_hi.3 to i32
  %.112 = zext i32 %imad.2 to i64
  %.113 = zext i32 %.103 to i64
  %.115 = shl i64 %.112, 2
  %.116 = and i64 %.115, 4294967295
  %.117 = add i64 %.116, %.113
  %.118 = trunc i64 %.117 to i32
  br label %BB_0220

BB_0220:                                          ; preds = %BB_0130
  %6 = zext i1 %isetrp_cmp1.1 to i32
  %7 = icmp ne i32 %6, 0
  br i1 %7, label %BB_0a00, label %BB_0230

BB_0230:                                          ; preds = %BB_0220
  %fsetrp_cmp1 = fcmp une float %phi.4, 0.000000e+00
  %.121 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 544
  %ldc_const.5 = load i32, ptr %.121, align 4
  %8 = sext i32 %ldc_const.5 to i64
  br label %BB_0260

BB_0260:                                          ; preds = %BB_0230
  %9 = zext i1 %fsetrp_cmp1 to i32
  %10 = icmp ne i32 %9, 0
  br i1 %10, label %BB_0310, label %BB_0270

BB_0270:                                          ; preds = %BB_0260
  %fmul = fmul float 0.000000e+00, %phi.4
  %.129 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.118
  store volatile float %fmul, ptr addrspace(3) %.129, align 4
  %sts_addr_memaddr_offset_add = add i32 %.118, 1040
  %.131 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add
  store volatile float %fmul, ptr addrspace(3) %.131, align 4
  %sts_addr_memaddr_offset_add.1 = add i32 %.118, 2080
  %.133 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.1
  store volatile float %fmul, ptr addrspace(3) %.133, align 4
  %sts_addr_memaddr_offset_add.2 = add i32 %.118, 3120
  %.135 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.2
  store volatile float %fmul, ptr addrspace(3) %.135, align 4
  %sts_addr_memaddr_offset_add.3 = add i32 %.118, 4160
  %.137 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.3
  store volatile float %fmul, ptr addrspace(3) %.137, align 4
  %sts_addr_memaddr_offset_add.4 = add i32 %.118, 5200
  %.139 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.4
  store volatile float %fmul, ptr addrspace(3) %.139, align 4
  %sts_addr_memaddr_offset_add.5 = add i32 %.118, 6240
  %.141 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.5
  store volatile float %fmul, ptr addrspace(3) %.141, align 4
  %sts_addr_memaddr_offset_add.6 = add i32 %.118, 7280
  %.143 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.6
  store volatile float %fmul, ptr addrspace(3) %.143, align 4
  br label %BB_0a00

BB_0310:                                          ; preds = %BB_0260
  %viadd.1 = add i32 %shf_result.1, 4
  %ldc_const.6 = load i64, ptr %.11, align 8
  %viadd.2 = add i32 %shf_result.1, 8
  %.148 = sext i32 %shf_result.1 to i64
  %.151 = shl i64 %.148, 1
  %11 = zext i32 %shf_result.1 to i64
  %12 = and i64 %.151, -4294967296
  %13 = add i64 %5, %11
  %14 = add i64 %13, %12
  %viadd.3 = add i32 %shf_result.1, 12
  %viadd.4 = add i32 %shf_result.1, 16
  %.157 = sext i32 %viadd.1 to i64
  %.160 = shl i64 %.157, 1
  %15 = zext i32 %viadd.1 to i64
  %16 = and i64 %.160, -4294967296
  %17 = add i64 %5, %15
  %18 = add i64 %17, %16
  %19 = mul i64 %14, %8
  %20 = add i64 %19, %4
  %.175 = sext i32 %viadd.2 to i64
  %.178 = shl i64 %.175, 1
  %21 = zext i32 %viadd.2 to i64
  %22 = and i64 %.178, -4294967296
  %23 = add i64 %5, %21
  %24 = add i64 %23, %22
  %.189 = shl i64 %20, 2
  %25 = add i64 %ldc_const.6, %.189
  %26 = mul i64 %18, %8
  %27 = add i64 %26, %4
  %.204 = sext i32 %viadd.3 to i64
  %.207 = shl i64 %.204, 1
  %28 = zext i32 %viadd.3 to i64
  %29 = and i64 %.207, -4294967296
  %30 = add i64 %5, %28
  %31 = add i64 %30, %29
  %isetrp_cmp1.2 = icmp sgt i32 %viadd.1, %viaddmnmx.1
  %.218 = shl i64 %27, 2
  %32 = add i64 %ldc_const.6, %.218
  %33 = mul i64 %24, %8
  %34 = add i64 %33, %4
  %.238 = shl i64 %34, 2
  %35 = add i64 %ldc_const.6, %.238
  %36 = mul i64 %31, %8
  %37 = add i64 %36, %4
  %.258 = shl i64 %37, 2
  %38 = add i64 %ldc_const.6, %.258
  %.264 = sext i32 %viadd.4 to i64
  %.267 = shl i64 %.264, 1
  %39 = zext i32 %viadd.4 to i64
  %40 = and i64 %.267, -4294967296
  %41 = add i64 %5, %39
  %42 = add i64 %41, %40
  %isetrp_cmp1.3 = icmp sgt i32 %shf_result.1, %viaddmnmx.1
  br label %BB_05f0

BB_05f0:                                          ; preds = %BB_0310
  %cond_not = xor i1 %isetrp_cmp1.2, true
  br i1 %cond_not, label %BB_800005f0, label %BB_0600

BB_800005f0:                                      ; preds = %BB_05f0
  %"R68:R332_addr_ptr" = inttoptr i64 %32 to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R68:R332_addr_ptr", align 4
  br label %BB_0600

BB_0600:                                          ; preds = %BB_800005f0, %BB_05f0
  %phi.6 = phi float [ %ldg.2, %BB_800005f0 ], [ 0.000000e+00, %BB_05f0 ]
  %viadd.5 = add i32 %shf_result.1, 20
  br label %BB_0610

BB_0610:                                          ; preds = %BB_0600
  %cond_not.1 = xor i1 %isetrp_cmp1.3, true
  br i1 %cond_not.1, label %BB_80000610, label %BB_0620

BB_80000610:                                      ; preds = %BB_0610
  %"R60:R49_addr_ptr" = inttoptr i64 %25 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R60:R49_addr_ptr", align 4
  br label %BB_0620

BB_0620:                                          ; preds = %BB_80000610, %BB_0610
  %phi.7 = phi float [ %ldg.3, %BB_80000610 ], [ 0.000000e+00, %BB_0610 ]
  %43 = mul i64 %42, %8
  %44 = add i64 %43, %4
  %.293 = shl i64 %44, 2
  %45 = add i64 %ldc_const.6, %.293
  %isetrp_cmp1.4 = icmp sgt i32 %viadd.2, %viaddmnmx.1
  %.299 = sext i32 %viadd.5 to i64
  %.302 = shl i64 %.299, 1
  %46 = zext i32 %viadd.5 to i64
  %47 = and i64 %.302, -4294967296
  %48 = add i64 %5, %46
  %49 = add i64 %48, %47
  br label %BB_06c0

BB_06c0:                                          ; preds = %BB_0620
  %cond_not.2 = xor i1 %isetrp_cmp1.4, true
  br i1 %cond_not.2, label %BB_800006c0, label %BB_06d0

BB_800006c0:                                      ; preds = %BB_06c0
  %"R396:R375_addr_ptr" = inttoptr i64 %35 to ptr addrspace(1)
  %ldg.4 = load float, ptr addrspace(1) %"R396:R375_addr_ptr", align 4
  br label %BB_06d0

BB_06d0:                                          ; preds = %BB_800006c0, %BB_06c0
  %phi.8 = phi float [ %ldg.4, %BB_800006c0 ], [ 0.000000e+00, %BB_06c0 ]
  %viadd.6 = add i32 %shf_result.1, 24
  %50 = mul i64 %49, %8
  %51 = add i64 %50, %4
  %.325 = shl i64 %51, 2
  %52 = add i64 %ldc_const.6, %.325
  %isetrp_cmp1.5 = icmp sgt i32 %viadd.3, %viaddmnmx.1
  %.331 = sext i32 %viadd.6 to i64
  %.334 = shl i64 %.331, 1
  %53 = zext i32 %viadd.6 to i64
  %54 = and i64 %.334, -4294967296
  %55 = add i64 %5, %53
  %56 = add i64 %55, %54
  br label %BB_0780

BB_0780:                                          ; preds = %BB_06d0
  %cond_not.3 = xor i1 %isetrp_cmp1.5, true
  br i1 %cond_not.3, label %BB_80000780, label %BB_0790

BB_80000780:                                      ; preds = %BB_0780
  %"R367:R146_addr_ptr" = inttoptr i64 %38 to ptr addrspace(1)
  %ldg.5 = load float, ptr addrspace(1) %"R367:R146_addr_ptr", align 4
  br label %BB_0790

BB_0790:                                          ; preds = %BB_80000780, %BB_0780
  %phi.9 = phi float [ %ldg.5, %BB_80000780 ], [ 0.000000e+00, %BB_0780 ]
  %57 = mul i64 %56, %8
  %58 = add i64 %57, %4
  %.357 = shl i64 %58, 2
  %59 = add i64 %ldc_const.6, %.357
  %viadd.7 = add i32 %shf_result.1, 28
  %.363 = sext i32 %viadd.7 to i64
  %.366 = shl i64 %.363, 1
  %60 = zext i32 %viadd.7 to i64
  %61 = and i64 %.366, -4294967296
  %62 = add i64 %5, %60
  %63 = add i64 %62, %61
  %isetrp_cmp1.6 = icmp sgt i32 %viadd.5, %viaddmnmx.1
  %isetrp_cmp1.7 = icmp sgt i32 %viadd.4, %viaddmnmx.1
  %isetrp_cmp1.8 = icmp sgt i32 %viadd.6, %viaddmnmx.1
  %isetrp_cmp1.9 = icmp sgt i32 %viadd.7, %viaddmnmx.1
  %64 = mul i64 %63, %8
  %65 = add i64 %64, %4
  %.386 = shl i64 %65, 2
  %66 = add i64 %ldc_const.6, %.386
  br label %BB_08c0

BB_08c0:                                          ; preds = %BB_0790
  %cond_not.4 = xor i1 %isetrp_cmp1.8, true
  br i1 %cond_not.4, label %BB_800008c0, label %BB_08d0

BB_800008c0:                                      ; preds = %BB_08c0
  %"R124:R338_addr_ptr" = inttoptr i64 %59 to ptr addrspace(1)
  %ldg.6 = load float, ptr addrspace(1) %"R124:R338_addr_ptr", align 4
  br label %BB_08d0

BB_08d0:                                          ; preds = %BB_800008c0, %BB_08c0
  %phi.10 = phi float [ %ldg.6, %BB_800008c0 ], [ 0.000000e+00, %BB_08c0 ]
  %cond_not.5 = xor i1 %isetrp_cmp1.7, true
  br i1 %cond_not.5, label %BB_800008d0, label %BB_08e0

BB_800008d0:                                      ; preds = %BB_08d0
  %"R112:R274_addr_ptr" = inttoptr i64 %45 to ptr addrspace(1)
  %ldg.7 = load float, ptr addrspace(1) %"R112:R274_addr_ptr", align 4
  br label %BB_08e0

BB_08e0:                                          ; preds = %BB_800008d0, %BB_08d0
  %phi.11 = phi float [ %ldg.7, %BB_800008d0 ], [ 0.000000e+00, %BB_08d0 ]
  %cond_not.6 = xor i1 %isetrp_cmp1.6, true
  br i1 %cond_not.6, label %BB_800008e0, label %BB_08f0

BB_800008e0:                                      ; preds = %BB_08e0
  %"R320:R183_addr_ptr" = inttoptr i64 %52 to ptr addrspace(1)
  %ldg.8 = load float, ptr addrspace(1) %"R320:R183_addr_ptr", align 4
  br label %BB_08f0

BB_08f0:                                          ; preds = %BB_800008e0, %BB_08e0
  %phi.12 = phi float [ %ldg.8, %BB_800008e0 ], [ 0.000000e+00, %BB_08e0 ]
  %cond_not.7 = xor i1 %isetrp_cmp1.9, true
  br i1 %cond_not.7, label %BB_800008f0, label %BB_0900

BB_800008f0:                                      ; preds = %BB_08f0
  %"R405:R382_addr_ptr" = inttoptr i64 %66 to ptr addrspace(1)
  %ldg.9 = load float, ptr addrspace(1) %"R405:R382_addr_ptr", align 4
  br label %BB_0900

BB_0900:                                          ; preds = %BB_800008f0, %BB_08f0
  %phi.13 = phi float [ %ldg.9, %BB_800008f0 ], [ 0.000000e+00, %BB_08f0 ]
  %fmul.1 = fmul float %phi.6, %phi.4
  %fmul.2 = fmul float %phi.7, %phi.4
  %sts_addr_memaddr_offset_add.7 = add i32 %.118, 1040
  %.401 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.7
  store volatile float %fmul.1, ptr addrspace(3) %.401, align 4
  %.403 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.118
  store volatile float %fmul.2, ptr addrspace(3) %.403, align 4
  %fmul.3 = fmul float %phi.8, %phi.4
  %sts_addr_memaddr_offset_add.8 = add i32 %.118, 2080
  %.405 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.8
  store volatile float %fmul.3, ptr addrspace(3) %.405, align 4
  %fmul.4 = fmul float %phi.9, %phi.4
  %sts_addr_memaddr_offset_add.9 = add i32 %.118, 3120
  %.407 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.9
  store volatile float %fmul.4, ptr addrspace(3) %.407, align 4
  %fmul.5 = fmul float %phi.10, %phi.4
  %fmul.6 = fmul float %phi.11, %phi.4
  %fmul.7 = fmul float %phi.12, %phi.4
  %fmul.8 = fmul float %phi.13, %phi.4
  %sts_addr_memaddr_offset_add.10 = add i32 %.118, 4160
  %.409 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.10
  store volatile float %fmul.6, ptr addrspace(3) %.409, align 4
  %sts_addr_memaddr_offset_add.11 = add i32 %.118, 5200
  %.411 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.11
  store volatile float %fmul.7, ptr addrspace(3) %.411, align 4
  %sts_addr_memaddr_offset_add.12 = add i32 %.118, 6240
  %.413 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.12
  store volatile float %fmul.5, ptr addrspace(3) %.413, align 4
  %sts_addr_memaddr_offset_add.13 = add i32 %.118, 7280
  %.415 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_addr_memaddr_offset_add.13
  store volatile float %fmul.8, ptr addrspace(3) %.415, align 4
  br label %BB_0a00

BB_0a00:                                          ; preds = %BB_0900, %BB_0270, %BB_0220
  call void @llvm.nvvm.barrier0()
  br label %BB_0a30

BB_0a30:                                          ; preds = %BB_0a00
  %67 = zext i1 %isetrp_cmp1.1 to i32
  %68 = icmp ne i32 %67, 0
  br i1 %68, label %BB_1370, label %BB_0a40

BB_0a40:                                          ; preds = %BB_0a30
  %fsetrp_cmp1.1 = fcmp une float %phi.5, 0.000000e+00
  %.420 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 548
  %ldc_const.7 = load i32, ptr %.420, align 4
  %69 = sext i32 %ldc_const.7 to i64
  br label %BB_0a70

BB_0a70:                                          ; preds = %BB_0a40
  %70 = zext i1 %fsetrp_cmp1.1 to i32
  %71 = icmp ne i32 %70, 0
  br i1 %71, label %BB_0c10, label %BB_0a80

BB_0a80:                                          ; preds = %BB_0a70
  %.428 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.118
  %lds = load volatile float, ptr addrspace(3) %.428, align 4
  %lds_addr_memaddr_offset_add = add i32 %.118, 1040
  %.429 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add
  %lds.1 = load volatile float, ptr addrspace(3) %.429, align 4
  %lds_addr_memaddr_offset_add.1 = add i32 %.118, 2080
  %.430 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.1
  %lds.2 = load volatile float, ptr addrspace(3) %.430, align 4
  %lds_addr_memaddr_offset_add.2 = add i32 %.118, 3120
  %.431 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.2
  %lds.3 = load volatile float, ptr addrspace(3) %.431, align 4
  %lds_addr_memaddr_offset_add.3 = add i32 %.118, 4160
  %.432 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.3
  %lds.4 = load volatile float, ptr addrspace(3) %.432, align 4
  %lds_addr_memaddr_offset_add.4 = add i32 %.118, 5200
  %.433 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.4
  %lds.5 = load volatile float, ptr addrspace(3) %.433, align 4
  %lds_addr_memaddr_offset_add.5 = add i32 %.118, 6240
  %.434 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.5
  %lds.6 = load volatile float, ptr addrspace(3) %.434, align 4
  %lds_addr_memaddr_offset_add.6 = add i32 %.118, 7280
  %.435 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.6
  %lds.7 = load volatile float, ptr addrspace(3) %.435, align 4
  %ffma = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds)
  %ffma.1 = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds.1)
  store volatile float %ffma, ptr addrspace(3) %.428, align 4
  %ffma.2 = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds.2)
  store volatile float %ffma.1, ptr addrspace(3) %.429, align 4
  %ffma.3 = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds.3)
  store volatile float %ffma.2, ptr addrspace(3) %.430, align 4
  %ffma.4 = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds.4)
  store volatile float %ffma.3, ptr addrspace(3) %.431, align 4
  %ffma.5 = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds.5)
  store volatile float %ffma.4, ptr addrspace(3) %.432, align 4
  %ffma.6 = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds.6)
  store volatile float %ffma.5, ptr addrspace(3) %.433, align 4
  %ffma.7 = call float @llvm.fma.f32(float 0.000000e+00, float %phi.5, float %lds.7)
  store volatile float %ffma.6, ptr addrspace(3) %.434, align 4
  store volatile float %ffma.7, ptr addrspace(3) %.435, align 4
  br label %BB_1370

BB_0c10:                                          ; preds = %BB_0a70
  %viadd.8 = add i32 %shf_result.1, 4
  %ldc_const.8 = load i64, ptr %.14, align 8
  %viadd.9 = add i32 %shf_result.1, 8
  %.455 = sext i32 %shf_result.1 to i64
  %.458 = shl i64 %.455, 1
  %72 = zext i32 %shf_result.1 to i64
  %73 = and i64 %.458, -4294967296
  %74 = add i64 %5, %72
  %75 = add i64 %74, %73
  %viadd.10 = add i32 %shf_result.1, 12
  %viadd.11 = add i32 %shf_result.1, 16
  %.464 = sext i32 %viadd.8 to i64
  %.467 = shl i64 %.464, 1
  %76 = zext i32 %viadd.8 to i64
  %77 = and i64 %.467, -4294967296
  %78 = add i64 %5, %76
  %79 = add i64 %78, %77
  %viadd.12 = add i32 %shf_result.1, 20
  %.473 = sext i32 %viadd.9 to i64
  %.476 = shl i64 %.473, 1
  %80 = zext i32 %viadd.9 to i64
  %81 = and i64 %.476, -4294967296
  %82 = add i64 %5, %80
  %83 = add i64 %82, %81
  %84 = mul i64 %75, %69
  %85 = add i64 %84, %4
  %.496 = shl i64 %85, 2
  %86 = add i64 %ldc_const.8, %.496
  %87 = mul i64 %79, %69
  %88 = add i64 %87, %4
  %.516 = shl i64 %88, 2
  %89 = add i64 %ldc_const.8, %.516
  %.522 = sext i32 %viadd.10 to i64
  %.525 = shl i64 %.522, 1
  %90 = zext i32 %viadd.10 to i64
  %91 = and i64 %.525, -4294967296
  %92 = add i64 %5, %90
  %93 = add i64 %92, %91
  %94 = mul i64 %83, %69
  %95 = add i64 %94, %4
  %.540 = sext i32 %viadd.11 to i64
  %.543 = shl i64 %.540, 1
  %96 = zext i32 %viadd.11 to i64
  %97 = and i64 %.543, -4294967296
  %98 = add i64 %5, %96
  %99 = add i64 %98, %97
  %.554 = shl i64 %95, 2
  %100 = add i64 %ldc_const.8, %.554
  %isetrp_cmp1.10 = icmp sgt i32 %viadd.8, %viaddmnmx.1
  %101 = mul i64 %93, %69
  %102 = add i64 %101, %4
  %.574 = shl i64 %102, 2
  %103 = add i64 %ldc_const.8, %.574
  %104 = mul i64 %99, %69
  %105 = add i64 %104, %4
  %.594 = shl i64 %105, 2
  %106 = add i64 %ldc_const.8, %.594
  %isetrp_cmp1.11 = icmp sgt i32 %shf_result.1, %viaddmnmx.1
  %.600 = sext i32 %viadd.12 to i64
  %.603 = shl i64 %.600, 1
  %107 = zext i32 %viadd.12 to i64
  %108 = and i64 %.603, -4294967296
  %109 = add i64 %5, %107
  %110 = add i64 %109, %108
  br label %BB_0f60

BB_0f60:                                          ; preds = %BB_0c10
  %cond_not.8 = xor i1 %isetrp_cmp1.11, true
  br i1 %cond_not.8, label %BB_80000f60, label %BB_0f70

BB_80000f60:                                      ; preds = %BB_0f60
  %"R353:R168_addr_ptr" = inttoptr i64 %86 to ptr addrspace(1)
  %ldg.10 = load float, ptr addrspace(1) %"R353:R168_addr_ptr", align 4
  br label %BB_0f70

BB_0f70:                                          ; preds = %BB_80000f60, %BB_0f60
  %phi.14 = phi float [ %ldg.10, %BB_80000f60 ], [ 0.000000e+00, %BB_0f60 ]
  br label %BB_0f80

BB_0f80:                                          ; preds = %BB_0f70
  %cond_not.9 = xor i1 %isetrp_cmp1.10, true
  br i1 %cond_not.9, label %BB_80000f80, label %BB_0f90

BB_80000f80:                                      ; preds = %BB_0f80
  %"R391:R385_addr_ptr" = inttoptr i64 %89 to ptr addrspace(1)
  %ldg.11 = load float, ptr addrspace(1) %"R391:R385_addr_ptr", align 4
  br label %BB_0f90

BB_0f90:                                          ; preds = %BB_80000f80, %BB_0f80
  %phi.15 = phi float [ %ldg.11, %BB_80000f80 ], [ 0.000000e+00, %BB_0f80 ]
  %111 = mul i64 %110, %69
  %112 = add i64 %111, %4
  %viadd.13 = add i32 %shf_result.1, 24
  %.629 = shl i64 %112, 2
  %113 = add i64 %ldc_const.8, %.629
  %.635 = sext i32 %viadd.13 to i64
  %.638 = shl i64 %.635, 1
  %114 = zext i32 %viadd.13 to i64
  %115 = and i64 %.638, -4294967296
  %116 = add i64 %5, %114
  %117 = add i64 %116, %115
  %isetrp_cmp1.12 = icmp sgt i32 %viadd.9, %viaddmnmx.1
  %isetrp_cmp1.13 = icmp sgt i32 %viadd.10, %viaddmnmx.1
  %lds_addr_memaddr_offset_add.7 = add i32 %.118, 4160
  %.644 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.7
  %lds.8 = load volatile float, ptr addrspace(3) %.644, align 4
  %118 = mul i64 %117, %69
  %119 = add i64 %118, %4
  %.654 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.118
  %lds.9 = load volatile float, ptr addrspace(3) %.654, align 4
  %.660 = shl i64 %119, 2
  %120 = add i64 %ldc_const.8, %.660
  %viadd.14 = add i32 %shf_result.1, 28
  %.666 = sext i32 %viadd.14 to i64
  %.669 = shl i64 %.666, 1
  %121 = zext i32 %viadd.14 to i64
  %122 = and i64 %.669, -4294967296
  %123 = add i64 %5, %121
  %124 = add i64 %123, %122
  %isetrp_cmp1.14 = icmp sgt i32 %viadd.11, %viaddmnmx.1
  %isetrp_cmp1.15 = icmp sgt i32 %viadd.12, %viaddmnmx.1
  %isetrp_cmp1.16 = icmp sgt i32 %viadd.13, %viaddmnmx.1
  %125 = mul i64 %124, %69
  %126 = add i64 %125, %4
  %isetrp_cmp1.17 = icmp sgt i32 %viadd.14, %viaddmnmx.1
  %.689 = shl i64 %126, 2
  %127 = add i64 %ldc_const.8, %.689
  %lds_addr_memaddr_offset_add.8 = add i32 %.118, 2080
  %.695 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.8
  %lds.10 = load volatile float, ptr addrspace(3) %.695, align 4
  br label %BB_11c0

BB_11c0:                                          ; preds = %BB_0f90
  %cond_not.10 = xor i1 %isetrp_cmp1.12, true
  br i1 %cond_not.10, label %BB_800011c0, label %BB_11d0

BB_800011c0:                                      ; preds = %BB_11c0
  %"R3:R277_addr_ptr" = inttoptr i64 %100 to ptr addrspace(1)
  %ldg.12 = load float, ptr addrspace(1) %"R3:R277_addr_ptr", align 4
  br label %BB_11d0

BB_11d0:                                          ; preds = %BB_800011c0, %BB_11c0
  %phi.16 = phi float [ %ldg.12, %BB_800011c0 ], [ 0.000000e+00, %BB_11c0 ]
  %cond_not.11 = xor i1 %isetrp_cmp1.13, true
  br i1 %cond_not.11, label %BB_800011d0, label %BB_11e0

BB_800011d0:                                      ; preds = %BB_11d0
  %"R286:R253_addr_ptr" = inttoptr i64 %103 to ptr addrspace(1)
  %ldg.13 = load float, ptr addrspace(1) %"R286:R253_addr_ptr", align 4
  br label %BB_11e0

BB_11e0:                                          ; preds = %BB_800011d0, %BB_11d0
  %phi.17 = phi float [ %ldg.13, %BB_800011d0 ], [ 0.000000e+00, %BB_11d0 ]
  %cond_not.12 = xor i1 %isetrp_cmp1.14, true
  br i1 %cond_not.12, label %BB_800011e0, label %BB_11f0

BB_800011e0:                                      ; preds = %BB_11e0
  %"R270:R48_addr_ptr" = inttoptr i64 %106 to ptr addrspace(1)
  %ldg.14 = load float, ptr addrspace(1) %"R270:R48_addr_ptr", align 4
  br label %BB_11f0

BB_11f0:                                          ; preds = %BB_800011e0, %BB_11e0
  %phi.18 = phi float [ %ldg.14, %BB_800011e0 ], [ 0.000000e+00, %BB_11e0 ]
  %cond_not.13 = xor i1 %isetrp_cmp1.15, true
  br i1 %cond_not.13, label %BB_800011f0, label %BB_1200

BB_800011f0:                                      ; preds = %BB_11f0
  %"R334:R329_addr_ptr" = inttoptr i64 %113 to ptr addrspace(1)
  %ldg.15 = load float, ptr addrspace(1) %"R334:R329_addr_ptr", align 4
  br label %BB_1200

BB_1200:                                          ; preds = %BB_800011f0, %BB_11f0
  %phi.19 = phi float [ %ldg.15, %BB_800011f0 ], [ 0.000000e+00, %BB_11f0 ]
  %cond_not.14 = xor i1 %isetrp_cmp1.16, true
  br i1 %cond_not.14, label %BB_80001200, label %BB_1210

BB_80001200:                                      ; preds = %BB_1200
  %"R392:R386_addr_ptr" = inttoptr i64 %120 to ptr addrspace(1)
  %ldg.16 = load float, ptr addrspace(1) %"R392:R386_addr_ptr", align 4
  br label %BB_1210

BB_1210:                                          ; preds = %BB_80001200, %BB_1200
  %phi.20 = phi float [ %ldg.16, %BB_80001200 ], [ 0.000000e+00, %BB_1200 ]
  %cond_not.15 = xor i1 %isetrp_cmp1.17, true
  br i1 %cond_not.15, label %BB_80001210, label %BB_1220

BB_80001210:                                      ; preds = %BB_1210
  %"R359:R224_addr_ptr" = inttoptr i64 %127 to ptr addrspace(1)
  %ldg.17 = load float, ptr addrspace(1) %"R359:R224_addr_ptr", align 4
  br label %BB_1220

BB_1220:                                          ; preds = %BB_80001210, %BB_1210
  %phi.21 = phi float [ %ldg.17, %BB_80001210 ], [ 0.000000e+00, %BB_1210 ]
  %lds_addr_memaddr_offset_add.9 = add i32 %.118, 1040
  %.709 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.9
  %lds.11 = load volatile float, ptr addrspace(3) %.709, align 4
  %lds_addr_memaddr_offset_add.10 = add i32 %.118, 3120
  %.710 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.10
  %lds.12 = load volatile float, ptr addrspace(3) %.710, align 4
  %lds_addr_memaddr_offset_add.11 = add i32 %.118, 5200
  %.711 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.11
  %lds.13 = load volatile float, ptr addrspace(3) %.711, align 4
  %lds_addr_memaddr_offset_add.12 = add i32 %.118, 6240
  %.712 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.12
  %lds.14 = load volatile float, ptr addrspace(3) %.712, align 4
  %lds_addr_memaddr_offset_add.13 = add i32 %.118, 7280
  %.713 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.13
  %lds.15 = load volatile float, ptr addrspace(3) %.713, align 4
  %ffma.8 = call float @llvm.fma.f32(float %phi.14, float %phi.5, float %lds.9)
  %ffma.9 = call float @llvm.fma.f32(float %phi.15, float %phi.5, float %lds.11)
  store volatile float %ffma.8, ptr addrspace(3) %.654, align 4
  store volatile float %ffma.9, ptr addrspace(3) %.709, align 4
  %ffma.10 = call float @llvm.fma.f32(float %phi.16, float %phi.5, float %lds.10)
  %ffma.11 = call float @llvm.fma.f32(float %phi.17, float %phi.5, float %lds.12)
  %ffma.12 = call float @llvm.fma.f32(float %phi.18, float %phi.5, float %lds.8)
  %ffma.13 = call float @llvm.fma.f32(float %phi.19, float %phi.5, float %lds.13)
  %ffma.14 = call float @llvm.fma.f32(float %phi.20, float %phi.5, float %lds.14)
  %ffma.15 = call float @llvm.fma.f32(float %phi.21, float %phi.5, float %lds.15)
  store volatile float %ffma.10, ptr addrspace(3) %.695, align 4
  store volatile float %ffma.11, ptr addrspace(3) %.710, align 4
  store volatile float %ffma.12, ptr addrspace(3) %.644, align 4
  store volatile float %ffma.13, ptr addrspace(3) %.711, align 4
  store volatile float %ffma.14, ptr addrspace(3) %.712, align 4
  store volatile float %ffma.15, ptr addrspace(3) %.713, align 4
  br label %BB_1370

BB_1370:                                          ; preds = %BB_1220, %BB_0a80, %BB_0a30
  %isetrp_cmp1.18 = icmp sgt i32 %shf_result.5, %viaddmnmx.1
  %viadd.15 = add i32 %shf_result.5, 8
  %128 = sext i32 %shf_result to i64
  %viadd.16 = add i32 %shf_result.5, 16
  %.735 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 552
  %ldc_const.9 = load i32, ptr %.735, align 4
  %viadd.17 = add i32 %shf_result.5, 24
  %isetrp_cmp1.19 = icmp sgt i32 %viadd.15, %viaddmnmx.1
  %viadd.18 = add i32 %viadd.15, %shf_result.2
  %isetrp_cmp1.20 = icmp sgt i32 %viadd.16, %viaddmnmx.1
  %viadd.19 = add i32 %viadd.17, %shf_result.2
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.21 = icmp sgt i32 %viadd.17, %viaddmnmx.1
  %viadd.20 = add i32 %viadd.16, %shf_result.2
  %.738 = zext i32 %viadd.18 to i64
  %129 = sext i32 %viadd.18 to i64
  %.742 = zext i32 %ldc_const.9 to i64
  %130 = sext i32 %ldc_const.9 to i64
  %.748 = and i32 %tid_x, 31
  %.754 = zext i32 %viadd.20 to i64
  %131 = sext i32 %viadd.20 to i64
  %.758 = zext i32 %viadd.19 to i64
  %132 = sext i32 %viadd.19 to i64
  br label %BB_14e0

BB_14e0:                                          ; preds = %BB_1370
  %133 = zext i1 %isetrp_cmp1.18 to i32
  %134 = icmp ne i32 %133, 0
  br i1 %134, label %BB_1670, label %BB_14f0

BB_14f0:                                          ; preds = %BB_14e0
  %viadd.21 = add i32 %shf_result.5, %shf_result.2
  %.763 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 560
  %ldc_const.10 = load i32, ptr %.763, align 4
  %ldc_const.11 = load i64, ptr %.17, align 8
  %imad_lhs_64.16 = sext i32 %viadd.21 to i64
  %imad_rhs_64.16 = sext i32 %ldc_const.9 to i64
  %imad_tmp_64.16 = mul i64 %imad_lhs_64.16, %imad_rhs_64.16
  %imad.68 = add i64 %imad_tmp_64.16, %128
  %"R13:R12_r0.5" = trunc i64 %imad.68 to i32
  %135 = add i64 %imad_tmp_64.16, %128
  %viadd.22 = add i32 %"R13:R12_r0.5", %ldc_const.10
  %.770 = and i32 %viadd.22, 31
  %iadd3_o1_raw64 = zext i32 %.770 to i64
  %iadd3_o1_not64 = xor i64 %iadd3_o1_raw64, -1
  %iadd3_o1_not64_masked = and i64 %iadd3_o1_not64, 4294967295
  %iadd3_o1_neg64 = add i64 %iadd3_o1_not64_masked, 1
  %iadd3_o2_64.16 = zext i32 %"R13:R12_r0.5" to i64
  %iadd3_o3_64.16 = zext i32 %.748 to i64
  %iadd3_tmp.16 = add i64 %iadd3_o1_neg64, %iadd3_o2_64.16
  %iadd3_tmp2.16 = add i64 %iadd3_tmp.16, %iadd3_o3_64.16
  %iadd3_trunc.16 = trunc i64 %iadd3_tmp2.16 to i32
  %iadd3_o1_not = xor i32 %"R13:R12_r0.5", -1
  %iadd3_o1_neg = add i32 %iadd3_o1_not, 1
  %iadd3_n1.1 = add i32 %iadd3_o1_neg, 32
  %iadd3_n2.1 = add i32 %iadd3_n1.1, %iadd3_trunc.16
  %imad_addend_neg = sub i32 0, %"R13:R12_r0.5"
  %imad.69 = add i32 %iadd3_trunc.16, %imad_addend_neg
  %iadd3_n1.2 = add i32 %iadd3_o1_neg, 64
  %iadd3_n2.2 = add i32 %iadd3_n1.2, %iadd3_trunc.16
  %136 = and i64 %iadd3_o1_not64, 4294967295
  %137 = zext i32 %.748 to i64
  %138 = add i64 %135, %136
  %139 = add i64 %138, 1
  %140 = add i64 %139, %137
  %141 = add i64 %140, -4294967296
  %imad_tmp.53 = mul i32 %shf_result.5, 65
  %imad.70 = add i32 %imad_tmp.53, %imad.69
  %isetrp_cmp1.22 = icmp uge i32 %viaddmnmx, %imad.69
  %isetrp_cmp1.23 = icmp uge i32 %viaddmnmx, %iadd3_n2.1
  %isetrp_cmp1.24 = icmp uge i32 %viaddmnmx, %iadd3_n2.2
  %.775 = zext i32 %imad.70 to i64
  %.778 = shl i64 %.775, 2
  %.779 = and i64 %.778, 4294967295
  %.780 = add i64 %.779, %.113
  %.781 = trunc i64 %.780 to i32
  %.796 = shl i64 %141, 2
  %142 = add i64 %ldc_const.11, %.796
  br label %BB_1610

BB_1610:                                          ; preds = %BB_14f0
  %143 = zext i1 %isetrp_cmp1.22 to i32
  %144 = icmp ne i32 %143, 0
  br i1 %144, label %BB_80001610, label %BB_1620

BB_80001610:                                      ; preds = %BB_1610
  %.804 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.781
  %lds.16 = load volatile i32, ptr addrspace(3) %.804, align 4
  br label %BB_1620

BB_1620:                                          ; preds = %BB_80001610, %BB_1610
  %phi.22 = phi i32 [ %lds.16, %BB_80001610 ], [ poison, %BB_1610 ]
  %warp_reconv_mask = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  br i1 %isetrp_cmp1.23, label %BB_80001620, label %BB_1630

BB_80001620:                                      ; preds = %BB_1620
  %lds_addr_memaddr_offset_add.14 = add i32 %.781, 128
  %.807 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.14
  %lds.17 = load volatile i32, ptr addrspace(3) %.807, align 4
  br label %BB_1630

BB_1630:                                          ; preds = %BB_80001620, %BB_1620
  %phi.23 = phi i32 [ %lds.17, %BB_80001620 ], [ poison, %BB_1620 ]
  br i1 %isetrp_cmp1.24, label %BB_80001630, label %BB_1640

BB_80001630:                                      ; preds = %BB_1630
  %lds_addr_memaddr_offset_add.15 = add i32 %.781, 256
  %.810 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.15
  %lds.18 = load volatile i32, ptr addrspace(3) %.810, align 4
  br label %BB_1640

BB_1640:                                          ; preds = %BB_80001630, %BB_1630
  %phi.24 = phi i32 [ %lds.18, %BB_80001630 ], [ poison, %BB_1630 ]
  %warp_reconv_mask.1 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  br i1 %isetrp_cmp1.22, label %BB_80001640, label %BB_1650

BB_80001640:                                      ; preds = %BB_1640
  %"R293:R260_addr_ptr" = inttoptr i64 %142 to ptr addrspace(1)
  store i32 %phi.22, ptr addrspace(1) %"R293:R260_addr_ptr", align 4
  br label %BB_1650

BB_1650:                                          ; preds = %BB_80001640, %BB_1640
  %145 = zext i1 %isetrp_cmp1.23 to i32
  %146 = icmp ne i32 %145, 0
  br i1 %146, label %BB_80001650, label %BB_1660

BB_80001650:                                      ; preds = %BB_1650
  %stg_addr_memaddr_offset_add = add i64 %142, 128
  %"R293:R260_addr_ptr.1" = inttoptr i64 %stg_addr_memaddr_offset_add to ptr addrspace(1)
  store i32 %phi.23, ptr addrspace(1) %"R293:R260_addr_ptr.1", align 4
  br label %BB_1660

BB_1660:                                          ; preds = %BB_80001650, %BB_1650
  %147 = zext i1 %isetrp_cmp1.24 to i32
  %148 = icmp ne i32 %147, 0
  br i1 %148, label %BB_80001660, label %BB_1670

BB_80001660:                                      ; preds = %BB_1660
  %stg_addr_memaddr_offset_add.1 = add i64 %142, 256
  %"R293:R260_addr_ptr.2" = inttoptr i64 %stg_addr_memaddr_offset_add.1 to ptr addrspace(1)
  store i32 %phi.24, ptr addrspace(1) %"R293:R260_addr_ptr.2", align 4
  br label %BB_1670

BB_1670:                                          ; preds = %BB_80001660, %BB_1660, %BB_14e0
  br label %BB_16c0

BB_16c0:                                          ; preds = %BB_1670
  %149 = zext i1 %isetrp_cmp1.19 to i32
  %150 = icmp ne i32 %149, 0
  br i1 %150, label %BB_1850, label %BB_16d0

BB_16d0:                                          ; preds = %BB_16c0
  %imad_tmp_64.17 = mul i64 %.738, %.742
  %imad.74 = add i64 %imad_tmp_64.17, %128
  %"R13:R12_r0.6" = trunc i64 %imad.74 to i32
  %.823 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 560
  %ldc_const.12 = load i32, ptr %.823, align 4
  %ldc_const.13 = load i64, ptr %.17, align 8
  %viadd.23 = add i32 %"R13:R12_r0.6", %ldc_const.12
  %151 = mul i64 %129, %130
  %152 = add i64 %151, %128
  %.830 = and i32 %viadd.23, 31
  %iadd3_o1_raw64.1 = zext i32 %.830 to i64
  %iadd3_o1_not64.1 = xor i64 %iadd3_o1_raw64.1, -1
  %iadd3_o1_not64_masked.1 = and i64 %iadd3_o1_not64.1, 4294967295
  %iadd3_o1_neg64.1 = add i64 %iadd3_o1_not64_masked.1, 1
  %iadd3_o2_64.17 = zext i32 %"R13:R12_r0.6" to i64
  %iadd3_o3_64.17 = zext i32 %.748 to i64
  %iadd3_tmp.17 = add i64 %iadd3_o1_neg64.1, %iadd3_o2_64.17
  %iadd3_tmp2.17 = add i64 %iadd3_tmp.17, %iadd3_o3_64.17
  %iadd3_trunc.17 = trunc i64 %iadd3_tmp2.17 to i32
  %iadd3_o1_not.2 = xor i32 %"R13:R12_r0.6", -1
  %iadd3_o1_neg.2 = add i32 %iadd3_o1_not.2, 1
  %iadd3_n1.4 = add i32 %iadd3_o1_neg.2, 32
  %iadd3_n2.4 = add i32 %iadd3_n1.4, %iadd3_trunc.17
  %imad_addend_neg.1 = sub i32 0, %"R13:R12_r0.6"
  %imad.76 = add i32 %iadd3_trunc.17, %imad_addend_neg.1
  %iadd3_n1.5 = add i32 %iadd3_o1_neg.2, 64
  %iadd3_n2.5 = add i32 %iadd3_n1.5, %iadd3_trunc.17
  %isetrp_cmp1.25 = icmp uge i32 %viaddmnmx, %iadd3_n2.4
  %imad_tmp.59 = mul i32 %viadd.15, 65
  %imad.77 = add i32 %imad_tmp.59, %imad.76
  %isetrp_cmp1.26 = icmp uge i32 %viaddmnmx, %imad.76
  %isetrp_cmp1.27 = icmp uge i32 %viaddmnmx, %iadd3_n2.5
  %.835 = zext i32 %imad.77 to i64
  %.838 = shl i64 %.835, 2
  %.839 = and i64 %.838, 4294967295
  %.840 = add i64 %.839, %.113
  %.841 = trunc i64 %.840 to i32
  %153 = and i64 %iadd3_o1_not64.1, 4294967295
  %154 = zext i32 %.748 to i64
  %155 = add i64 %152, %153
  %156 = add i64 %155, 1
  %157 = add i64 %156, %154
  %158 = add i64 %157, -4294967296
  br label %BB_17e0

BB_17e0:                                          ; preds = %BB_16d0
  %159 = zext i1 %isetrp_cmp1.25 to i32
  %160 = icmp ne i32 %159, 0
  br i1 %160, label %BB_800017e0, label %BB_17f0

BB_800017e0:                                      ; preds = %BB_17e0
  %lds_addr_memaddr_offset_add.16 = add i32 %.841, 128
  %.853 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.16
  %lds.19 = load volatile i32, ptr addrspace(3) %.853, align 4
  br label %BB_17f0

BB_17f0:                                          ; preds = %BB_800017e0, %BB_17e0
  %phi.25 = phi i32 [ %lds.19, %BB_800017e0 ], [ poison, %BB_17e0 ]
  %warp_reconv_mask.2 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.2)
  %.860 = shl i64 %158, 2
  %161 = add i64 %ldc_const.13, %.860
  br label %BB_1800

BB_1800:                                          ; preds = %BB_17f0
  %162 = zext i1 %isetrp_cmp1.26 to i32
  %163 = icmp ne i32 %162, 0
  br i1 %163, label %BB_80001800, label %BB_1810

BB_80001800:                                      ; preds = %BB_1800
  %.868 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.841
  %lds.20 = load volatile i32, ptr addrspace(3) %.868, align 4
  br label %BB_1810

BB_1810:                                          ; preds = %BB_80001800, %BB_1800
  %phi.26 = phi i32 [ %lds.20, %BB_80001800 ], [ poison, %BB_1800 ]
  %warp_reconv_mask.3 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.3)
  br i1 %isetrp_cmp1.27, label %BB_80001810, label %BB_1820

BB_80001810:                                      ; preds = %BB_1810
  %lds_addr_memaddr_offset_add.17 = add i32 %.841, 256
  %.871 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.17
  %lds.21 = load volatile i32, ptr addrspace(3) %.871, align 4
  br label %BB_1820

BB_1820:                                          ; preds = %BB_80001810, %BB_1810
  %phi.27 = phi i32 [ %lds.21, %BB_80001810 ], [ poison, %BB_1810 ]
  br i1 %isetrp_cmp1.25, label %BB_80001820, label %BB_1830

BB_80001820:                                      ; preds = %BB_1820
  %stg_addr_memaddr_offset_add.2 = add i64 %161, 128
  %"R295:R263_addr_ptr" = inttoptr i64 %stg_addr_memaddr_offset_add.2 to ptr addrspace(1)
  store i32 %phi.25, ptr addrspace(1) %"R295:R263_addr_ptr", align 4
  br label %BB_1830

BB_1830:                                          ; preds = %BB_80001820, %BB_1820
  %164 = zext i1 %isetrp_cmp1.26 to i32
  %165 = icmp ne i32 %164, 0
  br i1 %165, label %BB_80001830, label %BB_1840

BB_80001830:                                      ; preds = %BB_1830
  %"R295:R263_addr_ptr.1" = inttoptr i64 %161 to ptr addrspace(1)
  store i32 %phi.26, ptr addrspace(1) %"R295:R263_addr_ptr.1", align 4
  br label %BB_1840

BB_1840:                                          ; preds = %BB_80001830, %BB_1830
  %166 = zext i1 %isetrp_cmp1.27 to i32
  %167 = icmp ne i32 %166, 0
  br i1 %167, label %BB_80001840, label %BB_1850

BB_80001840:                                      ; preds = %BB_1840
  %stg_addr_memaddr_offset_add.3 = add i64 %161, 256
  %"R295:R263_addr_ptr.2" = inttoptr i64 %stg_addr_memaddr_offset_add.3 to ptr addrspace(1)
  store i32 %phi.27, ptr addrspace(1) %"R295:R263_addr_ptr.2", align 4
  br label %BB_1850

BB_1850:                                          ; preds = %BB_80001840, %BB_1840, %BB_16c0
  %imad_tmp_64.18 = mul i64 %.758, %.742
  %imad.79 = add i64 %imad_tmp_64.18, %128
  %"R5:R4_r0.1" = trunc i64 %imad.79 to i32
  br label %BB_18a0

BB_18a0:                                          ; preds = %BB_1850
  %168 = zext i1 %isetrp_cmp1.20 to i32
  %169 = icmp ne i32 %168, 0
  br i1 %169, label %BB_1a40, label %BB_18b0

BB_18b0:                                          ; preds = %BB_18a0
  %imad_tmp_64.19 = mul i64 %.754, %.742
  %imad.81 = add i64 %imad_tmp_64.19, %128
  %"R7:R6_r0" = trunc i64 %imad.81 to i32
  %.884 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 560
  %ldc_const.14 = load i32, ptr %.884, align 4
  %ldc_const.15 = load i64, ptr %.17, align 8
  %viadd.24 = add i32 %"R7:R6_r0", %ldc_const.14
  %170 = mul i64 %131, %130
  %171 = add i64 %170, %128
  %.891 = and i32 %viadd.24, 31
  %iadd3_o1_raw64.2 = zext i32 %.891 to i64
  %iadd3_o1_not64.2 = xor i64 %iadd3_o1_raw64.2, -1
  %iadd3_o1_not64_masked.2 = and i64 %iadd3_o1_not64.2, 4294967295
  %iadd3_o1_neg64.2 = add i64 %iadd3_o1_not64_masked.2, 1
  %iadd3_o2_64.18 = zext i32 %"R7:R6_r0" to i64
  %iadd3_o3_64.18 = zext i32 %.748 to i64
  %iadd3_tmp.18 = add i64 %iadd3_o1_neg64.2, %iadd3_o2_64.18
  %iadd3_tmp2.18 = add i64 %iadd3_tmp.18, %iadd3_o3_64.18
  %iadd3_trunc.18 = trunc i64 %iadd3_tmp2.18 to i32
  %iadd3_o1_not.4 = xor i32 %"R7:R6_r0", -1
  %iadd3_o1_neg.4 = add i32 %iadd3_o1_not.4, 1
  %iadd3_n1.7 = add i32 %iadd3_o1_neg.4, 32
  %iadd3_n2.7 = add i32 %iadd3_n1.7, %iadd3_trunc.18
  %imad_addend_neg.2 = sub i32 0, %"R7:R6_r0"
  %imad.83 = add i32 %iadd3_trunc.18, %imad_addend_neg.2
  %iadd3_n1.8 = add i32 %iadd3_o1_neg.4, 64
  %iadd3_n2.8 = add i32 %iadd3_n1.8, %iadd3_trunc.18
  %isetrp_cmp1.28 = icmp uge i32 %viaddmnmx, %iadd3_n2.7
  %imad_tmp.64 = mul i32 %viadd.16, 65
  %imad.84 = add i32 %imad_tmp.64, %imad.83
  %isetrp_cmp1.29 = icmp uge i32 %viaddmnmx, %imad.83
  %isetrp_cmp1.30 = icmp uge i32 %viaddmnmx, %iadd3_n2.8
  %.896 = zext i32 %imad.84 to i64
  %.899 = shl i64 %.896, 2
  %.900 = and i64 %.899, 4294967295
  %.901 = add i64 %.900, %.113
  %.902 = trunc i64 %.901 to i32
  %172 = and i64 %iadd3_o1_not64.2, 4294967295
  %173 = zext i32 %.748 to i64
  %174 = add i64 %171, %172
  %175 = add i64 %174, 1
  %176 = add i64 %175, %173
  %177 = add i64 %176, -4294967296
  br label %BB_19c0

BB_19c0:                                          ; preds = %BB_18b0
  %178 = zext i1 %isetrp_cmp1.28 to i32
  %179 = icmp ne i32 %178, 0
  br i1 %179, label %BB_800019c0, label %BB_19d0

BB_800019c0:                                      ; preds = %BB_19c0
  %lds_addr_memaddr_offset_add.18 = add i32 %.902, 128
  %.914 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.18
  %lds.22 = load volatile i32, ptr addrspace(3) %.914, align 4
  br label %BB_19d0

BB_19d0:                                          ; preds = %BB_800019c0, %BB_19c0
  %phi.29 = phi i32 [ %lds.22, %BB_800019c0 ], [ poison, %BB_19c0 ]
  %warp_reconv_mask.4 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.4)
  %.921 = shl i64 %177, 2
  %180 = add i64 %ldc_const.15, %.921
  br label %BB_19e0

BB_19e0:                                          ; preds = %BB_19d0
  %181 = zext i1 %isetrp_cmp1.29 to i32
  %182 = icmp ne i32 %181, 0
  br i1 %182, label %BB_800019e0, label %BB_19f0

BB_800019e0:                                      ; preds = %BB_19e0
  %.929 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.902
  %lds.23 = load volatile i32, ptr addrspace(3) %.929, align 4
  br label %BB_19f0

BB_19f0:                                          ; preds = %BB_800019e0, %BB_19e0
  %phi.30 = phi i32 [ %lds.23, %BB_800019e0 ], [ poison, %BB_19e0 ]
  %warp_reconv_mask.5 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.5)
  br i1 %isetrp_cmp1.30, label %BB_800019f0, label %BB_1a00

BB_800019f0:                                      ; preds = %BB_19f0
  %lds_addr_memaddr_offset_add.19 = add i32 %.902, 256
  %.932 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.19
  %lds.24 = load volatile i32, ptr addrspace(3) %.932, align 4
  br label %BB_1a00

BB_1a00:                                          ; preds = %BB_800019f0, %BB_19f0
  %phi.31 = phi i32 [ %lds.24, %BB_800019f0 ], [ poison, %BB_19f0 ]
  br i1 %isetrp_cmp1.28, label %BB_80001a00, label %BB_1a10

BB_80001a00:                                      ; preds = %BB_1a00
  %stg_addr_memaddr_offset_add.4 = add i64 %180, 128
  %"R162:R142_addr_ptr" = inttoptr i64 %stg_addr_memaddr_offset_add.4 to ptr addrspace(1)
  store i32 %phi.29, ptr addrspace(1) %"R162:R142_addr_ptr", align 4
  br label %BB_1a10

BB_1a10:                                          ; preds = %BB_80001a00, %BB_1a00
  %183 = zext i1 %isetrp_cmp1.29 to i32
  %184 = icmp ne i32 %183, 0
  br i1 %184, label %BB_80001a10, label %BB_1a20

BB_80001a10:                                      ; preds = %BB_1a10
  %"R162:R142_addr_ptr.1" = inttoptr i64 %180 to ptr addrspace(1)
  store i32 %phi.30, ptr addrspace(1) %"R162:R142_addr_ptr.1", align 4
  br label %BB_1a20

BB_1a20:                                          ; preds = %BB_80001a10, %BB_1a10
  %185 = zext i1 %isetrp_cmp1.30 to i32
  %186 = icmp ne i32 %185, 0
  br i1 %186, label %BB_80001a20, label %BB_1a40

BB_80001a20:                                      ; preds = %BB_1a20
  %stg_addr_memaddr_offset_add.5 = add i64 %180, 256
  %"R162:R142_addr_ptr.2" = inttoptr i64 %stg_addr_memaddr_offset_add.5 to ptr addrspace(1)
  store i32 %phi.31, ptr addrspace(1) %"R162:R142_addr_ptr.2", align 4
  br label %BB_1a40

BB_1a40:                                          ; preds = %BB_80001a20, %BB_1a20, %BB_18a0
  br i1 %isetrp_cmp1.21, label %BB_80001a40, label %BB_1a50

BB_1a50:                                          ; preds = %BB_1a40
  %.944 = getelementptr inbounds [608 x i8], ptr %param_local, i64 0, i64 560
  %ldc_const.16 = load i32, ptr %.944, align 4
  %viadd.25 = add i32 %"R5:R4_r0.1", %ldc_const.16
  %ldc_const.17 = load i64, ptr %.17, align 8
  %.951 = and i32 %viadd.25, 31
  %iadd3_o1_raw64.3 = zext i32 %.951 to i64
  %iadd3_o1_not64.3 = xor i64 %iadd3_o1_raw64.3, -1
  %iadd3_o1_not64_masked.3 = and i64 %iadd3_o1_not64.3, 4294967295
  %iadd3_o1_neg64.3 = add i64 %iadd3_o1_not64_masked.3, 1
  %iadd3_o2_64.19 = zext i32 %"R5:R4_r0.1" to i64
  %iadd3_o3_64.19 = zext i32 %.748 to i64
  %iadd3_tmp.19 = add i64 %iadd3_o1_neg64.3, %iadd3_o2_64.19
  %iadd3_tmp2.19 = add i64 %iadd3_tmp.19, %iadd3_o3_64.19
  %iadd3_trunc.19 = trunc i64 %iadd3_tmp2.19 to i32
  %187 = mul i64 %132, %130
  %188 = add i64 %187, %128
  %iadd3_o1_not.6 = xor i32 %"R5:R4_r0.1", -1
  %iadd3_o1_neg.6 = add i32 %iadd3_o1_not.6, 1
  %iadd3_n1.10 = add i32 %iadd3_o1_neg.6, 32
  %iadd3_n2.10 = add i32 %iadd3_n1.10, %iadd3_trunc.19
  %imad_addend_neg.3 = sub i32 0, %"R5:R4_r0.1"
  %imad.86 = add i32 %iadd3_trunc.19, %imad_addend_neg.3
  %189 = and i64 %iadd3_o1_not64.3, 4294967295
  %190 = zext i32 %.748 to i64
  %191 = add i64 %188, %189
  %192 = add i64 %191, 1
  %193 = add i64 %192, %190
  %194 = add i64 %193, -4294967296
  %isetrp_cmp1.31 = icmp uge i32 %viaddmnmx, %iadd3_n2.10
  %imad_tmp.67 = mul i32 %viadd.17, 65
  %imad.87 = add i32 %imad_tmp.67, %imad.86
  %isetrp_cmp1.32 = icmp uge i32 %viaddmnmx, %imad.86
  %.965 = zext i32 %imad.87 to i64
  %.968 = shl i64 %.965, 2
  %.969 = and i64 %.968, 4294967295
  %.970 = add i64 %.969, %.113
  %.971 = trunc i64 %.970 to i32
  %iadd3_n1.12 = add i32 %iadd3_o1_neg.6, 64
  %iadd3_n2.12 = add i32 %iadd3_n1.12, %iadd3_trunc.19
  %.977 = shl i64 %194, 2
  %195 = add i64 %ldc_const.17, %.977
  %isetrp_cmp1.33 = icmp uge i32 %viaddmnmx, %iadd3_n2.12
  br label %BB_1b60

BB_1b60:                                          ; preds = %BB_1a50
  %196 = zext i1 %isetrp_cmp1.31 to i32
  %197 = icmp ne i32 %196, 0
  br i1 %197, label %BB_80001b60, label %BB_1b70

BB_80001b60:                                      ; preds = %BB_1b60
  %lds_addr_memaddr_offset_add.20 = add i32 %.971, 128
  %.985 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.20
  %lds.25 = load volatile i32, ptr addrspace(3) %.985, align 4
  br label %BB_1b70

BB_1b70:                                          ; preds = %BB_80001b60, %BB_1b60
  %phi.33 = phi i32 [ %lds.25, %BB_80001b60 ], [ poison, %BB_1b60 ]
  %warp_reconv_mask.6 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.6)
  br i1 %isetrp_cmp1.32, label %BB_80001b70, label %BB_1b80

BB_80001b70:                                      ; preds = %BB_1b70
  %.988 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.971
  %lds.26 = load volatile i32, ptr addrspace(3) %.988, align 4
  br label %BB_1b80

BB_1b80:                                          ; preds = %BB_80001b70, %BB_1b70
  %phi.34 = phi i32 [ %lds.26, %BB_80001b70 ], [ poison, %BB_1b70 ]
  br i1 %isetrp_cmp1.31, label %BB_80001b80, label %BB_1b90

BB_80001b80:                                      ; preds = %BB_1b80
  %stg_addr_memaddr_offset_add.6 = add i64 %195, 128
  %"R164:R143_addr_ptr" = inttoptr i64 %stg_addr_memaddr_offset_add.6 to ptr addrspace(1)
  store i32 %phi.33, ptr addrspace(1) %"R164:R143_addr_ptr", align 4
  br label %BB_1b90

BB_1b90:                                          ; preds = %BB_80001b80, %BB_1b80
  %198 = zext i1 %isetrp_cmp1.32 to i32
  %199 = icmp ne i32 %198, 0
  br i1 %199, label %BB_80001b90, label %BB_1ba0

BB_80001b90:                                      ; preds = %BB_1b90
  %"R164:R143_addr_ptr.1" = inttoptr i64 %195 to ptr addrspace(1)
  store i32 %phi.34, ptr addrspace(1) %"R164:R143_addr_ptr.1", align 4
  br label %BB_1ba0

BB_1ba0:                                          ; preds = %BB_80001b90, %BB_1b90
  %cond_not.16 = xor i1 %isetrp_cmp1.33, true
  br i1 %cond_not.16, label %BB_80001ba0, label %BB_1bb0

BB_1bb0:                                          ; preds = %BB_1ba0
  %lds_addr_memaddr_offset_add.21 = add i32 %.971, 256
  %.997 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.21
  %lds.27 = load volatile i32, ptr addrspace(3) %.997, align 4
  %stg_addr_memaddr_offset_add.7 = add i64 %195, 256
  %"R164:R143_addr_ptr.2" = inttoptr i64 %stg_addr_memaddr_offset_add.7 to ptr addrspace(1)
  store i32 %lds.27, ptr addrspace(1) %"R164:R143_addr_ptr.2", align 4
  ret void

BB_80001ba0:                                      ; preds = %BB_1ba0
  ret void

BB_80001a40:                                      ; preds = %BB_1a40
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank() #0

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #0

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.activemask() #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #1

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { convergent nocallback nounwind }
attributes #2 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1, !2, !3, !4}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_, !"kernel", i32 1}
!2 = !{ptr @_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_, !"maxntidx", i32 256}
!3 = !{ptr @_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_, !"maxntidy", i32 1}
!4 = !{ptr @_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_, !"maxntidz", i32 1}
