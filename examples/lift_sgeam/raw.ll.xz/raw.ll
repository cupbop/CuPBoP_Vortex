; ModuleID = "/net/netscratch/hpu8/SLifter/claude_temp/bench_nvvm_eval/work/CB_sgeam/ptx/_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [32768 x i8], align 16
define void @"_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_"([36 x i8] %"arg_528", i64 %"arg_568", i64 %"arg_576", i64 %"arg_584", i64 %"arg_592", i64 %"arg_600")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [608 x i8], align 16
  %".8" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 528
  %".9" = bitcast i8* %".8" to [36 x i8]*
  store [36 x i8] %"arg_528", [36 x i8]* %".9", align 16
  %".11" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 568
  %".12" = bitcast i8* %".11" to i64*
  store i64 %"arg_568", i64* %".12", align 8
  %".14" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 576
  %".15" = bitcast i8* %".14" to i64*
  store i64 %"arg_576", i64* %".15", align 64
  %".17" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 584
  %".18" = bitcast i8* %".17" to i64*
  store i64 %"arg_584", i64* %".18", align 8
  %".20" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 592
  %".21" = bitcast i8* %".20" to i64*
  store i64 %"arg_592", i64* %".21", align 16
  %".23" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 600
  %".24" = bitcast i8* %".23" to i64*
  store i64 %"arg_600", i64* %".24", align 8
  %".26" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 556
  %".27" = bitcast i8* %".26" to i32*
  %"ldc_const" = load i32, i32* %".27"
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 0, %"ldc_const"
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %".28" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 528
  %".29" = bitcast i8* %".28" to i64*
  %"ldc_const.1" = load i64, i64* %".29"
  %"UR5:UR4_r0" = trunc i64 %"ldc_const.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".30" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 536
  %".31" = bitcast i8* %".30" to i64*
  %"ldc_const.2" = load i64, i64* %".31"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", %"UR5:UR4_r0"
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR5:UR4_r1"
  %"s2ur_ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  br label %"BB_00a0"
BB_00a0:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_800000a0", label %"BB_00c0"
BB_800000a0:
  %".34" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 592
  %".35" = bitcast i8* %".34" to i64*
  %"ldc_const.3" = load i64, i64* %".35"
  %"R3:R2_r0" = trunc i64 %"ldc_const.3" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".36" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 600
  %".37" = bitcast i8* %".36" to i64*
  %"ldc_const.4" = load i64, i64* %".37"
  %"R5:R4_r0" = trunc i64 %"ldc_const.4" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.4", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00c0"
BB_00c0:
  %"phi" = phi  i32 [%"R5:R4_r1", %"BB_800000a0"], [0, %"BB_00a0"]
  %"phi.1" = phi  i32 [%"R5:R4_r0", %"BB_800000a0"], [0, %"BB_00a0"]
  %"phi.2" = phi  i32 [%"R3:R2_r1", %"BB_800000a0"], [0, %"BB_00a0"]
  %"phi.3" = phi  i32 [%"R3:R2_r0", %"BB_800000a0"], [0, %"BB_00a0"]
  %"s2ur_ctaid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()
  %".39" = zext i32 %"s2ur_ctaid_x" to i64
  %".40" = zext i32 0 to i64
  %".41" = shl i64 %".40", 32
  %"shf_concat" = or i64 %".39", %".41"
  %"shf_shift_64" = zext i32 6 to i64
  %".42" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".42" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".43" = xor i32 0, -1
  %".44" = xor i32 %"shf_result", -1
  %".45" = xor i32 0, -1
  %".46" = and i32 %".43", %".44"
  %".47" = and i32 %".46", %".45"
  %".48" = and i32 %".43", %".44"
  %".49" = and i32 %".48", 0
  %".50" = or i32 %".47", %".49"
  %".51" = and i32 0, %".44"
  %".52" = and i32 %".51", %".45"
  %".53" = or i32 %".50", %".52"
  %".54" = and i32 0, %".44"
  %".55" = and i32 %".54", 0
  %".56" = or i32 %".53", %".55"
  br label %"BB_0100"
BB_0100:
  %"cond_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  %"phi_cast_R228_bitcast" = bitcast i32 %"imad" to float
  br i1 %"pbra_cond_to_i1.1", label %"BB_80000100", label %"BB_0110"
BB_80000100:
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R104:R95_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to float addrspace(1)*
  %"ldg" = load float, float addrspace(1)* %"R104:R95_addr_ptr"
  br label %"BB_0110"
BB_0110:
  %"phi.4" = phi  float [%"ldg", %"BB_80000100"], [%"phi_cast_R228_bitcast", %"BB_0100"]
  %".60" = xor i32 %"tid_x", -1
  %".61" = xor i32 63, -1
  %".62" = xor i32 0, -1
  %".63" = and i32 %"tid_x", 63
  %".64" = and i32 %".63", %".62"
  %".65" = and i32 %"tid_x", 63
  %".66" = and i32 %".65", 0
  %".67" = or i32 %".64", %".66"
  br label %"BB_0120"
BB_0120:
  %"cond_trunc.2" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_trunc.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  %"phi_cast_R155_bitcast" = bitcast i32 %"imad.1" to float
  br i1 %"pbra_cond_to_i1.2", label %"BB_80000120", label %"BB_0130"
BB_80000120:
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R130:R116_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to float addrspace(1)*
  %"ldg.1" = load float, float addrspace(1)* %"R130:R116_addr_ptr"
  br label %"BB_0130"
BB_0130:
  %"phi.5" = phi  float [%"ldg.1", %"BB_80000120"], [%"phi_cast_R155_bitcast", %"BB_0120"]
  %".71" = zext i32 0 to i64
  %".72" = zext i32 %"tid_x" to i64
  %".73" = shl i64 %".72", 32
  %"shf_concat.1" = or i64 %".71", %".73"
  %"shf_shift_64.1" = zext i32 6 to i64
  %".74" = ashr i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_hi" = lshr i64 %".74", 32
  %"shf_result.1" = trunc i64 %"shf_hi" to i32
  %"viadd" = add i32 %".67", %"shf_result"
  %"viaddmnmx_sum" = add i32 %".56", %"R13:R12_r0"
  %"viaddmnmx_cmp" = icmp slt i32 %"viaddmnmx_sum", 63
  %"viaddmnmx" = select  i1 %"viaddmnmx_cmp", i32 %"viaddmnmx_sum", i32 63
  %"isetrp_cmp1.1" = icmp sgt i32 %".67", %"viaddmnmx"
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %".75" = zext i32 %"s2ur_ctaid_y" to i64
  %".76" = zext i32 0 to i64
  %".77" = shl i64 %".76", 32
  %"shf_concat.2" = or i64 %".75", %".77"
  %"shf_shift_64.2" = zext i32 5 to i64
  %".78" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".78" to i32
  %"imad_tmp.2" = mul i32 %"shf_result.1", 65
  %"imad.2" = add i32 %"imad_tmp.2", %".67"
  %".79" = zext i32 0 to i64
  %".80" = zext i32 %"viadd" to i64
  %".81" = shl i64 %".80", 32
  %"shf_concat.3" = or i64 %".79", %".81"
  %"shf_shift_64.3" = zext i32 31 to i64
  %".82" = ashr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".82", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".83" = xor i32 0, -1
  %".84" = xor i32 %"shf_result.2", -1
  %".85" = xor i32 0, -1
  %".86" = and i32 %".83", %".84"
  %".87" = and i32 %".86", %".85"
  %".88" = and i32 %".83", %".84"
  %".89" = and i32 %".88", 0
  %".90" = or i32 %".87", %".89"
  %".91" = and i32 0, %".84"
  %".92" = and i32 %".91", %".85"
  %".93" = or i32 %".90", %".92"
  %".94" = and i32 0, %".84"
  %".95" = and i32 %".94", 0
  %".96" = or i32 %".93", %".95"
  %".97" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".98" = zext i32 1024 to i64
  %".99" = zext i32 24 to i64
  %".100" = shl i64 %".97", %".99"
  %".101" = and i64 %".100", 4294967295
  %".102" = add i64 %".101", %".98"
  %".103" = trunc i64 %".102" to i32
  %".104" = zext i32 0 to i64
  %".105" = zext i32 %"shf_result.2" to i64
  %".106" = shl i64 %".105", 32
  %"shf_concat.4" = or i64 %".104", %".106"
  %"shf_shift_64.4" = zext i32 31 to i64
  %".107" = ashr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.2" = lshr i64 %".107", 32
  %"shf_result.4" = trunc i64 %"shf_hi.2" to i32
  %"viaddmnmx_sum.1" = add i32 %".96", %"R13:R12_r1"
  %"viaddmnmx_cmp.1" = icmp slt i32 %"viaddmnmx_sum.1", 31
  %"viaddmnmx.1" = select  i1 %"viaddmnmx_cmp.1", i32 %"viaddmnmx_sum.1", i32 31
  %".108" = zext i32 0 to i64
  %".109" = zext i32 %"tid_x" to i64
  %".110" = shl i64 %".109", 32
  %"shf_concat.5" = or i64 %".108", %".110"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".111" = ashr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.3" = lshr i64 %".111", 32
  %"shf_result.5" = trunc i64 %"shf_hi.3" to i32
  %".112" = zext i32 %"imad.2" to i64
  %".113" = zext i32 %".103" to i64
  %".114" = zext i32 2 to i64
  %".115" = shl i64 %".112", %".114"
  %".116" = and i64 %".115", 4294967295
  %".117" = add i64 %".116", %".113"
  %".118" = trunc i64 %".117" to i32
  br label %"BB_0220"
BB_0220:
  %"cond_trunc.3" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_trunc.3" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_0a00", label %"BB_0230"
BB_0230:
  %"fsetrp_cmp1" = fcmp une float %"phi.4",              0x0
  %"fsetrp_cmp2" = and i1 %"fsetrp_cmp1", 1
  %"P15_to_i32" = zext i1 %"fsetrp_cmp2" to i32
  %".121" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 544
  %".122" = bitcast i8* %".121" to i32*
  %"ldc_const.5" = load i32, i32* %".122"
  %".123" = zext i32 0 to i64
  %".124" = zext i32 %"ldc_const.5" to i64
  %".125" = shl i64 %".124", 32
  %"shf_concat.6" = or i64 %".123", %".125"
  %"shf_shift_64.6" = zext i32 31 to i64
  %".126" = ashr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.4" = lshr i64 %".126", 32
  %"shf_result.6" = trunc i64 %"shf_hi.4" to i32
  br label %"BB_0260"
BB_0260:
  %"cond_trunc.4" = trunc i32 %"P15_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0310", label %"BB_0270"
BB_0270:
  %"fmul" = fmul float              0x0, %"phi.4"
  %".129" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".118"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".129" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast"
  %"sts_addr_memaddr_offset_add" = add i32 %".118", 1040
  %".131" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".131" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.1"
  %"sts_addr_memaddr_offset_add.1" = add i32 %".118", 2080
  %".133" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.1"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".133" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.2"
  %"sts_addr_memaddr_offset_add.2" = add i32 %".118", 3120
  %".135" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.2"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".135" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.3"
  %"sts_addr_memaddr_offset_add.3" = add i32 %".118", 4160
  %".137" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.3"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".137" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.4"
  %"sts_addr_memaddr_offset_add.4" = add i32 %".118", 5200
  %".139" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.4"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".139" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.5"
  %"sts_addr_memaddr_offset_add.5" = add i32 %".118", 6240
  %".141" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.5"
  %"sts_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".141" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.6"
  %"sts_addr_memaddr_offset_add.6" = add i32 %".118", 7280
  %".143" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.6"
  %"sts_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".143" to float addrspace(3)*
  store volatile float %"fmul", float addrspace(3)* %"sts_shared_addr_cast.7"
  br label %"BB_0a00"
BB_0310:
  %"iadd3_o1_64" = zext i32 %"shf_result.1" to i64
  %"iadd3_o2_64" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P27_to_i32" = zext i1 %"carry_ge_1" to i32
  %"viadd.1" = add i32 %"shf_result.1", 4
  %".146" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 568
  %".147" = bitcast i8* %".146" to i64*
  %"ldc_const.6" = load i64, i64* %".147"
  %"UR13:UR12_r0" = trunc i64 %"ldc_const.6" to i32
  %"UR13:UR12_r1_shift" = lshr i64 %"ldc_const.6", 32
  %"UR13:UR12_r1" = trunc i64 %"UR13:UR12_r1_shift" to i32
  %"viadd.2" = add i32 %"shf_result.1", 8
  %".148" = sext i32 %"shf_result.1" to i64
  %".149" = zext i32 %"shf_result.4" to i64
  %".150" = zext i32 1 to i64
  %".151" = shl i64 %".148", %".150"
  %".152" = lshr i64 %".151", 32
  %".153" = add i64 %".152", %".149"
  %"lea_cin_trunc" = trunc i32 %"P27_to_i32" to i1
  %".154" = zext i1 %"lea_cin_trunc" to i64
  %".155" = add i64 %".153", %".154"
  %".156" = trunc i64 %".155" to i32
  %"viadd.3" = add i32 %"shf_result.1", 12
  %"iadd3_o1_64.1" = zext i32 %"viadd.1" to i64
  %"iadd3_o2_64.1" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P31_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"viadd.4" = add i32 %"shf_result.1", 16
  %"imad_tmp.3" = mul i32 %".156", %"ldc_const.5"
  %"imad.3" = add i32 %"imad_tmp.3", 0
  %".157" = sext i32 %"viadd.1" to i64
  %".158" = zext i32 %"shf_result.4" to i64
  %".159" = zext i32 1 to i64
  %".160" = shl i64 %".157", %".159"
  %".161" = lshr i64 %".160", 32
  %".162" = add i64 %".161", %".158"
  %"lea_cin_trunc.1" = trunc i32 %"P31_to_i32" to i1
  %".163" = zext i1 %"lea_cin_trunc.1" to i64
  %".164" = add i64 %".162", %".163"
  %".165" = trunc i64 %".164" to i32
  %"iadd3_o1_64.2" = zext i32 %"viadd.2" to i64
  %"iadd3_o2_64.2" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P40_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"imad_tmp.4" = mul i32 %"iadd3_trunc", %"shf_result.6"
  %"imad.4" = add i32 %"imad_tmp.4", %"imad.3"
  %"imad_addend_r0_ext" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"iadd3_trunc" to i64
  %"imad_rhs_64" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.5" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R15:R14_r0" = trunc i64 %"imad.5" to i32
  %"R15:R14_r1_shift" = lshr i64 %"imad.5", 32
  %"R15:R14_r1" = trunc i64 %"R15:R14_r1_shift" to i32
  %"imad_tmp.5" = mul i32 %"R15:R14_r1", 1
  %"imad.6" = add i32 %"imad_tmp.5", %"imad.4"
  %".166" = zext i32 %"R15:R14_r0" to i64
  %".167" = zext i32 %"UR13:UR12_r0" to i64
  %".168" = zext i32 2 to i64
  %".169" = shl i64 %".166", %".168"
  %".170" = and i64 %".169", 4294967295
  %".171" = add i64 %".170", %".167"
  %".172" = trunc i64 %".171" to i32
  %".173" = lshr i64 %".171", 32
  %".174" = trunc i64 %".173" to i1
  %"P32_to_i32" = zext i1 %".174" to i32
  %"imad_tmp.6" = mul i32 %".165", %"ldc_const.5"
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".175" = sext i32 %"viadd.2" to i64
  %".176" = zext i32 %"shf_result.4" to i64
  %".177" = zext i32 1 to i64
  %".178" = shl i64 %".175", %".177"
  %".179" = lshr i64 %".178", 32
  %".180" = add i64 %".179", %".176"
  %"lea_cin_trunc.2" = trunc i32 %"P40_to_i32" to i1
  %".181" = zext i1 %"lea_cin_trunc.2" to i64
  %".182" = add i64 %".180", %".181"
  %".183" = trunc i64 %".182" to i32
  %"imad_addend_r0_ext.1" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"iadd3_trunc.1" to i64
  %"imad_rhs_64.1" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.8" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.8" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.8", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %".184" = zext i32 %"R15:R14_r0" to i64
  %".185" = zext i32 %"imad.6" to i64
  %".186" = shl i64 %".185", 32
  %"lea_funnel" = or i64 %".184", %".186"
  %".187" = zext i32 %"UR13:UR12_r1" to i64
  %".188" = zext i32 2 to i64
  %".189" = shl i64 %"lea_funnel", %".188"
  %".190" = lshr i64 %".189", 32
  %".191" = add i64 %".190", %".187"
  %"lea_cin_trunc.3" = trunc i32 %"P32_to_i32" to i1
  %".192" = zext i1 %"lea_cin_trunc.3" to i64
  %".193" = add i64 %".191", %".192"
  %".194" = trunc i64 %".193" to i32
  %"iadd3_o1_64.3" = zext i32 %"viadd.3" to i64
  %"iadd3_o2_64.3" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P51_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"imad_tmp.7" = mul i32 %"iadd3_trunc.1", %"shf_result.6"
  %"imad.9" = add i32 %"imad_tmp.7", %"imad.7"
  %".195" = zext i32 %"R13:R12_r0.1" to i64
  %".196" = zext i32 %"UR13:UR12_r0" to i64
  %".197" = zext i32 2 to i64
  %".198" = shl i64 %".195", %".197"
  %".199" = and i64 %".198", 4294967295
  %".200" = add i64 %".199", %".196"
  %".201" = trunc i64 %".200" to i32
  %".202" = lshr i64 %".200", 32
  %".203" = trunc i64 %".202" to i1
  %"P33_to_i32" = zext i1 %".203" to i32
  %"imad_tmp.8" = mul i32 %".183", %"ldc_const.5"
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"imad_tmp.9" = mul i32 %"R13:R12_r1.1", 1
  %"imad.11" = add i32 %"imad_tmp.9", %"imad.9"
  %".204" = sext i32 %"viadd.3" to i64
  %".205" = zext i32 %"shf_result.4" to i64
  %".206" = zext i32 1 to i64
  %".207" = shl i64 %".204", %".206"
  %".208" = lshr i64 %".207", 32
  %".209" = add i64 %".208", %".205"
  %"lea_cin_trunc.4" = trunc i32 %"P51_to_i32" to i1
  %".210" = zext i1 %"lea_cin_trunc.4" to i64
  %".211" = add i64 %".209", %".210"
  %".212" = trunc i64 %".211" to i32
  %"imad_tmp.10" = mul i32 %"iadd3_trunc.2", %"shf_result.6"
  %"imad.12" = add i32 %"imad_tmp.10", %"imad.10"
  %"isetrp_cmp1.2" = icmp sgt i32 %"viadd.1", %"viaddmnmx.1"
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P54_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"imad_addend_r0_ext.2" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"iadd3_trunc.2" to i64
  %"imad_rhs_64.2" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R15:R14_r0.1" = trunc i64 %"imad.13" to i32
  %"R15:R14_r1_shift.1" = lshr i64 %"imad.13", 32
  %"R15:R14_r1.1" = trunc i64 %"R15:R14_r1_shift.1" to i32
  %".213" = zext i32 %"R13:R12_r0.1" to i64
  %".214" = zext i32 %"imad.11" to i64
  %".215" = shl i64 %".214", 32
  %"lea_funnel.1" = or i64 %".213", %".215"
  %".216" = zext i32 %"UR13:UR12_r1" to i64
  %".217" = zext i32 2 to i64
  %".218" = shl i64 %"lea_funnel.1", %".217"
  %".219" = lshr i64 %".218", 32
  %".220" = add i64 %".219", %".216"
  %"lea_cin_trunc.5" = trunc i32 %"P33_to_i32" to i1
  %".221" = zext i1 %"lea_cin_trunc.5" to i64
  %".222" = add i64 %".220", %".221"
  %".223" = trunc i64 %".222" to i32
  %"imad_tmp.11" = mul i32 %".212", %"ldc_const.5"
  %"imad.14" = add i32 %"imad_tmp.11", 0
  %".224" = zext i32 %"R15:R14_r0.1" to i64
  %".225" = zext i32 %"UR13:UR12_r0" to i64
  %".226" = zext i32 2 to i64
  %".227" = shl i64 %".224", %".226"
  %".228" = and i64 %".227", 4294967295
  %".229" = add i64 %".228", %".225"
  %".230" = trunc i64 %".229" to i32
  %".231" = lshr i64 %".229", 32
  %".232" = trunc i64 %".231" to i1
  %"P35_to_i32" = zext i1 %".232" to i32
  %"imad_tmp.12" = mul i32 %"R15:R14_r1.1", 1
  %"imad.15" = add i32 %"imad_tmp.12", %"imad.12"
  %"iadd3_o1_64.4" = zext i32 %"viadd.4" to i64
  %"iadd3_o2_64.4" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.4" = zext i32 0 to i64
  %"iadd3_tmp.4" = add i64 %"iadd3_o1_64.4", %"iadd3_o2_64.4"
  %"iadd3_tmp2.4" = add i64 %"iadd3_tmp.4", %"iadd3_o3_64.4"
  %"iadd3_trunc.4" = trunc i64 %"iadd3_tmp2.4" to i32
  %"iadd3_carry_val.4" = lshr i64 %"iadd3_tmp2.4", 32
  %"carry_ge_1.4" = icmp uge i64 %"iadd3_carry_val.4", 1
  %"P63_to_i32" = zext i1 %"carry_ge_1.4" to i32
  %"imad_tmp.13" = mul i32 %"iadd3_trunc.3", %"shf_result.6"
  %"imad.16" = add i32 %"imad_tmp.13", %"imad.14"
  %"imad_addend_r0_ext.3" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.3" = or i64 0, %"imad_addend_r0_ext.3"
  %"imad_addend_r1_ext.3" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.3" = shl i64 %"imad_addend_r1_ext.3", 32
  %"imad_addend_packed_1.3" = or i64 %"imad_addend_packed_0.3", %"imad_addend_r1_shift.3"
  %"imad_lhs_64.3" = zext i32 %"iadd3_trunc.3" to i64
  %"imad_rhs_64.3" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64.3" = mul i64 %"imad_lhs_64.3", %"imad_rhs_64.3"
  %"imad.17" = add i64 %"imad_tmp_64.3", %"imad_addend_packed_1.3"
  %"R13:R12_r0.2" = trunc i64 %"imad.17" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"imad.17", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %".233" = zext i32 %"R15:R14_r0.1" to i64
  %".234" = zext i32 %"imad.15" to i64
  %".235" = shl i64 %".234", 32
  %"lea_funnel.2" = or i64 %".233", %".235"
  %".236" = zext i32 %"UR13:UR12_r1" to i64
  %".237" = zext i32 2 to i64
  %".238" = shl i64 %"lea_funnel.2", %".237"
  %".239" = lshr i64 %".238", 32
  %".240" = add i64 %".239", %".236"
  %"lea_cin_trunc.6" = trunc i32 %"P35_to_i32" to i1
  %".241" = zext i1 %"lea_cin_trunc.6" to i64
  %".242" = add i64 %".240", %".241"
  %".243" = trunc i64 %".242" to i32
  %"imad_tmp.14" = mul i32 %"R13:R12_r1.2", 1
  %"imad.18" = add i32 %"imad_tmp.14", %"imad.16"
  %".244" = zext i32 %"R13:R12_r0.2" to i64
  %".245" = zext i32 %"UR13:UR12_r0" to i64
  %".246" = zext i32 2 to i64
  %".247" = shl i64 %".244", %".246"
  %".248" = and i64 %".247", 4294967295
  %".249" = add i64 %".248", %".245"
  %".250" = trunc i64 %".249" to i32
  %".251" = lshr i64 %".249", 32
  %".252" = trunc i64 %".251" to i1
  %"P37_to_i32" = zext i1 %".252" to i32
  %".253" = zext i32 %"R13:R12_r0.2" to i64
  %".254" = zext i32 %"imad.18" to i64
  %".255" = shl i64 %".254", 32
  %"lea_funnel.3" = or i64 %".253", %".255"
  %".256" = zext i32 %"UR13:UR12_r1" to i64
  %".257" = zext i32 2 to i64
  %".258" = shl i64 %"lea_funnel.3", %".257"
  %".259" = lshr i64 %".258", 32
  %".260" = add i64 %".259", %".256"
  %"lea_cin_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %".261" = zext i1 %"lea_cin_trunc.7" to i64
  %".262" = add i64 %".260", %".261"
  %".263" = trunc i64 %".262" to i32
  %".264" = sext i32 %"viadd.4" to i64
  %".265" = zext i32 %"shf_result.4" to i64
  %".266" = zext i32 1 to i64
  %".267" = shl i64 %".264", %".266"
  %".268" = lshr i64 %".267", 32
  %".269" = add i64 %".268", %".265"
  %"lea_cin_trunc.8" = trunc i32 %"P63_to_i32" to i1
  %".270" = zext i1 %"lea_cin_trunc.8" to i64
  %".271" = add i64 %".269", %".270"
  %".272" = trunc i64 %".271" to i32
  %"isetrp_cmp1.3" = icmp sgt i32 %"shf_result.1", %"viaddmnmx.1"
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"imad_tmp.15" = mul i32 %".272", %"ldc_const.5"
  %"imad.19" = add i32 %"imad_tmp.15", 0
  %"imad_tmp.16" = mul i32 %"iadd3_trunc.4", %"shf_result.6"
  %"imad.20" = add i32 %"imad_tmp.16", %"imad.19"
  %"imad_addend_r0_ext.4" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.4" = or i64 0, %"imad_addend_r0_ext.4"
  %"imad_addend_r1_ext.4" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.4" = shl i64 %"imad_addend_r1_ext.4", 32
  %"imad_addend_packed_1.4" = or i64 %"imad_addend_packed_0.4", %"imad_addend_r1_shift.4"
  %"imad_lhs_64.4" = zext i32 %"iadd3_trunc.4" to i64
  %"imad_rhs_64.4" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64.4" = mul i64 %"imad_lhs_64.4", %"imad_rhs_64.4"
  %"imad.21" = add i64 %"imad_tmp_64.4", %"imad_addend_packed_1.4"
  %"R15:R14_r0.2" = trunc i64 %"imad.21" to i32
  %"R15:R14_r1_shift.2" = lshr i64 %"imad.21", 32
  %"R15:R14_r1.2" = trunc i64 %"R15:R14_r1_shift.2" to i32
  br label %"BB_05f0"
BB_05f0:
  %"cond_trunc.5" = trunc i32 %"P54_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800005f0", label %"BB_0600"
BB_800005f0:
  %"ldg_addr_r0_ext.2" = zext i32 %".201" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %".223" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"R68:R332_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.2" to float addrspace(1)*
  %"ldg.2" = load float, float addrspace(1)* %"R68:R332_addr_ptr"
  br label %"BB_0600"
BB_0600:
  %"phi.6" = phi  float [%"ldg.2", %"BB_800005f0"], [0x0, %"BB_05f0"]
  %"viadd.5" = add i32 %"shf_result.1", 20
  br label %"BB_0610"
BB_0610:
  %"cond_trunc.6" = trunc i32 %"P38_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_80000610", label %"BB_0620"
BB_80000610:
  %"ldg_addr_r0_ext.3" = zext i32 %".172" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %".194" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"R60:R49_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.3" to float addrspace(1)*
  %"ldg.3" = load float, float addrspace(1)* %"R60:R49_addr_ptr"
  br label %"BB_0620"
BB_0620:
  %"phi.7" = phi  float [%"ldg.3", %"BB_80000610"], [0x0, %"BB_0610"]
  %"imad_tmp.17" = mul i32 %"R15:R14_r1.2", 1
  %"imad.22" = add i32 %"imad_tmp.17", %"imad.20"
  %".279" = zext i32 %"R15:R14_r0.2" to i64
  %".280" = zext i32 %"UR13:UR12_r0" to i64
  %".281" = zext i32 2 to i64
  %".282" = shl i64 %".279", %".281"
  %".283" = and i64 %".282", 4294967295
  %".284" = add i64 %".283", %".280"
  %".285" = trunc i64 %".284" to i32
  %".286" = lshr i64 %".284", 32
  %".287" = trunc i64 %".286" to i1
  %"P39_to_i32" = zext i1 %".287" to i32
  %"iadd3_o1_64.5" = zext i32 %"viadd.5" to i64
  %"iadd3_o2_64.5" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.5" = zext i32 0 to i64
  %"iadd3_tmp.5" = add i64 %"iadd3_o1_64.5", %"iadd3_o2_64.5"
  %"iadd3_tmp2.5" = add i64 %"iadd3_tmp.5", %"iadd3_o3_64.5"
  %"iadd3_trunc.5" = trunc i64 %"iadd3_tmp2.5" to i32
  %"iadd3_carry_val.5" = lshr i64 %"iadd3_tmp2.5", 32
  %"carry_ge_1.5" = icmp uge i64 %"iadd3_carry_val.5", 1
  %"P55_to_i32" = zext i1 %"carry_ge_1.5" to i32
  %".288" = zext i32 %"R15:R14_r0.2" to i64
  %".289" = zext i32 %"imad.22" to i64
  %".290" = shl i64 %".289", 32
  %"lea_funnel.4" = or i64 %".288", %".290"
  %".291" = zext i32 %"UR13:UR12_r1" to i64
  %".292" = zext i32 2 to i64
  %".293" = shl i64 %"lea_funnel.4", %".292"
  %".294" = lshr i64 %".293", 32
  %".295" = add i64 %".294", %".291"
  %"lea_cin_trunc.9" = trunc i32 %"P39_to_i32" to i1
  %".296" = zext i1 %"lea_cin_trunc.9" to i64
  %".297" = add i64 %".295", %".296"
  %".298" = trunc i64 %".297" to i32
  %"isetrp_cmp1.4" = icmp sgt i32 %"viadd.2", %"viaddmnmx.1"
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %".299" = sext i32 %"viadd.5" to i64
  %".300" = zext i32 %"shf_result.4" to i64
  %".301" = zext i32 1 to i64
  %".302" = shl i64 %".299", %".301"
  %".303" = lshr i64 %".302", 32
  %".304" = add i64 %".303", %".300"
  %"lea_cin_trunc.10" = trunc i32 %"P55_to_i32" to i1
  %".305" = zext i1 %"lea_cin_trunc.10" to i64
  %".306" = add i64 %".304", %".305"
  %".307" = trunc i64 %".306" to i32
  %"imad_tmp.18" = mul i32 %".307", %"ldc_const.5"
  %"imad.23" = add i32 %"imad_tmp.18", 0
  %"imad_addend_r0_ext.5" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.5" = or i64 0, %"imad_addend_r0_ext.5"
  %"imad_addend_r1_ext.5" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.5" = shl i64 %"imad_addend_r1_ext.5", 32
  %"imad_addend_packed_1.5" = or i64 %"imad_addend_packed_0.5", %"imad_addend_r1_shift.5"
  %"imad_lhs_64.5" = zext i32 %"iadd3_trunc.5" to i64
  %"imad_rhs_64.5" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64.5" = mul i64 %"imad_lhs_64.5", %"imad_rhs_64.5"
  %"imad.24" = add i64 %"imad_tmp_64.5", %"imad_addend_packed_1.5"
  %"R17:R16_r0" = trunc i64 %"imad.24" to i32
  %"R17:R16_r1_shift" = lshr i64 %"imad.24", 32
  %"R17:R16_r1" = trunc i64 %"R17:R16_r1_shift" to i32
  %"imad_tmp.19" = mul i32 %"iadd3_trunc.5", %"shf_result.6"
  %"imad.25" = add i32 %"imad_tmp.19", %"imad.23"
  br label %"BB_06c0"
BB_06c0:
  %"cond_trunc.7" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.7", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_800006c0", label %"BB_06d0"
BB_800006c0:
  %"ldg_addr_r0_ext.4" = zext i32 %".230" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %".243" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"R396:R375_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.4" to float addrspace(1)*
  %"ldg.4" = load float, float addrspace(1)* %"R396:R375_addr_ptr"
  br label %"BB_06d0"
BB_06d0:
  %"phi.8" = phi  float [%"ldg.4", %"BB_800006c0"], [0x0, %"BB_06c0"]
  %".311" = zext i32 %"R17:R16_r0" to i64
  %".312" = zext i32 %"UR13:UR12_r0" to i64
  %".313" = zext i32 2 to i64
  %".314" = shl i64 %".311", %".313"
  %".315" = and i64 %".314", 4294967295
  %".316" = add i64 %".315", %".312"
  %".317" = trunc i64 %".316" to i32
  %".318" = lshr i64 %".316", 32
  %".319" = trunc i64 %".318" to i1
  %"P17_to_i32" = zext i1 %".319" to i32
  %"viadd.6" = add i32 %"shf_result.1", 24
  %"imad_tmp.20" = mul i32 %"R17:R16_r1", 1
  %"imad.26" = add i32 %"imad_tmp.20", %"imad.25"
  %".320" = zext i32 %"R17:R16_r0" to i64
  %".321" = zext i32 %"imad.26" to i64
  %".322" = shl i64 %".321", 32
  %"lea_funnel.5" = or i64 %".320", %".322"
  %".323" = zext i32 %"UR13:UR12_r1" to i64
  %".324" = zext i32 2 to i64
  %".325" = shl i64 %"lea_funnel.5", %".324"
  %".326" = lshr i64 %".325", 32
  %".327" = add i64 %".326", %".323"
  %"lea_cin_trunc.11" = trunc i32 %"P17_to_i32" to i1
  %".328" = zext i1 %"lea_cin_trunc.11" to i64
  %".329" = add i64 %".327", %".328"
  %".330" = trunc i64 %".329" to i32
  %"iadd3_o1_64.6" = zext i32 %"viadd.6" to i64
  %"iadd3_o2_64.6" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.6" = zext i32 0 to i64
  %"iadd3_tmp.6" = add i64 %"iadd3_o1_64.6", %"iadd3_o2_64.6"
  %"iadd3_tmp2.6" = add i64 %"iadd3_tmp.6", %"iadd3_o3_64.6"
  %"iadd3_trunc.6" = trunc i64 %"iadd3_tmp2.6" to i32
  %"iadd3_carry_val.6" = lshr i64 %"iadd3_tmp2.6", 32
  %"carry_ge_1.6" = icmp uge i64 %"iadd3_carry_val.6", 1
  %"P18_to_i32" = zext i1 %"carry_ge_1.6" to i32
  %"isetrp_cmp1.5" = icmp sgt i32 %"viadd.3", %"viaddmnmx.1"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P59_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %".331" = sext i32 %"viadd.6" to i64
  %".332" = zext i32 %"shf_result.4" to i64
  %".333" = zext i32 1 to i64
  %".334" = shl i64 %".331", %".333"
  %".335" = lshr i64 %".334", 32
  %".336" = add i64 %".335", %".332"
  %"lea_cin_trunc.12" = trunc i32 %"P18_to_i32" to i1
  %".337" = zext i1 %"lea_cin_trunc.12" to i64
  %".338" = add i64 %".336", %".337"
  %".339" = trunc i64 %".338" to i32
  %"imad_tmp.21" = mul i32 %".339", %"ldc_const.5"
  %"imad.27" = add i32 %"imad_tmp.21", 0
  %"imad_addend_r0_ext.6" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.6" = or i64 0, %"imad_addend_r0_ext.6"
  %"imad_addend_r1_ext.6" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.6" = shl i64 %"imad_addend_r1_ext.6", 32
  %"imad_addend_packed_1.6" = or i64 %"imad_addend_packed_0.6", %"imad_addend_r1_shift.6"
  %"imad_lhs_64.6" = zext i32 %"iadd3_trunc.6" to i64
  %"imad_rhs_64.6" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64.6" = mul i64 %"imad_lhs_64.6", %"imad_rhs_64.6"
  %"imad.28" = add i64 %"imad_tmp_64.6", %"imad_addend_packed_1.6"
  %"R21:R20_r0" = trunc i64 %"imad.28" to i32
  %"R21:R20_r1_shift" = lshr i64 %"imad.28", 32
  %"R21:R20_r1" = trunc i64 %"R21:R20_r1_shift" to i32
  %"imad_tmp.22" = mul i32 %"iadd3_trunc.6", %"shf_result.6"
  %"imad.29" = add i32 %"imad_tmp.22", %"imad.27"
  br label %"BB_0780"
BB_0780:
  %"cond_trunc.8" = trunc i32 %"P59_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000780", label %"BB_0790"
BB_80000780:
  %"ldg_addr_r0_ext.5" = zext i32 %".250" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %".263" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"R367:R146_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.5" to float addrspace(1)*
  %"ldg.5" = load float, float addrspace(1)* %"R367:R146_addr_ptr"
  br label %"BB_0790"
BB_0790:
  %"phi.9" = phi  float [%"ldg.5", %"BB_80000780"], [0x0, %"BB_0780"]
  %".343" = zext i32 %"R21:R20_r0" to i64
  %".344" = zext i32 %"UR13:UR12_r0" to i64
  %".345" = zext i32 2 to i64
  %".346" = shl i64 %".343", %".345"
  %".347" = and i64 %".346", 4294967295
  %".348" = add i64 %".347", %".344"
  %".349" = trunc i64 %".348" to i32
  %".350" = lshr i64 %".348", 32
  %".351" = trunc i64 %".350" to i1
  %"P60_to_i32" = zext i1 %".351" to i32
  %"imad_tmp.23" = mul i32 %"R21:R20_r1", 1
  %"imad.30" = add i32 %"imad_tmp.23", %"imad.29"
  %".352" = zext i32 %"R21:R20_r0" to i64
  %".353" = zext i32 %"imad.30" to i64
  %".354" = shl i64 %".353", 32
  %"lea_funnel.6" = or i64 %".352", %".354"
  %".355" = zext i32 %"UR13:UR12_r1" to i64
  %".356" = zext i32 2 to i64
  %".357" = shl i64 %"lea_funnel.6", %".356"
  %".358" = lshr i64 %".357", 32
  %".359" = add i64 %".358", %".355"
  %"lea_cin_trunc.13" = trunc i32 %"P60_to_i32" to i1
  %".360" = zext i1 %"lea_cin_trunc.13" to i64
  %".361" = add i64 %".359", %".360"
  %".362" = trunc i64 %".361" to i32
  %"viadd.7" = add i32 %"shf_result.1", 28
  %"iadd3_o1_64.7" = zext i32 %"viadd.7" to i64
  %"iadd3_o2_64.7" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.7" = zext i32 0 to i64
  %"iadd3_tmp.7" = add i64 %"iadd3_o1_64.7", %"iadd3_o2_64.7"
  %"iadd3_tmp2.7" = add i64 %"iadd3_tmp.7", %"iadd3_o3_64.7"
  %"iadd3_trunc.7" = trunc i64 %"iadd3_tmp2.7" to i32
  %"iadd3_carry_val.7" = lshr i64 %"iadd3_tmp2.7", 32
  %"carry_ge_1.7" = icmp uge i64 %"iadd3_carry_val.7", 1
  %"P68_to_i32" = zext i1 %"carry_ge_1.7" to i32
  %".363" = sext i32 %"viadd.7" to i64
  %".364" = zext i32 %"shf_result.4" to i64
  %".365" = zext i32 1 to i64
  %".366" = shl i64 %".363", %".365"
  %".367" = lshr i64 %".366", 32
  %".368" = add i64 %".367", %".364"
  %"lea_cin_trunc.14" = trunc i32 %"P68_to_i32" to i1
  %".369" = zext i1 %"lea_cin_trunc.14" to i64
  %".370" = add i64 %".368", %".369"
  %".371" = trunc i64 %".370" to i32
  %"isetrp_cmp1.6" = icmp sgt i32 %"viadd.5", %"viaddmnmx.1"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P61_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.24" = mul i32 %".371", %"ldc_const.5"
  %"imad.31" = add i32 %"imad_tmp.24", 0
  %"imad_addend_r0_ext.7" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.7" = or i64 0, %"imad_addend_r0_ext.7"
  %"imad_addend_r1_ext.7" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.7" = shl i64 %"imad_addend_r1_ext.7", 32
  %"imad_addend_packed_1.7" = or i64 %"imad_addend_packed_0.7", %"imad_addend_r1_shift.7"
  %"imad_lhs_64.7" = zext i32 %"iadd3_trunc.7" to i64
  %"imad_rhs_64.7" = zext i32 %"ldc_const.5" to i64
  %"imad_tmp_64.7" = mul i64 %"imad_lhs_64.7", %"imad_rhs_64.7"
  %"imad.32" = add i64 %"imad_tmp_64.7", %"imad_addend_packed_1.7"
  %"R19:R18_r0" = trunc i64 %"imad.32" to i32
  %"R19:R18_r1_shift" = lshr i64 %"imad.32", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"isetrp_cmp1.7" = icmp sgt i32 %"viadd.4", %"viaddmnmx.1"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.25" = mul i32 %"iadd3_trunc.7", %"shf_result.6"
  %"imad.33" = add i32 %"imad_tmp.25", %"imad.31"
  %"isetrp_cmp1.8" = icmp sgt i32 %"viadd.6", %"viaddmnmx.1"
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P69_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"isetrp_cmp1.9" = icmp sgt i32 %"viadd.7", %"viaddmnmx.1"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P75_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"imad_tmp.26" = mul i32 %"R19:R18_r1", 1
  %"imad.34" = add i32 %"imad_tmp.26", %"imad.33"
  %".372" = zext i32 %"R19:R18_r0" to i64
  %".373" = zext i32 %"UR13:UR12_r0" to i64
  %".374" = zext i32 2 to i64
  %".375" = shl i64 %".372", %".374"
  %".376" = and i64 %".375", 4294967295
  %".377" = add i64 %".376", %".373"
  %".378" = trunc i64 %".377" to i32
  %".379" = lshr i64 %".377", 32
  %".380" = trunc i64 %".379" to i1
  %"P67_to_i32" = zext i1 %".380" to i32
  %".381" = zext i32 %"R19:R18_r0" to i64
  %".382" = zext i32 %"imad.34" to i64
  %".383" = shl i64 %".382", 32
  %"lea_funnel.7" = or i64 %".381", %".383"
  %".384" = zext i32 %"UR13:UR12_r1" to i64
  %".385" = zext i32 2 to i64
  %".386" = shl i64 %"lea_funnel.7", %".385"
  %".387" = lshr i64 %".386", 32
  %".388" = add i64 %".387", %".384"
  %"lea_cin_trunc.15" = trunc i32 %"P67_to_i32" to i1
  %".389" = zext i1 %"lea_cin_trunc.15" to i64
  %".390" = add i64 %".388", %".389"
  %".391" = trunc i64 %".390" to i32
  %"R19:R18_bitcast" = bitcast double              0x0 to i64
  %"R19:R18_r0.1" = trunc i64 %"R19:R18_bitcast" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"R19:R18_bitcast", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  br label %"BB_08c0"
BB_08c0:
  %"cond_trunc.9" = trunc i32 %"P69_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800008c0", label %"BB_08d0"
BB_800008c0:
  %"ldg_addr_r0_ext.6" = zext i32 %".349" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %".362" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"R124:R338_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.6" to float addrspace(1)*
  %"ldg.6" = load float, float addrspace(1)* %"R124:R338_addr_ptr"
  br label %"BB_08d0"
BB_08d0:
  %"phi.10" = phi  float [%"ldg.6", %"BB_800008c0"], [0x0, %"BB_08c0"]
  %"cond_trunc.10" = trunc i32 %"P19_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  %"phi_cast_R81_bitcast" = bitcast i32 0 to float
  br i1 %"pbra_cond_to_i1.10", label %"BB_800008d0", label %"BB_08e0"
BB_800008d0:
  %"ldg_addr_r0_ext.7" = zext i32 %".285" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %".298" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"R112:R274_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.7" to float addrspace(1)*
  %"ldg.7" = load float, float addrspace(1)* %"R112:R274_addr_ptr"
  br label %"BB_08e0"
BB_08e0:
  %"phi.11" = phi  float [%"ldg.7", %"BB_800008d0"], [%"phi_cast_R81_bitcast", %"BB_08d0"]
  %"cond_trunc.11" = trunc i32 %"P61_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  %"phi_cast_R371_bitcast" = bitcast i32 %"R19:R18_r1.1" to float
  br i1 %"pbra_cond_to_i1.11", label %"BB_800008e0", label %"BB_08f0"
BB_800008e0:
  %"ldg_addr_r0_ext.8" = zext i32 %".317" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %".330" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"R320:R183_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.8" to float addrspace(1)*
  %"ldg.8" = load float, float addrspace(1)* %"R320:R183_addr_ptr"
  br label %"BB_08f0"
BB_08f0:
  %"phi.12" = phi  float [%"ldg.8", %"BB_800008e0"], [%"phi_cast_R371_bitcast", %"BB_08e0"]
  %"cond_trunc.12" = trunc i32 %"P75_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  %"phi_cast_R312_bitcast" = bitcast i32 %"R19:R18_r0.1" to float
  br i1 %"pbra_cond_to_i1.12", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"ldg_addr_r0_ext.9" = zext i32 %".378" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %".391" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"R405:R382_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.9" to float addrspace(1)*
  %"ldg.9" = load float, float addrspace(1)* %"R405:R382_addr_ptr"
  br label %"BB_0900"
BB_0900:
  %"phi.13" = phi  float [%"ldg.9", %"BB_800008f0"], [%"phi_cast_R312_bitcast", %"BB_08f0"]
  %"fmul.1" = fmul float %"phi.6", %"phi.4"
  %"fmul.2" = fmul float %"phi.7", %"phi.4"
  %"sts_addr_memaddr_offset_add.7" = add i32 %".118", 1040
  %".401" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.7"
  %"sts_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".401" to float addrspace(3)*
  store volatile float %"fmul.1", float addrspace(3)* %"sts_shared_addr_cast.8"
  %".403" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".118"
  %"sts_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".403" to float addrspace(3)*
  store volatile float %"fmul.2", float addrspace(3)* %"sts_shared_addr_cast.9"
  %"fmul.3" = fmul float %"phi.8", %"phi.4"
  %"sts_addr_memaddr_offset_add.8" = add i32 %".118", 2080
  %".405" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.8"
  %"sts_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".405" to float addrspace(3)*
  store volatile float %"fmul.3", float addrspace(3)* %"sts_shared_addr_cast.10"
  %"fmul.4" = fmul float %"phi.9", %"phi.4"
  %"sts_addr_memaddr_offset_add.9" = add i32 %".118", 3120
  %".407" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.9"
  %"sts_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".407" to float addrspace(3)*
  store volatile float %"fmul.4", float addrspace(3)* %"sts_shared_addr_cast.11"
  %"fmul.5" = fmul float %"phi.10", %"phi.4"
  %"fmul.6" = fmul float %"phi.11", %"phi.4"
  %"fmul.7" = fmul float %"phi.12", %"phi.4"
  %"fmul.8" = fmul float %"phi.13", %"phi.4"
  %"sts_addr_memaddr_offset_add.10" = add i32 %".118", 4160
  %".409" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.10"
  %"sts_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".409" to float addrspace(3)*
  store volatile float %"fmul.6", float addrspace(3)* %"sts_shared_addr_cast.12"
  %"sts_addr_memaddr_offset_add.11" = add i32 %".118", 5200
  %".411" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.11"
  %"sts_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".411" to float addrspace(3)*
  store volatile float %"fmul.7", float addrspace(3)* %"sts_shared_addr_cast.13"
  %"sts_addr_memaddr_offset_add.12" = add i32 %".118", 6240
  %".413" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.12"
  %"sts_shared_addr_cast.14" = bitcast i8 addrspace(3)* %".413" to float addrspace(3)*
  store volatile float %"fmul.5", float addrspace(3)* %"sts_shared_addr_cast.14"
  %"sts_addr_memaddr_offset_add.13" = add i32 %".118", 7280
  %".415" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.13"
  %"sts_shared_addr_cast.15" = bitcast i8 addrspace(3)* %".415" to float addrspace(3)*
  store volatile float %"fmul.8", float addrspace(3)* %"sts_shared_addr_cast.15"
  br label %"BB_0a00"
BB_0a00:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.13" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_1370", label %"BB_0a40"
BB_0a40:
  %"fsetrp_cmp1.1" = fcmp une float %"phi.5",              0x0
  %"fsetrp_cmp2.1" = and i1 %"fsetrp_cmp1.1", 1
  %"P6_to_i32" = zext i1 %"fsetrp_cmp2.1" to i32
  %".420" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 548
  %".421" = bitcast i8* %".420" to i32*
  %"ldc_const.7" = load i32, i32* %".421"
  %".422" = zext i32 0 to i64
  %".423" = zext i32 %"ldc_const.7" to i64
  %".424" = shl i64 %".423", 32
  %"shf_concat.7" = or i64 %".422", %".424"
  %"shf_shift_64.7" = zext i32 31 to i64
  %".425" = ashr i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_hi.5" = lshr i64 %".425", 32
  %"shf_result.7" = trunc i64 %"shf_hi.5" to i32
  br label %"BB_0a70"
BB_0a70:
  %"cond_trunc.14" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0c10", label %"BB_0a80"
BB_0a80:
  %".428" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".118"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".428" to float addrspace(3)*
  %"lds" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast"
  %"lds_addr_memaddr_offset_add" = add i32 %".118", 1040
  %".429" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".429" to float addrspace(3)*
  %"lds.1" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.1"
  %"lds_addr_memaddr_offset_add.1" = add i32 %".118", 2080
  %".430" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.1"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".430" to float addrspace(3)*
  %"lds.2" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.2"
  %"lds_addr_memaddr_offset_add.2" = add i32 %".118", 3120
  %".431" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.2"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".431" to float addrspace(3)*
  %"lds.3" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.3"
  %"lds_addr_memaddr_offset_add.3" = add i32 %".118", 4160
  %".432" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.3"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".432" to float addrspace(3)*
  %"lds.4" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.4"
  %"lds_addr_memaddr_offset_add.4" = add i32 %".118", 5200
  %".433" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.4"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".433" to float addrspace(3)*
  %"lds.5" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.5"
  %"lds_addr_memaddr_offset_add.5" = add i32 %".118", 6240
  %".434" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.5"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".434" to float addrspace(3)*
  %"lds.6" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.6"
  %"lds_addr_memaddr_offset_add.6" = add i32 %".118", 7280
  %".435" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.6"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".435" to float addrspace(3)*
  %"lds.7" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.7"
  %"ffma" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds")
  %"ffma.1" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds.1")
  %".436" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".118"
  %"sts_shared_addr_cast.16" = bitcast i8 addrspace(3)* %".436" to float addrspace(3)*
  store volatile float %"ffma", float addrspace(3)* %"sts_shared_addr_cast.16"
  %"ffma.2" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds.2")
  %"sts_addr_memaddr_offset_add.14" = add i32 %".118", 1040
  %".438" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.14"
  %"sts_shared_addr_cast.17" = bitcast i8 addrspace(3)* %".438" to float addrspace(3)*
  store volatile float %"ffma.1", float addrspace(3)* %"sts_shared_addr_cast.17"
  %"ffma.3" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds.3")
  %"sts_addr_memaddr_offset_add.15" = add i32 %".118", 2080
  %".440" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.15"
  %"sts_shared_addr_cast.18" = bitcast i8 addrspace(3)* %".440" to float addrspace(3)*
  store volatile float %"ffma.2", float addrspace(3)* %"sts_shared_addr_cast.18"
  %"ffma.4" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds.4")
  %"sts_addr_memaddr_offset_add.16" = add i32 %".118", 3120
  %".442" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.16"
  %"sts_shared_addr_cast.19" = bitcast i8 addrspace(3)* %".442" to float addrspace(3)*
  store volatile float %"ffma.3", float addrspace(3)* %"sts_shared_addr_cast.19"
  %"ffma.5" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds.5")
  %"sts_addr_memaddr_offset_add.17" = add i32 %".118", 4160
  %".444" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.17"
  %"sts_shared_addr_cast.20" = bitcast i8 addrspace(3)* %".444" to float addrspace(3)*
  store volatile float %"ffma.4", float addrspace(3)* %"sts_shared_addr_cast.20"
  %"ffma.6" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds.6")
  %"sts_addr_memaddr_offset_add.18" = add i32 %".118", 5200
  %".446" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.18"
  %"sts_shared_addr_cast.21" = bitcast i8 addrspace(3)* %".446" to float addrspace(3)*
  store volatile float %"ffma.5", float addrspace(3)* %"sts_shared_addr_cast.21"
  %"ffma.7" = call float @"llvm.fma.f32"(float              0x0, float %"phi.5", float %"lds.7")
  %"sts_addr_memaddr_offset_add.19" = add i32 %".118", 6240
  %".448" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.19"
  %"sts_shared_addr_cast.22" = bitcast i8 addrspace(3)* %".448" to float addrspace(3)*
  store volatile float %"ffma.6", float addrspace(3)* %"sts_shared_addr_cast.22"
  %"sts_addr_memaddr_offset_add.20" = add i32 %".118", 7280
  %".450" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.20"
  %"sts_shared_addr_cast.23" = bitcast i8 addrspace(3)* %".450" to float addrspace(3)*
  store volatile float %"ffma.7", float addrspace(3)* %"sts_shared_addr_cast.23"
  br label %"BB_1370"
BB_0c10:
  %"iadd3_o1_64.8" = zext i32 %"shf_result.1" to i64
  %"iadd3_o2_64.8" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.8" = zext i32 0 to i64
  %"iadd3_tmp.8" = add i64 %"iadd3_o1_64.8", %"iadd3_o2_64.8"
  %"iadd3_tmp2.8" = add i64 %"iadd3_tmp.8", %"iadd3_o3_64.8"
  %"iadd3_trunc.8" = trunc i64 %"iadd3_tmp2.8" to i32
  %"iadd3_carry_val.8" = lshr i64 %"iadd3_tmp2.8", 32
  %"carry_ge_1.8" = icmp uge i64 %"iadd3_carry_val.8", 1
  %"P7_to_i32" = zext i1 %"carry_ge_1.8" to i32
  %"viadd.8" = add i32 %"shf_result.1", 4
  %".453" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 576
  %".454" = bitcast i8* %".453" to i64*
  %"ldc_const.8" = load i64, i64* %".454"
  %"UR13:UR12_r0.1" = trunc i64 %"ldc_const.8" to i32
  %"UR13:UR12_r1_shift.1" = lshr i64 %"ldc_const.8", 32
  %"UR13:UR12_r1.1" = trunc i64 %"UR13:UR12_r1_shift.1" to i32
  %"viadd.9" = add i32 %"shf_result.1", 8
  %".455" = sext i32 %"shf_result.1" to i64
  %".456" = zext i32 %"shf_result.4" to i64
  %".457" = zext i32 1 to i64
  %".458" = shl i64 %".455", %".457"
  %".459" = lshr i64 %".458", 32
  %".460" = add i64 %".459", %".456"
  %"lea_cin_trunc.16" = trunc i32 %"P7_to_i32" to i1
  %".461" = zext i1 %"lea_cin_trunc.16" to i64
  %".462" = add i64 %".460", %".461"
  %".463" = trunc i64 %".462" to i32
  %"viadd.10" = add i32 %"shf_result.1", 12
  %"iadd3_o1_64.9" = zext i32 %"viadd.8" to i64
  %"iadd3_o2_64.9" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.9" = zext i32 0 to i64
  %"iadd3_tmp.9" = add i64 %"iadd3_o1_64.9", %"iadd3_o2_64.9"
  %"iadd3_tmp2.9" = add i64 %"iadd3_tmp.9", %"iadd3_o3_64.9"
  %"iadd3_trunc.9" = trunc i64 %"iadd3_tmp2.9" to i32
  %"iadd3_carry_val.9" = lshr i64 %"iadd3_tmp2.9", 32
  %"carry_ge_1.9" = icmp uge i64 %"iadd3_carry_val.9", 1
  %"P8_to_i32" = zext i1 %"carry_ge_1.9" to i32
  %"viadd.11" = add i32 %"shf_result.1", 16
  %"iadd3_o1_64.10" = zext i32 %"viadd.9" to i64
  %"iadd3_o2_64.10" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.10" = zext i32 0 to i64
  %"iadd3_tmp.10" = add i64 %"iadd3_o1_64.10", %"iadd3_o2_64.10"
  %"iadd3_tmp2.10" = add i64 %"iadd3_tmp.10", %"iadd3_o3_64.10"
  %"iadd3_trunc.10" = trunc i64 %"iadd3_tmp2.10" to i32
  %"iadd3_carry_val.10" = lshr i64 %"iadd3_tmp2.10", 32
  %"carry_ge_1.10" = icmp uge i64 %"iadd3_carry_val.10", 1
  %"P20_to_i32" = zext i1 %"carry_ge_1.10" to i32
  %"imad_tmp.27" = mul i32 %".463", %"ldc_const.7"
  %"imad.35" = add i32 %"imad_tmp.27", 0
  %".464" = sext i32 %"viadd.8" to i64
  %".465" = zext i32 %"shf_result.4" to i64
  %".466" = zext i32 1 to i64
  %".467" = shl i64 %".464", %".466"
  %".468" = lshr i64 %".467", 32
  %".469" = add i64 %".468", %".465"
  %"lea_cin_trunc.17" = trunc i32 %"P8_to_i32" to i1
  %".470" = zext i1 %"lea_cin_trunc.17" to i64
  %".471" = add i64 %".469", %".470"
  %".472" = trunc i64 %".471" to i32
  %"viadd.12" = add i32 %"shf_result.1", 20
  %"imad_tmp.28" = mul i32 %"iadd3_trunc.8", %"shf_result.7"
  %"imad.36" = add i32 %"imad_tmp.28", %"imad.35"
  %"imad_addend_r0_ext.8" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.8" = or i64 0, %"imad_addend_r0_ext.8"
  %"imad_addend_r1_ext.8" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.8" = shl i64 %"imad_addend_r1_ext.8", 32
  %"imad_addend_packed_1.8" = or i64 %"imad_addend_packed_0.8", %"imad_addend_r1_shift.8"
  %"imad_lhs_64.8" = zext i32 %"iadd3_trunc.8" to i64
  %"imad_rhs_64.8" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.8" = mul i64 %"imad_lhs_64.8", %"imad_rhs_64.8"
  %"imad.37" = add i64 %"imad_tmp_64.8", %"imad_addend_packed_1.8"
  %"R13:R12_r0.3" = trunc i64 %"imad.37" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.37", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"imad_tmp.29" = mul i32 %".472", %"ldc_const.7"
  %"imad.38" = add i32 %"imad_tmp.29", 0
  %".473" = sext i32 %"viadd.9" to i64
  %".474" = zext i32 %"shf_result.4" to i64
  %".475" = zext i32 1 to i64
  %".476" = shl i64 %".473", %".475"
  %".477" = lshr i64 %".476", 32
  %".478" = add i64 %".477", %".474"
  %"lea_cin_trunc.18" = trunc i32 %"P20_to_i32" to i1
  %".479" = zext i1 %"lea_cin_trunc.18" to i64
  %".480" = add i64 %".478", %".479"
  %".481" = trunc i64 %".480" to i32
  %"imad_tmp.30" = mul i32 %"R13:R12_r1.3", 1
  %"imad.39" = add i32 %"imad_tmp.30", %"imad.36"
  %".482" = zext i32 %"R13:R12_r0.3" to i64
  %".483" = zext i32 %"UR13:UR12_r0.1" to i64
  %".484" = zext i32 2 to i64
  %".485" = shl i64 %".482", %".484"
  %".486" = and i64 %".485", 4294967295
  %".487" = add i64 %".486", %".483"
  %".488" = trunc i64 %".487" to i32
  %".489" = lshr i64 %".487", 32
  %".490" = trunc i64 %".489" to i1
  %"P9_to_i32" = zext i1 %".490" to i32
  %"imad_tmp.31" = mul i32 %"iadd3_trunc.9", %"shf_result.7"
  %"imad.40" = add i32 %"imad_tmp.31", %"imad.38"
  %"imad_addend_r0_ext.9" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.9" = or i64 0, %"imad_addend_r0_ext.9"
  %"imad_addend_r1_ext.9" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.9" = shl i64 %"imad_addend_r1_ext.9", 32
  %"imad_addend_packed_1.9" = or i64 %"imad_addend_packed_0.9", %"imad_addend_r1_shift.9"
  %"imad_lhs_64.9" = zext i32 %"iadd3_trunc.9" to i64
  %"imad_rhs_64.9" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.9" = mul i64 %"imad_lhs_64.9", %"imad_rhs_64.9"
  %"imad.41" = add i64 %"imad_tmp_64.9", %"imad_addend_packed_1.9"
  %"R11:R10_r0" = trunc i64 %"imad.41" to i32
  %"R11:R10_r1_shift" = lshr i64 %"imad.41", 32
  %"R11:R10_r1" = trunc i64 %"R11:R10_r1_shift" to i32
  %"iadd3_o1_64.11" = zext i32 %"viadd.10" to i64
  %"iadd3_o2_64.11" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.11" = zext i32 0 to i64
  %"iadd3_tmp.11" = add i64 %"iadd3_o1_64.11", %"iadd3_o2_64.11"
  %"iadd3_tmp2.11" = add i64 %"iadd3_tmp.11", %"iadd3_o3_64.11"
  %"iadd3_trunc.11" = trunc i64 %"iadd3_tmp2.11" to i32
  %"iadd3_carry_val.11" = lshr i64 %"iadd3_tmp2.11", 32
  %"carry_ge_1.11" = icmp uge i64 %"iadd3_carry_val.11", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.11" to i32
  %".491" = zext i32 %"R13:R12_r0.3" to i64
  %".492" = zext i32 %"imad.39" to i64
  %".493" = shl i64 %".492", 32
  %"lea_funnel.8" = or i64 %".491", %".493"
  %".494" = zext i32 %"UR13:UR12_r1.1" to i64
  %".495" = zext i32 2 to i64
  %".496" = shl i64 %"lea_funnel.8", %".495"
  %".497" = lshr i64 %".496", 32
  %".498" = add i64 %".497", %".494"
  %"lea_cin_trunc.19" = trunc i32 %"P9_to_i32" to i1
  %".499" = zext i1 %"lea_cin_trunc.19" to i64
  %".500" = add i64 %".498", %".499"
  %".501" = trunc i64 %".500" to i32
  %"imad_tmp.32" = mul i32 %".481", %"ldc_const.7"
  %"imad.42" = add i32 %"imad_tmp.32", 0
  %".502" = zext i32 %"R11:R10_r0" to i64
  %".503" = zext i32 %"UR13:UR12_r0.1" to i64
  %".504" = zext i32 2 to i64
  %".505" = shl i64 %".502", %".504"
  %".506" = and i64 %".505", 4294967295
  %".507" = add i64 %".506", %".503"
  %".508" = trunc i64 %".507" to i32
  %".509" = lshr i64 %".507", 32
  %".510" = trunc i64 %".509" to i1
  %"P10_to_i32" = zext i1 %".510" to i32
  %"imad_tmp.33" = mul i32 %"R11:R10_r1", 1
  %"imad.43" = add i32 %"imad_tmp.33", %"imad.40"
  %"imad_addend_r0_ext.10" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.10" = or i64 0, %"imad_addend_r0_ext.10"
  %"imad_addend_r1_ext.10" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.10" = shl i64 %"imad_addend_r1_ext.10", 32
  %"imad_addend_packed_1.10" = or i64 %"imad_addend_packed_0.10", %"imad_addend_r1_shift.10"
  %"imad_lhs_64.10" = zext i32 %"iadd3_trunc.10" to i64
  %"imad_rhs_64.10" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.10" = mul i64 %"imad_lhs_64.10", %"imad_rhs_64.10"
  %"imad.44" = add i64 %"imad_tmp_64.10", %"imad_addend_packed_1.10"
  %"R13:R12_r0.4" = trunc i64 %"imad.44" to i32
  %"R13:R12_r1_shift.4" = lshr i64 %"imad.44", 32
  %"R13:R12_r1.4" = trunc i64 %"R13:R12_r1_shift.4" to i32
  %".511" = zext i32 %"R11:R10_r0" to i64
  %".512" = zext i32 %"imad.43" to i64
  %".513" = shl i64 %".512", 32
  %"lea_funnel.9" = or i64 %".511", %".513"
  %".514" = zext i32 %"UR13:UR12_r1.1" to i64
  %".515" = zext i32 2 to i64
  %".516" = shl i64 %"lea_funnel.9", %".515"
  %".517" = lshr i64 %".516", 32
  %".518" = add i64 %".517", %".514"
  %"lea_cin_trunc.20" = trunc i32 %"P10_to_i32" to i1
  %".519" = zext i1 %"lea_cin_trunc.20" to i64
  %".520" = add i64 %".518", %".519"
  %".521" = trunc i64 %".520" to i32
  %"imad_tmp.34" = mul i32 %"iadd3_trunc.10", %"shf_result.7"
  %"imad.45" = add i32 %"imad_tmp.34", %"imad.42"
  %".522" = sext i32 %"viadd.10" to i64
  %".523" = zext i32 %"shf_result.4" to i64
  %".524" = zext i32 1 to i64
  %".525" = shl i64 %".522", %".524"
  %".526" = lshr i64 %".525", 32
  %".527" = add i64 %".526", %".523"
  %"lea_cin_trunc.21" = trunc i32 %"P21_to_i32" to i1
  %".528" = zext i1 %"lea_cin_trunc.21" to i64
  %".529" = add i64 %".527", %".528"
  %".530" = trunc i64 %".529" to i32
  %"iadd3_o1_64.12" = zext i32 %"viadd.11" to i64
  %"iadd3_o2_64.12" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.12" = zext i32 0 to i64
  %"iadd3_tmp.12" = add i64 %"iadd3_o1_64.12", %"iadd3_o2_64.12"
  %"iadd3_tmp2.12" = add i64 %"iadd3_tmp.12", %"iadd3_o3_64.12"
  %"iadd3_trunc.12" = trunc i64 %"iadd3_tmp2.12" to i32
  %"iadd3_carry_val.12" = lshr i64 %"iadd3_tmp2.12", 32
  %"carry_ge_1.12" = icmp uge i64 %"iadd3_carry_val.12", 1
  %"P22_to_i32" = zext i1 %"carry_ge_1.12" to i32
  %"imad_tmp.35" = mul i32 %"R13:R12_r1.4", 1
  %"imad.46" = add i32 %"imad_tmp.35", %"imad.45"
  %".531" = zext i32 %"R13:R12_r0.4" to i64
  %".532" = zext i32 %"UR13:UR12_r0.1" to i64
  %".533" = zext i32 2 to i64
  %".534" = shl i64 %".531", %".533"
  %".535" = and i64 %".534", 4294967295
  %".536" = add i64 %".535", %".532"
  %".537" = trunc i64 %".536" to i32
  %".538" = lshr i64 %".536", 32
  %".539" = trunc i64 %".538" to i1
  %"P11_to_i32" = zext i1 %".539" to i32
  %"imad_tmp.36" = mul i32 %".530", %"ldc_const.7"
  %"imad.47" = add i32 %"imad_tmp.36", 0
  %".540" = sext i32 %"viadd.11" to i64
  %".541" = zext i32 %"shf_result.4" to i64
  %".542" = zext i32 1 to i64
  %".543" = shl i64 %".540", %".542"
  %".544" = lshr i64 %".543", 32
  %".545" = add i64 %".544", %".541"
  %"lea_cin_trunc.22" = trunc i32 %"P22_to_i32" to i1
  %".546" = zext i1 %"lea_cin_trunc.22" to i64
  %".547" = add i64 %".545", %".546"
  %".548" = trunc i64 %".547" to i32
  %".549" = zext i32 %"R13:R12_r0.4" to i64
  %".550" = zext i32 %"imad.46" to i64
  %".551" = shl i64 %".550", 32
  %"lea_funnel.10" = or i64 %".549", %".551"
  %".552" = zext i32 %"UR13:UR12_r1.1" to i64
  %".553" = zext i32 2 to i64
  %".554" = shl i64 %"lea_funnel.10", %".553"
  %".555" = lshr i64 %".554", 32
  %".556" = add i64 %".555", %".552"
  %"lea_cin_trunc.23" = trunc i32 %"P11_to_i32" to i1
  %".557" = zext i1 %"lea_cin_trunc.23" to i64
  %".558" = add i64 %".556", %".557"
  %".559" = trunc i64 %".558" to i32
  %"imad_tmp.37" = mul i32 %"iadd3_trunc.11", %"shf_result.7"
  %"imad.48" = add i32 %"imad_tmp.37", %"imad.47"
  %"isetrp_cmp1.10" = icmp sgt i32 %"viadd.8", %"viaddmnmx.1"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"imad_addend_r0_ext.11" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.11" = or i64 0, %"imad_addend_r0_ext.11"
  %"imad_addend_r1_ext.11" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.11" = shl i64 %"imad_addend_r1_ext.11", 32
  %"imad_addend_packed_1.11" = or i64 %"imad_addend_packed_0.11", %"imad_addend_r1_shift.11"
  %"imad_lhs_64.11" = zext i32 %"iadd3_trunc.11" to i64
  %"imad_rhs_64.11" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.11" = mul i64 %"imad_lhs_64.11", %"imad_rhs_64.11"
  %"imad.49" = add i64 %"imad_tmp_64.11", %"imad_addend_packed_1.11"
  %"R15:R14_r0.3" = trunc i64 %"imad.49" to i32
  %"R15:R14_r1_shift.3" = lshr i64 %"imad.49", 32
  %"R15:R14_r1.3" = trunc i64 %"R15:R14_r1_shift.3" to i32
  %"imad_tmp.38" = mul i32 %".548", %"ldc_const.7"
  %"imad.50" = add i32 %"imad_tmp.38", 0
  %"imad_tmp.39" = mul i32 %"R15:R14_r1.3", 1
  %"imad.51" = add i32 %"imad_tmp.39", %"imad.48"
  %"imad_tmp.40" = mul i32 %"iadd3_trunc.12", %"shf_result.7"
  %"imad.52" = add i32 %"imad_tmp.40", %"imad.50"
  %".560" = zext i32 %"R15:R14_r0.3" to i64
  %".561" = zext i32 %"UR13:UR12_r0.1" to i64
  %".562" = zext i32 2 to i64
  %".563" = shl i64 %".560", %".562"
  %".564" = and i64 %".563", 4294967295
  %".565" = add i64 %".564", %".561"
  %".566" = trunc i64 %".565" to i32
  %".567" = lshr i64 %".565", 32
  %".568" = trunc i64 %".567" to i1
  %"P13_to_i32" = zext i1 %".568" to i32
  %"imad_addend_r0_ext.12" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.12" = or i64 0, %"imad_addend_r0_ext.12"
  %"imad_addend_r1_ext.12" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.12" = shl i64 %"imad_addend_r1_ext.12", 32
  %"imad_addend_packed_1.12" = or i64 %"imad_addend_packed_0.12", %"imad_addend_r1_shift.12"
  %"imad_lhs_64.12" = zext i32 %"iadd3_trunc.12" to i64
  %"imad_rhs_64.12" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.12" = mul i64 %"imad_lhs_64.12", %"imad_rhs_64.12"
  %"imad.53" = add i64 %"imad_tmp_64.12", %"imad_addend_packed_1.12"
  %"R17:R16_r0.1" = trunc i64 %"imad.53" to i32
  %"R17:R16_r1_shift.1" = lshr i64 %"imad.53", 32
  %"R17:R16_r1.1" = trunc i64 %"R17:R16_r1_shift.1" to i32
  %".569" = zext i32 %"R15:R14_r0.3" to i64
  %".570" = zext i32 %"imad.51" to i64
  %".571" = shl i64 %".570", 32
  %"lea_funnel.11" = or i64 %".569", %".571"
  %".572" = zext i32 %"UR13:UR12_r1.1" to i64
  %".573" = zext i32 2 to i64
  %".574" = shl i64 %"lea_funnel.11", %".573"
  %".575" = lshr i64 %".574", 32
  %".576" = add i64 %".575", %".572"
  %"lea_cin_trunc.24" = trunc i32 %"P13_to_i32" to i1
  %".577" = zext i1 %"lea_cin_trunc.24" to i64
  %".578" = add i64 %".576", %".577"
  %".579" = trunc i64 %".578" to i32
  %"imad_tmp.41" = mul i32 %"R17:R16_r1.1", 1
  %"imad.54" = add i32 %"imad_tmp.41", %"imad.52"
  %".580" = zext i32 %"R17:R16_r0.1" to i64
  %".581" = zext i32 %"UR13:UR12_r0.1" to i64
  %".582" = zext i32 2 to i64
  %".583" = shl i64 %".580", %".582"
  %".584" = and i64 %".583", 4294967295
  %".585" = add i64 %".584", %".581"
  %".586" = trunc i64 %".585" to i32
  %".587" = lshr i64 %".585", 32
  %".588" = trunc i64 %".587" to i1
  %"P14_to_i32" = zext i1 %".588" to i32
  %"iadd3_o1_64.13" = zext i32 %"viadd.12" to i64
  %"iadd3_o2_64.13" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.13" = zext i32 0 to i64
  %"iadd3_tmp.13" = add i64 %"iadd3_o1_64.13", %"iadd3_o2_64.13"
  %"iadd3_tmp2.13" = add i64 %"iadd3_tmp.13", %"iadd3_o3_64.13"
  %"iadd3_trunc.13" = trunc i64 %"iadd3_tmp2.13" to i32
  %"iadd3_carry_val.13" = lshr i64 %"iadd3_tmp2.13", 32
  %"carry_ge_1.13" = icmp uge i64 %"iadd3_carry_val.13", 1
  %"P62_to_i32" = zext i1 %"carry_ge_1.13" to i32
  %".589" = zext i32 %"R17:R16_r0.1" to i64
  %".590" = zext i32 %"imad.54" to i64
  %".591" = shl i64 %".590", 32
  %"lea_funnel.12" = or i64 %".589", %".591"
  %".592" = zext i32 %"UR13:UR12_r1.1" to i64
  %".593" = zext i32 2 to i64
  %".594" = shl i64 %"lea_funnel.12", %".593"
  %".595" = lshr i64 %".594", 32
  %".596" = add i64 %".595", %".592"
  %"lea_cin_trunc.25" = trunc i32 %"P14_to_i32" to i1
  %".597" = zext i1 %"lea_cin_trunc.25" to i64
  %".598" = add i64 %".596", %".597"
  %".599" = trunc i64 %".598" to i32
  %"isetrp_cmp1.11" = icmp sgt i32 %"shf_result.1", %"viaddmnmx.1"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %".600" = sext i32 %"viadd.12" to i64
  %".601" = zext i32 %"shf_result.4" to i64
  %".602" = zext i32 1 to i64
  %".603" = shl i64 %".600", %".602"
  %".604" = lshr i64 %".603", 32
  %".605" = add i64 %".604", %".601"
  %"lea_cin_trunc.26" = trunc i32 %"P62_to_i32" to i1
  %".606" = zext i1 %"lea_cin_trunc.26" to i64
  %".607" = add i64 %".605", %".606"
  %".608" = trunc i64 %".607" to i32
  %"imad_tmp.42" = mul i32 %".608", %"ldc_const.7"
  %"imad.55" = add i32 %"imad_tmp.42", 0
  %"imad_tmp.43" = mul i32 %"iadd3_trunc.13", %"shf_result.7"
  %"imad.56" = add i32 %"imad_tmp.43", %"imad.55"
  br label %"BB_0f60"
BB_0f60:
  %"cond_trunc.15" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000f60", label %"BB_0f70"
BB_80000f60:
  %"ldg_addr_r0_ext.10" = zext i32 %".488" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %".501" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"R353:R168_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.10" to float addrspace(1)*
  %"ldg.10" = load float, float addrspace(1)* %"R353:R168_addr_ptr"
  br label %"BB_0f70"
BB_0f70:
  %"phi.14" = phi  float [%"ldg.10", %"BB_80000f60"], [0x0, %"BB_0f60"]
  br label %"BB_0f80"
BB_0f80:
  %"cond_trunc.16" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000f80", label %"BB_0f90"
BB_80000f80:
  %"ldg_addr_r0_ext.11" = zext i32 %".508" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %".521" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"R391:R385_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.11" to float addrspace(1)*
  %"ldg.11" = load float, float addrspace(1)* %"R391:R385_addr_ptr"
  br label %"BB_0f90"
BB_0f90:
  %"phi.15" = phi  float [%"ldg.11", %"BB_80000f80"], [0x0, %"BB_0f80"]
  %"imad_addend_r0_ext.13" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.13" = or i64 0, %"imad_addend_r0_ext.13"
  %"imad_addend_r1_ext.13" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.13" = shl i64 %"imad_addend_r1_ext.13", 32
  %"imad_addend_packed_1.13" = or i64 %"imad_addend_packed_0.13", %"imad_addend_r1_shift.13"
  %"imad_lhs_64.13" = zext i32 %"iadd3_trunc.13" to i64
  %"imad_rhs_64.13" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.13" = mul i64 %"imad_lhs_64.13", %"imad_rhs_64.13"
  %"imad.57" = add i64 %"imad_tmp_64.13", %"imad_addend_packed_1.13"
  %"R19:R18_r0.2" = trunc i64 %"imad.57" to i32
  %"R19:R18_r1_shift.2" = lshr i64 %"imad.57", 32
  %"R19:R18_r1.2" = trunc i64 %"R19:R18_r1_shift.2" to i32
  %"iadd3_n1" = add i32 %"R19:R18_r1.2", %"imad.56"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"viadd.13" = add i32 %"shf_result.1", 24
  %".615" = zext i32 %"R19:R18_r0.2" to i64
  %".616" = zext i32 %"UR13:UR12_r0.1" to i64
  %".617" = zext i32 2 to i64
  %".618" = shl i64 %".615", %".617"
  %".619" = and i64 %".618", 4294967295
  %".620" = add i64 %".619", %".616"
  %".621" = trunc i64 %".620" to i32
  %".622" = lshr i64 %".620", 32
  %".623" = trunc i64 %".622" to i1
  %"P36_to_i32" = zext i1 %".623" to i32
  %".624" = zext i32 %"R19:R18_r0.2" to i64
  %".625" = zext i32 %"iadd3_n2" to i64
  %".626" = shl i64 %".625", 32
  %"lea_funnel.13" = or i64 %".624", %".626"
  %".627" = zext i32 %"UR13:UR12_r1.1" to i64
  %".628" = zext i32 2 to i64
  %".629" = shl i64 %"lea_funnel.13", %".628"
  %".630" = lshr i64 %".629", 32
  %".631" = add i64 %".630", %".627"
  %"lea_cin_trunc.27" = trunc i32 %"P36_to_i32" to i1
  %".632" = zext i1 %"lea_cin_trunc.27" to i64
  %".633" = add i64 %".631", %".632"
  %".634" = trunc i64 %".633" to i32
  %"iadd3_o1_64.14" = zext i32 %"viadd.13" to i64
  %"iadd3_o2_64.14" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.14" = zext i32 0 to i64
  %"iadd3_tmp.14" = add i64 %"iadd3_o1_64.14", %"iadd3_o2_64.14"
  %"iadd3_tmp2.14" = add i64 %"iadd3_tmp.14", %"iadd3_o3_64.14"
  %"iadd3_trunc.14" = trunc i64 %"iadd3_tmp2.14" to i32
  %"iadd3_carry_val.14" = lshr i64 %"iadd3_tmp2.14", 32
  %"carry_ge_1.14" = icmp uge i64 %"iadd3_carry_val.14", 1
  %"P46_to_i32" = zext i1 %"carry_ge_1.14" to i32
  %".635" = sext i32 %"viadd.13" to i64
  %".636" = zext i32 %"shf_result.4" to i64
  %".637" = zext i32 1 to i64
  %".638" = shl i64 %".635", %".637"
  %".639" = lshr i64 %".638", 32
  %".640" = add i64 %".639", %".636"
  %"lea_cin_trunc.28" = trunc i32 %"P46_to_i32" to i1
  %".641" = zext i1 %"lea_cin_trunc.28" to i64
  %".642" = add i64 %".640", %".641"
  %".643" = trunc i64 %".642" to i32
  %"isetrp_cmp1.12" = icmp sgt i32 %"viadd.9", %"viaddmnmx.1"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.44" = mul i32 %".643", %"ldc_const.7"
  %"imad.58" = add i32 %"imad_tmp.44", 0
  %"imad_tmp.45" = mul i32 %"iadd3_trunc.14", %"shf_result.7"
  %"imad.59" = add i32 %"imad_tmp.45", %"imad.58"
  %"imad_addend_r0_ext.14" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.14" = or i64 0, %"imad_addend_r0_ext.14"
  %"imad_addend_r1_ext.14" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.14" = shl i64 %"imad_addend_r1_ext.14", 32
  %"imad_addend_packed_1.14" = or i64 %"imad_addend_packed_0.14", %"imad_addend_r1_shift.14"
  %"imad_lhs_64.14" = zext i32 %"iadd3_trunc.14" to i64
  %"imad_rhs_64.14" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.14" = mul i64 %"imad_lhs_64.14", %"imad_rhs_64.14"
  %"imad.60" = add i64 %"imad_tmp_64.14", %"imad_addend_packed_1.14"
  %"R19:R18_r0.3" = trunc i64 %"imad.60" to i32
  %"R19:R18_r1_shift.3" = lshr i64 %"imad.60", 32
  %"R19:R18_r1.3" = trunc i64 %"R19:R18_r1_shift.3" to i32
  %"isetrp_cmp1.13" = icmp sgt i32 %"viadd.10", %"viaddmnmx.1"
  %"isetrp_src_to_i32.13" = zext i1 1 to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P57_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"lds_addr_memaddr_offset_add.7" = add i32 %".118", 4160
  %".644" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.7"
  %"lds_shared_addr_cast.8" = bitcast i8 addrspace(3)* %".644" to float addrspace(3)*
  %"lds.8" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.8"
  %"imad_tmp.46" = mul i32 %"R19:R18_r1.3", 1
  %"imad.61" = add i32 %"imad_tmp.46", %"imad.59"
  %".645" = zext i32 %"R19:R18_r0.3" to i64
  %".646" = zext i32 %"UR13:UR12_r0.1" to i64
  %".647" = zext i32 2 to i64
  %".648" = shl i64 %".645", %".647"
  %".649" = and i64 %".648", 4294967295
  %".650" = add i64 %".649", %".646"
  %".651" = trunc i64 %".650" to i32
  %".652" = lshr i64 %".650", 32
  %".653" = trunc i64 %".652" to i1
  %"P41_to_i32" = zext i1 %".653" to i32
  %".654" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".118"
  %"lds_shared_addr_cast.9" = bitcast i8 addrspace(3)* %".654" to float addrspace(3)*
  %"lds.9" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.9"
  %".655" = zext i32 %"R19:R18_r0.3" to i64
  %".656" = zext i32 %"imad.61" to i64
  %".657" = shl i64 %".656", 32
  %"lea_funnel.14" = or i64 %".655", %".657"
  %".658" = zext i32 %"UR13:UR12_r1.1" to i64
  %".659" = zext i32 2 to i64
  %".660" = shl i64 %"lea_funnel.14", %".659"
  %".661" = lshr i64 %".660", 32
  %".662" = add i64 %".661", %".658"
  %"lea_cin_trunc.29" = trunc i32 %"P41_to_i32" to i1
  %".663" = zext i1 %"lea_cin_trunc.29" to i64
  %".664" = add i64 %".662", %".663"
  %".665" = trunc i64 %".664" to i32
  %"viadd.14" = add i32 %"shf_result.1", 28
  %"iadd3_o1_64.15" = zext i32 %"viadd.14" to i64
  %"iadd3_o2_64.15" = zext i32 %"shf_result.2" to i64
  %"iadd3_o3_64.15" = zext i32 0 to i64
  %"iadd3_tmp.15" = add i64 %"iadd3_o1_64.15", %"iadd3_o2_64.15"
  %"iadd3_tmp2.15" = add i64 %"iadd3_tmp.15", %"iadd3_o3_64.15"
  %"iadd3_trunc.15" = trunc i64 %"iadd3_tmp2.15" to i32
  %"iadd3_carry_val.15" = lshr i64 %"iadd3_tmp2.15", 32
  %"carry_ge_1.15" = icmp uge i64 %"iadd3_carry_val.15", 1
  %"P42_to_i32" = zext i1 %"carry_ge_1.15" to i32
  %".666" = sext i32 %"viadd.14" to i64
  %".667" = zext i32 %"shf_result.4" to i64
  %".668" = zext i32 1 to i64
  %".669" = shl i64 %".666", %".668"
  %".670" = lshr i64 %".669", 32
  %".671" = add i64 %".670", %".667"
  %"lea_cin_trunc.30" = trunc i32 %"P42_to_i32" to i1
  %".672" = zext i1 %"lea_cin_trunc.30" to i64
  %".673" = add i64 %".671", %".672"
  %".674" = trunc i64 %".673" to i32
  %"imad_addend_r0_ext.15" = zext i32 %"viadd" to i64
  %"imad_addend_packed_0.15" = or i64 0, %"imad_addend_r0_ext.15"
  %"imad_addend_r1_ext.15" = zext i32 %"shf_result.3" to i64
  %"imad_addend_r1_shift.15" = shl i64 %"imad_addend_r1_ext.15", 32
  %"imad_addend_packed_1.15" = or i64 %"imad_addend_packed_0.15", %"imad_addend_r1_shift.15"
  %"imad_lhs_64.15" = zext i32 %"iadd3_trunc.15" to i64
  %"imad_rhs_64.15" = zext i32 %"ldc_const.7" to i64
  %"imad_tmp_64.15" = mul i64 %"imad_lhs_64.15", %"imad_rhs_64.15"
  %"imad.62" = add i64 %"imad_tmp_64.15", %"imad_addend_packed_1.15"
  %"R9:R8_r0" = trunc i64 %"imad.62" to i32
  %"R9:R8_r1_shift" = lshr i64 %"imad.62", 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %"imad_tmp.47" = mul i32 %".674", %"ldc_const.7"
  %"imad.63" = add i32 %"imad_tmp.47", 0
  %"isetrp_cmp1.14" = icmp sgt i32 %"viadd.11", %"viaddmnmx.1"
  %"isetrp_src_to_i32.14" = zext i1 1 to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P70_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"imad_tmp.48" = mul i32 %"iadd3_trunc.15", %"shf_result.7"
  %"imad.64" = add i32 %"imad_tmp.48", %"imad.63"
  %"isetrp_cmp1.15" = icmp sgt i32 %"viadd.12", %"viaddmnmx.1"
  %"isetrp_src_to_i32.15" = zext i1 1 to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P79_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  %"isetrp_cmp1.16" = icmp sgt i32 %"viadd.13", %"viaddmnmx.1"
  %"isetrp_src_to_i32.16" = zext i1 1 to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P80_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"imad_tmp.49" = mul i32 %"R9:R8_r1", 1
  %"imad.65" = add i32 %"imad_tmp.49", %"imad.64"
  %"isetrp_cmp1.17" = icmp sgt i32 %"viadd.14", %"viaddmnmx.1"
  %"isetrp_src_to_i32.17" = zext i1 1 to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %".675" = zext i32 %"R9:R8_r0" to i64
  %".676" = zext i32 %"UR13:UR12_r0.1" to i64
  %".677" = zext i32 2 to i64
  %".678" = shl i64 %".675", %".677"
  %".679" = and i64 %".678", 4294967295
  %".680" = add i64 %".679", %".676"
  %".681" = trunc i64 %".680" to i32
  %".682" = lshr i64 %".680", 32
  %".683" = trunc i64 %".682" to i1
  %"P43_to_i32" = zext i1 %".683" to i32
  %"R23:R22_bitcast" = bitcast double              0x0 to i64
  %"R23:R22_r0" = trunc i64 %"R23:R22_bitcast" to i32
  %"R23:R22_r1_shift" = lshr i64 %"R23:R22_bitcast", 32
  %"R23:R22_r1" = trunc i64 %"R23:R22_r1_shift" to i32
  %".684" = zext i32 %"R9:R8_r0" to i64
  %".685" = zext i32 %"imad.65" to i64
  %".686" = shl i64 %".685", 32
  %"lea_funnel.15" = or i64 %".684", %".686"
  %".687" = zext i32 %"UR13:UR12_r1.1" to i64
  %".688" = zext i32 2 to i64
  %".689" = shl i64 %"lea_funnel.15", %".688"
  %".690" = lshr i64 %".689", 32
  %".691" = add i64 %".690", %".687"
  %"lea_cin_trunc.31" = trunc i32 %"P43_to_i32" to i1
  %".692" = zext i1 %"lea_cin_trunc.31" to i64
  %".693" = add i64 %".691", %".692"
  %".694" = trunc i64 %".693" to i32
  %"R9:R8_bitcast" = bitcast double              0x0 to i64
  %"R9:R8_r0.1" = trunc i64 %"R9:R8_bitcast" to i32
  %"R9:R8_r1_shift.1" = lshr i64 %"R9:R8_bitcast", 32
  %"R9:R8_r1.1" = trunc i64 %"R9:R8_r1_shift.1" to i32
  %"lds_addr_memaddr_offset_add.8" = add i32 %".118", 2080
  %".695" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.8"
  %"lds_shared_addr_cast.10" = bitcast i8 addrspace(3)* %".695" to float addrspace(3)*
  %"lds.10" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.10"
  br label %"BB_11c0"
BB_11c0:
  %"cond_trunc.17" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_800011c0", label %"BB_11d0"
BB_800011c0:
  %"ldg_addr_r0_ext.12" = zext i32 %".537" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %".559" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"R3:R277_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.12" to float addrspace(1)*
  %"ldg.12" = load float, float addrspace(1)* %"R3:R277_addr_ptr"
  br label %"BB_11d0"
BB_11d0:
  %"phi.16" = phi  float [%"ldg.12", %"BB_800011c0"], [0x0, %"BB_11c0"]
  %"cond_trunc.18" = trunc i32 %"P57_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  %"phi_cast_R175_bitcast" = bitcast i32 %"R9:R8_r0.1" to float
  br i1 %"pbra_cond_to_i1.18", label %"BB_800011d0", label %"BB_11e0"
BB_800011d0:
  %"ldg_addr_r0_ext.13" = zext i32 %".566" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %".579" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"R286:R253_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.13" to float addrspace(1)*
  %"ldg.13" = load float, float addrspace(1)* %"R286:R253_addr_ptr"
  br label %"BB_11e0"
BB_11e0:
  %"phi.17" = phi  float [%"ldg.13", %"BB_800011d0"], [%"phi_cast_R175_bitcast", %"BB_11d0"]
  %"cond_trunc.19" = trunc i32 %"P70_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  %"phi_cast_R408_bitcast" = bitcast i32 %"R23:R22_r0" to float
  br i1 %"pbra_cond_to_i1.19", label %"BB_800011e0", label %"BB_11f0"
BB_800011e0:
  %"ldg_addr_r0_ext.14" = zext i32 %".586" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %".599" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"R270:R48_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.14" to float addrspace(1)*
  %"ldg.14" = load float, float addrspace(1)* %"R270:R48_addr_ptr"
  br label %"BB_11f0"
BB_11f0:
  %"phi.18" = phi  float [%"ldg.14", %"BB_800011e0"], [%"phi_cast_R408_bitcast", %"BB_11e0"]
  %"cond_trunc.20" = trunc i32 %"P79_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.20", -1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_800011f0", label %"BB_1200"
BB_800011f0:
  %"ldg_addr_r0_ext.15" = zext i32 %".621" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %".634" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"R334:R329_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.15" to float addrspace(1)*
  %"ldg.15" = load float, float addrspace(1)* %"R334:R329_addr_ptr"
  br label %"BB_1200"
BB_1200:
  %"phi.19" = phi  float [%"ldg.15", %"BB_800011f0"], [0x0, %"BB_11f0"]
  %"cond_trunc.21" = trunc i32 %"P80_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  %"phi_cast_R27_bitcast" = bitcast i32 %"R23:R22_r1" to float
  br i1 %"pbra_cond_to_i1.21", label %"BB_80001200", label %"BB_1210"
BB_80001200:
  %"ldg_addr_r0_ext.16" = zext i32 %".651" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %".665" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"R392:R386_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.16" to float addrspace(1)*
  %"ldg.16" = load float, float addrspace(1)* %"R392:R386_addr_ptr"
  br label %"BB_1210"
BB_1210:
  %"phi.20" = phi  float [%"ldg.16", %"BB_80001200"], [%"phi_cast_R27_bitcast", %"BB_1200"]
  %"cond_trunc.22" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.15" = xor i1 %"cond_trunc.22", -1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_not.15" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  %"phi_cast_R191_bitcast" = bitcast i32 %"R9:R8_r1.1" to float
  br i1 %"pbra_cond_to_i1.22", label %"BB_80001210", label %"BB_1220"
BB_80001210:
  %"ldg_addr_r0_ext.17" = zext i32 %".681" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %".694" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"R359:R224_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.17" to float addrspace(1)*
  %"ldg.17" = load float, float addrspace(1)* %"R359:R224_addr_ptr"
  br label %"BB_1220"
BB_1220:
  %"phi.21" = phi  float [%"ldg.17", %"BB_80001210"], [%"phi_cast_R191_bitcast", %"BB_1210"]
  %"lds_addr_memaddr_offset_add.9" = add i32 %".118", 1040
  %".709" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.9"
  %"lds_shared_addr_cast.11" = bitcast i8 addrspace(3)* %".709" to float addrspace(3)*
  %"lds.11" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.11"
  %"lds_addr_memaddr_offset_add.10" = add i32 %".118", 3120
  %".710" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.10"
  %"lds_shared_addr_cast.12" = bitcast i8 addrspace(3)* %".710" to float addrspace(3)*
  %"lds.12" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.12"
  %"lds_addr_memaddr_offset_add.11" = add i32 %".118", 5200
  %".711" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.11"
  %"lds_shared_addr_cast.13" = bitcast i8 addrspace(3)* %".711" to float addrspace(3)*
  %"lds.13" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.13"
  %"lds_addr_memaddr_offset_add.12" = add i32 %".118", 6240
  %".712" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.12"
  %"lds_shared_addr_cast.14" = bitcast i8 addrspace(3)* %".712" to float addrspace(3)*
  %"lds.14" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.14"
  %"lds_addr_memaddr_offset_add.13" = add i32 %".118", 7280
  %".713" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.13"
  %"lds_shared_addr_cast.15" = bitcast i8 addrspace(3)* %".713" to float addrspace(3)*
  %"lds.15" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.15"
  %"ffma.8" = call float @"llvm.fma.f32"(float %"phi.14", float %"phi.5", float %"lds.9")
  %"ffma.9" = call float @"llvm.fma.f32"(float %"phi.15", float %"phi.5", float %"lds.11")
  %".714" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".118"
  %"sts_shared_addr_cast.24" = bitcast i8 addrspace(3)* %".714" to float addrspace(3)*
  store volatile float %"ffma.8", float addrspace(3)* %"sts_shared_addr_cast.24"
  %"sts_addr_memaddr_offset_add.21" = add i32 %".118", 1040
  %".716" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.21"
  %"sts_shared_addr_cast.25" = bitcast i8 addrspace(3)* %".716" to float addrspace(3)*
  store volatile float %"ffma.9", float addrspace(3)* %"sts_shared_addr_cast.25"
  %"ffma.10" = call float @"llvm.fma.f32"(float %"phi.16", float %"phi.5", float %"lds.10")
  %"ffma.11" = call float @"llvm.fma.f32"(float %"phi.17", float %"phi.5", float %"lds.12")
  %"ffma.12" = call float @"llvm.fma.f32"(float %"phi.18", float %"phi.5", float %"lds.8")
  %"ffma.13" = call float @"llvm.fma.f32"(float %"phi.19", float %"phi.5", float %"lds.13")
  %"ffma.14" = call float @"llvm.fma.f32"(float %"phi.20", float %"phi.5", float %"lds.14")
  %"ffma.15" = call float @"llvm.fma.f32"(float %"phi.21", float %"phi.5", float %"lds.15")
  %"sts_addr_memaddr_offset_add.22" = add i32 %".118", 2080
  %".718" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.22"
  %"sts_shared_addr_cast.26" = bitcast i8 addrspace(3)* %".718" to float addrspace(3)*
  store volatile float %"ffma.10", float addrspace(3)* %"sts_shared_addr_cast.26"
  %"sts_addr_memaddr_offset_add.23" = add i32 %".118", 3120
  %".720" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.23"
  %"sts_shared_addr_cast.27" = bitcast i8 addrspace(3)* %".720" to float addrspace(3)*
  store volatile float %"ffma.11", float addrspace(3)* %"sts_shared_addr_cast.27"
  %"sts_addr_memaddr_offset_add.24" = add i32 %".118", 4160
  %".722" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.24"
  %"sts_shared_addr_cast.28" = bitcast i8 addrspace(3)* %".722" to float addrspace(3)*
  store volatile float %"ffma.12", float addrspace(3)* %"sts_shared_addr_cast.28"
  %"sts_addr_memaddr_offset_add.25" = add i32 %".118", 5200
  %".724" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.25"
  %"sts_shared_addr_cast.29" = bitcast i8 addrspace(3)* %".724" to float addrspace(3)*
  store volatile float %"ffma.13", float addrspace(3)* %"sts_shared_addr_cast.29"
  %"sts_addr_memaddr_offset_add.26" = add i32 %".118", 6240
  %".726" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.26"
  %"sts_shared_addr_cast.30" = bitcast i8 addrspace(3)* %".726" to float addrspace(3)*
  store volatile float %"ffma.14", float addrspace(3)* %"sts_shared_addr_cast.30"
  %"sts_addr_memaddr_offset_add.27" = add i32 %".118", 7280
  %".728" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_addr_memaddr_offset_add.27"
  %"sts_shared_addr_cast.31" = bitcast i8 addrspace(3)* %".728" to float addrspace(3)*
  store volatile float %"ffma.15", float addrspace(3)* %"sts_shared_addr_cast.31"
  br label %"BB_1370"
BB_1370:
  %"isetrp_cmp1.18" = icmp sgt i32 %"shf_result.5", %"viaddmnmx.1"
  %"isetrp_src_to_i32.18" = zext i1 1 to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P71_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  %"viadd.15" = add i32 %"shf_result.5", 8
  %".731" = zext i32 0 to i64
  %".732" = zext i32 %"shf_result" to i64
  %".733" = shl i64 %".732", 32
  %"shf_concat.8" = or i64 %".731", %".733"
  %"shf_shift_64.8" = zext i32 31 to i64
  %".734" = ashr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.6" = lshr i64 %".734", 32
  %"shf_result.8" = trunc i64 %"shf_hi.6" to i32
  %"viadd.16" = add i32 %"shf_result.5", 16
  %".735" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 552
  %".736" = bitcast i8* %".735" to i32*
  %"ldc_const.9" = load i32, i32* %".736"
  %"viadd.17" = add i32 %"shf_result.5", 24
  %"isetrp_cmp1.19" = icmp sgt i32 %"viadd.15", %"viaddmnmx.1"
  %"isetrp_src_to_i32.19" = zext i1 1 to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"viadd.18" = add i32 %"viadd.15", %"shf_result.2"
  %"isetrp_cmp1.20" = icmp sgt i32 %"viadd.16", %"viaddmnmx.1"
  %"isetrp_src_to_i32.20" = zext i1 1 to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P73_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  %"viadd.19" = add i32 %"viadd.17", %"shf_result.2"
  call void @"llvm.nvvm.barrier0"()
  %"isetrp_cmp1.21" = icmp sgt i32 %"viadd.17", %"viaddmnmx.1"
  %"isetrp_src_to_i32.21" = zext i1 1 to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %"viadd.20" = add i32 %"viadd.16", %"shf_result.2"
  %".737" = zext i32 0 to i64
  %".738" = zext i32 %"viadd.18" to i64
  %".739" = shl i64 %".738", 32
  %"shf_concat.9" = or i64 %".737", %".739"
  %"shf_shift_64.9" = zext i32 31 to i64
  %".740" = ashr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.7" = lshr i64 %".740", 32
  %"shf_result.9" = trunc i64 %"shf_hi.7" to i32
  %"imad_tmp.50" = mul i32 0, 0
  %"imad.66" = add i32 %"imad_tmp.50", %"shf_result"
  %".741" = zext i32 0 to i64
  %".742" = zext i32 %"ldc_const.9" to i64
  %".743" = shl i64 %".742", 32
  %"shf_concat.10" = or i64 %".741", %".743"
  %"shf_shift_64.10" = zext i32 31 to i64
  %".744" = ashr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.8" = lshr i64 %".744", 32
  %"shf_result.10" = trunc i64 %"shf_hi.8" to i32
  %".745" = xor i32 %"tid_x", -1
  %".746" = xor i32 31, -1
  %".747" = xor i32 0, -1
  %".748" = and i32 %"tid_x", 31
  %".749" = and i32 %".748", %".747"
  %".750" = and i32 %"tid_x", 31
  %".751" = and i32 %".750", 0
  %".752" = or i32 %".749", %".751"
  %"imad_tmp.51" = mul i32 %"shf_result.9", %"ldc_const.9"
  %"imad.67" = add i32 %"imad_tmp.51", 0
  %".753" = zext i32 0 to i64
  %".754" = zext i32 %"viadd.20" to i64
  %".755" = shl i64 %".754", 32
  %"shf_concat.11" = or i64 %".753", %".755"
  %"shf_shift_64.11" = zext i32 31 to i64
  %".756" = ashr i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_hi.9" = lshr i64 %".756", 32
  %"shf_result.11" = trunc i64 %"shf_hi.9" to i32
  %".757" = zext i32 0 to i64
  %".758" = zext i32 %"viadd.19" to i64
  %".759" = shl i64 %".758", 32
  %"shf_concat.12" = or i64 %".757", %".759"
  %"shf_shift_64.12" = zext i32 31 to i64
  %".760" = ashr i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_hi.10" = lshr i64 %".760", 32
  %"shf_result.12" = trunc i64 %"shf_hi.10" to i32
  br label %"BB_14e0"
BB_14e0:
  %"cond_trunc.23" = trunc i32 %"P71_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_1670", label %"BB_14f0"
BB_14f0:
  %"viadd.21" = add i32 %"shf_result.5", %"shf_result.2"
  %".763" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 560
  %".764" = bitcast i8* %".763" to i32*
  %"ldc_const.10" = load i32, i32* %".764"
  %".765" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 584
  %".766" = bitcast i8* %".765" to i64*
  %"ldc_const.11" = load i64, i64* %".766"
  %"UR13:UR12_r0.2" = trunc i64 %"ldc_const.11" to i32
  %"UR13:UR12_r1_shift.2" = lshr i64 %"ldc_const.11", 32
  %"UR13:UR12_r1.2" = trunc i64 %"UR13:UR12_r1_shift.2" to i32
  %"imad_addend_r0_ext.16" = zext i32 %"imad.66" to i64
  %"imad_addend_packed_0.16" = or i64 0, %"imad_addend_r0_ext.16"
  %"imad_addend_r1_ext.16" = zext i32 %"shf_result.8" to i64
  %"imad_addend_r1_shift.16" = shl i64 %"imad_addend_r1_ext.16", 32
  %"imad_addend_packed_1.16" = or i64 %"imad_addend_packed_0.16", %"imad_addend_r1_shift.16"
  %"imad_lhs_64.16" = sext i32 %"viadd.21" to i64
  %"imad_rhs_64.16" = sext i32 %"ldc_const.9" to i64
  %"imad_tmp_64.16" = mul i64 %"imad_lhs_64.16", %"imad_rhs_64.16"
  %"imad.68" = add i64 %"imad_tmp_64.16", %"imad_addend_packed_1.16"
  %"R13:R12_r0.5" = trunc i64 %"imad.68" to i32
  %"R13:R12_r1_shift.5" = lshr i64 %"imad.68", 32
  %"R13:R12_r1.5" = trunc i64 %"R13:R12_r1_shift.5" to i32
  %"viadd.22" = add i32 %"R13:R12_r0.5", %"ldc_const.10"
  %".767" = xor i32 %"viadd.22", -1
  %".768" = xor i32 31, -1
  %".769" = xor i32 0, -1
  %".770" = and i32 %"viadd.22", 31
  %".771" = and i32 %".770", %".769"
  %".772" = and i32 %"viadd.22", 31
  %".773" = and i32 %".772", 0
  %".774" = or i32 %".771", %".773"
  %"iadd3_o1_raw64" = zext i32 %".774" to i64
  %"iadd3_o1_not64" = xor i64 %"iadd3_o1_raw64", -1
  %"iadd3_o1_not64_masked" = and i64 %"iadd3_o1_not64", 4294967295
  %"iadd3_o1_neg64" = add i64 %"iadd3_o1_not64_masked", 1
  %"iadd3_o2_64.16" = zext i32 %"R13:R12_r0.5" to i64
  %"iadd3_o3_64.16" = zext i32 %".752" to i64
  %"iadd3_tmp.16" = add i64 %"iadd3_o1_neg64", %"iadd3_o2_64.16"
  %"iadd3_tmp2.16" = add i64 %"iadd3_tmp.16", %"iadd3_o3_64.16"
  %"iadd3_trunc.16" = trunc i64 %"iadd3_tmp2.16" to i32
  %"iadd3_carry_val.16" = lshr i64 %"iadd3_tmp2.16", 32
  %"carry_ge_1.16" = icmp uge i64 %"iadd3_carry_val.16", 1
  %"P72_to_i32" = zext i1 %"carry_ge_1.16" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val.16", 2
  %"P23_to_i32" = zext i1 %"carry_ge_2" to i32
  %"iadd3_o1_not" = xor i32 %"R13:R12_r0.5", -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.1" = add i32 %"iadd3_o1_neg", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", %"iadd3_trunc.16"
  %"imad_addend_neg" = sub i32 0, %"R13:R12_r0.5"
  %"imad_tmp.52" = mul i32 %"iadd3_trunc.16", 1
  %"imad.69" = add i32 %"imad_tmp.52", %"imad_addend_neg"
  %"iadd3_o1_not.1" = xor i32 %"R13:R12_r0.5", -1
  %"iadd3_o1_neg.1" = add i32 %"iadd3_o1_not.1", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg.1", 64
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", %"iadd3_trunc.16"
  %"iadd3_n1.3" = add i32 %"R13:R12_r1.5", -1
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P72_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2.3", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_trunc" = trunc i32 %"P23_to_i32" to i1
  %"iadd3_cin2_narrow_zext" = zext i1 %"iadd3_cin2_trunc" to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  %"imad_tmp.53" = mul i32 %"shf_result.5", 65
  %"imad.70" = add i32 %"imad_tmp.53", %"imad.69"
  %"isetrp_cmp1.22" = icmp uge i32 %"viaddmnmx", %"imad.69"
  %"isetrp_src_to_i32.22" = zext i1 1 to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P74_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"isetrp_cmp1.23" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.1"
  %"isetrp_src_to_i32.23" = zext i1 1 to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"isetrp_cmp1.24" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.2"
  %"isetrp_src_to_i32.24" = zext i1 1 to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %".775" = zext i32 %"imad.70" to i64
  %".776" = zext i32 %".103" to i64
  %".777" = zext i32 2 to i64
  %".778" = shl i64 %".775", %".777"
  %".779" = and i64 %".778", 4294967295
  %".780" = add i64 %".779", %".776"
  %".781" = trunc i64 %".780" to i32
  %".782" = zext i32 %"iadd3_trunc.16" to i64
  %".783" = zext i32 %"UR13:UR12_r0.2" to i64
  %".784" = zext i32 2 to i64
  %".785" = shl i64 %".782", %".784"
  %".786" = and i64 %".785", 4294967295
  %".787" = add i64 %".786", %".783"
  %".788" = trunc i64 %".787" to i32
  %".789" = lshr i64 %".787", 32
  %".790" = trunc i64 %".789" to i1
  %"P2_to_i32" = zext i1 %".790" to i32
  %".791" = zext i32 %"iadd3_trunc.16" to i64
  %".792" = zext i32 %"iadd3_cin2_add" to i64
  %".793" = shl i64 %".792", 32
  %"lea_funnel.16" = or i64 %".791", %".793"
  %".794" = zext i32 %"UR13:UR12_r1.2" to i64
  %".795" = zext i32 2 to i64
  %".796" = shl i64 %"lea_funnel.16", %".795"
  %".797" = lshr i64 %".796", 32
  %".798" = add i64 %".797", %".794"
  %"lea_cin_trunc.32" = trunc i32 %"P2_to_i32" to i1
  %".799" = zext i1 %"lea_cin_trunc.32" to i64
  %".800" = add i64 %".798", %".799"
  %".801" = trunc i64 %".800" to i32
  br label %"BB_1610"
BB_1610:
  %"cond_trunc.24" = trunc i32 %"P74_to_i32" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80001610", label %"BB_1620"
BB_80001610:
  %".804" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".781"
  %"lds_shared_addr_cast.16" = bitcast i8 addrspace(3)* %".804" to i32 addrspace(3)*
  %"lds.16" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.16"
  br label %"BB_1620"
BB_1620:
  %"phi.22" = phi  i32 [%"lds.16", %"BB_80001610"], [%"iadd3_n2.2", %"BB_1610"]
  %"warp_reconv_mask" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask")
  %"cond_trunc.25" = trunc i32 %"P45_to_i32" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80001620", label %"BB_1630"
BB_80001620:
  %"lds_addr_memaddr_offset_add.14" = add i32 %".781", 128
  %".807" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.14"
  %"lds_shared_addr_cast.17" = bitcast i8 addrspace(3)* %".807" to i32 addrspace(3)*
  %"lds.17" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.17"
  br label %"BB_1630"
BB_1630:
  %"phi.23" = phi  i32 [%"lds.17", %"BB_80001620"], [%"iadd3_n2.1", %"BB_1620"]
  %"cond_trunc.26" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_trunc.26" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_80001630", label %"BB_1640"
BB_80001630:
  %"lds_addr_memaddr_offset_add.15" = add i32 %".781", 256
  %".810" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.15"
  %"lds_shared_addr_cast.18" = bitcast i8 addrspace(3)* %".810" to i32 addrspace(3)*
  %"lds.18" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.18"
  br label %"BB_1640"
BB_1640:
  %"phi.24" = phi  i32 [%"lds.18", %"BB_80001630"], [%"imad.69", %"BB_1630"]
  %"warp_reconv_mask.1" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.1")
  %"cond_trunc.27" = trunc i32 %"P74_to_i32" to i1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_trunc.27" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_80001640", label %"BB_1650"
BB_80001640:
  %"stg_addr_r0_ext" = zext i32 %".788" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %".801" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R293:R260_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %"phi.22", i32 addrspace(1)* %"R293:R260_addr_ptr"
  br label %"BB_1650"
BB_1650:
  %"cond_trunc.28" = trunc i32 %"P45_to_i32" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_80001650", label %"BB_1660"
BB_80001650:
  %"stg_addr_r0_ext.1" = zext i32 %".788" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %".801" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 128
  %"R293:R260_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %"phi.23", i32 addrspace(1)* %"R293:R260_addr_ptr.1"
  br label %"BB_1660"
BB_1660:
  %"cond_trunc.29" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_80001660", label %"BB_1670"
BB_80001660:
  %"stg_addr_r0_ext.2" = zext i32 %".788" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %".801" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 256
  %"R293:R260_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %"phi.24", i32 addrspace(1)* %"R293:R260_addr_ptr.2"
  br label %"BB_1670"
BB_1670:
  %"imad_tmp.54" = mul i32 %"shf_result.11", %"ldc_const.9"
  %"imad.71" = add i32 %"imad_tmp.54", 0
  %"imad_tmp.55" = mul i32 %"shf_result.12", %"ldc_const.9"
  %"imad.72" = add i32 %"imad_tmp.55", 0
  %"imad_tmp.56" = mul i32 %"viadd.18", %"shf_result.10"
  %"imad.73" = add i32 %"imad_tmp.56", %"imad.67"
  br label %"BB_16c0"
BB_16c0:
  %"cond_trunc.30" = trunc i32 %"P44_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_1850", label %"BB_16d0"
BB_16d0:
  %"imad_addend_r0_ext.17" = zext i32 %"imad.66" to i64
  %"imad_addend_packed_0.17" = or i64 0, %"imad_addend_r0_ext.17"
  %"imad_addend_r1_ext.17" = zext i32 %"shf_result.8" to i64
  %"imad_addend_r1_shift.17" = shl i64 %"imad_addend_r1_ext.17", 32
  %"imad_addend_packed_1.17" = or i64 %"imad_addend_packed_0.17", %"imad_addend_r1_shift.17"
  %"imad_lhs_64.17" = zext i32 %"viadd.18" to i64
  %"imad_rhs_64.17" = zext i32 %"ldc_const.9" to i64
  %"imad_tmp_64.17" = mul i64 %"imad_lhs_64.17", %"imad_rhs_64.17"
  %"imad.74" = add i64 %"imad_tmp_64.17", %"imad_addend_packed_1.17"
  %"R13:R12_r0.6" = trunc i64 %"imad.74" to i32
  %"R13:R12_r1_shift.6" = lshr i64 %"imad.74", 32
  %"R13:R12_r1.6" = trunc i64 %"R13:R12_r1_shift.6" to i32
  %".823" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 560
  %".824" = bitcast i8* %".823" to i32*
  %"ldc_const.12" = load i32, i32* %".824"
  %".825" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 584
  %".826" = bitcast i8* %".825" to i64*
  %"ldc_const.13" = load i64, i64* %".826"
  %"UR13:UR12_r0.3" = trunc i64 %"ldc_const.13" to i32
  %"UR13:UR12_r1_shift.3" = lshr i64 %"ldc_const.13", 32
  %"UR13:UR12_r1.3" = trunc i64 %"UR13:UR12_r1_shift.3" to i32
  %"viadd.23" = add i32 %"R13:R12_r0.6", %"ldc_const.12"
  %"imad_tmp.57" = mul i32 %"R13:R12_r1.6", 1
  %"imad.75" = add i32 %"imad_tmp.57", %"imad.73"
  %".827" = xor i32 %"viadd.23", -1
  %".828" = xor i32 31, -1
  %".829" = xor i32 0, -1
  %".830" = and i32 %"viadd.23", 31
  %".831" = and i32 %".830", %".829"
  %".832" = and i32 %"viadd.23", 31
  %".833" = and i32 %".832", 0
  %".834" = or i32 %".831", %".833"
  %"iadd3_o1_raw64.1" = zext i32 %".834" to i64
  %"iadd3_o1_not64.1" = xor i64 %"iadd3_o1_raw64.1", -1
  %"iadd3_o1_not64_masked.1" = and i64 %"iadd3_o1_not64.1", 4294967295
  %"iadd3_o1_neg64.1" = add i64 %"iadd3_o1_not64_masked.1", 1
  %"iadd3_o2_64.17" = zext i32 %"R13:R12_r0.6" to i64
  %"iadd3_o3_64.17" = zext i32 %".752" to i64
  %"iadd3_tmp.17" = add i64 %"iadd3_o1_neg64.1", %"iadd3_o2_64.17"
  %"iadd3_tmp2.17" = add i64 %"iadd3_tmp.17", %"iadd3_o3_64.17"
  %"iadd3_trunc.17" = trunc i64 %"iadd3_tmp2.17" to i32
  %"iadd3_carry_val.17" = lshr i64 %"iadd3_tmp2.17", 32
  %"carry_ge_1.17" = icmp uge i64 %"iadd3_carry_val.17", 1
  %"P48_to_i32" = zext i1 %"carry_ge_1.17" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.17", 2
  %"P4_to_i32" = zext i1 %"carry_ge_2.1" to i32
  %"iadd3_o1_not.2" = xor i32 %"R13:R12_r0.6", -1
  %"iadd3_o1_neg.2" = add i32 %"iadd3_o1_not.2", 1
  %"iadd3_n1.4" = add i32 %"iadd3_o1_neg.2", 32
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", %"iadd3_trunc.17"
  %"imad_addend_neg.1" = sub i32 0, %"R13:R12_r0.6"
  %"imad_tmp.58" = mul i32 %"iadd3_trunc.17", 1
  %"imad.76" = add i32 %"imad_tmp.58", %"imad_addend_neg.1"
  %"iadd3_o1_not.3" = xor i32 %"R13:R12_r0.6", -1
  %"iadd3_o1_neg.3" = add i32 %"iadd3_o1_not.3", 1
  %"iadd3_n1.5" = add i32 %"iadd3_o1_neg.3", 64
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", %"iadd3_trunc.17"
  %"isetrp_cmp1.25" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.4"
  %"isetrp_src_to_i32.25" = zext i1 1 to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P64_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  %"imad_tmp.59" = mul i32 %"viadd.15", 65
  %"imad.77" = add i32 %"imad_tmp.59", %"imad.76"
  %"isetrp_cmp1.26" = icmp uge i32 %"viaddmnmx", %"imad.76"
  %"isetrp_src_to_i32.26" = zext i1 1 to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"isetrp_cmp1.27" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.5"
  %"isetrp_src_to_i32.27" = zext i1 1 to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P47_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %".835" = zext i32 %"imad.77" to i64
  %".836" = zext i32 %".103" to i64
  %".837" = zext i32 2 to i64
  %".838" = shl i64 %".835", %".837"
  %".839" = and i64 %".838", 4294967295
  %".840" = add i64 %".839", %".836"
  %".841" = trunc i64 %".840" to i32
  %"iadd3_n1.6" = add i32 %"imad.75", -1
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_cin1_trunc.1" = trunc i32 %"P48_to_i32" to i1
  %"iadd3_cin1_narrow_zext.1" = zext i1 %"iadd3_cin1_trunc.1" to i32
  %"iadd3_cin1_add.1" = add i32 %"iadd3_n2.6", %"iadd3_cin1_narrow_zext.1"
  %"iadd3_cin2_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"iadd3_cin2_narrow_zext.1" = zext i1 %"iadd3_cin2_trunc.1" to i32
  %"iadd3_cin2_add.1" = add i32 %"iadd3_cin1_add.1", %"iadd3_cin2_narrow_zext.1"
  %".842" = zext i32 %"iadd3_trunc.17" to i64
  %".843" = zext i32 %"UR13:UR12_r0.3" to i64
  %".844" = zext i32 2 to i64
  %".845" = shl i64 %".842", %".844"
  %".846" = and i64 %".845", 4294967295
  %".847" = add i64 %".846", %".843"
  %".848" = trunc i64 %".847" to i32
  %".849" = lshr i64 %".847", 32
  %".850" = trunc i64 %".849" to i1
  %"P58_to_i32" = zext i1 %".850" to i32
  br label %"BB_17e0"
BB_17e0:
  %"cond_trunc.31" = trunc i32 %"P64_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_800017e0", label %"BB_17f0"
BB_800017e0:
  %"lds_addr_memaddr_offset_add.16" = add i32 %".841", 128
  %".853" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.16"
  %"lds_shared_addr_cast.19" = bitcast i8 addrspace(3)* %".853" to i32 addrspace(3)*
  %"lds.19" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.19"
  br label %"BB_17f0"
BB_17f0:
  %"phi.25" = phi  i32 [%"lds.19", %"BB_800017e0"], [%"iadd3_n2.4", %"BB_17e0"]
  %"warp_reconv_mask.2" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.2")
  %".855" = zext i32 %"iadd3_trunc.17" to i64
  %".856" = zext i32 %"iadd3_cin2_add.1" to i64
  %".857" = shl i64 %".856", 32
  %"lea_funnel.17" = or i64 %".855", %".857"
  %".858" = zext i32 %"UR13:UR12_r1.3" to i64
  %".859" = zext i32 2 to i64
  %".860" = shl i64 %"lea_funnel.17", %".859"
  %".861" = lshr i64 %".860", 32
  %".862" = add i64 %".861", %".858"
  %"lea_cin_trunc.33" = trunc i32 %"P58_to_i32" to i1
  %".863" = zext i1 %"lea_cin_trunc.33" to i64
  %".864" = add i64 %".862", %".863"
  %".865" = trunc i64 %".864" to i32
  br label %"BB_1800"
BB_1800:
  %"cond_trunc.32" = trunc i32 %"P56_to_i32" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_80001800", label %"BB_1810"
BB_80001800:
  %".868" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".841"
  %"lds_shared_addr_cast.20" = bitcast i8 addrspace(3)* %".868" to i32 addrspace(3)*
  %"lds.20" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.20"
  br label %"BB_1810"
BB_1810:
  %"phi.26" = phi  i32 [%"lds.20", %"BB_80001800"], [%"iadd3_n2.5", %"BB_1800"]
  %"warp_reconv_mask.3" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.3")
  %"cond_trunc.33" = trunc i32 %"P47_to_i32" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_80001810", label %"BB_1820"
BB_80001810:
  %"lds_addr_memaddr_offset_add.17" = add i32 %".841", 256
  %".871" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.17"
  %"lds_shared_addr_cast.21" = bitcast i8 addrspace(3)* %".871" to i32 addrspace(3)*
  %"lds.21" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.21"
  br label %"BB_1820"
BB_1820:
  %"phi.27" = phi  i32 [%"lds.21", %"BB_80001810"], [%"imad.76", %"BB_1810"]
  %"cond_trunc.34" = trunc i32 %"P64_to_i32" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_80001820", label %"BB_1830"
BB_80001820:
  %"stg_addr_r0_ext.3" = zext i32 %".848" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %".865" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 128
  %"R295:R263_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %"phi.25", i32 addrspace(1)* %"R295:R263_addr_ptr"
  br label %"BB_1830"
BB_1830:
  %"cond_trunc.35" = trunc i32 %"P56_to_i32" to i1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_trunc.35" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  br i1 %"pbra_cond_to_i1.35", label %"BB_80001830", label %"BB_1840"
BB_80001830:
  %"stg_addr_r0_ext.4" = zext i32 %".848" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %".865" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"R295:R263_addr_ptr.1" = inttoptr i64 %"stg_addr_packed_1.4" to i32 addrspace(1)*
  store i32 %"phi.26", i32 addrspace(1)* %"R295:R263_addr_ptr.1"
  br label %"BB_1840"
BB_1840:
  %"cond_trunc.36" = trunc i32 %"P47_to_i32" to i1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_trunc.36" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_80001840", label %"BB_1850"
BB_80001840:
  %"stg_addr_r0_ext.5" = zext i32 %".848" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %".865" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.5", 256
  %"R295:R263_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %"phi.27", i32 addrspace(1)* %"R295:R263_addr_ptr.2"
  br label %"BB_1850"
BB_1850:
  %"phi.28" = phi  i32 [%"shf_result.12", %"BB_16c0"], [%"phi.25", %"BB_80001840"], [%"phi.25", %"BB_1840"]
  %"imad_tmp.60" = mul i32 %"viadd.19", %"shf_result.10"
  %"imad.78" = add i32 %"imad_tmp.60", %"imad.72"
  %"imad_addend_r0_ext.18" = zext i32 %"imad.66" to i64
  %"imad_addend_packed_0.18" = or i64 0, %"imad_addend_r0_ext.18"
  %"imad_addend_r1_ext.18" = zext i32 %"shf_result.8" to i64
  %"imad_addend_r1_shift.18" = shl i64 %"imad_addend_r1_ext.18", 32
  %"imad_addend_packed_1.18" = or i64 %"imad_addend_packed_0.18", %"imad_addend_r1_shift.18"
  %"imad_lhs_64.18" = zext i32 %"viadd.19" to i64
  %"imad_rhs_64.18" = zext i32 %"ldc_const.9" to i64
  %"imad_tmp_64.18" = mul i64 %"imad_lhs_64.18", %"imad_rhs_64.18"
  %"imad.79" = add i64 %"imad_tmp_64.18", %"imad_addend_packed_1.18"
  %"R5:R4_r0.1" = trunc i64 %"imad.79" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.79", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"imad_tmp.61" = mul i32 %"viadd.20", %"shf_result.10"
  %"imad.80" = add i32 %"imad_tmp.61", %"imad.71"
  br label %"BB_18a0"
BB_18a0:
  %"cond_trunc.37" = trunc i32 %"P73_to_i32" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_1a40", label %"BB_18b0"
BB_18b0:
  %"imad_addend_r0_ext.19" = zext i32 %"imad.66" to i64
  %"imad_addend_packed_0.19" = or i64 0, %"imad_addend_r0_ext.19"
  %"imad_addend_r1_ext.19" = zext i32 %"shf_result.8" to i64
  %"imad_addend_r1_shift.19" = shl i64 %"imad_addend_r1_ext.19", 32
  %"imad_addend_packed_1.19" = or i64 %"imad_addend_packed_0.19", %"imad_addend_r1_shift.19"
  %"imad_lhs_64.19" = zext i32 %"viadd.20" to i64
  %"imad_rhs_64.19" = zext i32 %"ldc_const.9" to i64
  %"imad_tmp_64.19" = mul i64 %"imad_lhs_64.19", %"imad_rhs_64.19"
  %"imad.81" = add i64 %"imad_tmp_64.19", %"imad_addend_packed_1.19"
  %"R7:R6_r0" = trunc i64 %"imad.81" to i32
  %"R7:R6_r1_shift" = lshr i64 %"imad.81", 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %".884" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 560
  %".885" = bitcast i8* %".884" to i32*
  %"ldc_const.14" = load i32, i32* %".885"
  %".886" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 584
  %".887" = bitcast i8* %".886" to i64*
  %"ldc_const.15" = load i64, i64* %".887"
  %"UR13:UR12_r0.4" = trunc i64 %"ldc_const.15" to i32
  %"UR13:UR12_r1_shift.4" = lshr i64 %"ldc_const.15", 32
  %"UR13:UR12_r1.4" = trunc i64 %"UR13:UR12_r1_shift.4" to i32
  %"viadd.24" = add i32 %"R7:R6_r0", %"ldc_const.14"
  %"imad_tmp.62" = mul i32 %"R7:R6_r1", 1
  %"imad.82" = add i32 %"imad_tmp.62", %"imad.80"
  %".888" = xor i32 %"viadd.24", -1
  %".889" = xor i32 31, -1
  %".890" = xor i32 0, -1
  %".891" = and i32 %"viadd.24", 31
  %".892" = and i32 %".891", %".890"
  %".893" = and i32 %"viadd.24", 31
  %".894" = and i32 %".893", 0
  %".895" = or i32 %".892", %".894"
  %"iadd3_o1_raw64.2" = zext i32 %".895" to i64
  %"iadd3_o1_not64.2" = xor i64 %"iadd3_o1_raw64.2", -1
  %"iadd3_o1_not64_masked.2" = and i64 %"iadd3_o1_not64.2", 4294967295
  %"iadd3_o1_neg64.2" = add i64 %"iadd3_o1_not64_masked.2", 1
  %"iadd3_o2_64.18" = zext i32 %"R7:R6_r0" to i64
  %"iadd3_o3_64.18" = zext i32 %".752" to i64
  %"iadd3_tmp.18" = add i64 %"iadd3_o1_neg64.2", %"iadd3_o2_64.18"
  %"iadd3_tmp2.18" = add i64 %"iadd3_tmp.18", %"iadd3_o3_64.18"
  %"iadd3_trunc.18" = trunc i64 %"iadd3_tmp2.18" to i32
  %"iadd3_carry_val.18" = lshr i64 %"iadd3_tmp2.18", 32
  %"carry_ge_1.18" = icmp uge i64 %"iadd3_carry_val.18", 1
  %"P76_to_i32" = zext i1 %"carry_ge_1.18" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.18", 2
  %"P78_to_i32" = zext i1 %"carry_ge_2.2" to i32
  %"iadd3_o1_not.4" = xor i32 %"R7:R6_r0", -1
  %"iadd3_o1_neg.4" = add i32 %"iadd3_o1_not.4", 1
  %"iadd3_n1.7" = add i32 %"iadd3_o1_neg.4", 32
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", %"iadd3_trunc.18"
  %"imad_addend_neg.2" = sub i32 0, %"R7:R6_r0"
  %"imad_tmp.63" = mul i32 %"iadd3_trunc.18", 1
  %"imad.83" = add i32 %"imad_tmp.63", %"imad_addend_neg.2"
  %"iadd3_o1_not.5" = xor i32 %"R7:R6_r0", -1
  %"iadd3_o1_neg.5" = add i32 %"iadd3_o1_not.5", 1
  %"iadd3_n1.8" = add i32 %"iadd3_o1_neg.5", 64
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", %"iadd3_trunc.18"
  %"isetrp_cmp1.28" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.7"
  %"isetrp_src_to_i32.28" = zext i1 1 to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P49_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"imad_tmp.64" = mul i32 %"viadd.16", 65
  %"imad.84" = add i32 %"imad_tmp.64", %"imad.83"
  %"isetrp_cmp1.29" = icmp uge i32 %"viaddmnmx", %"imad.83"
  %"isetrp_src_to_i32.29" = zext i1 1 to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = and i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  %"isetrp_cmp1.30" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.8"
  %"isetrp_src_to_i32.30" = zext i1 1 to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = and i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P65_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  %".896" = zext i32 %"imad.84" to i64
  %".897" = zext i32 %".103" to i64
  %".898" = zext i32 2 to i64
  %".899" = shl i64 %".896", %".898"
  %".900" = and i64 %".899", 4294967295
  %".901" = add i64 %".900", %".897"
  %".902" = trunc i64 %".901" to i32
  %"iadd3_n1.9" = add i32 %"imad.82", -1
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"iadd3_cin1_trunc.2" = trunc i32 %"P76_to_i32" to i1
  %"iadd3_cin1_narrow_zext.2" = zext i1 %"iadd3_cin1_trunc.2" to i32
  %"iadd3_cin1_add.2" = add i32 %"iadd3_n2.9", %"iadd3_cin1_narrow_zext.2"
  %"iadd3_cin2_trunc.2" = trunc i32 %"P78_to_i32" to i1
  %"iadd3_cin2_narrow_zext.2" = zext i1 %"iadd3_cin2_trunc.2" to i32
  %"iadd3_cin2_add.2" = add i32 %"iadd3_cin1_add.2", %"iadd3_cin2_narrow_zext.2"
  %".903" = zext i32 %"iadd3_trunc.18" to i64
  %".904" = zext i32 %"UR13:UR12_r0.4" to i64
  %".905" = zext i32 2 to i64
  %".906" = shl i64 %".903", %".905"
  %".907" = and i64 %".906", 4294967295
  %".908" = add i64 %".907", %".904"
  %".909" = trunc i64 %".908" to i32
  %".910" = lshr i64 %".908", 32
  %".911" = trunc i64 %".910" to i1
  %"P77_to_i32" = zext i1 %".911" to i32
  br label %"BB_19c0"
BB_19c0:
  %"cond_trunc.38" = trunc i32 %"P49_to_i32" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_800019c0", label %"BB_19d0"
BB_800019c0:
  %"lds_addr_memaddr_offset_add.18" = add i32 %".902", 128
  %".914" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.18"
  %"lds_shared_addr_cast.22" = bitcast i8 addrspace(3)* %".914" to i32 addrspace(3)*
  %"lds.22" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.22"
  br label %"BB_19d0"
BB_19d0:
  %"phi.29" = phi  i32 [%"lds.22", %"BB_800019c0"], [%"iadd3_n2.7", %"BB_19c0"]
  %"warp_reconv_mask.4" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.4")
  %".916" = zext i32 %"iadd3_trunc.18" to i64
  %".917" = zext i32 %"iadd3_cin2_add.2" to i64
  %".918" = shl i64 %".917", 32
  %"lea_funnel.18" = or i64 %".916", %".918"
  %".919" = zext i32 %"UR13:UR12_r1.4" to i64
  %".920" = zext i32 2 to i64
  %".921" = shl i64 %"lea_funnel.18", %".920"
  %".922" = lshr i64 %".921", 32
  %".923" = add i64 %".922", %".919"
  %"lea_cin_trunc.34" = trunc i32 %"P77_to_i32" to i1
  %".924" = zext i1 %"lea_cin_trunc.34" to i64
  %".925" = add i64 %".923", %".924"
  %".926" = trunc i64 %".925" to i32
  br label %"BB_19e0"
BB_19e0:
  %"cond_trunc.39" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_trunc.39" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_800019e0", label %"BB_19f0"
BB_800019e0:
  %".929" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".902"
  %"lds_shared_addr_cast.23" = bitcast i8 addrspace(3)* %".929" to i32 addrspace(3)*
  %"lds.23" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.23"
  br label %"BB_19f0"
BB_19f0:
  %"phi.30" = phi  i32 [%"lds.23", %"BB_800019e0"], [%"iadd3_n2.8", %"BB_19e0"]
  %"warp_reconv_mask.5" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.5")
  %"cond_trunc.40" = trunc i32 %"P65_to_i32" to i1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_trunc.40" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_800019f0", label %"BB_1a00"
BB_800019f0:
  %"lds_addr_memaddr_offset_add.19" = add i32 %".902", 256
  %".932" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.19"
  %"lds_shared_addr_cast.24" = bitcast i8 addrspace(3)* %".932" to i32 addrspace(3)*
  %"lds.24" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.24"
  br label %"BB_1a00"
BB_1a00:
  %"phi.31" = phi  i32 [%"lds.24", %"BB_800019f0"], [%"imad.83", %"BB_19f0"]
  %"cond_trunc.41" = trunc i32 %"P49_to_i32" to i1
  %"pbra_cond_to_i32.41" = zext i1 %"cond_trunc.41" to i32
  %"pbra_cond_to_i1.41" = icmp ne i32 %"pbra_cond_to_i32.41", 0
  br i1 %"pbra_cond_to_i1.41", label %"BB_80001a00", label %"BB_1a10"
BB_80001a00:
  %"stg_addr_r0_ext.6" = zext i32 %".909" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %".926" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.6", 128
  %"R162:R142_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %"phi.29", i32 addrspace(1)* %"R162:R142_addr_ptr"
  br label %"BB_1a10"
BB_1a10:
  %"cond_trunc.42" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.42" = zext i1 %"cond_trunc.42" to i32
  %"pbra_cond_to_i1.42" = icmp ne i32 %"pbra_cond_to_i32.42", 0
  br i1 %"pbra_cond_to_i1.42", label %"BB_80001a10", label %"BB_1a20"
BB_80001a10:
  %"stg_addr_r0_ext.7" = zext i32 %".909" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %".926" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"R162:R142_addr_ptr.1" = inttoptr i64 %"stg_addr_packed_1.7" to i32 addrspace(1)*
  store i32 %"phi.30", i32 addrspace(1)* %"R162:R142_addr_ptr.1"
  br label %"BB_1a20"
BB_1a20:
  %"cond_trunc.43" = trunc i32 %"P65_to_i32" to i1
  %"pbra_cond_to_i32.43" = zext i1 %"cond_trunc.43" to i32
  %"pbra_cond_to_i1.43" = icmp ne i32 %"pbra_cond_to_i32.43", 0
  br i1 %"pbra_cond_to_i1.43", label %"BB_80001a20", label %"BB_1a40"
BB_80001a20:
  %"stg_addr_r0_ext.8" = zext i32 %".909" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %".926" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.8", 256
  %"R162:R142_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %"phi.31", i32 addrspace(1)* %"R162:R142_addr_ptr.2"
  br label %"BB_1a40"
BB_1a40:
  %"phi.32" = phi  i32 [%"phi.28", %"BB_18a0"], [%"phi.29", %"BB_80001a20"], [%"phi.29", %"BB_1a20"]
  %"cond_trunc.44" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.44" = zext i1 %"cond_trunc.44" to i32
  %"pbra_cond_to_i1.44" = icmp ne i32 %"pbra_cond_to_i32.44", 0
  br i1 %"pbra_cond_to_i1.44", label %"BB_80001a40", label %"BB_1a50"
BB_1a50:
  %".944" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 560
  %".945" = bitcast i8* %".944" to i32*
  %"ldc_const.16" = load i32, i32* %".945"
  %"viadd.25" = add i32 %"R5:R4_r0.1", %"ldc_const.16"
  %".946" = getelementptr inbounds [608 x i8], [608 x i8]* %"param_local", i64 0, i64 584
  %".947" = bitcast i8* %".946" to i64*
  %"ldc_const.17" = load i64, i64* %".947"
  %"UR5:UR4_r0.1" = trunc i64 %"ldc_const.17" to i32
  %"UR5:UR4_r1_shift.1" = lshr i64 %"ldc_const.17", 32
  %"UR5:UR4_r1.1" = trunc i64 %"UR5:UR4_r1_shift.1" to i32
  %".948" = xor i32 %"viadd.25", -1
  %".949" = xor i32 31, -1
  %".950" = xor i32 0, -1
  %".951" = and i32 %"viadd.25", 31
  %".952" = and i32 %".951", %".950"
  %".953" = and i32 %"viadd.25", 31
  %".954" = and i32 %".953", 0
  %".955" = or i32 %".952", %".954"
  %"iadd3_o1_raw64.3" = zext i32 %".955" to i64
  %"iadd3_o1_not64.3" = xor i64 %"iadd3_o1_raw64.3", -1
  %"iadd3_o1_not64_masked.3" = and i64 %"iadd3_o1_not64.3", 4294967295
  %"iadd3_o1_neg64.3" = add i64 %"iadd3_o1_not64_masked.3", 1
  %"iadd3_o2_64.19" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o3_64.19" = zext i32 %".752" to i64
  %"iadd3_tmp.19" = add i64 %"iadd3_o1_neg64.3", %"iadd3_o2_64.19"
  %"iadd3_tmp2.19" = add i64 %"iadd3_tmp.19", %"iadd3_o3_64.19"
  %"iadd3_trunc.19" = trunc i64 %"iadd3_tmp2.19" to i32
  %"iadd3_carry_val.19" = lshr i64 %"iadd3_tmp2.19", 32
  %"carry_ge_1.19" = icmp uge i64 %"iadd3_carry_val.19", 1
  %"P50_to_i32" = zext i1 %"carry_ge_1.19" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.19", 2
  %"P66_to_i32" = zext i1 %"carry_ge_2.3" to i32
  %"imad_tmp.65" = mul i32 %"R5:R4_r1.1", 1
  %"imad.85" = add i32 %"imad_tmp.65", %"imad.78"
  %"iadd3_o1_not.6" = xor i32 %"R5:R4_r0.1", -1
  %"iadd3_o1_neg.6" = add i32 %"iadd3_o1_not.6", 1
  %"iadd3_n1.10" = add i32 %"iadd3_o1_neg.6", 32
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", %"iadd3_trunc.19"
  %"imad_addend_neg.3" = sub i32 0, %"R5:R4_r0.1"
  %"imad_tmp.66" = mul i32 %"iadd3_trunc.19", 1
  %"imad.86" = add i32 %"imad_tmp.66", %"imad_addend_neg.3"
  %"iadd3_n1.11" = add i32 %"imad.85", -1
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"iadd3_cin1_trunc.3" = trunc i32 %"P50_to_i32" to i1
  %"iadd3_cin1_narrow_zext.3" = zext i1 %"iadd3_cin1_trunc.3" to i32
  %"iadd3_cin1_add.3" = add i32 %"iadd3_n2.11", %"iadd3_cin1_narrow_zext.3"
  %"iadd3_cin2_trunc.3" = trunc i32 %"P66_to_i32" to i1
  %"iadd3_cin2_narrow_zext.3" = zext i1 %"iadd3_cin2_trunc.3" to i32
  %"iadd3_cin2_add.3" = add i32 %"iadd3_cin1_add.3", %"iadd3_cin2_narrow_zext.3"
  %"isetrp_cmp1.31" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.10"
  %"isetrp_src_to_i32.31" = zext i1 1 to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  %"imad_tmp.67" = mul i32 %"viadd.17", 65
  %"imad.87" = add i32 %"imad_tmp.67", %"imad.86"
  %"isetrp_cmp1.32" = icmp uge i32 %"viaddmnmx", %"imad.86"
  %"isetrp_src_to_i32.32" = zext i1 1 to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %".956" = zext i32 %"iadd3_trunc.19" to i64
  %".957" = zext i32 %"UR5:UR4_r0.1" to i64
  %".958" = zext i32 2 to i64
  %".959" = shl i64 %".956", %".958"
  %".960" = and i64 %".959", 4294967295
  %".961" = add i64 %".960", %".957"
  %".962" = trunc i64 %".961" to i32
  %".963" = lshr i64 %".961", 32
  %".964" = trunc i64 %".963" to i1
  %"P52_to_i32" = zext i1 %".964" to i32
  %".965" = zext i32 %"imad.87" to i64
  %".966" = zext i32 %".103" to i64
  %".967" = zext i32 2 to i64
  %".968" = shl i64 %".965", %".967"
  %".969" = and i64 %".968", 4294967295
  %".970" = add i64 %".969", %".966"
  %".971" = trunc i64 %".970" to i32
  %"iadd3_o1_not.7" = xor i32 %"R5:R4_r0.1", -1
  %"iadd3_o1_neg.7" = add i32 %"iadd3_o1_not.7", 1
  %"iadd3_n1.12" = add i32 %"iadd3_o1_neg.7", 64
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", %"iadd3_trunc.19"
  %".972" = zext i32 %"iadd3_trunc.19" to i64
  %".973" = zext i32 %"iadd3_cin2_add.3" to i64
  %".974" = shl i64 %".973", 32
  %"lea_funnel.19" = or i64 %".972", %".974"
  %".975" = zext i32 %"UR5:UR4_r1.1" to i64
  %".976" = zext i32 2 to i64
  %".977" = shl i64 %"lea_funnel.19", %".976"
  %".978" = lshr i64 %".977", 32
  %".979" = add i64 %".978", %".975"
  %"lea_cin_trunc.35" = trunc i32 %"P52_to_i32" to i1
  %".980" = zext i1 %"lea_cin_trunc.35" to i64
  %".981" = add i64 %".979", %".980"
  %".982" = trunc i64 %".981" to i32
  %"isetrp_cmp1.33" = icmp uge i32 %"viaddmnmx", %"iadd3_n2.12"
  %"isetrp_src_to_i32.33" = zext i1 1 to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P53_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  br label %"BB_1b60"
BB_1b60:
  %"cond_trunc.45" = trunc i32 %"P30_to_i32" to i1
  %"pbra_cond_to_i32.45" = zext i1 %"cond_trunc.45" to i32
  %"pbra_cond_to_i1.45" = icmp ne i32 %"pbra_cond_to_i32.45", 0
  br i1 %"pbra_cond_to_i1.45", label %"BB_80001b60", label %"BB_1b70"
BB_80001b60:
  %"lds_addr_memaddr_offset_add.20" = add i32 %".971", 128
  %".985" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.20"
  %"lds_shared_addr_cast.25" = bitcast i8 addrspace(3)* %".985" to i32 addrspace(3)*
  %"lds.25" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.25"
  br label %"BB_1b70"
BB_1b70:
  %"phi.33" = phi  i32 [%"lds.25", %"BB_80001b60"], [%"phi.32", %"BB_1b60"]
  %"warp_reconv_mask.6" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask.6")
  %"cond_trunc.46" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.46" = zext i1 %"cond_trunc.46" to i32
  %"pbra_cond_to_i1.46" = icmp ne i32 %"pbra_cond_to_i32.46", 0
  br i1 %"pbra_cond_to_i1.46", label %"BB_80001b70", label %"BB_1b80"
BB_80001b70:
  %".988" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %".971"
  %"lds_shared_addr_cast.26" = bitcast i8 addrspace(3)* %".988" to i32 addrspace(3)*
  %"lds.26" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.26"
  br label %"BB_1b80"
BB_1b80:
  %"phi.34" = phi  i32 [%"lds.26", %"BB_80001b70"], [%"iadd3_n2.10", %"BB_1b70"]
  %"cond_trunc.47" = trunc i32 %"P30_to_i32" to i1
  %"pbra_cond_to_i32.47" = zext i1 %"cond_trunc.47" to i32
  %"pbra_cond_to_i1.47" = icmp ne i32 %"pbra_cond_to_i32.47", 0
  br i1 %"pbra_cond_to_i1.47", label %"BB_80001b80", label %"BB_1b90"
BB_80001b80:
  %"stg_addr_r0_ext.9" = zext i32 %".962" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %".982" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.9", 128
  %"R164:R143_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %"phi.33", i32 addrspace(1)* %"R164:R143_addr_ptr"
  br label %"BB_1b90"
BB_1b90:
  %"cond_trunc.48" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.48" = zext i1 %"cond_trunc.48" to i32
  %"pbra_cond_to_i1.48" = icmp ne i32 %"pbra_cond_to_i32.48", 0
  br i1 %"pbra_cond_to_i1.48", label %"BB_80001b90", label %"BB_1ba0"
BB_80001b90:
  %"stg_addr_r0_ext.10" = zext i32 %".962" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %".982" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"R164:R143_addr_ptr.1" = inttoptr i64 %"stg_addr_packed_1.10" to i32 addrspace(1)*
  store i32 %"phi.34", i32 addrspace(1)* %"R164:R143_addr_ptr.1"
  br label %"BB_1ba0"
BB_1ba0:
  %"cond_trunc.49" = trunc i32 %"P53_to_i32" to i1
  %"cond_not.16" = xor i1 %"cond_trunc.49", -1
  %"pbra_cond_to_i32.49" = zext i1 %"cond_not.16" to i32
  %"pbra_cond_to_i1.49" = icmp ne i32 %"pbra_cond_to_i32.49", 0
  br i1 %"pbra_cond_to_i1.49", label %"BB_80001ba0", label %"BB_1bb0"
BB_1bb0:
  %"lds_addr_memaddr_offset_add.21" = add i32 %".971", 256
  %".997" = getelementptr inbounds [32768 x i8], [32768 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_addr_memaddr_offset_add.21"
  %"lds_shared_addr_cast.27" = bitcast i8 addrspace(3)* %".997" to i32 addrspace(3)*
  %"lds.27" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.27"
  %"stg_addr_r0_ext.11" = zext i32 %".962" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %".982" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.11", 256
  %"R164:R143_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %"lds.27", i32 addrspace(1)* %"R164:R143_addr_ptr.2"
  ret void
BB_80001ba0:
  ret void
BB_80001a40:
  ret void
}

@"const_mem" = global [5 x [616 x i8]] [[616 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [616 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [616 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [616 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [616 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare void @"llvm.nvvm.barrier0"()

declare float @"llvm.fma.f32"(float %".1", float %".2", float %".3")

declare i32 @"llvm.nvvm.activemask"()

declare void @"llvm.nvvm.bar.warp.sync"(i32 %".1")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void ([36 x i8], i64, i64, i64, i64, i64)* @"_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_", !"kernel", i32 1 }
!2 = !{ void ([36 x i8], i64, i64, i64, i64, i64)* @"_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_", !"maxntidx", i32 256 }
!3 = !{ void ([36 x i8], i64, i64, i64, i64, i64)* @"_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_", !"maxntidy", i32 1 }
!4 = !{ void ([36 x i8], i64, i64, i64, i64, i64)* @"_Z11geam_kernelIifLb0ELb0ELb0ELb0ELi6ELi5ELi3ELb1EEv16cublasGeamParamsIT_T0_EPKS2_S5_PS2_S5_S5_", !"maxntidz", i32 1 }
