; ModuleID = "/tmp/culifter-sm52-10787/round14/nn"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [32768 x i8], align 16
define void @"_Z6euclidP7latLongPfiff"(i64 %"arg_320", i64 %"arg_328", i32 %"arg_336", i32 %"arg_340", i32 %"arg_344")
{
EntryBB_0008:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [352 x i8], align 16
  %".7" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 320
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_320", i64* %".8", align 64
  %".10" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 328
  %".11" = bitcast i8* %".10" to i64*
  store i64 %"arg_328", i64* %".11", align 8
  %".13" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 336
  %".14" = bitcast i8* %".13" to i32*
  store i32 %"arg_336", i32* %".14", align 16
  %".16" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 340
  %".17" = bitcast i8* %".16" to i32*
  store i32 %"arg_340", i32* %".17", align 4
  %".19" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 344
  %".20" = bitcast i8* %".19" to i32*
  store i32 %"arg_344", i32* %".20", align 8
  %"ctaid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()
  %"ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"nctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.nctaid.x"()
  %".22" = trunc i32 %"ctaid_y" to i16
  %".23" = zext i16 %".22" to i32
  %".24" = lshr i32 %"nctaid_x", 16
  %".25" = trunc i32 %".24" to i16
  %".26" = zext i16 %".25" to i32
  %"xmad_product" = mul i32 %".23", %".26"
  %"xmad_sum" = add i32 %"xmad_product", 0
  %".27" = and i32 %"xmad_sum", 65535
  %".28" = shl i32 %"nctaid_x", 16
  %"xmad_merge" = or i32 %".27", %".28"
  %".29" = trunc i32 %"ctaid_y" to i16
  %".30" = zext i16 %".29" to i32
  %".31" = trunc i32 %"nctaid_x" to i16
  %".32" = zext i16 %".31" to i32
  %"xmad_product.1" = mul i32 %".30", %".32"
  %"xmad_sum.1" = add i32 %"xmad_product.1", %"ctaid_x"
  %".33" = lshr i32 %"ctaid_y", 16
  %".34" = trunc i32 %".33" to i16
  %".35" = zext i16 %".34" to i32
  %".36" = lshr i32 %"xmad_merge", 16
  %".37" = trunc i32 %".36" to i16
  %".38" = zext i16 %".37" to i32
  %"xmad_product.2" = mul i32 %".35", %".38"
  %"xmad_psl" = shl i32 %"xmad_product.2", 16
  %".39" = shl i32 %"xmad_merge", 16
  %"xmad_cbcc" = add i32 %"xmad_sum.1", %".39"
  %"xmad_sum.2" = add i32 %"xmad_psl", %"xmad_cbcc"
  %"ntid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ntid.x"()
  %".40" = trunc i32 %"xmad_sum.2" to i16
  %".41" = zext i16 %".40" to i32
  %".42" = trunc i32 %"ntid_x" to i16
  %".43" = zext i16 %".42" to i32
  %"xmad_product.3" = mul i32 %".41", %".43"
  %"xmad_sum.3" = add i32 %"xmad_product.3", %"tid_x"
  %".44" = trunc i32 %"xmad_sum.2" to i16
  %".45" = zext i16 %".44" to i32
  %".46" = lshr i32 %"ntid_x", 16
  %".47" = trunc i32 %".46" to i16
  %".48" = zext i16 %".47" to i32
  %"xmad_product.4" = mul i32 %".45", %".48"
  %"xmad_sum.4" = add i32 %"xmad_product.4", 0
  %".49" = and i32 %"xmad_sum.4", 65535
  %".50" = shl i32 %"ntid_x", 16
  %"xmad_merge.1" = or i32 %".49", %".50"
  %".51" = lshr i32 %"xmad_sum.2", 16
  %".52" = trunc i32 %".51" to i16
  %".53" = zext i16 %".52" to i32
  %".54" = lshr i32 %"xmad_merge.1", 16
  %".55" = trunc i32 %".54" to i16
  %".56" = zext i16 %".55" to i32
  %"xmad_product.5" = mul i32 %".53", %".56"
  %"xmad_psl.1" = shl i32 %"xmad_product.5", 16
  %".57" = shl i32 %"xmad_merge.1", 16
  %"xmad_cbcc.1" = add i32 %"xmad_sum.3", %".57"
  %"xmad_sum.5" = add i32 %"xmad_psl.1", %"xmad_cbcc.1"
  %".58" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 336
  %".59" = bitcast i8* %".58" to i32*
  %"isetrp_rhs" = load i32, i32* %".59"
  %"isetrp_cmp1" = icmp sge i32 %"xmad_sum.5", %"isetrp_rhs"
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0078"
BB_0078:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000078", label %"BB_0088"
BB_0088:
  %"shr_overflow" = icmp ugt i32 29, 31
  %"shr_clamp" = select  i1 %"shr_overflow", i32 31, i32 29
  %"shr_result" = ashr i32 %"xmad_sum.5", %"shr_clamp"
  %"legacy_a_shift" = shl i32 %"xmad_sum.5", 3
  %"legacy_a_wide" = zext i32 %"legacy_a_shift" to i64
  %".62" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 320
  %".63" = bitcast i8* %".62" to i32*
  %"legacy_b" = load i32, i32* %".63"
  %"legacy_b_wide" = zext i32 %"legacy_b" to i64
  %"legacy_sum" = add i64 %"legacy_a_wide", %"legacy_b_wide"
  %"legacy_result" = trunc i64 %"legacy_sum" to i32
  %".64" = lshr i64 %"legacy_sum", 32
  %"legacy_cout" = trunc i64 %".64" to i1
  %"P7_to_i32" = zext i1 %"legacy_cout" to i32
  %"legacy_a_wide.1" = zext i32 %"shr_result" to i64
  %".65" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 324
  %".66" = bitcast i8* %".65" to i32*
  %"legacy_b.1" = load i32, i32* %".66"
  %"legacy_b_wide.1" = zext i32 %"legacy_b.1" to i64
  %"legacy_sum.1" = add i64 %"legacy_a_wide.1", %"legacy_b_wide.1"
  %"legacy_cin_trunc" = trunc i32 %"P7_to_i32" to i1
  %".67" = zext i1 %"legacy_cin_trunc" to i64
  %"legacy_sum_cin" = add i64 %"legacy_sum.1", %".67"
  %"legacy_result.1" = trunc i64 %"legacy_sum_cin" to i32
  %"ldg_addr_r0_ext" = zext i32 %"legacy_result" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"legacy_result.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 4
  %"R13:R7_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to float addrspace(1)*
  %"ldg" = load float, float addrspace(1)* %"R13:R7_addr_ptr"
  %"ldg_addr_r0_ext.1" = zext i32 %"legacy_result" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"legacy_result.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R13:R7_addr_ptr.1" = inttoptr i64 %"ldg_addr_packed_1.1" to float addrspace(1)*
  %"ldg.1" = load float, float addrspace(1)* %"R13:R7_addr_ptr.1"
  %"fadd_lhs_fneg" = fneg float %"ldg"
  %".68" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 344
  %".69" = bitcast i8* %".68" to float*
  %"fadd_rhs" = load float, float* %".69"
  %"fadd" = fadd float %"fadd_lhs_fneg", %"fadd_rhs"
  %"fadd_lhs_fneg.1" = fneg float %"ldg.1"
  %".70" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 340
  %".71" = bitcast i8* %".70" to float*
  %"fadd_rhs.1" = load float, float* %".71"
  %"fadd.1" = fadd float %"fadd_lhs_fneg.1", %"fadd_rhs.1"
  %"fmul" = fmul float %"fadd", %"fadd"
  %"ffma" = call float @"llvm.fma.f32"(float %"fadd.1", float %"fadd.1", float %"fmul")
  %"shr_overflow.1" = icmp ugt i32 30, 31
  %"shr_clamp.1" = select  i1 %"shr_overflow.1", i32 31, i32 30
  %"shr_result.1" = ashr i32 %"xmad_sum.5", %"shr_clamp.1"
  %"mufu_rsq" = call float @"llvm.nvvm.rsqrt.approx.ftz.f"(float %"ffma")
  %"legacy_a_bitcast" = bitcast float %"ffma" to i32
  %"legacy_a_wide.2" = zext i32 %"legacy_a_bitcast" to i64
  %"legacy_b_wide.2" = zext i32 -218103808 to i64
  %"legacy_sum.2" = add i64 %"legacy_a_wide.2", %"legacy_b_wide.2"
  %"legacy_result.2" = trunc i64 %"legacy_sum.2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"legacy_result.2", 1920991231
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"legacy_a_shift.1" = shl i32 %"xmad_sum.5", 2
  %"legacy_a_wide.3" = zext i32 %"legacy_a_shift.1" to i64
  %".72" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 328
  %".73" = bitcast i8* %".72" to i32*
  %"legacy_b.2" = load i32, i32* %".73"
  %"legacy_b_wide.3" = zext i32 %"legacy_b.2" to i64
  %"legacy_sum.3" = add i64 %"legacy_a_wide.3", %"legacy_b_wide.3"
  %"legacy_result.3" = trunc i64 %"legacy_sum.3" to i32
  %".74" = lshr i64 %"legacy_sum.3", 32
  %"legacy_cout.1" = trunc i64 %".74" to i1
  %"P8_to_i32" = zext i1 %"legacy_cout.1" to i32
  %"legacy_a_wide.4" = zext i32 %"shr_result.1" to i64
  %".75" = getelementptr inbounds [352 x i8], [352 x i8]* %"param_local", i64 0, i64 332
  %".76" = bitcast i8* %".75" to i32*
  %"legacy_b.3" = load i32, i32* %".76"
  %"legacy_b_wide.4" = zext i32 %"legacy_b.3" to i64
  %"legacy_sum.4" = add i64 %"legacy_a_wide.4", %"legacy_b_wide.4"
  %"legacy_cin_trunc.1" = trunc i32 %"P8_to_i32" to i1
  %".77" = zext i1 %"legacy_cin_trunc.1" to i64
  %"legacy_sum_cin.1" = add i64 %"legacy_sum.4", %".77"
  %"legacy_result.4" = trunc i64 %"legacy_sum_cin.1" to i32
  br label %"BB_0130"
BB_0130:
  %"cond_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0150", label %"BB_0138_0198"
BB_0138_0198:
  %"legacy_source_bitcast" = bitcast float %"ffma" to i32
  %".80" = and i32 %"legacy_source_bitcast", 2147483647
  %".81" = icmp ne i32 %".80", 0
  %"P3_to_i32" = zext i1 %".81" to i32
  br label %"BB_0138_01a8"
BB_0138_01a8:
  %"cond_trunc.2" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0188", label %"BB_0138_01b8"
BB_0138_01b8:
  %".84" = bitcast float %"ffma" to i32
  %".85" = and i32 %".84", 2139095040
  %".86" = icmp eq i32 %".85", 0
  %".87" = and i32 %".84", 2147483648
  %".88" = select  i1 %".86", i32 %".87", i32 %".84"
  %".89" = bitcast i32 %".88" to float
  %".90" = bitcast float              0x0 to i32
  %".91" = and i32 %".90", 2139095040
  %".92" = icmp eq i32 %".91", 0
  %".93" = and i32 %".90", 2147483648
  %".94" = select  i1 %".92", i32 %".93", i32 %".90"
  %".95" = bitcast i32 %".94" to float
  %".96" = fcmp uge float %".89", %".95"
  %".97" = and i1 %".96", 1
  %".98" = xor i1 %".96", -1
  %".99" = and i1 %".98", 1
  %"P4_to_i32" = zext i1 %".97" to i32
  br label %"BB_0138_01c8"
BB_0138_01c8:
  %"cond_trunc.3" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_0138_800001c8", label %"BB_0138_01d8"
BB_0138_01d8:
  %".102" = bitcast float %"ffma" to i32
  %".103" = and i32 %".102", 2147483647
  %".104" = and i32 %".103", 2139095040
  %".105" = icmp eq i32 %".104", 0
  %".106" = and i32 %".103", 2147483648
  %".107" = select  i1 %".105", i32 %".106", i32 %".103"
  %".108" = bitcast i32 %".107" to float
  %".109" = bitcast float 0x7ff0000000000000 to i32
  %".110" = and i32 %".109", 2139095040
  %".111" = icmp eq i32 %".110", 0
  %".112" = and i32 %".109", 2147483648
  %".113" = select  i1 %".111", i32 %".112", i32 %".109"
  %".114" = bitcast i32 %".113" to float
  %".115" = fcmp ugt float %".108", %".114"
  %".116" = and i1 %".115", 1
  %".117" = xor i1 %".115", -1
  %".118" = and i1 %".117", 1
  %"P5_to_i32" = zext i1 %".116" to i32
  br label %"BB_0138_01e8"
BB_0138_01e8:
  %"cond_trunc.4" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0138_800001e8", label %"BB_0138_01f8"
BB_0138_01f8:
  %".121" = bitcast float %"ffma" to i32
  %".122" = and i32 %".121", 2147483647
  %".123" = and i32 %".122", 2139095040
  %".124" = icmp eq i32 %".123", 0
  %".125" = and i32 %".122", 2147483648
  %".126" = select  i1 %".124", i32 %".125", i32 %".122"
  %".127" = bitcast i32 %".126" to float
  %".128" = bitcast float 0x7ff0000000000000 to i32
  %".129" = and i32 %".128", 2139095040
  %".130" = icmp eq i32 %".129", 0
  %".131" = and i32 %".128", 2147483648
  %".132" = select  i1 %".130", i32 %".131", i32 %".128"
  %".133" = bitcast i32 %".132" to float
  %".134" = fcmp une float %".127", %".133"
  %".135" = and i1 %".134", 1
  %".136" = xor i1 %".134", -1
  %".137" = and i1 %".136", 1
  %"P6_to_i32" = zext i1 %".135" to i32
  br label %"BB_0138_0208"
BB_0138_0208:
  %"cond_trunc.5" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  %"phi_cast_R7_bitcast" = bitcast i32 %"legacy_result" to float
  br i1 %"pbra_cond_to_i1.5", label %"BB_0138_80000208", label %"BB_0138_0210"
BB_0138_80000208:
  %"ffma.1" = call float @"llvm.fma.f32"(float %"ffma", float 0x43f0000000000000, float              0x0)
  br label %"BB_0138_0210"
BB_0138_0210:
  %"phi" = phi  float [%"ffma.1", %"BB_0138_80000208"], [%"phi_cast_R7_bitcast", %"BB_0138_0208"]
  %"cond_trunc.6" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  %"phi_cast_R30_bitcast" = bitcast i32 %"xmad_sum.5" to float
  br i1 %"pbra_cond_to_i1.6", label %"BB_0138_80000210", label %"BB_0138_0218"
BB_0138_80000210:
  br label %"BB_0138_0218"
BB_0138_0218:
  %"phi.1" = phi  float [%"ffma", %"BB_0138_80000210"], [%"phi_cast_R30_bitcast", %"BB_0138_0210"]
  %"cond_trunc.7" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0138_80000218", label %"BB_0188"
BB_0138_80000218:
  %"mufu_rsq.1" = call float @"llvm.nvvm.rsqrt.approx.ftz.f"(float %"phi")
  %"fmul.1" = fmul float %"phi", %"mufu_rsq.1"
  %"fmul.2" = fmul float %"mufu_rsq.1", 0x3fe0000000000000
  %"fadd_lhs_fneg.2" = fneg float %"fmul.1"
  %"fadd.2" = fadd float %"fadd_lhs_fneg.2",              0x0
  %"ffma.2" = call float @"llvm.fma.f32"(float %"fmul.1", float %"fadd.2", float %"phi")
  %"ffma.3" = call float @"llvm.fma.f32"(float %"ffma.2", float %"fmul.2", float %"fmul.1")
  %"fmul.3" = fmul float %"ffma.3", 0x3df0000000000000
  br label %"BB_0188"
BB_0138_800001e8:
  %"fadd.3" = fadd float %"ffma", 0x3ff0000000000000
  br label %"BB_0188"
BB_0138_800001c8:
  %"phi_cast_R15_bitcast" = bitcast i32 2147483647 to float
  br label %"BB_0188"
BB_0150:
  %"fmul.4" = fmul float %"ffma", %"mufu_rsq"
  %"fmul.5" = fmul float %"mufu_rsq", 0x3fe0000000000000
  %"ffma_rhs_fneg" = fneg float %"fmul.4"
  %"ffma.4" = call float @"llvm.fma.f32"(float %"fmul.4", float %"ffma_rhs_fneg", float %"ffma")
  %"ffma.5" = call float @"llvm.fma.f32"(float %"ffma.4", float %"fmul.5", float %"fmul.4")
  br label %"BB_0188"
BB_0188:
  %"phi.2" = phi  float [%"fmul.3", %"BB_0138_80000218"], [%"phi.1", %"BB_0138_0218"], [%"ffma", %"BB_0138_01a8"], [%"phi_cast_R15_bitcast", %"BB_0138_800001c8"], [%"fadd.3", %"BB_0138_800001e8"], [%"ffma.5", %"BB_0150"]
  %"stg_addr_r0_ext" = zext i32 %"legacy_result.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"legacy_result.4" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R6:R39_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to float addrspace(1)*
  store float %"phi.2", float addrspace(1)* %"R6:R39_addr_ptr"
  ret void
BB_80000078:
  ret void
}

@"const_mem" = internal global [5 x [348 x i8]] [[348 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [348 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [348 x i8] [i8 255, i8 255, i8 127, i8 114, i8 255, i8 255, i8 255, i8 127, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [348 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [348 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.nctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ntid.x"()

declare float @"llvm.fma.f32"(float %".1", float %".2", float %".3")

declare float @"llvm.nvvm.rsqrt.approx.ftz.f"(float %".1")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64, i32, i32, i32)* @"_Z6euclidP7latLongPfiff", !"kernel", i32 1 }
