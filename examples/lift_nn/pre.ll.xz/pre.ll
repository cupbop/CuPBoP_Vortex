; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/nn.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/nn.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16
@const_mem = internal global [5 x [348 x i8]] [[348 x i8] zeroinitializer, [348 x i8] zeroinitializer, [348 x i8] c"\FF\FF\7Fr\FF\FF\FF\7F\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", [348 x i8] zeroinitializer, [348 x i8] zeroinitializer], align 16

define void @_Z6euclidP7latLongPfiff(i64 %arg_320, i64 %arg_328, i32 %arg_336, i32 %arg_340, i32 %arg_344) {
EntryBB_0008:
  %param_local = alloca [352 x i8], align 16
  %.7 = getelementptr inbounds [352 x i8], ptr %param_local, i64 0, i64 320
  store i64 %arg_320, ptr %.7, align 64
  %.10 = getelementptr inbounds [352 x i8], ptr %param_local, i64 0, i64 328
  store i64 %arg_328, ptr %.10, align 8
  %.13 = getelementptr inbounds [352 x i8], ptr %param_local, i64 0, i64 336
  store i32 %arg_336, ptr %.13, align 16
  %.16 = getelementptr inbounds [352 x i8], ptr %param_local, i64 0, i64 340
  store i32 %arg_340, ptr %.16, align 4
  %.19 = getelementptr inbounds [352 x i8], ptr %param_local, i64 0, i64 344
  store i32 %arg_344, ptr %.19, align 8
  %ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %nctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %.22 = trunc i32 %ctaid_y to i16
  %.23 = zext i16 %.22 to i32
  %.24 = lshr i32 %nctaid_x, 16
  %.25 = trunc i32 %.24 to i16
  %.26 = zext i16 %.25 to i32
  %xmad_product = mul i32 %.23, %.26
  %.27 = and i32 %xmad_product, 65535
  %.28 = shl i32 %nctaid_x, 16
  %xmad_merge = or i32 %.27, %.28
  %.31 = trunc i32 %nctaid_x to i16
  %.32 = zext i16 %.31 to i32
  %xmad_product.1 = mul i32 %.23, %.32
  %xmad_sum.1 = add i32 %xmad_product.1, %ctaid_x
  %.33 = lshr i32 %ctaid_y, 16
  %.34 = trunc i32 %.33 to i16
  %.35 = zext i16 %.34 to i32
  %.36 = lshr i32 %xmad_merge, 16
  %.37 = trunc i32 %.36 to i16
  %.38 = zext i16 %.37 to i32
  %xmad_product.2 = mul i32 %.35, %.38
  %xmad_psl = shl i32 %xmad_product.2, 16
  %.39 = shl i32 %xmad_merge, 16
  %xmad_cbcc = add i32 %xmad_sum.1, %.39
  %xmad_sum.2 = add i32 %xmad_psl, %xmad_cbcc
  %ntid_x = call i32 @llvm.nvvm.read.ptx.sreg.ntid.x()
  %.40 = trunc i32 %xmad_sum.2 to i16
  %.41 = zext i16 %.40 to i32
  %.42 = trunc i32 %ntid_x to i16
  %.43 = zext i16 %.42 to i32
  %xmad_product.3 = mul i32 %.41, %.43
  %xmad_sum.3 = add i32 %xmad_product.3, %tid_x
  %.46 = lshr i32 %ntid_x, 16
  %.47 = trunc i32 %.46 to i16
  %.48 = zext i16 %.47 to i32
  %xmad_product.4 = mul i32 %.41, %.48
  %.49 = and i32 %xmad_product.4, 65535
  %.50 = shl i32 %ntid_x, 16
  %xmad_merge.1 = or i32 %.49, %.50
  %.51 = lshr i32 %xmad_sum.2, 16
  %.52 = trunc i32 %.51 to i16
  %.53 = zext i16 %.52 to i32
  %.54 = lshr i32 %xmad_merge.1, 16
  %.55 = trunc i32 %.54 to i16
  %.56 = zext i16 %.55 to i32
  %xmad_product.5 = mul i32 %.53, %.56
  %xmad_psl.1 = shl i32 %xmad_product.5, 16
  %.57 = shl i32 %xmad_merge.1, 16
  %xmad_cbcc.1 = add i32 %xmad_sum.3, %.57
  %xmad_sum.5 = add i32 %xmad_psl.1, %xmad_cbcc.1
  %isetrp_rhs = load i32, ptr %.13, align 4
  %isetrp_cmp1 = icmp sge i32 %xmad_sum.5, %isetrp_rhs
  br label %BB_0078

BB_0078:                                          ; preds = %EntryBB_0008
  %0 = zext i1 %isetrp_cmp1 to i32
  %1 = icmp ne i32 %0, 0
  br i1 %1, label %BB_80000078, label %BB_0088

BB_0088:                                          ; preds = %BB_0078
  %shr_result = ashr i32 %xmad_sum.5, 29
  %legacy_a_shift = shl i32 %xmad_sum.5, 3
  %legacy_a_wide = zext i32 %legacy_a_shift to i64
  %legacy_b = load i32, ptr %.7, align 4
  %legacy_b_wide = zext i32 %legacy_b to i64
  %legacy_sum = add i64 %legacy_a_wide, %legacy_b_wide
  %legacy_result = trunc i64 %legacy_sum to i32
  %.65 = getelementptr inbounds [352 x i8], ptr %param_local, i64 0, i64 324
  %legacy_b.1 = load i32, ptr %.65, align 4
  %2 = zext i32 %legacy_a_shift to i64
  %3 = zext i32 %legacy_b to i64
  %4 = zext i32 %shr_result to i64
  %5 = shl i64 %4, 32
  %6 = zext i32 %legacy_b.1 to i64
  %7 = shl i64 %6, 32
  %8 = add i64 %2, %3
  %9 = add i64 %8, %5
  %10 = add i64 %9, %7
  %ldg_addr_memaddr_offset_add = add i64 %10, 4
  %"R13:R7_addr_ptr" = inttoptr i64 %ldg_addr_memaddr_offset_add to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R13:R7_addr_ptr", align 4
  %"R13:R7_addr_ptr.1" = inttoptr i64 %10 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R13:R7_addr_ptr.1", align 4
  %fadd_lhs_fneg = fneg float %ldg
  %fadd_rhs = load float, ptr %.19, align 4
  %fadd = fadd float %fadd_lhs_fneg, %fadd_rhs
  %fadd_lhs_fneg.1 = fneg float %ldg.1
  %fadd_rhs.1 = load float, ptr %.16, align 4
  %fadd.1 = fadd float %fadd_lhs_fneg.1, %fadd_rhs.1
  %fmul = fmul float %fadd, %fadd
  %ffma = call float @llvm.fma.f32(float %fadd.1, float %fadd.1, float %fmul)
  %shr_result.1 = ashr i32 %xmad_sum.5, 30
  %mufu_rsq = call float @llvm.nvvm.rsqrt.approx.ftz.f(float %ffma)
  %legacy_a_bitcast = bitcast float %ffma to i32
  %legacy_a_wide.2 = zext i32 %legacy_a_bitcast to i64
  %legacy_sum.2 = add i64 %legacy_a_wide.2, 4076863488
  %legacy_result.2 = trunc i64 %legacy_sum.2 to i32
  %isetrp_cmp1.1 = icmp ugt i32 %legacy_result.2, 1920991231
  %legacy_a_shift.1 = shl i32 %xmad_sum.5, 2
  %legacy_b.2 = load i32, ptr %.10, align 4
  %.75 = getelementptr inbounds [352 x i8], ptr %param_local, i64 0, i64 332
  %legacy_b.3 = load i32, ptr %.75, align 4
  %11 = zext i32 %legacy_a_shift.1 to i64
  %12 = zext i32 %legacy_b.2 to i64
  %13 = zext i32 %shr_result.1 to i64
  %14 = shl i64 %13, 32
  %15 = zext i32 %legacy_b.3 to i64
  %16 = shl i64 %15, 32
  %17 = add i64 %11, %12
  %18 = add i64 %17, %14
  %19 = add i64 %18, %16
  br label %BB_0130

BB_0130:                                          ; preds = %BB_0088
  %cond_not = xor i1 %isetrp_cmp1.1, true
  br i1 %cond_not, label %BB_0150, label %BB_0138_0198

BB_0138_0198:                                     ; preds = %BB_0130
  %.80 = and i32 %legacy_a_bitcast, 2147483647
  %.81 = icmp ne i32 %.80, 0
  br label %BB_0138_01a8

BB_0138_01a8:                                     ; preds = %BB_0138_0198
  %cond_not.1 = xor i1 %.81, true
  br i1 %cond_not.1, label %BB_0188, label %BB_0138_01b8

BB_0138_01b8:                                     ; preds = %BB_0138_01a8
  %.85 = and i32 %legacy_a_bitcast, 2139095040
  %.86 = icmp eq i32 %.85, 0
  %.87 = and i32 %legacy_a_bitcast, -2147483648
  %.88 = select i1 %.86, i32 %.87, i32 %legacy_a_bitcast
  %.89 = bitcast i32 %.88 to float
  %.96 = fcmp uge float %.89, 0.000000e+00
  br label %BB_0138_01c8

BB_0138_01c8:                                     ; preds = %BB_0138_01b8
  %cond_not.2 = xor i1 %.96, true
  br i1 %cond_not.2, label %BB_0138_800001c8, label %BB_0138_01d8

BB_0138_01d8:                                     ; preds = %BB_0138_01c8
  %.104 = and i32 %.80, 2139095040
  %.105 = icmp eq i32 %.104, 0
  %.107 = select i1 %.105, i32 0, i32 %.80
  %.108 = bitcast i32 %.107 to float
  %.115 = fcmp ugt float %.108, 0x7FF0000000000000
  br label %BB_0138_01e8

BB_0138_01e8:                                     ; preds = %BB_0138_01d8
  %20 = zext i1 %.115 to i32
  %21 = icmp ne i32 %20, 0
  br i1 %21, label %BB_0138_800001e8, label %BB_0138_01f8

BB_0138_01f8:                                     ; preds = %BB_0138_01e8
  %.134 = fcmp une float %.108, 0x7FF0000000000000
  br label %BB_0138_0208

BB_0138_0208:                                     ; preds = %BB_0138_01f8
  %phi_cast_R7_bitcast = bitcast i32 %legacy_result to float
  br i1 %.134, label %BB_0138_80000208, label %BB_0138_0210

BB_0138_80000208:                                 ; preds = %BB_0138_0208
  %ffma.1 = call float @llvm.fma.f32(float %ffma, float 0x43F0000000000000, float 0.000000e+00)
  br label %BB_0138_0210

BB_0138_0210:                                     ; preds = %BB_0138_80000208, %BB_0138_0208
  %phi = phi float [ %ffma.1, %BB_0138_80000208 ], [ %phi_cast_R7_bitcast, %BB_0138_0208 ]
  %cond_not.3 = xor i1 %.134, true
  %phi_cast_R30_bitcast = bitcast i32 %xmad_sum.5 to float
  br i1 %cond_not.3, label %BB_0138_80000210, label %BB_0138_0218

BB_0138_80000210:                                 ; preds = %BB_0138_0210
  br label %BB_0138_0218

BB_0138_0218:                                     ; preds = %BB_0138_80000210, %BB_0138_0210
  %phi.1 = phi float [ %ffma, %BB_0138_80000210 ], [ %phi_cast_R30_bitcast, %BB_0138_0210 ]
  br i1 %.134, label %BB_0138_80000218, label %BB_0188

BB_0138_80000218:                                 ; preds = %BB_0138_0218
  %mufu_rsq.1 = call float @llvm.nvvm.rsqrt.approx.ftz.f(float %phi)
  %fmul.1 = fmul float %phi, %mufu_rsq.1
  %fmul.2 = fmul float %mufu_rsq.1, 5.000000e-01
  %fadd_lhs_fneg.2 = fneg float %fmul.1
  %fadd.2 = fadd float %fadd_lhs_fneg.2, 0.000000e+00
  %ffma.2 = call float @llvm.fma.f32(float %fmul.1, float %fadd.2, float %phi)
  %ffma.3 = call float @llvm.fma.f32(float %ffma.2, float %fmul.2, float %fmul.1)
  %fmul.3 = fmul float %ffma.3, 0x3DF0000000000000
  br label %BB_0188

BB_0138_800001e8:                                 ; preds = %BB_0138_01e8
  %fadd.3 = fadd float %ffma, 1.000000e+00
  br label %BB_0188

BB_0138_800001c8:                                 ; preds = %BB_0138_01c8
  br label %BB_0188

BB_0150:                                          ; preds = %BB_0130
  %fmul.4 = fmul float %ffma, %mufu_rsq
  %fmul.5 = fmul float %mufu_rsq, 5.000000e-01
  %ffma_rhs_fneg = fneg float %fmul.4
  %ffma.4 = call float @llvm.fma.f32(float %fmul.4, float %ffma_rhs_fneg, float %ffma)
  %ffma.5 = call float @llvm.fma.f32(float %ffma.4, float %fmul.5, float %fmul.4)
  br label %BB_0188

BB_0188:                                          ; preds = %BB_0150, %BB_0138_800001c8, %BB_0138_800001e8, %BB_0138_80000218, %BB_0138_0218, %BB_0138_01a8
  %phi.2 = phi float [ %fmul.3, %BB_0138_80000218 ], [ %phi.1, %BB_0138_0218 ], [ %ffma, %BB_0138_01a8 ], [ 0x7FFFFFFFE0000000, %BB_0138_800001c8 ], [ %fadd.3, %BB_0138_800001e8 ], [ %ffma.5, %BB_0150 ]
  %"R6:R39_addr_ptr" = inttoptr i64 %19 to ptr addrspace(1)
  store float %phi.2, ptr addrspace(1) %"R6:R39_addr_ptr", align 4
  ret void

BB_80000078:                                      ; preds = %BB_0078
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rsqrt.approx.ftz.f(float) #1

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(none) }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z6euclidP7latLongPfiff, !"kernel", i32 1}
