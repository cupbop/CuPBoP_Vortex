; ModuleID = "tcgen05_cubin"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [6160 x i8], align 16
define void @"_Z11dynamic_mmaILb1EEvjPj"(i32 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i32*
  store i32 %"arg_896", i32* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", 1010580540
  %".22" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".23" = zext i32 1024 to i64
  %".24" = zext i32 24 to i64
  %".25" = shl i64 %".22", %".24"
  %".26" = and i64 %".25", 4294967295
  %".27" = add i64 %".26", %".23"
  %".28" = trunc i64 %".27" to i32
  %".29" = zext i32 %"tid_x.1" to i64
  %".30" = zext i32 %".28" to i64
  %".31" = zext i32 2 to i64
  %".32" = shl i64 %".29", %".31"
  %".33" = and i64 %".32", 4294967295
  %".34" = add i64 %".33", %".30"
  %".35" = trunc i64 %".34" to i32
  br label %"BB_0090"
BB_0090:
  %"phi" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_00d0"]
  %"phi.1" = phi  i32 [%".35", %"EntryBB_0000"], [%"viadd.1", %"BB_00d0"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 896
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".37" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".37" to i32 addrspace(3)*
  store volatile i32 %"imad", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd" = add i32 %"phi", 128
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_00d0"
BB_00d0:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0090", label %"BB_00e0"
BB_00e0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0120"
BB_0120:
  %"cond_trunc.1" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_0130"
BB_0130:
  %"iadd3_n1" = add i32 1024, 4096
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", 1077952576
  %".43" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".44" = zext i32 %"iadd3_n2" to i64
  %".45" = zext i32 24 to i64
  %".46" = shl i64 %".43", %".45"
  %".47" = and i64 %".46", 4294967295
  %".48" = add i64 %".47", %".44"
  %".49" = trunc i64 %".48" to i32
  %".50" = zext i32 %"tid_x.1" to i64
  %".51" = zext i32 %".49" to i64
  %".52" = zext i32 2 to i64
  %".53" = shl i64 %".50", %".52"
  %".54" = and i64 %".53", 4294967295
  %".55" = add i64 %".54", %".51"
  %".56" = trunc i64 %".55" to i32
  br label %"BB_0180"
BB_0180:
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_0130"], [%"viadd.2", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".56", %"BB_0130"], [%"viadd.3", %"BB_01c0"]
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"sts_shared_addr_winoff.1" = and i32 %"phi.3", 16777215
  %".58" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".58" to i32 addrspace(3)*
  store volatile i32 %"imad.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.2" = add i32 %"phi.2", 128
  %"viadd.3" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0180", label %"BB_01d0"
BB_01d0:
  %"phi.4" = phi  i32 [0, %"BB_0120"], [%".49", %"BB_01c0"]
  %"phi.5" = phi  i32 [%"P7_to_i32", %"BB_0120"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P22_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_01f0"
BB_01f0:
  %"cond_trunc.3" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800001f0", label %"BB_0200"
BB_800001f0:
  %"iadd3_n1.1" = add i32 1024, 5128
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_0200"
BB_0200:
  %"phi.6" = phi  i32 [%"iadd3_n2.1", %"BB_800001f0"], [0, %"BB_01f0"]
  br label %"BB_0210"
BB_0210:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0250"
BB_80000210:
  %".67" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".68" = zext i32 %"phi.6" to i64
  %".69" = zext i32 24 to i64
  %".70" = shl i64 %".67", %".69"
  %".71" = and i64 %".70", 4294967295
  %".72" = add i64 %".71", %".68"
  %".73" = trunc i64 %".72" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".74" = zext i32 %"iadd3_n2.2" to i64
  %".75" = zext i32 0 to i64
  %".76" = shl i64 %".75", 32
  %"shf_concat" = or i64 %".74", %".76"
  %"shf_shift_64" = zext i32 11 to i64
  %".77" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".77" to i32
  %".78" = zext i32 %"iadd3_n2.2" to i64
  %".79" = zext i32 0 to i64
  %".80" = shl i64 %".79", 32
  %"shf_concat.1" = or i64 %".78", %".80"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".81" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".81" to i32
  br label %"BB_0250"
BB_0250:
  %"phi.7" = phi  i32 [%".73", %"BB_80000210"], [%"phi.6", %"BB_0210"]
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.4", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P24_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.5" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000280", label %"BB_0290"
BB_80000280:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".86" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".86" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".87" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".87" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.6" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0560", label %"BB_02a0"
BB_02a0:
  %".91" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".92" = zext i32 64 to i64
  %".93" = zext i32 24 to i64
  %".94" = shl i64 %".91", %".93"
  %".95" = and i64 %".94", 4294967295
  %".96" = add i64 %".95", %".92"
  %".97" = trunc i64 %".96" to i32
  %"lds_shared_addr_winoff" = and i32 %".97", 16777215
  %".98" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".98"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0500", label %"BB_030f"
BB_030f:
  %"allocation_slot_winoff" = and i32 6144, 16777215
  %".101" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".102" = ptrtoint i8 addrspace(3)* %".101" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".102", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0320"
BB_0320:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0560", label %"BB_0330"
BB_0330:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 6144, 16777215
  %".106" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".107" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  %".108" = load i32, i32 addrspace(3)* %".107"
  %".109" = lshr i32 %".108", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P25_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".110" = xor i32 %"plop3_a_bit", 1
  %".111" = xor i32 %"plop3_b_bit", 1
  %".112" = xor i32 %"plop3_c_bit", 1
  %".113" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".114" = and i32 %".113", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".114", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.4", %".109"
  br label %"BB_03c0"
BB_03c0:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0460", label %"BB_03d0"
BB_03d0:
  %"tmem_alloc_winoff.1" = and i32 6144, 16777215
  %".117" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".118" = bitcast i8 addrspace(3)* %".117" to i32 addrspace(3)*
  %".119" = load i32, i32 addrspace(3)* %".118"
  %".120" = lshr i32 %".119", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".121" = xor i32 %"plop3_a_bit.1", 1
  %".122" = xor i32 %"plop3_b_bit.1", 1
  %".123" = xor i32 %"plop3_c_bit.1", 1
  %".124" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".125" = and i32 %".124", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".125", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.5", %".120"
  br label %"BB_0450"
BB_0450:
  %"cond_trunc.10" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03d0", label %"BB_0460"
BB_0460:
  %"phi.10" = phi  i32 [%"imad.4", %"BB_03c0"], [%"imad.5", %"BB_0450"]
  %"viadd.4" = add i32 %"phi.10", 16
  %".128" = zext i32 %"imad.3" to i64
  %".129" = zext i32 0 to i64
  %".130" = shl i64 %".129", 32
  %"shf_concat.2" = or i64 %".128", %".130"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".131" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".131" to i32
  %".132" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".133" = zext i32 80 to i64
  %".134" = zext i32 24 to i64
  %".135" = shl i64 %".132", %".134"
  %".136" = and i64 %".135", 4294967295
  %".137" = add i64 %".136", %".133"
  %".138" = trunc i64 %".137" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.6" = add i32 %"imad_tmp.6", 0
  %".139" = zext i32 %"imad.2" to i64
  %".140" = zext i32 0 to i64
  %".141" = shl i64 %".140", 32
  %"shf_concat.3" = or i64 %".139", %".141"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".142" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".142" to i32
  %".143" = xor i32 %"shf_result.3", -1
  %".144" = xor i32 %"shf_result.2", -1
  %".145" = xor i32 0, -1
  %".146" = and i32 %".143", %"shf_result.2"
  %".147" = and i32 %".146", %".145"
  %".148" = and i32 %".143", %"shf_result.2"
  %".149" = and i32 %".148", 0
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %".144"
  %".152" = and i32 %".151", %".145"
  %".153" = or i32 %".150", %".152"
  %".154" = and i32 %"shf_result.3", %".144"
  %".155" = and i32 %".154", 0
  %".156" = or i32 %".153", %".155"
  %".157" = and i32 %"shf_result.3", %"shf_result.2"
  %".158" = and i32 %".157", %".145"
  %".159" = or i32 %".156", %".158"
  %".160" = and i32 %"shf_result.3", %"shf_result.2"
  %".161" = and i32 %".160", 0
  %".162" = or i32 %".159", %".161"
  %"atoms_shared_addr_winoff" = and i32 %".138", 16777215
  %".163" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".163" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".162" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".28", 5120
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".164" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".164" to i32 addrspace(3)*
  store volatile i32 %"imad.6", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560"
BB_0500:
  %"sts_addr_memaddr_offset_add.1" = add i32 %".28", 5120
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".167" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".167" to i32 addrspace(3)*
  store volatile i32 4294967295, i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0530_1230"
BB_0530_1230:
  call void @"llvm.trap"()
  br label %"BB_0560"
BB_0560:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x.1", 65536
  %"imad.7" = add i32 %"imad_tmp.7", 0
  %"hfma2_a" = bitcast i32 0 to <2 x half>
  %"hfma2_a_v2neg" = fneg <2 x half> %"hfma2_a"
  %"hfma2_b" = bitcast i32 0 to <2 x half>
  %"hfma2_c" = bitcast i32 1093664768 to <2 x half>
  %"hfma2_res" = call <2 x half> @"llvm.fma.v2f16"(<2 x half> %"hfma2_a_v2neg", <2 x half> %"hfma2_b", <2 x half> %"hfma2_c")
  %"hfma2" = bitcast <2 x half> %"hfma2_res" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.8", 1093664768
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.9", 1093664768
  %".171" = xor i32 %"imad.7", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.7", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.7", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.10", 1093664768
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.11", 1093664768
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.12", 1093664768
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.13", 1093664768
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.14", 1093664768
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.15", 1093664768
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.16", 1093664768
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.17", 1093664768
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.18", 1093664768
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.19", 1093664768
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.20", 1093664768
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.21", 1093664768
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 5120
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.22", 1093664768
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.23", 1093664768
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.24", 1093664768
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.25", 1093664768
  %"imad_tmp.26" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.26", 1093664768
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.27", 1093664768
  %"imad_tmp.28" = mul i32 0, 0
  %"imad.28" = add i32 %"imad_tmp.28", 1093664768
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.29" = add i32 %"imad_tmp.29", 1093664768
  %"imad_tmp.30" = mul i32 %"lds.1", 1
  %"imad.30" = add i32 %"imad_tmp.30", %".178"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.30", i32 %"imad.8", i32 %"imad.9", i32 %"imad.10", i32 %"imad.11")
  %"sttm_memaddr_offset_add" = add i32 %"imad.30", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"imad.12", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.30", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"imad.16", i32 %"hfma2", i32 %"imad.17", i32 %"imad.18")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.30", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"imad.19", i32 %"imad.20", i32 %"imad.21", i32 %"imad.22")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.30", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"imad.23", i32 %"imad.24", i32 %"imad.25", i32 %"imad.26")
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.30", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 1093664768, i32 %"imad.27", i32 %"imad.28", i32 %"imad.29")
  %"sttm_memaddr_offset_add.5" = add i32 %"imad.30", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.5", i32 %"imad.8", i32 %"imad.9", i32 %"imad.10", i32 %"imad.11")
  %"sttm_memaddr_offset_add.6" = add i32 %"imad.30", 28
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.6", i32 %"imad.12", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15")
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.31", -2122285186
  %"imad_tmp.32" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.32", -2122285186
  %"imad_tmp.33" = mul i32 0, 0
  %"imad.33" = add i32 %"imad_tmp.33", -2122285186
  %"imad_tmp.34" = mul i32 0, 0
  %"imad.34" = add i32 %"imad_tmp.34", -2122285186
  %"imad_tmp.35" = mul i32 0, 0
  %"imad.35" = add i32 %"imad_tmp.35", 2122285185
  %"imad_tmp.36" = mul i32 0, 0
  %"imad.36" = add i32 %"imad_tmp.36", 2122285185
  %"sttm_memaddr_offset_add.7" = add i32 %"imad.30", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.7", i32 %"imad.31", i32 %"imad.32", i32 %"imad.33", i32 %"imad.34")
  %"imad_tmp.37" = mul i32 0, 0
  %"imad.37" = add i32 %"imad_tmp.37", 2122285185
  %"sttm_memaddr_offset_add.8" = add i32 %"imad.30", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.8", i32 %"imad.35", i32 %"imad.36", i32 %"imad.37", i32 2122285185)
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0950"
BB_0950:
  %"cond_trunc.11" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0b40", label %"BB_0960"
BB_0960:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 5120
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".201" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".201" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 4096
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".202" = xor i32 %"plop3_a_bit.2", 1
  %".203" = xor i32 %"plop3_b_bit.2", 1
  %".204" = xor i32 %"plop3_c_bit.2", 1
  %".205" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".206" = and i32 %".205", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".206", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".207" = zext i32 0 to i64
  %".208" = zext i32 %".185" to i64
  %".209" = shl i64 %".208", 32
  %"shf_concat.4" = or i64 %".207", %".209"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".210" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".210", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".211" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".212" = zext i32 %"iadd3_n2.3" to i64
  %".213" = zext i32 24 to i64
  %".214" = shl i64 %".211", %".213"
  %".215" = and i64 %".214", 4294967295
  %".216" = add i64 %".215", %".212"
  %".217" = trunc i64 %".216" to i32
  %".218" = xor i32 %"shf_result.4", -1
  %".219" = xor i32 16376, -1
  %".220" = xor i32 0, -1
  %".221" = and i32 %"shf_result.4", 16376
  %".222" = and i32 %".221", %".220"
  %".223" = and i32 %"shf_result.4", 16376
  %".224" = and i32 %".223", 0
  %".225" = or i32 %".222", %".224"
  %".226" = zext i32 0 to i64
  %".227" = zext i32 %".217" to i64
  %".228" = shl i64 %".227", 32
  %"shf_concat.5" = or i64 %".226", %".228"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".229" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".229", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".230" = xor i32 %".225", -1
  %".231" = xor i32 524288, -1
  %".232" = xor i32 0, -1
  %".233" = and i32 %".230", 524288
  %".234" = and i32 %".233", %".232"
  %".235" = and i32 %".230", 524288
  %".236" = and i32 %".235", 0
  %".237" = or i32 %".234", %".236"
  %".238" = and i32 %".225", %".231"
  %".239" = and i32 %".238", %".232"
  %".240" = or i32 %".237", %".239"
  %".241" = and i32 %".225", %".231"
  %".242" = and i32 %".241", 0
  %".243" = or i32 %".240", %".242"
  %".244" = and i32 %".225", 524288
  %".245" = and i32 %".244", %".232"
  %".246" = or i32 %".243", %".245"
  %".247" = and i32 %".225", 524288
  %".248" = and i32 %".247", 0
  %".249" = or i32 %".246", %".248"
  %".250" = xor i32 %"shf_result.5", -1
  %".251" = xor i32 16376, -1
  %".252" = xor i32 0, -1
  %".253" = and i32 %"shf_result.5", 16376
  %".254" = and i32 %".253", %".252"
  %".255" = and i32 %"shf_result.5", 16376
  %".256" = and i32 %".255", 0
  %".257" = or i32 %".254", %".256"
  %".258" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".259" = bitcast i8* %".258" to i32*
  %"ldc_const" = load i32, i32* %".259"
  %".260" = xor i32 %".257", -1
  %".261" = xor i32 524288, -1
  %".262" = xor i32 0, -1
  %".263" = and i32 %".260", 524288
  %".264" = and i32 %".263", %".262"
  %".265" = and i32 %".260", 524288
  %".266" = and i32 %".265", 0
  %".267" = or i32 %".264", %".266"
  %".268" = and i32 %".257", %".261"
  %".269" = and i32 %".268", %".262"
  %".270" = or i32 %".267", %".269"
  %".271" = and i32 %".257", %".261"
  %".272" = and i32 %".271", 0
  %".273" = or i32 %".270", %".272"
  %".274" = and i32 %".257", 524288
  %".275" = and i32 %".274", %".262"
  %".276" = or i32 %".273", %".275"
  %".277" = and i32 %".257", 524288
  %".278" = and i32 %".277", 0
  %".279" = or i32 %".276", %".278"
  %"iadd3_n1.4" = add i32 %"lds.2", 32
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 36
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0a70"
BB_0a70:
  %"phi.11" = phi  i32 [%"phi.5", %"BB_0960"], [%"P20_to_i32", %"BB_0aa0"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0960"], [%"phi.14", %"BB_0aa0"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000a70", label %"BB_0a80"
BB_80000a70:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0a80"
BB_0a80:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000a70"], [%"phi.11", %"BB_0a70"]
  %"mma_a_r0_ext" = zext i32 %".249" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".283" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".284" = sub i64 %".283", 0
  %".285" = lshr i64 %".284", 4
  %".286" = add i64 %"mma_a_packed_1", %".285"
  %".287" = and i64 %".286", 16383
  %".288" = and i64 %"mma_a_packed_1", -16384
  %".289" = or i64 %".288", %".287"
  %"mma_b_r0_ext" = zext i32 %".279" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".290" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".291" = sub i64 %".290", 0
  %".292" = lshr i64 %".291", 4
  %".293" = add i64 %"mma_b_packed_1", %".292"
  %".294" = and i64 %".293", 16383
  %".295" = and i64 %"mma_b_packed_1", -16384
  %".296" = or i64 %".295", %".294"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred issuer, sp, dn; .reg .b32 mask, mode; activemask.b32 mask; elect.sync _|issuer, mask; and.b32 mode, $3, 4; setp.ne.and.u32 sp, mode, 0, issuer; setp.eq.and.u32 dn, mode, 0, issuer; @sp tcgen05.mma.sp.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, [$5], $3, [$6], [$7], use_d; @dn tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$6], [$7], use_d; } }", "r,l,l,r,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".289", i64 %".296", i32 %"ldc_const", i32 %"mma_arg_zext", i32 0, i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_0a90"
BB_0a90:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000a90", label %"BB_0aa0"
BB_80000a90:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".300" = xor i32 %"plop3_a_bit.3", 1
  %".301" = xor i32 %"plop3_b_bit.3", 1
  %".302" = xor i32 %"plop3_c_bit.3", 1
  %".303" = and i32 %".300", %"plop3_b_bit.3"
  %".304" = and i32 %".303", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".304", 0
  %"P8_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0aa0"
BB_0aa0:
  %"phi.14" = phi  i32 [%"P8_to_i32", %"BB_80000a90"], [%"phi.12", %"BB_0a90"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".306" = xor i32 %"plop3_a_bit.4", 1
  %".307" = xor i32 %"plop3_b_bit.4", 1
  %".308" = xor i32 %"plop3_c_bit.4", 1
  %".309" = and i32 %".306", %"plop3_b_bit.4"
  %".310" = and i32 %".309", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".310", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0a70", label %"BB_0ac0"
BB_0ac0:
  %"iadd3_n1.6" = add i32 1024, 5128
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".312" = xor i32 %"plop3_a_bit.5", 1
  %".313" = xor i32 %"plop3_b_bit.5", 1
  %".314" = xor i32 %"plop3_c_bit.5", 1
  %".315" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".316" = and i32 %".315", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".316", 0
  %"P30_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".317" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".318" = zext i32 %"iadd3_n2.6" to i64
  %".319" = zext i32 24 to i64
  %".320" = shl i64 %".317", %".319"
  %".321" = and i64 %".320", 4294967295
  %".322" = add i64 %".321", %".318"
  %".323" = trunc i64 %".322" to i32
  br label %"BB_0af0"
BB_0af0:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0ac0"], [%"P11_to_i32", %"BB_0b20"]
  %"phi.16" = phi  i32 [%"P30_to_i32", %"BB_0ac0"], [%"phi.18", %"BB_0b20"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000af0", label %"BB_0b00"
BB_80000af0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P9_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0b00"
BB_0b00:
  %"phi.17" = phi  i32 [%"P9_to_i32", %"BB_80000af0"], [%"phi.15", %"BB_0af0"]
  %"utcbar_local_winoff" = and i32 %".323", 16777215
  %".327" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".328" = ptrtoint i8 addrspace(3)* %".327" to i32
  %".329" = lshr i32 %".323", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".328", i32 %".329")
  br label %"BB_0b10"
BB_0b10:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000b10", label %"BB_0b20"
BB_80000b10:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".333" = xor i32 %"plop3_a_bit.6", 1
  %".334" = xor i32 %"plop3_b_bit.6", 1
  %".335" = xor i32 %"plop3_c_bit.6", 1
  %".336" = and i32 %".333", %"plop3_b_bit.6"
  %".337" = and i32 %".336", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".337", 0
  %"P32_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_0b20"
BB_0b20:
  %"phi.18" = phi  i32 [%"P32_to_i32", %"BB_80000b10"], [%"phi.16", %"BB_0b10"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".339" = xor i32 %"plop3_a_bit.7", 1
  %".340" = xor i32 %"plop3_b_bit.7", 1
  %".341" = xor i32 %"plop3_c_bit.7", 1
  %".342" = and i32 %".339", %"plop3_b_bit.7"
  %".343" = and i32 %".342", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".343", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0af0", label %"BB_0b40"
BB_0b40:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 5128
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".345" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".346" = zext i32 %"iadd3_n2.7" to i64
  %".347" = zext i32 24 to i64
  %".348" = shl i64 %".345", %".347"
  %".349" = and i64 %".348", 4294967295
  %".350" = add i64 %".349", %".346"
  %".351" = trunc i64 %".350" to i32
  %"mbar_shared_winoff.1" = and i32 %".351", 16777215
  %".352" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".352" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_11d0", label %"BB_0bb0"
BB_11d0:
  %"mbar_shared_winoff.2" = and i32 %".351", 16777215
  %".355" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".355" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_11e0"
BB_11e0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_11d0", label %"BB_0bb0"
BB_0bb0:
  %".358" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".359" = bitcast i8* %".358" to i64*
  %"ldc_const.1" = load i64, i64* %".359"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.38" = mul i32 %"tid_x.1", 32
  %"imad.38" = add i32 %"imad_tmp.38", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.30")
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.30", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".365" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".366" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".367" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad.38" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.39" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R13:R12_r0.1" = trunc i64 %"imad.39" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.39", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R114:R90_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R114:R90_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R114:R90_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R114:R90_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R114:R90_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R114:R90_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R114:R90_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R114:R90_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R114:R90_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R114:R90_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.30", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".373" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R114:R90_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".365", i32 addrspace(1)* %"R114:R90_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R114:R90_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".366", i32 addrspace(1)* %"R114:R90_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R114:R90_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".367", i32 addrspace(1)* %"R114:R90_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.30", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".380" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".381" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".382" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".383" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R114:R90_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".373", i32 addrspace(1)* %"R114:R90_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R114:R90_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R114:R90_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R114:R90_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R114:R90_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R114:R90_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R114:R90_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R114:R90_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".380", i32 addrspace(1)* %"R114:R90_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.30", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".389" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".390" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".391" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".392" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R114:R90_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".381", i32 addrspace(1)* %"R114:R90_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R114:R90_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".382", i32 addrspace(1)* %"R114:R90_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R114:R90_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".383", i32 addrspace(1)* %"R114:R90_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.30", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".396" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".397" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".398" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".399" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R114:R90_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".389", i32 addrspace(1)* %"R114:R90_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R114:R90_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".390", i32 addrspace(1)* %"R114:R90_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R114:R90_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".391", i32 addrspace(1)* %"R114:R90_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R114:R90_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".392", i32 addrspace(1)* %"R114:R90_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R114:R90_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".396", i32 addrspace(1)* %"R114:R90_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.30", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".405" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".406" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".407" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".408" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R114:R90_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".397", i32 addrspace(1)* %"R114:R90_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R114:R90_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".398", i32 addrspace(1)* %"R114:R90_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R114:R90_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".399", i32 addrspace(1)* %"R114:R90_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.30", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".412" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".413" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".414" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".415" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R114:R90_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".405", i32 addrspace(1)* %"R114:R90_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R114:R90_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".406", i32 addrspace(1)* %"R114:R90_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R114:R90_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".407", i32 addrspace(1)* %"R114:R90_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R114:R90_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".408", i32 addrspace(1)* %"R114:R90_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R114:R90_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".412", i32 addrspace(1)* %"R114:R90_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R114:R90_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".413", i32 addrspace(1)* %"R114:R90_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R114:R90_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".414", i32 addrspace(1)* %"R114:R90_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R114:R90_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".415", i32 addrspace(1)* %"R114:R90_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0f30"
BB_0f30:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000f30", label %"BB_0f40"
BB_0f40:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 5120
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".426" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".426" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.39" = mul i32 0, 0
  %"imad.40" = add i32 %"imad_tmp.39", 3
  %".427" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".428" = zext i32 80 to i64
  %".429" = zext i32 24 to i64
  %".430" = shl i64 %".427", %".429"
  %".431" = and i64 %".430", 4294967295
  %".432" = add i64 %".431", %".428"
  %".433" = trunc i64 %".432" to i32
  %"imad_tmp.40" = mul i32 0, 0
  %"imad.41" = add i32 %"imad_tmp.40", 1
  %"lds_shared_addr_winoff.4" = and i32 %".433", 16777215
  %".434" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".434" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".435" = xor i32 %"lds.3", -1
  %".436" = xor i32 65535, -1
  %".437" = xor i32 0, -1
  %".438" = and i32 %"lds.3", 65535
  %".439" = and i32 %".438", %".437"
  %".440" = and i32 %"lds.3", 65535
  %".441" = and i32 %".440", 0
  %".442" = or i32 %".439", %".441"
  %".443" = zext i32 0 to i64
  %".444" = zext i32 %".442" to i64
  %".445" = shl i64 %".444", 32
  %"shf_concat.6" = or i64 %".443", %".445"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".446" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".446", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".447" = zext i32 %"imad.40" to i64
  %".448" = zext i32 0 to i64
  %".449" = shl i64 %".448", 32
  %"shf_concat.7" = or i64 %".447", %".449"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".450" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".450" to i32
  %".451" = zext i32 %"imad.41" to i64
  %".452" = zext i32 0 to i64
  %".453" = shl i64 %".452", 32
  %"shf_concat.8" = or i64 %".451", %".453"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".454" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".454" to i32
  %".455" = xor i32 %"shf_result.8", -1
  %".456" = xor i32 %"shf_result.7", -1
  %".457" = xor i32 0, -1
  %".458" = and i32 %".455", %"shf_result.7"
  %".459" = and i32 %".458", %".457"
  %".460" = and i32 %".455", %"shf_result.7"
  %".461" = and i32 %".460", 0
  %".462" = or i32 %".459", %".461"
  %".463" = and i32 %"shf_result.8", %".456"
  %".464" = and i32 %".463", %".457"
  %".465" = or i32 %".462", %".464"
  %".466" = and i32 %"shf_result.8", %".456"
  %".467" = and i32 %".466", 0
  %".468" = or i32 %".465", %".467"
  %".469" = and i32 %"shf_result.8", %"shf_result.7"
  %".470" = and i32 %".469", %".457"
  %".471" = or i32 %".468", %".470"
  %".472" = and i32 %"shf_result.8", %"shf_result.7"
  %".473" = and i32 %".472", 0
  %".474" = or i32 %".471", %".473"
  %".475" = xor i32 %".474", -1
  %".476" = xor i32 65535, -1
  %".477" = xor i32 0, -1
  %".478" = and i32 %".474", 65535
  %".479" = and i32 %".478", %".477"
  %".480" = and i32 %".474", 65535
  %".481" = and i32 %".480", 0
  %".482" = or i32 %".479", %".481"
  %".483" = xor i32 %".474", -1
  %".484" = xor i32 65535, -1
  %".485" = xor i32 %"lds.4", -1
  %".486" = and i32 %".474", 65535
  %".487" = and i32 %".486", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".487", %".482"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_1040"
BB_1040:
  %"cond_trunc.19" = trunc i32 %"P35_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_11a0_1260", label %"BB_1050"
BB_1050:
  %".490" = zext i32 0 to i64
  %".491" = zext i32 %"lds.4" to i64
  %".492" = shl i64 %".491", 32
  %"shf_concat.9" = or i64 %".490", %".492"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".493" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".493", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".494" = zext i32 0 to i64
  %".495" = zext i32 %".474" to i64
  %".496" = shl i64 %".495", 32
  %"shf_concat.10" = or i64 %".494", %".496"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".497" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".497", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".498" = xor i32 %"shf_result.9", -1
  %".499" = xor i32 %"shf_result.10", -1
  %".500" = xor i32 0, -1
  %".501" = and i32 %"shf_result.9", %"shf_result.10"
  %".502" = and i32 %".501", %".500"
  %".503" = and i32 %"shf_result.9", %"shf_result.10"
  %".504" = and i32 %".503", 0
  %".505" = or i32 %".502", %".504"
  %"isetrp_cmp1.11" = icmp ne i32 %".505", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_1090"
BB_1090:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_1170_1200", label %"BB_10a0"
BB_10a0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".508" = xor i32 0, -1
  %".509" = xor i32 %".474", -1
  %".510" = xor i32 0, -1
  %".511" = and i32 %".508", %".509"
  %".512" = and i32 %".511", %".510"
  %".513" = and i32 %".508", %".509"
  %".514" = and i32 %".513", 0
  %".515" = or i32 %".512", %".514"
  %".516" = and i32 0, %".509"
  %".517" = and i32 %".516", %".510"
  %".518" = or i32 %".515", %".517"
  %".519" = and i32 0, %".509"
  %".520" = and i32 %".519", 0
  %".521" = or i32 %".518", %".520"
  %"imad_tmp.41" = mul i32 0, 0
  %"imad.42" = add i32 %"imad_tmp.41", %".521"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.42", i32 %"redux_mask")
  %".522" = xor i32 %".521", -1
  %".523" = call i32 @"llvm.cttz.i32"(i32 %".522", i1 0)
  %".524" = shl i32 %".523", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".524") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.42" = mul i32 0, 0
  %"imad.43" = add i32 %"imad_tmp.42", %"redux_sync_and"
  br label %"BB_1140"
BB_1140:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80001140", label %"BB_11b0"
BB_80001140:
  %"atoms_shared_addr_winoff.1" = and i32 %".433", 16777215
  %".528" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".528" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.43" monotonic
  br label %"BB_11b0"
BB_1170_1200:
  call void @"llvm.trap"()
  br label %"BB_11b0"
BB_11a0_1260:
  call void @"llvm.trap"()
  br label %"BB_11b0"
BB_11b0:
  ret void
BB_80000f30:
  ret void
}

define void @"_Z11dynamic_mmaILb0EEvjPj"(i32 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i32*
  store i32 %"arg_896", i32* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", 1065369472
  %".22" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".23" = zext i32 1024 to i64
  %".24" = zext i32 24 to i64
  %".25" = shl i64 %".22", %".24"
  %".26" = and i64 %".25", 4294967295
  %".27" = add i64 %".26", %".23"
  %".28" = trunc i64 %".27" to i32
  %".29" = zext i32 %"tid_x.1" to i64
  %".30" = zext i32 %".28" to i64
  %".31" = zext i32 2 to i64
  %".32" = shl i64 %".29", %".31"
  %".33" = and i64 %".32", 4294967295
  %".34" = add i64 %".33", %".30"
  %".35" = trunc i64 %".34" to i32
  br label %"BB_0090"
BB_0090:
  %"phi" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_00d0"]
  %"phi.1" = phi  i32 [%".35", %"EntryBB_0000"], [%"viadd.1", %"BB_00d0"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 896
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".37" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".37" to i32 addrspace(3)*
  store volatile i32 %"imad", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd" = add i32 %"phi", 128
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_00d0"
BB_00d0:
  %"cond_trunc" = trunc i32 %"P27_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0090", label %"BB_00e0"
BB_00e0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0120"
BB_0120:
  %"cond_trunc.1" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_0130"
BB_0130:
  %"iadd3_n1" = add i32 1024, 4096
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", 1073758208
  %".43" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".44" = zext i32 %"iadd3_n2" to i64
  %".45" = zext i32 24 to i64
  %".46" = shl i64 %".43", %".45"
  %".47" = and i64 %".46", 4294967295
  %".48" = add i64 %".47", %".44"
  %".49" = trunc i64 %".48" to i32
  %".50" = zext i32 %"tid_x.1" to i64
  %".51" = zext i32 %".49" to i64
  %".52" = zext i32 2 to i64
  %".53" = shl i64 %".50", %".52"
  %".54" = and i64 %".53", 4294967295
  %".55" = add i64 %".54", %".51"
  %".56" = trunc i64 %".55" to i32
  br label %"BB_0180"
BB_0180:
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_0130"], [%"viadd.2", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".56", %"BB_0130"], [%"viadd.3", %"BB_01c0"]
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"sts_shared_addr_winoff.1" = and i32 %"phi.3", 16777215
  %".58" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".58" to i32 addrspace(3)*
  store volatile i32 %"imad.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.2" = add i32 %"phi.2", 128
  %"viadd.3" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0180", label %"BB_01d0"
BB_01d0:
  %"phi.4" = phi  i32 [0, %"BB_0120"], [%".49", %"BB_01c0"]
  %"phi.5" = phi  i32 [%"P7_to_i32", %"BB_0120"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P22_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_01f0"
BB_01f0:
  %"cond_trunc.3" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800001f0", label %"BB_0200"
BB_800001f0:
  %"iadd3_n1.1" = add i32 1024, 5128
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_0200"
BB_0200:
  %"phi.6" = phi  i32 [%"iadd3_n2.1", %"BB_800001f0"], [0, %"BB_01f0"]
  br label %"BB_0210"
BB_0210:
  %"cond_trunc.4" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0250"
BB_80000210:
  %".67" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".68" = zext i32 %"phi.6" to i64
  %".69" = zext i32 24 to i64
  %".70" = shl i64 %".67", %".69"
  %".71" = and i64 %".70", 4294967295
  %".72" = add i64 %".71", %".68"
  %".73" = trunc i64 %".72" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".74" = zext i32 %"iadd3_n2.2" to i64
  %".75" = zext i32 0 to i64
  %".76" = shl i64 %".75", 32
  %"shf_concat" = or i64 %".74", %".76"
  %"shf_shift_64" = zext i32 11 to i64
  %".77" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".77" to i32
  %".78" = zext i32 %"iadd3_n2.2" to i64
  %".79" = zext i32 0 to i64
  %".80" = shl i64 %".79", 32
  %"shf_concat.1" = or i64 %".78", %".80"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".81" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".81" to i32
  br label %"BB_0250"
BB_0250:
  %"phi.7" = phi  i32 [%".73", %"BB_80000210"], [%"phi.6", %"BB_0210"]
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.4", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P24_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P39_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.5" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000280", label %"BB_0290"
BB_80000280:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".86" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".86" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".87" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".87" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.6" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0560", label %"BB_02a0"
BB_02a0:
  %".91" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".92" = zext i32 64 to i64
  %".93" = zext i32 24 to i64
  %".94" = shl i64 %".91", %".93"
  %".95" = and i64 %".94", 4294967295
  %".96" = add i64 %".95", %".92"
  %".97" = trunc i64 %".96" to i32
  %"lds_shared_addr_winoff" = and i32 %".97", 16777215
  %".98" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".98"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.7" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0500", label %"BB_030f"
BB_030f:
  %"allocation_slot_winoff" = and i32 6144, 16777215
  %".101" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".102" = ptrtoint i8 addrspace(3)* %".101" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".102", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P4_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0320"
BB_0320:
  %"cond_trunc.8" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0560", label %"BB_0330"
BB_0330:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 6144, 16777215
  %".106" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".107" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  %".108" = load i32, i32 addrspace(3)* %".107"
  %".109" = lshr i32 %".108", 5
  %"P25_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P25_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".110" = xor i32 %"plop3_a_bit", 1
  %".111" = xor i32 %"plop3_b_bit", 1
  %".112" = xor i32 %"plop3_c_bit", 1
  %".113" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".114" = and i32 %".113", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".114", 0
  %"P5_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.4", %".109"
  br label %"BB_03c0"
BB_03c0:
  %"cond_trunc.9" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0460", label %"BB_03d0"
BB_03d0:
  %"tmem_alloc_winoff.1" = and i32 6144, 16777215
  %".117" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".118" = bitcast i8 addrspace(3)* %".117" to i32 addrspace(3)*
  %".119" = load i32, i32 addrspace(3)* %".118"
  %".120" = lshr i32 %".119", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".121" = xor i32 %"plop3_a_bit.1", 1
  %".122" = xor i32 %"plop3_b_bit.1", 1
  %".123" = xor i32 %"plop3_c_bit.1", 1
  %".124" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".125" = and i32 %".124", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".125", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.5", %".120"
  br label %"BB_0450"
BB_0450:
  %"cond_trunc.10" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03d0", label %"BB_0460"
BB_0460:
  %"phi.10" = phi  i32 [%"imad.4", %"BB_03c0"], [%"imad.5", %"BB_0450"]
  %"viadd.4" = add i32 %"phi.10", 16
  %".128" = zext i32 %"imad.3" to i64
  %".129" = zext i32 0 to i64
  %".130" = shl i64 %".129", 32
  %"shf_concat.2" = or i64 %".128", %".130"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".131" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".131" to i32
  %".132" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".133" = zext i32 80 to i64
  %".134" = zext i32 24 to i64
  %".135" = shl i64 %".132", %".134"
  %".136" = and i64 %".135", 4294967295
  %".137" = add i64 %".136", %".133"
  %".138" = trunc i64 %".137" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.6" = add i32 %"imad_tmp.6", 0
  %".139" = zext i32 %"imad.2" to i64
  %".140" = zext i32 0 to i64
  %".141" = shl i64 %".140", 32
  %"shf_concat.3" = or i64 %".139", %".141"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".142" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".142" to i32
  %".143" = xor i32 %"shf_result.3", -1
  %".144" = xor i32 %"shf_result.2", -1
  %".145" = xor i32 0, -1
  %".146" = and i32 %".143", %"shf_result.2"
  %".147" = and i32 %".146", %".145"
  %".148" = and i32 %".143", %"shf_result.2"
  %".149" = and i32 %".148", 0
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %".144"
  %".152" = and i32 %".151", %".145"
  %".153" = or i32 %".150", %".152"
  %".154" = and i32 %"shf_result.3", %".144"
  %".155" = and i32 %".154", 0
  %".156" = or i32 %".153", %".155"
  %".157" = and i32 %"shf_result.3", %"shf_result.2"
  %".158" = and i32 %".157", %".145"
  %".159" = or i32 %".156", %".158"
  %".160" = and i32 %"shf_result.3", %"shf_result.2"
  %".161" = and i32 %".160", 0
  %".162" = or i32 %".159", %".161"
  %"atoms_shared_addr_winoff" = and i32 %".138", 16777215
  %".163" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".163" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".162" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".28", 5120
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".164" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".164" to i32 addrspace(3)*
  store volatile i32 %"imad.6", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560"
BB_0500:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".28", 5120
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".167" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".167" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0530_10f0"
BB_0530_10f0:
  call void @"llvm.trap"()
  br label %"BB_0560"
BB_0560:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.8" = mul i32 %"tid_x.1", 65536
  %"imad.8" = add i32 %"imad_tmp.8", 0
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.9", 1093664768
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.10", 1093664768
  %".171" = xor i32 %"imad.8", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.8", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.8", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.11", 1093664768
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.12", 1093664768
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.13", 1093664768
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.14", 1093664768
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.15", 1093664768
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.16", 1093664768
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.17", 1093664768
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.18", 1093664768
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.19", 1093664768
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.20", 1093664768
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.21", 1093664768
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.22", 1093664768
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 5120
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.23", 1093664768
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.24", 1093664768
  %"imad_tmp.25" = mul i32 %"lds.1", 1
  %"imad.25" = add i32 %"imad_tmp.25", %".178"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.25", i32 %"imad.9", i32 %"imad.10", i32 %"imad.11", i32 %"imad.12")
  %"sttm_memaddr_offset_add" = add i32 %"imad.25", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15", i32 %"imad.16")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.25", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"imad.17", i32 %"imad.18", i32 %"imad.19", i32 %"imad.20")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.25", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"imad.21", i32 %"imad.22", i32 %"imad.23", i32 %"imad.24")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.25", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"imad.9", i32 %"imad.10", i32 %"imad.11", i32 %"imad.12")
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.25", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15", i32 %"imad.16")
  %"sttm_memaddr_offset_add.5" = add i32 %"imad.25", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.5", i32 %"imad.17", i32 %"imad.18", i32 %"imad.19", i32 %"imad.20")
  %"sttm_memaddr_offset_add.6" = add i32 %"imad.25", 28
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.6", i32 %"imad.21", i32 %"imad.22", i32 %"imad.23", i32 %"imad.24")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0830"
BB_0830:
  %"cond_trunc.11" = trunc i32 %"P28_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a00", label %"BB_0840"
BB_0840:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 5120
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".199" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".199" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 4096
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".200" = xor i32 %"plop3_a_bit.2", 1
  %".201" = xor i32 %"plop3_b_bit.2", 1
  %".202" = xor i32 %"plop3_c_bit.2", 1
  %".203" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".204" = and i32 %".203", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".204", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".205" = zext i32 0 to i64
  %".206" = zext i32 %".185" to i64
  %".207" = shl i64 %".206", 32
  %"shf_concat.4" = or i64 %".205", %".207"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".208" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".208", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".209" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".210" = zext i32 %"iadd3_n2.3" to i64
  %".211" = zext i32 24 to i64
  %".212" = shl i64 %".209", %".211"
  %".213" = and i64 %".212", 4294967295
  %".214" = add i64 %".213", %".210"
  %".215" = trunc i64 %".214" to i32
  %".216" = xor i32 %"shf_result.4", -1
  %".217" = xor i32 16376, -1
  %".218" = xor i32 0, -1
  %".219" = and i32 %"shf_result.4", 16376
  %".220" = and i32 %".219", %".218"
  %".221" = and i32 %"shf_result.4", 16376
  %".222" = and i32 %".221", 0
  %".223" = or i32 %".220", %".222"
  %".224" = zext i32 0 to i64
  %".225" = zext i32 %".215" to i64
  %".226" = shl i64 %".225", 32
  %"shf_concat.5" = or i64 %".224", %".226"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".227" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".227", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".228" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".229" = bitcast i8* %".228" to i32*
  %"ldc_const" = load i32, i32* %".229"
  %".230" = xor i32 %"shf_result.5", -1
  %".231" = xor i32 16376, -1
  %".232" = xor i32 0, -1
  %".233" = and i32 %"shf_result.5", 16376
  %".234" = and i32 %".233", %".232"
  %".235" = and i32 %"shf_result.5", 16376
  %".236" = and i32 %".235", 0
  %".237" = or i32 %".234", %".236"
  %".238" = xor i32 %".223", -1
  %".239" = xor i32 524288, -1
  %".240" = xor i32 0, -1
  %".241" = and i32 %".238", 524288
  %".242" = and i32 %".241", %".240"
  %".243" = and i32 %".238", 524288
  %".244" = and i32 %".243", 0
  %".245" = or i32 %".242", %".244"
  %".246" = and i32 %".223", %".239"
  %".247" = and i32 %".246", %".240"
  %".248" = or i32 %".245", %".247"
  %".249" = and i32 %".223", %".239"
  %".250" = and i32 %".249", 0
  %".251" = or i32 %".248", %".250"
  %".252" = and i32 %".223", 524288
  %".253" = and i32 %".252", %".240"
  %".254" = or i32 %".251", %".253"
  %".255" = and i32 %".223", 524288
  %".256" = and i32 %".255", 0
  %".257" = or i32 %".254", %".256"
  %".258" = xor i32 %".237", -1
  %".259" = xor i32 524288, -1
  %".260" = xor i32 0, -1
  %".261" = and i32 %".258", 524288
  %".262" = and i32 %".261", %".260"
  %".263" = and i32 %".258", 524288
  %".264" = and i32 %".263", 0
  %".265" = or i32 %".262", %".264"
  %".266" = and i32 %".237", %".259"
  %".267" = and i32 %".266", %".260"
  %".268" = or i32 %".265", %".267"
  %".269" = and i32 %".237", %".259"
  %".270" = and i32 %".269", 0
  %".271" = or i32 %".268", %".270"
  %".272" = and i32 %".237", 524288
  %".273" = and i32 %".272", %".260"
  %".274" = or i32 %".271", %".273"
  %".275" = and i32 %".237", 524288
  %".276" = and i32 %".275", 0
  %".277" = or i32 %".274", %".276"
  br label %"BB_0930"
BB_0930:
  %"phi.11" = phi  i32 [%"phi.5", %"BB_0840"], [%"P20_to_i32", %"BB_0960"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0840"], [%"phi.14", %"BB_0960"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000930", label %"BB_0940"
BB_80000930:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000930"], [%"phi.11", %"BB_0930"]
  %"mma_a_r0_ext" = zext i32 %".257" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".281" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".282" = sub i64 %".281", 0
  %".283" = lshr i64 %".282", 4
  %".284" = add i64 %"mma_a_packed_1", %".283"
  %".285" = and i64 %".284", 16383
  %".286" = and i64 %"mma_a_packed_1", -16384
  %".287" = or i64 %".286", %".285"
  %"mma_b_r0_ext" = zext i32 %".277" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".288" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".289" = sub i64 %".288", 0
  %".290" = lshr i64 %".289", 4
  %".291" = add i64 %"mma_b_packed_1", %".290"
  %".292" = and i64 %".291", 16383
  %".293" = and i64 %"mma_b_packed_1", -16384
  %".294" = or i64 %".293", %".292"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred issuer, sp, dn; .reg .b32 mask, mode; activemask.b32 mask; elect.sync _|issuer, mask; and.b32 mode, $3, 4; setp.ne.and.u32 sp, mode, 0, issuer; setp.eq.and.u32 dn, mode, 0, issuer; .reg .pred tf, tf_sp, tf_dn; and.b32 mode, $3, 8064; setp.eq.u32 tf, mode, 2304; and.pred tf_sp, tf, sp; and.pred tf_dn, tf, dn; not.pred tf, tf; and.pred sp, tf, sp; and.pred dn, tf, dn; @tf_sp tcgen05.mma.sp.cta_group::1.kind::tf32 [$0], $1, $2, [$5], $3, use_d; @tf_dn tcgen05.mma.cta_group::1.kind::tf32 [$0], $1, $2, $3, use_d; @sp tcgen05.mma.sp.cta_group::1.kind::f16 [$0], $1, $2, [$5], $3, use_d; @dn tcgen05.mma.cta_group::1.kind::f16 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,r,~{memory}"(i32 %"lds.2", i64 %".287", i64 %".294", i32 %"ldc_const", i32 %"mma_arg_zext", i32 0)
  br label %"BB_0950"
BB_0950:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000950", label %"BB_0960"
BB_80000950:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".298" = xor i32 %"plop3_a_bit.3", 1
  %".299" = xor i32 %"plop3_b_bit.3", 1
  %".300" = xor i32 %"plop3_c_bit.3", 1
  %".301" = and i32 %".298", %"plop3_b_bit.3"
  %".302" = and i32 %".301", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".302", 0
  %"P8_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0960"
BB_0960:
  %"phi.14" = phi  i32 [%"P8_to_i32", %"BB_80000950"], [%"phi.12", %"BB_0950"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".304" = xor i32 %"plop3_a_bit.4", 1
  %".305" = xor i32 %"plop3_b_bit.4", 1
  %".306" = xor i32 %"plop3_c_bit.4", 1
  %".307" = and i32 %".304", %"plop3_b_bit.4"
  %".308" = and i32 %".307", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".308", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0930", label %"BB_0980"
BB_0980:
  %"iadd3_n1.4" = add i32 1024, 5128
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".310" = xor i32 %"plop3_a_bit.5", 1
  %".311" = xor i32 %"plop3_b_bit.5", 1
  %".312" = xor i32 %"plop3_c_bit.5", 1
  %".313" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".314" = and i32 %".313", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".314", 0
  %"P30_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".315" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".316" = zext i32 %"iadd3_n2.4" to i64
  %".317" = zext i32 24 to i64
  %".318" = shl i64 %".315", %".317"
  %".319" = and i64 %".318", 4294967295
  %".320" = add i64 %".319", %".316"
  %".321" = trunc i64 %".320" to i32
  br label %"BB_09b0"
BB_09b0:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0980"], [%"P11_to_i32", %"BB_09e0"]
  %"phi.16" = phi  i32 [%"P30_to_i32", %"BB_0980"], [%"phi.18", %"BB_09e0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P9_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.17" = phi  i32 [%"P9_to_i32", %"BB_800009b0"], [%"phi.15", %"BB_09b0"]
  %"utcbar_local_winoff" = and i32 %".321", 16777215
  %".325" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".326" = ptrtoint i8 addrspace(3)* %".325" to i32
  %".327" = lshr i32 %".321", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".326", i32 %".327")
  br label %"BB_09d0"
BB_09d0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009d0", label %"BB_09e0"
BB_800009d0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".331" = xor i32 %"plop3_a_bit.6", 1
  %".332" = xor i32 %"plop3_b_bit.6", 1
  %".333" = xor i32 %"plop3_c_bit.6", 1
  %".334" = and i32 %".331", %"plop3_b_bit.6"
  %".335" = and i32 %".334", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".335", 0
  %"P32_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09e0"
BB_09e0:
  %"phi.18" = phi  i32 [%"P32_to_i32", %"BB_800009d0"], [%"phi.16", %"BB_09d0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".337" = xor i32 %"plop3_a_bit.7", 1
  %".338" = xor i32 %"plop3_b_bit.7", 1
  %".339" = xor i32 %"plop3_c_bit.7", 1
  %".340" = and i32 %".337", %"plop3_b_bit.7"
  %".341" = and i32 %".340", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".341", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09b0", label %"BB_0a00"
BB_0a00:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 5128
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".343" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".344" = zext i32 %"iadd3_n2.5" to i64
  %".345" = zext i32 24 to i64
  %".346" = shl i64 %".343", %".345"
  %".347" = and i64 %".346", 4294967295
  %".348" = add i64 %".347", %".344"
  %".349" = trunc i64 %".348" to i32
  %"mbar_shared_winoff.1" = and i32 %".349", 16777215
  %".350" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".350" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P1_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.16" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1090", label %"BB_0a70"
BB_1090:
  %"mbar_shared_winoff.2" = and i32 %".349", 16777215
  %".353" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".353" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_10a0"
BB_10a0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_1090", label %"BB_0a70"
BB_0a70:
  %".356" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".357" = bitcast i8* %".356" to i64*
  %"ldc_const.1" = load i64, i64* %".357"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.26" = mul i32 %"tid_x.1", 32
  %"imad.26" = add i32 %"imad_tmp.26", 0
  %"isetrp_cmp1.9" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.25")
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.25", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".365" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad.26" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.27" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R13:R12_r0.1" = trunc i64 %"imad.27" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.27", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R74:R60_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R74:R60_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R74:R60_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R74:R60_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R74:R60_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R74:R60_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R74:R60_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R74:R60_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R74:R60_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R74:R60_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.25", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".371" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".373" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R74:R60_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R74:R60_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R74:R60_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R74:R60_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R74:R60_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".365", i32 addrspace(1)* %"R74:R60_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.25", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".379" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".380" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".381" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R74:R60_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".371", i32 addrspace(1)* %"R74:R60_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R74:R60_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R74:R60_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R74:R60_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".373", i32 addrspace(1)* %"R74:R60_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R74:R60_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R74:R60_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R74:R60_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R74:R60_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.25", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".387" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".388" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".389" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".390" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R74:R60_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".379", i32 addrspace(1)* %"R74:R60_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R74:R60_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".380", i32 addrspace(1)* %"R74:R60_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R74:R60_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".381", i32 addrspace(1)* %"R74:R60_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.25", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".394" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".395" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".396" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".397" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R74:R60_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".387", i32 addrspace(1)* %"R74:R60_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R74:R60_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".388", i32 addrspace(1)* %"R74:R60_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R74:R60_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".389", i32 addrspace(1)* %"R74:R60_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R74:R60_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".390", i32 addrspace(1)* %"R74:R60_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R74:R60_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".394", i32 addrspace(1)* %"R74:R60_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.25", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".403" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".404" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".405" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".406" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R74:R60_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".395", i32 addrspace(1)* %"R74:R60_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R74:R60_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".396", i32 addrspace(1)* %"R74:R60_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R74:R60_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".397", i32 addrspace(1)* %"R74:R60_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.25", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".410" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".411" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".412" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".413" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R74:R60_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".403", i32 addrspace(1)* %"R74:R60_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R74:R60_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".404", i32 addrspace(1)* %"R74:R60_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R74:R60_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".405", i32 addrspace(1)* %"R74:R60_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R74:R60_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".406", i32 addrspace(1)* %"R74:R60_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R74:R60_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".410", i32 addrspace(1)* %"R74:R60_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R74:R60_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".411", i32 addrspace(1)* %"R74:R60_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R74:R60_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".412", i32 addrspace(1)* %"R74:R60_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R74:R60_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".413", i32 addrspace(1)* %"R74:R60_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0df0"
BB_0df0:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000df0", label %"BB_0e00"
BB_0e00:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 5120
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".424" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".424" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.28" = add i32 %"imad_tmp.27", 3
  %".425" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".426" = zext i32 80 to i64
  %".427" = zext i32 24 to i64
  %".428" = shl i64 %".425", %".427"
  %".429" = and i64 %".428", 4294967295
  %".430" = add i64 %".429", %".426"
  %".431" = trunc i64 %".430" to i32
  %"imad_tmp.28" = mul i32 0, 0
  %"imad.29" = add i32 %"imad_tmp.28", 1
  %"lds_shared_addr_winoff.4" = and i32 %".431", 16777215
  %".432" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".432" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".433" = xor i32 %"lds.3", -1
  %".434" = xor i32 65535, -1
  %".435" = xor i32 0, -1
  %".436" = and i32 %"lds.3", 65535
  %".437" = and i32 %".436", %".435"
  %".438" = and i32 %"lds.3", 65535
  %".439" = and i32 %".438", 0
  %".440" = or i32 %".437", %".439"
  %".441" = zext i32 0 to i64
  %".442" = zext i32 %".440" to i64
  %".443" = shl i64 %".442", 32
  %"shf_concat.6" = or i64 %".441", %".443"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".444" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".444", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.5" = add i32 %"shf_result.6", 16
  %".445" = zext i32 %"imad.28" to i64
  %".446" = zext i32 0 to i64
  %".447" = shl i64 %".446", 32
  %"shf_concat.7" = or i64 %".445", %".447"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".448" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".448" to i32
  %".449" = zext i32 %"imad.29" to i64
  %".450" = zext i32 0 to i64
  %".451" = shl i64 %".450", 32
  %"shf_concat.8" = or i64 %".449", %".451"
  %"shf_shift_64.8" = zext i32 %"viadd.5" to i64
  %".452" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".452" to i32
  %".453" = xor i32 %"shf_result.8", -1
  %".454" = xor i32 %"shf_result.7", -1
  %".455" = xor i32 0, -1
  %".456" = and i32 %".453", %"shf_result.7"
  %".457" = and i32 %".456", %".455"
  %".458" = and i32 %".453", %"shf_result.7"
  %".459" = and i32 %".458", 0
  %".460" = or i32 %".457", %".459"
  %".461" = and i32 %"shf_result.8", %".454"
  %".462" = and i32 %".461", %".455"
  %".463" = or i32 %".460", %".462"
  %".464" = and i32 %"shf_result.8", %".454"
  %".465" = and i32 %".464", 0
  %".466" = or i32 %".463", %".465"
  %".467" = and i32 %"shf_result.8", %"shf_result.7"
  %".468" = and i32 %".467", %".455"
  %".469" = or i32 %".466", %".468"
  %".470" = and i32 %"shf_result.8", %"shf_result.7"
  %".471" = and i32 %".470", 0
  %".472" = or i32 %".469", %".471"
  %".473" = xor i32 %".472", -1
  %".474" = xor i32 65535, -1
  %".475" = xor i32 0, -1
  %".476" = and i32 %".472", 65535
  %".477" = and i32 %".476", %".475"
  %".478" = and i32 %".472", 65535
  %".479" = and i32 %".478", 0
  %".480" = or i32 %".477", %".479"
  %".481" = xor i32 %".472", -1
  %".482" = xor i32 65535, -1
  %".483" = xor i32 %"lds.4", -1
  %".484" = and i32 %".472", 65535
  %".485" = and i32 %".484", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".485", %".480"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0f00"
BB_0f00:
  %"cond_trunc.19" = trunc i32 %"P35_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_1060_1120", label %"BB_0f10"
BB_0f10:
  %".488" = zext i32 0 to i64
  %".489" = zext i32 %"lds.4" to i64
  %".490" = shl i64 %".489", 32
  %"shf_concat.9" = or i64 %".488", %".490"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".491" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".491", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".492" = zext i32 0 to i64
  %".493" = zext i32 %".472" to i64
  %".494" = shl i64 %".493", 32
  %"shf_concat.10" = or i64 %".492", %".494"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".495" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".495", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".496" = xor i32 %"shf_result.9", -1
  %".497" = xor i32 %"shf_result.10", -1
  %".498" = xor i32 0, -1
  %".499" = and i32 %"shf_result.9", %"shf_result.10"
  %".500" = and i32 %".499", %".498"
  %".501" = and i32 %"shf_result.9", %"shf_result.10"
  %".502" = and i32 %".501", 0
  %".503" = or i32 %".500", %".502"
  %"isetrp_cmp1.11" = icmp ne i32 %".503", %"shf_result.10"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0f50"
BB_0f50:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_1030_10c0", label %"BB_0f60"
BB_0f60:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".506" = xor i32 0, -1
  %".507" = xor i32 %".472", -1
  %".508" = xor i32 0, -1
  %".509" = and i32 %".506", %".507"
  %".510" = and i32 %".509", %".508"
  %".511" = and i32 %".506", %".507"
  %".512" = and i32 %".511", 0
  %".513" = or i32 %".510", %".512"
  %".514" = and i32 0, %".507"
  %".515" = and i32 %".514", %".508"
  %".516" = or i32 %".513", %".515"
  %".517" = and i32 0, %".507"
  %".518" = and i32 %".517", 0
  %".519" = or i32 %".516", %".518"
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.29", %".519"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.30", i32 %"redux_mask")
  %".520" = xor i32 %".519", -1
  %".521" = call i32 @"llvm.cttz.i32"(i32 %".520", i1 0)
  %".522" = shl i32 %".521", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".522") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.30", %"redux_sync_and"
  br label %"BB_1000"
BB_1000:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80001000", label %"BB_1070"
BB_80001000:
  %"atoms_shared_addr_winoff.1" = and i32 %".431", 16777215
  %".526" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".526" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.31" monotonic
  br label %"BB_1070"
BB_1030_10c0:
  call void @"llvm.trap"()
  br label %"BB_1070"
BB_1060_1120:
  call void @"llvm.trap"()
  br label %"BB_1070"
BB_1070:
  ret void
BB_80000df0:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare <2 x half> @"llvm.fma.v2f16"(<2 x half> %".1", <2 x half> %".2", <2 x half> %".3")

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i32, i64)* @"_Z11dynamic_mmaILb1EEvjPj", !"kernel", i32 1 }
!2 = !{ void (i32, i64)* @"_Z11dynamic_mmaILb0EEvjPj", !"kernel", i32 1 }
