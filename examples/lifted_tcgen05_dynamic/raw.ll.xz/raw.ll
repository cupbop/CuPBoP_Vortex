; ModuleID = "tcgen05_cubin"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [6160 x i8], align 16
define void @"_Z11dynamic_mmaILb1EEvjPj"(i32 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i32*
  store i32 %"arg_896", i32* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P33_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", 1010580540
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %".17" = zext i32 %"tid_x" to i64
  %".18" = zext i32 %".16" to i64
  %".19" = zext i32 2 to i64
  %".20" = shl i64 %".17", %".19"
  %".21" = and i64 %".20", 4294967295
  %".22" = add i64 %".21", %".18"
  %".23" = trunc i64 %".22" to i32
  br label %"BB_0090"
BB_0090:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_00d0"]
  %"phi.1" = phi  i32 [%".23", %"EntryBB_0000"], [%"viadd.1", %"BB_00d0"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 896
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".25" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".25" to i32 addrspace(3)*
  store volatile i32 %"imad", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd" = add i32 %"phi", 128
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_00d0"
BB_00d0:
  %"cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0090", label %"BB_00e0"
BB_00e0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0130"
BB_0130:
  %"cond_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01e0", label %"BB_0140"
BB_0140:
  %"iadd3_n1" = add i32 1024, 4096
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", 1077952576
  %".31" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".32" = zext i32 %"iadd3_n2" to i64
  %".33" = zext i32 24 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %".38" = zext i32 %"tid_x" to i64
  %".39" = zext i32 %".37" to i64
  %".40" = zext i32 2 to i64
  %".41" = shl i64 %".38", %".40"
  %".42" = and i64 %".41", 4294967295
  %".43" = add i64 %".42", %".39"
  %".44" = trunc i64 %".43" to i32
  br label %"BB_0190"
BB_0190:
  %"phi.2" = phi  i32 [%"tid_x", %"BB_0140"], [%"viadd.2", %"BB_01d0"]
  %"phi.3" = phi  i32 [%".44", %"BB_0140"], [%"viadd.3", %"BB_01d0"]
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"sts_shared_addr_winoff.1" = and i32 %"phi.3", 16777215
  %".46" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".46" to i32 addrspace(3)*
  store volatile i32 %"imad.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.2" = add i32 %"phi.2", 128
  %"viadd.3" = add i32 %"phi.3", 512
  br label %"BB_01d0"
BB_01d0:
  %"cond_trunc.2" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0190", label %"BB_01e0"
BB_01e0:
  %"vote_pred_trunc" = trunc i32 %"P25_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P15_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0230"
BB_0230:
  %"cond_trunc.3" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000230", label %"BB_0280"
BB_80000230:
  %"iadd3_n1.1" = add i32 1024, 5128
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".52" = zext i32 %"iadd3_n2.2" to i64
  %".53" = zext i32 0 to i64
  %".54" = shl i64 %".53", 32
  %"shf_concat" = or i64 %".52", %".54"
  %"shf_shift_64" = zext i32 11 to i64
  %".55" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".55" to i32
  %".56" = zext i32 %"iadd3_n2.2" to i64
  %".57" = zext i32 0 to i64
  %".58" = shl i64 %".57", 32
  %"shf_concat.1" = or i64 %".56", %".58"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".59" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".59" to i32
  %".60" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".61" = zext i32 %"iadd3_n2.1" to i64
  %".62" = zext i32 24 to i64
  %".63" = shl i64 %".60", %".62"
  %".64" = and i64 %".63", 4294967295
  %".65" = add i64 %".64", %".61"
  %".66" = trunc i64 %".65" to i32
  br label %"BB_0280"
BB_0280:
  %"phi.4" = phi  i32 [%".66", %"BB_80000230"], [0, %"BB_0230"]
  %"phi.5" = phi  i32 [%"shf_result", %"BB_80000230"], [0, %"BB_0230"]
  %"phi.6" = phi  i32 [%"shf_result.1", %"BB_80000230"], [1, %"BB_0230"]
  %"vote_pred_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P17_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.4" = trunc i32 %"P17_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002a0", label %"BB_02b0"
BB_800002a0:
  %"mbar_shared_winoff" = and i32 %"phi.4", 16777215
  %".71" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".71" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.6" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.5" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".72" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".72" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_02b0"
BB_02b0:
  %"cond_trunc.5" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0450", label %"BB_02c0"
BB_02c0:
  %"allocation_dst_memaddr_offset_add" = add i32 %".16", 5120
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".76" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".77" = ptrtoint i8 addrspace(3)* %".76" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".77", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P2_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.6" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0450", label %"BB_02f0"
BB_02f0:
  %".81" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".82" = zext i32 64 to i64
  %".83" = zext i32 24 to i64
  %".84" = shl i64 %".81", %".83"
  %".85" = and i64 %".84", 4294967295
  %".86" = add i64 %".85", %".82"
  %".87" = trunc i64 %".86" to i32
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.2", 3
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".16", 5120
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".88" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".89" = bitcast i8 addrspace(3)* %".88" to i32 addrspace(3)*
  %".90" = load i32, i32 addrspace(3)* %".89"
  %".91" = lshr i32 %".90", 5
  %"P18_to_i32" = zext i1 1 to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.3", %".91"
  %"bra_cond_trunc" = trunc i32 %"P18_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_03e0", label %"BB_0380"
BB_0380:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".16", 5120
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".93" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".94" = bitcast i8 addrspace(3)* %".93" to i32 addrspace(3)*
  %".95" = load i32, i32 addrspace(3)* %".94"
  %".96" = lshr i32 %".95", 5
  %"P19_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.4", %".96"
  %"bra_cond_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0380", label %"BB_03e0"
BB_03e0:
  %"phi.7" = phi  i32 [%"imad.3", %"BB_02f0"], [%"imad.4", %"BB_0380"]
  %".98" = zext i32 %"imad.2" to i64
  %".99" = zext i32 0 to i64
  %".100" = shl i64 %".99", 32
  %"shf_concat.2" = or i64 %".98", %".100"
  %"shf_shift_64.2" = zext i32 %"phi.7" to i64
  %".101" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".101" to i32
  %".102" = zext i32 1 to i64
  %".103" = zext i32 0 to i64
  %".104" = shl i64 %".103", 32
  %"shf_concat.3" = or i64 %".102", %".104"
  %"shf_shift_64.3" = zext i32 %"phi.7" to i64
  %".105" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".105" to i32
  %"imad_tmp.5" = mul i32 %"phi.7", 32
  %"imad.5" = add i32 %"imad_tmp.5", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".87", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".87", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".107" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".107" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 5120
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".108" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  store volatile i32 %"imad.5", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0450"
BB_0450:
  %"phi.8" = phi  i32 [%"P2_to_i32", %"BB_03e0"], [%"P2_to_i32", %"BB_02e0"], [%"P33_to_i32", %"BB_02b0"]
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.6" = mul i32 %"tid_x", 65536
  %"imad.6" = add i32 %"imad_tmp.6", 0
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.7", 1093664768
  %"hfma2_a" = bitcast i32 0 to <2 x half>
  %"hfma2_a_v2neg" = fneg <2 x half> %"hfma2_a"
  %"hfma2_b" = bitcast i32 0 to <2 x half>
  %"hfma2_c" = bitcast i32 1093664768 to <2 x half>
  %"hfma2_res" = call <2 x half> @"llvm.fma.v2f16"(<2 x half> %"hfma2_a_v2neg", <2 x half> %"hfma2_b", <2 x half> %"hfma2_c")
  %"hfma2" = bitcast <2 x half> %"hfma2_res" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.8", 1093664768
  %".111" = xor i32 %"imad.6", -1
  %".112" = xor i32 65011712, -1
  %".113" = xor i32 0, -1
  %".114" = and i32 %"imad.6", 65011712
  %".115" = and i32 %".114", %".113"
  %".116" = and i32 %"imad.6", 65011712
  %".117" = and i32 %".116", 0
  %".118" = or i32 %".115", %".117"
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.9", 1093664768
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.10", 1093664768
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.11", 1093664768
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.12", 1093664768
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.13", 1093664768
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.14", 1093664768
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.15", 1093664768
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.16", 1093664768
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.17", 1093664768
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 5120
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".119" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.18", 1093664768
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.19", 1093664768
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.20", 1093664768
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.21", 1093664768
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.22", 1093664768
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.23", 1093664768
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.24", 1093664768
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.25", 1093664768
  %"imad_tmp.26" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.26", 1093664768
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.27", 1093664768
  %"imad_tmp.28" = mul i32 %"lds", 1
  %"imad.28" = add i32 %"imad_tmp.28", %".118"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.28", i32 %"imad.7", i32 %"imad.8", i32 1093664768, i32 %"imad.9")
  %"sttm_memaddr_offset_add" = add i32 %"imad.28", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"imad.10", i32 %"imad.11", i32 %"imad.12", i32 %"imad.13")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.28", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"imad.14", i32 %"imad.15", i32 %"hfma2", i32 %"imad.16")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.28", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"imad.17", i32 %"imad.18", i32 %"imad.19", i32 %"imad.20")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.28", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"imad.21", i32 %"imad.22", i32 1093664768, i32 %"imad.23")
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.28", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"imad.24", i32 %"imad.25", i32 %"imad.26", i32 %"imad.27")
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.29" = add i32 %"imad_tmp.29", -2122285186
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.30", -2122285186
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.31", -2122285186
  %"imad_tmp.32" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.32", 2122285185
  %"imad_tmp.33" = mul i32 0, 0
  %"imad.33" = add i32 %"imad_tmp.33", 2122285185
  %"imad_tmp.34" = mul i32 0, 0
  %"imad.34" = add i32 %"imad_tmp.34", 2122285185
  %"imad_tmp.35" = mul i32 0, 0
  %"imad.35" = add i32 %"imad_tmp.35", 2122285185
  %"sttm_memaddr_offset_add.5" = add i32 %"imad.28", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.5", i32 %"imad.7", i32 %"imad.8", i32 1093664768, i32 %"imad.9")
  %"sttm_memaddr_offset_add.6" = add i32 %"imad.28", 28
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.6", i32 %"imad.10", i32 %"imad.11", i32 %"imad.12", i32 %"imad.13")
  %"sttm_memaddr_offset_add.7" = add i32 %"imad.28", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.7", i32 %"imad.29", i32 %"imad.30", i32 2172682110, i32 %"imad.31")
  %"sttm_memaddr_offset_add.8" = add i32 %"imad.28", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.8", i32 %"imad.32", i32 %"imad.33", i32 %"imad.34", i32 %"imad.35")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0850"
BB_0850:
  %"cond_trunc.7" = trunc i32 %"P25_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0a40", label %"BB_0860"
BB_0860:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 5120
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".134" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".134" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 4096
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".135" = xor i32 %"plop3_a_bit", 1
  %".136" = xor i32 %"plop3_b_bit", 1
  %".137" = xor i32 %"plop3_c_bit", 1
  %".138" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".139" = and i32 %".138", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".139", 0
  %"P26_to_i32" = zext i1 %"plop3_pred" to i32
  %".140" = zext i32 0 to i64
  %".141" = zext i32 %".16" to i64
  %".142" = shl i64 %".141", 32
  %"shf_concat.4" = or i64 %".140", %".142"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".143" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".143", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".144" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".145" = zext i32 %"iadd3_n2.3" to i64
  %".146" = zext i32 24 to i64
  %".147" = shl i64 %".144", %".146"
  %".148" = and i64 %".147", 4294967295
  %".149" = add i64 %".148", %".145"
  %".150" = trunc i64 %".149" to i32
  %".151" = xor i32 %"shf_result.4", -1
  %".152" = xor i32 16376, -1
  %".153" = xor i32 0, -1
  %".154" = and i32 %"shf_result.4", 16376
  %".155" = and i32 %".154", %".153"
  %".156" = and i32 %"shf_result.4", 16376
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = zext i32 0 to i64
  %".160" = zext i32 %".150" to i64
  %".161" = shl i64 %".160", 32
  %"shf_concat.5" = or i64 %".159", %".161"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".162" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".162", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".163" = xor i32 %".158", -1
  %".164" = xor i32 524288, -1
  %".165" = xor i32 0, -1
  %".166" = and i32 %".163", 524288
  %".167" = and i32 %".166", %".165"
  %".168" = and i32 %".163", 524288
  %".169" = and i32 %".168", 0
  %".170" = or i32 %".167", %".169"
  %".171" = and i32 %".158", %".164"
  %".172" = and i32 %".171", %".165"
  %".173" = or i32 %".170", %".172"
  %".174" = and i32 %".158", %".164"
  %".175" = and i32 %".174", 0
  %".176" = or i32 %".173", %".175"
  %".177" = and i32 %".158", 524288
  %".178" = and i32 %".177", %".165"
  %".179" = or i32 %".176", %".178"
  %".180" = and i32 %".158", 524288
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = xor i32 %"shf_result.5", -1
  %".184" = xor i32 16376, -1
  %".185" = xor i32 0, -1
  %".186" = and i32 %"shf_result.5", 16376
  %".187" = and i32 %".186", %".185"
  %".188" = and i32 %"shf_result.5", 16376
  %".189" = and i32 %".188", 0
  %".190" = or i32 %".187", %".189"
  %".191" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".192" = bitcast i8* %".191" to i32*
  %"ldc_const" = load i32, i32* %".192"
  %".193" = xor i32 %".190", -1
  %".194" = xor i32 524288, -1
  %".195" = xor i32 0, -1
  %".196" = and i32 %".193", 524288
  %".197" = and i32 %".196", %".195"
  %".198" = and i32 %".193", 524288
  %".199" = and i32 %".198", 0
  %".200" = or i32 %".197", %".199"
  %".201" = and i32 %".190", %".194"
  %".202" = and i32 %".201", %".195"
  %".203" = or i32 %".200", %".202"
  %".204" = and i32 %".190", %".194"
  %".205" = and i32 %".204", 0
  %".206" = or i32 %".203", %".205"
  %".207" = and i32 %".190", 524288
  %".208" = and i32 %".207", %".195"
  %".209" = or i32 %".206", %".208"
  %".210" = and i32 %".190", 524288
  %".211" = and i32 %".210", 0
  %".212" = or i32 %".209", %".211"
  %"iadd3_n1.4" = add i32 %"lds.1", 32
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.1", 36
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0970"
BB_0970:
  %"phi.9" = phi  i32 [%"phi.8", %"BB_0860"], [%"P9_to_i32", %"BB_09a0"]
  %"phi.10" = phi  i32 [%"P26_to_i32", %"BB_0860"], [%"phi.12", %"BB_09a0"]
  %"cond_trunc.8" = trunc i32 %"phi.10" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000970", label %"BB_0980"
BB_80000970:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P7_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0980"
BB_0980:
  %"phi.11" = phi  i32 [%"P7_to_i32", %"BB_80000970"], [%"phi.9", %"BB_0970"]
  %"mma_a_r0_ext" = zext i32 %".182" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".216" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".217" = sub i64 %".216", 0
  %".218" = lshr i64 %".217", 4
  %".219" = add i64 %"mma_a_packed_1", %".218"
  %".220" = and i64 %".219", 16383
  %".221" = and i64 %"mma_a_packed_1", -16384
  %".222" = or i64 %".221", %".220"
  %"mma_b_r0_ext" = zext i32 %".212" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".223" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".224" = sub i64 %".223", 0
  %".225" = lshr i64 %".224", 4
  %".226" = add i64 %"mma_b_packed_1", %".225"
  %".227" = and i64 %".226", 16383
  %".228" = and i64 %"mma_b_packed_1", -16384
  %".229" = or i64 %".228", %".227"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred issuer, sp, dn; .reg .b32 mask, mode; activemask.b32 mask; elect.sync _|issuer, mask; and.b32 mode, $3, 4; setp.ne.and.u32 sp, mode, 0, issuer; setp.eq.and.u32 dn, mode, 0, issuer; @sp tcgen05.mma.sp.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, [$5], $3, [$6], [$7], use_d; @dn tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$6], [$7], use_d; } }", "r,l,l,r,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".222", i64 %".229", i32 %"ldc_const", i32 %"mma_arg_zext", i32 0, i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_0990"
BB_0990:
  %"cond_trunc.9" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"lop3_a_trunc" = trunc i32 %"phi.11" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".233" = xor i32 %"plop3_a_bit.1", 1
  %".234" = xor i32 %"plop3_b_bit.1", 1
  %".235" = xor i32 %"plop3_c_bit.1", 1
  %".236" = and i32 %".233", %"plop3_b_bit.1"
  %".237" = and i32 %".236", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".237", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.12" = phi  i32 [%"P1_to_i32", %"BB_80000990"], [%"phi.10", %"BB_0990"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".239" = xor i32 %"plop3_a_bit.2", 1
  %".240" = xor i32 %"plop3_b_bit.2", 1
  %".241" = xor i32 %"plop3_c_bit.2", 1
  %".242" = and i32 %".239", %"plop3_b_bit.2"
  %".243" = and i32 %".242", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".243", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.12" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0970", label %"BB_09c0"
BB_09c0:
  %"iadd3_n1.6" = add i32 1024, 5128
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".245" = xor i32 %"plop3_a_bit.3", 1
  %".246" = xor i32 %"plop3_b_bit.3", 1
  %".247" = xor i32 %"plop3_c_bit.3", 1
  %".248" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".249" = and i32 %".248", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".249", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".250" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".251" = zext i32 %"iadd3_n2.6" to i64
  %".252" = zext i32 24 to i64
  %".253" = shl i64 %".250", %".252"
  %".254" = and i64 %".253", 4294967295
  %".255" = add i64 %".254", %".251"
  %".256" = trunc i64 %".255" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.13" = phi  i32 [%"P9_to_i32", %"BB_09c0"], [%"P3_to_i32", %"BB_0a20"]
  %"phi.14" = phi  i32 [%"P23_to_i32", %"BB_09c0"], [%"phi.16", %"BB_0a20"]
  %"cond_trunc.10" = trunc i32 %"phi.14" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_800009f0", label %"BB_0a00"
BB_800009f0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0a00"
BB_0a00:
  %"phi.15" = phi  i32 [%"P13_to_i32", %"BB_800009f0"], [%"phi.13", %"BB_09f0"]
  %"utcbar_local_winoff" = and i32 %".256", 16777215
  %".260" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".261" = ptrtoint i8 addrspace(3)* %".260" to i32
  %".262" = lshr i32 %".256", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".261", i32 %".262")
  br label %"BB_0a10"
BB_0a10:
  %"cond_trunc.11" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"lop3_a_trunc.1" = trunc i32 %"phi.15" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".266" = xor i32 %"plop3_a_bit.4", 1
  %".267" = xor i32 %"plop3_b_bit.4", 1
  %".268" = xor i32 %"plop3_c_bit.4", 1
  %".269" = and i32 %".266", %"plop3_b_bit.4"
  %".270" = and i32 %".269", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".270", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.16" = phi  i32 [%"P4_to_i32", %"BB_80000a10"], [%"phi.14", %"BB_0a10"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".272" = xor i32 %"plop3_a_bit.5", 1
  %".273" = xor i32 %"plop3_b_bit.5", 1
  %".274" = xor i32 %"plop3_c_bit.5", 1
  %".275" = and i32 %".272", %"plop3_b_bit.5"
  %".276" = and i32 %".275", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".276", 0
  %"P3_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.16" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_09f0", label %"BB_0a40"
BB_0a40:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 5128
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".278" = zext i32 0 to i64
  %".279" = zext i32 0 to i64
  %".280" = shl i64 %".279", 32
  %"shf_concat.6" = or i64 %".278", %".280"
  %"shf_shift_64.6" = zext i32 31 to i64
  %".281" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".281" to i32
  %".282" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".283" = zext i32 %"iadd3_n2.7" to i64
  %".284" = zext i32 24 to i64
  %".285" = shl i64 %".282", %".284"
  %".286" = and i64 %".285", 4294967295
  %".287" = add i64 %".286", %".283"
  %".288" = trunc i64 %".287" to i32
  %"mbar_shared_winoff.1" = and i32 %".288", 16777215
  %".289" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".289" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P21_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0ac0"
BB_0ac0:
  %"cond_trunc.12" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_10e0", label %"BB_0ad0"
BB_10e0:
  %"mbar_shared_winoff.2" = and i32 %".288", 16777215
  %".292" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".292" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P22_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_10f0"
BB_10f0:
  %"cond_trunc.13" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_10e0", label %"BB_0ad0"
BB_0ad0:
  %".295" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".296" = bitcast i8* %".295" to i64*
  %"ldc_const.1" = load i64, i64* %".296"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.36" = mul i32 %"tid_x", 32
  %"imad.36" = add i32 %"imad_tmp.36", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.28")
  %".297" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".299" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".300" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.28", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".301" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".302" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".303" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad.36" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.37" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0" = trunc i64 %"imad.37" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.37", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R168:R155_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".297", i32 addrspace(1)* %"R168:R155_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R168:R155_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R168:R155_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R168:R155_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".299", i32 addrspace(1)* %"R168:R155_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R168:R155_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".300", i32 addrspace(1)* %"R168:R155_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R168:R155_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".301", i32 addrspace(1)* %"R168:R155_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.28", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R168:R155_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".302", i32 addrspace(1)* %"R168:R155_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R168:R155_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".303", i32 addrspace(1)* %"R168:R155_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R168:R155_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R168:R155_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.28", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".317" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".318" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".319" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R168:R155_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R168:R155_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R168:R155_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R168:R155_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R168:R155_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R168:R155_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R168:R155_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R168:R155_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R168:R155_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".317", i32 addrspace(1)* %"R168:R155_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.28", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".328" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R168:R155_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".318", i32 addrspace(1)* %"R168:R155_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R168:R155_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".319", i32 addrspace(1)* %"R168:R155_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R168:R155_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R168:R155_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.28", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".333" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".334" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".335" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".336" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R168:R155_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R168:R155_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R168:R155_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R168:R155_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R168:R155_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".328", i32 addrspace(1)* %"R168:R155_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R168:R155_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R168:R155_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R168:R155_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".333", i32 addrspace(1)* %"R168:R155_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.28", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".344" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".345" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R168:R155_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".334", i32 addrspace(1)* %"R168:R155_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R168:R155_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".335", i32 addrspace(1)* %"R168:R155_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R168:R155_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".336", i32 addrspace(1)* %"R168:R155_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.28", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".350" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R168:R155_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R168:R155_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R168:R155_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R168:R155_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R168:R155_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".344", i32 addrspace(1)* %"R168:R155_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R168:R155_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".345", i32 addrspace(1)* %"R168:R155_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R168:R155_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R168:R155_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R168:R155_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".350", i32 addrspace(1)* %"R168:R155_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R168:R155_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R168:R155_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R168:R155_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R168:R155_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0e40"
BB_0e40:
  %"cond_trunc.14" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000e40", label %"BB_0e50"
BB_0e50:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 5120
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".363" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".363" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.37" = mul i32 0, 0
  %"imad.38" = add i32 %"imad_tmp.37", 3
  %".364" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".365" = zext i32 64 to i64
  %".366" = zext i32 24 to i64
  %".367" = shl i64 %".364", %".366"
  %".368" = and i64 %".367", 4294967295
  %".369" = add i64 %".368", %".365"
  %".370" = trunc i64 %".369" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".370", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".371" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".371" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".372" = xor i32 %"lds.2", -1
  %".373" = xor i32 65535, -1
  %".374" = xor i32 0, -1
  %".375" = and i32 %"lds.2", 65535
  %".376" = and i32 %".375", %".374"
  %".377" = and i32 %"lds.2", 65535
  %".378" = and i32 %".377", 0
  %".379" = or i32 %".376", %".378"
  %".380" = zext i32 0 to i64
  %".381" = zext i32 %".379" to i64
  %".382" = shl i64 %".381", 32
  %"shf_concat.7" = or i64 %".380", %".382"
  %"shf_shift_64.7" = zext i32 5 to i64
  %".383" = lshr i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_hi.2" = lshr i64 %".383", 32
  %"shf_result.7" = trunc i64 %"shf_hi.2" to i32
  %".384" = zext i32 %"imad.38" to i64
  %".385" = zext i32 0 to i64
  %".386" = shl i64 %".385", 32
  %"shf_concat.8" = or i64 %".384", %".386"
  %"shf_shift_64.8" = zext i32 %"shf_result.7" to i64
  %".387" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".387" to i32
  %".388" = xor i32 %"lds.3", -1
  %".389" = xor i32 %"shf_result.8", -1
  %".390" = xor i32 0, -1
  %".391" = and i32 %"lds.3", %"shf_result.8"
  %".392" = and i32 %".391", %".390"
  %".393" = and i32 %"lds.3", %"shf_result.8"
  %".394" = and i32 %".393", 0
  %".395" = or i32 %".392", %".394"
  %"isetrp_cmp1.5" = icmp ne i32 %".395", %"shf_result.8"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %".396" = zext i32 1 to i64
  %".397" = zext i32 0 to i64
  %".398" = shl i64 %".397", 32
  %"shf_concat.9" = or i64 %".396", %".398"
  %"shf_shift_64.9" = zext i32 %"shf_result.7" to i64
  %".399" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".399" to i32
  br label %"BB_0f20"
BB_0f20:
  %"cond_trunc.15" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_10b0_1140", label %"BB_0f30"
BB_0f30:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".370", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".402" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".402" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".403" = xor i32 %"lds.4", -1
  %".404" = xor i32 %"shf_result.9", -1
  %".405" = xor i32 0, -1
  %".406" = and i32 %"lds.4", %"shf_result.9"
  %".407" = and i32 %".406", %".405"
  %".408" = and i32 %"lds.4", %"shf_result.9"
  %".409" = and i32 %".408", 0
  %".410" = or i32 %".407", %".409"
  %"isetrp_cmp1.6" = icmp ne i32 %".410", %"shf_result.9"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0f60"
BB_0f60:
  %"cond_trunc.16" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1080_1110", label %"BB_0f70"
BB_0f70:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".413" = xor i32 0, -1
  %".414" = xor i32 %"shf_result.9", -1
  %".415" = xor i32 0, -1
  %".416" = and i32 %".413", %".414"
  %".417" = and i32 %".416", %".415"
  %".418" = and i32 %".413", %".414"
  %".419" = and i32 %".418", 0
  %".420" = or i32 %".417", %".419"
  %".421" = and i32 0, %".414"
  %".422" = and i32 %".421", %".415"
  %".423" = or i32 %".420", %".422"
  %".424" = and i32 0, %".414"
  %".425" = and i32 %".424", 0
  %".426" = or i32 %".423", %".425"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".426", i32 %"redux_mask")
  %".427" = xor i32 0, -1
  %".428" = xor i32 %"shf_result.8", -1
  %".429" = xor i32 0, -1
  %".430" = and i32 %".427", %".428"
  %".431" = and i32 %".430", %".429"
  %".432" = and i32 %".427", %".428"
  %".433" = and i32 %".432", 0
  %".434" = or i32 %".431", %".433"
  %".435" = and i32 0, %".428"
  %".436" = and i32 %".435", %".429"
  %".437" = or i32 %".434", %".436"
  %".438" = and i32 0, %".428"
  %".439" = and i32 %".438", 0
  %".440" = or i32 %".437", %".439"
  %"imad_tmp.38" = mul i32 0, 0
  %"imad.39" = add i32 %"imad_tmp.38", %".440"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.39", i32 %"redux_mask.1")
  %".441" = xor i32 %".440", -1
  %".442" = call i32 @"llvm.cttz.i32"(i32 %".441", i1 0)
  %".443" = shl i32 %".442", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".443") convergent
  %"imad_tmp.39" = mul i32 0, 0
  %"imad.40" = add i32 %"imad_tmp.39", %"redux_sync_and"
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.40" = mul i32 0, 0
  %"imad.41" = add i32 %"imad_tmp.40", %"redux_sync_and.1"
  br label %"BB_1040"
BB_1040:
  %"cond_trunc.17" = trunc i32 %"P20_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001040", label %"BB_10c0"
BB_80001040:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".370", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".447" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".447" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.41" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".370", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".448" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".448" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.40" monotonic
  br label %"BB_10c0"
BB_1080_1110:
  call void @"llvm.trap"()
  br label %"BB_10c0"
BB_10b0_1140:
  call void @"llvm.trap"()
  br label %"BB_10c0"
BB_10c0:
  ret void
BB_80000e40:
  ret void
}

define void @"_Z11dynamic_mmaILb0EEvjPj"(i32 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i32*
  store i32 %"arg_896", i32* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P33_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", 1065369472
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %".17" = zext i32 %"tid_x" to i64
  %".18" = zext i32 %".16" to i64
  %".19" = zext i32 2 to i64
  %".20" = shl i64 %".17", %".19"
  %".21" = and i64 %".20", 4294967295
  %".22" = add i64 %".21", %".18"
  %".23" = trunc i64 %".22" to i32
  br label %"BB_0090"
BB_0090:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_00d0"]
  %"phi.1" = phi  i32 [%".23", %"EntryBB_0000"], [%"viadd.1", %"BB_00d0"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 896
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".25" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".25" to i32 addrspace(3)*
  store volatile i32 %"imad", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd" = add i32 %"phi", 128
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_00d0"
BB_00d0:
  %"cond_trunc" = trunc i32 %"P24_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0090", label %"BB_00e0"
BB_00e0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P29_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P25_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0130"
BB_0130:
  %"cond_trunc.1" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01e0", label %"BB_0140"
BB_0140:
  %"iadd3_n1" = add i32 1024, 4096
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", 1073758208
  %".31" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".32" = zext i32 %"iadd3_n2" to i64
  %".33" = zext i32 24 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %".38" = zext i32 %"tid_x" to i64
  %".39" = zext i32 %".37" to i64
  %".40" = zext i32 2 to i64
  %".41" = shl i64 %".38", %".40"
  %".42" = and i64 %".41", 4294967295
  %".43" = add i64 %".42", %".39"
  %".44" = trunc i64 %".43" to i32
  br label %"BB_0190"
BB_0190:
  %"phi.2" = phi  i32 [%"tid_x", %"BB_0140"], [%"viadd.2", %"BB_01d0"]
  %"phi.3" = phi  i32 [%".44", %"BB_0140"], [%"viadd.3", %"BB_01d0"]
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"sts_shared_addr_winoff.1" = and i32 %"phi.3", 16777215
  %".46" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".46" to i32 addrspace(3)*
  store volatile i32 %"imad.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.2" = add i32 %"phi.2", 128
  %"viadd.3" = add i32 %"phi.3", 512
  br label %"BB_01d0"
BB_01d0:
  %"cond_trunc.2" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0190", label %"BB_01e0"
BB_01e0:
  %"vote_pred_trunc" = trunc i32 %"P25_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P15_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0230"
BB_0230:
  %"cond_trunc.3" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000230", label %"BB_0280"
BB_80000230:
  %"iadd3_n1.1" = add i32 1024, 5128
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".52" = zext i32 %"iadd3_n2.2" to i64
  %".53" = zext i32 0 to i64
  %".54" = shl i64 %".53", 32
  %"shf_concat" = or i64 %".52", %".54"
  %"shf_shift_64" = zext i32 11 to i64
  %".55" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".55" to i32
  %".56" = zext i32 %"iadd3_n2.2" to i64
  %".57" = zext i32 0 to i64
  %".58" = shl i64 %".57", 32
  %"shf_concat.1" = or i64 %".56", %".58"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".59" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".59" to i32
  %".60" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".61" = zext i32 %"iadd3_n2.1" to i64
  %".62" = zext i32 24 to i64
  %".63" = shl i64 %".60", %".62"
  %".64" = and i64 %".63", 4294967295
  %".65" = add i64 %".64", %".61"
  %".66" = trunc i64 %".65" to i32
  br label %"BB_0280"
BB_0280:
  %"phi.4" = phi  i32 [%".66", %"BB_80000230"], [0, %"BB_0230"]
  %"phi.5" = phi  i32 [%"shf_result", %"BB_80000230"], [0, %"BB_0230"]
  %"phi.6" = phi  i32 [%"shf_result.1", %"BB_80000230"], [1, %"BB_0230"]
  %"vote_pred_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P17_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.4" = trunc i32 %"P17_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002a0", label %"BB_02b0"
BB_800002a0:
  %"mbar_shared_winoff" = and i32 %"phi.4", 16777215
  %".71" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".71" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.6" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.5" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".72" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".72" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_02b0"
BB_02b0:
  %"cond_trunc.5" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0450", label %"BB_02c0"
BB_02c0:
  %"allocation_dst_memaddr_offset_add" = add i32 %".16", 5120
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".76" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".77" = ptrtoint i8 addrspace(3)* %".76" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".77", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P2_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.6" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0450", label %"BB_02f0"
BB_02f0:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.2", 3
  %".81" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".82" = zext i32 64 to i64
  %".83" = zext i32 24 to i64
  %".84" = shl i64 %".81", %".83"
  %".85" = and i64 %".84", 4294967295
  %".86" = add i64 %".85", %".82"
  %".87" = trunc i64 %".86" to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".16", 5120
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".88" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".89" = bitcast i8 addrspace(3)* %".88" to i32 addrspace(3)*
  %".90" = load i32, i32 addrspace(3)* %".89"
  %".91" = lshr i32 %".90", 5
  %"P18_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.4", %".91"
  %"bra_cond_trunc" = trunc i32 %"P18_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_03e0", label %"BB_0380"
BB_0380:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".16", 5120
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".93" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".94" = bitcast i8 addrspace(3)* %".93" to i32 addrspace(3)*
  %".95" = load i32, i32 addrspace(3)* %".94"
  %".96" = lshr i32 %".95", 5
  %"P19_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.5", %".96"
  %"bra_cond_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0380", label %"BB_03e0"
BB_03e0:
  %"phi.7" = phi  i32 [%"imad.4", %"BB_02f0"], [%"imad.5", %"BB_0380"]
  %".98" = zext i32 %"imad.2" to i64
  %".99" = zext i32 0 to i64
  %".100" = shl i64 %".99", 32
  %"shf_concat.2" = or i64 %".98", %".100"
  %"shf_shift_64.2" = zext i32 %"phi.7" to i64
  %".101" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".101" to i32
  %".102" = zext i32 %"imad.3" to i64
  %".103" = zext i32 0 to i64
  %".104" = shl i64 %".103", 32
  %"shf_concat.3" = or i64 %".102", %".104"
  %"shf_shift_64.3" = zext i32 %"phi.7" to i64
  %".105" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".105" to i32
  %"imad_tmp.6" = mul i32 %"phi.7", 32
  %"imad.6" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".87", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".87", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".107" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".107" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 5120
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".108" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  store volatile i32 %"imad.6", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0450"
BB_0450:
  %"phi.8" = phi  i32 [%"P2_to_i32", %"BB_03e0"], [%"P2_to_i32", %"BB_02e0"], [%"P33_to_i32", %"BB_02b0"]
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 65536
  %"imad.7" = add i32 %"imad_tmp.7", 0
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.8", 1093664768
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.9", 1093664768
  %".111" = xor i32 %"imad.7", -1
  %".112" = xor i32 65011712, -1
  %".113" = xor i32 0, -1
  %".114" = and i32 %"imad.7", 65011712
  %".115" = and i32 %".114", %".113"
  %".116" = and i32 %"imad.7", 65011712
  %".117" = and i32 %".116", 0
  %".118" = or i32 %".115", %".117"
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.10", 1093664768
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.11", 1093664768
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.12", 1093664768
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.13", 1093664768
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.14", 1093664768
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.15", 1093664768
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.16", 1093664768
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.17", 1093664768
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.18", 1093664768
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 5120
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".119" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.19", 1093664768
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.20", 1093664768
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.21", 1093664768
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.22", 1093664768
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.23", 1093664768
  %"imad_tmp.24" = mul i32 %"lds", 1
  %"imad.24" = add i32 %"imad_tmp.24", %".118"
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.24", i32 %"imad.8", i32 %"imad.9", i32 %"imad.10", i32 %"imad.11")
  %"sttm_memaddr_offset_add" = add i32 %"imad.24", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"imad.12", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.24", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"imad.16", i32 %"imad.17", i32 %"imad.18", i32 %"imad.19")
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.24", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"imad.20", i32 %"imad.21", i32 %"imad.22", i32 %"imad.23")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.24", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"imad.8", i32 %"imad.9", i32 %"imad.10", i32 %"imad.11")
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.24", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"imad.12", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15")
  %"sttm_memaddr_offset_add.5" = add i32 %"imad.24", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.5", i32 %"imad.16", i32 %"imad.17", i32 %"imad.18", i32 %"imad.19")
  %"sttm_memaddr_offset_add.6" = add i32 %"imad.24", 28
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.6", i32 %"imad.20", i32 %"imad.21", i32 %"imad.22", i32 %"imad.23")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0710"
BB_0710:
  %"cond_trunc.7" = trunc i32 %"P25_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_08e0", label %"BB_0720"
BB_0720:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 5120
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".132" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".132" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 4096
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".133" = xor i32 %"plop3_a_bit", 1
  %".134" = xor i32 %"plop3_b_bit", 1
  %".135" = xor i32 %"plop3_c_bit", 1
  %".136" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".137" = and i32 %".136", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".137", 0
  %"P26_to_i32" = zext i1 %"plop3_pred" to i32
  %".138" = zext i32 0 to i64
  %".139" = zext i32 %".16" to i64
  %".140" = shl i64 %".139", 32
  %"shf_concat.4" = or i64 %".138", %".140"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".141" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".141", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".142" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".143" = zext i32 %"iadd3_n2.3" to i64
  %".144" = zext i32 24 to i64
  %".145" = shl i64 %".142", %".144"
  %".146" = and i64 %".145", 4294967295
  %".147" = add i64 %".146", %".143"
  %".148" = trunc i64 %".147" to i32
  %".149" = xor i32 %"shf_result.4", -1
  %".150" = xor i32 16376, -1
  %".151" = xor i32 0, -1
  %".152" = and i32 %"shf_result.4", 16376
  %".153" = and i32 %".152", %".151"
  %".154" = and i32 %"shf_result.4", 16376
  %".155" = and i32 %".154", 0
  %".156" = or i32 %".153", %".155"
  %".157" = zext i32 0 to i64
  %".158" = zext i32 %".148" to i64
  %".159" = shl i64 %".158", 32
  %"shf_concat.5" = or i64 %".157", %".159"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".160" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".160", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".161" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".162" = bitcast i8* %".161" to i32*
  %"ldc_const" = load i32, i32* %".162"
  %".163" = xor i32 %"shf_result.5", -1
  %".164" = xor i32 16376, -1
  %".165" = xor i32 0, -1
  %".166" = and i32 %"shf_result.5", 16376
  %".167" = and i32 %".166", %".165"
  %".168" = and i32 %"shf_result.5", 16376
  %".169" = and i32 %".168", 0
  %".170" = or i32 %".167", %".169"
  %".171" = xor i32 %".156", -1
  %".172" = xor i32 524288, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %".171", 524288
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %".171", 524288
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = and i32 %".156", %".172"
  %".180" = and i32 %".179", %".173"
  %".181" = or i32 %".178", %".180"
  %".182" = and i32 %".156", %".172"
  %".183" = and i32 %".182", 0
  %".184" = or i32 %".181", %".183"
  %".185" = and i32 %".156", 524288
  %".186" = and i32 %".185", %".173"
  %".187" = or i32 %".184", %".186"
  %".188" = and i32 %".156", 524288
  %".189" = and i32 %".188", 0
  %".190" = or i32 %".187", %".189"
  %".191" = xor i32 %".170", -1
  %".192" = xor i32 524288, -1
  %".193" = xor i32 0, -1
  %".194" = and i32 %".191", 524288
  %".195" = and i32 %".194", %".193"
  %".196" = and i32 %".191", 524288
  %".197" = and i32 %".196", 0
  %".198" = or i32 %".195", %".197"
  %".199" = and i32 %".170", %".192"
  %".200" = and i32 %".199", %".193"
  %".201" = or i32 %".198", %".200"
  %".202" = and i32 %".170", %".192"
  %".203" = and i32 %".202", 0
  %".204" = or i32 %".201", %".203"
  %".205" = and i32 %".170", 524288
  %".206" = and i32 %".205", %".193"
  %".207" = or i32 %".204", %".206"
  %".208" = and i32 %".170", 524288
  %".209" = and i32 %".208", 0
  %".210" = or i32 %".207", %".209"
  br label %"BB_0810"
BB_0810:
  %"phi.9" = phi  i32 [%"phi.8", %"BB_0720"], [%"P9_to_i32", %"BB_0840"]
  %"phi.10" = phi  i32 [%"P26_to_i32", %"BB_0720"], [%"phi.12", %"BB_0840"]
  %"cond_trunc.8" = trunc i32 %"phi.10" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000810", label %"BB_0820"
BB_80000810:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P7_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0820"
BB_0820:
  %"phi.11" = phi  i32 [%"P7_to_i32", %"BB_80000810"], [%"phi.9", %"BB_0810"]
  %"mma_a_r0_ext" = zext i32 %".190" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".214" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".215" = sub i64 %".214", 0
  %".216" = lshr i64 %".215", 4
  %".217" = add i64 %"mma_a_packed_1", %".216"
  %".218" = and i64 %".217", 16383
  %".219" = and i64 %"mma_a_packed_1", -16384
  %".220" = or i64 %".219", %".218"
  %"mma_b_r0_ext" = zext i32 %".210" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".221" = ptrtoint [6160 x i8] addrspace(3)* @"shared_mem" to i64
  %".222" = sub i64 %".221", 0
  %".223" = lshr i64 %".222", 4
  %".224" = add i64 %"mma_b_packed_1", %".223"
  %".225" = and i64 %".224", 16383
  %".226" = and i64 %"mma_b_packed_1", -16384
  %".227" = or i64 %".226", %".225"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred issuer, sp, dn; .reg .b32 mask, mode; activemask.b32 mask; elect.sync _|issuer, mask; and.b32 mode, $3, 4; setp.ne.and.u32 sp, mode, 0, issuer; setp.eq.and.u32 dn, mode, 0, issuer; .reg .pred tf, tf_sp, tf_dn; and.b32 mode, $3, 8064; setp.eq.u32 tf, mode, 2304; and.pred tf_sp, tf, sp; and.pred tf_dn, tf, dn; not.pred tf, tf; and.pred sp, tf, sp; and.pred dn, tf, dn; @tf_sp tcgen05.mma.sp.cta_group::1.kind::tf32 [$0], $1, $2, [$5], $3, use_d; @tf_dn tcgen05.mma.cta_group::1.kind::tf32 [$0], $1, $2, $3, use_d; @sp tcgen05.mma.sp.cta_group::1.kind::f16 [$0], $1, $2, [$5], $3, use_d; @dn tcgen05.mma.cta_group::1.kind::f16 [$0], $1, $2, $3, use_d; } }", "r,l,l,r,r,r,~{memory}"(i32 %"lds.1", i64 %".220", i64 %".227", i32 %"ldc_const", i32 %"mma_arg_zext", i32 0)
  br label %"BB_0830"
BB_0830:
  %"cond_trunc.9" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000830", label %"BB_0840"
BB_80000830:
  %"lop3_a_trunc" = trunc i32 %"phi.11" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".231" = xor i32 %"plop3_a_bit.1", 1
  %".232" = xor i32 %"plop3_b_bit.1", 1
  %".233" = xor i32 %"plop3_c_bit.1", 1
  %".234" = and i32 %".231", %"plop3_b_bit.1"
  %".235" = and i32 %".234", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".235", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0840"
BB_0840:
  %"phi.12" = phi  i32 [%"P1_to_i32", %"BB_80000830"], [%"phi.10", %"BB_0830"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".237" = xor i32 %"plop3_a_bit.2", 1
  %".238" = xor i32 %"plop3_b_bit.2", 1
  %".239" = xor i32 %"plop3_c_bit.2", 1
  %".240" = and i32 %".237", %"plop3_b_bit.2"
  %".241" = and i32 %".240", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".241", 0
  %"P9_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.12" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0810", label %"BB_0860"
BB_0860:
  %"iadd3_n1.4" = add i32 1024, 5128
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".243" = xor i32 %"plop3_a_bit.3", 1
  %".244" = xor i32 %"plop3_b_bit.3", 1
  %".245" = xor i32 %"plop3_c_bit.3", 1
  %".246" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".247" = and i32 %".246", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".247", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".248" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".249" = zext i32 %"iadd3_n2.4" to i64
  %".250" = zext i32 24 to i64
  %".251" = shl i64 %".248", %".250"
  %".252" = and i64 %".251", 4294967295
  %".253" = add i64 %".252", %".249"
  %".254" = trunc i64 %".253" to i32
  br label %"BB_0890"
BB_0890:
  %"phi.13" = phi  i32 [%"P9_to_i32", %"BB_0860"], [%"P3_to_i32", %"BB_08c0"]
  %"phi.14" = phi  i32 [%"P23_to_i32", %"BB_0860"], [%"phi.16", %"BB_08c0"]
  %"cond_trunc.10" = trunc i32 %"phi.14" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P13_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.15" = phi  i32 [%"P13_to_i32", %"BB_80000890"], [%"phi.13", %"BB_0890"]
  %"utcbar_local_winoff" = and i32 %".254", 16777215
  %".258" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".259" = ptrtoint i8 addrspace(3)* %".258" to i32
  %".260" = lshr i32 %".254", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".259", i32 %".260")
  br label %"BB_08b0"
BB_08b0:
  %"cond_trunc.11" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_800008b0", label %"BB_08c0"
BB_800008b0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.15" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".264" = xor i32 %"plop3_a_bit.4", 1
  %".265" = xor i32 %"plop3_b_bit.4", 1
  %".266" = xor i32 %"plop3_c_bit.4", 1
  %".267" = and i32 %".264", %"plop3_b_bit.4"
  %".268" = and i32 %".267", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".268", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_08c0"
BB_08c0:
  %"phi.16" = phi  i32 [%"P4_to_i32", %"BB_800008b0"], [%"phi.14", %"BB_08b0"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".270" = xor i32 %"plop3_a_bit.5", 1
  %".271" = xor i32 %"plop3_b_bit.5", 1
  %".272" = xor i32 %"plop3_c_bit.5", 1
  %".273" = and i32 %".270", %"plop3_b_bit.5"
  %".274" = and i32 %".273", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".274", 0
  %"P3_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.16" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0890", label %"BB_08e0"
BB_08e0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 5128
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".276" = zext i32 0 to i64
  %".277" = zext i32 0 to i64
  %".278" = shl i64 %".277", 32
  %"shf_concat.6" = or i64 %".276", %".278"
  %"shf_shift_64.6" = zext i32 31 to i64
  %".279" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".279" to i32
  %".280" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".281" = zext i32 %"iadd3_n2.5" to i64
  %".282" = zext i32 24 to i64
  %".283" = shl i64 %".280", %".282"
  %".284" = and i64 %".283", 4294967295
  %".285" = add i64 %".284", %".281"
  %".286" = trunc i64 %".285" to i32
  %"mbar_shared_winoff.1" = and i32 %".286", 16777215
  %".287" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".287" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P21_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.12" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0f80", label %"BB_0970"
BB_0f80:
  %"mbar_shared_winoff.2" = and i32 %".286", 16777215
  %".290" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".290" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P22_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f90"
BB_0f90:
  %"cond_trunc.13" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_0f80", label %"BB_0970"
BB_0970:
  %".293" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".294" = bitcast i8* %".293" to i64*
  %"ldc_const.1" = load i64, i64* %".294"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.25" = mul i32 %"tid_x", 32
  %"imad.25" = add i32 %"imad_tmp.25", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.24")
  %".295" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".296" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".297" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".298" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.24", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".299" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".300" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".301" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".302" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad.25" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.26" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0" = trunc i64 %"imad.26" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.26", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R109:R95_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".295", i32 addrspace(1)* %"R109:R95_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R109:R95_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".296", i32 addrspace(1)* %"R109:R95_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R109:R95_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".297", i32 addrspace(1)* %"R109:R95_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R109:R95_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".298", i32 addrspace(1)* %"R109:R95_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R109:R95_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".299", i32 addrspace(1)* %"R109:R95_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.24", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R109:R95_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".300", i32 addrspace(1)* %"R109:R95_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R109:R95_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".301", i32 addrspace(1)* %"R109:R95_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R109:R95_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".302", i32 addrspace(1)* %"R109:R95_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.24", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".315" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".316" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".317" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".318" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R109:R95_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R109:R95_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R109:R95_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R109:R95_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R109:R95_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R109:R95_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R109:R95_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R109:R95_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R109:R95_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".315", i32 addrspace(1)* %"R109:R95_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.24", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R109:R95_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".316", i32 addrspace(1)* %"R109:R95_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R109:R95_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".317", i32 addrspace(1)* %"R109:R95_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R109:R95_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".318", i32 addrspace(1)* %"R109:R95_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.24", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".331" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".332" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".333" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".334" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R109:R95_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R109:R95_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R109:R95_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R109:R95_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R109:R95_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R109:R95_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R109:R95_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R109:R95_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R109:R95_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".331", i32 addrspace(1)* %"R109:R95_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.24", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R109:R95_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".332", i32 addrspace(1)* %"R109:R95_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R109:R95_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".333", i32 addrspace(1)* %"R109:R95_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R109:R95_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".334", i32 addrspace(1)* %"R109:R95_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.24", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".347" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".348" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".350" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R109:R95_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R109:R95_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R109:R95_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R109:R95_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R109:R95_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R109:R95_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R109:R95_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R109:R95_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R109:R95_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".347", i32 addrspace(1)* %"R109:R95_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R109:R95_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".348", i32 addrspace(1)* %"R109:R95_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R109:R95_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R109:R95_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R109:R95_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".350", i32 addrspace(1)* %"R109:R95_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0ce0"
BB_0ce0:
  %"cond_trunc.14" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000ce0", label %"BB_0cf0"
BB_0cf0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 5120
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".361" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".361" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.26" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.26", 3
  %".362" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".363" = zext i32 64 to i64
  %".364" = zext i32 24 to i64
  %".365" = shl i64 %".362", %".364"
  %".366" = and i64 %".365", 4294967295
  %".367" = add i64 %".366", %".363"
  %".368" = trunc i64 %".367" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".368", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".369" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".369" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".370" = xor i32 %"lds.2", -1
  %".371" = xor i32 65535, -1
  %".372" = xor i32 0, -1
  %".373" = and i32 %"lds.2", 65535
  %".374" = and i32 %".373", %".372"
  %".375" = and i32 %"lds.2", 65535
  %".376" = and i32 %".375", 0
  %".377" = or i32 %".374", %".376"
  %".378" = zext i32 0 to i64
  %".379" = zext i32 %".377" to i64
  %".380" = shl i64 %".379", 32
  %"shf_concat.7" = or i64 %".378", %".380"
  %"shf_shift_64.7" = zext i32 5 to i64
  %".381" = lshr i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_hi.2" = lshr i64 %".381", 32
  %"shf_result.7" = trunc i64 %"shf_hi.2" to i32
  %".382" = zext i32 %"imad.27" to i64
  %".383" = zext i32 0 to i64
  %".384" = shl i64 %".383", 32
  %"shf_concat.8" = or i64 %".382", %".384"
  %"shf_shift_64.8" = zext i32 %"shf_result.7" to i64
  %".385" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".385" to i32
  %".386" = xor i32 %"lds.3", -1
  %".387" = xor i32 %"shf_result.8", -1
  %".388" = xor i32 0, -1
  %".389" = and i32 %"lds.3", %"shf_result.8"
  %".390" = and i32 %".389", %".388"
  %".391" = and i32 %"lds.3", %"shf_result.8"
  %".392" = and i32 %".391", 0
  %".393" = or i32 %".390", %".392"
  %"isetrp_cmp1.5" = icmp ne i32 %".393", %"shf_result.8"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.28" = add i32 %"imad_tmp.27", 1
  %".394" = zext i32 %"imad.28" to i64
  %".395" = zext i32 0 to i64
  %".396" = shl i64 %".395", 32
  %"shf_concat.9" = or i64 %".394", %".396"
  %"shf_shift_64.9" = zext i32 %"shf_result.7" to i64
  %".397" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".397" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.15" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0f50_0fe0", label %"BB_0dd0"
BB_0dd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".368", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".400" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".400" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".401" = xor i32 %"lds.4", -1
  %".402" = xor i32 %"shf_result.9", -1
  %".403" = xor i32 0, -1
  %".404" = and i32 %"lds.4", %"shf_result.9"
  %".405" = and i32 %".404", %".403"
  %".406" = and i32 %"lds.4", %"shf_result.9"
  %".407" = and i32 %".406", 0
  %".408" = or i32 %".405", %".407"
  %"isetrp_cmp1.6" = icmp ne i32 %".408", %"shf_result.9"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0e00"
BB_0e00:
  %"cond_trunc.16" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0f20_0fb0", label %"BB_0e10"
BB_0e10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".411" = xor i32 0, -1
  %".412" = xor i32 %"shf_result.9", -1
  %".413" = xor i32 0, -1
  %".414" = and i32 %".411", %".412"
  %".415" = and i32 %".414", %".413"
  %".416" = and i32 %".411", %".412"
  %".417" = and i32 %".416", 0
  %".418" = or i32 %".415", %".417"
  %".419" = and i32 0, %".412"
  %".420" = and i32 %".419", %".413"
  %".421" = or i32 %".418", %".420"
  %".422" = and i32 0, %".412"
  %".423" = and i32 %".422", 0
  %".424" = or i32 %".421", %".423"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".424", i32 %"redux_mask")
  %".425" = xor i32 0, -1
  %".426" = xor i32 %"shf_result.8", -1
  %".427" = xor i32 0, -1
  %".428" = and i32 %".425", %".426"
  %".429" = and i32 %".428", %".427"
  %".430" = and i32 %".425", %".426"
  %".431" = and i32 %".430", 0
  %".432" = or i32 %".429", %".431"
  %".433" = and i32 0, %".426"
  %".434" = and i32 %".433", %".427"
  %".435" = or i32 %".432", %".434"
  %".436" = and i32 0, %".426"
  %".437" = and i32 %".436", 0
  %".438" = or i32 %".435", %".437"
  %"imad_tmp.28" = mul i32 0, 0
  %"imad.29" = add i32 %"imad_tmp.28", %".438"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.29", i32 %"redux_mask.1")
  %".439" = xor i32 %".438", -1
  %".440" = call i32 @"llvm.cttz.i32"(i32 %".439", i1 0)
  %".441" = shl i32 %".440", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".441") convergent
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.29", %"redux_sync_and"
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.30", %"redux_sync_and.1"
  br label %"BB_0ee0"
BB_0ee0:
  %"cond_trunc.17" = trunc i32 %"P20_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000ee0", label %"BB_0f60"
BB_80000ee0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".368", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".445" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".445" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.31" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".368", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".446" = getelementptr inbounds [6160 x i8], [6160 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".446" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.30" monotonic
  br label %"BB_0f60"
BB_0f20_0fb0:
  call void @"llvm.trap"()
  br label %"BB_0f60"
BB_0f50_0fe0:
  call void @"llvm.trap"()
  br label %"BB_0f60"
BB_0f60:
  ret void
BB_80000ce0:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare <2 x half> @"llvm.fma.v2f16"(<2 x half> %".1", <2 x half> %".2", <2 x half> %".3")

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i32, i64)* @"_Z11dynamic_mmaILb1EEvjPj", !"kernel", i32 1 }
!2 = !{ void (i32, i64)* @"_Z11dynamic_mmaILb0EEvjPj", !"kernel", i32 1 }
