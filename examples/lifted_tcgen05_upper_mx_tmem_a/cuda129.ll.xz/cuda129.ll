; ModuleID = "tcgen05_upper_mx_tmem_a_sm100a_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [10256 x i8], align 16
define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"UR5:UR4_r0" = trunc i64 %"ldc_const" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x.1", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".24" = xor i32 %"imad", -1
  %".25" = xor i32 508, -1
  %".26" = xor i32 0, -1
  %".27" = and i32 %"imad", 508
  %".28" = and i32 %".27", %".26"
  %".29" = and i32 %"imad", 508
  %".30" = and i32 %".29", 0
  %".31" = or i32 %".28", %".30"
  %"iadd3_o1_64" = zext i32 %".31" to i64
  %"iadd3_o2_64" = zext i32 %"UR5:UR4_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR5:UR4_r1"
  %"imad_cin_trunc" = trunc i32 %"P1_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R11:R176_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R11:R176_addr_ptr"
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".32" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".33" = zext i32 %"iadd3_n2" to i64
  %".34" = zext i32 24 to i64
  %".35" = shl i64 %".32", %".34"
  %".36" = and i64 %".35", 4294967295
  %".37" = add i64 %".36", %".33"
  %".38" = trunc i64 %".37" to i32
  %"viadd" = add i32 %"imad", %".38"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd.1", %"BB_0140"]
  %"phi.1" = phi  i32 [%"viadd", %"EntryBB_0000"], [%"viadd.2", %"BB_0140"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P63_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".40" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".40" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0140"
BB_0140:
  %"cond_trunc" = trunc i32 %"P63_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0100", label %"BB_0150"
BB_0150:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0190"
BB_0190:
  %"cond_trunc.1" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01a0"
BB_01a0:
  %".46" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".47" = bitcast i8* %".46" to i64*
  %"ldc_const.1" = load i64, i64* %".47"
  %"R3:R2_r0" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".48" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".49" = zext i32 1024 to i64
  %".50" = zext i32 24 to i64
  %".51" = shl i64 %".48", %".50"
  %".52" = and i64 %".51", 4294967295
  %".53" = add i64 %".52", %".49"
  %".54" = trunc i64 %".53" to i32
  %"viadd.3" = add i32 %"imad", %".54"
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad.2" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P36_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0210"
BB_0210:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_01a0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.3" = phi  i32 [%"tid_x.1", %"BB_01a0"], [%"viadd.4", %"BB_0290"]
  %"phi.4" = phi  i32 [%"viadd.3", %"BB_01a0"], [%"viadd.5", %"BB_0290"]
  %"phi.5" = phi  i32 [%"iadd3_trunc.1", %"BB_01a0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.5" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R62:R8_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R62:R8_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.3", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.4" = add i32 %"phi.3", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.5" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P52_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P52_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.4", 16777215
  %".56" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".56" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.4", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P44_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.6" = phi  i32 [%"P22_to_i32", %"BB_0190"], [%"P44_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P8_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P54_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02d0"
BB_02d0:
  %"cond_trunc.3" = trunc i32 %"P54_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002d0", label %"BB_0320"
BB_800002d0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".62" = zext i32 %"iadd3_n2.2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat" = or i64 %".62", %".64"
  %"shf_shift_64" = zext i32 11 to i64
  %".65" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".65" to i32
  %".66" = zext i32 %"iadd3_n2.2" to i64
  %".67" = zext i32 0 to i64
  %".68" = shl i64 %".67", 32
  %"shf_concat.1" = or i64 %".66", %".68"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".69" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".69" to i32
  %".70" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".71" = zext i32 %"iadd3_n2.1" to i64
  %".72" = zext i32 24 to i64
  %".73" = shl i64 %".70", %".72"
  %".74" = and i64 %".73", 4294967295
  %".75" = add i64 %".74", %".71"
  %".76" = trunc i64 %".75" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.7" = phi  i32 [%".76", %"BB_800002d0"], [0, %"BB_02d0"]
  %"phi.8" = phi  i32 [%"shf_result", %"BB_800002d0"], [%"UR5:UR4_r1", %"BB_02d0"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_800002d0"], [1, %"BB_02d0"]
  %"vote_pred_trunc.1" = trunc i32 %"P8_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P57_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P17_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.4" = trunc i32 %"P57_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".81" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".81" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".82" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".82" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.5" = trunc i32 %"P17_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0650", label %"BB_0370"
BB_0370:
  %".86" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".87" = zext i32 64 to i64
  %".88" = zext i32 24 to i64
  %".89" = shl i64 %".86", %".88"
  %".90" = and i64 %".89", 4294967295
  %".91" = add i64 %".90", %".87"
  %".92" = trunc i64 %".91" to i32
  %"lds_shared_addr_winoff" = and i32 %".92", 16777215
  %".93" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".93"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.6" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_05e0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".96" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".97" = ptrtoint i8 addrspace(3)* %".96" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".97", i32 512) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P19_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.7" = trunc i32 %"P19_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.7", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0650", label %"BB_0400"
BB_0400:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 1
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", 65535
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".101" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P59_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P59_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".105" = xor i32 %"plop3_a_bit", 1
  %".106" = xor i32 %"plop3_b_bit", 1
  %".107" = xor i32 %"plop3_c_bit", 1
  %".108" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".109" = and i32 %".108", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".109", 0
  %"P20_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P20_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".104"
  br label %"BB_0490"
BB_0490:
  %"cond_trunc.8" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0530", label %"BB_04a0"
BB_04a0:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".112" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".113" = bitcast i8 addrspace(3)* %".112" to i32 addrspace(3)*
  %".114" = load i32, i32 addrspace(3)* %".113"
  %".115" = lshr i32 %".114", 5
  %"P60_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P60_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".116" = xor i32 %"plop3_a_bit.1", 1
  %".117" = xor i32 %"plop3_b_bit.1", 1
  %".118" = xor i32 %"plop3_c_bit.1", 1
  %".119" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".120" = and i32 %".119", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".120", 0
  %"P5_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", %".115"
  br label %"BB_0520"
BB_0520:
  %"cond_trunc.9" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_04a0", label %"BB_0530"
BB_0530:
  %"phi.10" = phi  i32 [%"imad.7", %"BB_0490"], [%"imad.8", %"BB_0520"]
  %"viadd.6" = add i32 %"phi.10", 16
  %".123" = zext i32 %"imad.6" to i64
  %".124" = zext i32 0 to i64
  %".125" = shl i64 %".124", 32
  %"shf_concat.2" = or i64 %".123", %".125"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".126" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".126" to i32
  %".127" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %"imad_tmp.8" = mul i32 %"phi.10", 32
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %".134" = zext i32 %"imad.5" to i64
  %".135" = zext i32 0 to i64
  %".136" = shl i64 %".135", 32
  %"shf_concat.3" = or i64 %".134", %".136"
  %"shf_shift_64.3" = zext i32 %"viadd.6" to i64
  %".137" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".137" to i32
  %".138" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".139" = zext i32 1024 to i64
  %".140" = zext i32 24 to i64
  %".141" = shl i64 %".138", %".140"
  %".142" = and i64 %".141", 4294967295
  %".143" = add i64 %".142", %".139"
  %".144" = trunc i64 %".143" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".144", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.9", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0650"
BB_05e0:
  %".169" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".170" = zext i32 1024 to i64
  %".171" = zext i32 24 to i64
  %".172" = shl i64 %".169", %".171"
  %".173" = and i64 %".172", 4294967295
  %".174" = add i64 %".173", %".170"
  %".175" = trunc i64 %".174" to i32
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.9", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".175", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".176" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".176" to i32 addrspace(3)*
  store volatile i32 %"imad.10", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0620_1250"
BB_0620_1250:
  call void @"llvm.trap"()
  br label %"BB_0650"
BB_0650:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P55_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".180" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".181" = bitcast i8* %".180" to i64*
  %"ldc_const.2" = load i64, i64* %".181"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.10" = mul i32 %"tid_x.1", 18
  %"imad.11" = add i32 %"imad_tmp.10", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.11" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.12" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.12" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.12", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R100:R80_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R100:R80_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R100:R80_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R100:R80_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R100:R80_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R100:R80_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R100:R80_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R100:R80_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.11" = mul i32 %"tid_x.1", 65536
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %".182" = xor i32 %"imad.13", -1
  %".183" = xor i32 65011712, -1
  %".184" = xor i32 0, -1
  %".185" = and i32 %"imad.13", 65011712
  %".186" = and i32 %".185", %".184"
  %".187" = and i32 %"imad.13", 65011712
  %".188" = and i32 %".187", 0
  %".189" = or i32 %".186", %".188"
  %".190" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".191" = zext i32 1024 to i64
  %".192" = zext i32 24 to i64
  %".193" = shl i64 %".190", %".192"
  %".194" = and i64 %".193", 4294967295
  %".195" = add i64 %".194", %".191"
  %".196" = trunc i64 %".195" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".197" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".197" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.12" = mul i32 %"lds.1", 1
  %"imad.14" = add i32 %"imad_tmp.12", %".189"
  %"sttm_memaddr_offset_add" = add i32 %"imad.14", 272
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.14", 276
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R100:R80_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R100:R80_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R100:R80_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R100:R80_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R100:R80_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R100:R80_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R100:R80_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R100:R80_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.14", 256
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.14", 260
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0900"
BB_0900:
  %"cond_trunc.10" = trunc i32 %"P55_to_i32" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0c60", label %"BB_0910"
BB_0910:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".207" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".207" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".208" = xor i32 %"plop3_a_bit.2", 1
  %".209" = xor i32 %"plop3_b_bit.2", 1
  %".210" = xor i32 %"plop3_c_bit.2", 1
  %".211" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".212" = and i32 %".211", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".212", 0
  %"P61_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".213" = zext i32 0 to i64
  %".214" = zext i32 %".196" to i64
  %".215" = shl i64 %".214", 32
  %"shf_concat.4" = or i64 %".213", %".215"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".216" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".216", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".217" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".218" = zext i32 %"iadd3_n2.3" to i64
  %".219" = zext i32 24 to i64
  %".220" = shl i64 %".217", %".219"
  %".221" = and i64 %".220", 4294967295
  %".222" = add i64 %".221", %".218"
  %".223" = trunc i64 %".222" to i32
  %".224" = xor i32 %"shf_result.4", -1
  %".225" = xor i32 16376, -1
  %".226" = xor i32 0, -1
  %".227" = and i32 %"shf_result.4", 16376
  %".228" = and i32 %".227", %".226"
  %".229" = and i32 %"shf_result.4", 16376
  %".230" = and i32 %".229", 0
  %".231" = or i32 %".228", %".230"
  %".232" = zext i32 0 to i64
  %".233" = zext i32 %".223" to i64
  %".234" = shl i64 %".233", 32
  %"shf_concat.5" = or i64 %".232", %".234"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".235" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".235", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".236" = xor i32 %".231", -1
  %".237" = xor i32 524288, -1
  %".238" = xor i32 0, -1
  %".239" = and i32 %".236", 524288
  %".240" = and i32 %".239", %".238"
  %".241" = and i32 %".236", 524288
  %".242" = and i32 %".241", 0
  %".243" = or i32 %".240", %".242"
  %".244" = and i32 %".231", %".237"
  %".245" = and i32 %".244", %".238"
  %".246" = or i32 %".243", %".245"
  %".247" = and i32 %".231", %".237"
  %".248" = and i32 %".247", 0
  %".249" = or i32 %".246", %".248"
  %".250" = and i32 %".231", 524288
  %".251" = and i32 %".250", %".238"
  %".252" = or i32 %".249", %".251"
  %".253" = and i32 %".231", 524288
  %".254" = and i32 %".253", 0
  %".255" = or i32 %".252", %".254"
  %".256" = xor i32 %"shf_result.5", -1
  %".257" = xor i32 16376, -1
  %".258" = xor i32 0, -1
  %".259" = and i32 %"shf_result.5", 16376
  %".260" = and i32 %".259", %".258"
  %".261" = and i32 %"shf_result.5", 16376
  %".262" = and i32 %".261", 0
  %".263" = or i32 %".260", %".262"
  %".264" = xor i32 %".263", -1
  %".265" = xor i32 524288, -1
  %".266" = xor i32 0, -1
  %".267" = and i32 %".264", 524288
  %".268" = and i32 %".267", %".266"
  %".269" = and i32 %".264", 524288
  %".270" = and i32 %".269", 0
  %".271" = or i32 %".268", %".270"
  %".272" = and i32 %".263", %".265"
  %".273" = and i32 %".272", %".266"
  %".274" = or i32 %".271", %".273"
  %".275" = and i32 %".263", %".265"
  %".276" = and i32 %".275", 0
  %".277" = or i32 %".274", %".276"
  %".278" = and i32 %".263", 524288
  %".279" = and i32 %".278", %".266"
  %".280" = or i32 %".277", %".279"
  %".281" = and i32 %".263", 524288
  %".282" = and i32 %".281", 0
  %".283" = or i32 %".280", %".282"
  %"iadd3_n1.4" = add i32 %"lds.2", 272
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_0a10"
BB_0a10:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0910"], [%"P51_to_i32", %"BB_0a40"]
  %"phi.12" = phi  i32 [%"P61_to_i32", %"BB_0910"], [%"phi.14", %"BB_0a40"]
  %"cond_trunc.11" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P48_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.13" = phi  i32 [%"P48_to_i32", %"BB_80000a10"], [%"phi.11", %"BB_0a10"]
  %"mma_b_r0_ext" = zext i32 %".283" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".287" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".288" = sub i64 %".287", 0
  %".289" = lshr i64 %".288", 4
  %".290" = add i64 %"mma_b_packed_1", %".289"
  %".291" = and i64 %".290", 16383
  %".292" = and i64 %"mma_b_packed_1", -16384
  %".293" = or i64 %".292", %".291"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".293", i32 138416272, i32 %"mma_arg_zext")
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.12" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000a30", label %"BB_0a40"
BB_80000a30:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".297" = xor i32 %"plop3_a_bit.3", 1
  %".298" = xor i32 %"plop3_b_bit.3", 1
  %".299" = xor i32 %"plop3_c_bit.3", 1
  %".300" = and i32 %".297", %"plop3_b_bit.3"
  %".301" = and i32 %".300", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".301", 0
  %"P10_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.14" = phi  i32 [%"P10_to_i32", %"BB_80000a30"], [%"phi.12", %"BB_0a30"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".303" = xor i32 %"plop3_a_bit.4", 1
  %".304" = xor i32 %"plop3_b_bit.4", 1
  %".305" = xor i32 %"plop3_c_bit.4", 1
  %".306" = and i32 %".303", %"plop3_b_bit.4"
  %".307" = and i32 %".306", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".307", 0
  %"P51_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0a10", label %"BB_0a60"
BB_0a60:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".309" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".309" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".310" = xor i32 %"plop3_a_bit.5", 1
  %".311" = xor i32 %"plop3_b_bit.5", 1
  %".312" = xor i32 %"plop3_c_bit.5", 1
  %".313" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".314" = and i32 %".313", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".314", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"iadd3_n1.5" = add i32 %"lds.3", 272
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.3", 256
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"lds.3", 260
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  br label %"BB_0ae0"
BB_0ae0:
  %"phi.15" = phi  i32 [%"P51_to_i32", %"BB_0a60"], [%"P27_to_i32", %"BB_0b10"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0a60"], [%"phi.18", %"BB_0b10"]
  %"cond_trunc.13" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000ae0", label %"BB_0af0"
BB_80000ae0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P25_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0af0"
BB_0af0:
  %"phi.17" = phi  i32 [%"P25_to_i32", %"BB_80000ae0"], [%"phi.15", %"BB_0ae0"]
  %"mma_b_r0_ext.1" = zext i32 %".255" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".318" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".319" = sub i64 %".318", 0
  %".320" = lshr i64 %".319", 4
  %".321" = add i64 %"mma_b_packed_1.1", %".320"
  %".322" = and i64 %".321", 16383
  %".323" = and i64 %"mma_b_packed_1.1", -16384
  %".324" = or i64 %".323", %".322"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.5", i64 %".324", i32 679743664, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.6", i32 %"iadd3_n2.7")
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.14" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000b00", label %"BB_0b10"
BB_80000b00:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".328" = xor i32 %"plop3_a_bit.6", 1
  %".329" = xor i32 %"plop3_b_bit.6", 1
  %".330" = xor i32 %"plop3_c_bit.6", 1
  %".331" = and i32 %".328", %"plop3_b_bit.6"
  %".332" = and i32 %".331", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".332", 0
  %"P58_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_0b10"
BB_0b10:
  %"phi.18" = phi  i32 [%"P58_to_i32", %"BB_80000b00"], [%"phi.16", %"BB_0b00"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".334" = xor i32 %"plop3_a_bit.7", 1
  %".335" = xor i32 %"plop3_b_bit.7", 1
  %".336" = xor i32 %"plop3_c_bit.7", 1
  %".337" = and i32 %".334", %"plop3_b_bit.7"
  %".338" = and i32 %".337", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".338", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0ae0", label %"BB_0b30"
BB_0b30:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".340" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".340" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".341" = xor i32 %"plop3_a_bit.8", 1
  %".342" = xor i32 %"plop3_b_bit.8", 1
  %".343" = xor i32 %"plop3_c_bit.8", 1
  %".344" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".345" = and i32 %".344", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".345", 0
  %"P12_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"iadd3_n1.8" = add i32 %"lds.4", 272
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"lds.4", 256
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"iadd3_n1.10" = add i32 %"lds.4", 260
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  br label %"BB_0b90"
BB_0b90:
  %"phi.19" = phi  i32 [%"P27_to_i32", %"BB_0b30"], [%"P32_to_i32", %"BB_0bc0"]
  %"phi.20" = phi  i32 [%"P12_to_i32", %"BB_0b30"], [%"phi.22", %"BB_0bc0"]
  %"cond_trunc.15" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P29_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.21" = phi  i32 [%"P29_to_i32", %"BB_80000b90"], [%"phi.19", %"BB_0b90"]
  %"mma_b_r0_ext.2" = zext i32 %".255" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".349" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".350" = sub i64 %".349", 0
  %".351" = lshr i64 %".350", 4
  %".352" = add i64 %"mma_b_packed_1.2", %".351"
  %".353" = and i64 %".352", 16383
  %".354" = and i64 %"mma_b_packed_1.2", -16384
  %".355" = or i64 %".354", %".353"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.4", i32 %"iadd3_n2.8", i64 %".355", i32 679743664, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.9", i32 %"iadd3_n2.10")
  br label %"BB_0bb0"
BB_0bb0:
  %"cond_trunc.16" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000bb0", label %"BB_0bc0"
BB_80000bb0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".359" = xor i32 %"plop3_a_bit.9", 1
  %".360" = xor i32 %"plop3_b_bit.9", 1
  %".361" = xor i32 %"plop3_c_bit.9", 1
  %".362" = and i32 %".359", %"plop3_b_bit.9"
  %".363" = and i32 %".362", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".363", 0
  %"P34_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"phi.22" = phi  i32 [%"P34_to_i32", %"BB_80000bb0"], [%"phi.20", %"BB_0bb0"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".365" = xor i32 %"plop3_a_bit.10", 1
  %".366" = xor i32 %"plop3_b_bit.10", 1
  %".367" = xor i32 %"plop3_c_bit.10", 1
  %".368" = and i32 %".365", %"plop3_b_bit.10"
  %".369" = and i32 %".368", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".369", 0
  %"P32_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0b90", label %"BB_0be0"
BB_0be0:
  %"iadd3_n1.11" = add i32 1024, 9216
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".371" = xor i32 %"plop3_a_bit.11", 1
  %".372" = xor i32 %"plop3_b_bit.11", 1
  %".373" = xor i32 %"plop3_c_bit.11", 1
  %".374" = and i32 %"plop3_a_bit.11", %"plop3_b_bit.11"
  %".375" = and i32 %".374", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".375", 0
  %"P56_to_i32" = zext i1 %"plop3_pred.11" to i32
  %".376" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".377" = zext i32 %"iadd3_n2.11" to i64
  %".378" = zext i32 24 to i64
  %".379" = shl i64 %".376", %".378"
  %".380" = and i64 %".379", 4294967295
  %".381" = add i64 %".380", %".377"
  %".382" = trunc i64 %".381" to i32
  br label %"BB_0c10"
BB_0c10:
  %"phi.23" = phi  i32 [%"P32_to_i32", %"BB_0be0"], [%"P38_to_i32", %"BB_0c40"]
  %"phi.24" = phi  i32 [%"P56_to_i32", %"BB_0be0"], [%"phi.26", %"BB_0c40"]
  %"cond_trunc.17" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000c10", label %"BB_0c20"
BB_80000c10:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P35_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0c20"
BB_0c20:
  %"phi.25" = phi  i32 [%"P35_to_i32", %"BB_80000c10"], [%"phi.23", %"BB_0c10"]
  %"utcbar_local_winoff" = and i32 %".382", 16777215
  %".386" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".387" = ptrtoint i8 addrspace(3)* %".386" to i32
  %".388" = lshr i32 %".382", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".387", i32 %".388")
  br label %"BB_0c30"
BB_0c30:
  %"cond_trunc.18" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c30", label %"BB_0c40"
BB_80000c30:
  %"lop3_a_trunc.3" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.12" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".392" = xor i32 %"plop3_a_bit.12", 1
  %".393" = xor i32 %"plop3_b_bit.12", 1
  %".394" = xor i32 %"plop3_c_bit.12", 1
  %".395" = and i32 %".392", %"plop3_b_bit.12"
  %".396" = and i32 %".395", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".396", 0
  %"P65_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_0c40"
BB_0c40:
  %"phi.26" = phi  i32 [%"P65_to_i32", %"BB_80000c30"], [%"phi.24", %"BB_0c30"]
  %"lop3_a_cast_zext.13" = zext i1 1 to i32
  %"lop3_b_cast_zext.13" = zext i1 1 to i32
  %"lop3_c_cast_zext.13" = zext i1 1 to i32
  %"plop3_a_bit.13" = and i32 %"lop3_a_cast_zext.13", 1
  %"plop3_b_bit.13" = and i32 %"lop3_b_cast_zext.13", 1
  %"plop3_c_bit.13" = and i32 %"lop3_c_cast_zext.13", 1
  %".398" = xor i32 %"plop3_a_bit.13", 1
  %".399" = xor i32 %"plop3_b_bit.13", 1
  %".400" = xor i32 %"plop3_c_bit.13", 1
  %".401" = and i32 %".398", %"plop3_b_bit.13"
  %".402" = and i32 %".401", %"plop3_c_bit.13"
  %"plop3_pred.13" = icmp ne i32 %".402", 0
  %"P38_to_i32" = zext i1 %"plop3_pred.13" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.3", label %"BB_0c10", label %"BB_0c60"
BB_0c60:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.12" = add i32 1024, 9216
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", 0
  %".404" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".405" = zext i32 %"iadd3_n2.12" to i64
  %".406" = zext i32 24 to i64
  %".407" = shl i64 %".404", %".406"
  %".408" = and i64 %".407", 4294967295
  %".409" = add i64 %".408", %".405"
  %".410" = trunc i64 %".409" to i32
  %".411" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".412" = bitcast i8* %".411" to i64*
  %"ldc_const.3" = load i64, i64* %".412"
  %"R5:R4_r0" = trunc i64 %"ldc_const.3" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"mbar_shared_winoff.1" = and i32 %".410", 16777215
  %".413" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".413" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P4_to_i32" = zext i1 %"mbar_ready" to i32
  %"imad_addend_r0_ext.2" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64.2" = zext i32 1056 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.15" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R5:R4_r0.1" = trunc i64 %"imad.15" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.15", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.3" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.3" = zext i32 16 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P39_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  br label %"BB_0ce0"
BB_0ce0:
  %"cond_trunc.19" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_11f0", label %"BB_0cf0"
BB_11f0:
  %"mbar_shared_winoff.2" = and i32 %".410", 16777215
  %".416" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".416" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P6_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1200"
BB_1200:
  %"cond_trunc.20" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.20", -1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_11f0", label %"BB_0cf0"
BB_0cf0:
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 4
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"R5:R4_r1.1"
  %"imad_cin_trunc.3" = trunc i32 %"P39_to_i32" to i1
  %"imad_cin_ext.3" = zext i1 %"imad_cin_trunc.3" to i32
  %"imad_with_cin.3" = add i32 %"imad.17", %"imad_cin_ext.3"
  br label %"BB_0d20"
BB_0d20:
  %"phi.27" = phi  i32 [%"imad.16", %"BB_0cf0"], [%"viadd.8", %"BB_0f20"]
  %"phi.28" = phi  i32 [%"imad_with_cin.3", %"BB_0cf0"], [%"imad_with_cin.4", %"BB_0f20"]
  %"phi.29" = phi  i32 [%"iadd3_trunc.3", %"BB_0cf0"], [%"iadd3_trunc.4", %"BB_0f20"]
  %"viadd.7" = add i32 %"phi.27", 4294967292
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", 240
  %"isetrp_cmp1.9" = icmp uge i32 %"viadd.7", 24
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"isetrp_cmp1.10" = icmp uge i32 %"viadd.7", 20
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P53_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"isetrp_cmp1.11" = icmp uge i32 %"viadd.7", 16
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"sel_pred_trunc.2" = trunc i32 %"P41_to_i32" to i1
  %"sel_pred_not.2" = xor i1 %"sel_pred_trunc.2", -1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_not.2" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 %"imad.18", i32 4294967288
  %"isetrp_cmp1.12" = icmp uge i32 %"viadd.7", 12
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"sel_pred_trunc.3" = trunc i32 %"P53_to_i32" to i1
  %"sel_pred_not.3" = xor i1 %"sel_pred_trunc.3", -1
  %"sel_pred_to_i32.3" = zext i1 %"sel_pred_not.3" to i32
  %"sel_pred_to_i1.3" = icmp ne i32 %"sel_pred_to_i32.3", 0
  %"sel.3" = select  i1 %"sel_pred_to_i1.3", i32 %"imad.18", i32 4294967288
  %"sel_pred_trunc.4" = trunc i32 %"P7_to_i32" to i1
  %"sel_pred_to_i32.4" = zext i1 %"sel_pred_trunc.4" to i32
  %"sel_pred_to_i1.4" = icmp ne i32 %"sel_pred_to_i32.4", 0
  %"sel.4" = select  i1 %"sel_pred_to_i1.4", i32 %"sel.2", i32 0
  %"sel_pred_trunc.5" = trunc i32 %"P42_to_i32" to i1
  %"sel_pred_to_i32.5" = zext i1 %"sel_pred_trunc.5" to i32
  %"sel_pred_to_i1.5" = icmp ne i32 %"sel_pred_to_i32.5", 0
  %"sel.5" = select  i1 %"sel_pred_to_i1.5", i32 %"sel.3", i32 0
  %"iadd3_n1.13" = add i32 %"phi.27", %"imad.14"
  %"iadd3_n2.13" = add i32 %"iadd3_n1.13", %"sel.4"
  %"iadd3_n1.14" = add i32 %"phi.27", %"imad.14"
  %"iadd3_n2.14" = add i32 %"iadd3_n1.14", %"sel.5"
  %"viadd.8" = add i32 %"phi.27", 8
  %"isetrp_cmp1.13" = icmp uge i32 %"viadd.7", 256
  %"isetrp_src_to_i32.13" = zext i1 1 to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"iadd3_o1_64.4" = zext i32 %"phi.29" to i64
  %"iadd3_o2_64.4" = zext i32 32 to i64
  %"iadd3_o3_64.4" = zext i32 0 to i64
  %"iadd3_tmp.4" = add i64 %"iadd3_o1_64.4", %"iadd3_o2_64.4"
  %"iadd3_tmp2.4" = add i64 %"iadd3_tmp.4", %"iadd3_o3_64.4"
  %"iadd3_trunc.4" = trunc i64 %"iadd3_tmp2.4" to i32
  %"iadd3_carry_val.4" = lshr i64 %"iadd3_tmp2.4", 32
  %"carry_ge_1.4" = icmp uge i64 %"iadd3_carry_val.4", 1
  %"P43_to_i32" = zext i1 %"carry_ge_1.4" to i32
  %"carry_ge_2.4" = icmp uge i64 %"iadd3_carry_val.4", 2
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.16", %"phi.28"
  %"imad_cin_trunc.4" = trunc i32 %"P43_to_i32" to i1
  %"imad_cin_ext.4" = zext i1 %"imad_cin_trunc.4" to i32
  %"imad_with_cin.4" = add i32 %"imad.19", %"imad_cin_ext.4"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"iadd3_n2.13", -4
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".420" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".421" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".422" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".423" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"iadd3_n2.14")
  %".424" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".425" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".426" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".427" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"stg_addr_r0_ext" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1", -16
  %"R148:R137_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".420", i32 addrspace(1)* %"R148:R137_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.1", -12
  %"R148:R137_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".421", i32 addrspace(1)* %"R148:R137_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.2", -8
  %"R148:R137_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".422", i32 addrspace(1)* %"R148:R137_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.3", -4
  %"R148:R137_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".423", i32 addrspace(1)* %"R148:R137_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"R148:R137_addr_ptr.4" = inttoptr i64 %"stg_addr_packed_1.4" to i32 addrspace(1)*
  store i32 %".424", i32 addrspace(1)* %"R148:R137_addr_ptr.4"
  %"stg_addr_r0_ext.5" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 4
  %"R148:R137_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".425", i32 addrspace(1)* %"R148:R137_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 8
  %"R148:R137_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".426", i32 addrspace(1)* %"R148:R137_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 12
  %"R148:R137_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".427", i32 addrspace(1)* %"R148:R137_addr_ptr.7"
  br label %"BB_0f20"
BB_0f20:
  %"cond_trunc.21" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0d20", label %"BB_0f30"
BB_0f30:
  call void @"llvm.nvvm.barrier0"()
  %"isetrp_cmp1.14" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.14" = zext i1 1 to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  br label %"BB_0f50"
BB_0f50:
  %"cond_trunc.22" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000f50", label %"BB_0f60"
BB_0f60:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".440" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".440" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.17", 65535
  %".441" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".442" = zext i32 80 to i64
  %".443" = zext i32 24 to i64
  %".444" = shl i64 %".441", %".443"
  %".445" = and i64 %".444", 4294967295
  %".446" = add i64 %".445", %".442"
  %".447" = trunc i64 %".446" to i32
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.18", 1
  %"lds_shared_addr_winoff.6" = and i32 %".447", 16777215
  %".448" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".448" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".449" = xor i32 %"lds.5", -1
  %".450" = xor i32 65535, -1
  %".451" = xor i32 0, -1
  %".452" = and i32 %"lds.5", 65535
  %".453" = and i32 %".452", %".451"
  %".454" = and i32 %"lds.5", 65535
  %".455" = and i32 %".454", 0
  %".456" = or i32 %".453", %".455"
  %".457" = zext i32 0 to i64
  %".458" = zext i32 %".456" to i64
  %".459" = shl i64 %".458", 32
  %"shf_concat.6" = or i64 %".457", %".459"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".460" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".460", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.9" = add i32 %"shf_result.6", 16
  %".461" = zext i32 %"imad.20" to i64
  %".462" = zext i32 0 to i64
  %".463" = shl i64 %".462", 32
  %"shf_concat.7" = or i64 %".461", %".463"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".464" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".464" to i32
  %".465" = zext i32 %"imad.21" to i64
  %".466" = zext i32 0 to i64
  %".467" = shl i64 %".466", 32
  %"shf_concat.8" = or i64 %".465", %".467"
  %"shf_shift_64.8" = zext i32 %"viadd.9" to i64
  %".468" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".468" to i32
  %".469" = xor i32 %"shf_result.8", -1
  %".470" = xor i32 %"shf_result.7", -1
  %".471" = xor i32 0, -1
  %".472" = and i32 %".469", %"shf_result.7"
  %".473" = and i32 %".472", %".471"
  %".474" = and i32 %".469", %"shf_result.7"
  %".475" = and i32 %".474", 0
  %".476" = or i32 %".473", %".475"
  %".477" = and i32 %"shf_result.8", %".470"
  %".478" = and i32 %".477", %".471"
  %".479" = or i32 %".476", %".478"
  %".480" = and i32 %"shf_result.8", %".470"
  %".481" = and i32 %".480", 0
  %".482" = or i32 %".479", %".481"
  %".483" = and i32 %"shf_result.8", %"shf_result.7"
  %".484" = and i32 %".483", %".471"
  %".485" = or i32 %".482", %".484"
  %".486" = and i32 %"shf_result.8", %"shf_result.7"
  %".487" = and i32 %".486", 0
  %".488" = or i32 %".485", %".487"
  %".489" = xor i32 %".488", -1
  %".490" = xor i32 65535, -1
  %".491" = xor i32 0, -1
  %".492" = and i32 %".488", 65535
  %".493" = and i32 %".492", %".491"
  %".494" = and i32 %".488", 65535
  %".495" = and i32 %".494", 0
  %".496" = or i32 %".493", %".495"
  %".497" = xor i32 %".488", -1
  %".498" = xor i32 65535, -1
  %".499" = xor i32 %"lds.6", -1
  %".500" = and i32 %".488", 65535
  %".501" = and i32 %".500", %"lds.6"
  %"isetrp_cmp1.15" = icmp ne i32 %".501", %".496"
  %"isetrp_src_to_i32.15" = zext i1 1 to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  br label %"BB_1060"
BB_1060:
  %"cond_trunc.23" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_11c0_1280", label %"BB_1070"
BB_1070:
  %".504" = zext i32 0 to i64
  %".505" = zext i32 %"lds.6" to i64
  %".506" = shl i64 %".505", 32
  %"shf_concat.9" = or i64 %".504", %".506"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".507" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".507", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".508" = zext i32 0 to i64
  %".509" = zext i32 %".488" to i64
  %".510" = shl i64 %".509", 32
  %"shf_concat.10" = or i64 %".508", %".510"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".511" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".511", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".512" = xor i32 %"shf_result.9", -1
  %".513" = xor i32 %"shf_result.10", -1
  %".514" = xor i32 0, -1
  %".515" = and i32 %"shf_result.9", %"shf_result.10"
  %".516" = and i32 %".515", %".514"
  %".517" = and i32 %"shf_result.9", %"shf_result.10"
  %".518" = and i32 %".517", 0
  %".519" = or i32 %".516", %".518"
  %"isetrp_cmp1.16" = icmp ne i32 %".519", %"shf_result.10"
  %"isetrp_src_to_i32.16" = zext i1 1 to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  br label %"BB_10b0"
BB_10b0:
  %"cond_trunc.24" = trunc i32 %"P14_to_i32" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_1190_1220", label %"BB_10c0"
BB_10c0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".522" = xor i32 0, -1
  %".523" = xor i32 %".488", -1
  %".524" = xor i32 0, -1
  %".525" = and i32 %".522", %".523"
  %".526" = and i32 %".525", %".524"
  %".527" = and i32 %".522", %".523"
  %".528" = and i32 %".527", 0
  %".529" = or i32 %".526", %".528"
  %".530" = and i32 0, %".523"
  %".531" = and i32 %".530", %".524"
  %".532" = or i32 %".529", %".531"
  %".533" = and i32 0, %".523"
  %".534" = and i32 %".533", 0
  %".535" = or i32 %".532", %".534"
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.19", %".535"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.22", i32 %"redux_mask")
  %".536" = xor i32 %".535", -1
  %".537" = call i32 @"llvm.cttz.i32"(i32 %".536", i1 0)
  %".538" = shl i32 %".537", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 512;", "r,~{memory}"(i32 %".538") convergent
  %"isetrp_cmp1.17" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.17" = zext i1 1 to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.20", %"redux_sync_and"
  br label %"BB_1160"
BB_1160:
  %"cond_trunc.25" = trunc i32 %"P15_to_i32" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80001160", label %"BB_11d0"
BB_80001160:
  %"atoms_shared_addr_winoff.1" = and i32 %".447", 16777215
  %".542" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".542" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.23" monotonic
  br label %"BB_11d0"
BB_1190_1220:
  call void @"llvm.trap"()
  br label %"BB_11d0"
BB_11c0_1280:
  call void @"llvm.trap"()
  br label %"BB_11d0"
BB_11d0:
  ret void
BB_80000f50:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"UR5:UR4_r0" = trunc i64 %"ldc_const" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x.1", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".24" = xor i32 %"imad", -1
  %".25" = xor i32 508, -1
  %".26" = xor i32 0, -1
  %".27" = and i32 %"imad", 508
  %".28" = and i32 %".27", %".26"
  %".29" = and i32 %"imad", 508
  %".30" = and i32 %".29", 0
  %".31" = or i32 %".28", %".30"
  %"iadd3_o1_64" = zext i32 %".31" to i64
  %"iadd3_o2_64" = zext i32 %"UR5:UR4_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR5:UR4_r1"
  %"imad_cin_trunc" = trunc i32 %"P1_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R11:R176_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R11:R176_addr_ptr"
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".32" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".33" = zext i32 %"iadd3_n2" to i64
  %".34" = zext i32 24 to i64
  %".35" = shl i64 %".32", %".34"
  %".36" = and i64 %".35", 4294967295
  %".37" = add i64 %".36", %".33"
  %".38" = trunc i64 %".37" to i32
  %"viadd" = add i32 %"imad", %".38"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd.1", %"BB_0140"]
  %"phi.1" = phi  i32 [%"viadd", %"EntryBB_0000"], [%"viadd.2", %"BB_0140"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P63_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".40" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".40" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0140"
BB_0140:
  %"cond_trunc" = trunc i32 %"P63_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0100", label %"BB_0150"
BB_0150:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0190"
BB_0190:
  %"cond_trunc.1" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01a0"
BB_01a0:
  %".46" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".47" = bitcast i8* %".46" to i64*
  %"ldc_const.1" = load i64, i64* %".47"
  %"R3:R2_r0" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".48" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".49" = zext i32 1024 to i64
  %".50" = zext i32 24 to i64
  %".51" = shl i64 %".48", %".50"
  %".52" = and i64 %".51", 4294967295
  %".53" = add i64 %".52", %".49"
  %".54" = trunc i64 %".53" to i32
  %"viadd.3" = add i32 %"imad", %".54"
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad.2" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P36_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0210"
BB_0210:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_01a0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.3" = phi  i32 [%"tid_x.1", %"BB_01a0"], [%"viadd.4", %"BB_0290"]
  %"phi.4" = phi  i32 [%"viadd.3", %"BB_01a0"], [%"viadd.5", %"BB_0290"]
  %"phi.5" = phi  i32 [%"iadd3_trunc.1", %"BB_01a0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.5" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R62:R8_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R62:R8_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.3", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.4" = add i32 %"phi.3", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.5" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P52_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P52_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.4", 16777215
  %".56" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".56" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.4", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P44_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.6" = phi  i32 [%"P22_to_i32", %"BB_0190"], [%"P44_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P8_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P54_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02d0"
BB_02d0:
  %"cond_trunc.3" = trunc i32 %"P54_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002d0", label %"BB_0320"
BB_800002d0:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".62" = zext i32 %"iadd3_n2.2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat" = or i64 %".62", %".64"
  %"shf_shift_64" = zext i32 11 to i64
  %".65" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".65" to i32
  %".66" = zext i32 %"iadd3_n2.2" to i64
  %".67" = zext i32 0 to i64
  %".68" = shl i64 %".67", 32
  %"shf_concat.1" = or i64 %".66", %".68"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".69" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".69" to i32
  %".70" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".71" = zext i32 %"iadd3_n2.1" to i64
  %".72" = zext i32 24 to i64
  %".73" = shl i64 %".70", %".72"
  %".74" = and i64 %".73", 4294967295
  %".75" = add i64 %".74", %".71"
  %".76" = trunc i64 %".75" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.7" = phi  i32 [%".76", %"BB_800002d0"], [0, %"BB_02d0"]
  %"phi.8" = phi  i32 [%"shf_result", %"BB_800002d0"], [%"UR5:UR4_r1", %"BB_02d0"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_800002d0"], [1, %"BB_02d0"]
  %"vote_pred_trunc.1" = trunc i32 %"P8_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P57_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P17_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.4" = trunc i32 %"P57_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".81" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".81" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".82" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".82" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.5" = trunc i32 %"P17_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0650", label %"BB_0370"
BB_0370:
  %".86" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".87" = zext i32 64 to i64
  %".88" = zext i32 24 to i64
  %".89" = shl i64 %".86", %".88"
  %".90" = and i64 %".89", 4294967295
  %".91" = add i64 %".90", %".87"
  %".92" = trunc i64 %".91" to i32
  %"lds_shared_addr_winoff" = and i32 %".92", 16777215
  %".93" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".93"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.6" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_05e0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 10248, 16777215
  %".96" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".97" = ptrtoint i8 addrspace(3)* %".96" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".97", i32 512) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P19_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.7" = trunc i32 %"P19_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.7", -1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0650", label %"BB_0400"
BB_0400:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 1
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", 65535
  %"tmem_alloc_winoff" = and i32 10248, 16777215
  %".101" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P59_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P59_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".105" = xor i32 %"plop3_a_bit", 1
  %".106" = xor i32 %"plop3_b_bit", 1
  %".107" = xor i32 %"plop3_c_bit", 1
  %".108" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".109" = and i32 %".108", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".109", 0
  %"P20_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P20_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".104"
  br label %"BB_0490"
BB_0490:
  %"cond_trunc.8" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0530", label %"BB_04a0"
BB_04a0:
  %"tmem_alloc_winoff.1" = and i32 10248, 16777215
  %".112" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".113" = bitcast i8 addrspace(3)* %".112" to i32 addrspace(3)*
  %".114" = load i32, i32 addrspace(3)* %".113"
  %".115" = lshr i32 %".114", 5
  %"P60_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P60_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".116" = xor i32 %"plop3_a_bit.1", 1
  %".117" = xor i32 %"plop3_b_bit.1", 1
  %".118" = xor i32 %"plop3_c_bit.1", 1
  %".119" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".120" = and i32 %".119", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".120", 0
  %"P5_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P5_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", %".115"
  br label %"BB_0520"
BB_0520:
  %"cond_trunc.9" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.9", -1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_04a0", label %"BB_0530"
BB_0530:
  %"phi.10" = phi  i32 [%"imad.7", %"BB_0490"], [%"imad.8", %"BB_0520"]
  %"viadd.6" = add i32 %"phi.10", 16
  %".123" = zext i32 %"imad.6" to i64
  %".124" = zext i32 0 to i64
  %".125" = shl i64 %".124", 32
  %"shf_concat.2" = or i64 %".123", %".125"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".126" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".126" to i32
  %".127" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %"imad_tmp.8" = mul i32 %"phi.10", 32
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %".134" = zext i32 %"imad.5" to i64
  %".135" = zext i32 0 to i64
  %".136" = shl i64 %".135", 32
  %"shf_concat.3" = or i64 %".134", %".136"
  %"shf_shift_64.3" = zext i32 %"viadd.6" to i64
  %".137" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".137" to i32
  %".138" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".139" = zext i32 1024 to i64
  %".140" = zext i32 24 to i64
  %".141" = shl i64 %".138", %".140"
  %".142" = and i64 %".141", 4294967295
  %".143" = add i64 %".142", %".139"
  %".144" = trunc i64 %".143" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".165" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".144", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.9", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0650"
BB_05e0:
  %".169" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".170" = zext i32 1024 to i64
  %".171" = zext i32 24 to i64
  %".172" = shl i64 %".169", %".171"
  %".173" = and i64 %".172", 4294967295
  %".174" = add i64 %".173", %".170"
  %".175" = trunc i64 %".174" to i32
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.9", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".175", 9224
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".176" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".176" to i32 addrspace(3)*
  store volatile i32 %"imad.10", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_0620_1250"
BB_0620_1250:
  call void @"llvm.trap"()
  br label %"BB_0650"
BB_0650:
  %"isetrp_cmp1.8" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P55_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %".180" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".181" = bitcast i8* %".180" to i64*
  %"ldc_const.2" = load i64, i64* %".181"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.10" = mul i32 %"tid_x.1", 18
  %"imad.11" = add i32 %"imad_tmp.10", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.11" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.12" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.12" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.12", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R100:R80_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R100:R80_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R100:R80_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R100:R80_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R100:R80_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R100:R80_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R100:R80_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R100:R80_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.11" = mul i32 %"tid_x.1", 65536
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %".182" = xor i32 %"imad.13", -1
  %".183" = xor i32 65011712, -1
  %".184" = xor i32 0, -1
  %".185" = and i32 %"imad.13", 65011712
  %".186" = and i32 %".185", %".184"
  %".187" = and i32 %"imad.13", 65011712
  %".188" = and i32 %".187", 0
  %".189" = or i32 %".186", %".188"
  %".190" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".191" = zext i32 1024 to i64
  %".192" = zext i32 24 to i64
  %".193" = shl i64 %".190", %".192"
  %".194" = and i64 %".193", 4294967295
  %".195" = add i64 %".194", %".191"
  %".196" = trunc i64 %".195" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".197" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".197" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.12" = mul i32 %"lds.1", 1
  %"imad.14" = add i32 %"imad_tmp.12", %".189"
  %"sttm_memaddr_offset_add" = add i32 %"imad.14", 272
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.14", 276
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R100:R80_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R100:R80_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R100:R80_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R100:R80_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R100:R80_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R100:R80_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R100:R80_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R100:R80_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R100:R80_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.14", 256
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.14", 260
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0900"
BB_0900:
  %"cond_trunc.10" = trunc i32 %"P55_to_i32" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0c60", label %"BB_0910"
BB_0910:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".207" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".207" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".208" = xor i32 %"plop3_a_bit.2", 1
  %".209" = xor i32 %"plop3_b_bit.2", 1
  %".210" = xor i32 %"plop3_c_bit.2", 1
  %".211" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".212" = and i32 %".211", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".212", 0
  %"P61_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".213" = zext i32 0 to i64
  %".214" = zext i32 %".196" to i64
  %".215" = shl i64 %".214", 32
  %"shf_concat.4" = or i64 %".213", %".215"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".216" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".216", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".217" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".218" = zext i32 %"iadd3_n2.3" to i64
  %".219" = zext i32 24 to i64
  %".220" = shl i64 %".217", %".219"
  %".221" = and i64 %".220", 4294967295
  %".222" = add i64 %".221", %".218"
  %".223" = trunc i64 %".222" to i32
  %".224" = xor i32 %"shf_result.4", -1
  %".225" = xor i32 16376, -1
  %".226" = xor i32 0, -1
  %".227" = and i32 %"shf_result.4", 16376
  %".228" = and i32 %".227", %".226"
  %".229" = and i32 %"shf_result.4", 16376
  %".230" = and i32 %".229", 0
  %".231" = or i32 %".228", %".230"
  %".232" = zext i32 0 to i64
  %".233" = zext i32 %".223" to i64
  %".234" = shl i64 %".233", 32
  %"shf_concat.5" = or i64 %".232", %".234"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".235" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".235", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".236" = xor i32 %".231", -1
  %".237" = xor i32 524288, -1
  %".238" = xor i32 0, -1
  %".239" = and i32 %".236", 524288
  %".240" = and i32 %".239", %".238"
  %".241" = and i32 %".236", 524288
  %".242" = and i32 %".241", 0
  %".243" = or i32 %".240", %".242"
  %".244" = and i32 %".231", %".237"
  %".245" = and i32 %".244", %".238"
  %".246" = or i32 %".243", %".245"
  %".247" = and i32 %".231", %".237"
  %".248" = and i32 %".247", 0
  %".249" = or i32 %".246", %".248"
  %".250" = and i32 %".231", 524288
  %".251" = and i32 %".250", %".238"
  %".252" = or i32 %".249", %".251"
  %".253" = and i32 %".231", 524288
  %".254" = and i32 %".253", 0
  %".255" = or i32 %".252", %".254"
  %".256" = xor i32 %"shf_result.5", -1
  %".257" = xor i32 16376, -1
  %".258" = xor i32 0, -1
  %".259" = and i32 %"shf_result.5", 16376
  %".260" = and i32 %".259", %".258"
  %".261" = and i32 %"shf_result.5", 16376
  %".262" = and i32 %".261", 0
  %".263" = or i32 %".260", %".262"
  %".264" = xor i32 %".263", -1
  %".265" = xor i32 524288, -1
  %".266" = xor i32 0, -1
  %".267" = and i32 %".264", 524288
  %".268" = and i32 %".267", %".266"
  %".269" = and i32 %".264", 524288
  %".270" = and i32 %".269", 0
  %".271" = or i32 %".268", %".270"
  %".272" = and i32 %".263", %".265"
  %".273" = and i32 %".272", %".266"
  %".274" = or i32 %".271", %".273"
  %".275" = and i32 %".263", %".265"
  %".276" = and i32 %".275", 0
  %".277" = or i32 %".274", %".276"
  %".278" = and i32 %".263", 524288
  %".279" = and i32 %".278", %".266"
  %".280" = or i32 %".277", %".279"
  %".281" = and i32 %".263", 524288
  %".282" = and i32 %".281", 0
  %".283" = or i32 %".280", %".282"
  %"iadd3_n1.4" = add i32 %"lds.2", 272
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_0a10"
BB_0a10:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0910"], [%"P51_to_i32", %"BB_0a40"]
  %"phi.12" = phi  i32 [%"P61_to_i32", %"BB_0910"], [%"phi.14", %"BB_0a40"]
  %"cond_trunc.11" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P48_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.13" = phi  i32 [%"P48_to_i32", %"BB_80000a10"], [%"phi.11", %"BB_0a10"]
  %"mma_b_r0_ext" = zext i32 %".283" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".287" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".288" = sub i64 %".287", 0
  %".289" = lshr i64 %".288", 4
  %".290" = add i64 %"mma_b_packed_1", %".289"
  %".291" = and i64 %".290", 16383
  %".292" = and i64 %"mma_b_packed_1", -16384
  %".293" = or i64 %".292", %".291"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".293", i32 138417552, i32 %"mma_arg_zext")
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.12" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000a30", label %"BB_0a40"
BB_80000a30:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".297" = xor i32 %"plop3_a_bit.3", 1
  %".298" = xor i32 %"plop3_b_bit.3", 1
  %".299" = xor i32 %"plop3_c_bit.3", 1
  %".300" = and i32 %".297", %"plop3_b_bit.3"
  %".301" = and i32 %".300", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".301", 0
  %"P10_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.14" = phi  i32 [%"P10_to_i32", %"BB_80000a30"], [%"phi.12", %"BB_0a30"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".303" = xor i32 %"plop3_a_bit.4", 1
  %".304" = xor i32 %"plop3_b_bit.4", 1
  %".305" = xor i32 %"plop3_c_bit.4", 1
  %".306" = and i32 %".303", %"plop3_b_bit.4"
  %".307" = and i32 %".306", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".307", 0
  %"P51_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0a10", label %"BB_0a60"
BB_0a60:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".309" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".309" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".310" = xor i32 %"plop3_a_bit.5", 1
  %".311" = xor i32 %"plop3_b_bit.5", 1
  %".312" = xor i32 %"plop3_c_bit.5", 1
  %".313" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".314" = and i32 %".313", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".314", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"iadd3_n1.5" = add i32 %"lds.3", 272
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.3", 256
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"iadd3_n1.7" = add i32 %"lds.3", 260
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  br label %"BB_0ae0"
BB_0ae0:
  %"phi.15" = phi  i32 [%"P51_to_i32", %"BB_0a60"], [%"P27_to_i32", %"BB_0b10"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0a60"], [%"phi.18", %"BB_0b10"]
  %"cond_trunc.13" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000ae0", label %"BB_0af0"
BB_80000ae0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P25_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0af0"
BB_0af0:
  %"phi.17" = phi  i32 [%"P25_to_i32", %"BB_80000ae0"], [%"phi.15", %"BB_0ae0"]
  %"mma_b_r0_ext.1" = zext i32 %".255" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".318" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".319" = sub i64 %".318", 0
  %".320" = lshr i64 %".319", 4
  %".321" = add i64 %"mma_b_packed_1.1", %".320"
  %".322" = and i64 %".321", 16383
  %".323" = and i64 %"mma_b_packed_1.1", -16384
  %".324" = or i64 %".323", %".322"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.5", i64 %".324", i32 679744944, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.6", i32 %"iadd3_n2.7")
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.14" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000b00", label %"BB_0b10"
BB_80000b00:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".328" = xor i32 %"plop3_a_bit.6", 1
  %".329" = xor i32 %"plop3_b_bit.6", 1
  %".330" = xor i32 %"plop3_c_bit.6", 1
  %".331" = and i32 %".328", %"plop3_b_bit.6"
  %".332" = and i32 %".331", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".332", 0
  %"P58_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_0b10"
BB_0b10:
  %"phi.18" = phi  i32 [%"P58_to_i32", %"BB_80000b00"], [%"phi.16", %"BB_0b00"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".334" = xor i32 %"plop3_a_bit.7", 1
  %".335" = xor i32 %"plop3_b_bit.7", 1
  %".336" = xor i32 %"plop3_c_bit.7", 1
  %".337" = and i32 %".334", %"plop3_b_bit.7"
  %".338" = and i32 %".337", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".338", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0ae0", label %"BB_0b30"
BB_0b30:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".340" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".340" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".341" = xor i32 %"plop3_a_bit.8", 1
  %".342" = xor i32 %"plop3_b_bit.8", 1
  %".343" = xor i32 %"plop3_c_bit.8", 1
  %".344" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".345" = and i32 %".344", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".345", 0
  %"P12_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"iadd3_n1.8" = add i32 %"lds.4", 272
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"lds.4", 256
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"iadd3_n1.10" = add i32 %"lds.4", 260
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  br label %"BB_0b90"
BB_0b90:
  %"phi.19" = phi  i32 [%"P27_to_i32", %"BB_0b30"], [%"P32_to_i32", %"BB_0bc0"]
  %"phi.20" = phi  i32 [%"P12_to_i32", %"BB_0b30"], [%"phi.22", %"BB_0bc0"]
  %"cond_trunc.15" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P29_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.21" = phi  i32 [%"P29_to_i32", %"BB_80000b90"], [%"phi.19", %"BB_0b90"]
  %"mma_b_r0_ext.2" = zext i32 %".255" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".349" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".350" = sub i64 %".349", 0
  %".351" = lshr i64 %".350", 4
  %".352" = add i64 %"mma_b_packed_1.2", %".351"
  %".353" = and i64 %".352", 16383
  %".354" = and i64 %"mma_b_packed_1.2", -16384
  %".355" = or i64 %".354", %".353"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.4", i32 %"iadd3_n2.8", i64 %".355", i32 679744944, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.9", i32 %"iadd3_n2.10")
  br label %"BB_0bb0"
BB_0bb0:
  %"cond_trunc.16" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000bb0", label %"BB_0bc0"
BB_80000bb0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".359" = xor i32 %"plop3_a_bit.9", 1
  %".360" = xor i32 %"plop3_b_bit.9", 1
  %".361" = xor i32 %"plop3_c_bit.9", 1
  %".362" = and i32 %".359", %"plop3_b_bit.9"
  %".363" = and i32 %".362", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".363", 0
  %"P34_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"phi.22" = phi  i32 [%"P34_to_i32", %"BB_80000bb0"], [%"phi.20", %"BB_0bb0"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".365" = xor i32 %"plop3_a_bit.10", 1
  %".366" = xor i32 %"plop3_b_bit.10", 1
  %".367" = xor i32 %"plop3_c_bit.10", 1
  %".368" = and i32 %".365", %"plop3_b_bit.10"
  %".369" = and i32 %".368", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".369", 0
  %"P32_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0b90", label %"BB_0be0"
BB_0be0:
  %"iadd3_n1.11" = add i32 1024, 9216
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".371" = xor i32 %"plop3_a_bit.11", 1
  %".372" = xor i32 %"plop3_b_bit.11", 1
  %".373" = xor i32 %"plop3_c_bit.11", 1
  %".374" = and i32 %"plop3_a_bit.11", %"plop3_b_bit.11"
  %".375" = and i32 %".374", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".375", 0
  %"P56_to_i32" = zext i1 %"plop3_pred.11" to i32
  %".376" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".377" = zext i32 %"iadd3_n2.11" to i64
  %".378" = zext i32 24 to i64
  %".379" = shl i64 %".376", %".378"
  %".380" = and i64 %".379", 4294967295
  %".381" = add i64 %".380", %".377"
  %".382" = trunc i64 %".381" to i32
  br label %"BB_0c10"
BB_0c10:
  %"phi.23" = phi  i32 [%"P32_to_i32", %"BB_0be0"], [%"P38_to_i32", %"BB_0c40"]
  %"phi.24" = phi  i32 [%"P56_to_i32", %"BB_0be0"], [%"phi.26", %"BB_0c40"]
  %"cond_trunc.17" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000c10", label %"BB_0c20"
BB_80000c10:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P35_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0c20"
BB_0c20:
  %"phi.25" = phi  i32 [%"P35_to_i32", %"BB_80000c10"], [%"phi.23", %"BB_0c10"]
  %"utcbar_local_winoff" = and i32 %".382", 16777215
  %".386" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".387" = ptrtoint i8 addrspace(3)* %".386" to i32
  %".388" = lshr i32 %".382", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".387", i32 %".388")
  br label %"BB_0c30"
BB_0c30:
  %"cond_trunc.18" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c30", label %"BB_0c40"
BB_80000c30:
  %"lop3_a_trunc.3" = trunc i32 %"phi.25" to i1
  %"lop3_a_cast_zext.12" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".392" = xor i32 %"plop3_a_bit.12", 1
  %".393" = xor i32 %"plop3_b_bit.12", 1
  %".394" = xor i32 %"plop3_c_bit.12", 1
  %".395" = and i32 %".392", %"plop3_b_bit.12"
  %".396" = and i32 %".395", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".396", 0
  %"P65_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_0c40"
BB_0c40:
  %"phi.26" = phi  i32 [%"P65_to_i32", %"BB_80000c30"], [%"phi.24", %"BB_0c30"]
  %"lop3_a_cast_zext.13" = zext i1 1 to i32
  %"lop3_b_cast_zext.13" = zext i1 1 to i32
  %"lop3_c_cast_zext.13" = zext i1 1 to i32
  %"plop3_a_bit.13" = and i32 %"lop3_a_cast_zext.13", 1
  %"plop3_b_bit.13" = and i32 %"lop3_b_cast_zext.13", 1
  %"plop3_c_bit.13" = and i32 %"lop3_c_cast_zext.13", 1
  %".398" = xor i32 %"plop3_a_bit.13", 1
  %".399" = xor i32 %"plop3_b_bit.13", 1
  %".400" = xor i32 %"plop3_c_bit.13", 1
  %".401" = and i32 %".398", %"plop3_b_bit.13"
  %".402" = and i32 %".401", %"plop3_c_bit.13"
  %"plop3_pred.13" = icmp ne i32 %".402", 0
  %"P38_to_i32" = zext i1 %"plop3_pred.13" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.26" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.3", label %"BB_0c10", label %"BB_0c60"
BB_0c60:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.12" = add i32 1024, 9216
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", 0
  %".404" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".405" = zext i32 %"iadd3_n2.12" to i64
  %".406" = zext i32 24 to i64
  %".407" = shl i64 %".404", %".406"
  %".408" = and i64 %".407", 4294967295
  %".409" = add i64 %".408", %".405"
  %".410" = trunc i64 %".409" to i32
  %".411" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".412" = bitcast i8* %".411" to i64*
  %"ldc_const.3" = load i64, i64* %".412"
  %"R5:R4_r0" = trunc i64 %"ldc_const.3" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"mbar_shared_winoff.1" = and i32 %".410", 16777215
  %".413" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".413" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P4_to_i32" = zext i1 %"mbar_ready" to i32
  %"imad_addend_r0_ext.2" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64.2" = zext i32 1056 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.15" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R5:R4_r0.1" = trunc i64 %"imad.15" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.15", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.3" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.3" = zext i32 16 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P39_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  br label %"BB_0ce0"
BB_0ce0:
  %"cond_trunc.19" = trunc i32 %"P4_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_11f0", label %"BB_0cf0"
BB_11f0:
  %"mbar_shared_winoff.2" = and i32 %".410", 16777215
  %".416" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".416" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P6_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1200"
BB_1200:
  %"cond_trunc.20" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.20", -1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_11f0", label %"BB_0cf0"
BB_0cf0:
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 4
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"R5:R4_r1.1"
  %"imad_cin_trunc.3" = trunc i32 %"P39_to_i32" to i1
  %"imad_cin_ext.3" = zext i1 %"imad_cin_trunc.3" to i32
  %"imad_with_cin.3" = add i32 %"imad.17", %"imad_cin_ext.3"
  br label %"BB_0d20"
BB_0d20:
  %"phi.27" = phi  i32 [%"imad.16", %"BB_0cf0"], [%"viadd.8", %"BB_0f20"]
  %"phi.28" = phi  i32 [%"imad_with_cin.3", %"BB_0cf0"], [%"imad_with_cin.4", %"BB_0f20"]
  %"phi.29" = phi  i32 [%"iadd3_trunc.3", %"BB_0cf0"], [%"iadd3_trunc.4", %"BB_0f20"]
  %"viadd.7" = add i32 %"phi.27", 4294967292
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", 240
  %"isetrp_cmp1.9" = icmp uge i32 %"viadd.7", 24
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"isetrp_cmp1.10" = icmp uge i32 %"viadd.7", 20
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P53_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"isetrp_cmp1.11" = icmp uge i32 %"viadd.7", 16
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"sel_pred_trunc.2" = trunc i32 %"P41_to_i32" to i1
  %"sel_pred_not.2" = xor i1 %"sel_pred_trunc.2", -1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_not.2" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 %"imad.18", i32 4294967288
  %"isetrp_cmp1.12" = icmp uge i32 %"viadd.7", 12
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"sel_pred_trunc.3" = trunc i32 %"P53_to_i32" to i1
  %"sel_pred_not.3" = xor i1 %"sel_pred_trunc.3", -1
  %"sel_pred_to_i32.3" = zext i1 %"sel_pred_not.3" to i32
  %"sel_pred_to_i1.3" = icmp ne i32 %"sel_pred_to_i32.3", 0
  %"sel.3" = select  i1 %"sel_pred_to_i1.3", i32 %"imad.18", i32 4294967288
  %"sel_pred_trunc.4" = trunc i32 %"P7_to_i32" to i1
  %"sel_pred_to_i32.4" = zext i1 %"sel_pred_trunc.4" to i32
  %"sel_pred_to_i1.4" = icmp ne i32 %"sel_pred_to_i32.4", 0
  %"sel.4" = select  i1 %"sel_pred_to_i1.4", i32 %"sel.2", i32 0
  %"sel_pred_trunc.5" = trunc i32 %"P42_to_i32" to i1
  %"sel_pred_to_i32.5" = zext i1 %"sel_pred_trunc.5" to i32
  %"sel_pred_to_i1.5" = icmp ne i32 %"sel_pred_to_i32.5", 0
  %"sel.5" = select  i1 %"sel_pred_to_i1.5", i32 %"sel.3", i32 0
  %"iadd3_n1.13" = add i32 %"phi.27", %"imad.14"
  %"iadd3_n2.13" = add i32 %"iadd3_n1.13", %"sel.4"
  %"iadd3_n1.14" = add i32 %"phi.27", %"imad.14"
  %"iadd3_n2.14" = add i32 %"iadd3_n1.14", %"sel.5"
  %"viadd.8" = add i32 %"phi.27", 8
  %"isetrp_cmp1.13" = icmp uge i32 %"viadd.7", 256
  %"isetrp_src_to_i32.13" = zext i1 1 to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"iadd3_o1_64.4" = zext i32 %"phi.29" to i64
  %"iadd3_o2_64.4" = zext i32 32 to i64
  %"iadd3_o3_64.4" = zext i32 0 to i64
  %"iadd3_tmp.4" = add i64 %"iadd3_o1_64.4", %"iadd3_o2_64.4"
  %"iadd3_tmp2.4" = add i64 %"iadd3_tmp.4", %"iadd3_o3_64.4"
  %"iadd3_trunc.4" = trunc i64 %"iadd3_tmp2.4" to i32
  %"iadd3_carry_val.4" = lshr i64 %"iadd3_tmp2.4", 32
  %"carry_ge_1.4" = icmp uge i64 %"iadd3_carry_val.4", 1
  %"P43_to_i32" = zext i1 %"carry_ge_1.4" to i32
  %"carry_ge_2.4" = icmp uge i64 %"iadd3_carry_val.4", 2
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.16", %"phi.28"
  %"imad_cin_trunc.4" = trunc i32 %"P43_to_i32" to i1
  %"imad_cin_ext.4" = zext i1 %"imad_cin_trunc.4" to i32
  %"imad_with_cin.4" = add i32 %"imad.19", %"imad_cin_ext.4"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"iadd3_n2.13", -4
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".420" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".421" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".422" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".423" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"iadd3_n2.14")
  %".424" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".425" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".426" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".427" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"stg_addr_r0_ext" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1", -16
  %"R148:R137_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".420", i32 addrspace(1)* %"R148:R137_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.1", -12
  %"R148:R137_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".421", i32 addrspace(1)* %"R148:R137_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.2", -8
  %"R148:R137_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".422", i32 addrspace(1)* %"R148:R137_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.3", -4
  %"R148:R137_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".423", i32 addrspace(1)* %"R148:R137_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"R148:R137_addr_ptr.4" = inttoptr i64 %"stg_addr_packed_1.4" to i32 addrspace(1)*
  store i32 %".424", i32 addrspace(1)* %"R148:R137_addr_ptr.4"
  %"stg_addr_r0_ext.5" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 4
  %"R148:R137_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".425", i32 addrspace(1)* %"R148:R137_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 8
  %"R148:R137_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".426", i32 addrspace(1)* %"R148:R137_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"phi.29" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"phi.28" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 12
  %"R148:R137_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".427", i32 addrspace(1)* %"R148:R137_addr_ptr.7"
  br label %"BB_0f20"
BB_0f20:
  %"cond_trunc.21" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0d20", label %"BB_0f30"
BB_0f30:
  call void @"llvm.nvvm.barrier0"()
  %"isetrp_cmp1.14" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.14" = zext i1 1 to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  br label %"BB_0f50"
BB_0f50:
  %"cond_trunc.22" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000f50", label %"BB_0f60"
BB_0f60:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".196", 9224
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".440" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".440" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.17", 65535
  %".441" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".442" = zext i32 80 to i64
  %".443" = zext i32 24 to i64
  %".444" = shl i64 %".441", %".443"
  %".445" = and i64 %".444", 4294967295
  %".446" = add i64 %".445", %".442"
  %".447" = trunc i64 %".446" to i32
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.18", 1
  %"lds_shared_addr_winoff.6" = and i32 %".447", 16777215
  %".448" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".448" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".449" = xor i32 %"lds.5", -1
  %".450" = xor i32 65535, -1
  %".451" = xor i32 0, -1
  %".452" = and i32 %"lds.5", 65535
  %".453" = and i32 %".452", %".451"
  %".454" = and i32 %"lds.5", 65535
  %".455" = and i32 %".454", 0
  %".456" = or i32 %".453", %".455"
  %".457" = zext i32 0 to i64
  %".458" = zext i32 %".456" to i64
  %".459" = shl i64 %".458", 32
  %"shf_concat.6" = or i64 %".457", %".459"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".460" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".460", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %"viadd.9" = add i32 %"shf_result.6", 16
  %".461" = zext i32 %"imad.20" to i64
  %".462" = zext i32 0 to i64
  %".463" = shl i64 %".462", 32
  %"shf_concat.7" = or i64 %".461", %".463"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".464" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".464" to i32
  %".465" = zext i32 %"imad.21" to i64
  %".466" = zext i32 0 to i64
  %".467" = shl i64 %".466", 32
  %"shf_concat.8" = or i64 %".465", %".467"
  %"shf_shift_64.8" = zext i32 %"viadd.9" to i64
  %".468" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".468" to i32
  %".469" = xor i32 %"shf_result.8", -1
  %".470" = xor i32 %"shf_result.7", -1
  %".471" = xor i32 0, -1
  %".472" = and i32 %".469", %"shf_result.7"
  %".473" = and i32 %".472", %".471"
  %".474" = and i32 %".469", %"shf_result.7"
  %".475" = and i32 %".474", 0
  %".476" = or i32 %".473", %".475"
  %".477" = and i32 %"shf_result.8", %".470"
  %".478" = and i32 %".477", %".471"
  %".479" = or i32 %".476", %".478"
  %".480" = and i32 %"shf_result.8", %".470"
  %".481" = and i32 %".480", 0
  %".482" = or i32 %".479", %".481"
  %".483" = and i32 %"shf_result.8", %"shf_result.7"
  %".484" = and i32 %".483", %".471"
  %".485" = or i32 %".482", %".484"
  %".486" = and i32 %"shf_result.8", %"shf_result.7"
  %".487" = and i32 %".486", 0
  %".488" = or i32 %".485", %".487"
  %".489" = xor i32 %".488", -1
  %".490" = xor i32 65535, -1
  %".491" = xor i32 0, -1
  %".492" = and i32 %".488", 65535
  %".493" = and i32 %".492", %".491"
  %".494" = and i32 %".488", 65535
  %".495" = and i32 %".494", 0
  %".496" = or i32 %".493", %".495"
  %".497" = xor i32 %".488", -1
  %".498" = xor i32 65535, -1
  %".499" = xor i32 %"lds.6", -1
  %".500" = and i32 %".488", 65535
  %".501" = and i32 %".500", %"lds.6"
  %"isetrp_cmp1.15" = icmp ne i32 %".501", %".496"
  %"isetrp_src_to_i32.15" = zext i1 1 to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  br label %"BB_1060"
BB_1060:
  %"cond_trunc.23" = trunc i32 %"P13_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_11c0_1280", label %"BB_1070"
BB_1070:
  %".504" = zext i32 0 to i64
  %".505" = zext i32 %"lds.6" to i64
  %".506" = shl i64 %".505", 32
  %"shf_concat.9" = or i64 %".504", %".506"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".507" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".507", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".508" = zext i32 0 to i64
  %".509" = zext i32 %".488" to i64
  %".510" = shl i64 %".509", 32
  %"shf_concat.10" = or i64 %".508", %".510"
  %"shf_shift_64.10" = zext i32 16 to i64
  %".511" = lshr i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_hi.4" = lshr i64 %".511", 32
  %"shf_result.10" = trunc i64 %"shf_hi.4" to i32
  %".512" = xor i32 %"shf_result.9", -1
  %".513" = xor i32 %"shf_result.10", -1
  %".514" = xor i32 0, -1
  %".515" = and i32 %"shf_result.9", %"shf_result.10"
  %".516" = and i32 %".515", %".514"
  %".517" = and i32 %"shf_result.9", %"shf_result.10"
  %".518" = and i32 %".517", 0
  %".519" = or i32 %".516", %".518"
  %"isetrp_cmp1.16" = icmp ne i32 %".519", %"shf_result.10"
  %"isetrp_src_to_i32.16" = zext i1 1 to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  br label %"BB_10b0"
BB_10b0:
  %"cond_trunc.24" = trunc i32 %"P14_to_i32" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_1190_1220", label %"BB_10c0"
BB_10c0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".522" = xor i32 0, -1
  %".523" = xor i32 %".488", -1
  %".524" = xor i32 0, -1
  %".525" = and i32 %".522", %".523"
  %".526" = and i32 %".525", %".524"
  %".527" = and i32 %".522", %".523"
  %".528" = and i32 %".527", 0
  %".529" = or i32 %".526", %".528"
  %".530" = and i32 0, %".523"
  %".531" = and i32 %".530", %".524"
  %".532" = or i32 %".529", %".531"
  %".533" = and i32 0, %".523"
  %".534" = and i32 %".533", 0
  %".535" = or i32 %".532", %".534"
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.19", %".535"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.22", i32 %"redux_mask")
  %".536" = xor i32 %".535", -1
  %".537" = call i32 @"llvm.cttz.i32"(i32 %".536", i1 0)
  %".538" = shl i32 %".537", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 512;", "r,~{memory}"(i32 %".538") convergent
  %"isetrp_cmp1.17" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.17" = zext i1 1 to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.20", %"redux_sync_and"
  br label %"BB_1160"
BB_1160:
  %"cond_trunc.25" = trunc i32 %"P15_to_i32" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80001160", label %"BB_11d0"
BB_80001160:
  %"atoms_shared_addr_winoff.1" = and i32 %".447", 16777215
  %".542" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".542" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.23" monotonic
  br label %"BB_11d0"
BB_1190_1220:
  call void @"llvm.trap"()
  br label %"BB_11d0"
BB_11c0_1280:
  call void @"llvm.trap"()
  br label %"BB_11d0"
BB_11d0:
  ret void
BB_80000f50:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
