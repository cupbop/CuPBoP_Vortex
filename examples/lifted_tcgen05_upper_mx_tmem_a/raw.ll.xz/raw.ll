; ModuleID = "tcgen05_upper_mx_tmem_a_sm100a_cuda13"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [10256 x i8], align 16
define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P15_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"UR5:UR4_r0" = trunc i64 %"ldc_const" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".12" = xor i32 %"imad", -1
  %".13" = xor i32 508, -1
  %".14" = xor i32 0, -1
  %".15" = and i32 %"imad", 508
  %".16" = and i32 %".15", %".14"
  %".17" = and i32 %"imad", 508
  %".18" = and i32 %".17", 0
  %".19" = or i32 %".16", %".18"
  %"iadd3_o1_64" = zext i32 %".19" to i64
  %"iadd3_o2_64" = zext i32 %"UR5:UR4_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR5:UR4_r1"
  %"imad_cin_trunc" = trunc i32 %"P1_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R156:R143_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R156:R143_addr_ptr"
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".20" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".21" = zext i32 %"iadd3_n2" to i64
  %".22" = zext i32 24 to i64
  %".23" = shl i64 %".20", %".22"
  %".24" = and i64 %".23", 4294967295
  %".25" = add i64 %".24", %".21"
  %".26" = trunc i64 %".25" to i32
  %"viadd" = add i32 %"imad", %".26"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd.1", %"BB_0140"]
  %"phi.1" = phi  i32 [%"viadd", %"EntryBB_0000"], [%"viadd.2", %"BB_0140"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".28" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".28" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0140"
BB_0140:
  %"cond_trunc" = trunc i32 %"P56_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0100", label %"BB_0150"
BB_0150:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %".32" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".33" = zext i32 1024 to i64
  %".34" = zext i32 24 to i64
  %".35" = shl i64 %".32", %".34"
  %".36" = and i64 %".35", 4294967295
  %".37" = add i64 %".36", %".33"
  %".38" = trunc i64 %".37" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %".41" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".42" = bitcast i8* %".41" to i64*
  %"ldc_const.1" = load i64, i64* %".42"
  %"R3:R2_r0" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"viadd.3" = add i32 %"imad", %".38"
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad.2" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0220"
BB_0220:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.3" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.4", %"BB_02a0"]
  %"phi.4" = phi  i32 [%"viadd.3", %"BB_01c0"], [%"viadd.5", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.5" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R36:R152_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R36:R152_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.3", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.4" = add i32 %"phi.3", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.5" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P29_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P29_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.4", 16777215
  %".44" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".44" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.4", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.6" = phi  i32 [%"P15_to_i32", %"BB_01b0"], [%"P29_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P49_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P49_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".50" = zext i32 %"iadd3_n2.2" to i64
  %".51" = zext i32 0 to i64
  %".52" = shl i64 %".51", 32
  %"shf_concat" = or i64 %".50", %".52"
  %"shf_shift_64" = zext i32 11 to i64
  %".53" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".53" to i32
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat.1" = or i64 %".54", %".56"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".57" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".57" to i32
  %".58" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".59" = zext i32 %"iadd3_n2.1" to i64
  %".60" = zext i32 24 to i64
  %".61" = shl i64 %".58", %".60"
  %".62" = and i64 %".61", 4294967295
  %".63" = add i64 %".62", %".59"
  %".64" = trunc i64 %".63" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.7" = phi  i32 [%".64", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000300"], [%"UR5:UR4_r1", %"BB_0300"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P50_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P50_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".69" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".69" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".70" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".70" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P14_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0520", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".38", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".74" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".75" = ptrtoint i8 addrspace(3)* %".74" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".75", i32 512) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P40_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P40_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0520", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 65535
  %".79" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".80" = zext i32 64 to i64
  %".81" = zext i32 24 to i64
  %".82" = shl i64 %".79", %".81"
  %".83" = and i64 %".82", 4294967295
  %".84" = add i64 %".83", %".80"
  %".85" = trunc i64 %".84" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".38", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".86" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".87" = bitcast i8 addrspace(3)* %".86" to i32 addrspace(3)*
  %".88" = load i32, i32 addrspace(3)* %".87"
  %".89" = lshr i32 %".88", 5
  %"P52_to_i32" = zext i1 1 to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".89"
  %"bra_cond_trunc" = trunc i32 %"P52_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04b0", label %"BB_0450"
BB_0450:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".38", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".91" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".92" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  %".93" = load i32, i32 addrspace(3)* %".92"
  %".94" = lshr i32 %".93", 5
  %"P53_to_i32" = zext i1 1 to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", %".94"
  %"bra_cond_trunc.1" = trunc i32 %"P53_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0450", label %"BB_04b0"
BB_04b0:
  %"phi.10" = phi  i32 [%"imad.7", %"BB_03c0"], [%"imad.8", %"BB_0450"]
  %".96" = zext i32 %"imad.5" to i64
  %".97" = zext i32 0 to i64
  %".98" = shl i64 %".97", 32
  %"shf_concat.2" = or i64 %".96", %".98"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".99" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".99" to i32
  %".100" = zext i32 %"imad.6" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.3" = or i64 %".100", %".102"
  %"shf_shift_64.3" = zext i32 %"phi.10" to i64
  %".103" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".103" to i32
  %"imad_tmp.8" = mul i32 %"phi.10", 32
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".85", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".85", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".38", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.9", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0520"
BB_0520:
  %"phi.11" = phi  i32 [%"P40_to_i32", %"BB_04b0"], [%"P40_to_i32", %"BB_03b0"], [%"phi.6", %"BB_0380"]
  %".109" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".110" = bitcast i8* %".109" to i64*
  %"ldc_const.2" = load i64, i64* %".110"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.9" = mul i32 %"tid_x", 18
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.10" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.11" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.11" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.11", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R104:R105_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R104:R105_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R104:R105_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R104:R105_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R104:R105_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R104:R105_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R104:R105_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R104:R105_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.7"
  %"imad_tmp.10" = mul i32 %"tid_x", 65536
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".38", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".111" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".111" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".112" = xor i32 %"imad.12", -1
  %".113" = xor i32 65011712, -1
  %".114" = xor i32 0, -1
  %".115" = and i32 %"imad.12", 65011712
  %".116" = and i32 %".115", %".114"
  %".117" = and i32 %"imad.12", 65011712
  %".118" = and i32 %".117", 0
  %".119" = or i32 %".116", %".118"
  %"imad_tmp.11" = mul i32 %"lds", 1
  %"imad.13" = add i32 %"imad_tmp.11", %".119"
  %"sttm_memaddr_offset_add" = add i32 %"imad.13", 272
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.13", 276
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R104:R105_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R104:R105_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R104:R105_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R104:R105_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R104:R105_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R104:R105_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R104:R105_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R104:R105_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.13", 256
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.13", 260
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_07a0"
BB_07a0:
  %"cond_trunc.7" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0ae0", label %"BB_07b0"
BB_07b0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".129" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".129" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".26" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.4" = or i64 %".130", %".132"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".133", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".134" = xor i32 %"plop3_a_bit", 1
  %".135" = xor i32 %"plop3_b_bit", 1
  %".136" = xor i32 %"plop3_c_bit", 1
  %".137" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".138" = and i32 %".137", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".138", 0
  %"P3_to_i32" = zext i1 %"plop3_pred" to i32
  %".139" = zext i32 0 to i64
  %".140" = zext i32 %".38" to i64
  %".141" = shl i64 %".140", 32
  %"shf_concat.5" = or i64 %".139", %".141"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".142" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".142", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".143" = xor i32 %"shf_result.4", -1
  %".144" = xor i32 16376, -1
  %".145" = xor i32 0, -1
  %".146" = and i32 %"shf_result.4", 16376
  %".147" = and i32 %".146", %".145"
  %".148" = and i32 %"shf_result.4", 16376
  %".149" = and i32 %".148", 0
  %".150" = or i32 %".147", %".149"
  %".151" = xor i32 %"shf_result.5", -1
  %".152" = xor i32 16376, -1
  %".153" = xor i32 0, -1
  %".154" = and i32 %"shf_result.5", 16376
  %".155" = and i32 %".154", %".153"
  %".156" = and i32 %"shf_result.5", 16376
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = xor i32 %".150", -1
  %".160" = xor i32 524288, -1
  %".161" = xor i32 0, -1
  %".162" = and i32 %".159", 524288
  %".163" = and i32 %".162", %".161"
  %".164" = and i32 %".159", 524288
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".150", %".160"
  %".168" = and i32 %".167", %".161"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %".150", %".160"
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %".173" = and i32 %".150", 524288
  %".174" = and i32 %".173", %".161"
  %".175" = or i32 %".172", %".174"
  %".176" = and i32 %".150", 524288
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = xor i32 %".158", -1
  %".180" = xor i32 524288, -1
  %".181" = xor i32 0, -1
  %".182" = and i32 %".179", 524288
  %".183" = and i32 %".182", %".181"
  %".184" = and i32 %".179", 524288
  %".185" = and i32 %".184", 0
  %".186" = or i32 %".183", %".185"
  %".187" = and i32 %".158", %".180"
  %".188" = and i32 %".187", %".181"
  %".189" = or i32 %".186", %".188"
  %".190" = and i32 %".158", %".180"
  %".191" = and i32 %".190", 0
  %".192" = or i32 %".189", %".191"
  %".193" = and i32 %".158", 524288
  %".194" = and i32 %".193", %".181"
  %".195" = or i32 %".192", %".194"
  %".196" = and i32 %".158", 524288
  %".197" = and i32 %".196", 0
  %".198" = or i32 %".195", %".197"
  %"iadd3_n1.3" = add i32 %"lds.1", 272
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0890"
BB_0890:
  %"phi.12" = phi  i32 [%"phi.11", %"BB_07b0"], [%"P46_to_i32", %"BB_08c0"]
  %"phi.13" = phi  i32 [%"P3_to_i32", %"BB_07b0"], [%"phi.15", %"BB_08c0"]
  %"cond_trunc.8" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P43_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.14" = phi  i32 [%"P43_to_i32", %"BB_80000890"], [%"phi.12", %"BB_0890"]
  %"mma_b_r0_ext" = zext i32 %".178" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".202" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".203" = sub i64 %".202", 0
  %".204" = lshr i64 %".203", 4
  %".205" = add i64 %"mma_b_packed_1", %".204"
  %".206" = and i64 %".205", 16383
  %".207" = and i64 %"mma_b_packed_1", -16384
  %".208" = or i64 %".207", %".206"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.3", i64 %".208", i32 138416272, i32 %"mma_arg_zext")
  br label %"BB_08b0"
BB_08b0:
  %"cond_trunc.9" = trunc i32 %"phi.14" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800008b0", label %"BB_08c0"
BB_800008b0:
  %"lop3_a_trunc" = trunc i32 %"phi.14" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".212" = xor i32 %"plop3_a_bit.1", 1
  %".213" = xor i32 %"plop3_b_bit.1", 1
  %".214" = xor i32 %"plop3_c_bit.1", 1
  %".215" = and i32 %".212", %"plop3_b_bit.1"
  %".216" = and i32 %".215", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".216", 0
  %"P6_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_08c0"
BB_08c0:
  %"phi.15" = phi  i32 [%"P6_to_i32", %"BB_800008b0"], [%"phi.13", %"BB_08b0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".218" = xor i32 %"plop3_a_bit.2", 1
  %".219" = xor i32 %"plop3_b_bit.2", 1
  %".220" = xor i32 %"plop3_c_bit.2", 1
  %".221" = and i32 %".218", %"plop3_b_bit.2"
  %".222" = and i32 %".221", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".222", 0
  %"P46_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.15" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0890", label %"BB_08e0"
BB_08e0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".224" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".224" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".225" = xor i32 %"plop3_a_bit.3", 1
  %".226" = xor i32 %"plop3_b_bit.3", 1
  %".227" = xor i32 %"plop3_c_bit.3", 1
  %".228" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".229" = and i32 %".228", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".229", 0
  %"P8_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"iadd3_n1.4" = add i32 %"lds.2", 272
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 256
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.2", 260
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  br label %"BB_0960"
BB_0960:
  %"phi.16" = phi  i32 [%"P46_to_i32", %"BB_08e0"], [%"P20_to_i32", %"BB_0990"]
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_08e0"], [%"phi.19", %"BB_0990"]
  %"cond_trunc.10" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P18_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.18" = phi  i32 [%"P18_to_i32", %"BB_80000960"], [%"phi.16", %"BB_0960"]
  %"mma_b_r0_ext.1" = zext i32 %".198" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".233" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".234" = sub i64 %".233", 0
  %".235" = lshr i64 %".234", 4
  %".236" = add i64 %"mma_b_packed_1.1", %".235"
  %".237" = and i64 %".236", 16383
  %".238" = and i64 %"mma_b_packed_1.1", -16384
  %".239" = or i64 %".238", %".237"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".239", i32 679743664, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.6")
  br label %"BB_0980"
BB_0980:
  %"cond_trunc.11" = trunc i32 %"phi.18" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000980", label %"BB_0990"
BB_80000980:
  %"lop3_a_trunc.1" = trunc i32 %"phi.18" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".243" = xor i32 %"plop3_a_bit.4", 1
  %".244" = xor i32 %"plop3_b_bit.4", 1
  %".245" = xor i32 %"plop3_c_bit.4", 1
  %".246" = and i32 %".243", %"plop3_b_bit.4"
  %".247" = and i32 %".246", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".247", 0
  %"P5_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0990"
BB_0990:
  %"phi.19" = phi  i32 [%"P5_to_i32", %"BB_80000980"], [%"phi.17", %"BB_0980"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".249" = xor i32 %"plop3_a_bit.5", 1
  %".250" = xor i32 %"plop3_b_bit.5", 1
  %".251" = xor i32 %"plop3_c_bit.5", 1
  %".252" = and i32 %".249", %"plop3_b_bit.5"
  %".253" = and i32 %".252", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".253", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.19" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0960", label %"BB_09b0"
BB_09b0:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".255" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".255" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".256" = xor i32 %"plop3_a_bit.6", 1
  %".257" = xor i32 %"plop3_b_bit.6", 1
  %".258" = xor i32 %"plop3_c_bit.6", 1
  %".259" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".260" = and i32 %".259", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".260", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"iadd3_n1.7" = add i32 %"lds.3", 272
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"iadd3_n1.8" = add i32 %"lds.3", 256
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"lds.3", 260
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  br label %"BB_0a10"
BB_0a10:
  %"phi.20" = phi  i32 [%"P20_to_i32", %"BB_09b0"], [%"P25_to_i32", %"BB_0a40"]
  %"phi.21" = phi  i32 [%"P27_to_i32", %"BB_09b0"], [%"phi.23", %"BB_0a40"]
  %"cond_trunc.12" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P22_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.22" = phi  i32 [%"P22_to_i32", %"BB_80000a10"], [%"phi.20", %"BB_0a10"]
  %"mma_b_r0_ext.2" = zext i32 %".198" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".264" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".265" = sub i64 %".264", 0
  %".266" = lshr i64 %".265", 4
  %".267" = add i64 %"mma_b_packed_1.2", %".266"
  %".268" = and i64 %".267", 16383
  %".269" = and i64 %"mma_b_packed_1.2", -16384
  %".270" = or i64 %".269", %".268"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.7", i64 %".270", i32 679743664, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.8", i32 %"iadd3_n2.9")
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.13" = trunc i32 %"phi.22" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000a30", label %"BB_0a40"
BB_80000a30:
  %"lop3_a_trunc.2" = trunc i32 %"phi.22" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".274" = xor i32 %"plop3_a_bit.7", 1
  %".275" = xor i32 %"plop3_b_bit.7", 1
  %".276" = xor i32 %"plop3_c_bit.7", 1
  %".277" = and i32 %".274", %"plop3_b_bit.7"
  %".278" = and i32 %".277", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".278", 0
  %"P48_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.23" = phi  i32 [%"P48_to_i32", %"BB_80000a30"], [%"phi.21", %"BB_0a30"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".280" = xor i32 %"plop3_a_bit.8", 1
  %".281" = xor i32 %"plop3_b_bit.8", 1
  %".282" = xor i32 %"plop3_c_bit.8", 1
  %".283" = and i32 %".280", %"plop3_b_bit.8"
  %".284" = and i32 %".283", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".284", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.4" = trunc i32 %"phi.23" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.4")
  br i1 %"branch_any.2", label %"BB_0a10", label %"BB_0a60"
BB_0a60:
  %"iadd3_n1.10" = add i32 1024, 9216
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".286" = xor i32 %"plop3_a_bit.9", 1
  %".287" = xor i32 %"plop3_b_bit.9", 1
  %".288" = xor i32 %"plop3_c_bit.9", 1
  %".289" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".290" = and i32 %".289", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".290", 0
  %"P55_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".291" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".292" = zext i32 %"iadd3_n2.10" to i64
  %".293" = zext i32 24 to i64
  %".294" = shl i64 %".291", %".293"
  %".295" = and i64 %".294", 4294967295
  %".296" = add i64 %".295", %".292"
  %".297" = trunc i64 %".296" to i32
  br label %"BB_0a90"
BB_0a90:
  %"phi.24" = phi  i32 [%"P25_to_i32", %"BB_0a60"], [%"P31_to_i32", %"BB_0ac0"]
  %"phi.25" = phi  i32 [%"P55_to_i32", %"BB_0a60"], [%"phi.27", %"BB_0ac0"]
  %"cond_trunc.14" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000a90", label %"BB_0aa0"
BB_80000a90:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P28_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0aa0"
BB_0aa0:
  %"phi.26" = phi  i32 [%"P28_to_i32", %"BB_80000a90"], [%"phi.24", %"BB_0a90"]
  %"utcbar_local_winoff" = and i32 %".297", 16777215
  %".301" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".302" = ptrtoint i8 addrspace(3)* %".301" to i32
  %".303" = lshr i32 %".297", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".302", i32 %".303")
  br label %"BB_0ab0"
BB_0ab0:
  %"cond_trunc.15" = trunc i32 %"phi.26" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000ab0", label %"BB_0ac0"
BB_80000ab0:
  %"lop3_a_trunc.3" = trunc i32 %"phi.26" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".307" = xor i32 %"plop3_a_bit.10", 1
  %".308" = xor i32 %"plop3_b_bit.10", 1
  %".309" = xor i32 %"plop3_c_bit.10", 1
  %".310" = and i32 %".307", %"plop3_b_bit.10"
  %".311" = and i32 %".310", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".311", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_0ac0"
BB_0ac0:
  %"phi.27" = phi  i32 [%"P11_to_i32", %"BB_80000ab0"], [%"phi.25", %"BB_0ab0"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".313" = xor i32 %"plop3_a_bit.11", 1
  %".314" = xor i32 %"plop3_b_bit.11", 1
  %".315" = xor i32 %"plop3_c_bit.11", 1
  %".316" = and i32 %".313", %"plop3_b_bit.11"
  %".317" = and i32 %".316", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".317", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.5" = trunc i32 %"phi.27" to i1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_trunc.5" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.5")
  br i1 %"branch_any.3", label %"BB_0a90", label %"BB_0ae0"
BB_0ae0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.11" = add i32 1024, 9216
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %".319" = zext i32 0 to i64
  %".320" = zext i32 0 to i64
  %".321" = shl i64 %".320", 32
  %"shf_concat.6" = or i64 %".319", %".321"
  %"shf_shift_64.6" = zext i32 31 to i64
  %".322" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".322" to i32
  %".323" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".324" = zext i32 %"iadd3_n2.11" to i64
  %".325" = zext i32 24 to i64
  %".326" = shl i64 %".323", %".325"
  %".327" = and i64 %".326", 4294967295
  %".328" = add i64 %".327", %".324"
  %".329" = trunc i64 %".328" to i32
  %".330" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".331" = bitcast i8* %".330" to i64*
  %"ldc_const.3" = load i64, i64* %".331"
  %"R5:R4_r0" = trunc i64 %"ldc_const.3" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"mbar_shared_winoff.1" = and i32 %".329", 16777215
  %".332" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".332" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P51_to_i32" = zext i1 %"mbar_ready" to i32
  %"imad_addend_r0_ext.2" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"tid_x" to i64
  %"imad_rhs_64.2" = zext i32 1056 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R5:R4_r0.1" = trunc i64 %"imad.14" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.14", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.3" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.3" = zext i32 16 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  br label %"BB_0b80"
BB_0b80:
  %"cond_trunc.16" = trunc i32 %"P51_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1080", label %"BB_0b90"
BB_1080:
  %"mbar_shared_winoff.2" = and i32 %".329", 16777215
  %".335" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".335" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P57_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1090"
BB_1090:
  %"cond_trunc.17" = trunc i32 %"P57_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_1080", label %"BB_0b90"
BB_0b90:
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 4
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"R5:R4_r1.1"
  %"imad_cin_trunc.3" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext.3" = zext i1 %"imad_cin_trunc.3" to i32
  %"imad_with_cin.3" = add i32 %"imad.16", %"imad_cin_ext.3"
  br label %"BB_0bc0"
BB_0bc0:
  %"phi.28" = phi  i32 [%"imad.15", %"BB_0b90"], [%"viadd.7", %"BB_0dc0"]
  %"phi.29" = phi  i32 [%"imad_with_cin.3", %"BB_0b90"], [%"imad_with_cin.4", %"BB_0dc0"]
  %"phi.30" = phi  i32 [%"iadd3_trunc.3", %"BB_0b90"], [%"iadd3_trunc.4", %"BB_0dc0"]
  %"viadd.6" = add i32 %"phi.28", 4294967292
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", 240
  %"isetrp_cmp1.5" = icmp uge i32 %"viadd.6", 24
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"isetrp_cmp1.6" = icmp uge i32 %"viadd.6", 20
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P47_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"isetrp_cmp1.7" = icmp uge i32 %"viadd.6", 16
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"sel_pred_trunc" = trunc i32 %"P35_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 %"imad.17", i32 4294967288
  %"isetrp_cmp1.8" = icmp uge i32 %"viadd.6", 12
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P47_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 %"imad.17", i32 4294967288
  %"sel_pred_trunc.2" = trunc i32 %"P23_to_i32" to i1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_trunc.2" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 %"sel", i32 0
  %"sel_pred_trunc.3" = trunc i32 %"P36_to_i32" to i1
  %"sel_pred_to_i32.3" = zext i1 %"sel_pred_trunc.3" to i32
  %"sel_pred_to_i1.3" = icmp ne i32 %"sel_pred_to_i32.3", 0
  %"sel.3" = select  i1 %"sel_pred_to_i1.3", i32 %"sel.1", i32 0
  %"iadd3_n1.12" = add i32 %"phi.28", %"imad.13"
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", %"sel.2"
  %"iadd3_n1.13" = add i32 %"phi.28", %"imad.13"
  %"iadd3_n2.13" = add i32 %"iadd3_n1.13", %"sel.3"
  %"viadd.7" = add i32 %"phi.28", 8
  %"isetrp_cmp1.9" = icmp uge i32 %"viadd.6", 256
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"iadd3_o1_64.4" = zext i32 %"phi.30" to i64
  %"iadd3_o2_64.4" = zext i32 32 to i64
  %"iadd3_o3_64.4" = zext i32 0 to i64
  %"iadd3_tmp.4" = add i64 %"iadd3_o1_64.4", %"iadd3_o2_64.4"
  %"iadd3_tmp2.4" = add i64 %"iadd3_tmp.4", %"iadd3_o3_64.4"
  %"iadd3_trunc.4" = trunc i64 %"iadd3_tmp2.4" to i32
  %"iadd3_carry_val.4" = lshr i64 %"iadd3_tmp2.4", 32
  %"carry_ge_1.4" = icmp uge i64 %"iadd3_carry_val.4", 1
  %"P37_to_i32" = zext i1 %"carry_ge_1.4" to i32
  %"carry_ge_2.4" = icmp uge i64 %"iadd3_carry_val.4", 2
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"phi.29"
  %"imad_cin_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"imad_cin_ext.4" = zext i1 %"imad_cin_trunc.4" to i32
  %"imad_with_cin.4" = add i32 %"imad.18", %"imad_cin_ext.4"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"iadd3_n2.12", -4
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"iadd3_n2.13")
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".344" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".345" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".346" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"stg_addr_r0_ext" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1", -16
  %"R118:R113_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R118:R113_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.1", -12
  %"R118:R113_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R118:R113_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.2", -8
  %"R118:R113_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R118:R113_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.3", -4
  %"R118:R113_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R118:R113_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"R118:R113_addr_ptr.4" = inttoptr i64 %"stg_addr_packed_1.4" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R118:R113_addr_ptr.4"
  %"stg_addr_r0_ext.5" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 4
  %"R118:R113_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".344", i32 addrspace(1)* %"R118:R113_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 8
  %"R118:R113_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".345", i32 addrspace(1)* %"R118:R113_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 12
  %"R118:R113_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".346", i32 addrspace(1)* %"R118:R113_addr_ptr.7"
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.18" = trunc i32 %"P34_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0bc0", label %"BB_0dd0"
BB_0dd0:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0de0"
BB_0de0:
  %"cond_trunc.19" = trunc i32 %"P14_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000de0", label %"BB_0df0"
BB_0df0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".359" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".359" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.16", 65535
  %".360" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".361" = zext i32 64 to i64
  %".362" = zext i32 24 to i64
  %".363" = shl i64 %".360", %".362"
  %".364" = and i64 %".363", 4294967295
  %".365" = add i64 %".364", %".361"
  %".366" = trunc i64 %".365" to i32
  %"lds_addr_memaddr_offset_add.5" = add i32 %".366", 20
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".367" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".367" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".368" = xor i32 %"lds.4", -1
  %".369" = xor i32 65535, -1
  %".370" = xor i32 0, -1
  %".371" = and i32 %"lds.4", 65535
  %".372" = and i32 %".371", %".370"
  %".373" = and i32 %"lds.4", 65535
  %".374" = and i32 %".373", 0
  %".375" = or i32 %".372", %".374"
  %".376" = zext i32 0 to i64
  %".377" = zext i32 %".375" to i64
  %".378" = shl i64 %".377", 32
  %"shf_concat.7" = or i64 %".376", %".378"
  %"shf_shift_64.7" = zext i32 5 to i64
  %".379" = lshr i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_hi.2" = lshr i64 %".379", 32
  %"shf_result.7" = trunc i64 %"shf_hi.2" to i32
  %".380" = zext i32 %"imad.19" to i64
  %".381" = zext i32 0 to i64
  %".382" = shl i64 %".381", 32
  %"shf_concat.8" = or i64 %".380", %".382"
  %"shf_shift_64.8" = zext i32 %"shf_result.7" to i64
  %".383" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".383" to i32
  %".384" = xor i32 %"lds.5", -1
  %".385" = xor i32 %"shf_result.8", -1
  %".386" = xor i32 0, -1
  %".387" = and i32 %"lds.5", %"shf_result.8"
  %".388" = and i32 %".387", %".386"
  %".389" = and i32 %"lds.5", %"shf_result.8"
  %".390" = and i32 %".389", 0
  %".391" = or i32 %".388", %".390"
  %"isetrp_cmp1.10" = icmp ne i32 %".391", %"shf_result.8"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.17", 1
  %".392" = zext i32 %"imad.20" to i64
  %".393" = zext i32 0 to i64
  %".394" = shl i64 %".393", 32
  %"shf_concat.9" = or i64 %".392", %".394"
  %"shf_shift_64.9" = zext i32 %"shf_result.7" to i64
  %".395" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".395" to i32
  br label %"BB_0ec0"
BB_0ec0:
  %"cond_trunc.20" = trunc i32 %"P45_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_1050_10e0", label %"BB_0ed0"
BB_0ed0:
  %"lds_addr_memaddr_offset_add.6" = add i32 %".366", 24
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".398" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".398" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %".399" = xor i32 %"lds.6", -1
  %".400" = xor i32 %"shf_result.9", -1
  %".401" = xor i32 0, -1
  %".402" = and i32 %"lds.6", %"shf_result.9"
  %".403" = and i32 %".402", %".401"
  %".404" = and i32 %"lds.6", %"shf_result.9"
  %".405" = and i32 %".404", 0
  %".406" = or i32 %".403", %".405"
  %"isetrp_cmp1.11" = icmp ne i32 %".406", %"shf_result.9"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0f00"
BB_0f00:
  %"cond_trunc.21" = trunc i32 %"P58_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_1020_10b0", label %"BB_0f10"
BB_0f10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".409" = xor i32 0, -1
  %".410" = xor i32 %"shf_result.9", -1
  %".411" = xor i32 0, -1
  %".412" = and i32 %".409", %".410"
  %".413" = and i32 %".412", %".411"
  %".414" = and i32 %".409", %".410"
  %".415" = and i32 %".414", 0
  %".416" = or i32 %".413", %".415"
  %".417" = and i32 0, %".410"
  %".418" = and i32 %".417", %".411"
  %".419" = or i32 %".416", %".418"
  %".420" = and i32 0, %".410"
  %".421" = and i32 %".420", 0
  %".422" = or i32 %".419", %".421"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".422", i32 %"redux_mask")
  %".423" = xor i32 0, -1
  %".424" = xor i32 %"shf_result.8", -1
  %".425" = xor i32 0, -1
  %".426" = and i32 %".423", %".424"
  %".427" = and i32 %".426", %".425"
  %".428" = and i32 %".423", %".424"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".424"
  %".432" = and i32 %".431", %".425"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 0, %".424"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.18", %".436"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.21", i32 %"redux_mask.1")
  %".437" = xor i32 %".436", -1
  %".438" = call i32 @"llvm.cttz.i32"(i32 %".437", i1 0)
  %".439" = shl i32 %".438", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 512;", "r,~{memory}"(i32 %".439") convergent
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.19", %"redux_sync_and"
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P59_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.20", %"redux_sync_and.1"
  br label %"BB_0fe0"
BB_0fe0:
  %"cond_trunc.22" = trunc i32 %"P59_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000fe0", label %"BB_1060"
BB_80000fe0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".366", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".443" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".443" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.23" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".366", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".444" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".444" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.22" monotonic
  br label %"BB_1060"
BB_1020_10b0:
  call void @"llvm.trap"()
  br label %"BB_1060"
BB_1050_10e0:
  call void @"llvm.trap"()
  br label %"BB_1060"
BB_1060:
  ret void
BB_80000de0:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P15_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"UR5:UR4_r0" = trunc i64 %"ldc_const" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %"imad_tmp" = mul i32 %"tid_x", 4
  %"imad" = add i32 %"imad_tmp", 0
  %".12" = xor i32 %"imad", -1
  %".13" = xor i32 508, -1
  %".14" = xor i32 0, -1
  %".15" = and i32 %"imad", 508
  %".16" = and i32 %".15", %".14"
  %".17" = and i32 %"imad", 508
  %".18" = and i32 %".17", 0
  %".19" = or i32 %".16", %".18"
  %"iadd3_o1_64" = zext i32 %".19" to i64
  %"iadd3_o2_64" = zext i32 %"UR5:UR4_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", %"UR5:UR4_r1"
  %"imad_cin_trunc" = trunc i32 %"P1_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"ldg_addr_r0_ext" = zext i32 %"iadd3_trunc" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1", 8192
  %"R156:R143_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R156:R143_addr_ptr"
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".20" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".21" = zext i32 %"iadd3_n2" to i64
  %".22" = zext i32 24 to i64
  %".23" = shl i64 %".20", %".22"
  %".24" = and i64 %".23", 4294967295
  %".25" = add i64 %".24", %".21"
  %".26" = trunc i64 %".25" to i32
  %"viadd" = add i32 %"imad", %".26"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd.1", %"BB_0140"]
  %"phi.1" = phi  i32 [%"viadd", %"EntryBB_0000"], [%"viadd.2", %"BB_0140"]
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P56_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".28" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".28" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi", 128
  %"viadd.2" = add i32 %"phi.1", 512
  br label %"BB_0140"
BB_0140:
  %"cond_trunc" = trunc i32 %"P56_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0100", label %"BB_0150"
BB_0150:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %".32" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".33" = zext i32 1024 to i64
  %".34" = zext i32 24 to i64
  %".35" = shl i64 %".32", %".34"
  %".36" = and i64 %".35", 4294967295
  %".37" = add i64 %".36", %".33"
  %".38" = trunc i64 %".37" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %".41" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".42" = bitcast i8* %".41" to i64*
  %"ldc_const.1" = load i64, i64* %".42"
  %"R3:R2_r0" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"viadd.3" = add i32 %"imad", %".38"
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.2" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad.2" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.2", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P10_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P10_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.3", %"imad_cin_ext.1"
  br label %"BB_0220"
BB_0220:
  %"phi.2" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.3" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.4", %"BB_02a0"]
  %"phi.4" = phi  i32 [%"viadd.3", %"BB_01c0"], [%"viadd.5", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.5" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.2" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R36:R152_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R36:R152_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.3", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.4" = add i32 %"phi.3", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.5" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P29_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", %"phi.2"
  %"imad_cin_trunc.2" = trunc i32 %"P29_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.4", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.4", 16777215
  %".44" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".44" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.5" = add i32 %"phi.4", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.6" = phi  i32 [%"P15_to_i32", %"BB_01b0"], [%"P29_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P49_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P49_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 9216
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".50" = zext i32 %"iadd3_n2.2" to i64
  %".51" = zext i32 0 to i64
  %".52" = shl i64 %".51", 32
  %"shf_concat" = or i64 %".50", %".52"
  %"shf_shift_64" = zext i32 11 to i64
  %".53" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".53" to i32
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat.1" = or i64 %".54", %".56"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".57" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".57" to i32
  %".58" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".59" = zext i32 %"iadd3_n2.1" to i64
  %".60" = zext i32 24 to i64
  %".61" = shl i64 %".58", %".60"
  %".62" = and i64 %".61", 4294967295
  %".63" = add i64 %".62", %".59"
  %".64" = trunc i64 %".63" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.7" = phi  i32 [%".64", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000300"], [%"UR5:UR4_r1", %"BB_0300"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P50_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P50_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".69" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".69" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".70" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".70" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P14_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0520", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".38", 9224
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".74" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".75" = ptrtoint i8 addrspace(3)* %".74" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".75", i32 512) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P40_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P40_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0520", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", 65535
  %".79" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".80" = zext i32 64 to i64
  %".81" = zext i32 24 to i64
  %".82" = shl i64 %".79", %".81"
  %".83" = and i64 %".82", 4294967295
  %".84" = add i64 %".83", %".80"
  %".85" = trunc i64 %".84" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".38", 9224
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".86" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".87" = bitcast i8 addrspace(3)* %".86" to i32 addrspace(3)*
  %".88" = load i32, i32 addrspace(3)* %".87"
  %".89" = lshr i32 %".88", 5
  %"P52_to_i32" = zext i1 1 to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.6", %".89"
  %"bra_cond_trunc" = trunc i32 %"P52_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04b0", label %"BB_0450"
BB_0450:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".38", 9224
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".91" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".92" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  %".93" = load i32, i32 addrspace(3)* %".92"
  %".94" = lshr i32 %".93", 5
  %"P53_to_i32" = zext i1 1 to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", %".94"
  %"bra_cond_trunc.1" = trunc i32 %"P53_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0450", label %"BB_04b0"
BB_04b0:
  %"phi.10" = phi  i32 [%"imad.7", %"BB_03c0"], [%"imad.8", %"BB_0450"]
  %".96" = zext i32 %"imad.5" to i64
  %".97" = zext i32 0 to i64
  %".98" = shl i64 %".97", 32
  %"shf_concat.2" = or i64 %".96", %".98"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".99" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".99" to i32
  %".100" = zext i32 %"imad.6" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.3" = or i64 %".100", %".102"
  %"shf_shift_64.3" = zext i32 %"phi.10" to i64
  %".103" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".103" to i32
  %"imad_tmp.8" = mul i32 %"phi.10", 32
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".85", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".85", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".38", 9224
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.9", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0520"
BB_0520:
  %"phi.11" = phi  i32 [%"P40_to_i32", %"BB_04b0"], [%"P40_to_i32", %"BB_03b0"], [%"phi.6", %"BB_0380"]
  %".109" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".110" = bitcast i8* %".109" to i64*
  %"ldc_const.2" = load i64, i64* %".110"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.9" = mul i32 %"tid_x", 18
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.10" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.11" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.11" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.11", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9256
  %"R104:R105_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9260
  %"R104:R105_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9264
  %"R104:R105_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9268
  %"R104:R105_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9272
  %"R104:R105_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9276
  %"R104:R105_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9280
  %"R104:R105_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9284
  %"R104:R105_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.7"
  %"imad_tmp.10" = mul i32 %"tid_x", 65536
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".38", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".111" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".111" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".112" = xor i32 %"imad.12", -1
  %".113" = xor i32 65011712, -1
  %".114" = xor i32 0, -1
  %".115" = and i32 %"imad.12", 65011712
  %".116" = and i32 %".115", %".114"
  %".117" = and i32 %"imad.12", 65011712
  %".118" = and i32 %".117", 0
  %".119" = or i32 %".116", %".118"
  %"imad_tmp.11" = mul i32 %"lds", 1
  %"imad.13" = add i32 %"imad_tmp.11", %".119"
  %"sttm_memaddr_offset_add" = add i32 %"imad.13", 272
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4", i32 %"ldg.5")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.13", 276
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8", i32 %"ldg.9")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9216
  %"R104:R105_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.8"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9220
  %"R104:R105_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.9"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9224
  %"R104:R105_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.10"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9228
  %"R104:R105_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.11"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9232
  %"R104:R105_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.12"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9236
  %"R104:R105_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.13"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9240
  %"R104:R105_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.14"
  %"ldg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9244
  %"R104:R105_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R104:R105_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.13", 256
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12", i32 %"ldg.13")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.13", 260
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16", i32 %"ldg.17")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_07a0"
BB_07a0:
  %"cond_trunc.7" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0ae0", label %"BB_07b0"
BB_07b0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".129" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".129" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".130" = zext i32 0 to i64
  %".131" = zext i32 %".26" to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.4" = or i64 %".130", %".132"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".133" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".133", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".134" = xor i32 %"plop3_a_bit", 1
  %".135" = xor i32 %"plop3_b_bit", 1
  %".136" = xor i32 %"plop3_c_bit", 1
  %".137" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".138" = and i32 %".137", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".138", 0
  %"P3_to_i32" = zext i1 %"plop3_pred" to i32
  %".139" = zext i32 0 to i64
  %".140" = zext i32 %".38" to i64
  %".141" = shl i64 %".140", 32
  %"shf_concat.5" = or i64 %".139", %".141"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".142" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".142", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".143" = xor i32 %"shf_result.4", -1
  %".144" = xor i32 16376, -1
  %".145" = xor i32 0, -1
  %".146" = and i32 %"shf_result.4", 16376
  %".147" = and i32 %".146", %".145"
  %".148" = and i32 %"shf_result.4", 16376
  %".149" = and i32 %".148", 0
  %".150" = or i32 %".147", %".149"
  %".151" = xor i32 %"shf_result.5", -1
  %".152" = xor i32 16376, -1
  %".153" = xor i32 0, -1
  %".154" = and i32 %"shf_result.5", 16376
  %".155" = and i32 %".154", %".153"
  %".156" = and i32 %"shf_result.5", 16376
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = xor i32 %".150", -1
  %".160" = xor i32 524288, -1
  %".161" = xor i32 0, -1
  %".162" = and i32 %".159", 524288
  %".163" = and i32 %".162", %".161"
  %".164" = and i32 %".159", 524288
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = and i32 %".150", %".160"
  %".168" = and i32 %".167", %".161"
  %".169" = or i32 %".166", %".168"
  %".170" = and i32 %".150", %".160"
  %".171" = and i32 %".170", 0
  %".172" = or i32 %".169", %".171"
  %".173" = and i32 %".150", 524288
  %".174" = and i32 %".173", %".161"
  %".175" = or i32 %".172", %".174"
  %".176" = and i32 %".150", 524288
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = xor i32 %".158", -1
  %".180" = xor i32 524288, -1
  %".181" = xor i32 0, -1
  %".182" = and i32 %".179", 524288
  %".183" = and i32 %".182", %".181"
  %".184" = and i32 %".179", 524288
  %".185" = and i32 %".184", 0
  %".186" = or i32 %".183", %".185"
  %".187" = and i32 %".158", %".180"
  %".188" = and i32 %".187", %".181"
  %".189" = or i32 %".186", %".188"
  %".190" = and i32 %".158", %".180"
  %".191" = and i32 %".190", 0
  %".192" = or i32 %".189", %".191"
  %".193" = and i32 %".158", 524288
  %".194" = and i32 %".193", %".181"
  %".195" = or i32 %".192", %".194"
  %".196" = and i32 %".158", 524288
  %".197" = and i32 %".196", 0
  %".198" = or i32 %".195", %".197"
  %"iadd3_n1.3" = add i32 %"lds.1", 272
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0890"
BB_0890:
  %"phi.12" = phi  i32 [%"phi.11", %"BB_07b0"], [%"P46_to_i32", %"BB_08c0"]
  %"phi.13" = phi  i32 [%"P3_to_i32", %"BB_07b0"], [%"phi.15", %"BB_08c0"]
  %"cond_trunc.8" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000890", label %"BB_08a0"
BB_80000890:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P43_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_08a0"
BB_08a0:
  %"phi.14" = phi  i32 [%"P43_to_i32", %"BB_80000890"], [%"phi.12", %"BB_0890"]
  %"mma_b_r0_ext" = zext i32 %".178" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".202" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".203" = sub i64 %".202", 0
  %".204" = lshr i64 %".203", 4
  %".205" = add i64 %"mma_b_packed_1", %".204"
  %".206" = and i64 %".205", 16383
  %".207" = and i64 %"mma_b_packed_1", -16384
  %".208" = or i64 %".207", %".206"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.3", i64 %".208", i32 138417552, i32 %"mma_arg_zext")
  br label %"BB_08b0"
BB_08b0:
  %"cond_trunc.9" = trunc i32 %"phi.14" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800008b0", label %"BB_08c0"
BB_800008b0:
  %"lop3_a_trunc" = trunc i32 %"phi.14" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".212" = xor i32 %"plop3_a_bit.1", 1
  %".213" = xor i32 %"plop3_b_bit.1", 1
  %".214" = xor i32 %"plop3_c_bit.1", 1
  %".215" = and i32 %".212", %"plop3_b_bit.1"
  %".216" = and i32 %".215", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".216", 0
  %"P6_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_08c0"
BB_08c0:
  %"phi.15" = phi  i32 [%"P6_to_i32", %"BB_800008b0"], [%"phi.13", %"BB_08b0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".218" = xor i32 %"plop3_a_bit.2", 1
  %".219" = xor i32 %"plop3_b_bit.2", 1
  %".220" = xor i32 %"plop3_c_bit.2", 1
  %".221" = and i32 %".218", %"plop3_b_bit.2"
  %".222" = and i32 %".221", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".222", 0
  %"P46_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.15" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0890", label %"BB_08e0"
BB_08e0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".224" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".224" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".225" = xor i32 %"plop3_a_bit.3", 1
  %".226" = xor i32 %"plop3_b_bit.3", 1
  %".227" = xor i32 %"plop3_c_bit.3", 1
  %".228" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".229" = and i32 %".228", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".229", 0
  %"P8_to_i32" = zext i1 %"plop3_pred.3" to i32
  %"iadd3_n1.4" = add i32 %"lds.2", 272
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.2", 256
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.2", 260
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  br label %"BB_0960"
BB_0960:
  %"phi.16" = phi  i32 [%"P46_to_i32", %"BB_08e0"], [%"P20_to_i32", %"BB_0990"]
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_08e0"], [%"phi.19", %"BB_0990"]
  %"cond_trunc.10" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P18_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.18" = phi  i32 [%"P18_to_i32", %"BB_80000960"], [%"phi.16", %"BB_0960"]
  %"mma_b_r0_ext.1" = zext i32 %".198" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".233" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".234" = sub i64 %".233", 0
  %".235" = lshr i64 %".234", 4
  %".236" = add i64 %"mma_b_packed_1.1", %".235"
  %".237" = and i64 %".236", 16383
  %".238" = and i64 %"mma_b_packed_1.1", -16384
  %".239" = or i64 %".238", %".237"
  %"mma_arg_zext.1" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.4", i64 %".239", i32 679744944, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.6")
  br label %"BB_0980"
BB_0980:
  %"cond_trunc.11" = trunc i32 %"phi.18" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000980", label %"BB_0990"
BB_80000980:
  %"lop3_a_trunc.1" = trunc i32 %"phi.18" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".243" = xor i32 %"plop3_a_bit.4", 1
  %".244" = xor i32 %"plop3_b_bit.4", 1
  %".245" = xor i32 %"plop3_c_bit.4", 1
  %".246" = and i32 %".243", %"plop3_b_bit.4"
  %".247" = and i32 %".246", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".247", 0
  %"P5_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0990"
BB_0990:
  %"phi.19" = phi  i32 [%"P5_to_i32", %"BB_80000980"], [%"phi.17", %"BB_0980"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".249" = xor i32 %"plop3_a_bit.5", 1
  %".250" = xor i32 %"plop3_b_bit.5", 1
  %".251" = xor i32 %"plop3_c_bit.5", 1
  %".252" = and i32 %".249", %"plop3_b_bit.5"
  %".253" = and i32 %".252", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".253", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.19" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0960", label %"BB_09b0"
BB_09b0:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".255" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".255" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".256" = xor i32 %"plop3_a_bit.6", 1
  %".257" = xor i32 %"plop3_b_bit.6", 1
  %".258" = xor i32 %"plop3_c_bit.6", 1
  %".259" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".260" = and i32 %".259", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".260", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  %"iadd3_n1.7" = add i32 %"lds.3", 272
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"iadd3_n1.8" = add i32 %"lds.3", 256
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"iadd3_n1.9" = add i32 %"lds.3", 260
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  br label %"BB_0a10"
BB_0a10:
  %"phi.20" = phi  i32 [%"P20_to_i32", %"BB_09b0"], [%"P25_to_i32", %"BB_0a40"]
  %"phi.21" = phi  i32 [%"P27_to_i32", %"BB_09b0"], [%"phi.23", %"BB_0a40"]
  %"cond_trunc.12" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P22_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.22" = phi  i32 [%"P22_to_i32", %"BB_80000a10"], [%"phi.20", %"BB_0a10"]
  %"mma_b_r0_ext.2" = zext i32 %".198" to i64
  %"mma_b_packed_0.2" = or i64 0, %"mma_b_r0_ext.2"
  %"mma_b_r1_ext.2" = zext i32 16400 to i64
  %"mma_b_r1_shift.2" = shl i64 %"mma_b_r1_ext.2", 32
  %"mma_b_packed_1.2" = or i64 %"mma_b_packed_0.2", %"mma_b_r1_shift.2"
  %".264" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".265" = sub i64 %".264", 0
  %".266" = lshr i64 %".265", 4
  %".267" = add i64 %"mma_b_packed_1.2", %".266"
  %".268" = and i64 %".267", 16383
  %".269" = and i64 %"mma_b_packed_1.2", -16384
  %".270" = or i64 %".269", %".268"
  %"mma_arg_zext.2" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.7", i64 %".270", i32 679744944, i32 %"mma_arg_zext.2", i32 %"iadd3_n2.8", i32 %"iadd3_n2.9")
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.13" = trunc i32 %"phi.22" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000a30", label %"BB_0a40"
BB_80000a30:
  %"lop3_a_trunc.2" = trunc i32 %"phi.22" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".274" = xor i32 %"plop3_a_bit.7", 1
  %".275" = xor i32 %"plop3_b_bit.7", 1
  %".276" = xor i32 %"plop3_c_bit.7", 1
  %".277" = and i32 %".274", %"plop3_b_bit.7"
  %".278" = and i32 %".277", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".278", 0
  %"P48_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.23" = phi  i32 [%"P48_to_i32", %"BB_80000a30"], [%"phi.21", %"BB_0a30"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".280" = xor i32 %"plop3_a_bit.8", 1
  %".281" = xor i32 %"plop3_b_bit.8", 1
  %".282" = xor i32 %"plop3_c_bit.8", 1
  %".283" = and i32 %".280", %"plop3_b_bit.8"
  %".284" = and i32 %".283", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".284", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.4" = trunc i32 %"phi.23" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.4")
  br i1 %"branch_any.2", label %"BB_0a10", label %"BB_0a60"
BB_0a60:
  %"iadd3_n1.10" = add i32 1024, 9216
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".286" = xor i32 %"plop3_a_bit.9", 1
  %".287" = xor i32 %"plop3_b_bit.9", 1
  %".288" = xor i32 %"plop3_c_bit.9", 1
  %".289" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".290" = and i32 %".289", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".290", 0
  %"P55_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".291" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".292" = zext i32 %"iadd3_n2.10" to i64
  %".293" = zext i32 24 to i64
  %".294" = shl i64 %".291", %".293"
  %".295" = and i64 %".294", 4294967295
  %".296" = add i64 %".295", %".292"
  %".297" = trunc i64 %".296" to i32
  br label %"BB_0a90"
BB_0a90:
  %"phi.24" = phi  i32 [%"P25_to_i32", %"BB_0a60"], [%"P31_to_i32", %"BB_0ac0"]
  %"phi.25" = phi  i32 [%"P55_to_i32", %"BB_0a60"], [%"phi.27", %"BB_0ac0"]
  %"cond_trunc.14" = trunc i32 %"phi.25" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000a90", label %"BB_0aa0"
BB_80000a90:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P28_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0aa0"
BB_0aa0:
  %"phi.26" = phi  i32 [%"P28_to_i32", %"BB_80000a90"], [%"phi.24", %"BB_0a90"]
  %"utcbar_local_winoff" = and i32 %".297", 16777215
  %".301" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".302" = ptrtoint i8 addrspace(3)* %".301" to i32
  %".303" = lshr i32 %".297", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".302", i32 %".303")
  br label %"BB_0ab0"
BB_0ab0:
  %"cond_trunc.15" = trunc i32 %"phi.26" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000ab0", label %"BB_0ac0"
BB_80000ab0:
  %"lop3_a_trunc.3" = trunc i32 %"phi.26" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".307" = xor i32 %"plop3_a_bit.10", 1
  %".308" = xor i32 %"plop3_b_bit.10", 1
  %".309" = xor i32 %"plop3_c_bit.10", 1
  %".310" = and i32 %".307", %"plop3_b_bit.10"
  %".311" = and i32 %".310", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".311", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_0ac0"
BB_0ac0:
  %"phi.27" = phi  i32 [%"P11_to_i32", %"BB_80000ab0"], [%"phi.25", %"BB_0ab0"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".313" = xor i32 %"plop3_a_bit.11", 1
  %".314" = xor i32 %"plop3_b_bit.11", 1
  %".315" = xor i32 %"plop3_c_bit.11", 1
  %".316" = and i32 %".313", %"plop3_b_bit.11"
  %".317" = and i32 %".316", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".317", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.5" = trunc i32 %"phi.27" to i1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_trunc.5" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.5")
  br i1 %"branch_any.3", label %"BB_0a90", label %"BB_0ae0"
BB_0ae0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.11" = add i32 1024, 9216
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %".319" = zext i32 0 to i64
  %".320" = zext i32 0 to i64
  %".321" = shl i64 %".320", 32
  %"shf_concat.6" = or i64 %".319", %".321"
  %"shf_shift_64.6" = zext i32 31 to i64
  %".322" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".322" to i32
  %".323" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".324" = zext i32 %"iadd3_n2.11" to i64
  %".325" = zext i32 24 to i64
  %".326" = shl i64 %".323", %".325"
  %".327" = and i64 %".326", 4294967295
  %".328" = add i64 %".327", %".324"
  %".329" = trunc i64 %".328" to i32
  %".330" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".331" = bitcast i8* %".330" to i64*
  %"ldc_const.3" = load i64, i64* %".331"
  %"R5:R4_r0" = trunc i64 %"ldc_const.3" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.3", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"mbar_shared_winoff.1" = and i32 %".329", 16777215
  %".332" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".332" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P51_to_i32" = zext i1 %"mbar_ready" to i32
  %"imad_addend_r0_ext.2" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"tid_x" to i64
  %"imad_rhs_64.2" = zext i32 1056 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R5:R4_r0.1" = trunc i64 %"imad.14" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad.14", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64.3" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64.3" = zext i32 16 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P33_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  br label %"BB_0b80"
BB_0b80:
  %"cond_trunc.16" = trunc i32 %"P51_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1080", label %"BB_0b90"
BB_1080:
  %"mbar_shared_winoff.2" = and i32 %".329", 16777215
  %".335" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".335" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.6", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P57_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1090"
BB_1090:
  %"cond_trunc.17" = trunc i32 %"P57_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_1080", label %"BB_0b90"
BB_0b90:
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 4
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"R5:R4_r1.1"
  %"imad_cin_trunc.3" = trunc i32 %"P33_to_i32" to i1
  %"imad_cin_ext.3" = zext i1 %"imad_cin_trunc.3" to i32
  %"imad_with_cin.3" = add i32 %"imad.16", %"imad_cin_ext.3"
  br label %"BB_0bc0"
BB_0bc0:
  %"phi.28" = phi  i32 [%"imad.15", %"BB_0b90"], [%"viadd.7", %"BB_0dc0"]
  %"phi.29" = phi  i32 [%"imad_with_cin.3", %"BB_0b90"], [%"imad_with_cin.4", %"BB_0dc0"]
  %"phi.30" = phi  i32 [%"iadd3_trunc.3", %"BB_0b90"], [%"iadd3_trunc.4", %"BB_0dc0"]
  %"viadd.6" = add i32 %"phi.28", 4294967292
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", 240
  %"isetrp_cmp1.5" = icmp uge i32 %"viadd.6", 24
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"isetrp_cmp1.6" = icmp uge i32 %"viadd.6", 20
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P47_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"isetrp_cmp1.7" = icmp uge i32 %"viadd.6", 16
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"sel_pred_trunc" = trunc i32 %"P35_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 %"imad.17", i32 4294967288
  %"isetrp_cmp1.8" = icmp uge i32 %"viadd.6", 12
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P47_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 %"imad.17", i32 4294967288
  %"sel_pred_trunc.2" = trunc i32 %"P23_to_i32" to i1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_trunc.2" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 %"sel", i32 0
  %"sel_pred_trunc.3" = trunc i32 %"P36_to_i32" to i1
  %"sel_pred_to_i32.3" = zext i1 %"sel_pred_trunc.3" to i32
  %"sel_pred_to_i1.3" = icmp ne i32 %"sel_pred_to_i32.3", 0
  %"sel.3" = select  i1 %"sel_pred_to_i1.3", i32 %"sel.1", i32 0
  %"iadd3_n1.12" = add i32 %"phi.28", %"imad.13"
  %"iadd3_n2.12" = add i32 %"iadd3_n1.12", %"sel.2"
  %"iadd3_n1.13" = add i32 %"phi.28", %"imad.13"
  %"iadd3_n2.13" = add i32 %"iadd3_n1.13", %"sel.3"
  %"viadd.7" = add i32 %"phi.28", 8
  %"isetrp_cmp1.9" = icmp uge i32 %"viadd.6", 256
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  %"iadd3_o1_64.4" = zext i32 %"phi.30" to i64
  %"iadd3_o2_64.4" = zext i32 32 to i64
  %"iadd3_o3_64.4" = zext i32 0 to i64
  %"iadd3_tmp.4" = add i64 %"iadd3_o1_64.4", %"iadd3_o2_64.4"
  %"iadd3_tmp2.4" = add i64 %"iadd3_tmp.4", %"iadd3_o3_64.4"
  %"iadd3_trunc.4" = trunc i64 %"iadd3_tmp2.4" to i32
  %"iadd3_carry_val.4" = lshr i64 %"iadd3_tmp2.4", 32
  %"carry_ge_1.4" = icmp uge i64 %"iadd3_carry_val.4", 1
  %"P37_to_i32" = zext i1 %"carry_ge_1.4" to i32
  %"carry_ge_2.4" = icmp uge i64 %"iadd3_carry_val.4", 2
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"phi.29"
  %"imad_cin_trunc.4" = trunc i32 %"P37_to_i32" to i1
  %"imad_cin_ext.4" = zext i1 %"imad_cin_trunc.4" to i32
  %"imad_with_cin.4" = add i32 %"imad.18", %"imad_cin_ext.4"
  %"ldtm_addr_memaddr_offset_add" = add i32 %"iadd3_n2.12", -4
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"iadd3_n2.13")
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".344" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".345" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".346" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"stg_addr_r0_ext" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1", -16
  %"R118:R113_addr_ptr" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R118:R113_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.1", -12
  %"R118:R113_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R118:R113_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.2", -8
  %"R118:R113_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R118:R113_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.3", -4
  %"R118:R113_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R118:R113_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"R118:R113_addr_ptr.4" = inttoptr i64 %"stg_addr_packed_1.4" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R118:R113_addr_ptr.4"
  %"stg_addr_r0_ext.5" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 4
  %"R118:R113_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".344", i32 addrspace(1)* %"R118:R113_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 8
  %"R118:R113_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".345", i32 addrspace(1)* %"R118:R113_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"phi.30" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"phi.29" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 12
  %"R118:R113_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".346", i32 addrspace(1)* %"R118:R113_addr_ptr.7"
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.18" = trunc i32 %"P34_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0bc0", label %"BB_0dd0"
BB_0dd0:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0de0"
BB_0de0:
  %"cond_trunc.19" = trunc i32 %"P14_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000de0", label %"BB_0df0"
BB_0df0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".38", 9224
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".359" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".359" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.16", 65535
  %".360" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".361" = zext i32 64 to i64
  %".362" = zext i32 24 to i64
  %".363" = shl i64 %".360", %".362"
  %".364" = and i64 %".363", 4294967295
  %".365" = add i64 %".364", %".361"
  %".366" = trunc i64 %".365" to i32
  %"lds_addr_memaddr_offset_add.5" = add i32 %".366", 20
  %"lds_shared_addr_winoff.5" = and i32 %"lds_addr_memaddr_offset_add.5", 16777215
  %".367" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".367" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.5"
  %".368" = xor i32 %"lds.4", -1
  %".369" = xor i32 65535, -1
  %".370" = xor i32 0, -1
  %".371" = and i32 %"lds.4", 65535
  %".372" = and i32 %".371", %".370"
  %".373" = and i32 %"lds.4", 65535
  %".374" = and i32 %".373", 0
  %".375" = or i32 %".372", %".374"
  %".376" = zext i32 0 to i64
  %".377" = zext i32 %".375" to i64
  %".378" = shl i64 %".377", 32
  %"shf_concat.7" = or i64 %".376", %".378"
  %"shf_shift_64.7" = zext i32 5 to i64
  %".379" = lshr i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_hi.2" = lshr i64 %".379", 32
  %"shf_result.7" = trunc i64 %"shf_hi.2" to i32
  %".380" = zext i32 %"imad.19" to i64
  %".381" = zext i32 0 to i64
  %".382" = shl i64 %".381", 32
  %"shf_concat.8" = or i64 %".380", %".382"
  %"shf_shift_64.8" = zext i32 %"shf_result.7" to i64
  %".383" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".383" to i32
  %".384" = xor i32 %"lds.5", -1
  %".385" = xor i32 %"shf_result.8", -1
  %".386" = xor i32 0, -1
  %".387" = and i32 %"lds.5", %"shf_result.8"
  %".388" = and i32 %".387", %".386"
  %".389" = and i32 %"lds.5", %"shf_result.8"
  %".390" = and i32 %".389", 0
  %".391" = or i32 %".388", %".390"
  %"isetrp_cmp1.10" = icmp ne i32 %".391", %"shf_result.8"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.17", 1
  %".392" = zext i32 %"imad.20" to i64
  %".393" = zext i32 0 to i64
  %".394" = shl i64 %".393", 32
  %"shf_concat.9" = or i64 %".392", %".394"
  %"shf_shift_64.9" = zext i32 %"shf_result.7" to i64
  %".395" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".395" to i32
  br label %"BB_0ec0"
BB_0ec0:
  %"cond_trunc.20" = trunc i32 %"P45_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_1050_10e0", label %"BB_0ed0"
BB_0ed0:
  %"lds_addr_memaddr_offset_add.6" = add i32 %".366", 24
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.6", 16777215
  %".398" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".398" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  %".399" = xor i32 %"lds.6", -1
  %".400" = xor i32 %"shf_result.9", -1
  %".401" = xor i32 0, -1
  %".402" = and i32 %"lds.6", %"shf_result.9"
  %".403" = and i32 %".402", %".401"
  %".404" = and i32 %"lds.6", %"shf_result.9"
  %".405" = and i32 %".404", 0
  %".406" = or i32 %".403", %".405"
  %"isetrp_cmp1.11" = icmp ne i32 %".406", %"shf_result.9"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0f00"
BB_0f00:
  %"cond_trunc.21" = trunc i32 %"P58_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_1020_10b0", label %"BB_0f10"
BB_0f10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".409" = xor i32 0, -1
  %".410" = xor i32 %"shf_result.9", -1
  %".411" = xor i32 0, -1
  %".412" = and i32 %".409", %".410"
  %".413" = and i32 %".412", %".411"
  %".414" = and i32 %".409", %".410"
  %".415" = and i32 %".414", 0
  %".416" = or i32 %".413", %".415"
  %".417" = and i32 0, %".410"
  %".418" = and i32 %".417", %".411"
  %".419" = or i32 %".416", %".418"
  %".420" = and i32 0, %".410"
  %".421" = and i32 %".420", 0
  %".422" = or i32 %".419", %".421"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".422", i32 %"redux_mask")
  %".423" = xor i32 0, -1
  %".424" = xor i32 %"shf_result.8", -1
  %".425" = xor i32 0, -1
  %".426" = and i32 %".423", %".424"
  %".427" = and i32 %".426", %".425"
  %".428" = and i32 %".423", %".424"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".424"
  %".432" = and i32 %".431", %".425"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 0, %".424"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.18", %".436"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.21", i32 %"redux_mask.1")
  %".437" = xor i32 %".436", -1
  %".438" = call i32 @"llvm.cttz.i32"(i32 %".437", i1 0)
  %".439" = shl i32 %".438", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 512;", "r,~{memory}"(i32 %".439") convergent
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.19", %"redux_sync_and"
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P59_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.20", %"redux_sync_and.1"
  br label %"BB_0fe0"
BB_0fe0:
  %"cond_trunc.22" = trunc i32 %"P59_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000fe0", label %"BB_1060"
BB_80000fe0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".366", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".443" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".443" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.23" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".366", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".444" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".444" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.22" monotonic
  br label %"BB_1060"
BB_1020_10b0:
  call void @"llvm.trap"()
  br label %"BB_1060"
BB_1050_10e0:
  call void @"llvm.trap"()
  br label %"BB_1060"
BB_1060:
  ret void
BB_80000de0:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
