; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../p2a/ir/p0/fprop.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../p2a/ir/p0/fprop.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [12288 x i8], align 16
@const_mem = global [5 x [1840 x i8]] zeroinitializer, align 16

define void @sm80_xmma_fprop_implicit_gemm_f16f16_f16f32_f32_nhwckrsc_nhwc_tilesize64x32x64_stage5_warpsize2x2x1_g1_tensor16x8x16_execute_kernel__5x_cudnn([1488 x i8] %arg_352) #0 {
EntryBB_0000:
  %lo.frag = alloca [32 x float], align 4
  %p2c.q209 = alloca [18 x i64], align 8
  store i64 0, ptr %p2c.q209, align 8
  %0 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 8
  store i64 0, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 16
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 24
  store i64 0, ptr %2, align 8
  %3 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 32
  store i64 0, ptr %3, align 8
  %4 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 40
  store i64 0, ptr %4, align 8
  %5 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 48
  store i64 0, ptr %5, align 8
  %6 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 56
  store i64 0, ptr %6, align 8
  %7 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 64
  store i64 0, ptr %7, align 8
  %8 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 72
  store i64 0, ptr %8, align 8
  %9 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 80
  store i64 0, ptr %9, align 8
  %10 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 88
  store i64 0, ptr %10, align 8
  %11 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 96
  store i64 0, ptr %11, align 8
  %12 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 104
  store i64 0, ptr %12, align 8
  %13 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 112
  store i64 0, ptr %13, align 8
  %14 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 120
  store i64 0, ptr %14, align 8
  %15 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 128
  store i64 0, ptr %15, align 8
  %16 = getelementptr inbounds nuw i8, ptr %p2c.q209, i64 136
  store i64 0, ptr %16, align 8
  %param_local = alloca [1840 x i8], align 16
  %.3 = getelementptr inbounds nuw i8, ptr %param_local, i64 352
  store [1488 x i8] %arg_352, ptr %.3, align 32
  %ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %.8 = getelementptr inbounds nuw i8, ptr %param_local, i64 792
  %ldc_const = load i32, ptr %.8, align 4
  %s2ur_ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %isetrp_cmp1.1.not = icmp eq i32 %ldc_const, 0
  %s2ur_ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %.6 = getelementptr inbounds nuw i8, ptr %param_local, i64 784
  %isetrp_rhs = load i32, ptr %.6, align 4
  %isetrp_cmp1.not = icmp eq i32 %isetrp_rhs, 0
  br i1 %isetrp_cmp1.not, label %BB_0380, label %BB_0080

BB_0080:                                          ; preds = %EntryBB_0000
  %.12 = getelementptr inbounds nuw i8, ptr %param_local, i64 1608
  %ldc_const.1 = load i32, ptr %.12, align 4
  %shf_shift_64 = zext i32 %ldc_const.1 to i64
  %.17 = shl i64 4294967295, %shf_shift_64
  %shf_result = trunc i64 %.17 to i32
  %.18 = getelementptr inbounds nuw i8, ptr %param_local, i64 832
  %ldc_const.2 = load i64, ptr %.18, align 8
  %"UR7:UR6_r0" = trunc i64 %ldc_const.2 to i32
  %"UR7:UR6_r1_shift" = lshr i64 %ldc_const.2, 32
  %"UR7:UR6_r1" = trunc nuw i64 %"UR7:UR6_r1_shift" to i32
  %sel = select i1 %isetrp_cmp1.1.not, i32 %"UR7:UR6_r1", i32 %"UR7:UR6_r0"
  %.21 = xor i32 %shf_result, -1
  %.36 = or i32 %s2ur_ctaid_y, %.21
  %.43 = shl nuw i64 1, %shf_shift_64
  %shf_result.1 = trunc i64 %.43 to i32
  %sel.1 = select i1 %isetrp_cmp1.1.not, i32 %"UR7:UR6_r0", i32 %"UR7:UR6_r1"
  %.52 = and i32 %s2ur_ctaid_y, %shf_result.1
  %lop3_pred_cmp.1.not = icmp ne i32 %.52, 0
  %sel.2 = zext i1 %lop3_pred_cmp.1.not to i32
  %isetrp_cmp1.2.not = icmp ult i32 %.36, %sel
  br i1 %isetrp_cmp1.2.not, label %BB_0290, label %BB_01a0.preheader

BB_01a0.preheader:                                ; preds = %BB_0080
  br label %BB_01a0

BB_01a0:                                          ; preds = %BB_01a0.preheader, %BB_01e0
  %phi = phi i32 [ %iadd3_n1, %BB_01e0 ], [ %ldc_const.1, %BB_01a0.preheader ]
  %phi.1 = phi i32 [ %17, %BB_01e0 ], [ %.21, %BB_01a0.preheader ]
  %phi.2 = phi i32 [ %phi.4, %BB_01e0 ], [ %sel.2, %BB_01a0.preheader ]
  %phi.3 = phi i32 [ %.99, %BB_01e0 ], [ %.36, %BB_01a0.preheader ]
  %isetrp_cmp1.4 = icmp ne i32 %phi, 2
  %isetrp_cmp1.3.not = icmp ne i32 %phi.3, %sel
  %brmerge = or i1 %isetrp_cmp1.3.not, %isetrp_cmp1.4
  br i1 %brmerge, label %BB_01e0, label %BB_02e0

BB_01e0:                                          ; preds = %BB_01a0
  %17 = lshr i32 %phi.1, 1
  %iadd3_n1 = add i32 %phi, -1
  %.99 = or i32 %s2ur_ctaid_y, %17
  %isetrp_cmp1.5.not = icmp ult i32 %.99, %sel
  %shf_shift_64.3 = zext nneg i32 %iadd3_n1 to i64
  %.106 = shl nuw i64 1, %shf_shift_64.3
  %shf_result.3 = trunc i64 %.106 to i32
  %.110 = and i32 %s2ur_ctaid_y, %shf_result.3
  %lop3_pred_cmp.2.not = icmp ne i32 %.110, 0
  %sel.3 = zext i1 %lop3_pred_cmp.2.not to i32
  %phi.4 = xor i32 %phi.2, %sel.3
  br i1 %isetrp_cmp1.5.not, label %BB_0290.loopexit, label %BB_01a0

BB_02e0:                                          ; preds = %BB_01a0
  %.127 = and i32 %phi.1, %s2ur_ctaid_y
  %.133 = xor i32 %phi.1, -1
  %.135 = and i32 %s2ur_ctaid_y, %.133
  %imad_tmp.1 = mul i32 %.127, %sel.1
  %imad.1 = add i32 %imad_tmp.1, %s2ur_ctaid_x
  %imad_lhs_64 = zext i32 %imad.1 to i64
  %imad_tmp_64 = mul nuw nsw i64 %imad_lhs_64, 1431655766
  %"UR9:UR8_r1_shift" = lshr i64 %imad_tmp_64, 32
  %"UR9:UR8_r1" = trunc nuw nsw i64 %"UR9:UR8_r1_shift" to i32
  %iadd3_n1.1 = add i32 %imad.1, %.135
  %imad_tmp.2 = mul i32 %"UR9:UR8_r1", -3
  %imad.3 = add i32 %imad_tmp.2, %iadd3_n1.1
  br label %BB_0350

BB_0290.loopexit:                                 ; preds = %BB_01e0
  br label %BB_0290

BB_0290:                                          ; preds = %BB_0290.loopexit, %BB_0080
  %phi.5 = phi i32 [ %ldc_const.1, %BB_0080 ], [ %iadd3_n1, %BB_0290.loopexit ]
  %phi.6 = phi i32 [ %.21, %BB_0080 ], [ %17, %BB_0290.loopexit ]
  %phi.7 = phi i32 [ %sel.2, %BB_0080 ], [ %phi.4, %BB_0290.loopexit ]
  %.144 = and i32 %phi.6, %s2ur_ctaid_y
  %imad_tmp.3 = mul i32 %.144, %sel.1
  %imad.4 = add i32 %imad_tmp.3, %s2ur_ctaid_x
  %.150 = zext i32 %imad.4 to i64
  %.151 = shl nuw i64 %.150, 32
  %shf_shift_64.4 = zext nneg i32 %phi.5 to i64
  %.152 = lshr i64 %.151, %shf_shift_64.4
  %shf_hi.1 = lshr i64 %.152, 32
  %shf_result.4 = trunc nuw i64 %shf_hi.1 to i32
  %.154 = xor i32 %phi.6, -1
  %.158 = and i32 %s2ur_ctaid_y, %.154
  %18 = and i32 %phi.6, %imad.4
  %.166 = or i32 %18, %.158
  br label %BB_0350

BB_0350:                                          ; preds = %BB_0290, %BB_02e0
  %phi.8 = phi i32 [ %shf_result.4, %BB_0290 ], [ %"UR9:UR8_r1", %BB_02e0 ]
  %phi.9 = phi i32 [ %.166, %BB_0290 ], [ %imad.3, %BB_02e0 ]
  %phi.10 = phi i32 [ %phi.7, %BB_0290 ], [ %phi.2, %BB_02e0 ]
  %isetrp_cmp1.7.not = icmp eq i32 %phi.10, 0
  br i1 %isetrp_cmp1.7.not, label %BB_0380, label %BB_80000370

BB_80000370:                                      ; preds = %BB_0350
  %.169 = xor i32 %phi.8, -1
  %iadd3_n1.2 = add i32 %sel.1, %.169
  br label %BB_0380

BB_0380:                                          ; preds = %BB_80000370, %BB_0350, %EntryBB_0000
  %phi.11 = phi i32 [ %s2ur_ctaid_x, %EntryBB_0000 ], [ %iadd3_n1.2, %BB_80000370 ], [ %phi.8, %BB_0350 ]
  %phi.12 = phi i32 [ %s2ur_ctaid_y, %EntryBB_0000 ], [ %phi.9, %BB_80000370 ], [ %phi.9, %BB_0350 ]
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %sel.4 = select i1 %isetrp_cmp1.1.not, i32 %phi.11, i32 %phi.12
  %sel.5 = select i1 %isetrp_cmp1.1.not, i32 %phi.12, i32 %phi.11
  %.185 = getelementptr inbounds nuw i8, ptr %param_local, i64 940
  %imad_rhs = load i32, ptr %.185, align 4
  %imad_tmp.5 = mul i32 %ctaid_z, %imad_rhs
  %.187 = getelementptr inbounds nuw i8, ptr %param_local, i64 968
  %isetrp_rhs.1 = load i32, ptr %.187, align 4
  %isetrp_cmp1.8.not = icmp eq i32 %isetrp_rhs.1, 1
  %.192 = shl i32 %sel.4, 6
  %.193 = getelementptr inbounds nuw i8, ptr %param_local, i64 972
  %isetrp_rhs.2 = load i32, ptr %.193, align 4
  %isetrp_cmp1.9.not = icmp eq i32 %isetrp_rhs.2, 1
  %.195 = getelementptr inbounds nuw i8, ptr %param_local, i64 456
  %ldc_const.4 = load i32, ptr %.195, align 4
  %.197 = getelementptr inbounds nuw i8, ptr %param_local, i64 436
  %isetrp_rhs.3 = load i32, ptr %.197, align 4
  %isetrp_cmp1.10.not = icmp eq i32 %isetrp_rhs.3, 1
  %isetrp_cmp1.11 = icmp sgt i32 %ldc_const.4, 1
  %.202 = shl i32 %sel.5, 5
  %.203 = getelementptr inbounds nuw i8, ptr %param_local, i64 424
  %ldc_const.5 = load i32, ptr %.203, align 4
  %sel.6 = select i1 %isetrp_cmp1.11, i32 %.202, i32 0
  %imad_tmp.6 = mul i32 %ldc_const.4, %ldc_const.5
  %.205 = getelementptr inbounds nuw i8, ptr %param_local, i64 632
  %mov = load i32, ptr %.205, align 4
  %.207 = getelementptr inbounds nuw i8, ptr %param_local, i64 628
  %imad_addend = load i32, ptr %.207, align 4
  %.210 = zext i32 %tid_x to i64
  %.211 = shl nuw i64 %.210, 32
  %.212 = ashr exact i64 %.211, 31
  %.213 = getelementptr inbounds nuw i8, ptr %param_local, i64 636
  %mov.1 = load i32, ptr %.213, align 4
  %.215 = getelementptr inbounds nuw i8, ptr %param_local, i64 460
  %imad_addend.1 = load i32, ptr %.215, align 4
  %.223 = lshr i64 %.212, 61
  %19 = trunc nuw nsw i64 %.223 to i32
  %.225 = add i32 %tid_x, %19
  %.226 = getelementptr inbounds nuw i8, ptr %param_local, i64 1576
  %lop3_b = load i32, ptr %.226, align 4
  %.229 = xor i32 %lop3_b, -1
  %.243 = zext i32 %.225 to i64
  %.244 = shl nuw i64 %.243, 32
  %.245 = ashr exact i64 %.244, 3
  %shf_hi.3 = lshr i64 %.245, 32
  %shf_result.8 = trunc nuw i64 %shf_hi.3 to i32
  %.249 = ashr exact i64 %.244, 31
  %iadd3_n1.3 = add i32 %.192, %shf_result.8
  %.255 = lshr i64 %.249, 32
  %.256 = and i64 %.255, 7
  %.257 = add nuw nsw i64 %.256, %shf_hi.3
  %.258 = trunc i64 %.257 to i32
  %.262 = and i32 %.225, -8
  br i1 %isetrp_cmp1.8.not, label %BB_0610, label %BB_80000600

BB_80000600:                                      ; preds = %BB_0380
  %.269 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.1 = load i32, ptr %.269, align 4
  %imad_lhs_64.1 = zext i32 %iadd3_n1.3 to i64
  %imad_rhs_64.1 = zext i32 %imad_rhs.1 to i64
  %imad_tmp_64.1 = mul nuw i64 %imad_lhs_64.1, %imad_rhs_64.1
  %imad_tmp_hi = lshr i64 %imad_tmp_64.1, 32
  %imad_tmp_hi_trunc = trunc nuw i64 %imad_tmp_hi to i32
  br label %BB_0610

BB_0610:                                          ; preds = %BB_80000600, %BB_0380
  %phi.13 = phi i32 [ %imad_tmp_hi_trunc, %BB_80000600 ], [ 0, %BB_0380 ]
  %.275 = and i32 %.258, 268435448
  %iadd3_n1.4 = sub i32 %tid_x, %.262
  br i1 %isetrp_cmp1.8.not, label %BB_0650, label %BB_80000640

BB_80000640:                                      ; preds = %BB_0610
  %.282 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %shf_shift = load i32, ptr %.282, align 4
  %.285 = zext i32 %phi.13 to i64
  %.286 = shl nuw i64 %.285, 32
  %shf_shift_64.10 = zext nneg i32 %shf_shift to i64
  %.287 = lshr i64 %.286, %shf_shift_64.10
  %shf_hi.5 = lshr i64 %.287, 32
  %shf_result.10 = trunc nuw i64 %shf_hi.5 to i32
  br label %BB_0650

BB_0650:                                          ; preds = %BB_80000640, %BB_0610
  %phi.14 = phi i32 [ %shf_result.10, %BB_80000640 ], [ %iadd3_n1.3, %BB_0610 ]
  %imad.10 = sub i32 %shf_result.8, %.275
  %20 = ashr i32 %.225, 3
  %.295 = add i32 %20, %.192
  %.306 = xor i32 %iadd3_n1.4, %imad.10
  %imad_tmp.10 = shl i32 %iadd3_n1.4, 3
  %imad.11 = add i32 %imad_tmp.10, %imad_tmp.5
  %iadd3_o1_neg.1 = sub i32 0, %phi.14
  %phi.15 = select i1 %isetrp_cmp1.8.not, i32 %imad.10, i32 %iadd3_o1_neg.1
  %iadd3_n1.6 = add i32 %.295, 32
  %iadd3_n1.7 = add i32 %.295, 48
  %imad_rhs.2 = load i32, ptr %.187, align 4
  %imad_tmp.12 = mul i32 %phi.15, %imad_rhs.2
  %imad.13 = add i32 %imad_tmp.12, %iadd3_n1.3
  %phi.16 = select i1 %isetrp_cmp1.8.not, i32 0, i32 %imad.13
  %iadd3_n1.8 = add i32 %iadd3_n1.3, 16
  br i1 %isetrp_cmp1.8.not, label %BB_0700, label %BB_800006f0

BB_800006f0:                                      ; preds = %BB_0650
  %.320 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.3 = load i32, ptr %.320, align 4
  %imad_lhs_64.2 = zext i32 %iadd3_n1.6 to i64
  %imad_rhs_64.2 = zext i32 %imad_rhs.3 to i64
  %imad_tmp_64.2 = mul nuw i64 %imad_lhs_64.2, %imad_rhs_64.2
  %imad_tmp_hi.1 = lshr i64 %imad_tmp_64.2, 32
  %imad_tmp_hi_trunc.1 = trunc nuw i64 %imad_tmp_hi.1 to i32
  br label %BB_0700

BB_0700:                                          ; preds = %BB_800006f0, %BB_0650
  %phi.17 = phi i32 [ %imad_tmp_hi_trunc.1, %BB_800006f0 ], [ 0, %BB_0650 ]
  %iadd3_n1.9 = add i32 %imad.11, %sel.6
  %21 = shl i32 %shf_result.8, 7
  %22 = shl i32 %.306, 4
  %.326 = add i32 %21, %22
  br i1 %isetrp_cmp1.8.not, label %BB_0750, label %BB_80000730

BB_80000730:                                      ; preds = %BB_0700
  %.329 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.4 = load i32, ptr %.329, align 4
  %imad_lhs_64.3 = zext i32 %iadd3_n1.7 to i64
  %imad_rhs_64.3 = zext i32 %imad_rhs.4 to i64
  %imad_tmp_64.3 = mul nuw i64 %imad_lhs_64.3, %imad_rhs_64.3
  %imad_tmp_hi.2 = lshr i64 %imad_tmp_64.3, 32
  %imad_tmp_hi_trunc.2 = trunc nuw i64 %imad_tmp_hi.2 to i32
  %.331 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %shf_shift.1 = load i32, ptr %.331, align 4
  %.334 = zext i32 %phi.17 to i64
  %.335 = shl nuw i64 %.334, 32
  %shf_shift_64.12 = zext nneg i32 %shf_shift.1 to i64
  %.336 = lshr i64 %.335, %shf_shift_64.12
  %shf_hi.6 = lshr i64 %.336, 32
  %shf_result.12 = trunc nuw i64 %shf_hi.6 to i32
  br label %BB_0750

BB_0750:                                          ; preds = %BB_80000730, %BB_0700
  %phi.18 = phi i32 [ %imad_tmp_hi_trunc.2, %BB_80000730 ], [ 0, %BB_0700 ]
  %phi.19 = phi i32 [ %shf_result.12, %BB_80000730 ], [ %phi.17, %BB_0700 ]
  %isetrp_cmp1.12.not = icmp slt i32 %iadd3_n1.9, %imad_tmp.6
  br i1 %isetrp_cmp1.8.not, label %BB_07b0, label %BB_80000760

BB_80000760:                                      ; preds = %BB_0750
  %.340 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.5 = load i32, ptr %.340, align 4
  %imad_lhs_64.4 = zext i32 %iadd3_n1.8 to i64
  %imad_rhs_64.4 = zext i32 %imad_rhs.5 to i64
  %imad_tmp_64.4 = mul nuw i64 %imad_lhs_64.4, %imad_rhs_64.4
  %imad_tmp_hi.3 = and i64 %imad_tmp_64.4, -4294967296
  %.342 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %shf_shift.2 = load i32, ptr %.342, align 4
  %.345 = zext i32 %phi.18 to i64
  %.346 = shl nuw i64 %.345, 32
  %shf_shift_64.13 = zext i32 %shf_shift.2 to i64
  %.347 = lshr i64 %.346, %shf_shift_64.13
  %shf_hi.7 = lshr i64 %.347, 32
  %shf_result.13 = trunc nuw i64 %shf_hi.7 to i32
  %iadd3_o1_neg.2 = sub i32 0, %phi.19
  %.353 = lshr i64 %imad_tmp_hi.3, %shf_shift_64.13
  %shf_hi.8 = lshr i64 %.353, 32
  %shf_result.14 = trunc nuw i64 %shf_hi.8 to i32
  %imad_addend_neg.1 = sub i32 0, %shf_result.13
  br label %BB_07b0

BB_07b0:                                          ; preds = %BB_80000760, %BB_0750
  %spec.select = phi i32 [ %shf_result.14, %BB_80000760 ], [ %iadd3_n1.8, %BB_0750 ]
  %phi.30 = phi i32 [ %shf_result.13, %BB_80000760 ], [ %iadd3_n1.7, %BB_0750 ]
  %phi.20 = phi i32 [ %shf_result.13, %BB_80000760 ], [ %phi.18, %BB_0750 ]
  %phi.21 = phi i32 [ %imad_addend_neg.1, %BB_80000760 ], [ %shf_result.8, %BB_0750 ]
  %phi.22 = phi i32 [ %iadd3_o1_neg.2, %BB_80000760 ], [ 0, %BB_0750 ]
  %phi.23 = phi i32 [ %shf_result.14, %BB_80000760 ], [ 0, %BB_0750 ]
  %.355 = getelementptr inbounds nuw i8, ptr %param_local, i64 964
  %isetrp_rhs.4 = load i32, ptr %.355, align 4
  %isetrp_cmp1.13 = icmp slt i32 %iadd3_n1.6, %isetrp_rhs.4
  %isetrp_cmp2.13 = and i1 %isetrp_cmp1.13, %isetrp_cmp1.12.not
  br i1 %isetrp_cmp1.8.not, label %BB_07f0, label %BB_800007c0

BB_800007c0:                                      ; preds = %BB_07b0
  %imad_rhs.6 = load i32, ptr %.187, align 4
  %imad_tmp.14 = mul i32 %phi.22, %imad_rhs.6
  %imad.15 = add i32 %imad_tmp.14, %iadd3_n1.6
  %iadd3_o1_neg.3 = sub i32 0, %phi.23
  %imad_tmp.15 = mul i32 %phi.21, %imad_rhs.6
  %imad.16 = add i32 %imad_tmp.15, %iadd3_n1.7
  br label %BB_07f0

BB_07f0:                                          ; preds = %BB_800007c0, %BB_07b0
  %phi.27 = phi i32 [ %phi.19, %BB_800007c0 ], [ %iadd3_n1.6, %BB_07b0 ]
  %phi.24 = phi i32 [ %imad.15, %BB_800007c0 ], [ 0, %BB_07b0 ]
  %phi.25 = phi i32 [ %imad.16, %BB_800007c0 ], [ 0, %BB_07b0 ]
  %phi.26 = phi i32 [ %iadd3_o1_neg.3, %BB_800007c0 ], [ %phi.13, %BB_07b0 ]
  %isetrp_rhs.5 = load i32, ptr %.355, align 4
  %isetrp_cmp1.14 = icmp slt i32 %iadd3_n1.8, %isetrp_rhs.5
  %isetrp_cmp2.14 = and i1 %isetrp_cmp1.14, %isetrp_cmp1.12.not
  %isetrp_cmp1.15 = icmp slt i32 %iadd3_n1.3, %isetrp_rhs.5
  %isetrp_cmp2.15 = and i1 %isetrp_cmp1.15, %isetrp_cmp1.12.not
  br i1 %isetrp_cmp1.9.not, label %BB_0830, label %BB_80000820

BB_80000820:                                      ; preds = %BB_07f0
  %.373 = getelementptr inbounds nuw i8, ptr %param_local, i64 992
  %imad_rhs.8 = load i32, ptr %.373, align 4
  %imad_lhs_64.5 = zext i32 %phi.25 to i64
  %imad_rhs_64.5 = zext i32 %imad_rhs.8 to i64
  %imad_tmp_64.5 = mul nuw i64 %imad_lhs_64.5, %imad_rhs_64.5
  %imad_tmp_hi.4 = lshr i64 %imad_tmp_64.5, 32
  %imad_tmp_hi_trunc.4 = trunc nuw i64 %imad_tmp_hi.4 to i32
  br label %BB_0830

BB_0830:                                          ; preds = %BB_80000820, %BB_07f0
  %phi.28 = phi i32 [ %imad_tmp_hi_trunc.4, %BB_80000820 ], [ %phi.19, %BB_07f0 ]
  %isetrp_rhs.7 = load i32, ptr %.355, align 4
  %isetrp_cmp1.16 = icmp slt i32 %iadd3_n1.7, %isetrp_rhs.7
  %isetrp_cmp2.16 = and i1 %isetrp_cmp1.16, %isetrp_cmp1.12.not
  %imad_rhs.9 = load i32, ptr %.187, align 4
  %imad_tmp.16 = mul i32 %phi.26, %imad_rhs.9
  %imad.17 = add i32 %imad_tmp.16, %iadd3_n1.8
  %phi.29 = select i1 %isetrp_cmp1.8.not, i32 0, i32 %imad.17
  br i1 %isetrp_cmp1.9.not, label %BB_0870, label %BB_80000860

BB_80000860:                                      ; preds = %BB_0830
  %.384 = getelementptr inbounds nuw i8, ptr %param_local, i64 996
  %shf_shift.4 = load i32, ptr %.384, align 4
  %.387 = zext i32 %phi.28 to i64
  %.388 = shl nuw i64 %.387, 32
  %shf_shift_64.15 = zext nneg i32 %shf_shift.4 to i64
  %.389 = lshr i64 %.388, %shf_shift_64.15
  %shf_hi.9 = lshr i64 %.389, 32
  %shf_result.15 = trunc nuw i64 %shf_hi.9 to i32
  br label %BB_0870

BB_0870:                                          ; preds = %BB_80000860, %BB_0830
  %spec.select77 = phi i32 [ %shf_result.15, %BB_80000860 ], [ %phi.25, %BB_0830 ]
  %phi.31 = phi i32 [ %shf_result.15, %BB_80000860 ], [ %phi.28, %BB_0830 ]
  br i1 %isetrp_cmp1.9.not, label %BB_0940, label %BB_80000880

BB_80000880:                                      ; preds = %BB_0870
  %.394 = getelementptr inbounds nuw i8, ptr %param_local, i64 992
  %imad_rhs.10 = load i32, ptr %.394, align 4
  %imad_lhs_64.6 = zext i32 %phi.24 to i64
  %imad_rhs_64.6 = zext i32 %imad_rhs.10 to i64
  %imad_tmp_64.6 = mul nuw i64 %imad_lhs_64.6, %imad_rhs_64.6
  %imad_tmp_hi.5 = and i64 %imad_tmp_64.6, -4294967296
  %imad_lhs_64.7 = zext i32 %phi.16 to i64
  %imad_tmp_64.7 = mul nuw i64 %imad_lhs_64.7, %imad_rhs_64.6
  %imad_tmp_hi.6 = and i64 %imad_tmp_64.7, -4294967296
  %.398 = getelementptr inbounds nuw i8, ptr %param_local, i64 996
  %shf_shift.5 = load i32, ptr %.398, align 4
  %shf_shift_64.16 = zext i32 %shf_shift.5 to i64
  %.403 = lshr i64 %imad_tmp_hi.5, %shf_shift_64.16
  %shf_hi.10 = lshr i64 %.403, 32
  %shf_result.16 = trunc nuw i64 %shf_hi.10 to i32
  %imad_addend_neg.2 = sub i32 0, %phi.31
  %.409 = lshr i64 %imad_tmp_hi.6, %shf_shift_64.16
  %shf_hi.11 = lshr i64 %.409, 32
  %shf_result.17 = trunc nuw i64 %shf_hi.11 to i32
  %imad_lhs_64.8 = zext i32 %phi.29 to i64
  %imad_tmp_64.8 = mul nuw i64 %imad_lhs_64.8, %imad_rhs_64.6
  %imad_tmp_hi.7 = and i64 %imad_tmp_64.8, -4294967296
  %iadd3_o1_neg.4 = sub i32 0, %shf_result.16
  %imad_rhs.13 = load i32, ptr %.193, align 4
  %imad_tmp.18 = mul i32 %imad_rhs.13, %imad_addend_neg.2
  %imad.19 = add i32 %imad_tmp.18, %phi.25
  %.419 = lshr i64 %imad_tmp_hi.7, %shf_shift_64.16
  %shf_hi.12 = lshr i64 %.419, 32
  %shf_result.18 = trunc nuw i64 %shf_hi.12 to i32
  %imad_addend_neg.3 = sub i32 0, %shf_result.17
  %imad_tmp.20 = mul i32 %imad_rhs.13, %iadd3_o1_neg.4
  %imad.21 = add i32 %imad_tmp.20, %phi.24
  %iadd3_o1_neg.5 = sub i32 0, %shf_result.18
  br label %BB_0940

BB_0940:                                          ; preds = %BB_80000880, %BB_0870
  %spec.select76 = phi i32 [ %shf_result.16, %BB_80000880 ], [ %phi.24, %BB_0870 ]
  %spec.select75 = phi i32 [ %shf_result.18, %BB_80000880 ], [ %phi.29, %BB_0870 ]
  %spec.select74 = phi i32 [ %shf_result.17, %BB_80000880 ], [ %phi.16, %BB_0870 ]
  %phi.33 = phi i32 [ %imad_addend_neg.3, %BB_80000880 ], [ %phi.20, %BB_0870 ]
  %phi.34 = phi i32 [ %imad_addend_neg.2, %BB_80000880 ], [ %phi.21, %BB_0870 ]
  %phi.35 = phi i32 [ %imad.21, %BB_80000880 ], [ 0, %BB_0870 ]
  %phi.36 = phi i32 [ %imad.19, %BB_80000880 ], [ 0, %BB_0870 ]
  %phi.37 = phi i32 [ %iadd3_o1_neg.5, %BB_80000880 ], [ %phi.26, %BB_0870 ]
  %phi.38 = phi i32 [ %iadd3_o1_neg.4, %BB_80000880 ], [ %iadd3_n1.3, %BB_0870 ]
  %phi.39 = phi i32 [ %shf_result.17, %BB_80000880 ], [ %phi.22, %BB_0870 ]
  %phi.41 = phi i32 [ %shf_result.16, %BB_80000880 ], [ %phi.23, %BB_0870 ]
  br i1 %isetrp_cmp1.10.not, label %BB_0950, label %BB_80000940

BB_80000940:                                      ; preds = %BB_0940
  %.424 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.15 = load i32, ptr %.424, align 4
  %imad_lhs_64.9 = zext i32 %phi.36 to i64
  %imad_rhs_64.9 = zext i32 %imad_rhs.15 to i64
  %imad_tmp_64.9 = mul nuw i64 %imad_lhs_64.9, %imad_rhs_64.9
  %imad_tmp_hi.8 = lshr i64 %imad_tmp_64.9, 32
  %imad_tmp_hi_trunc.8 = trunc nuw i64 %imad_tmp_hi.8 to i32
  br label %BB_0950

BB_0950:                                          ; preds = %BB_80000940, %BB_0940
  %phi.42 = phi i32 [ %imad_tmp_hi_trunc.8, %BB_80000940 ], [ %phi.38, %BB_0940 ]
  %imad_rhs.16 = load i32, ptr %.193, align 4
  %imad_tmp.21 = mul i32 %phi.33, %imad_rhs.16
  %imad.22 = add i32 %imad_tmp.21, %phi.16
  %phi.43 = select i1 %isetrp_cmp1.9.not, i32 0, i32 %imad.22
  br i1 %isetrp_cmp1.10.not, label %BB_0970, label %BB_80000960

BB_80000960:                                      ; preds = %BB_0950
  %.432 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.8 = load i32, ptr %.432, align 4
  %.435 = zext i32 %phi.42 to i64
  %.436 = shl nuw i64 %.435, 32
  %shf_shift_64.19 = zext nneg i32 %shf_shift.8 to i64
  %.437 = lshr i64 %.436, %shf_shift_64.19
  %shf_hi.13 = lshr i64 %.437, 32
  %shf_result.19 = trunc nuw i64 %shf_hi.13 to i32
  br label %BB_0970

BB_0970:                                          ; preds = %BB_80000960, %BB_0950
  %phi.44 = phi i32 [ %shf_result.19, %BB_80000960 ], [ %phi.42, %BB_0950 ]
  br i1 %isetrp_cmp1.10.not, label %BB_0990, label %BB_80000980

BB_80000980:                                      ; preds = %BB_0970
  %.442 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.17 = load i32, ptr %.442, align 4
  %imad_lhs_64.10 = zext i32 %phi.43 to i64
  %imad_rhs_64.10 = zext i32 %imad_rhs.17 to i64
  %imad_tmp_64.10 = mul nuw i64 %imad_lhs_64.10, %imad_rhs_64.10
  %imad_tmp_hi.9 = lshr i64 %imad_tmp_64.10, 32
  %imad_tmp_hi_trunc.9 = trunc nuw i64 %imad_tmp_hi.9 to i32
  br label %BB_0990

BB_0990:                                          ; preds = %BB_80000980, %BB_0970
  %phi.46 = phi i32 [ %imad_tmp_hi_trunc.9, %BB_80000980 ], [ %phi.39, %BB_0970 ]
  %imad_rhs.18 = load i32, ptr %.193, align 4
  %imad_tmp.22 = mul i32 %phi.37, %imad_rhs.18
  %imad.23 = add i32 %imad_tmp.22, %phi.29
  %phi.47 = select i1 %isetrp_cmp1.9.not, i32 0, i32 %imad.23
  br i1 %isetrp_cmp1.10.not, label %BB_09c0, label %BB_800009a0

BB_800009a0:                                      ; preds = %BB_0990
  %.450 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.9 = load i32, ptr %.450, align 4
  %.453 = zext i32 %phi.46 to i64
  %.454 = shl nuw i64 %.453, 32
  %shf_shift_64.20 = zext nneg i32 %shf_shift.9 to i64
  %.455 = lshr i64 %.454, %shf_shift_64.20
  %shf_hi.14 = lshr i64 %.455, 32
  %shf_result.20 = trunc nuw i64 %shf_hi.14 to i32
  %.456 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.19 = load i32, ptr %.456, align 4
  %imad_lhs_64.11 = zext i32 %phi.35 to i64
  %imad_rhs_64.11 = zext i32 %imad_rhs.19 to i64
  %imad_tmp_64.11 = mul nuw i64 %imad_lhs_64.11, %imad_rhs_64.11
  %imad_tmp_hi.10 = lshr i64 %imad_tmp_64.11, 32
  %imad_tmp_hi_trunc.10 = trunc nuw i64 %imad_tmp_hi.10 to i32
  br label %BB_09c0

BB_09c0:                                          ; preds = %BB_800009a0, %BB_0990
  %phi.48 = phi i32 [ %imad_tmp_hi_trunc.10, %BB_800009a0 ], [ %phi.37, %BB_0990 ]
  %phi.49 = phi i32 [ %shf_result.20, %BB_800009a0 ], [ %phi.46, %BB_0990 ]
  br i1 %isetrp_cmp1.10.not, label %BB_09f0, label %BB_800009d0

BB_800009d0:                                      ; preds = %BB_09c0
  %imad_addend_neg.4 = sub i32 0, %phi.44
  %.462 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.10 = load i32, ptr %.462, align 4
  %.465 = zext i32 %phi.48 to i64
  %.466 = shl nuw i64 %.465, 32
  %shf_shift_64.21 = zext nneg i32 %shf_shift.10 to i64
  %.467 = lshr i64 %.466, %shf_shift_64.21
  %shf_hi.15 = lshr i64 %.467, 32
  %shf_result.21 = trunc nuw i64 %shf_hi.15 to i32
  br label %BB_09f0

BB_09f0:                                          ; preds = %BB_800009d0, %BB_09c0
  %phi.51 = phi i32 [ %imad_addend_neg.4, %BB_800009d0 ], [ %phi.34, %BB_09c0 ]
  %phi.52 = phi i32 [ %shf_result.21, %BB_800009d0 ], [ %phi.48, %BB_09c0 ]
  br i1 %isetrp_cmp1.10.not, label %BB_0a60, label %BB_80000a00

BB_80000a00:                                      ; preds = %BB_09f0
  %imad_rhs.20 = load i32, ptr %.197, align 4
  %imad_tmp.24 = mul i32 %phi.51, %imad_rhs.20
  %imad.25 = add i32 %imad_tmp.24, %phi.36
  %iadd3_o1_neg.6 = sub i32 0, %phi.52
  %.474 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.21 = load i32, ptr %.474, align 4
  %imad_lhs_64.12 = zext i32 %phi.47 to i64
  %imad_rhs_64.12 = zext i32 %imad_rhs.21 to i64
  %imad_tmp_64.12 = mul nuw i64 %imad_lhs_64.12, %imad_rhs_64.12
  %imad_tmp_hi.11 = and i64 %imad_tmp_64.12, -4294967296
  %imad_addend_neg.5 = sub i32 0, %phi.49
  %.476 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.11 = load i32, ptr %.476, align 4
  %shf_shift_64.22 = zext nneg i32 %shf_shift.11 to i64
  %.481 = lshr i64 %imad_tmp_hi.11, %shf_shift_64.22
  %shf_hi.16 = lshr i64 %.481, 32
  %shf_result.22 = trunc nuw i64 %shf_hi.16 to i32
  br label %BB_0a60

BB_0a60:                                          ; preds = %BB_80000a00, %BB_09f0
  %phi.54 = phi i32 [ %iadd3_o1_neg.6, %BB_80000a00 ], [ %phi.33, %BB_09f0 ]
  %phi.55 = phi i32 [ %shf_result.22, %BB_80000a00 ], [ %phi.51, %BB_09f0 ]
  %phi.56 = phi i32 [ %imad.25, %BB_80000a00 ], [ 0, %BB_09f0 ]
  %phi.57 = phi i32 [ %phi.44, %BB_80000a00 ], [ %phi.36, %BB_09f0 ]
  %phi.58 = phi i32 [ %imad_addend_neg.5, %BB_80000a00 ], [ %phi.41, %BB_09f0 ]
  %imad_rhs.22 = load i32, ptr %.197, align 4
  %imad_tmp.26 = mul i32 %phi.58, %imad_rhs.22
  %imad.27 = add i32 %imad_tmp.26, %phi.43
  %phi.60 = select i1 %isetrp_cmp1.10.not, i32 0, i32 %imad.27
  %.489 = getelementptr inbounds nuw i8, ptr %param_local, i64 604
  %imad_addend.2 = load i32, ptr %.489, align 4
  %imad_tmp.27 = mul i32 %spec.select74, %imad_addend
  %imad.28 = sub i32 %imad_tmp.27, %imad_addend.2
  %imad_tmp.28 = mul i32 %spec.select76, %imad_addend
  %imad.29 = sub i32 %imad_tmp.28, %imad_addend.2
  %imad_tmp.29 = mul i32 %spec.select77, %imad_addend
  %imad.30 = sub i32 %imad_tmp.29, %imad_addend.2
  %.495 = getelementptr inbounds nuw i8, ptr %param_local, i64 932
  %imad_rhs.23 = load i32, ptr %.495, align 4
  %imad_tmp.30 = mul i32 %ctaid_z, %imad_rhs.23
  %imad_tmp.31 = mul i32 %spec.select75, %imad_addend
  %imad.32 = sub i32 %imad_tmp.31, %imad_addend.2
  br i1 %isetrp_cmp1.10.not, label %BB_0b10, label %BB_80000ad0

BB_80000ad0:                                      ; preds = %BB_0a60
  %imad_rhs.24 = load i32, ptr %.197, align 4
  %imad_tmp.32 = mul i32 %phi.54, %imad_rhs.24
  %imad.33 = add i32 %imad_tmp.32, %phi.35
  %imad_addend_neg.10 = sub i32 0, %phi.55
  br label %BB_0b10

BB_0b10:                                          ; preds = %BB_80000ad0, %BB_0a60
  %phi.66 = phi i32 [ %phi.55, %BB_80000ad0 ], [ %phi.47, %BB_0a60 ]
  %phi.61 = phi i32 [ %imad_addend_neg.10, %BB_80000ad0 ], [ %phi.54, %BB_0a60 ]
  %phi.62 = phi i32 [ %phi.49, %BB_80000ad0 ], [ %phi.43, %BB_0a60 ]
  %phi.63 = phi i32 [ %phi.52, %BB_80000ad0 ], [ %phi.35, %BB_0a60 ]
  %phi.64 = phi i32 [ %imad.33, %BB_80000ad0 ], [ 0, %BB_0a60 ]
  %.504 = getelementptr inbounds nuw i8, ptr %param_local, i64 640
  %imad_rhs.25 = load i32, ptr %.504, align 4
  %imad_tmp.34 = mul i32 %imad_tmp.30, %imad_rhs.25
  %imad.35 = add i32 %imad_tmp.34, %imad.28
  %imad.36 = add i32 %imad_tmp.34, %imad.29
  %imad.37 = add i32 %imad_tmp.34, %imad.30
  %imad.38 = add i32 %imad_tmp.34, %imad.32
  %.510 = getelementptr inbounds nuw i8, ptr %param_local, i64 412
  %isetrp_rhs.8 = load i32, ptr %.510, align 4
  %isetrp_cmp1.17.not = icmp ult i32 %imad.35, %isetrp_rhs.8
  %.514 = getelementptr inbounds nuw i8, ptr %param_local, i64 560
  %imad_rhs.29 = load i32, ptr %.514, align 4
  %imad_tmp.38 = mul i32 %phi.14, %imad_rhs.29
  %.516 = getelementptr inbounds nuw i8, ptr %param_local, i64 936
  %imad_rhs.30 = load i32, ptr %.516, align 4
  %imad_tmp.39 = mul i32 %ctaid_z, %imad_rhs.30
  %.518 = getelementptr inbounds nuw i8, ptr %param_local, i64 612
  %imad_addend.6 = load i32, ptr %.518, align 4
  %imad_tmp.40 = mul i32 %phi.62, %mov
  %imad.41 = sub i32 %imad_tmp.40, %imad_addend.6
  %imad_rhs.31 = load i32, ptr %.197, align 4
  %imad_tmp.41 = mul i32 %phi.61, %imad_rhs.31
  %imad.42 = add i32 %imad_tmp.41, %phi.47
  %phi.65 = select i1 %isetrp_cmp1.10.not, i32 0, i32 %imad.42
  %imad_addend.7 = load i32, ptr %.518, align 4
  %imad_tmp.42 = mul i32 %phi.63, %mov
  %imad.43 = sub i32 %imad_tmp.42, %imad_addend.7
  %imad_rhs.32 = load i32, ptr %.514, align 4
  %imad_tmp.43 = mul i32 %phi.27, %imad_rhs.32
  %.529 = getelementptr inbounds nuw i8, ptr %param_local, i64 644
  %imad_rhs.33 = load i32, ptr %.529, align 4
  %imad_tmp.44 = mul i32 %imad_tmp.39, %imad_rhs.33
  %imad.45 = add i32 %imad_tmp.44, %imad.41
  %imad.47 = add i32 %imad_tmp.44, %imad.43
  %.531 = getelementptr inbounds nuw i8, ptr %param_local, i64 1568
  %lop3_b.1 = load i32, ptr %.531, align 4
  %.534 = xor i32 %lop3_b.1, -1
  %sel.7 = select i1 %isetrp_cmp1.17.not, i32 -1, i32 %.534
  %sel.8 = select i1 %isetrp_cmp2.15, i32 %sel.7, i32 0
  %.547 = getelementptr inbounds nuw i8, ptr %param_local, i64 564
  %imad_rhs.34 = load i32, ptr %.547, align 4
  %imad_tmp.45 = mul i32 %imad.35, %imad_rhs.34
  %imad.46 = add i32 %imad_tmp.45, %imad_tmp.38
  %imad_tmp.47 = mul i32 %imad.36, %imad_rhs.34
  %imad.48 = add i32 %imad_tmp.47, %imad_tmp.43
  %.551 = getelementptr inbounds nuw i8, ptr %param_local, i64 416
  %isetrp_rhs.9 = load i32, ptr %.551, align 4
  %isetrp_cmp1.18.not = icmp ult i32 %imad.45, %isetrp_rhs.9
  %isetrp_cmp1.19.not = icmp ult i32 %imad.47, %isetrp_rhs.9
  %imad_addend.8 = load i32, ptr %.518, align 4
  %imad_tmp.48 = mul i32 %phi.57, %mov
  %imad.49 = sub i32 %imad_tmp.48, %imad_addend.8
  %isetrp_rhs.11 = load i32, ptr %.510, align 4
  %isetrp_cmp1.20.not = icmp ult i32 %imad.38, %isetrp_rhs.11
  %sel.9 = select i1 %isetrp_cmp1.20.not, i32 -1, i32 %.534
  %sel.16 = select i1 %isetrp_cmp2.14, i32 %sel.9, i32 0
  %imad_rhs.37 = load i32, ptr %.514, align 4
  %imad_tmp.49 = mul i32 %phi.30, %imad_rhs.37
  %imad_tmp.58 = mul i32 %spec.select, %imad_rhs.37
  %.566 = getelementptr inbounds nuw i8, ptr %param_local, i64 568
  %imad_rhs.38 = load i32, ptr %.566, align 4
  %imad_tmp.50 = mul i32 %imad.45, %imad_rhs.38
  %imad.51 = add i32 %imad_tmp.50, %imad.46
  %imad_tmp.51 = mul i32 %imad.47, %imad_rhs.38
  %imad.52 = add i32 %imad_tmp.51, %imad.48
  %imad_rhs.40 = load i32, ptr %.529, align 4
  %imad_tmp.52 = mul i32 %imad_tmp.39, %imad_rhs.40
  %imad.53 = add i32 %imad_tmp.52, %imad.49
  %imad_tmp.53 = mul i32 %imad.37, %imad_rhs.34
  %imad.54 = add i32 %imad_tmp.53, %imad_tmp.49
  %.574 = getelementptr inbounds nuw i8, ptr %param_local, i64 620
  %imad_addend.9 = load i32, ptr %.574, align 4
  %imad_tmp.54 = mul i32 %phi.60, %mov.1
  %imad.55 = sub i32 %imad_tmp.54, %imad_addend.9
  %isetrp_cmp1.21.not = icmp ult i32 %imad.53, %isetrp_rhs.9
  %imad_tmp.55 = mul i32 %imad.53, %imad_rhs.38
  %imad.56 = add i32 %imad_tmp.55, %imad.54
  %imad_tmp.56 = mul i32 %phi.66, %mov
  %imad.57 = sub i32 %imad_tmp.56, %imad_addend.8
  %imad.61 = add i32 %imad_tmp.52, %imad.57
  %imad_tmp.63 = mul i32 %imad.61, %imad_rhs.38
  %isetrp_cmp1.27.not = icmp ult i32 %imad.61, %isetrp_rhs.9
  %isetrp_cmp1.22.not = icmp ult i32 %imad.36, %isetrp_rhs.11
  %sel.10 = select i1 %isetrp_cmp1.22.not, i32 -1, i32 %.534
  %sel.13 = select i1 %isetrp_cmp2.13, i32 %sel.10, i32 0
  %imad_tmp.57 = mul i32 %phi.64, %mov.1
  %imad.58 = sub i32 %imad_tmp.57, %imad_addend.9
  %.586 = getelementptr inbounds nuw i8, ptr %param_local, i64 1572
  %lop3_b.2 = load i32, ptr %.586, align 4
  %.589 = xor i32 %lop3_b.2, -1
  %sel.11 = select i1 %isetrp_cmp1.18.not, i32 -1, i32 %.589
  %sel.18 = select i1 %isetrp_cmp1.19.not, i32 -1, i32 %.589
  %sel.20 = select i1 %isetrp_cmp1.21.not, i32 -1, i32 %.589
  %sel.22 = select i1 %isetrp_cmp1.27.not, i32 -1, i32 %.589
  %imad_tmp.59 = mul i32 %phi.56, %mov.1
  %imad.60 = sub i32 %imad_tmp.59, %imad_addend.9
  %.606 = getelementptr inbounds nuw i8, ptr %param_local, i64 420
  %isetrp_rhs.14 = load i32, ptr %.606, align 4
  %isetrp_cmp1.23.not = icmp ult i32 %imad.55, %isetrp_rhs.14
  %sel.12 = select i1 %isetrp_cmp1.23.not, i32 -1, i32 %.229
  %.631 = and i32 %sel.12, %sel.8
  %.632 = and i32 %.631, %sel.11
  %imad_tmp.61 = mul i32 %phi.65, %mov.1
  %imad.62 = sub i32 %imad_tmp.61, %imad_addend.9
  %imad_tmp.62 = mul i32 %imad.38, %imad_rhs.34
  %imad.63 = add i32 %imad_tmp.62, %imad_tmp.58
  %imad.64 = add i32 %imad_tmp.63, %imad.63
  %isetrp_cmp1.24.not = icmp ult i32 %imad.37, %isetrp_rhs.11
  %sel.14 = select i1 %isetrp_cmp1.24.not, i32 -1, i32 %.534
  %sel.15 = select i1 %isetrp_cmp2.16, i32 %sel.14, i32 0
  %isetrp_cmp1.25.not = icmp ult i32 %imad.58, %isetrp_rhs.14
  %sel.17 = select i1 %isetrp_cmp1.25.not, i32 -1, i32 %.229
  %.636 = and i32 %sel.17, %sel.13
  %.637 = and i32 %.636, %sel.18
  %.620 = getelementptr inbounds nuw i8, ptr %param_local, i64 572
  %imad_rhs.47 = load i32, ptr %.620, align 4
  %imad_tmp.64 = mul i32 %imad.62, %imad_rhs.47
  %imad.65 = add i32 %imad_tmp.64, %imad.64
  %isetrp_cmp1.26.not = icmp ult i32 %imad.60, %isetrp_rhs.14
  %sel.19 = select i1 %isetrp_cmp1.26.not, i32 -1, i32 %.229
  %.678 = and i32 %sel.19, %sel.15
  %.679 = and i32 %.678, %sel.20
  %isetrp_cmp1.28.not = icmp ult i32 %imad.62, %isetrp_rhs.14
  %sel.21 = select i1 %isetrp_cmp1.28.not, i32 -1, i32 %.229
  %.643 = and i32 %sel.21, %sel.16
  %.644 = and i32 %.643, %sel.22
  %imad_tmp.65 = mul i32 %imad.58, %imad_rhs.47
  %imad.66 = add i32 %imad_tmp.65, %imad.52
  %imad_tmp.66 = mul i32 %imad.60, %imad_rhs.47
  %imad.67 = add i32 %imad_tmp.66, %imad.56
  %imad_tmp.69 = mul i32 %imad.55, %imad_rhs.47
  %imad.70 = add i32 %imad_tmp.69, %imad.51
  %.655 = getelementptr inbounds nuw i8, ptr %param_local, i64 576
  %imad_rhs.50 = load i32, ptr %.655, align 4
  %imad_tmp.67 = mul i32 %iadd3_n1.9, %imad_rhs.50
  %imad.68 = add i32 %imad_tmp.67, %imad.66
  %imad.69 = add i32 %imad_tmp.67, %imad.67
  %imad.71 = add i32 %imad_tmp.67, %imad.70
  %imad.72 = add i32 %imad_tmp.67, %imad.65
  %.660 = and i32 %.632, 1
  %.697 = and i32 %.225, 536870904
  %iadd3_n1.15 = sub i32 %tid_x, %.697
  %.670 = shl i32 %.644, 1
  %p2r_p1_shl = and i32 %.670, 2
  %p2r_or_1 = or disjoint i32 %.660, %p2r_p1_shl
  %.650 = shl i32 %.637, 2
  %p2r_p2_shl = and i32 %.650, 4
  %p2r_or_2 = or disjoint i32 %p2r_or_1, %p2r_p2_shl
  %.685 = shl i32 %.679, 3
  %p2r_p3_shl = and i32 %.685, 8
  %p2r_or_3 = or disjoint i32 %p2r_or_2, %p2r_p3_shl
  %imad_tmp.72 = shl i32 %iadd3_n1.15, 3
  %imad.73 = add i32 %imad_tmp.72, %imad_tmp.5
  %.702 = getelementptr inbounds nuw i8, ptr %param_local, i64 1592
  %iadd3_o2 = load i32, ptr %.702, align 4
  %iadd3_n1.16 = add i32 %imad.73, %iadd3_o2
  %isetrp_cmp1.32 = icmp slt i32 %imad_addend.1, 2
  br i1 %isetrp_cmp1.32, label %BB_18d0, label %BB_1140

BB_1140:                                          ; preds = %BB_0b10
  %23 = add nsw i32 %imad_addend.1, -2
  %isetrp_cmp1.34 = icmp ult i32 %23, 3
  br i1 %isetrp_cmp1.34, label %BB_1690, label %BB_1150

BB_1150:                                          ; preds = %BB_1140
  %iadd3_n1.18 = add nsw i32 %imad_addend.1, -1
  %imad_addend.14 = load i32, ptr %.531, align 4
  %imad_addend.15 = load i32, ptr %.504, align 4
  %iadd3_n1.19 = and i32 %iadd3_n1.18, -4
  br label %BB_11b0

BB_11b0:                                          ; preds = %BB_11b0, %BB_1150
  %phi.67 = phi i32 [ %.632, %BB_1150 ], [ %.871, %BB_11b0 ]
  %phi.68 = phi i32 [ %.644, %BB_1150 ], [ %.876, %BB_11b0 ]
  %phi.69 = phi i32 [ %.637, %BB_1150 ], [ %.881, %BB_11b0 ]
  %phi.70 = phi i32 [ %.679, %BB_1150 ], [ %.886, %BB_11b0 ]
  %phi.71 = phi i32 [ 1, %BB_1150 ], [ %iadd3_n1.26, %BB_11b0 ]
  %phi.72 = phi i32 [ %iadd3_n1.19, %BB_1150 ], [ %iadd3_n1.20, %BB_11b0 ]
  %iadd3_n1.26 = add i32 %phi.71, 4
  %imad_tmp.78 = mul i32 %phi.71, %imad_addend.15
  %imad_rhs.55 = load i32, ptr %.504, align 4
  %imad.79 = add i32 %imad_tmp.78, %imad_rhs.55
  %iadd3_n1.21 = add i32 %imad.79, %imad_rhs.55
  %iadd3_n1.24 = add i32 %iadd3_n1.21, %imad_rhs.55
  %imad_tmp.77 = mul i32 %phi.71, %imad_rhs.55
  %imad.95 = add i32 %imad.37, %iadd3_n1.24
  %isetrp_rhs.20 = load i32, ptr %.510, align 4
  %isetrp_cmp1.51.not = icmp ult i32 %imad.95, %isetrp_rhs.20
  %.743 = zext i32 %imad_addend.14 to i64
  %.735 = getelementptr inbounds nuw i8, ptr %param_local, i64 1564
  %imad_rhs.58 = load i32, ptr %.735, align 4
  %imad_tmp.82 = mul i32 %phi.71, %imad_rhs.58
  %iadd3_n1.22 = add i32 %imad_tmp.82, %imad_rhs.58
  %shf_shift_64.23 = zext nneg i32 %imad_tmp.82 to i64
  %.746 = shl i64 %.743, %shf_shift_64.23
  %shf_result.23 = trunc i64 %.746 to i32
  %.754 = xor i32 %shf_result.23, -1
  %iadd3_n1.23 = add i32 %iadd3_n1.22, %imad_rhs.58
  %iadd3_n1.25 = add i32 %iadd3_n1.23, %imad_rhs.58
  %shf_shift_64.26 = zext nneg i32 %iadd3_n1.25 to i64
  %.833 = shl i64 %.743, %shf_shift_64.26
  %shf_result.26 = trunc i64 %.833 to i32
  %.842 = xor i32 %shf_result.26, -1
  %sel.38 = select i1 %isetrp_cmp1.51.not, i32 -1, i32 %.842
  %shf_shift_64.25 = zext nneg i32 %iadd3_n1.23 to i64
  %.800 = shl i64 %.743, %shf_shift_64.25
  %shf_result.25 = trunc i64 %.800 to i32
  %.806 = xor i32 %shf_result.25, -1
  %shf_shift_64.24 = zext nneg i32 %iadd3_n1.22 to i64
  %.770 = shl i64 %.743, %shf_shift_64.24
  %shf_result.24 = trunc i64 %.770 to i32
  %.774 = xor i32 %shf_result.24, -1
  %imad.86 = add i32 %imad.37, %imad.79
  %isetrp_cmp1.41.not = icmp ult i32 %imad.86, %isetrp_rhs.20
  %sel.31 = select i1 %isetrp_cmp1.41.not, i32 -1, i32 %.774
  %.839 = and i32 %sel.31, %phi.70
  %imad.82 = add i32 %imad_tmp.77, %imad.37
  %isetrp_cmp1.38.not = icmp ult i32 %imad.82, %isetrp_rhs.20
  %sel.30 = select i1 %isetrp_cmp1.38.not, i32 -1, i32 %.754
  %.840 = and i32 %.839, %sel.30
  %.885 = and i32 %sel.38, %.840
  %imad.91 = add i32 %imad.37, %iadd3_n1.21
  %isetrp_cmp1.46.not = icmp ult i32 %imad.91, %isetrp_rhs.20
  %sel.37 = select i1 %isetrp_cmp1.46.not, i32 -1, i32 %.806
  %.886 = and i32 %.885, %sel.37
  %imad.90 = add i32 %imad.36, %iadd3_n1.21
  %isetrp_cmp1.45.not = icmp ult i32 %imad.90, %isetrp_rhs.20
  %sel.33 = select i1 %isetrp_cmp1.45.not, i32 -1, i32 %.806
  %imad.84 = add i32 %imad.36, %imad.79
  %isetrp_cmp1.39.not = icmp ult i32 %imad.84, %isetrp_rhs.20
  %sel.28 = select i1 %isetrp_cmp1.39.not, i32 -1, i32 %.774
  %.865 = and i32 %sel.28, %phi.69
  %imad.78 = add i32 %imad_tmp.77, %imad.36
  %isetrp_cmp1.35.not = icmp ult i32 %imad.78, %isetrp_rhs.20
  %sel.27 = select i1 %isetrp_cmp1.35.not, i32 -1, i32 %.754
  %.866 = and i32 %.865, %sel.27
  %imad.94 = add i32 %imad.36, %iadd3_n1.24
  %isetrp_cmp1.50.not = icmp ult i32 %imad.94, %isetrp_rhs.20
  %sel.36 = select i1 %isetrp_cmp1.50.not, i32 -1, i32 %.842
  %24 = and i32 %sel.36, %sel.33
  %.881 = and i32 %24, %.866
  %imad.89 = add i32 %imad.38, %iadd3_n1.21
  %isetrp_cmp1.43.not = icmp ult i32 %imad.89, %isetrp_rhs.20
  %sel.29 = select i1 %isetrp_cmp1.43.not, i32 -1, i32 %.806
  %imad.80 = add i32 %imad_tmp.77, %imad.38
  %isetrp_cmp1.36.not = icmp ult i32 %imad.80, %isetrp_rhs.20
  %sel.24 = select i1 %isetrp_cmp1.36.not, i32 -1, i32 %.754
  %imad.87 = add i32 %imad.38, %imad.79
  %isetrp_cmp1.44.not = icmp ult i32 %imad.87, %isetrp_rhs.20
  %sel.26 = select i1 %isetrp_cmp1.44.not, i32 -1, i32 %.774
  %.824 = and i32 %sel.26, %phi.68
  %imad.93 = add i32 %imad.38, %iadd3_n1.24
  %isetrp_cmp1.49.not = icmp ult i32 %imad.93, %isetrp_rhs.20
  %sel.35 = select i1 %isetrp_cmp1.49.not, i32 -1, i32 %.842
  %25 = and i32 %.824, %sel.35
  %26 = and i32 %25, %sel.29
  %.876 = and i32 %26, %sel.24
  %imad.92 = add i32 %imad.35, %iadd3_n1.24
  %isetrp_cmp1.47.not = icmp ult i32 %imad.92, %isetrp_rhs.20
  %sel.34 = select i1 %isetrp_cmp1.47.not, i32 -1, i32 %.842
  %imad.81 = add i32 %imad.35, %imad.79
  %isetrp_cmp1.37.not = icmp ult i32 %imad.81, %isetrp_rhs.20
  %sel.25 = select i1 %isetrp_cmp1.37.not, i32 -1, i32 %.774
  %.860 = and i32 %sel.25, %phi.67
  %imad.85 = add i32 %imad_tmp.77, %imad.35
  %isetrp_cmp1.40.not = icmp ult i32 %imad.85, %isetrp_rhs.20
  %sel.23 = select i1 %isetrp_cmp1.40.not, i32 -1, i32 %.754
  %.861 = and i32 %.860, %sel.23
  %.870 = and i32 %sel.34, %.861
  %imad.88 = add i32 %imad.35, %iadd3_n1.21
  %isetrp_cmp1.42.not = icmp ult i32 %imad.88, %isetrp_rhs.20
  %sel.32 = select i1 %isetrp_cmp1.42.not, i32 -1, i32 %.806
  %.871 = and i32 %.870, %sel.32
  %iadd3_n1.20 = add i32 %phi.72, -4
  %isetrp_cmp1.48.not = icmp eq i32 %iadd3_n1.20, 0
  br i1 %isetrp_cmp1.48.not, label %BB_1690.loopexit, label %BB_11b0

BB_1690.loopexit:                                 ; preds = %BB_11b0
  br label %BB_1690

BB_1690:                                          ; preds = %BB_1690.loopexit, %BB_1140
  %phi.73 = phi i32 [ %.632, %BB_1140 ], [ %.871, %BB_1690.loopexit ]
  %phi.74 = phi i32 [ %.644, %BB_1140 ], [ %.876, %BB_1690.loopexit ]
  %phi.75 = phi i32 [ %.637, %BB_1140 ], [ %.881, %BB_1690.loopexit ]
  %phi.76 = phi i32 [ %.679, %BB_1140 ], [ %.886, %BB_1690.loopexit ]
  %phi.77 = phi i32 [ 1, %BB_1140 ], [ %iadd3_n1.26, %BB_1690.loopexit ]
  %phi.78 = phi i32 [ 0, %BB_1140 ], [ %sel.24, %BB_1690.loopexit ]
  %phi.79 = phi i32 [ 0, %BB_1140 ], [ %.866, %BB_1690.loopexit ]
  %27 = and i32 %imad_addend.1, 3
  %isetrp_cmp1.52.not = icmp eq i32 %27, 1
  br i1 %isetrp_cmp1.52.not, label %BB_18d0, label %BB_16a0

BB_16a0:                                          ; preds = %BB_1690
  %imad_rhs.60 = load i32, ptr %.495, align 4
  %imad_tmp.95 = mul i32 %ctaid_z, %imad_rhs.60
  %imad.96 = add i32 %imad_tmp.95, %phi.77
  %28 = sub nsw i32 0, %imad_addend.1
  %iadd3_o1_not.8 = or i32 %28, -4
  %iadd3_o1_neg.8 = add nsw i32 %iadd3_o1_not.8, 1
  %.901 = getelementptr inbounds nuw i8, ptr %param_local, i64 1564
  %imad_rhs.61 = load i32, ptr %.901, align 4
  %imad_tmp.96 = mul i32 %phi.77, %imad_rhs.61
  %imad_rhs.62 = load i32, ptr %.504, align 4
  %imad_tmp.97 = mul i32 %imad.96, %imad_rhs.62
  %imad_rhs.63 = load i32, ptr %.207, align 4
  %imad_tmp.98 = mul i32 %spec.select77, %imad_rhs.63
  %imad.99 = add i32 %imad_tmp.98, %imad_tmp.97
  %imad_tmp.99 = mul i32 %spec.select76, %imad_rhs.63
  %imad.100 = add i32 %imad_tmp.99, %imad_tmp.97
  %imad_tmp.100 = mul i32 %spec.select75, %imad_rhs.63
  %imad.101 = add i32 %imad_tmp.100, %imad_tmp.97
  %iadd3_o2.6 = load i32, ptr %.489, align 4
  %iadd3_n1.29 = sub i32 %imad.99, %iadd3_o2.6
  %imad_tmp.101 = mul i32 %spec.select74, %imad_rhs.63
  %imad.102 = add i32 %imad_tmp.101, %imad_tmp.97
  %mov.2 = load i32, ptr %.531, align 4
  %iadd3_n1.30 = sub i32 %imad.100, %iadd3_o2.6
  %iadd3_n1.31 = sub i32 %imad.101, %iadd3_o2.6
  %iadd3_n1.32 = sub i32 %imad.102, %iadd3_o2.6
  br label %BB_1770

BB_1770:                                          ; preds = %BB_1770, %BB_16a0
  %phi.80 = phi i32 [ %iadd3_n1.32, %BB_16a0 ], [ %iadd3_n1.37, %BB_1770 ]
  %phi.81 = phi i32 [ %iadd3_n1.31, %BB_16a0 ], [ %iadd3_n1.36, %BB_1770 ]
  %phi.82 = phi i32 [ %phi.73, %BB_16a0 ], [ %.953, %BB_1770 ]
  %phi.83 = phi i32 [ %phi.74, %BB_16a0 ], [ %.961, %BB_1770 ]
  %phi.84 = phi i32 [ %phi.75, %BB_16a0 ], [ %.969, %BB_1770 ]
  %phi.85 = phi i32 [ %phi.76, %BB_16a0 ], [ %.977, %BB_1770 ]
  %phi.86 = phi i32 [ %iadd3_n1.30, %BB_16a0 ], [ %iadd3_n1.35, %BB_1770 ]
  %phi.87 = phi i32 [ %iadd3_n1.29, %BB_16a0 ], [ %iadd3_n1.34, %BB_1770 ]
  %phi.88 = phi i32 [ %imad_tmp.96, %BB_16a0 ], [ %iadd3_n1.38, %BB_1770 ]
  %phi.89 = phi i32 [ %iadd3_o1_neg.8, %BB_16a0 ], [ %iadd3_n1.33, %BB_1770 ]
  %iadd3_o2.14 = load i32, ptr %.901, align 4
  %iadd3_n1.38 = add i32 %phi.88, %iadd3_o2.14
  %iadd3_o2.10 = load i32, ptr %.504, align 4
  %iadd3_n1.37 = add i32 %phi.80, %iadd3_o2.10
  %iadd3_n1.36 = add i32 %phi.81, %iadd3_o2.10
  %iadd3_n1.35 = add i32 %phi.86, %iadd3_o2.10
  %iadd3_n1.34 = add i32 %phi.87, %iadd3_o2.10
  %isetrp_rhs.36 = load i32, ptr %.510, align 4
  %isetrp_cmp1.56.not = icmp ult i32 %phi.87, %isetrp_rhs.36
  %.924 = zext i32 %mov.2 to i64
  %shf_shift_64.27 = zext nneg i32 %phi.88 to i64
  %.927 = shl i64 %.924, %shf_shift_64.27
  %shf_result.27 = trunc i64 %.927 to i32
  %.931 = xor i32 %shf_result.27, -1
  %sel.42 = select i1 %isetrp_cmp1.56.not, i32 -1, i32 %.931
  %.977 = and i32 %phi.85, %sel.42
  %isetrp_cmp1.55.not = icmp ult i32 %phi.86, %isetrp_rhs.36
  %sel.41 = select i1 %isetrp_cmp1.55.not, i32 -1, i32 %.931
  %.969 = and i32 %phi.84, %sel.41
  %isetrp_cmp1.54.not = icmp ult i32 %phi.81, %isetrp_rhs.36
  %sel.40 = select i1 %isetrp_cmp1.54.not, i32 -1, i32 %.931
  %.961 = and i32 %phi.83, %sel.40
  %iadd3_n1.33 = add i32 %phi.89, 1
  %isetrp_cmp1.57.not = icmp eq i32 %iadd3_n1.33, 0
  %isetrp_cmp1.53.not = icmp ult i32 %phi.80, %isetrp_rhs.36
  %sel.39 = select i1 %isetrp_cmp1.53.not, i32 -1, i32 %.931
  %.953 = and i32 %phi.82, %sel.39
  br i1 %isetrp_cmp1.57.not, label %BB_18d0.loopexit, label %BB_1770

BB_18d0.loopexit:                                 ; preds = %BB_1770
  br label %BB_18d0

BB_18d0:                                          ; preds = %BB_18d0.loopexit, %BB_1690, %BB_0b10
  %phi.90 = phi i32 [ %spec.select75, %BB_0b10 ], [ %spec.select75, %BB_1690 ], [ %iadd3_n1.36, %BB_18d0.loopexit ]
  %phi.91 = phi i32 [ %.632, %BB_0b10 ], [ %phi.73, %BB_1690 ], [ %.953, %BB_18d0.loopexit ]
  %phi.92 = phi i32 [ %.644, %BB_0b10 ], [ %phi.74, %BB_1690 ], [ %.961, %BB_18d0.loopexit ]
  %phi.93 = phi i32 [ %.637, %BB_0b10 ], [ %phi.75, %BB_1690 ], [ %.969, %BB_18d0.loopexit ]
  %phi.94 = phi i32 [ %.679, %BB_0b10 ], [ %phi.76, %BB_1690 ], [ %.977, %BB_18d0.loopexit ]
  %phi.95 = phi i32 [ 0, %BB_0b10 ], [ %phi.78, %BB_1690 ], [ %phi.78, %BB_18d0.loopexit ]
  %phi.96 = phi i32 [ 0, %BB_0b10 ], [ %phi.79, %BB_1690 ], [ %phi.79, %BB_18d0.loopexit ]
  %.994 = getelementptr inbounds nuw i8, ptr %param_local, i64 464
  %ldc_const.6 = load i32, ptr %.994, align 4
  %isetrp_cmp1.58 = icmp slt i32 %ldc_const.6, 2
  br i1 %isetrp_cmp1.58, label %BB_2130, label %BB_1910

BB_1910:                                          ; preds = %BB_18d0
  %iadd3_n1.40 = add nsw i32 %ldc_const.6, -1
  %.1006 = and i32 %iadd3_n1.40, 3
  %29 = add nsw i32 %ldc_const.6, -2
  %isetrp_cmp1.59 = icmp ult i32 %29, 3
  br i1 %isetrp_cmp1.59, label %BB_1ef0, label %BB_1980

BB_1980:                                          ; preds = %BB_1910
  %imad_addend.17 = load i32, ptr %.518, align 4
  %imad.103 = sub i32 %imad_tmp.42, %imad_addend.17
  %imad.104 = sub i32 %imad_tmp.40, %imad_addend.17
  %mov.3 = load i32, ptr %.529, align 4
  %imad.105 = sub i32 %imad_tmp.56, %imad_addend.17
  %mov.4 = load i32, ptr %.586, align 4
  %imad_tmp.105 = mul i32 %imad_tmp.39, %mov.3
  %imad.106 = add i32 %imad_tmp.105, %imad.49
  %iadd3_n1.41 = and i32 %iadd3_n1.40, -4
  %imad.107 = add i32 %imad_tmp.105, %imad.103
  %imad.108 = add i32 %imad_tmp.105, %imad.104
  %imad.109 = add i32 %imad_tmp.105, %imad.105
  br label %BB_1a30

BB_1a30:                                          ; preds = %BB_1a30, %BB_1980
  %phi.97 = phi i32 [ %iadd3_n1.41, %BB_1980 ], [ %iadd3_n1.42, %BB_1a30 ]
  %phi.98 = phi i32 [ %phi.91, %BB_1980 ], [ %.1187, %BB_1a30 ]
  %phi.99 = phi i32 [ %phi.92, %BB_1980 ], [ %.1192, %BB_1a30 ]
  %phi.100 = phi i32 [ %phi.93, %BB_1980 ], [ %.1197, %BB_1a30 ]
  %phi.101 = phi i32 [ %phi.94, %BB_1980 ], [ %.1202, %BB_1a30 ]
  %phi.102 = phi i32 [ 1, %BB_1980 ], [ %iadd3_n1.48, %BB_1a30 ]
  %iadd3_n1.48 = add i32 %phi.102, 4
  %imad_tmp.111 = mul i32 %phi.102, %mov.3
  %imad_rhs.71 = load i32, ptr %.529, align 4
  %imad.112 = add i32 %imad_tmp.111, %imad_rhs.71
  %iadd3_n1.44 = add i32 %imad.112, %imad_rhs.71
  %iadd3_n1.45 = add i32 %iadd3_n1.44, %imad_rhs.71
  %imad_tmp.109 = mul i32 %phi.102, %imad_rhs.71
  %imad.127 = add i32 %imad.106, %iadd3_n1.45
  %isetrp_rhs.40 = load i32, ptr %.551, align 4
  %isetrp_cmp1.76.not = icmp ult i32 %imad.127, %isetrp_rhs.40
  %.1055 = zext i32 %mov.4 to i64
  %.1049 = getelementptr inbounds nuw i8, ptr %param_local, i64 468
  %imad_rhs.74 = load i32, ptr %.1049, align 4
  %imad_tmp.114 = mul i32 %phi.102, %imad_rhs.74
  %iadd3_n1.43 = add i32 %imad_tmp.114, %imad_rhs.74
  %shf_shift_64.28 = zext nneg i32 %imad_tmp.114 to i64
  %.1058 = shl i64 %.1055, %shf_shift_64.28
  %shf_result.28 = trunc i64 %.1058 to i32
  %.1068 = xor i32 %shf_result.28, -1
  %iadd3_n1.46 = add i32 %iadd3_n1.43, %imad_rhs.74
  %iadd3_n1.47 = add i32 %iadd3_n1.46, %imad_rhs.74
  %shf_shift_64.31 = zext nneg i32 %iadd3_n1.47 to i64
  %.1149 = shl i64 %.1055, %shf_shift_64.31
  %shf_result.31 = trunc i64 %.1149 to i32
  %.1158 = xor i32 %shf_result.31, -1
  %sel.58 = select i1 %isetrp_cmp1.76.not, i32 -1, i32 %.1158
  %shf_shift_64.30 = zext nneg i32 %iadd3_n1.46 to i64
  %.1120 = shl i64 %.1055, %shf_shift_64.30
  %shf_result.30 = trunc i64 %.1120 to i32
  %.1124 = xor i32 %shf_result.30, -1
  %shf_shift_64.29 = zext nneg i32 %iadd3_n1.43 to i64
  %.1086 = shl i64 %.1055, %shf_shift_64.29
  %shf_result.29 = trunc i64 %.1086 to i32
  %.1090 = xor i32 %shf_result.29, -1
  %imad.119 = add i32 %imad.106, %imad.112
  %isetrp_cmp1.66.not = icmp ult i32 %imad.119, %isetrp_rhs.40
  %sel.51 = select i1 %isetrp_cmp1.66.not, i32 -1, i32 %.1090
  %.1155 = and i32 %sel.51, %phi.101
  %imad.118 = add i32 %imad_tmp.109, %imad.106
  %isetrp_cmp1.69.not = icmp ult i32 %imad.118, %isetrp_rhs.40
  %sel.49 = select i1 %isetrp_cmp1.69.not, i32 -1, i32 %.1068
  %.1156 = and i32 %.1155, %sel.49
  %.1201 = and i32 %sel.58, %.1156
  %imad.123 = add i32 %imad.106, %iadd3_n1.44
  %isetrp_cmp1.72.not = icmp ult i32 %imad.123, %isetrp_rhs.40
  %sel.57 = select i1 %isetrp_cmp1.72.not, i32 -1, i32 %.1124
  %.1202 = and i32 %.1201, %sel.57
  %imad.122 = add i32 %imad.107, %iadd3_n1.44
  %isetrp_cmp1.70.not = icmp ult i32 %imad.122, %isetrp_rhs.40
  %sel.53 = select i1 %isetrp_cmp1.70.not, i32 -1, i32 %.1124
  %imad.117 = add i32 %imad.107, %imad.112
  %isetrp_cmp1.65.not = icmp ult i32 %imad.117, %isetrp_rhs.40
  %sel.47 = select i1 %isetrp_cmp1.65.not, i32 -1, i32 %.1090
  %.1181 = and i32 %sel.47, %phi.100
  %imad.110 = add i32 %imad_tmp.109, %imad.107
  %isetrp_cmp1.60.not = icmp ult i32 %imad.110, %isetrp_rhs.40
  %sel.48 = select i1 %isetrp_cmp1.60.not, i32 -1, i32 %.1068
  %.1182 = and i32 %.1181, %sel.48
  %imad.126 = add i32 %imad.107, %iadd3_n1.45
  %isetrp_cmp1.75.not = icmp ult i32 %imad.126, %isetrp_rhs.40
  %sel.56 = select i1 %isetrp_cmp1.75.not, i32 -1, i32 %.1158
  %30 = and i32 %sel.56, %sel.53
  %.1197 = and i32 %30, %.1182
  %imad.125 = add i32 %imad.109, %iadd3_n1.45
  %isetrp_cmp1.73.not = icmp ult i32 %imad.125, %isetrp_rhs.40
  %sel.55 = select i1 %isetrp_cmp1.73.not, i32 -1, i32 %.1158
  %imad.116 = add i32 %imad.109, %imad.112
  %isetrp_cmp1.64.not = icmp ult i32 %imad.116, %isetrp_rhs.40
  %sel.46 = select i1 %isetrp_cmp1.64.not, i32 -1, i32 %.1090
  %.1142 = and i32 %sel.46, %phi.99
  %imad.111 = add i32 %imad_tmp.109, %imad.109
  %isetrp_cmp1.61.not = icmp ult i32 %imad.111, %isetrp_rhs.40
  %sel.44 = select i1 %isetrp_cmp1.61.not, i32 -1, i32 %.1068
  %.1143 = and i32 %.1142, %sel.44
  %.1191 = and i32 %sel.55, %.1143
  %imad.121 = add i32 %imad.109, %iadd3_n1.44
  %isetrp_cmp1.68.not = icmp ult i32 %imad.121, %isetrp_rhs.40
  %sel.50 = select i1 %isetrp_cmp1.68.not, i32 -1, i32 %.1124
  %.1192 = and i32 %.1191, %sel.50
  %imad.124 = add i32 %imad.108, %iadd3_n1.45
  %isetrp_cmp1.71.not = icmp ult i32 %imad.124, %isetrp_rhs.40
  %sel.54 = select i1 %isetrp_cmp1.71.not, i32 -1, i32 %.1158
  %imad.114 = add i32 %imad.108, %imad.112
  %isetrp_cmp1.63.not = icmp ult i32 %imad.114, %isetrp_rhs.40
  %sel.45 = select i1 %isetrp_cmp1.63.not, i32 -1, i32 %.1090
  %.1176 = and i32 %sel.45, %phi.98
  %imad.113 = add i32 %imad_tmp.109, %imad.108
  %imad.120 = add i32 %imad.108, %iadd3_n1.44
  %isetrp_cmp1.67.not = icmp ult i32 %imad.120, %isetrp_rhs.40
  %sel.52 = select i1 %isetrp_cmp1.67.not, i32 -1, i32 %.1124
  %isetrp_cmp1.62.not = icmp ult i32 %imad.113, %isetrp_rhs.40
  %sel.43 = select i1 %isetrp_cmp1.62.not, i32 -1, i32 %.1068
  %.1177 = and i32 %.1176, %sel.43
  %.1186 = and i32 %sel.54, %.1177
  %.1187 = and i32 %.1186, %sel.52
  %iadd3_n1.42 = add i32 %phi.97, -4
  %isetrp_cmp1.74.not = icmp eq i32 %iadd3_n1.42, 0
  br i1 %isetrp_cmp1.74.not, label %BB_1ef0.loopexit, label %BB_1a30

BB_1ef0.loopexit:                                 ; preds = %BB_1a30
  br label %BB_1ef0

BB_1ef0:                                          ; preds = %BB_1ef0.loopexit, %BB_1910
  %phi.103 = phi i32 [ %phi.91, %BB_1910 ], [ %.1187, %BB_1ef0.loopexit ]
  %phi.104 = phi i32 [ %phi.92, %BB_1910 ], [ %.1192, %BB_1ef0.loopexit ]
  %phi.105 = phi i32 [ %phi.93, %BB_1910 ], [ %.1197, %BB_1ef0.loopexit ]
  %phi.106 = phi i32 [ %phi.94, %BB_1910 ], [ %.1202, %BB_1ef0.loopexit ]
  %phi.107 = phi i32 [ %phi.95, %BB_1910 ], [ %sel.48, %BB_1ef0.loopexit ]
  %phi.108 = phi i32 [ %phi.96, %BB_1910 ], [ %.1182, %BB_1ef0.loopexit ]
  %phi.109 = phi i32 [ 1, %BB_1910 ], [ %iadd3_n1.48, %BB_1ef0.loopexit ]
  %phi.110 = phi i32 [ %imad.49, %BB_1910 ], [ %imad.106, %BB_1ef0.loopexit ]
  %isetrp_cmp1.77.not = icmp eq i32 %.1006, 0
  br i1 %isetrp_cmp1.77.not, label %BB_2130, label %BB_1f00

BB_1f00:                                          ; preds = %BB_1ef0
  %imad_rhs.76 = load i32, ptr %.516, align 4
  %imad_tmp.127 = mul i32 %ctaid_z, %imad_rhs.76
  %imad.128 = add i32 %imad_tmp.127, %phi.109
  %iadd3_o2_neg.6 = sub nsw i32 0, %.1006
  %.1209 = getelementptr inbounds nuw i8, ptr %param_local, i64 468
  %imad_rhs.77 = load i32, ptr %.1209, align 4
  %imad_tmp.128 = mul i32 %phi.109, %imad_rhs.77
  %mov.5 = load i32, ptr %.586, align 4
  %imad_rhs.78 = load i32, ptr %.529, align 4
  %imad_tmp.129 = mul i32 %imad.128, %imad_rhs.78
  %imad_rhs.79 = load i32, ptr %.205, align 4
  %imad_tmp.130 = mul i32 %phi.57, %imad_rhs.79
  %imad.131 = add i32 %imad_tmp.130, %imad_tmp.129
  %imad_tmp.131 = mul i32 %phi.63, %imad_rhs.79
  %imad.132 = add i32 %imad_tmp.131, %imad_tmp.129
  %imad_tmp.132 = mul i32 %phi.66, %imad_rhs.79
  %imad.133 = add i32 %imad_tmp.132, %imad_tmp.129
  %iadd3_o2.20 = load i32, ptr %.518, align 4
  %iadd3_n1.50 = sub i32 %imad.131, %iadd3_o2.20
  %imad_tmp.133 = mul i32 %phi.62, %imad_rhs.79
  %imad.134 = add i32 %imad_tmp.133, %imad_tmp.129
  %iadd3_n1.51 = sub i32 %imad.132, %iadd3_o2.20
  %iadd3_n1.52 = sub i32 %imad.133, %iadd3_o2.20
  %iadd3_n1.53 = sub i32 %imad.134, %iadd3_o2.20
  br label %BB_1fd0

BB_1fd0:                                          ; preds = %BB_1fd0, %BB_1f00
  %phi.111 = phi i32 [ %iadd3_n1.53, %BB_1f00 ], [ %iadd3_n1.58, %BB_1fd0 ]
  %phi.112 = phi i32 [ %phi.103, %BB_1f00 ], [ %.1261, %BB_1fd0 ]
  %phi.113 = phi i32 [ %phi.104, %BB_1f00 ], [ %.1269, %BB_1fd0 ]
  %phi.114 = phi i32 [ %phi.105, %BB_1f00 ], [ %.1277, %BB_1fd0 ]
  %phi.115 = phi i32 [ %phi.106, %BB_1f00 ], [ %.1285, %BB_1fd0 ]
  %phi.116 = phi i32 [ %iadd3_n1.52, %BB_1f00 ], [ %iadd3_n1.57, %BB_1fd0 ]
  %phi.117 = phi i32 [ %iadd3_n1.51, %BB_1f00 ], [ %iadd3_n1.56, %BB_1fd0 ]
  %phi.118 = phi i32 [ %iadd3_n1.50, %BB_1f00 ], [ %iadd3_n1.55, %BB_1fd0 ]
  %phi.119 = phi i32 [ %imad_tmp.128, %BB_1f00 ], [ %iadd3_n1.59, %BB_1fd0 ]
  %phi.120 = phi i32 [ %iadd3_o2_neg.6, %BB_1f00 ], [ %iadd3_n1.54, %BB_1fd0 ]
  %iadd3_o2.28 = load i32, ptr %.1209, align 4
  %iadd3_n1.59 = add i32 %phi.119, %iadd3_o2.28
  %iadd3_o2.24 = load i32, ptr %.529, align 4
  %iadd3_n1.58 = add i32 %phi.111, %iadd3_o2.24
  %iadd3_n1.57 = add i32 %phi.116, %iadd3_o2.24
  %iadd3_n1.56 = add i32 %phi.117, %iadd3_o2.24
  %iadd3_n1.55 = add i32 %phi.118, %iadd3_o2.24
  %isetrp_rhs.56 = load i32, ptr %.551, align 4
  %isetrp_cmp1.81.not = icmp ult i32 %phi.118, %isetrp_rhs.56
  %.1232 = zext i32 %mov.5 to i64
  %shf_shift_64.32 = zext nneg i32 %phi.119 to i64
  %.1235 = shl i64 %.1232, %shf_shift_64.32
  %shf_result.32 = trunc i64 %.1235 to i32
  %.1239 = xor i32 %shf_result.32, -1
  %sel.62 = select i1 %isetrp_cmp1.81.not, i32 -1, i32 %.1239
  %.1285 = and i32 %phi.115, %sel.62
  %isetrp_cmp1.80.not = icmp ult i32 %phi.117, %isetrp_rhs.56
  %sel.61 = select i1 %isetrp_cmp1.80.not, i32 -1, i32 %.1239
  %.1277 = and i32 %phi.114, %sel.61
  %isetrp_cmp1.79.not = icmp ult i32 %phi.116, %isetrp_rhs.56
  %sel.60 = select i1 %isetrp_cmp1.79.not, i32 -1, i32 %.1239
  %.1269 = and i32 %phi.113, %sel.60
  %iadd3_n1.54 = add i32 %phi.120, 1
  %isetrp_cmp1.82.not = icmp eq i32 %iadd3_n1.54, 0
  %isetrp_cmp1.78.not = icmp ult i32 %phi.111, %isetrp_rhs.56
  %sel.59 = select i1 %isetrp_cmp1.78.not, i32 -1, i32 %.1239
  %.1261 = and i32 %phi.112, %sel.59
  br i1 %isetrp_cmp1.82.not, label %BB_2130.loopexit, label %BB_1fd0

BB_2130.loopexit:                                 ; preds = %BB_1fd0
  br label %BB_2130

BB_2130:                                          ; preds = %BB_2130.loopexit, %BB_1ef0, %BB_18d0
  %phi.121 = phi i32 [ %phi.91, %BB_18d0 ], [ %phi.103, %BB_1ef0 ], [ %.1261, %BB_2130.loopexit ]
  %phi.122 = phi i32 [ %phi.92, %BB_18d0 ], [ %phi.104, %BB_1ef0 ], [ %.1269, %BB_2130.loopexit ]
  %phi.123 = phi i32 [ %phi.93, %BB_18d0 ], [ %phi.105, %BB_1ef0 ], [ %.1277, %BB_2130.loopexit ]
  %phi.124 = phi i32 [ %phi.94, %BB_18d0 ], [ %phi.106, %BB_1ef0 ], [ %.1285, %BB_2130.loopexit ]
  %phi.125 = phi i32 [ %phi.95, %BB_18d0 ], [ %phi.107, %BB_1ef0 ], [ %phi.107, %BB_2130.loopexit ]
  %phi.126 = phi i32 [ %phi.96, %BB_18d0 ], [ %phi.108, %BB_1ef0 ], [ %phi.108, %BB_2130.loopexit ]
  %phi.127 = phi i32 [ %imad.49, %BB_18d0 ], [ %phi.110, %BB_1ef0 ], [ %iadd3_n1.54, %BB_2130.loopexit ]
  %.1302 = getelementptr inbounds nuw i8, ptr %param_local, i64 468
  %ldc_const.7 = load i32, ptr %.1302, align 4
  %isetrp_cmp1.83 = icmp slt i32 %ldc_const.7, 2
  br i1 %isetrp_cmp1.83, label %BB_28f0, label %BB_2170

BB_2170:                                          ; preds = %BB_2130
  %iadd3_n1.61 = add nsw i32 %ldc_const.7, -1
  %.1314 = and i32 %iadd3_n1.61, 3
  %31 = add nsw i32 %ldc_const.7, -2
  %isetrp_cmp1.84 = icmp ult i32 %31, 3
  br i1 %isetrp_cmp1.84, label %BB_26d0, label %BB_21e0

BB_21e0:                                          ; preds = %BB_2170
  %iadd3_n1.62 = and i32 %iadd3_n1.61, -4
  %mov.6 = load i32, ptr %.226, align 4
  %.1328 = getelementptr inbounds nuw i8, ptr %param_local, i64 648
  %mov.7 = load i32, ptr %.1328, align 4
  br label %BB_2220

BB_2220:                                          ; preds = %BB_2220, %BB_21e0
  %phi.128 = phi i32 [ %iadd3_n1.62, %BB_21e0 ], [ %iadd3_n1.64, %BB_2220 ]
  %phi.129 = phi i32 [ %phi.121, %BB_21e0 ], [ %.1473, %BB_2220 ]
  %phi.130 = phi i32 [ %phi.122, %BB_21e0 ], [ %.1478, %BB_2220 ]
  %phi.131 = phi i32 [ %phi.123, %BB_21e0 ], [ %.1483, %BB_2220 ]
  %phi.132 = phi i32 [ %phi.124, %BB_21e0 ], [ %.1488, %BB_2220 ]
  %phi.133 = phi i32 [ 1, %BB_21e0 ], [ %iadd3_n1.69, %BB_2220 ]
  %iadd3_n1.69 = add i32 %phi.133, 4
  %imad_tmp.136 = mul i32 %phi.133, %mov.7
  %imad_rhs.83 = load i32, ptr %.1328, align 4
  %imad.137 = add i32 %imad_tmp.136, %imad_rhs.83
  %iadd3_n1.65 = add i32 %imad.137, %imad_rhs.83
  %iadd3_n1.66 = add i32 %iadd3_n1.65, %imad_rhs.83
  %imad_tmp.134 = mul i32 %phi.133, %imad_rhs.83
  %imad.151 = add i32 %imad.60, %iadd3_n1.66
  %isetrp_rhs.60 = load i32, ptr %.606, align 4
  %isetrp_cmp1.99.not = icmp ult i32 %imad.151, %isetrp_rhs.60
  %.1335 = zext i32 %mov.6 to i64
  %iadd3_n1.68 = add i32 %phi.133, 3
  %shf_shift_64.36 = zext nneg i32 %iadd3_n1.68 to i64
  %.1445 = shl i64 %.1335, %shf_shift_64.36
  %shf_result.36 = trunc i64 %.1445 to i32
  %.1451 = xor i32 %shf_result.36, -1
  %sel.78 = select i1 %isetrp_cmp1.99.not, i32 -1, i32 %.1451
  %imad.143 = add i32 %imad.60, %imad.137
  %isetrp_cmp1.92.not = icmp ult i32 %imad.143, %isetrp_rhs.60
  %iadd3_n1.63 = add i32 %phi.133, 1
  %shf_shift_64.34 = zext nneg i32 %iadd3_n1.63 to i64
  %.1350 = shl i64 %.1335, %shf_shift_64.34
  %shf_result.34 = trunc i64 %.1350 to i32
  %.1376 = xor i32 %shf_result.34, -1
  %sel.69 = select i1 %isetrp_cmp1.92.not, i32 -1, i32 %.1376
  %.1440 = and i32 %sel.69, %phi.132
  %imad.136 = add i32 %imad_tmp.134, %imad.60
  %isetrp_cmp1.86.not = icmp ult i32 %imad.136, %isetrp_rhs.60
  %shf_shift_64.33 = zext nneg i32 %phi.133 to i64
  %.1338 = shl i64 %.1335, %shf_shift_64.33
  %shf_result.33 = trunc i64 %.1338 to i32
  %.1352 = xor i32 %shf_result.33, -1
  %sel.70 = select i1 %isetrp_cmp1.86.not, i32 -1, i32 %.1352
  %.1441 = and i32 %.1440, %sel.70
  %.1487 = and i32 %sel.78, %.1441
  %imad.147 = add i32 %imad.60, %iadd3_n1.65
  %isetrp_cmp1.96.not = icmp ult i32 %imad.147, %isetrp_rhs.60
  %iadd3_n1.67 = add i32 %phi.133, 2
  %shf_shift_64.35 = zext nneg i32 %iadd3_n1.67 to i64
  %.1420 = shl i64 %.1335, %shf_shift_64.35
  %shf_result.35 = trunc i64 %.1420 to i32
  %.1424 = xor i32 %shf_result.35, -1
  %sel.77 = select i1 %isetrp_cmp1.96.not, i32 -1, i32 %.1424
  %.1488 = and i32 %.1487, %sel.77
  %imad.146 = add i32 %imad.58, %iadd3_n1.65
  %isetrp_cmp1.95.not = icmp ult i32 %imad.146, %isetrp_rhs.60
  %sel.73 = select i1 %isetrp_cmp1.95.not, i32 -1, i32 %.1424
  %imad.141 = add i32 %imad_tmp.134, %imad.58
  %isetrp_cmp1.91.not = icmp ult i32 %imad.141, %isetrp_rhs.60
  %sel.67 = select i1 %isetrp_cmp1.91.not, i32 -1, i32 %.1352
  %imad.142 = add i32 %imad.58, %imad.137
  %isetrp_cmp1.90.not = icmp ult i32 %imad.142, %isetrp_rhs.60
  %sel.68 = select i1 %isetrp_cmp1.90.not, i32 -1, i32 %.1376
  %.1467 = and i32 %sel.68, %phi.131
  %imad.150 = add i32 %imad.58, %iadd3_n1.66
  %isetrp_cmp1.101.not = icmp ult i32 %imad.150, %isetrp_rhs.60
  %sel.76 = select i1 %isetrp_cmp1.101.not, i32 -1, i32 %.1451
  %32 = and i32 %.1467, %sel.76
  %33 = and i32 %32, %sel.73
  %.1483 = and i32 %33, %sel.67
  %imad.148 = add i32 %imad.62, %iadd3_n1.66
  %isetrp_cmp1.97.not = icmp ult i32 %imad.148, %isetrp_rhs.60
  %sel.75 = select i1 %isetrp_cmp1.97.not, i32 -1, i32 %.1451
  %imad.140 = add i32 %imad.62, %imad.137
  %isetrp_cmp1.88.not = icmp ult i32 %imad.140, %isetrp_rhs.60
  %sel.65 = select i1 %isetrp_cmp1.88.not, i32 -1, i32 %.1376
  %.1400 = and i32 %sel.65, %phi.130
  %imad.138 = add i32 %imad_tmp.134, %imad.62
  %isetrp_cmp1.89.not = icmp ult i32 %imad.138, %isetrp_rhs.60
  %sel.64 = select i1 %isetrp_cmp1.89.not, i32 -1, i32 %.1352
  %.1401 = and i32 %.1400, %sel.64
  %.1477 = and i32 %sel.75, %.1401
  %imad.145 = add i32 %imad.62, %iadd3_n1.65
  %isetrp_cmp1.94.not = icmp ult i32 %imad.145, %isetrp_rhs.60
  %sel.72 = select i1 %isetrp_cmp1.94.not, i32 -1, i32 %.1424
  %.1478 = and i32 %.1477, %sel.72
  %imad.149 = add i32 %imad.55, %iadd3_n1.66
  %isetrp_cmp1.98.not = icmp ult i32 %imad.149, %isetrp_rhs.60
  %sel.74 = select i1 %isetrp_cmp1.98.not, i32 -1, i32 %.1451
  %imad.139 = add i32 %imad.55, %imad.137
  %isetrp_cmp1.87.not = icmp ult i32 %imad.139, %isetrp_rhs.60
  %sel.66 = select i1 %isetrp_cmp1.87.not, i32 -1, i32 %.1376
  %.1413 = and i32 %sel.66, %phi.129
  %imad.135 = add i32 %imad_tmp.134, %imad.55
  %isetrp_cmp1.85.not = icmp ult i32 %imad.135, %isetrp_rhs.60
  %sel.63 = select i1 %isetrp_cmp1.85.not, i32 -1, i32 %.1352
  %.1414 = and i32 %.1413, %sel.63
  %.1472 = and i32 %sel.74, %.1414
  %imad.144 = add i32 %imad.55, %iadd3_n1.65
  %isetrp_cmp1.93.not = icmp ult i32 %imad.144, %isetrp_rhs.60
  %sel.71 = select i1 %isetrp_cmp1.93.not, i32 -1, i32 %.1424
  %.1473 = and i32 %.1472, %sel.71
  %iadd3_n1.64 = add i32 %phi.128, -4
  %isetrp_cmp1.100.not = icmp eq i32 %iadd3_n1.64, 0
  br i1 %isetrp_cmp1.100.not, label %BB_26d0.loopexit, label %BB_2220

BB_26d0.loopexit:                                 ; preds = %BB_2220
  br label %BB_26d0

BB_26d0:                                          ; preds = %BB_26d0.loopexit, %BB_2170
  %phi.134 = phi i32 [ %phi.121, %BB_2170 ], [ %.1473, %BB_26d0.loopexit ]
  %phi.135 = phi i32 [ %phi.122, %BB_2170 ], [ %.1478, %BB_26d0.loopexit ]
  %phi.136 = phi i32 [ %phi.123, %BB_2170 ], [ %.1483, %BB_26d0.loopexit ]
  %phi.137 = phi i32 [ %phi.124, %BB_2170 ], [ %.1488, %BB_26d0.loopexit ]
  %phi.138 = phi i32 [ %phi.126, %BB_2170 ], [ %sel.67, %BB_26d0.loopexit ]
  %phi.139 = phi i32 [ 1, %BB_2170 ], [ %iadd3_n1.69, %BB_26d0.loopexit ]
  %phi.140 = phi i32 [ %phi.127, %BB_2170 ], [ %mov.6, %BB_26d0.loopexit ]
  %isetrp_cmp1.102.not = icmp eq i32 %.1314, 0
  br i1 %isetrp_cmp1.102.not, label %BB_28f0, label %BB_26e0

BB_26e0:                                          ; preds = %BB_26d0
  %.1493 = getelementptr inbounds nuw i8, ptr %param_local, i64 648
  %imad_rhs.87 = load i32, ptr %.1493, align 4
  %imad_tmp.151 = mul i32 %phi.139, %imad_rhs.87
  %iadd3_o2_neg.12 = sub nsw i32 0, %.1314
  %mov.8 = load i32, ptr %.226, align 4
  %imad_rhs.88 = load i32, ptr %.213, align 4
  %imad_tmp.152 = mul i32 %phi.56, %imad_rhs.88
  %imad.153 = add i32 %imad_tmp.152, %imad_tmp.151
  %imad_tmp.153 = mul i32 %phi.64, %imad_rhs.88
  %imad.154 = add i32 %imad_tmp.153, %imad_tmp.151
  %imad_tmp.154 = mul i32 %phi.65, %imad_rhs.88
  %imad.155 = add i32 %imad_tmp.154, %imad_tmp.151
  %iadd3_o2.31 = load i32, ptr %.574, align 4
  %iadd3_n1.71 = sub i32 %imad.153, %iadd3_o2.31
  %imad_tmp.155 = mul i32 %phi.60, %imad_rhs.88
  %imad.156 = add i32 %imad_tmp.155, %imad_tmp.151
  %iadd3_n1.72 = sub i32 %imad.154, %iadd3_o2.31
  %iadd3_n1.73 = sub i32 %imad.155, %iadd3_o2.31
  %iadd3_n1.74 = sub i32 %imad.156, %iadd3_o2.31
  br label %BB_2790

BB_2790:                                          ; preds = %BB_2790, %BB_26e0
  %phi.141 = phi i32 [ %phi.134, %BB_26e0 ], [ %.1543, %BB_2790 ]
  %phi.142 = phi i32 [ %phi.135, %BB_26e0 ], [ %.1551, %BB_2790 ]
  %phi.143 = phi i32 [ %phi.136, %BB_26e0 ], [ %.1559, %BB_2790 ]
  %phi.144 = phi i32 [ %phi.137, %BB_26e0 ], [ %.1567, %BB_2790 ]
  %phi.145 = phi i32 [ %phi.139, %BB_26e0 ], [ %iadd3_n1.80, %BB_2790 ]
  %phi.146 = phi i32 [ %iadd3_n1.71, %BB_26e0 ], [ %iadd3_n1.76, %BB_2790 ]
  %phi.147 = phi i32 [ %iadd3_n1.72, %BB_26e0 ], [ %iadd3_n1.77, %BB_2790 ]
  %phi.148 = phi i32 [ %iadd3_n1.73, %BB_26e0 ], [ %iadd3_n1.78, %BB_2790 ]
  %phi.149 = phi i32 [ %iadd3_n1.74, %BB_26e0 ], [ %iadd3_n1.79, %BB_2790 ]
  %phi.150 = phi i32 [ %iadd3_o2_neg.12, %BB_26e0 ], [ %iadd3_n1.75, %BB_2790 ]
  %iadd3_n1.80 = add i32 %phi.145, 1
  %iadd3_o2.35 = load i32, ptr %.1493, align 4
  %iadd3_n1.79 = add i32 %phi.149, %iadd3_o2.35
  %iadd3_n1.78 = add i32 %phi.148, %iadd3_o2.35
  %iadd3_n1.77 = add i32 %phi.147, %iadd3_o2.35
  %iadd3_n1.76 = add i32 %phi.146, %iadd3_o2.35
  %isetrp_rhs.76 = load i32, ptr %.606, align 4
  %isetrp_cmp1.104.not = icmp ult i32 %phi.146, %isetrp_rhs.76
  %.1514 = zext i32 %mov.8 to i64
  %shf_shift_64.37 = zext nneg i32 %phi.145 to i64
  %.1517 = shl i64 %.1514, %shf_shift_64.37
  %shf_result.37 = trunc i64 %.1517 to i32
  %.1521 = xor i32 %shf_result.37, -1
  %sel.80 = select i1 %isetrp_cmp1.104.not, i32 -1, i32 %.1521
  %.1567 = and i32 %phi.144, %sel.80
  %isetrp_cmp1.107.not = icmp ult i32 %phi.147, %isetrp_rhs.76
  %sel.82 = select i1 %isetrp_cmp1.107.not, i32 -1, i32 %.1521
  %.1559 = and i32 %phi.143, %sel.82
  %isetrp_cmp1.105.not = icmp ult i32 %phi.148, %isetrp_rhs.76
  %sel.81 = select i1 %isetrp_cmp1.105.not, i32 -1, i32 %.1521
  %.1551 = and i32 %phi.142, %sel.81
  %isetrp_cmp1.103.not = icmp ult i32 %phi.149, %isetrp_rhs.76
  %sel.79 = select i1 %isetrp_cmp1.103.not, i32 -1, i32 %.1521
  %.1543 = and i32 %phi.141, %sel.79
  %iadd3_n1.75 = add i32 %phi.150, 1
  %isetrp_cmp1.106.not = icmp eq i32 %iadd3_n1.75, 0
  br i1 %isetrp_cmp1.106.not, label %BB_28f0.loopexit, label %BB_2790

BB_28f0.loopexit:                                 ; preds = %BB_2790
  br label %BB_28f0

BB_28f0:                                          ; preds = %BB_28f0.loopexit, %BB_26d0, %BB_2130
  %phi.151 = phi i32 [ %phi.121, %BB_2130 ], [ %phi.134, %BB_26d0 ], [ %.1543, %BB_28f0.loopexit ]
  %phi.152 = phi i32 [ %phi.122, %BB_2130 ], [ %phi.135, %BB_26d0 ], [ %.1551, %BB_28f0.loopexit ]
  %phi.153 = phi i32 [ %phi.123, %BB_2130 ], [ %phi.136, %BB_26d0 ], [ %.1559, %BB_28f0.loopexit ]
  %phi.154 = phi i32 [ %phi.124, %BB_2130 ], [ %phi.137, %BB_26d0 ], [ %.1567, %BB_28f0.loopexit ]
  %phi.155 = phi i32 [ %phi.126, %BB_2130 ], [ %phi.138, %BB_26d0 ], [ %phi.138, %BB_28f0.loopexit ]
  %phi.156 = phi i32 [ %imad.58, %BB_2130 ], [ %imad.58, %BB_26d0 ], [ %iadd3_n1.75, %BB_28f0.loopexit ]
  %phi.157 = phi i32 [ %phi.127, %BB_2130 ], [ %phi.140, %BB_26d0 ], [ %mov.8, %BB_28f0.loopexit ]
  %.1582 = getelementptr inbounds nuw i8, ptr %param_local, i64 652
  %ldc_const.8 = load i8, ptr %.1582, align 1
  %.1583 = getelementptr inbounds nuw i8, ptr %param_local, i64 1560
  %imad_addend.22 = load i32, ptr %.1583, align 4
  %isetrp_cmp1.108.not = icmp eq i8 %ldc_const.8, 0
  %.1585 = getelementptr inbounds nuw i8, ptr %param_local, i64 600
  %ldc_const.9 = load i8, ptr %.1585, align 1
  %34 = ashr i32 %.225, 3
  %.1592 = add i32 %34, %.202
  %iadd3_n1.81 = add i32 %imad_addend.22, -1
  %.1593 = getelementptr inbounds nuw i8, ptr %param_local, i64 364
  %imad_addend.23 = load i32, ptr %.1593, align 4
  %.1595 = getelementptr inbounds nuw i8, ptr %param_local, i64 1584
  %isetrp_rhs.80 = load i32, ptr %.1595, align 4
  %isetrp_cmp1.109 = icmp slt i32 %isetrp_rhs.80, 0
  %imad_addend.24 = load i32, ptr %.3, align 4
  %.1602 = shl i32 %iadd3_n1.15, 3
  %isetrp_rhs.81 = load i32, ptr %.203, align 4
  %isetrp_cmp1.110.not = icmp slt i32 %imad.11, %isetrp_rhs.81
  %.1607 = getelementptr inbounds nuw i8, ptr %param_local, i64 948
  %imad_addend.25 = load i32, ptr %.1607, align 4
  %.1612 = xor i32 %ctaid_z, -1
  %phi.160 = select i1 %isetrp_cmp1.108.not, i32 %.1612, i32 %phi.157
  %imad_rhs.92 = load i32, ptr %.185, align 4
  %imad_tmp.160 = mul i32 %ctaid_z, %imad_rhs.92
  %imad.161 = add i32 %imad_tmp.160, %.1602
  %iadd3_n1.82 = add i32 %.1592, 16
  %.1630 = getelementptr inbounds nuw i8, ptr %param_local, i64 444
  %iadd3_o2.39 = load i32, ptr %.1630, align 4
  %iadd3_n1.83 = add i32 %iadd3_o2.39, %.1612
  %phi.161 = select i1 %isetrp_cmp1.108.not, i32 %iadd3_n1.83, i32 %phi.156
  %.1634 = getelementptr inbounds nuw i8, ptr %param_local, i64 944
  %iadd3_o2.40 = load i32, ptr %.1634, align 4
  %iadd3_n1.84 = add i32 %imad_addend.25, %iadd3_o2.40
  br i1 %isetrp_cmp1.108.not, label %BB_80002a30, label %BB_2a50

BB_80002a30:                                      ; preds = %BB_28f0
  %.1638 = getelementptr inbounds nuw i8, ptr %param_local, i64 448
  %iadd3_o2.41 = load i32, ptr %.1638, align 4
  %iadd3_n1.85 = add i32 %phi.160, %iadd3_o2.41
  %.1640 = getelementptr inbounds nuw i8, ptr %param_local, i64 944
  %imad_rhs.93 = load i32, ptr %.1640, align 4
  %imad_tmp.161 = mul i32 %phi.161, %imad_rhs.93
  br label %BB_2a50

BB_2a50:                                          ; preds = %BB_80002a30, %BB_28f0
  %phi.163 = phi i32 [ %imad_tmp.161, %BB_80002a30 ], [ %phi.161, %BB_28f0 ]
  %phi.164 = phi i32 [ %iadd3_n1.85, %BB_80002a30 ], [ %phi.160, %BB_28f0 ]
  %.1643 = getelementptr inbounds nuw i8, ptr %param_local, i64 360
  %mov.9 = load i32, ptr %.1643, align 4
  %35 = zext i32 %imad_addend.23 to i64
  %36 = shl nuw i64 %35, 32
  %37 = zext i32 %mov.9 to i64
  %38 = or disjoint i64 %36, %37
  %imad_tmp.162 = mul i32 %iadd3_n1.84, %ctaid_z
  %.1648 = getelementptr inbounds nuw i8, ptr %param_local, i64 356
  %mov.10 = load i32, ptr %.1648, align 4
  %39 = zext i32 %mov.10 to i64
  %40 = shl nuw i64 %39, 32
  %41 = zext i32 %imad_addend.24 to i64
  %42 = or disjoint i64 %40, %41
  %.1652 = getelementptr inbounds nuw i8, ptr %param_local, i64 948
  %imad_rhs.94 = load i32, ptr %.1652, align 4
  %imad_tmp.163 = mul i32 %phi.164, %imad_rhs.94
  %imad.164 = add i32 %imad_tmp.163, %phi.163
  %isetrp_cmp1.111.not = icmp eq i8 %ldc_const.9, 0
  %.1655 = getelementptr inbounds nuw i8, ptr %param_local, i64 980
  %imad_addend.26 = load i32, ptr %.1655, align 4
  %.1657 = getelementptr inbounds nuw i8, ptr %param_local, i64 440
  %ldc_const.10 = load i32, ptr %.1657, align 4
  %43 = add i32 %iadd3_n1.81, %imad.164
  %imad.166 = select i1 %isetrp_cmp1.108.not, i32 %43, i32 %imad_tmp.162
  %imad_tmp.166 = mul i32 %ldc_const.4, %ldc_const.10
  %iadd3_o2.42 = load i32, ptr %.702, align 4
  %iadd3_n1.86 = add i32 %imad.161, %iadd3_o2.42
  %imad_tmp.167 = mul i32 %.1592, %imad_addend.26
  %imad.168 = add i32 %imad_tmp.167, %imad.166
  %sel.84 = select i1 %isetrp_cmp1.111.not, i32 1, i32 %imad_addend.26
  %.1663 = getelementptr inbounds nuw i8, ptr %param_local, i64 976
  %imad_rhs.96 = load i32, ptr %.1663, align 4
  %imad_tmp.168 = mul i32 %.1592, %imad_rhs.96
  %imad.169 = add i32 %imad_tmp.168, %imad.166
  %imad_rhs.97 = load i32, ptr %.203, align 4
  %imad_tmp.169 = mul i32 %imad.168, %imad_rhs.97
  %phi.167 = select i1 %isetrp_cmp1.111.not, i32 %imad_tmp.169, i32 %imad.169
  %isetrp_cmp1.112 = icmp slt i32 %.1592, %imad_tmp.166
  %isetrp_cmp2.112 = and i1 %isetrp_cmp1.112, %isetrp_cmp1.110.not
  %isetrp_cmp1.113 = icmp slt i32 %iadd3_n1.82, %imad_tmp.166
  %isetrp_cmp2.113 = and i1 %isetrp_cmp1.113, %isetrp_cmp1.110.not
  %imad_tmp.171 = mul i32 %imad.11, %sel.84
  %imad.172 = add i32 %imad_tmp.171, %phi.167
  %p2r_p0_i32.1 = zext i1 %isetrp_cmp2.112 to i32
  %p2r_p1_shl.1 = select i1 %isetrp_cmp2.113, i32 2, i32 0
  %p2r_or_1.1 = or disjoint i32 %p2r_p1_shl.1, %p2r_p0_i32.1
  %imad_rhs.98 = load i32, ptr %.1663, align 4
  %imad_tmp.172 = shl i32 %imad_rhs.98, 4
  %imad.173 = add i32 %imad_tmp.172, %imad.172
  br i1 %isetrp_cmp1.109, label %BB_2fe0, label %BB_2ba0

BB_2ba0:                                          ; preds = %BB_2a50
  %imad_addend.27 = load i32, ptr %.1595, align 4
  %isetrp_cmp1.114 = icmp slt i32 %imad_addend.22, 2
  %imad_addend.28 = load i32, ptr %.3, align 4
  %imad_addend.29 = load i32, ptr %.1648, align 4
  %44 = zext i32 %imad_addend.29 to i64
  %45 = shl nuw i64 %44, 32
  %46 = zext i32 %imad_addend.28 to i64
  %47 = or disjoint i64 %45, %46
  %iadd3_n1.87 = add i32 %imad_addend.27, 1
  %iadd3_n1.88 = add i32 %imad_addend.27, 4
  %imnmx_max = call i32 @llvm.smin.i32(i32 %iadd3_n1.87, i32 4)
  %.1680 = getelementptr inbounds nuw i8, ptr %param_local, i64 1588
  %iadd3_o2.43 = load i32, ptr %.1680, align 4
  %iadd3_n1.89 = sub i32 %iadd3_n1.88, %iadd3_o2.43
  %48 = and i32 %.326, 16777200
  %p2c.f157 = add nuw nsw i32 %48, 2048
  %p2c.f158 = add nuw nsw i32 %48, 4096
  %p2c.f159 = add nuw nsw i32 %48, 6144
  %49 = add i32 %.326, 40960
  %50 = and i32 %49, 16777200
  %p2c.f160 = add nsw i32 %50, -32768
  %p2c.f161 = add nsw i32 %50, -30720
  br label %BB_2c50

BB_2c50:                                          ; preds = %BB_2fd0, %BB_2ba0
  %p2c.c = phi i32 [ 0, %BB_2ba0 ], [ %113, %BB_2fd0 ]
  %51 = phi i64 [ %38, %BB_2ba0 ], [ %112, %BB_2fd0 ]
  %52 = phi i64 [ %47, %BB_2ba0 ], [ %111, %BB_2fd0 ]
  %phi.168 = phi i32 [ 0, %BB_2ba0 ], [ %phi.178, %BB_2fd0 ]
  %phi.169 = phi i32 [ 0, %BB_2ba0 ], [ %phi.179, %BB_2fd0 ]
  %phi.170 = phi i32 [ 0, %BB_2ba0 ], [ %iadd3_n1.96, %BB_2fd0 ]
  %phi.171 = phi i32 [ %p2r_or_3, %BB_2ba0 ], [ %sel.86, %BB_2fd0 ]
  %phi.172 = phi i32 [ %p2r_or_1.1, %BB_2ba0 ], [ %sel.87, %BB_2fd0 ]
  %phi.173 = phi i32 [ 0, %BB_2ba0 ], [ %sel.85, %BB_2fd0 ]
  %r2p_p0 = trunc i32 %phi.171 to i1
  %imad_tmp.176 = shl i32 %phi.173, 3
  %ldc_idx = add i32 %imad_tmp.176, 1032
  %ldc_const_off_zext = zext i32 %ldc_idx to i64
  %.1683 = getelementptr inbounds nuw [1840 x i8], ptr %param_local, i64 0, i64 %ldc_const_off_zext
  %ldc_const.11 = load i64, ptr %.1683, align 8
  %isetrp_cmp1.115 = icmp slt i32 %phi.168, 32768
  %imad_lhs_64.13 = sext i32 %imad.71 to i64
  %imad_tmp_64.13 = shl nsw i64 %imad_lhs_64.13, 1
  %imad.178 = add i64 %imad_tmp_64.13, %52
  %"R37:R36_r0" = trunc i64 %imad.178 to i32
  %53 = add i64 %imad_tmp_64.13, %52
  %isetrp_cmp1.116 = icmp slt i32 %phi.169, 16384
  %imad_lhs_64.14 = sext i32 %imad.72 to i64
  %imad_tmp_64.14 = shl nsw i64 %imad_lhs_64.14, 1
  %54 = add i64 %imad_tmp_64.14, %52
  %warp_reconv_mask = call i32 asm sideeffect "activemask.b32 $0;", "=r"() #10
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  %55 = icmp slt i32 %p2c.c, 1
  br i1 %55, label %56, label %58

56:                                               ; preds = %BB_2c50
  %57 = zext nneg i32 %48 to i64
  %p2c.sm163 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %57
  %p2c.smp164 = ptrtoint ptr addrspace(3) %p2c.sm163 to i64
  %p2c.sz = select i1 %r2p_p0, i32 16, i32 0
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp164, i64 %53, i32 %p2c.sz) #10
  br label %62

58:                                               ; preds = %BB_2c50
  %p2c.q165 = select i1 %r2p_p0, i64 %53, i64 0
  %59 = zext nneg i32 %p2c.c to i64
  %60 = getelementptr i64, ptr %p2c.q209, i64 %59
  %61 = getelementptr i8, ptr %60, i64 -8
  store i64 %p2c.q165, ptr %61, align 8
  br label %62

62:                                               ; preds = %58, %56
  %imad_lhs_64.15 = sext i32 %imad.68 to i64
  %imad_tmp_64.15 = shl nsw i64 %imad_lhs_64.15, 1
  %63 = add i64 %imad_tmp_64.15, %52
  %64 = shl i32 %phi.171, 3
  %cpa_srcsz.1 = and i32 %64, 16
  %65 = icmp slt i32 %p2c.c, 1
  br i1 %65, label %66, label %68

66:                                               ; preds = %62
  %67 = zext nneg i32 %p2c.f157 to i64
  %p2c.sm167 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %67
  %p2c.smp168 = ptrtoint ptr addrspace(3) %p2c.sm167 to i64
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp168, i64 %54, i32 %cpa_srcsz.1) #10
  br label %72

68:                                               ; preds = %62
  %.not = icmp eq i32 %cpa_srcsz.1, 0
  %p2c.q170 = select i1 %.not, i64 0, i64 %54
  %69 = add nuw i32 %p2c.c, 5
  %70 = sext i32 %69 to i64
  %71 = getelementptr i64, ptr %p2c.q209, i64 %70
  store i64 %p2c.q170, ptr %71, align 8
  br label %72

72:                                               ; preds = %68, %66
  %r2p_p0.1 = trunc i32 %phi.172 to i1
  %imad_lhs_64.16 = sext i32 %imad.69 to i64
  %imad_tmp_64.16 = shl nsw i64 %imad_lhs_64.16, 1
  %73 = add i64 %imad_tmp_64.16, %52
  %phi.178.v = select i1 %isetrp_cmp1.115, i32 8192, i32 -32768
  %phi.178 = add i32 %phi.168, %phi.178.v
  %74 = shl i32 %phi.171, 2
  %cpa_srcsz.2 = and i32 %74, 16
  %75 = icmp slt i32 %p2c.c, 1
  br i1 %75, label %76, label %78

76:                                               ; preds = %72
  %77 = zext nneg i32 %p2c.f158 to i64
  %p2c.sm172 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %77
  %p2c.smp173 = ptrtoint ptr addrspace(3) %p2c.sm172 to i64
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp173, i64 %63, i32 %cpa_srcsz.2) #10
  br label %82

78:                                               ; preds = %72
  %.not211 = icmp eq i32 %cpa_srcsz.2, 0
  %p2c.q175 = select i1 %.not211, i64 0, i64 %63
  %79 = add nuw i32 %p2c.c, 8
  %80 = sext i32 %79 to i64
  %81 = getelementptr i64, ptr %p2c.q209, i64 %80
  store i64 %p2c.q175, ptr %81, align 8
  br label %82

82:                                               ; preds = %78, %76
  %phi.179.v = select i1 %isetrp_cmp1.116, i32 4096, i32 -16384
  %phi.179 = add i32 %phi.169, %phi.179.v
  %imad_lhs_64.17 = sext i32 %imad.172 to i64
  %imad_tmp_64.17 = shl nsw i64 %imad_lhs_64.17, 1
  %83 = add i64 %imad_tmp_64.17, %51
  %84 = shl i32 %phi.171, 1
  %cpa_srcsz.3 = and i32 %84, 16
  %85 = icmp slt i32 %p2c.c, 1
  br i1 %85, label %86, label %88

86:                                               ; preds = %82
  %87 = zext nneg i32 %p2c.f159 to i64
  %p2c.sm177 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %87
  %p2c.smp178 = ptrtoint ptr addrspace(3) %p2c.sm177 to i64
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp178, i64 %73, i32 %cpa_srcsz.3) #10
  br label %92

88:                                               ; preds = %82
  %.not213 = icmp eq i32 %cpa_srcsz.3, 0
  %p2c.q180 = select i1 %.not213, i64 0, i64 %73
  %89 = add nuw i32 %p2c.c, 2
  %90 = sext i32 %89 to i64
  %91 = getelementptr i64, ptr %p2c.q209, i64 %90
  store i64 %p2c.q180, ptr %91, align 8
  br label %92

92:                                               ; preds = %88, %86
  %imad_lhs_64.18 = sext i32 %imad.173 to i64
  %imad_tmp_64.18 = shl nsw i64 %imad_lhs_64.18, 1
  %93 = add i64 %imad_tmp_64.18, %51
  %94 = icmp slt i32 %p2c.c, 1
  br i1 %94, label %95, label %97

95:                                               ; preds = %92
  %96 = zext i32 %p2c.f160 to i64
  %p2c.sm182 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %96
  %p2c.smp183 = ptrtoint ptr addrspace(3) %p2c.sm182 to i64
  %p2c.sz184 = select i1 %r2p_p0.1, i32 16, i32 0
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp183, i64 %83, i32 %p2c.sz184) #10
  br label %101

97:                                               ; preds = %92
  %p2c.q185 = select i1 %r2p_p0.1, i64 %83, i64 0
  %98 = add nuw i32 %p2c.c, 11
  %99 = sext i32 %98 to i64
  %100 = getelementptr i64, ptr %p2c.q209, i64 %99
  store i64 %p2c.q185, ptr %100, align 8
  br label %101

101:                                              ; preds = %97, %95
  %102 = shl i32 %phi.172, 3
  %cpa_srcsz.5 = and i32 %102, 16
  %103 = icmp slt i32 %p2c.c, 1
  br i1 %103, label %104, label %106

104:                                              ; preds = %101
  %105 = zext i32 %p2c.f161 to i64
  %p2c.sm187 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %105
  %p2c.smp188 = ptrtoint ptr addrspace(3) %p2c.sm187 to i64
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp188, i64 %93, i32 %cpa_srcsz.5) #10
  br label %110

106:                                              ; preds = %101
  %.not215 = icmp eq i32 %cpa_srcsz.5, 0
  %p2c.q190 = select i1 %.not215, i64 0, i64 %93
  %107 = add nuw i32 %p2c.c, 14
  %108 = sext i32 %107 to i64
  %109 = getelementptr i64, ptr %p2c.q209, i64 %108
  store i64 %p2c.q190, ptr %109, align 8
  br label %110

110:                                              ; preds = %106, %104
  %isetrp_cmp1.117.not = icmp eq i32 %iadd3_n1.81, %phi.173
  %111 = add i64 %ldc_const.11, %52
  %iadd3_n1.95 = add i32 %phi.173, 1
  %sel.85 = select i1 %isetrp_cmp1.117.not, i32 0, i32 %iadd3_n1.95
  %ldc_idx.1 = add i32 %imad_tmp.176, 1288
  %ldc_const_off_zext.1 = zext i32 %ldc_idx.1 to i64
  %.1706 = getelementptr inbounds nuw [1840 x i8], ptr %param_local, i64 0, i64 %ldc_const_off_zext.1
  %ldc_const.12 = load i64, ptr %.1706, align 8
  br i1 %isetrp_cmp1.114, label %BB_2fd0, label %BB_2ed0

BB_2ed0:                                          ; preds = %110
  %shf_shift_64.39 = zext nneg i32 %sel.85 to i64
  %.1713 = shl nuw i64 1, %shf_shift_64.39
  %shf_result.39 = trunc i64 %.1713 to i32
  %.1717 = and i32 %phi.151, %shf_result.39
  %lop3_pred_cmp.8 = icmp ne i32 %.1717, 0
  %.1725 = and i32 %phi.152, %shf_result.39
  %lop3_pred_cmp.9.not = icmp eq i32 %.1725, 0
  %.1733 = and i32 %phi.153, %shf_result.39
  %lop3_pred_cmp.10.not = icmp eq i32 %.1733, 0
  %.1741 = and i32 %phi.154, %shf_result.39
  %lop3_pred_cmp.11.not = icmp eq i32 %.1741, 0
  %p2r_p0_i32.2 = zext i1 %lop3_pred_cmp.8 to i32
  %p2r_p1_shl.2 = select i1 %lop3_pred_cmp.9.not, i32 0, i32 2
  %p2r_or_1.2 = or disjoint i32 %p2r_p1_shl.2, %p2r_p0_i32.2
  %p2r_p2_shl.1 = select i1 %lop3_pred_cmp.10.not, i32 0, i32 4
  %p2r_or_2.1 = or disjoint i32 %p2r_or_1.2, %p2r_p2_shl.1
  %p2r_p3_shl.1 = select i1 %lop3_pred_cmp.11.not, i32 0, i32 8
  %p2r_or_3.1 = or disjoint i32 %p2r_or_2.1, %p2r_p3_shl.1
  br label %BB_2fd0

BB_2fd0:                                          ; preds = %110, %BB_2ed0
  %phi.180 = phi i32 [ %p2r_or_3.1, %BB_2ed0 ], [ %phi.171, %110 ]
  %isetrp_cmp1.120 = icmp slt i32 %iadd3_n1.86, %imad_tmp.6
  %isetrp_cmp1.118.not = icmp sgt i32 %iadd3_n1.89, %phi.170
  %isetrp_cmp2.120 = or i1 %isetrp_cmp1.120, %isetrp_cmp1.118.not
  %sel.87 = select i1 %isetrp_cmp2.120, i32 %phi.172, i32 0
  %isetrp_cmp1.119 = icmp slt i32 %iadd3_n1.16, %imad_tmp.6
  %isetrp_cmp2.119 = or i1 %isetrp_cmp1.119, %isetrp_cmp1.118.not
  %sel.86 = select i1 %isetrp_cmp2.119, i32 %phi.180, i32 0
  %iadd3_n1.96 = add i32 %phi.170, 1
  %isetrp_cmp1.121.not = icmp sgt i32 %imnmx_max, %iadd3_n1.96
  %112 = add i64 %ldc_const.12, %51
  %113 = add i32 %p2c.c, 1
  br i1 %isetrp_cmp1.121.not, label %BB_2c50, label %BB_2fe0.loopexit

BB_2fe0.loopexit:                                 ; preds = %BB_2fd0
  br label %BB_2fe0

BB_2fe0:                                          ; preds = %BB_2fe0.loopexit, %BB_2a50
  %114 = phi i64 [ %38, %BB_2a50 ], [ %112, %BB_2fe0.loopexit ]
  %115 = phi i64 [ %42, %BB_2a50 ], [ %111, %BB_2fe0.loopexit ]
  %phi.181 = phi i32 [ 0, %BB_2a50 ], [ %phi.178, %BB_2fe0.loopexit ]
  %phi.182 = phi i32 [ 0, %BB_2a50 ], [ %phi.179, %BB_2fe0.loopexit ]
  %phi.183 = phi i32 [ %p2r_or_3, %BB_2a50 ], [ %sel.86, %BB_2fe0.loopexit ]
  %phi.184 = phi i32 [ %p2r_or_1.1, %BB_2a50 ], [ %sel.87, %BB_2fe0.loopexit ]
  %phi.185 = phi i32 [ 0, %BB_2a50 ], [ %sel.85, %BB_2fe0.loopexit ]
  %phi.190 = phi i32 [ %phi.155, %BB_2a50 ], [ %"R37:R36_r0", %BB_2fe0.loopexit ]
  %mov.11 = load i32, ptr %.1595, align 4
  %isetrp_cmp1.122 = icmp sgt i32 %mov.11, 2
  br i1 %isetrp_cmp1.122, label %BB_30f0, label %BB_3030.preheader

BB_3030.preheader:                                ; preds = %BB_2fe0
  br label %BB_3030

BB_3030:                                          ; preds = %BB_3030.preheader, %BB_3030
  %phi.191 = phi i32 [ %phi.194, %BB_3030 ], [ %phi.181, %BB_3030.preheader ]
  %phi.192 = phi i32 [ %phi.195, %BB_3030 ], [ %phi.182, %BB_3030.preheader ]
  %phi.193 = phi i32 [ %iadd3_n1.97, %BB_3030 ], [ %mov.11, %BB_3030.preheader ]
  %iadd3_n1.97 = add i32 %phi.193, 1
  %isetrp_cmp1.124 = icmp slt i32 %phi.192, 16384
  %isetrp_cmp1.125 = icmp slt i32 %iadd3_n1.97, 3
  %isetrp_cmp1.123 = icmp slt i32 %phi.191, 32768
  %phi.194.v = select i1 %isetrp_cmp1.123, i32 8192, i32 -32768
  %phi.194 = add i32 %phi.191, %phi.194.v
  %phi.195.v = select i1 %isetrp_cmp1.124, i32 4096, i32 -16384
  %phi.195 = add i32 %phi.192, %phi.195.v
  br i1 %isetrp_cmp1.125, label %BB_3030, label %BB_30f0.loopexit

BB_30f0.loopexit:                                 ; preds = %BB_3030
  br label %BB_30f0

BB_30f0:                                          ; preds = %BB_30f0.loopexit, %BB_2fe0
  %phi.196 = phi i32 [ %phi.181, %BB_2fe0 ], [ %phi.194, %BB_30f0.loopexit ]
  %phi.197 = phi i32 [ %phi.182, %BB_2fe0 ], [ %phi.195, %BB_30f0.loopexit ]
  %.1766 = and i32 %tid_x, 7
  %.1774 = and i32 %tid_x, 64
  %.1801 = lshr exact i32 %.1774, 2
  %.1802 = or disjoint i32 %.1801, %.1766
  %imad_tmp.182 = shl i32 %tid_x, 4
  %.1782 = lshr i32 %tid_x, 3
  %116 = and i32 %.1782, 1
  %.1790 = lshr i32 %tid_x, 1
  %117 = and i32 %.1790, 8
  %.18152 = or disjoint i32 %117, %.1802
  %.1820 = and i32 %tid_x, 32
  %.1828 = and i32 %tid_x, 15
  %.1843 = xor i32 %tid_x, -1
  %.1844 = xor i32 %116, 7
  %.1845 = and i32 %.1844, %tid_x
  %.1853 = and i32 %116, %.1843
  %.1854 = or disjoint i32 %.1845, %.1853
  %.1861 = lshr exact i32 %.1820, 1
  %.1862 = or disjoint i32 %.1861, %.1828
  %.1864 = and i32 %imad_tmp.182, 16
  %.1867 = xor i32 %.1864, 16
  %.1868 = and i32 %.1867, %tid_x
  %.1869 = and i32 %imad_tmp.182, 96
  %.1874 = or disjoint i32 %.1868, %.1869
  %.1875 = and i32 %imad_tmp.182, 16
  %.1876 = and i32 %.1875, %.1843
  %imad_tmp.184 = shl nuw nsw i32 %.1862, 7
  %118 = or disjoint i32 %.1876, %imad_tmp.184
  %imad.191 = or i32 %118, %.1874
  call void @llvm.nvvm.barrier0()
  %119 = shl nuw nsw i32 %.18152, 7
  %120 = shl nuw nsw i32 %.1854, 4
  %imad_tmp.185 = or disjoint i32 %119, %120
  %ldsm_shared_winoff = and i32 %imad.191, 16777200
  %ldsm_addr_memaddr_offset_add.1 = and i32 %imad_tmp.185, 16736240
  %p2c.f153 = or disjoint i32 %ldsm_addr_memaddr_offset_add.1, 8192
  br i1 %isetrp_cmp1.109, label %BB_3970, label %BB_3260

BB_3260:                                          ; preds = %BB_30f0
  %imad_addend.30 = load i32, ptr %.1583, align 4
  %.1895 = xor i32 %imad.191, 32
  %imad_lhs_64.19 = sext i32 %imad.71 to i64
  %imad_tmp_64.19 = shl nsw i64 %imad_lhs_64.19, 1
  %.1899 = xor i32 %imad_tmp.185, -1
  %.1902 = and i32 %.1899, 32
  %.1907 = and i32 %imad_tmp.185, 16777168
  %.1909 = or disjoint i32 %.1902, %.1907
  %isetrp_cmp1.126 = icmp sgt i32 %imad_addend.30, 1
  %imad_lhs_64.20 = sext i32 %imad.72 to i64
  %imad_tmp_64.20 = shl nsw i64 %imad_lhs_64.20, 1
  %.1930 = and i32 %.1899, 64
  %.1935 = and i32 %imad_tmp.185, 16777136
  %.1937 = or disjoint i32 %.1930, %.1935
  %imad_lhs_64.21 = sext i32 %imad.68 to i64
  %imad_tmp_64.21 = shl nsw i64 %imad_lhs_64.21, 1
  %.1885 = and i32 %imad_tmp.182, 96
  %.1949 = and i32 %imad.191, 16777104
  %121 = or disjoint i32 %.1885, %.1949
  %.1951 = xor i32 %121, 96
  %.1958 = and i32 %.1899, 96
  %.1963 = and i32 %imad_tmp.185, 16777104
  %.1965 = or disjoint i32 %.1958, %.1963
  %imad_lhs_64.22 = sext i32 %imad.69 to i64
  %imad_tmp_64.22 = shl nsw i64 %imad_lhs_64.22, 1
  %mov.13 = load i32, ptr %.1595, align 4
  %imad_lhs_64.23 = sext i32 %imad.172 to i64
  %imad_tmp_64.23 = shl nsw i64 %imad_lhs_64.23, 1
  %imad_lhs_64.24 = sext i32 %imad.173 to i64
  %imad_tmp_64.24 = shl nsw i64 %imad_lhs_64.24, 1
  %spec.select85 = select i1 %isetrp_cmp1.126, i32 1, i32 %phi.90
  %.1923 = and i32 %imad.191, 16777200
  %122 = xor i32 %.1923, 64
  %123 = and i32 %imad.191, 16777200
  %124 = and i32 %imad_tmp.185, 16736240
  %p2c.f126 = or disjoint i32 %124, 8192
  %125 = and i32 %.326, 16777200
  %p2c.f137 = add nuw nsw i32 %125, 6144
  %p2c.f139 = add nuw nsw i32 %125, 2048
  %p2c.f141 = add nuw nsw i32 %125, 4096
  %126 = add i32 %.326, 40960
  %127 = and i32 %126, 16777200
  %p2c.f143 = add nsw i32 %127, -32768
  %p2c.f145 = add nsw i32 %127, -30720
  br label %BB_3370

BB_3370:                                          ; preds = %BB_3260, %BB_3890
  %lo.fragoff237 = phi i32 [ %p2c.f153, %BB_3260 ], [ %p2c.f126, %BB_3890 ]
  %lo.fragoff = phi i32 [ %ldsm_shared_winoff, %BB_3260 ], [ %123, %BB_3890 ]
  %p2c.qi = phi i32 [ 0, %BB_3260 ], [ %540, %BB_3890 ]
  %128 = phi i64 [ %114, %BB_3260 ], [ %537, %BB_3890 ]
  %129 = phi i64 [ %115, %BB_3260 ], [ %536, %BB_3890 ]
  %phi.198 = phi i32 [ 0, %BB_3260 ], [ %phi.239, %BB_3890 ]
  %phi.199 = phi i32 [ 0, %BB_3260 ], [ %phi.240, %BB_3890 ]
  %phi.200 = phi i32 [ %phi.196, %BB_3260 ], [ %phi.241, %BB_3890 ]
  %phi.201 = phi i32 [ %phi.197, %BB_3260 ], [ %phi.242, %BB_3890 ]
  %phi.202 = phi float [ 0.000000e+00, %BB_3260 ], [ %369, %BB_3890 ]
  %phi.203 = phi float [ 0.000000e+00, %BB_3260 ], [ %368, %BB_3890 ]
  %phi.204 = phi float [ 0.000000e+00, %BB_3260 ], [ %367, %BB_3890 ]
  %phi.205 = phi i32 [ %mov.13, %BB_3260 ], [ %iadd3_n1.124, %BB_3890 ]
  %phi.206 = phi i32 [ %phi.183, %BB_3260 ], [ %sel.92, %BB_3890 ]
  %phi.207 = phi i32 [ %phi.184, %BB_3260 ], [ %sel.91, %BB_3890 ]
  %phi.209 = phi float [ 0.000000e+00, %BB_3260 ], [ %366, %BB_3890 ]
  %phi.210 = phi i32 [ %phi.185, %BB_3260 ], [ %sel.90, %BB_3890 ]
  %phi.214 = phi float [ 0.000000e+00, %BB_3260 ], [ %365, %BB_3890 ]
  %phi.216 = phi float [ 0.000000e+00, %BB_3260 ], [ %364, %BB_3890 ]
  %phi.229 = phi float [ 0.000000e+00, %BB_3260 ], [ %528, %BB_3890 ]
  %phi.230 = phi float [ 0.000000e+00, %BB_3260 ], [ %527, %BB_3890 ]
  %phi.231 = phi float [ 0.000000e+00, %BB_3260 ], [ %526, %BB_3890 ]
  %phi.232 = phi float [ 0.000000e+00, %BB_3260 ], [ %525, %BB_3890 ]
  %phi.233 = phi float [ 0.000000e+00, %BB_3260 ], [ %524, %BB_3890 ]
  %phi.234 = phi float [ 0.000000e+00, %BB_3260 ], [ %523, %BB_3890 ]
  %phi.235 = phi float [ 0.000000e+00, %BB_3260 ], [ %522, %BB_3890 ]
  %phi.236 = phi float [ 0.000000e+00, %BB_3260 ], [ %521, %BB_3890 ]
  %phi.237 = phi float [ 0.000000e+00, %BB_3260 ], [ %371, %BB_3890 ]
  %phi.238 = phi float [ 0.000000e+00, %BB_3260 ], [ %370, %BB_3890 ]
  %lo.fragoff236 = add nuw nsw i32 %lo.fragoff, 4096
  %isetrp_cmp1.129 = icmp sgt i32 %phi.205, 3
  %sel.88 = select i1 %isetrp_cmp1.129, i32 %phi.206, i32 0
  %sel.89 = select i1 %isetrp_cmp1.129, i32 %phi.207, i32 0
  %r2p_p0.2 = trunc i32 %sel.88 to i1
  %130 = add i64 %imad_tmp_64.19, %129
  %p2c.q136 = select i1 %r2p_p0.2, i64 %130, i64 0
  %131 = sext i32 %p2c.qi to i64
  %132 = getelementptr i64, ptr %p2c.q209, i64 %131
  %133 = sext i32 %p2c.qi to i64
  %134 = getelementptr i64, ptr %p2c.q209, i64 %133
  %p2c.qo = load i64, ptr %134, align 8
  %135 = add i32 %p2c.qi, 3
  %136 = sext i32 %135 to i64
  %137 = getelementptr i64, ptr %p2c.q209, i64 %136
  %p2c.qo130 = load i64, ptr %137, align 8
  %138 = add i32 %p2c.qi, 6
  %139 = sext i32 %138 to i64
  %140 = getelementptr i64, ptr %p2c.q209, i64 %139
  %p2c.qo131 = load i64, ptr %140, align 8
  %141 = add i32 %p2c.qi, 9
  %142 = sext i32 %141 to i64
  %143 = getelementptr i64, ptr %p2c.q209, i64 %142
  %p2c.qo132 = load i64, ptr %143, align 8
  %144 = add i32 %p2c.qi, 12
  %145 = sext i32 %144 to i64
  %146 = getelementptr i64, ptr %p2c.q209, i64 %145
  %p2c.qo133 = load i64, ptr %146, align 8
  %147 = add i32 %p2c.qi, 15
  %148 = sext i32 %147 to i64
  %149 = getelementptr i64, ptr %p2c.q209, i64 %148
  %p2c.qo134 = load i64, ptr %149, align 8
  store i64 %p2c.q136, ptr %132, align 8
  %150 = and i32 %sel.88, 8
  %.not217 = icmp eq i32 %150, 0
  %151 = add i64 %imad_tmp_64.22, %129
  %p2c.q138 = select i1 %.not217, i64 0, i64 %151
  %152 = add i32 %p2c.qi, 3
  %153 = sext i32 %152 to i64
  %154 = getelementptr i64, ptr %p2c.q209, i64 %153
  store i64 %p2c.q138, ptr %154, align 8
  %155 = and i32 %sel.88, 2
  %.not218 = icmp eq i32 %155, 0
  %156 = add i64 %imad_tmp_64.20, %129
  %p2c.q140 = select i1 %.not218, i64 0, i64 %156
  %157 = add i32 %p2c.qi, 6
  %158 = sext i32 %157 to i64
  %159 = getelementptr i64, ptr %p2c.q209, i64 %158
  store i64 %p2c.q140, ptr %159, align 8
  %160 = and i32 %sel.88, 4
  %.not219 = icmp eq i32 %160, 0
  %161 = add i64 %imad_tmp_64.21, %129
  %p2c.q142 = select i1 %.not219, i64 0, i64 %161
  %162 = add i32 %p2c.qi, 9
  %163 = sext i32 %162 to i64
  %164 = getelementptr i64, ptr %p2c.q209, i64 %163
  store i64 %p2c.q142, ptr %164, align 8
  %r2p_p0.3 = trunc i32 %sel.89 to i1
  %165 = add i64 %imad_tmp_64.23, %128
  %p2c.q144 = select i1 %r2p_p0.3, i64 %165, i64 0
  %166 = add i32 %p2c.qi, 12
  %167 = sext i32 %166 to i64
  %168 = getelementptr i64, ptr %p2c.q209, i64 %167
  store i64 %p2c.q144, ptr %168, align 8
  %169 = and i32 %sel.89, 2
  %.not220 = icmp eq i32 %169, 0
  %170 = add i64 %imad_tmp_64.24, %128
  %p2c.q146 = select i1 %.not220, i64 0, i64 %170
  %171 = add i32 %p2c.qi, 15
  %172 = sext i32 %171 to i64
  %173 = getelementptr i64, ptr %p2c.q209, i64 %172
  store i64 %p2c.q146, ptr %173, align 8
  %lo.lane = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %lo.t = and i32 %lo.lane, 3
  %lo.g = lshr i32 %lo.lane, 2
  %174 = and i32 %lo.lane, 2
  %lo.th.not = icmp eq i32 %174, 0
  %175 = shl nuw nsw i32 %174, 3
  %176 = or i32 %175, %lo.g
  %lo.shfl243 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff, i32 %176, i32 31) #8
  %177 = shl i32 %lo.lane, 3
  %lo.t8 = and i32 %177, 8
  %178 = add i32 %lo.shfl243, %lo.t8
  %179 = sext i32 %178 to i64
  %180 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %179
  %181 = load volatile float, ptr addrspace(3) %180, align 4
  %182 = add i32 %lo.shfl243, %lo.t8
  %183 = sext i32 %182 to i64
  %184 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %183
  %185 = getelementptr i8, ptr addrspace(3) %184, i64 4
  %186 = load volatile float, ptr addrspace(3) %185, align 4
  %lo.shfl245 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1895, i32 %176, i32 31) #8
  %187 = add i32 %lo.shfl245, %lo.t8
  %188 = sext i32 %187 to i64
  %189 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %188
  %190 = load volatile float, ptr addrspace(3) %189, align 4
  %191 = add i32 %lo.shfl245, %lo.t8
  %192 = sext i32 %191 to i64
  %193 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %192
  %194 = getelementptr i8, ptr addrspace(3) %193, i64 4
  %195 = load volatile float, ptr addrspace(3) %194, align 4
  %196 = select i1 %lo.th.not, i32 8, i32 24
  %197 = or i32 %196, %lo.g
  %lo.shfl244 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff, i32 %197, i32 31) #8
  %198 = add i32 %lo.shfl244, %lo.t8
  %199 = sext i32 %198 to i64
  %200 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %199
  %201 = load volatile float, ptr addrspace(3) %200, align 4
  %202 = add i32 %lo.shfl244, %lo.t8
  %203 = sext i32 %202 to i64
  %204 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %203
  %205 = getelementptr i8, ptr addrspace(3) %204, i64 4
  %206 = load volatile float, ptr addrspace(3) %205, align 4
  %lo.shfl246 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1895, i32 %197, i32 31) #8
  %207 = add i32 %lo.shfl246, %lo.t8
  %208 = sext i32 %207 to i64
  %209 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %208
  %210 = load volatile float, ptr addrspace(3) %209, align 4
  %211 = add i32 %lo.shfl246, %lo.t8
  %212 = sext i32 %211 to i64
  %213 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %212
  %214 = getelementptr i8, ptr addrspace(3) %213, i64 4
  %215 = load volatile float, ptr addrspace(3) %214, align 4
  %216 = shl nuw nsw i32 %174, 2
  %217 = shl nuw nsw i32 %lo.g, 1
  %218 = and i32 %217, 6
  %219 = lshr i32 %lo.lane, 4
  %lo.rho = or i32 %218, %219
  %220 = or i32 %216, %lo.rho
  %lo.shfl = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff237, i32 %220, i32 31) #8
  %221 = add i32 %lo.shfl, %lo.t8
  %222 = sext i32 %221 to i64
  %223 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %222
  %224 = load volatile float, ptr addrspace(3) %223, align 4
  %225 = select i1 %lo.th.not, i32 16, i32 24
  %226 = or i32 %225, %lo.rho
  %lo.shfl240 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff237, i32 %226, i32 31) #8
  %227 = shl nuw nsw i32 %lo.rho, 2
  %lo.bsrc = or disjoint i32 %227, %lo.t
  %228 = add i32 %lo.shfl240, %lo.t8
  %229 = sext i32 %228 to i64
  %230 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %229
  %231 = load volatile float, ptr addrspace(3) %230, align 4
  %232 = add i32 %lo.shfl, %lo.t8
  %233 = sext i32 %232 to i64
  %234 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %233
  %235 = getelementptr i8, ptr addrspace(3) %234, i64 4
  %236 = load volatile float, ptr addrspace(3) %235, align 4
  %237 = add i32 %lo.shfl240, %lo.t8
  %238 = sext i32 %237 to i64
  %239 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %238
  %240 = getelementptr i8, ptr addrspace(3) %239, i64 4
  %241 = load volatile float, ptr addrspace(3) %240, align 4
  %lo.shfl247 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1909, i32 %220, i32 31) #8
  %242 = add i32 %lo.shfl247, %lo.t8
  %243 = sext i32 %242 to i64
  %244 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %243
  %245 = getelementptr i8, ptr addrspace(3) %244, i64 8192
  %246 = load volatile float, ptr addrspace(3) %245, align 4
  %lo.shfl248 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1909, i32 %226, i32 31) #8
  %247 = add i32 %lo.shfl248, %lo.t8
  %248 = sext i32 %247 to i64
  %249 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %248
  %250 = getelementptr i8, ptr addrspace(3) %249, i64 8192
  %251 = load volatile float, ptr addrspace(3) %250, align 4
  %252 = add i32 %lo.shfl247, %lo.t8
  %253 = sext i32 %252 to i64
  %254 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %253
  %255 = getelementptr i8, ptr addrspace(3) %254, i64 8196
  %256 = load volatile float, ptr addrspace(3) %255, align 4
  %257 = add i32 %lo.shfl248, %lo.t8
  %258 = sext i32 %257 to i64
  %259 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %258
  %260 = getelementptr i8, ptr addrspace(3) %259, i64 8196
  %261 = load volatile float, ptr addrspace(3) %260, align 4
  %lo.w = call { float, float, float, float, float, float, float, float } @lo.wmma(ptr nonnull %lo.frag, float %181, float %186, float %190, float %195, float %201, float %206, float %210, float %215, float %224, float %231, float %236, float %241, float %246, float %251, float %256, float %261, float %phi.216, float %phi.214, float %phi.203, float %phi.202, float %phi.209, float %phi.204, float %phi.238, float %phi.237) #8
  %262 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 0
  %263 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 1
  %264 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 4
  %265 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 5
  %266 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 2
  %267 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 3
  %268 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 6
  %269 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 7
  %lo.shfl249 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %122, i32 %176, i32 31) #8
  %270 = add i32 %lo.shfl249, %lo.t8
  %271 = sext i32 %270 to i64
  %272 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %271
  %273 = load volatile float, ptr addrspace(3) %272, align 4
  %274 = add i32 %lo.shfl249, %lo.t8
  %275 = sext i32 %274 to i64
  %276 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %275
  %277 = getelementptr i8, ptr addrspace(3) %276, i64 4
  %278 = load volatile float, ptr addrspace(3) %277, align 4
  %lo.shfl253 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1951, i32 %lo.g, i32 31) #8
  %lo.shfl257 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1965, i32 %lo.g, i32 31) #8
  %lo.t4 = shl nuw nsw i32 %lo.t, 2
  %279 = add i32 %lo.shfl257, %lo.t4
  %280 = sext i32 %279 to i64
  %281 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %280
  %282 = getelementptr i8, ptr addrspace(3) %281, i64 8192
  %283 = load float, ptr addrspace(3) %282, align 4
  %284 = bitcast float %283 to i32
  %285 = bitcast float %283 to i32
  %286 = bitcast float %283 to i32
  %lo.shfl286 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %286, i32 %lo.bsrc, i32 31) #8
  %287 = bitcast i32 %lo.shfl286 to float
  %lo.shfl280 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %285, i32 %lo.bsrc, i32 31) #8
  %288 = bitcast i32 %lo.shfl280 to float
  %289 = add i32 %lo.shfl253, %lo.t4
  %290 = sext i32 %289 to i64
  %291 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %290
  %292 = load volatile float, ptr addrspace(3) %291, align 4
  %293 = or i32 %lo.g, 16
  %lo.shfl255 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1951, i32 %293, i32 31) #8
  %lo.shfl259 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1965, i32 %293, i32 31) #8
  %294 = add i32 %lo.shfl259, %lo.t4
  %295 = sext i32 %294 to i64
  %296 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %295
  %297 = getelementptr i8, ptr addrspace(3) %296, i64 8192
  %298 = load float, ptr addrspace(3) %297, align 4
  %299 = bitcast float %298 to i32
  %300 = bitcast float %298 to i32
  %lo.shfl287 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %300, i32 %lo.bsrc, i32 31) #8
  %301 = bitcast i32 %lo.shfl287 to float
  %lo.shfl281 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %299, i32 %lo.bsrc, i32 31) #8
  %302 = bitcast i32 %lo.shfl281 to float
  %303 = add i32 %lo.shfl255, %lo.t4
  %304 = sext i32 %303 to i64
  %305 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %304
  %306 = load volatile float, ptr addrspace(3) %305, align 4
  %lo.shfl250 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %122, i32 %197, i32 31) #8
  %307 = add i32 %lo.shfl250, %lo.t8
  %308 = sext i32 %307 to i64
  %309 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %308
  %310 = load volatile float, ptr addrspace(3) %309, align 4
  %311 = add i32 %lo.shfl250, %lo.t8
  %312 = sext i32 %311 to i64
  %313 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %312
  %314 = getelementptr i8, ptr addrspace(3) %313, i64 4
  %315 = load volatile float, ptr addrspace(3) %314, align 4
  %316 = or i32 %lo.g, 8
  %lo.shfl254 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1951, i32 %316, i32 31) #8
  %lo.shfl258 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1965, i32 %316, i32 31) #8
  %317 = add i32 %lo.shfl258, %lo.t4
  %318 = sext i32 %317 to i64
  %319 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %318
  %320 = getelementptr i8, ptr addrspace(3) %319, i64 8192
  %321 = load float, ptr addrspace(3) %320, align 4
  %322 = bitcast float %321 to i32
  %323 = bitcast float %321 to i32
  %lo.shfl288 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %323, i32 %lo.bsrc, i32 31) #8
  %324 = bitcast i32 %lo.shfl288 to float
  %lo.shfl282 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %322, i32 %lo.bsrc, i32 31) #8
  %325 = bitcast i32 %lo.shfl282 to float
  %326 = add i32 %lo.shfl254, %lo.t4
  %327 = sext i32 %326 to i64
  %328 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %327
  %329 = load volatile float, ptr addrspace(3) %328, align 4
  %330 = or i32 %lo.g, 24
  %lo.shfl256 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1951, i32 %330, i32 31) #8
  %lo.shfl260 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1965, i32 %330, i32 31) #8
  %331 = add i32 %lo.shfl260, %lo.t4
  %332 = sext i32 %331 to i64
  %333 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %332
  %334 = getelementptr i8, ptr addrspace(3) %333, i64 8192
  %335 = load float, ptr addrspace(3) %334, align 4
  %336 = bitcast float %335 to i32
  %337 = bitcast float %335 to i32
  %lo.shfl289 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %337, i32 %lo.bsrc, i32 31) #8
  %338 = bitcast i32 %lo.shfl289 to float
  %lo.shfl283 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %336, i32 %lo.bsrc, i32 31) #8
  %339 = bitcast i32 %lo.shfl283 to float
  %340 = add i32 %lo.shfl256, %lo.t4
  %341 = sext i32 %340 to i64
  %342 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %341
  %343 = load volatile float, ptr addrspace(3) %342, align 4
  %lo.shfl251 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1937, i32 %220, i32 31) #8
  %lo.shfl252 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.1937, i32 %226, i32 31) #8
  %344 = add i32 %lo.shfl251, %lo.t8
  %345 = sext i32 %344 to i64
  %346 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %345
  %347 = getelementptr i8, ptr addrspace(3) %346, i64 8192
  %348 = load volatile float, ptr addrspace(3) %347, align 4
  %349 = add i32 %lo.shfl252, %lo.t8
  %350 = sext i32 %349 to i64
  %351 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %350
  %352 = getelementptr i8, ptr addrspace(3) %351, i64 8192
  %353 = load volatile float, ptr addrspace(3) %352, align 4
  %354 = add i32 %lo.shfl251, %lo.t8
  %355 = sext i32 %354 to i64
  %356 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %355
  %357 = getelementptr i8, ptr addrspace(3) %356, i64 8196
  %358 = load volatile float, ptr addrspace(3) %357, align 4
  %359 = add i32 %lo.shfl252, %lo.t8
  %360 = sext i32 %359 to i64
  %361 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %360
  %362 = getelementptr i8, ptr addrspace(3) %361, i64 8196
  %363 = load volatile float, ptr addrspace(3) %362, align 4
  %lo.w284 = call { float, float, float, float, float, float, float, float } @lo.wmma(ptr nonnull %lo.frag, float %273, float %278, float %292, float %306, float %310, float %315, float %329, float %343, float %348, float %353, float %358, float %363, float %288, float %302, float %325, float %339, float %262, float %263, float %266, float %267, float %264, float %265, float %268, float %269) #8
  %364 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 0
  %365 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 1
  %366 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 4
  %367 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 5
  %368 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 2
  %369 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 3
  %370 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 6
  %371 = extractvalue { float, float, float, float, float, float, float, float } %lo.w284, 7
  %lo.shfl241 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff236, i32 %176, i32 31) #8
  %lo.shfl242 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff236, i32 %197, i32 31) #8
  %372 = add i32 %lo.shfl241, %lo.t8
  %373 = sext i32 %372 to i64
  %374 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %373
  %375 = load volatile float, ptr addrspace(3) %374, align 4
  %376 = add i32 %lo.shfl241, %lo.t8
  %377 = sext i32 %376 to i64
  %378 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %377
  %379 = getelementptr i8, ptr addrspace(3) %378, i64 4
  %380 = load volatile float, ptr addrspace(3) %379, align 4
  %381 = add i32 %lo.shfl245, %lo.t8
  %382 = sext i32 %381 to i64
  %383 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %382
  %384 = getelementptr i8, ptr addrspace(3) %383, i64 4096
  %385 = load volatile float, ptr addrspace(3) %384, align 4
  %386 = add i32 %lo.shfl245, %lo.t8
  %387 = sext i32 %386 to i64
  %388 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %387
  %389 = getelementptr i8, ptr addrspace(3) %388, i64 4100
  %390 = load volatile float, ptr addrspace(3) %389, align 4
  %391 = add i32 %lo.shfl242, %lo.t8
  %392 = sext i32 %391 to i64
  %393 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %392
  %394 = load volatile float, ptr addrspace(3) %393, align 4
  %395 = add i32 %lo.shfl242, %lo.t8
  %396 = sext i32 %395 to i64
  %397 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %396
  %398 = getelementptr i8, ptr addrspace(3) %397, i64 4
  %399 = load volatile float, ptr addrspace(3) %398, align 4
  %400 = add i32 %lo.shfl246, %lo.t8
  %401 = sext i32 %400 to i64
  %402 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %401
  %403 = getelementptr i8, ptr addrspace(3) %402, i64 4096
  %404 = load volatile float, ptr addrspace(3) %403, align 4
  %405 = add i32 %lo.shfl246, %lo.t8
  %406 = sext i32 %405 to i64
  %407 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %406
  %408 = getelementptr i8, ptr addrspace(3) %407, i64 4100
  %409 = load volatile float, ptr addrspace(3) %408, align 4
  %410 = add i32 %lo.shfl, %lo.t8
  %411 = sext i32 %410 to i64
  %412 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %411
  %413 = load volatile float, ptr addrspace(3) %412, align 4
  %414 = add i32 %lo.shfl240, %lo.t8
  %415 = sext i32 %414 to i64
  %416 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %415
  %417 = load volatile float, ptr addrspace(3) %416, align 4
  %418 = add i32 %lo.shfl, %lo.t8
  %419 = sext i32 %418 to i64
  %420 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %419
  %421 = getelementptr i8, ptr addrspace(3) %420, i64 4
  %422 = load volatile float, ptr addrspace(3) %421, align 4
  %423 = add i32 %lo.shfl240, %lo.t8
  %424 = sext i32 %423 to i64
  %425 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %424
  %426 = getelementptr i8, ptr addrspace(3) %425, i64 4
  %427 = load volatile float, ptr addrspace(3) %426, align 4
  %428 = add i32 %lo.shfl247, %lo.t8
  %429 = sext i32 %428 to i64
  %430 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %429
  %431 = getelementptr i8, ptr addrspace(3) %430, i64 8192
  %432 = load volatile float, ptr addrspace(3) %431, align 4
  %433 = add i32 %lo.shfl248, %lo.t8
  %434 = sext i32 %433 to i64
  %435 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %434
  %436 = getelementptr i8, ptr addrspace(3) %435, i64 8192
  %437 = load volatile float, ptr addrspace(3) %436, align 4
  %438 = add i32 %lo.shfl247, %lo.t8
  %439 = sext i32 %438 to i64
  %440 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %439
  %441 = getelementptr i8, ptr addrspace(3) %440, i64 8196
  %442 = load volatile float, ptr addrspace(3) %441, align 4
  %443 = add i32 %lo.shfl248, %lo.t8
  %444 = sext i32 %443 to i64
  %445 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %444
  %446 = getelementptr i8, ptr addrspace(3) %445, i64 8196
  %447 = load volatile float, ptr addrspace(3) %446, align 4
  %lo.w285 = call { float, float, float, float, float, float, float, float } @lo.wmma(ptr nonnull %lo.frag, float %375, float %380, float %385, float %390, float %394, float %399, float %404, float %409, float %413, float %417, float %422, float %427, float %432, float %437, float %442, float %447, float %phi.236, float %phi.235, float %phi.232, float %phi.231, float %phi.234, float %phi.233, float %phi.230, float %phi.229) #8
  %448 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 0
  %449 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 1
  %450 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 4
  %451 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 5
  %452 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 2
  %453 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 3
  %454 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 6
  %455 = extractvalue { float, float, float, float, float, float, float, float } %lo.w285, 7
  %456 = add i32 %lo.shfl249, %lo.t8
  %457 = sext i32 %456 to i64
  %458 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %457
  %459 = getelementptr i8, ptr addrspace(3) %458, i64 4096
  %460 = load volatile float, ptr addrspace(3) %459, align 4
  %461 = add i32 %lo.shfl249, %lo.t8
  %462 = sext i32 %461 to i64
  %463 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %462
  %464 = getelementptr i8, ptr addrspace(3) %463, i64 4100
  %465 = load volatile float, ptr addrspace(3) %464, align 4
  %466 = add i32 %lo.shfl253, %lo.t4
  %467 = sext i32 %466 to i64
  %468 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %467
  %469 = getelementptr i8, ptr addrspace(3) %468, i64 4096
  %470 = load volatile float, ptr addrspace(3) %469, align 4
  %471 = add i32 %lo.shfl255, %lo.t4
  %472 = sext i32 %471 to i64
  %473 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %472
  %474 = getelementptr i8, ptr addrspace(3) %473, i64 4096
  %475 = load volatile float, ptr addrspace(3) %474, align 4
  %476 = add i32 %lo.shfl250, %lo.t8
  %477 = sext i32 %476 to i64
  %478 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %477
  %479 = getelementptr i8, ptr addrspace(3) %478, i64 4096
  %480 = load volatile float, ptr addrspace(3) %479, align 4
  %481 = add i32 %lo.shfl250, %lo.t8
  %482 = sext i32 %481 to i64
  %483 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %482
  %484 = getelementptr i8, ptr addrspace(3) %483, i64 4100
  %485 = load volatile float, ptr addrspace(3) %484, align 4
  %486 = add i32 %lo.shfl254, %lo.t4
  %487 = sext i32 %486 to i64
  %488 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %487
  %489 = getelementptr i8, ptr addrspace(3) %488, i64 4096
  %490 = load volatile float, ptr addrspace(3) %489, align 4
  %491 = add i32 %lo.shfl256, %lo.t4
  %492 = add i32 %lo.shfl253, %lo.t4
  %493 = sext i32 %492 to i64
  %494 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %493
  %495 = getelementptr i8, ptr addrspace(3) %494, i64 4096
  %496 = load i32, ptr addrspace(3) %495, align 4
  %497 = sext i32 %491 to i64
  %498 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %497
  %499 = getelementptr i8, ptr addrspace(3) %498, i64 4096
  %500 = load volatile float, ptr addrspace(3) %499, align 4
  %501 = add i32 %lo.shfl251, %lo.t8
  %502 = sext i32 %501 to i64
  %503 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %502
  %504 = getelementptr i8, ptr addrspace(3) %503, i64 8192
  %505 = load volatile float, ptr addrspace(3) %504, align 4
  %506 = add i32 %lo.shfl252, %lo.t8
  %507 = sext i32 %506 to i64
  %508 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %507
  %509 = getelementptr i8, ptr addrspace(3) %508, i64 8192
  %510 = load volatile float, ptr addrspace(3) %509, align 4
  %511 = add i32 %lo.shfl251, %lo.t8
  %512 = add i32 %lo.shfl252, %lo.t8
  %513 = sext i32 %512 to i64
  %514 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %513
  %515 = getelementptr i8, ptr addrspace(3) %514, i64 8196
  %516 = load volatile float, ptr addrspace(3) %515, align 4
  %517 = sext i32 %511 to i64
  %518 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %517
  %519 = getelementptr i8, ptr addrspace(3) %518, i64 8196
  %520 = load volatile float, ptr addrspace(3) %519, align 4
  %lo.w290 = call { float, float, float, float, float, float, float, float } @lo.wmma(ptr nonnull %lo.frag, float %460, float %465, float %470, float %475, float %480, float %485, float %490, float %500, float %505, float %510, float %520, float %516, float %287, float %301, float %324, float %338, float %448, float %449, float %452, float %453, float %450, float %451, float %454, float %455) #8
  %521 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 0
  %522 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 1
  %523 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 4
  %524 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 5
  %525 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 2
  %526 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 3
  %527 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 6
  %528 = extractvalue { float, float, float, float, float, float, float, float } %lo.w290, 7
  call void @llvm.nvvm.barrier0()
  %529 = zext nneg i32 %125 to i64
  %p2c.sm191 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %529
  %p2c.smp192 = ptrtoint ptr addrspace(3) %p2c.sm191 to i64
  %.not221 = icmp eq i64 %p2c.qo, 0
  %p2c.sz193 = select i1 %.not221, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp192, i64 %p2c.qo, i32 %p2c.sz193) #10
  %530 = zext nneg i32 %p2c.f137 to i64
  %p2c.sm194 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %530
  %p2c.smp195 = ptrtoint ptr addrspace(3) %p2c.sm194 to i64
  %.not222 = icmp eq i64 %p2c.qo130, 0
  %p2c.sz196 = select i1 %.not222, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp195, i64 %p2c.qo130, i32 %p2c.sz196) #10
  %531 = zext nneg i32 %p2c.f139 to i64
  %p2c.sm197 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %531
  %p2c.smp198 = ptrtoint ptr addrspace(3) %p2c.sm197 to i64
  %.not223 = icmp eq i64 %p2c.qo131, 0
  %p2c.sz199 = select i1 %.not223, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp198, i64 %p2c.qo131, i32 %p2c.sz199) #10
  %532 = zext nneg i32 %p2c.f141 to i64
  %p2c.sm200 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %532
  %p2c.smp201 = ptrtoint ptr addrspace(3) %p2c.sm200 to i64
  %.not224 = icmp eq i64 %p2c.qo132, 0
  %p2c.sz202 = select i1 %.not224, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp201, i64 %p2c.qo132, i32 %p2c.sz202) #10
  %533 = zext i32 %p2c.f143 to i64
  %p2c.sm203 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %533
  %p2c.smp204 = ptrtoint ptr addrspace(3) %p2c.sm203 to i64
  %.not225 = icmp eq i64 %p2c.qo133, 0
  %p2c.sz205 = select i1 %.not225, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp204, i64 %p2c.qo133, i32 %p2c.sz205) #10
  %534 = zext i32 %p2c.f145 to i64
  %p2c.sm206 = getelementptr [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %534
  %p2c.smp207 = ptrtoint ptr addrspace(3) %p2c.sm206 to i64
  %.not226 = icmp eq i64 %p2c.qo134, 0
  %p2c.sz208 = select i1 %.not226, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp207, i64 %p2c.qo134, i32 %p2c.sz208) #10
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.128 = icmp slt i32 %phi.199, 16384
  %phi.240.v = select i1 %isetrp_cmp1.128, i32 4096, i32 -16384
  %phi.240 = add i32 %phi.199, %phi.240.v
  %isetrp_cmp1.127 = icmp slt i32 %phi.198, 32768
  %phi.239.v = select i1 %isetrp_cmp1.127, i32 8192, i32 -32768
  %phi.239 = add i32 %phi.198, %phi.239.v
  %isetrp_cmp1.131 = icmp slt i32 %phi.201, 16384
  %phi.242.v = select i1 %isetrp_cmp1.131, i32 4096, i32 -16384
  %phi.242 = add i32 %phi.201, %phi.242.v
  %isetrp_cmp1.130 = icmp slt i32 %phi.200, 32768
  %phi.241.v = select i1 %isetrp_cmp1.130, i32 8192, i32 -32768
  %phi.241 = add i32 %phi.200, %phi.241.v
  %.2000 = getelementptr inbounds nuw i8, ptr %param_local, i64 1588
  %isetrp_rhs.82 = load i32, ptr %.2000, align 4
  %isetrp_cmp1.132 = icmp sgt i32 %phi.205, %isetrp_rhs.82
  %iadd3_o2_64.6 = and i64 %128, 4294967295
  %iadd3_o1_64.7 = and i64 %imad_tmp_64.24, 4294967294
  %iadd3_tmp.7 = add nuw nsw i64 %iadd3_o1_64.7, %iadd3_o2_64.6
  %carry_ge_1.7 = icmp samesign ugt i64 %iadd3_tmp.7, 4294967295
  %imad_tmp.196 = shl i32 %phi.210, 3
  %isetrp_cmp1.133 = icmp ne i32 %iadd3_n1.81, %phi.210
  %iadd3_n1.121 = add i32 %phi.210, 1
  %sel.90 = select i1 %isetrp_cmp1.133, i32 %iadd3_n1.121, i32 0
  %ldc_idx.2 = add i32 %imad_tmp.196, 1032
  %ldc_const_off_zext.2 = zext i32 %ldc_idx.2 to i64
  %.2009 = getelementptr inbounds nuw [1840 x i8], ptr %param_local, i64 0, i64 %ldc_const_off_zext.2
  %ldc_const.13 = load i64, ptr %.2009, align 8
  %ldc_idx.3 = add i32 %imad_tmp.196, 1288
  %ldc_const_off_zext.3 = zext i32 %ldc_idx.3 to i64
  %.2018 = getelementptr inbounds nuw [1840 x i8], ptr %param_local, i64 0, i64 %ldc_const_off_zext.3
  %ldc_const.14 = load i64, ptr %.2018, align 8
  %.2013 = zext i32 %spec.select85 to i64
  %shf_shift_64.41 = zext nneg i32 %sel.90 to i64
  %.2016 = shl i64 %.2013, %shf_shift_64.41
  %phi.243.in = select i1 %isetrp_cmp1.126, i64 %.2016, i64 %iadd3_tmp.7
  %phi.243 = trunc i64 %phi.243.in to i32
  %.2025 = and i32 %phi.151, %phi.243
  %lop3_pred_cmp.12 = icmp ne i32 %.2025, 0
  %phi.244.in = select i1 %isetrp_cmp1.126, i1 %lop3_pred_cmp.12, i1 %isetrp_cmp1.133
  br i1 %isetrp_cmp1.126, label %BB_80003830, label %BB_3850

BB_80003830:                                      ; preds = %BB_3370
  %.2036 = and i32 %phi.152, %phi.243
  %lop3_pred_cmp.13.not = icmp eq i32 %.2036, 0
  %.2044 = and i32 %phi.153, %phi.243
  %lop3_pred_cmp.14 = icmp ne i32 %.2044, 0
  %535 = select i1 %lop3_pred_cmp.13.not, i32 0, i32 2
  br label %BB_3850

BB_3850:                                          ; preds = %BB_80003830, %BB_3370
  %phi.245.in = phi i1 [ %lop3_pred_cmp.14, %BB_80003830 ], [ %carry_ge_1.7, %BB_3370 ]
  %phi.246 = phi i32 [ %535, %BB_80003830 ], [ %169, %BB_3370 ]
  br i1 %isetrp_cmp1.126, label %BB_80003880, label %BB_3890

BB_80003880:                                      ; preds = %BB_3850
  %.2055 = and i32 %phi.154, %phi.243
  %lop3_pred_cmp.15.not = icmp eq i32 %.2055, 0
  %p2r_p0_i32.3 = zext i1 %phi.244.in to i32
  %p2r_or_1.3 = or disjoint i32 %phi.246, %p2r_p0_i32.3
  %p2r_p2_shl.2 = select i1 %phi.245.in, i32 4, i32 0
  %p2r_or_2.2 = or disjoint i32 %p2r_or_1.3, %p2r_p2_shl.2
  %p2r_p3_shl.2 = select i1 %lop3_pred_cmp.15.not, i32 0, i32 8
  %p2r_or_3.2 = or disjoint i32 %p2r_or_2.2, %p2r_p3_shl.2
  br label %BB_3890

BB_3890:                                          ; preds = %BB_80003880, %BB_3850
  %phi.248 = phi i32 [ %p2r_or_3.2, %BB_80003880 ], [ %sel.88, %BB_3850 ]
  %isetrp_cmp1.135 = icmp slt i32 %iadd3_n1.16, %imad_tmp.6
  %isetrp_cmp2.135 = or i1 %isetrp_cmp1.135, %isetrp_cmp1.132
  %sel.92 = select i1 %isetrp_cmp2.135, i32 %phi.248, i32 0
  %isetrp_cmp1.134 = icmp slt i32 %iadd3_n1.86, %imad_tmp.6
  %isetrp_cmp2.134 = or i1 %isetrp_cmp1.134, %isetrp_cmp1.132
  %sel.91 = select i1 %isetrp_cmp2.134, i32 %sel.89, i32 0
  %536 = add i64 %ldc_const.13, %129
  %iadd3_n1.124 = add i32 %phi.205, -1
  %isetrp_cmp1.136 = icmp sgt i32 %phi.205, 0
  %537 = add i64 %ldc_const.14, %128
  %538 = add i32 %p2c.qi, 1
  %539 = icmp eq i32 %538, 3
  %540 = select i1 %539, i32 0, i32 %538
  br i1 %isetrp_cmp1.136, label %BB_3370, label %BB_3970.loopexit

BB_3970.loopexit:                                 ; preds = %BB_3890
  br label %BB_3970

BB_3970:                                          ; preds = %BB_3970.loopexit, %BB_30f0
  %lo.fragoff239 = phi i32 [ %p2c.f153, %BB_30f0 ], [ %p2c.f126, %BB_3970.loopexit ]
  %lo.fragoff238 = phi i32 [ %ldsm_shared_winoff, %BB_30f0 ], [ %123, %BB_3970.loopexit ]
  %phi.249 = phi i32 [ 0, %BB_30f0 ], [ %phi.239, %BB_3970.loopexit ]
  %phi.250 = phi float [ 0.000000e+00, %BB_30f0 ], [ %369, %BB_3970.loopexit ]
  %phi.251 = phi float [ 0.000000e+00, %BB_30f0 ], [ %368, %BB_3970.loopexit ]
  %phi.252 = phi float [ 0.000000e+00, %BB_30f0 ], [ %367, %BB_3970.loopexit ]
  %phi.253 = phi float [ 0.000000e+00, %BB_30f0 ], [ %366, %BB_3970.loopexit ]
  %phi.254 = phi float [ 0.000000e+00, %BB_30f0 ], [ %365, %BB_3970.loopexit ]
  %phi.255 = phi i32 [ %phi.64, %BB_30f0 ], [ %.1895, %BB_3970.loopexit ]
  %phi.256 = phi i32 [ %phi.125, %BB_30f0 ], [ %496, %BB_3970.loopexit ]
  %phi.257 = phi float [ 0.000000e+00, %BB_30f0 ], [ %364, %BB_3970.loopexit ]
  %phi.258 = phi i32 [ %phi.190, %BB_30f0 ], [ %284, %BB_3970.loopexit ]
  %phi.263 = phi float [ 0.000000e+00, %BB_30f0 ], [ %528, %BB_3970.loopexit ]
  %phi.264 = phi float [ 0.000000e+00, %BB_30f0 ], [ %527, %BB_3970.loopexit ]
  %phi.265 = phi float [ 0.000000e+00, %BB_30f0 ], [ %526, %BB_3970.loopexit ]
  %phi.266 = phi float [ 0.000000e+00, %BB_30f0 ], [ %525, %BB_3970.loopexit ]
  %phi.267 = phi float [ 0.000000e+00, %BB_30f0 ], [ %524, %BB_3970.loopexit ]
  %phi.268 = phi float [ 0.000000e+00, %BB_30f0 ], [ %523, %BB_3970.loopexit ]
  %phi.269 = phi float [ 0.000000e+00, %BB_30f0 ], [ %522, %BB_3970.loopexit ]
  %phi.270 = phi float [ 0.000000e+00, %BB_30f0 ], [ %521, %BB_3970.loopexit ]
  %phi.271 = phi float [ 0.000000e+00, %BB_30f0 ], [ %371, %BB_3970.loopexit ]
  %phi.272 = phi float [ 0.000000e+00, %BB_30f0 ], [ %370, %BB_3970.loopexit ]
  %lo.lane261 = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %lo.g262 = lshr i32 %lo.lane261, 2
  %lo.t263 = shl i32 %lo.lane261, 2
  %lo.t4269 = and i32 %lo.t263, 12
  %541 = or i32 %lo.g262, 24
  %542 = or i32 %lo.g262, 16
  %543 = or i32 %lo.g262, 8
  %lo.shfl272 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff239, i32 %lo.g262, i32 31) #8
  %lo.shfl273 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff239, i32 %543, i32 31) #8
  %544 = add i32 %lo.shfl273, %lo.t4269
  %545 = sext i32 %544 to i64
  %546 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %545
  %547 = load i32, ptr addrspace(3) %546, align 4
  %lo.shfl274 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff239, i32 %542, i32 31) #8
  %lo.shfl275 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff239, i32 %541, i32 31) #8
  %lo.shfl276 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff238, i32 %lo.g262, i32 31) #8
  %lo.shfl277 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff238, i32 %543, i32 31) #8
  %lo.shfl278 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff238, i32 %542, i32 31) #8
  %548 = add i32 %lo.shfl278, %lo.t4269
  %549 = sext i32 %548 to i64
  %550 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %549
  %551 = load i32, ptr addrspace(3) %550, align 4
  %lo.shfl279 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff238, i32 %541, i32 31) #8
  %.2069 = getelementptr inbounds nuw i8, ptr %param_local, i64 808
  %isetrp_rhs.83 = load i32, ptr %.2069, align 4
  %isetrp_cmp1.137.not = icmp eq i32 %isetrp_rhs.83, 0
  %.2071 = getelementptr inbounds nuw i8, ptr %param_local, i64 812
  %ldc_const.15 = load i8, ptr %.2071, align 1
  %imad_tmp.199 = shl i32 %tid_x, 3
  %.2096 = getelementptr inbounds nuw i8, ptr %param_local, i64 828
  %ldc_const.16 = load i32, ptr %.2096, align 4
  br i1 %isetrp_cmp1.137.not, label %BB_3a50, label %BB_800039f0

BB_800039f0:                                      ; preds = %BB_3970
  %.2100 = getelementptr inbounds nuw i8, ptr %param_local, i64 392
  %imad_addend.31 = load i32, ptr %.2100, align 4
  %.2102 = getelementptr inbounds nuw i8, ptr %param_local, i64 400
  %imad_addend.32 = load i32, ptr %.2102, align 4
  %.2104 = getelementptr inbounds nuw i8, ptr %param_local, i64 396
  %imad_addend.33 = load i32, ptr %.2104, align 4
  %.2106 = getelementptr inbounds nuw i8, ptr %param_local, i64 404
  %imad_addend.34 = load i32, ptr %.2106, align 4
  %ldg_addr_r0_ext = zext i32 %imad_addend.31 to i64
  %ldg_addr_r1_ext = zext i32 %imad_addend.33 to i64
  %ldg_addr_r1_shift = shl nuw i64 %ldg_addr_r1_ext, 32
  %ldg_addr_packed_1 = or disjoint i64 %ldg_addr_r1_shift, %ldg_addr_r0_ext
  %"R659:R631_addr_ptr" = inttoptr i64 %ldg_addr_packed_1 to ptr addrspace(1)
  %ldg = load i32, ptr addrspace(1) %"R659:R631_addr_ptr", align 4
  %ldg_addr_r0_ext.1 = zext i32 %imad_addend.32 to i64
  %ldg_addr_r1_ext.1 = zext i32 %imad_addend.34 to i64
  %ldg_addr_r1_shift.1 = shl nuw i64 %ldg_addr_r1_ext.1, 32
  %ldg_addr_packed_1.1 = or disjoint i64 %ldg_addr_r1_shift.1, %ldg_addr_r0_ext.1
  %"R774:R747_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.1 to ptr addrspace(1)
  %ldg.1 = load i32, ptr addrspace(1) %"R774:R747_addr_ptr", align 4
  br label %BB_3a50

BB_3a50:                                          ; preds = %BB_800039f0, %BB_3970
  %phi.273 = phi i32 [ %ldg.1, %BB_800039f0 ], [ %phi.256, %BB_3970 ]
  %phi.274 = phi i32 [ %ldg, %BB_800039f0 ], [ %phi.258, %BB_3970 ]
  %isetrp_cmp1.138 = icmp ne i8 %ldc_const.15, 0
  %.2112 = and i32 %imad_tmp.199, 8
  %.2091 = lshr i32 %tid_x, 1
  %552 = and i32 %.2091, 15
  %.21268 = or disjoint i32 %552, %.1820
  %553 = lshr exact i32 %.1774, 1
  %.21379 = or disjoint i32 %553, %.2112
  %.2153 = lshr i64 %.212, 32
  %554 = trunc nuw i64 %.2153 to i32
  %555 = and i32 %554, 3
  %.2156 = add i32 %555, %tid_x
  %imad_tmp.204 = mul nuw nsw i32 %.21268, 80
  %imad.217 = add nuw nsw i32 %imad_tmp.204, %.21379
  %.2163 = and i32 %.2156, -4
  %.2169 = zext i32 %.2156 to i64
  %.2170 = shl nuw i64 %.2169, 32
  %.2171 = ashr exact i64 %.2170, 2
  %shf_hi.19 = lshr i64 %.2171, 32
  %shf_result.43 = trunc nuw i64 %shf_hi.19 to i32
  %imad.218 = sub i32 %tid_x, %.2163
  %iadd3_n1.126 = add i32 %.192, %shf_result.43
  %imad_tmp.206 = mul i32 %shf_result.43, 10
  %imad.219 = add i32 %imad_tmp.206, %imad.218
  %.2175 = shl i32 %imad.218, 3
  %.2177 = add i32 %.2175, %.202
  %.2182 = getelementptr inbounds nuw i8, ptr %param_local, i64 800
  %isetrp_rhs.84 = load i32, ptr %.2182, align 4
  %isetrp_cmp1.139.not = icmp ne i32 %isetrp_rhs.84, 0
  %phi_cast_R749_bitcast = bitcast i32 %phi.273 to float
  %.2188 = getelementptr inbounds nuw i8, ptr %param_local, i64 480
  %imad_addend.35 = load i32, ptr %.2188, align 4
  %.2190 = getelementptr inbounds nuw i8, ptr %param_local, i64 496
  %imad_addend.3610 = load float, ptr %.2190, align 4
  %phi.279 = select i1 %isetrp_cmp1.137.not, float %imad_addend.3610, float %phi_cast_R749_bitcast
  %phi.280 = select i1 %isetrp_cmp1.137.not, i32 %imad_addend.35, i32 %phi.274
  %isetrp_rhs.85 = load i32, ptr %.2182, align 4
  %isetrp_cmp1.140.not = icmp slt i32 %.2177, %isetrp_rhs.85
  %or.cond = select i1 %isetrp_cmp1.139.not, i1 %isetrp_cmp1.140.not, i1 false
  br i1 %or.cond, label %BB_3c50, label %BB_3cd0

BB_3c50:                                          ; preds = %BB_3a50
  %.2117 = getelementptr inbounds nuw i8, ptr %param_local, i64 384
  %ldc_const.17 = load i64, ptr %.2117, align 8
  %phi.276 = select i1 %isetrp_cmp1.138, i32 %ctaid_z, i32 %phi.249
  %imad_tmp.207 = mul i32 %phi.276, %ldc_const.16
  %imad_lhs_64.25 = sext i32 %imad_tmp.207 to i64
  %imad_tmp_64.25 = shl nsw i64 %imad_lhs_64.25, 1
  %556 = select i1 %isetrp_cmp1.138, i64 %imad_tmp_64.25, i64 0
  %557 = add i64 %ldc_const.17, %556
  %.2212 = zext i32 %.2177 to i64
  %.2213 = shl nuw i64 %.2212, 32
  %.2233 = ashr exact i64 %.2213, 31
  %558 = add i64 %557, %.2233
  %"R530:R499_addr_ptr" = inttoptr i64 %558 to ptr addrspace(1)
  %ldg_vec = load <4 x i32>, ptr addrspace(1) %"R530:R499_addr_ptr", align 16
  %ldg_lane0 = extractelement <4 x i32> %ldg_vec, i64 0
  %ldg_lane1 = extractelement <4 x i32> %ldg_vec, i64 1
  %ldg_lane2 = extractelement <4 x i32> %ldg_vec, i64 2
  %ldg_lane3 = extractelement <4 x i32> %ldg_vec, i64 3
  br label %BB_3cd0

BB_3cd0:                                          ; preds = %BB_3a50, %BB_3c50
  %phi.281 = phi i32 [ %ldg_lane3, %BB_3c50 ], [ 0, %BB_3a50 ]
  %phi.282 = phi i32 [ %ldg_lane2, %BB_3c50 ], [ 0, %BB_3a50 ]
  %phi.283 = phi i32 [ %ldg_lane1, %BB_3c50 ], [ 0, %BB_3a50 ]
  %phi.284 = phi i32 [ %ldg_lane0, %BB_3c50 ], [ 0, %BB_3a50 ]
  %.2241 = getelementptr inbounds nuw i8, ptr %param_local, i64 824
  %ldc_const.19 = load i32, ptr %.2241, align 4
  %isetrp_cmp1.142 = icmp sgt i32 %ldc_const.19, 0
  %isetrp_cmp2.142 = and i1 %isetrp_cmp1.142, %isetrp_cmp1.138
  %.2243 = getelementptr inbounds nuw i8, ptr %param_local, i64 928
  br i1 %isetrp_cmp2.142, label %BB_3d40, label %BB_80003d30

BB_80003d30:                                      ; preds = %BB_3cd0
  %ldc_const.20 = load i32, ptr %.2243, align 4
  %isetrp_cmp1.143 = icmp ne i32 %ldc_const.20, 0
  br label %BB_3d40

BB_3d40:                                          ; preds = %BB_80003d30, %BB_3cd0
  %phi.285.in = phi i1 [ %isetrp_cmp1.143, %BB_80003d30 ], [ true, %BB_3cd0 ]
  %phi_cast_R637_bitcast = bitcast i32 %phi.280 to float
  br i1 %isetrp_cmp2.142, label %BB_3d50, label %BB_3ea0

BB_3d50:                                          ; preds = %BB_3d40
  %ldc_const.21 = load i32, ptr %.2243, align 4
  %isetrp_cmp1.144.not = icmp eq i32 %ldc_const.21, 0
  %ldc_const.22 = load i32, ptr %.2241, align 4
  %.2258 = getelementptr inbounds nuw i8, ptr %param_local, i64 392
  %ldc_const.23 = load i64, ptr %.2258, align 8
  %imad_tmp.210 = mul i32 %ctaid_z, %ldc_const.22
  %.2265 = getelementptr inbounds nuw i8, ptr %param_local, i64 400
  %ldc_const.24 = load i64, ptr %.2265, align 8
  %"UR5:UR4_r1_shift" = lshr i64 %ldc_const.24, 32
  %559 = sext i32 %imad_tmp.210 to i64
  br i1 %isetrp_cmp1.144.not, label %BB_3e10, label %BB_80003e00

BB_80003e00:                                      ; preds = %BB_3d50
  %.2268 = zext i32 %imad_tmp.210 to i64
  %.2274 = and i64 %ldc_const.24, 4294967295
  %.2276 = shl nuw nsw i64 %.2268, 2
  %.2277 = and i64 %.2276, 4294967292
  %.2278 = add nuw nsw i64 %.2277, %.2274
  %.2281 = icmp samesign ugt i64 %.2278, 4294967295
  br label %BB_3e10

BB_3e10:                                          ; preds = %BB_80003e00, %BB_3d50
  %phi.286.in = phi i64 [ %.2278, %BB_80003e00 ], [ %ldc_const.24, %BB_3d50 ]
  %phi.287.in = phi i1 [ %.2281, %BB_80003e00 ], [ %isetrp_cmp1.138, %BB_3d50 ]
  %imad_lhs_64.26 = sext i32 %imad_tmp.210 to i64
  %imad_tmp_64.26 = shl nsw i64 %imad_lhs_64.26, 2
  %imad.225 = add i64 %imad_tmp_64.26, %ldc_const.23
  %"UR11:UR10_r0.2" = trunc i64 %imad.225 to i32
  %560 = add i64 %imad_tmp_64.26, %ldc_const.23
  br i1 %isetrp_cmp1.144.not, label %BB_3e30, label %BB_80003e20

BB_80003e20:                                      ; preds = %BB_3e10
  %561 = lshr i64 %559, 30
  %.2292 = add nuw nsw i64 %561, %"UR5:UR4_r1_shift"
  %.2293 = zext i1 %phi.287.in to i64
  %.2294 = add nuw nsw i64 %.2292, %.2293
  %562 = and i64 %.2294, 4294967295
  br label %BB_3e30

BB_3e30:                                          ; preds = %BB_80003e20, %BB_3e10
  %phi.288.in = phi i64 [ %562, %BB_80003e20 ], [ %"UR5:UR4_r1_shift", %BB_3e10 ]
  %"R251:R1672_addr_ptr" = inttoptr i64 %560 to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R251:R1672_addr_ptr", align 4
  br i1 %isetrp_cmp1.144.not, label %BB_3ea0, label %BB_80003e80

BB_80003e80:                                      ; preds = %BB_3e30
  %ldg_addr_r0_ext.4 = and i64 %phi.286.in, 4294967295
  %ldg_addr_r1_shift.4 = shl nuw i64 %phi.288.in, 32
  %ldg_addr_packed_1.4 = or disjoint i64 %ldg_addr_r0_ext.4, %ldg_addr_r1_shift.4
  %"R68:R1765_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.4 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R68:R1765_addr_ptr", align 4
  br label %BB_3ea0

BB_3ea0:                                          ; preds = %BB_3e30, %BB_80003e80, %BB_3d40
  %phi.290.in = phi i1 [ %phi.285.in, %BB_3d40 ], [ true, %BB_80003e80 ], [ false, %BB_3e30 ]
  %phi.291 = phi float [ %phi.279, %BB_3d40 ], [ %ldg.3, %BB_80003e80 ], [ 0.000000e+00, %BB_3e30 ]
  %phi.292 = phi float [ %phi_cast_R637_bitcast, %BB_3d40 ], [ %ldg.2, %BB_80003e80 ], [ %ldg.2, %BB_3e30 ]
  %phi.293 = phi i32 [ %551, %BB_3d40 ], [ %"UR11:UR10_r0.2", %BB_80003e80 ], [ %"UR11:UR10_r0.2", %BB_3e30 ]
  call void @llvm.nvvm.barrier0()
  %.2306 = getelementptr inbounds nuw i8, ptr %param_local, i64 844
  %imad_addend.37 = load i32, ptr %.2306, align 4
  %.2316 = getelementptr inbounds nuw i8, ptr %param_local, i64 656
  %ldc_const.25 = load i32, ptr %.2316, align 4
  %isetrp_rhs.86 = load i32, ptr %.187, align 4
  %isetrp_cmp1.146.not = icmp eq i32 %isetrp_rhs.86, 1
  %iadd3_n1.127 = add i32 %ldc_const.25, -1
  %isetrp_rhs.87 = load i32, ptr %.193, align 4
  %isetrp_cmp1.147.not = icmp eq i32 %isetrp_rhs.87, 1
  %ldc_const.26 = load i32, ptr %.195, align 4
  %isetrp_rhs.88 = load i32, ptr %.197, align 4
  %isetrp_cmp1.148.not = icmp eq i32 %isetrp_rhs.88, 1
  %ldc_const.27 = load i32, ptr %.1657, align 4
  %.2328 = getelementptr inbounds nuw i8, ptr %param_local, i64 848
  %imad_rhs.99 = load i32, ptr %.2328, align 4
  %imad_tmp.215 = mul i32 %imad_addend.37, %imad_rhs.99
  %imad_tmp.216 = mul i32 %ldc_const.26, %ldc_const.27
  %isetrp_cmp1.149 = icmp eq i32 %ctaid_z, %iadd3_n1.127
  %isetrp_cmp2.149 = or i1 %isetrp_cmp1.149, %isetrp_cmp1.138
  %imad_tmp.217 = mul i32 %s2ur_ctaid_y, %imad_addend.37
  %imad.232 = add i32 %imad_tmp.217, %s2ur_ctaid_x
  %.2312 = fcmp une float %phi.291, 0.000000e+00
  %.2313 = or i1 %.2312, %phi.290.in
  br i1 %.2313, label %BB_5810, label %BB_4050

BB_4050:                                          ; preds = %BB_3ea0
  %isetrp_cmp1.150.not = icmp eq i32 %ldc_const.25, 1
  br i1 %isetrp_cmp1.150.not, label %BB_4610, label %BB_4060

BB_4060:                                          ; preds = %BB_4050
  %.2341 = getelementptr inbounds nuw i8, ptr %param_local, i64 660
  %ldc_const.28 = load i32, ptr %.2341, align 4
  %.2343 = getelementptr inbounds nuw i8, ptr %param_local, i64 664
  %imad_addend.38 = load i32, ptr %.2343, align 4
  %isetrp_cmp1.151.not = icmp ne i32 %ldc_const.25, %ldc_const.28
  %isetrp_cmp1.152 = icmp ne i32 %imad_addend.38, 2
  %brmerge78 = select i1 %isetrp_cmp1.151.not, i1 true, i1 %isetrp_cmp1.152
  br i1 %brmerge78, label %BB_40d0, label %BB_4610

BB_40d0:                                          ; preds = %BB_4060
  %isetrp_cmp1.153 = icmp eq i32 %imad_addend.38, 1
  %brmerge79.not = select i1 %isetrp_cmp2.149, i1 %isetrp_cmp1.153, i1 false
  br i1 %brmerge79.not, label %BB_4490, label %BB_4100

BB_4100:                                          ; preds = %BB_40d0
  %iabs_src = load i32, ptr %.2341, align 4
  %iabs = call i32 @llvm.abs.i32(i32 %iabs_src, i1 false)
  %iabs.1 = call i32 @llvm.abs.i32(i32 %ctaid_z, i1 false)
  %i2f_directed = call float asm "cvt.rp.f32.s32 $0, $1;", "=f,r"(i32 %iabs) #10
  %mufu_rcp = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed)
  %cast = bitcast float %mufu_rcp to i32
  %iadd3_n1.128 = add i32 %cast, 268435454
  %cast.1 = bitcast i32 %iadd3_n1.128 to float
  %f2i = fptoui float %cast.1 to i32
  %563 = mul i32 %iabs, %f2i
  %imad_tmp.221 = sub i32 0, %563
  %imad_addend_r1_ext.27 = zext i32 %f2i to i64
  %imad_rhs_64.27 = zext i32 %imad_tmp.221 to i64
  %imad_addend_r1_shift.2711 = or disjoint i64 %imad_rhs_64.27, 4294967296
  %imad.237 = mul i64 %imad_addend_r1_shift.2711, %imad_addend_r1_ext.27
  %"UR11:UR10_r1_shift.3" = lshr i64 %imad.237, 32
  %imad_rhs_64.28 = zext i32 %iabs.1 to i64
  %imad_tmp_64.28 = mul nuw i64 %"UR11:UR10_r1_shift.3", %imad_rhs_64.28
  %"UR11:UR10_r1_shift.4" = lshr i64 %imad_tmp_64.28, 32
  %"UR11:UR10_r1.4" = trunc nuw i64 %"UR11:UR10_r1_shift.4" to i32
  %564 = mul i32 %iabs, %"UR11:UR10_r1.4"
  %imad.239 = sub i32 %iabs.1, %564
  %isetrp_cmp1.154.not = icmp ule i32 %iabs, %imad.239
  %iadd3_n1.132 = zext i1 %isetrp_cmp1.154.not to i32
  %phi.294 = add i32 %"UR11:UR10_r1.4", %iadd3_n1.132
  %iadd3_n1.131 = select i1 %isetrp_cmp1.154.not, i32 %iabs, i32 0
  %phi.295 = sub nuw i32 %imad.239, %iadd3_n1.131
  %ldc_const.29 = load i32, ptr %.2341, align 4
  %.2378 = xor i32 %ldc_const.29, %ctaid_z
  %isetrp_cmp1.156 = icmp slt i32 %.2378, 0
  %isetrp_cmp1.155.not = icmp uge i32 %phi.295, %iabs
  %iadd3_n1.133 = zext i1 %isetrp_cmp1.155.not to i32
  %phi.296 = add i32 %phi.294, %iadd3_n1.133
  %isetrp_cmp1.157.not = icmp eq i32 %ldc_const.29, 0
  %iadd3_o1_neg.10 = sub i32 0, %phi.296
  %phi.297 = select i1 %isetrp_cmp1.156, i32 %iadd3_o1_neg.10, i32 %phi.296
  %phi.298 = select i1 %isetrp_cmp1.157.not, i32 -1, i32 %phi.297
  %isetrp_cmp1.158.not = icmp eq i32 %phi.298, 0
  %565 = mul i32 %phi.298, %ldc_const.29
  %imad.240 = sub i32 %ctaid_z, %565
  %not.isetrp_cmp1.158.not = xor i1 %isetrp_cmp1.158.not, true
  %sel.93 = zext i1 %not.isetrp_cmp1.158.not to i32
  %imad_tmp.224 = mul i32 %imad_tmp.215, %imad.240
  %imad.241 = add i32 %imad_tmp.224, %imad.232
  %.2404 = getelementptr inbounds nuw i8, ptr %param_local, i64 696
  %imad_addend.39 = load i64, ptr %.2404, align 8
  %imad_lhs_64.29 = sext i32 %imad.241 to i64
  %imad_tmp_64.29 = shl nsw i64 %imad_lhs_64.29, 2
  %imad.243 = add i64 %imad_tmp_64.29, %imad_addend.39
  %566 = add i64 %imad_tmp_64.29, %imad_addend.39
  %.2406 = getelementptr inbounds nuw i8, ptr %param_local, i64 704
  %imad_addend.40 = load i64, ptr %.2406, align 8
  %imad_lhs_64.30 = sext i32 %imad.232 to i64
  %imad_tmp_64.30 = shl nsw i64 %imad_lhs_64.30, 2
  %imad.244 = add i64 %imad_tmp_64.30, %imad_addend.40
  %isetrp_cmp1.160 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.160 = or i1 %isetrp_cmp1.160, %isetrp_cmp1.158.not
  br i1 %isetrp_cmp2.160, label %BB_4440, label %BB_43b0.preheader

BB_43b0.preheader:                                ; preds = %BB_4100
  br label %BB_43b0

BB_43b0:                                          ; preds = %BB_43b0.preheader, %BB_43b0
  %ld_volatile = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %566) #10
  %isetrp_cmp1.161.not = icmp eq i32 %ld_volatile, %phi.298
  br i1 %isetrp_cmp1.161.not, label %BB_4440.loopexit, label %BB_43b0

BB_4440.loopexit:                                 ; preds = %BB_43b0
  br label %BB_4440

BB_4440:                                          ; preds = %BB_4440.loopexit, %BB_4100
  call void @llvm.nvvm.barrier0()
  %phi_cast_R411_zext = and i64 %imad.243, 4294967295
  %phi_cast_R1568_zext = and i64 %imad.244, 4294967295
  %567 = inttoptr i64 %phi_cast_R411_zext to ptr addrspace(1)
  br label %BB_4610

BB_4490:                                          ; preds = %BB_40d0
  %isetrp_cmp1.162.not = icmp eq i32 %iadd3_n1.127, 0
  %ldc_const.30 = load i32, ptr %.2341, align 4
  %isetrp_cmp1.163 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.163 = or i1 %isetrp_cmp1.163, %isetrp_cmp1.162.not
  %not.isetrp_cmp1.151.not = xor i1 %isetrp_cmp1.151.not, true
  %iadd3_n1.136 = sext i1 %not.isetrp_cmp1.151.not to i32
  %phi.299 = add i32 %ldc_const.30, %iadd3_n1.136
  %.2418 = getelementptr inbounds nuw i8, ptr %param_local, i64 704
  %imad_addend.41 = load i64, ptr %.2418, align 8
  %imad_lhs_64.31 = sext i32 %imad.232 to i64
  %imad_tmp_64.31 = shl nsw i64 %imad_lhs_64.31, 2
  %imad.246 = add i64 %imad_tmp_64.31, %imad_addend.41
  %568 = add i64 %imad_tmp_64.31, %imad_addend.41
  br i1 %isetrp_cmp2.163, label %BB_45c0, label %BB_4530.preheader

BB_4530.preheader:                                ; preds = %BB_4490
  br label %BB_4530

BB_4530:                                          ; preds = %BB_4530.preheader, %BB_4530
  %ld_volatile.1 = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %568) #10
  %isetrp_cmp1.164.not = icmp eq i32 %ld_volatile.1, %iadd3_n1.127
  br i1 %isetrp_cmp1.164.not, label %BB_45c0.loopexit, label %BB_4530

BB_45c0.loopexit:                                 ; preds = %BB_4530
  br label %BB_45c0

BB_45c0:                                          ; preds = %BB_45c0.loopexit, %BB_4490
  call void @llvm.nvvm.barrier0()
  %phi_cast_R1558_zext = and i64 %imad.246, 4294967295
  br label %BB_4610

BB_4610:                                          ; preds = %BB_4060, %BB_45c0, %BB_4440, %BB_4050
  %isetrp_cmp1.177.not = phi i1 [ true, %BB_4440 ], [ true, %BB_45c0 ], [ false, %BB_4050 ], [ false, %BB_4060 ]
  %phi.301 = phi i32 [ %imad.240, %BB_4440 ], [ 0, %BB_45c0 ], [ 0, %BB_4050 ], [ %ctaid_z, %BB_4060 ]
  %phi.302 = phi i32 [ %sel.93, %BB_4440 ], [ %phi.299, %BB_45c0 ], [ 0, %BB_4050 ], [ 0, %BB_4060 ]
  %phi.303 = phi ptr addrspace(1) [ %567, %BB_4440 ], [ null, %BB_45c0 ], [ null, %BB_4050 ], [ null, %BB_4060 ]
  %phi.304 = phi i64 [ %phi_cast_R1568_zext, %BB_4440 ], [ %phi_cast_R1558_zext, %BB_45c0 ], [ 0, %BB_4050 ], [ 0, %BB_4060 ]
  %phi.305 = phi i32 [ %iadd3_n1.128, %BB_4440 ], [ %phi.293, %BB_45c0 ], [ %phi.293, %BB_4050 ], [ %phi.293, %BB_4060 ]
  %phi.306 = phi i32 [ %iabs.1, %BB_4440 ], [ %s2ur_ctaid_y, %BB_45c0 ], [ %s2ur_ctaid_y, %BB_4050 ], [ %s2ur_ctaid_y, %BB_4060 ]
  %mov.14 = load i32, ptr %.2316, align 4
  %.2427 = getelementptr inbounds nuw i8, ptr %param_local, i64 664
  %ldc_const.31 = load i32, ptr %.2427, align 4
  %569 = sext i32 %phi.301 to i64
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.166 = icmp eq i32 %ldc_const.31, 1
  %isetrp_cmp2.166 = and i1 %isetrp_cmp1.166, %isetrp_cmp2.149
  %.2433 = getelementptr inbounds nuw i8, ptr %param_local, i64 672
  %imad_rhs.101 = load i32, ptr %.2433, align 4
  %.2435 = getelementptr inbounds nuw i8, ptr %param_local, i64 676
  %imad_rhs.102 = load i32, ptr %.2435, align 4
  %570 = zext i32 %imad_rhs.102 to i64
  %571 = shl nuw i64 %570, 32
  %572 = zext i32 %imad_rhs.101 to i64
  %573 = or disjoint i64 %571, %572
  %574 = mul i64 %573, %569
  %isetrp_cmp1.165 = icmp slt i32 %mov.14, 2
  %phi_cast_R1587_bitcast.1 = bitcast float %phi.250 to i32
  %phi_cast_R1507_bitcast.1 = bitcast float %phi.251 to i32
  %575 = zext i32 %phi_cast_R1587_bitcast.1 to i64
  %576 = shl nuw i64 %575, 32
  %577 = zext i32 %phi_cast_R1507_bitcast.1 to i64
  %578 = or disjoint i64 %576, %577
  %phi_cast_R1400_bitcast.1 = bitcast float %phi.252 to i32
  %phi_cast_R1287_bitcast.1 = bitcast float %phi.253 to i32
  %579 = zext i32 %phi_cast_R1400_bitcast.1 to i64
  %580 = shl nuw i64 %579, 32
  %581 = zext i32 %phi_cast_R1287_bitcast.1 to i64
  %582 = or disjoint i64 %580, %581
  %phi_cast_R1939_bitcast.1 = bitcast float %phi.254 to i32
  %phi_cast_R1007_bitcast.1 = bitcast float %phi.257 to i32
  %583 = zext i32 %phi_cast_R1939_bitcast.1 to i64
  %584 = shl nuw i64 %583, 32
  %585 = zext i32 %phi_cast_R1007_bitcast.1 to i64
  %586 = or disjoint i64 %584, %585
  %phi_cast_R1232_bitcast.1 = bitcast float %phi.271 to i32
  %phi_cast_R179_bitcast.1 = bitcast float %phi.272 to i32
  %587 = zext i32 %phi_cast_R1232_bitcast.1 to i64
  %588 = shl nuw i64 %587, 32
  %589 = zext i32 %phi_cast_R179_bitcast.1 to i64
  %590 = or disjoint i64 %588, %589
  br i1 %isetrp_cmp1.165, label %BB_49a0, label %BB_46c0

BB_46c0:                                          ; preds = %BB_4610
  %imad_tmp.229 = shl i32 %imad_tmp.215, 7
  %imad_tmp.230 = shl i32 %imad.232, 7
  %imad.251 = add i32 %imad_tmp.230, %tid_x
  %.2442 = zext i32 %imad_tmp.229 to i64
  %591 = sext i32 %imad_tmp.229 to i64
  %isetrp_cmp1.167 = icmp slt i32 %phi.302, 1
  br i1 %isetrp_cmp1.167, label %BB_48f0, label %BB_4710

BB_4710:                                          ; preds = %BB_46c0
  %imad_tmp.231 = shl i32 %imad.251, 4
  %.2456 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.44 = load i32, ptr %.2456, align 4
  %592 = sext i32 %imad_tmp.231 to i64
  %.2467 = shl nsw i64 %591, 4
  %593 = add i64 %574, %.2467
  %.2473 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.45 = load i32, ptr %.2473, align 4
  %594 = zext i32 %iadd3_o2.44 to i64
  %595 = zext i32 %iadd3_o2.45 to i64
  %596 = shl nuw i64 %595, 32
  %597 = add i64 %593, %592
  %598 = add i64 %597, %594
  %599 = add i64 %598, %596
  %600 = zext i32 %iadd3_o2.44 to i64
  %601 = zext i32 %iadd3_o2.45 to i64
  %602 = shl nuw i64 %601, 32
  %603 = add i64 %574, %592
  %604 = add i64 %603, %600
  %605 = add i64 %604, %602
  br label %BB_47a0

BB_47a0:                                          ; preds = %BB_47a0, %BB_4710
  %606 = phi i64 [ %599, %BB_4710 ], [ %612, %BB_47a0 ]
  %607 = phi i64 [ %605, %BB_4710 ], [ %617, %BB_47a0 ]
  %phi.307 = phi i32 [ 0, %BB_4710 ], [ %iadd3_n1.141, %BB_47a0 ]
  %phi.308 = phi float [ %phi.250, %BB_4710 ], [ %fadd.5, %BB_47a0 ]
  %phi.309 = phi float [ %phi.251, %BB_4710 ], [ %fadd.4, %BB_47a0 ]
  %phi.310 = phi float [ %phi.252, %BB_4710 ], [ %fadd.3, %BB_47a0 ]
  %phi.311 = phi float [ %phi.253, %BB_4710 ], [ %fadd.2, %BB_47a0 ]
  %phi.312 = phi float [ %phi.254, %BB_4710 ], [ %fadd.1, %BB_47a0 ]
  %phi.317 = phi float [ %phi.257, %BB_4710 ], [ %fadd, %BB_47a0 ]
  %phi.318 = phi float [ %phi.271, %BB_4710 ], [ %fadd.7, %BB_47a0 ]
  %phi.319 = phi float [ %phi.272, %BB_4710 ], [ %fadd.6, %BB_47a0 ]
  %ldv_volatile = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %607) #10
  %ldstrongv_lane3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 3
  %fadd_lhs_bitcast.3 = bitcast i32 %ldstrongv_lane3 to float
  %ldstrongv_lane2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 2
  %fadd_lhs_bitcast.2 = bitcast i32 %ldstrongv_lane2 to float
  %ldstrongv_lane1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 1
  %fadd_lhs_bitcast.1 = bitcast i32 %ldstrongv_lane1 to float
  %ldstrongv_lane0 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 0
  %fadd_lhs_bitcast = bitcast i32 %ldstrongv_lane0 to float
  %fadd = fadd float %phi.317, %fadd_lhs_bitcast
  %fadd.1 = fadd float %phi.312, %fadd_lhs_bitcast.1
  %fadd.2 = fadd float %phi.311, %fadd_lhs_bitcast.2
  %fadd.3 = fadd float %phi.310, %fadd_lhs_bitcast.3
  %ldv_volatile.1 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %606) #10
  %ldstrongv_lane3.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 3
  %fadd_lhs_bitcast.7 = bitcast i32 %ldstrongv_lane3.1 to float
  %ldstrongv_lane2.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 2
  %fadd_lhs_bitcast.6 = bitcast i32 %ldstrongv_lane2.1 to float
  %ldstrongv_lane1.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 1
  %fadd_lhs_bitcast.5 = bitcast i32 %ldstrongv_lane1.1 to float
  %ldstrongv_lane0.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 0
  %fadd_lhs_bitcast.4 = bitcast i32 %ldstrongv_lane0.1 to float
  %fadd.4 = fadd float %phi.309, %fadd_lhs_bitcast.4
  %fadd.5 = fadd float %phi.308, %fadd_lhs_bitcast.5
  %fadd.6 = fadd float %phi.319, %fadd_lhs_bitcast.6
  %fadd.7 = fadd float %phi.318, %fadd_lhs_bitcast.7
  %iadd3_o2.48 = load i32, ptr %.2433, align 4
  %608 = zext i32 %iadd3_o2.48 to i64
  %609 = add i64 %606, %608
  %iadd3_o2.50 = load i32, ptr %.2435, align 4
  %610 = zext i32 %iadd3_o2.50 to i64
  %611 = shl nuw i64 %610, 32
  %612 = add i64 %609, %611
  %iadd3_n1.141 = add i32 %phi.307, 1
  %isetrp_cmp1.168.not = icmp sgt i32 %phi.302, %iadd3_n1.141
  %613 = zext i32 %iadd3_o2.48 to i64
  %614 = add i64 %607, %613
  %615 = zext i32 %iadd3_o2.50 to i64
  %616 = shl nuw i64 %615, 32
  %617 = add i64 %614, %616
  br i1 %isetrp_cmp1.168.not, label %BB_47a0, label %BB_48f0.loopexit

BB_48f0.loopexit:                                 ; preds = %BB_47a0
  %ldg_addr_r0_ext.7 = and i64 %607, 4294967295
  %iadd3_o2_64.12 = zext i32 %iadd3_o2.48 to i64
  %iadd3_tmp.12 = add nuw nsw i64 %ldg_addr_r0_ext.7, %iadd3_o2_64.12
  %iadd3_trunc.12 = trunc i64 %iadd3_tmp.12 to i32
  %618 = lshr i64 %607, 32
  %619 = trunc nuw i64 %618 to i32
  %iadd3_n1.142 = add i32 %iadd3_o2.50, %619
  %carry_ge_1.12 = icmp samesign ugt i64 %iadd3_tmp.12, 4294967295
  %iadd3_cin1_narrow_zext.2 = zext i1 %carry_ge_1.12 to i32
  %iadd3_cin1_add.2 = add i32 %iadd3_n1.142, %iadd3_cin1_narrow_zext.2
  %phi_cast_R1590_bitcast = bitcast float %fadd.5 to i32
  %620 = zext i32 %phi_cast_R1590_bitcast to i64
  %621 = shl nuw i64 %620, 32
  %phi_cast_R1509_bitcast = bitcast float %fadd.4 to i32
  %622 = zext i32 %phi_cast_R1509_bitcast to i64
  %623 = or disjoint i64 %621, %622
  %phi_cast_R1436_bitcast = bitcast float %fadd.7 to i32
  %624 = zext i32 %phi_cast_R1436_bitcast to i64
  %625 = shl nuw i64 %624, 32
  %phi_cast_R221_bitcast = bitcast float %fadd.6 to i32
  %626 = zext i32 %phi_cast_R221_bitcast to i64
  %627 = or disjoint i64 %625, %626
  %phi_cast_R1984_bitcast = bitcast float %fadd.1 to i32
  %628 = zext i32 %phi_cast_R1984_bitcast to i64
  %629 = shl nuw i64 %628, 32
  %phi_cast_R1009_bitcast = bitcast float %fadd to i32
  %630 = zext i32 %phi_cast_R1009_bitcast to i64
  %631 = or disjoint i64 %629, %630
  %phi_cast_R1403_bitcast = bitcast float %fadd.3 to i32
  %632 = zext i32 %phi_cast_R1403_bitcast to i64
  %633 = shl nuw i64 %632, 32
  %phi_cast_R1290_bitcast = bitcast float %fadd.2 to i32
  %634 = zext i32 %phi_cast_R1290_bitcast to i64
  %635 = or disjoint i64 %633, %634
  br label %BB_48f0

BB_48f0:                                          ; preds = %BB_48f0.loopexit, %BB_46c0
  %636 = phi i64 [ %590, %BB_46c0 ], [ %627, %BB_48f0.loopexit ]
  %637 = phi i64 [ %582, %BB_46c0 ], [ %635, %BB_48f0.loopexit ]
  %638 = phi i64 [ %578, %BB_46c0 ], [ %623, %BB_48f0.loopexit ]
  %639 = phi i64 [ %586, %BB_46c0 ], [ %631, %BB_48f0.loopexit ]
  %phi.325 = phi i32 [ %imad.191, %BB_46c0 ], [ %iadd3_trunc.12, %BB_48f0.loopexit ]
  %phi.326 = phi i32 [ %phi.255, %BB_46c0 ], [ %iadd3_cin1_add.2, %BB_48f0.loopexit ]
  %phi.328 = phi i32 [ %547, %BB_46c0 ], [ %ldstrongv_lane1, %BB_48f0.loopexit ]
  %phi.329 = phi i32 [ %phi.305, %BB_46c0 ], [ %ldstrongv_lane2.1, %BB_48f0.loopexit ]
  %phi.330 = phi i32 [ %phi.306, %BB_46c0 ], [ %ldstrongv_lane1.1, %BB_48f0.loopexit ]
  %phi.331 = phi i32 [ %mov.14, %BB_46c0 ], [ %ldstrongv_lane0.1, %BB_48f0.loopexit ]
  br i1 %isetrp_cmp2.166, label %BB_49a0, label %BB_4910

BB_4910:                                          ; preds = %BB_48f0
  %.mask = and i64 %637, 4294967295
  %stg_val_r2_ext = zext nneg i64 %.mask to i128
  %stg_val_r2_shift = shl nuw nsw i128 %stg_val_r2_ext, 64
  %stg_val_packed_1 = zext i64 %639 to i128
  %stg_val_packed_2 = or disjoint i128 %stg_val_r2_shift, %stg_val_packed_1
  %640 = lshr i64 %637, 32
  %stg_val_r3_ext = zext nneg i64 %640 to i128
  %stg_val_r3_shift = shl nuw i128 %stg_val_r3_ext, 96
  %stg_val_packed_3 = or disjoint i128 %stg_val_packed_2, %stg_val_r3_shift
  %imad_lhs_64.33 = sext i32 %imad.251 to i64
  %imad_tmp_64.33 = shl nsw i64 %imad_lhs_64.33, 4
  %641 = add i64 %imad_tmp_64.33, %574
  %imad.253 = add i64 %imad_tmp_64.33, %574
  %.2497 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.52 = load i32, ptr %.2497, align 4
  %642 = zext i32 %iadd3_o2.52 to i64
  %643 = add i64 %641, %642
  %.2499 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.53 = load i32, ptr %.2499, align 4
  %644 = zext i32 %iadd3_o2.53 to i64
  %645 = shl nuw i64 %644, 32
  %646 = add i64 %643, %645
  %"R256:R183_addr_ptr" = inttoptr i64 %646 to ptr addrspace(1)
  store i128 %stg_val_packed_3, ptr addrspace(1) %"R256:R183_addr_ptr", align 8
  %.mask18 = and i64 %636, 4294967295
  %stg_val_r2_ext.1 = zext nneg i64 %.mask18 to i128
  %stg_val_r2_shift.1 = shl nuw nsw i128 %stg_val_r2_ext.1, 64
  %stg_val_packed_1.1 = zext i64 %638 to i128
  %stg_val_packed_2.1 = or disjoint i128 %stg_val_r2_shift.1, %stg_val_packed_1.1
  %647 = lshr i64 %636, 32
  %stg_val_r3_ext.1 = zext nneg i64 %647 to i128
  %stg_val_r3_shift.1 = shl nuw i128 %stg_val_r3_ext.1, 96
  %stg_val_packed_3.1 = or disjoint i128 %stg_val_packed_2.1, %stg_val_r3_shift.1
  %648 = and i64 %imad.253, 4294967295
  %649 = zext i32 %iadd3_o2.52 to i64
  %650 = add nuw nsw i64 %648, %649
  %.2516 = shl nsw i64 %591, 4
  %651 = add nsw i64 %650, %.2516
  %.2517 = lshr i64 %.2516, 32
  %652 = and i64 %imad.253, -4294967296
  %653 = add i64 %651, %652
  %654 = zext i32 %iadd3_o2.53 to i64
  %655 = shl nuw i64 %654, 32
  %656 = add i64 %653, %655
  %"R84:R7_addr_ptr" = inttoptr i64 %656 to ptr addrspace(1)
  store i128 %stg_val_packed_3.1, ptr addrspace(1) %"R84:R7_addr_ptr", align 8
  %"R21:R20_r1_shift" = lshr i64 %imad.253, 32
  %"R21:R20_r1" = trunc nuw i64 %"R21:R20_r1_shift" to i32
  %iadd3_n1.144 = add i32 %iadd3_o2.53, %"R21:R20_r1"
  %iadd3_o1_64.14 = and i64 %imad.253, 4294967295
  %iadd3_o2_64.14 = zext i32 %iadd3_o2.52 to i64
  %iadd3_tmp.14 = add nuw nsw i64 %iadd3_o1_64.14, %iadd3_o2_64.14
  %iadd3_trunc.14 = trunc i64 %iadd3_tmp.14 to i32
  %carry_ge_1.14 = icmp samesign ugt i64 %iadd3_tmp.14, 4294967295
  %iadd3_cin1_narrow_zext.4 = zext i1 %carry_ge_1.14 to i32
  %iadd3_cin1_add.4 = add i32 %iadd3_n1.144, %iadd3_cin1_narrow_zext.4
  %stg_addr_r1_ext = zext i32 %iadd3_cin1_add.4 to i64
  %.2518 = add nuw nsw i64 %.2517, %stg_addr_r1_ext
  %.2502 = and i64 %iadd3_tmp.14, 4294967295
  %.2504 = shl nuw nsw i64 %.2442, 4
  %.2505 = and i64 %.2504, 4294965248
  %.2506 = add nuw nsw i64 %.2505, %.2502
  %.2507 = trunc i64 %.2506 to i32
  %.2509 = icmp samesign ugt i64 %.2506, 4294967295
  %.2519 = zext i1 %.2509 to i64
  %.2520 = add nuw nsw i64 %.2518, %.2519
  %.2521 = trunc i64 %.2520 to i32
  br label %BB_49a0

BB_49a0:                                          ; preds = %BB_4610, %BB_48f0, %BB_4910
  %657 = phi i64 [ %636, %BB_4910 ], [ %590, %BB_4610 ], [ %636, %BB_48f0 ]
  %658 = phi i64 [ %637, %BB_4910 ], [ %582, %BB_4610 ], [ %637, %BB_48f0 ]
  %659 = phi i64 [ %638, %BB_4910 ], [ %578, %BB_4610 ], [ %638, %BB_48f0 ]
  %660 = phi i64 [ %639, %BB_4910 ], [ %586, %BB_4610 ], [ %639, %BB_48f0 ]
  %phi.339 = phi i32 [ %phi.325, %BB_4910 ], [ %imad.191, %BB_4610 ], [ %phi.325, %BB_48f0 ]
  %phi.340 = phi i32 [ %phi.326, %BB_4910 ], [ %phi.255, %BB_4610 ], [ %phi.326, %BB_48f0 ]
  %phi.342 = phi i32 [ %phi.328, %BB_4910 ], [ %547, %BB_4610 ], [ %phi.328, %BB_48f0 ]
  %phi.343 = phi i32 [ %iadd3_trunc.14, %BB_4910 ], [ %phi.305, %BB_4610 ], [ %phi.329, %BB_48f0 ]
  %phi.344 = phi i32 [ %.2521, %BB_4910 ], [ %phi.306, %BB_4610 ], [ %phi.330, %BB_48f0 ]
  %phi.345 = phi i32 [ %.2507, %BB_4910 ], [ %mov.14, %BB_4610 ], [ %phi.331, %BB_48f0 ]
  %661 = trunc i64 %660 to i32
  br i1 %isetrp_cmp2.166, label %BB_49b0, label %BB_4e40

BB_49b0:                                          ; preds = %BB_49a0
  %662 = zext nneg i32 %imad.217 to i64
  %.2531 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %662
  store volatile i64 %660, ptr addrspace(3) %.2531, align 8
  br i1 %isetrp_cmp1.146.not, label %BB_49d0, label %BB_800049c0

BB_800049c0:                                      ; preds = %BB_49b0
  %.2535 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.104 = load i32, ptr %.2535, align 4
  %imad_lhs_64.34 = zext i32 %iadd3_n1.126 to i64
  %imad_rhs_64.34 = zext i32 %imad_rhs.104 to i64
  %imad_tmp_64.34 = mul nuw i64 %imad_lhs_64.34, %imad_rhs_64.34
  %imad_tmp_hi.12 = lshr i64 %imad_tmp_64.34, 32
  %imad_tmp_hi_trunc.12 = trunc nuw i64 %imad_tmp_hi.12 to i32
  br label %BB_49d0

BB_49d0:                                          ; preds = %BB_800049c0, %BB_49b0
  %phi.348 = phi i32 [ %imad_tmp_hi_trunc.12, %BB_800049c0 ], [ %phi.345, %BB_49b0 ]
  %sts_addr_memaddr_offset_add = add nuw nsw i32 %imad.217, 16
  %663 = zext nneg i32 %sts_addr_memaddr_offset_add to i64
  %.2538 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %663
  store volatile i64 %659, ptr addrspace(3) %.2538, align 8
  br i1 %isetrp_cmp1.146.not, label %BB_4a10, label %BB_80004a00

BB_80004a00:                                      ; preds = %BB_49d0
  %.2542 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %shf_shift.12 = load i32, ptr %.2542, align 4
  %.2545 = zext i32 %phi.348 to i64
  %.2546 = shl nuw i64 %.2545, 32
  %shf_shift_64.51 = zext nneg i32 %shf_shift.12 to i64
  %.2547 = lshr i64 %.2546, %shf_shift_64.51
  %shf_hi.27 = lshr i64 %.2547, 32
  %shf_result.51 = trunc nuw i64 %shf_hi.27 to i32
  br label %BB_4a10

BB_4a10:                                          ; preds = %BB_80004a00, %BB_49d0
  %phi.349 = phi i32 [ %shf_result.51, %BB_80004a00 ], [ %iadd3_n1.126, %BB_49d0 ]
  %sts_addr_memaddr_offset_add.1 = add nuw nsw i32 %imad.217, 1280
  %664 = zext nneg i32 %sts_addr_memaddr_offset_add.1 to i64
  %.2549 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %664
  store volatile i64 %658, ptr addrspace(3) %.2549, align 8
  %isetrp_rhs.89 = load i32, ptr %.355, align 4
  %isetrp_cmp1.169.not = icmp slt i32 %iadd3_n1.126, %isetrp_rhs.89
  %imad_addend_neg.23 = sub i32 0, %phi.349
  %phi.350 = select i1 %isetrp_cmp1.146.not, i32 %phi.344, i32 %imad_addend_neg.23
  %sts_addr_memaddr_offset_add.2 = add nuw nsw i32 %imad.217, 1296
  %665 = zext nneg i32 %sts_addr_memaddr_offset_add.2 to i64
  %.2556 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %665
  store volatile i64 %657, ptr addrspace(3) %.2556, align 8
  call void @llvm.nvvm.barrier0()
  %imad_rhs.105 = load i32, ptr %.187, align 4
  %imad_tmp.233 = mul i32 %phi.350, %imad_rhs.105
  %imad.255 = add i32 %imad_tmp.233, %iadd3_n1.126
  %phi.351 = select i1 %isetrp_cmp1.146.not, i32 0, i32 %imad.255
  %isetrp_cmp1.170 = icmp slt i32 %.2177, %imad_tmp.216
  %isetrp_cmp2.170 = and i1 %isetrp_cmp1.170, %isetrp_cmp1.169.not
  br i1 %isetrp_cmp1.147.not, label %BB_4ab0, label %BB_80004a90

BB_80004a90:                                      ; preds = %BB_4a10
  %.2565 = getelementptr inbounds nuw i8, ptr %param_local, i64 992
  %imad_rhs.106 = load i32, ptr %.2565, align 4
  %imad_lhs_64.35 = zext i32 %phi.351 to i64
  %imad_rhs_64.35 = zext i32 %imad_rhs.106 to i64
  %imad_tmp_64.35 = mul nuw i64 %imad_lhs_64.35, %imad_rhs_64.35
  %imad_tmp_hi.13 = and i64 %imad_tmp_64.35, -4294967296
  %.2567 = getelementptr inbounds nuw i8, ptr %param_local, i64 996
  %shf_shift.13 = load i32, ptr %.2567, align 4
  %shf_shift_64.52 = zext nneg i32 %shf_shift.13 to i64
  %.2572 = lshr i64 %imad_tmp_hi.13, %shf_shift_64.52
  %shf_hi.28 = lshr i64 %.2572, 32
  %shf_result.52 = trunc nuw i64 %shf_hi.28 to i32
  br label %BB_4ab0

BB_4ab0:                                          ; preds = %BB_80004a90, %BB_4a10
  %phi.355 = phi i32 [ %shf_result.52, %BB_80004a90 ], [ %phi.351, %BB_4a10 ]
  %phi.352 = phi i32 [ %shf_result.52, %BB_80004a90 ], [ %phi.340, %BB_4a10 ]
  %.2574 = getelementptr inbounds nuw i8, ptr %param_local, i64 596
  %imad_rhs.107 = load i32, ptr %.2574, align 4
  %imad_tmp.234 = mul i32 %.2177, %imad_rhs.107
  %imad_addend_neg.24 = sub i32 0, %phi.352
  %phi.353 = select i1 %isetrp_cmp1.147.not, i32 %phi.339, i32 %imad_addend_neg.24
  %666 = shl i32 %phi.284, 16
  %667 = lshr exact i32 %666, 3
  %668 = and i32 %667, 268427264
  %669 = icmp samesign ugt i32 %668, 260046847
  %670 = select i1 %669, i32 2139095040, i32 0
  %671 = or i32 %668, %670
  %672 = bitcast i32 %671 to float
  %673 = fmul float %672, 0x46F0000000000000
  %674 = bitcast i32 %666 to float
  %675 = call float @llvm.copysign.f32(float %673, float %674)
  %imad_rhs.108 = load i32, ptr %.193, align 4
  %imad_tmp.236 = mul i32 %phi.353, %imad_rhs.108
  %imad.258 = add i32 %imad_tmp.236, %phi.351
  %phi.354 = select i1 %isetrp_cmp1.147.not, i32 0, i32 %imad.258
  %extelt.offset = and i32 %phi.284, -65536
  %676 = lshr i32 %phi.284, 3
  %677 = and i32 %676, 268427264
  %678 = icmp samesign ugt i32 %677, 260046847
  %679 = select i1 %678, i32 2139095040, i32 0
  %680 = or i32 %677, %679
  %681 = bitcast i32 %680 to float
  %682 = fmul float %681, 0x46F0000000000000
  %683 = bitcast i32 %extelt.offset to float
  %684 = call float @llvm.copysign.f32(float %682, float %683)
  br i1 %isetrp_cmp1.148.not, label %BB_4b20, label %BB_80004b10

BB_80004b10:                                      ; preds = %BB_4ab0
  %.2588 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.109 = load i32, ptr %.2588, align 4
  %imad_lhs_64.36 = zext i32 %phi.354 to i64
  %imad_rhs_64.36 = zext i32 %imad_rhs.109 to i64
  %imad_tmp_64.36 = mul nuw i64 %imad_lhs_64.36, %imad_rhs_64.36
  %imad_tmp_hi.14 = lshr i64 %imad_tmp_64.36, 32
  br label %BB_4b20

BB_4b20:                                          ; preds = %BB_80004b10, %BB_4ab0
  %phi.356.in = phi i64 [ %imad_tmp_hi.14, %BB_80004b10 ], [ %659, %BB_4ab0 ]
  %lds_addr_memaddr_offset_add.xscale = shl i32 %imad.219, 4
  %lds_addr_memaddr_offset_add = add i32 %lds_addr_memaddr_offset_add.xscale, 80
  %lds_shared_addr_winoff = and i32 %lds_addr_memaddr_offset_add, 16777200
  %685 = zext nneg i32 %lds_shared_addr_winoff to i64
  %.2591 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %685
  %lds = load volatile i128, ptr addrspace(3) %.2591, align 8
  %"R23:R22:R21:R20_r0.3" = trunc i128 %lds to i32
  %"R23:R22:R21:R20_r1_shift.3" = lshr i128 %lds, 32
  %"R23:R22:R21:R20_r1.3" = trunc i128 %"R23:R22:R21:R20_r1_shift.3" to i32
  %"R23:R22:R21:R20_r2_shift.3" = lshr i128 %lds, 64
  %"R23:R22:R21:R20_r2.3" = trunc i128 %"R23:R22:R21:R20_r2_shift.3" to i32
  %"R23:R22:R21:R20_r3_shift.3" = lshr i128 %lds, 96
  %"R23:R22:R21:R20_r3.3" = trunc nuw i128 %"R23:R22:R21:R20_r3_shift.3" to i32
  %686 = shl i32 %phi.281, 16
  %687 = lshr exact i32 %686, 3
  %688 = and i32 %687, 268427264
  %689 = icmp samesign ugt i32 %688, 260046847
  %690 = select i1 %689, i32 2139095040, i32 0
  %691 = or i32 %688, %690
  %692 = bitcast i32 %691 to float
  %693 = fmul float %692, 0x46F0000000000000
  %694 = bitcast i32 %686 to float
  %695 = call float @llvm.copysign.f32(float %693, float %694)
  %.2592 = getelementptr inbounds nuw i8, ptr %param_local, i64 580
  %imad_rhs.110 = load i32, ptr %.2592, align 4
  %imad_tmp.237 = mul i32 %phi.349, %imad_rhs.110
  %imad.259 = add i32 %imad_tmp.237, %imad_tmp.234
  %lds_shared_addr_winoff.1 = and i32 %lds_addr_memaddr_offset_add.xscale, 16777200
  %696 = zext nneg i32 %lds_shared_addr_winoff.1 to i64
  %.2594 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %696
  %lds.1 = load volatile i128, ptr addrspace(3) %.2594, align 8
  %"R27:R26:R25:R24_r0.3" = trunc i128 %lds.1 to i32
  %"R27:R26:R25:R24_r1_shift.3" = lshr i128 %lds.1, 32
  %"R27:R26:R25:R24_r1.3" = trunc i128 %"R27:R26:R25:R24_r1_shift.3" to i32
  %"R27:R26:R25:R24_r2_shift.3" = lshr i128 %lds.1, 64
  %"R27:R26:R25:R24_r2.3" = trunc i128 %"R27:R26:R25:R24_r2_shift.3" to i32
  %"R27:R26:R25:R24_r3_shift.3" = lshr i128 %lds.1, 96
  %"R27:R26:R25:R24_r3.3" = trunc nuw i128 %"R27:R26:R25:R24_r3_shift.3" to i32
  br i1 %isetrp_cmp1.148.not, label %BB_4b70, label %BB_80004b60

BB_80004b60:                                      ; preds = %BB_4b20
  %.2597 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.14 = load i32, ptr %.2597, align 4
  %.2601 = shl i64 %phi.356.in, 32
  %shf_shift_64.53 = zext nneg i32 %shf_shift.14 to i64
  %.2602 = lshr i64 %.2601, %shf_shift_64.53
  %shf_hi.29 = lshr i64 %.2602, 32
  br label %BB_4b70

BB_4b70:                                          ; preds = %BB_80004b60, %BB_4b20
  %phi.357.in = phi i64 [ %shf_hi.29, %BB_80004b60 ], [ %phi.356.in, %BB_4b20 ]
  %ffma_lhs_bitcast = bitcast i32 %"R23:R22:R21:R20_r3.3" to float
  %ffma_lhs_bitcast.1 = bitcast i32 %"R23:R22:R21:R20_r2.3" to float
  %ffma_lhs_bitcast.2 = bitcast i32 %"R27:R26:R25:R24_r1.3" to float
  %ffma_lhs_bitcast.3 = bitcast i32 %"R27:R26:R25:R24_r0.3" to float
  %ffma_lhs_bitcast.4 = bitcast i32 %"R27:R26:R25:R24_r2.3" to float
  %ffma_lhs_bitcast.5 = bitcast i32 %"R27:R26:R25:R24_r3.3" to float
  %ffma_lhs_bitcast.6 = bitcast i32 %"R23:R22:R21:R20_r0.3" to float
  %ffma_lhs_bitcast.7 = bitcast i32 %"R23:R22:R21:R20_r1.3" to float
  %ffma.3 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.3, float %phi.292, float %675)
  %ffma.2 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.2, float %phi.292, float %684)
  %ffma.1 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.1, float %phi.292, float %695)
  %.2618 = getelementptr inbounds nuw i8, ptr %param_local, i64 528
  %fmnmx_rhs = load float, ptr %.2618, align 4
  %fmnmx_max = call float @llvm.maximum.f32(float %ffma.1, float %fmnmx_rhs)
  %fmnmx_max.1 = call float @llvm.maximum.f32(float %ffma.2, float %fmnmx_rhs)
  %fmnmx_max.2 = call float @llvm.maximum.f32(float %ffma.3, float %fmnmx_rhs)
  %697 = shl i32 %phi.283, 16
  %698 = lshr exact i32 %697, 3
  %699 = and i32 %698, 268427264
  %700 = icmp samesign ugt i32 %699, 260046847
  %701 = select i1 %700, i32 2139095040, i32 0
  %702 = or i32 %699, %701
  %703 = bitcast i32 %702 to float
  %704 = fmul float %703, 0x46F0000000000000
  %705 = bitcast i32 %697 to float
  %706 = call float @llvm.copysign.f32(float %704, float %705)
  %ffma.4 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.4, float %phi.292, float %706)
  %fmnmx_max.3 = call float @llvm.maximum.f32(float %ffma.4, float %fmnmx_rhs)
  %extelt.offset20 = and i32 %phi.283, -65536
  %707 = lshr i32 %phi.283, 3
  %708 = and i32 %707, 268427264
  %709 = icmp samesign ugt i32 %708, 260046847
  %710 = select i1 %709, i32 2139095040, i32 0
  %711 = or i32 %708, %710
  %712 = bitcast i32 %711 to float
  %713 = fmul float %712, 0x46F0000000000000
  %714 = bitcast i32 %extelt.offset20 to float
  %715 = call float @llvm.copysign.f32(float %713, float %714)
  %ffma.5 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.5, float %phi.292, float %715)
  %fmnmx_max.4 = call float @llvm.maximum.f32(float %ffma.5, float %fmnmx_rhs)
  %716 = shl i32 %phi.282, 16
  %717 = lshr exact i32 %716, 3
  %718 = and i32 %717, 268427264
  %719 = icmp samesign ugt i32 %718, 260046847
  %720 = select i1 %719, i32 2139095040, i32 0
  %721 = or i32 %718, %720
  %722 = bitcast i32 %721 to float
  %723 = fmul float %722, 0x46F0000000000000
  %724 = bitcast i32 %716 to float
  %725 = call float @llvm.copysign.f32(float %723, float %724)
  %hadd2_f32_i32.7 = bitcast float %725 to i32
  %ffma.6 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.6, float %phi.292, float %725)
  %fmnmx_max.5 = call float @llvm.maximum.f32(float %ffma.6, float %fmnmx_rhs)
  %extelt.offset22 = and i32 %phi.282, -65536
  %726 = lshr i32 %phi.282, 3
  %727 = and i32 %726, 268427264
  %728 = icmp samesign ugt i32 %727, 260046847
  %729 = select i1 %728, i32 2139095040, i32 0
  %730 = or i32 %727, %729
  %731 = bitcast i32 %730 to float
  %732 = fmul float %731, 0x46F0000000000000
  %733 = bitcast i32 %extelt.offset22 to float
  %734 = call float @llvm.copysign.f32(float %732, float %733)
  %ffma.7 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.7, float %phi.292, float %734)
  %fmnmx_max.6 = call float @llvm.maximum.f32(float %ffma.7, float %fmnmx_rhs)
  %extelt.offset21 = and i32 %phi.281, -65536
  %735 = lshr i32 %phi.281, 3
  %736 = and i32 %735, 268427264
  %737 = icmp samesign ugt i32 %736, 260046847
  %738 = select i1 %737, i32 2139095040, i32 0
  %739 = or i32 %736, %738
  %740 = bitcast i32 %739 to float
  %741 = fmul float %740, 0x46F0000000000000
  %742 = bitcast i32 %extelt.offset21 to float
  %743 = call float @llvm.copysign.f32(float %741, float %742)
  %ffma = call float @llvm.fma.f32(float %ffma_lhs_bitcast, float %phi.292, float %743)
  %fmnmx_max.7 = call float @llvm.maximum.f32(float %ffma, float %fmnmx_rhs)
  %.2634 = getelementptr inbounds nuw i8, ptr %param_local, i64 544
  %fmnmx_rhs.8 = load float, ptr %.2634, align 4
  %fmnmx_min = call float @llvm.minimum.f32(float %fmnmx_max.1, float %fmnmx_rhs.8)
  %fmnmx_min.1 = call float @llvm.minimum.f32(float %fmnmx_max.2, float %fmnmx_rhs.8)
  %phi_cast_R1599_bitcast = bitcast float %fmnmx_min.1 to i32
  %744 = zext i32 %phi_cast_R1599_bitcast to i64
  %745 = shl nuw i64 %744, 32
  %fmnmx_min.2 = call float @llvm.minimum.f32(float %fmnmx_max, float %fmnmx_rhs.8)
  %fmnmx_min.3 = call float @llvm.minimum.f32(float %fmnmx_max.3, float %fmnmx_rhs.8)
  %fmnmx_min.4 = call float @llvm.minimum.f32(float %fmnmx_max.4, float %fmnmx_rhs.8)
  %fmnmx_min.5 = call float @llvm.minimum.f32(float %fmnmx_max.5, float %fmnmx_rhs.8)
  %fmnmx_min.6 = call float @llvm.minimum.f32(float %fmnmx_max.6, float %fmnmx_rhs.8)
  %fmnmx_min.7 = call float @llvm.minimum.f32(float %fmnmx_max.7, float %fmnmx_rhs.8)
  %746 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.1, float %fmnmx_min)
  %747 = extractvalue { i32, i32 } %746, 0
  %748 = extractvalue { i32, i32 } %746, 1
  %f2fp_a_shift = shl nuw i32 %748, 16
  %f2fp_packed = or disjoint i32 %f2fp_a_shift, %747
  %phi.357 = trunc i64 %phi.357.in to i32
  %.2604 = getelementptr inbounds nuw i8, ptr %param_local, i64 584
  %imad_rhs.111 = load i32, ptr %.2604, align 4
  %imad_tmp.238 = mul i32 %phi.355, %imad_rhs.111
  %imad.260 = add i32 %imad_tmp.238, %imad.259
  %imad_rhs.112 = load i32, ptr %.197, align 4
  %749 = mul i32 %imad_rhs.112, %phi.357
  %imad.261 = sub i32 %phi.354, %749
  %phi.358 = select i1 %isetrp_cmp1.148.not, i32 0, i32 %imad.261
  %phi.359 = select i1 %isetrp_cmp1.148.not, i32 %phi.354, i32 %phi.357
  %.2614 = getelementptr inbounds nuw i8, ptr %param_local, i64 588
  %imad_rhs.113 = load i32, ptr %.2614, align 4
  %imad_tmp.240 = mul i32 %phi.359, %imad_rhs.113
  %imad.262 = add i32 %imad_tmp.240, %imad.260
  %.2616 = getelementptr inbounds nuw i8, ptr %param_local, i64 592
  %imad_rhs.114 = load i32, ptr %.2616, align 4
  %imad_tmp.241 = mul i32 %phi.358, %imad_rhs.114
  %imad.263 = add i32 %imad_tmp.241, %imad.262
  %sel.94 = select i1 %isetrp_cmp2.170, i32 %imad.263, i32 -1
  %isetrp_cmp1.171 = icmp sgt i32 %sel.94, -1
  %750 = zext i32 %sel.94 to i64
  %751 = or disjoint i64 %745, %750
  br i1 %isetrp_cmp1.171, label %BB_80004df0, label %BB_4e00

BB_80004df0:                                      ; preds = %BB_4b70
  %.2655 = getelementptr inbounds nuw i8, ptr %param_local, i64 368
  %imad_addend.42 = load i64, ptr %.2655, align 8
  %752 = shl nuw i32 %sel.94, 1
  %imad_tmp_64.37 = zext i32 %752 to i64
  %753 = add i64 %imad_addend.42, %imad_tmp_64.37
  br label %BB_4e00

BB_4e00:                                          ; preds = %BB_80004df0, %BB_4b70
  %754 = phi i64 [ %753, %BB_80004df0 ], [ %751, %BB_4b70 ]
  %phi_cast_R188_bitcast.1 = bitcast float %fmnmx_min.7 to i32
  br i1 %isetrp_cmp1.171, label %BB_80004e30, label %BB_4e40

BB_80004e30:                                      ; preds = %BB_4e00
  %755 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min.7, float %fmnmx_min.2, float %fmnmx_min.6, float %fmnmx_min.5)
  %756 = extractvalue { i32, i32, i32, i32 } %755, 0
  %757 = extractvalue { i32, i32, i32, i32 } %755, 1
  %758 = extractvalue { i32, i32, i32, i32 } %755, 2
  %759 = extractvalue { i32, i32, i32, i32 } %755, 3
  %f2fp_a_shift.3 = shl nuw i32 %756, 16
  %f2fp_packed.3 = or disjoint i32 %f2fp_a_shift.3, %757
  %f2fp_a_shift.2 = shl nuw i32 %758, 16
  %f2fp_packed.2 = or disjoint i32 %f2fp_a_shift.2, %759
  %760 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.4, float %fmnmx_min.3)
  %761 = extractvalue { i32, i32 } %760, 0
  %762 = extractvalue { i32, i32 } %760, 1
  %f2fp_a_shift.1 = shl nuw i32 %761, 16
  %f2fp_packed.1 = or disjoint i32 %f2fp_a_shift.1, %762
  %stg_val_r0_ext.2 = zext i32 %f2fp_packed to i128
  %stg_val_r1_ext.2 = zext i32 %f2fp_packed.1 to i128
  %stg_val_r1_shift.2 = shl nuw nsw i128 %stg_val_r1_ext.2, 32
  %stg_val_packed_1.2 = or disjoint i128 %stg_val_r1_shift.2, %stg_val_r0_ext.2
  %stg_val_r2_ext.2 = zext i32 %f2fp_packed.2 to i128
  %stg_val_r2_shift.2 = shl nuw nsw i128 %stg_val_r2_ext.2, 64
  %stg_val_packed_2.2 = or disjoint i128 %stg_val_packed_1.2, %stg_val_r2_shift.2
  %stg_val_r3_ext.2 = zext i32 %f2fp_packed.3 to i128
  %stg_val_r3_shift.2 = shl nuw i128 %stg_val_r3_ext.2, 96
  %stg_val_packed_3.2 = or disjoint i128 %stg_val_packed_2.2, %stg_val_r3_shift.2
  %"R1602:R1524_addr_ptr" = inttoptr i64 %754 to ptr addrspace(1)
  store i128 %stg_val_packed_3.2, ptr addrspace(1) %"R1602:R1524_addr_ptr", align 8
  br label %BB_4e40

BB_4e40:                                          ; preds = %BB_80004e30, %BB_4e00, %BB_49a0
  %phi.363 = phi i32 [ %661, %BB_49a0 ], [ %f2fp_packed, %BB_80004e30 ], [ %f2fp_packed, %BB_4e00 ]
  %phi.364 = phi i32 [ %phi.342, %BB_49a0 ], [ %hadd2_f32_i32.7, %BB_80004e30 ], [ %hadd2_f32_i32.7, %BB_4e00 ]
  %phi.365 = phi i32 [ %phi.343, %BB_49a0 ], [ %phi_cast_R188_bitcast.1, %BB_80004e30 ], [ %phi_cast_R188_bitcast.1, %BB_4e00 ]
  call void @llvm.nvvm.barrier0()
  %phi_cast_R2019_bitcast.1 = bitcast float %phi.263 to i32
  %phi_cast_R1998_bitcast.1 = bitcast float %phi.264 to i32
  %763 = zext i32 %phi_cast_R2019_bitcast.1 to i64
  %764 = shl nuw i64 %763, 32
  %765 = zext i32 %phi_cast_R1998_bitcast.1 to i64
  %766 = or disjoint i64 %764, %765
  %phi_cast_R1979_bitcast.1 = bitcast float %phi.265 to i32
  %phi_cast_R1871_bitcast.1 = bitcast float %phi.266 to i32
  %767 = zext i32 %phi_cast_R1979_bitcast.1 to i64
  %768 = shl nuw i64 %767, 32
  %769 = zext i32 %phi_cast_R1871_bitcast.1 to i64
  %770 = or disjoint i64 %768, %769
  %phi_cast_R1719_bitcast.1 = bitcast float %phi.267 to i32
  %phi_cast_R1494_bitcast.1 = bitcast float %phi.268 to i32
  %771 = zext i32 %phi_cast_R1719_bitcast.1 to i64
  %772 = shl nuw i64 %771, 32
  %773 = zext i32 %phi_cast_R1494_bitcast.1 to i64
  %774 = or disjoint i64 %772, %773
  %phi_cast_R1407_bitcast.1 = bitcast float %phi.269 to i32
  %phi_cast_R905_bitcast.1 = bitcast float %phi.270 to i32
  %775 = zext i32 %phi_cast_R1407_bitcast.1 to i64
  %776 = shl nuw i64 %775, 32
  %777 = zext i32 %phi_cast_R905_bitcast.1 to i64
  %778 = or disjoint i64 %776, %777
  br i1 %isetrp_cmp1.165, label %BB_51a0, label %BB_4e60

BB_4e60:                                          ; preds = %BB_4e40
  %imad_tmp.242 = shl i32 %imad_tmp.215, 7
  %imad_tmp.243 = shl i32 %imad.232, 7
  %imad.266 = add i32 %imad_tmp.243, %tid_x
  %779 = sext i32 %imad_tmp.242 to i64
  %isetrp_cmp1.172 = icmp slt i32 %phi.302, 1
  br i1 %isetrp_cmp1.172, label %BB_50d0, label %BB_4eb0

BB_4eb0:                                          ; preds = %BB_4e60
  %imad_tmp.244 = shl i32 %imad.266, 4
  %imad_lhs_64.39 = sext i32 %imad_tmp.242 to i64
  %imad_tmp_64.39 = shl nsw i64 %imad_lhs_64.39, 5
  %780 = add i64 %imad_tmp_64.39, %574
  %.2670 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.54 = load i32, ptr %.2670, align 4
  %781 = sext i32 %imad_tmp.244 to i64
  %782 = mul nsw i64 %779, 48
  %783 = add i64 %782, %574
  %.2678 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.56 = load i32, ptr %.2678, align 4
  %784 = zext i32 %iadd3_o2.54 to i64
  %785 = zext i32 %iadd3_o2.56 to i64
  %786 = shl nuw i64 %785, 32
  %787 = add i64 %780, %781
  %788 = add i64 %787, %784
  %789 = add i64 %788, %786
  %790 = zext i32 %iadd3_o2.54 to i64
  %791 = zext i32 %iadd3_o2.56 to i64
  %792 = shl nuw i64 %791, 32
  %793 = add i64 %783, %781
  %794 = add i64 %793, %790
  %795 = add i64 %794, %792
  br label %BB_4f80

BB_4f80:                                          ; preds = %BB_4f80, %BB_4eb0
  %796 = phi i64 [ %795, %BB_4eb0 ], [ %802, %BB_4f80 ]
  %797 = phi i64 [ %789, %BB_4eb0 ], [ %807, %BB_4f80 ]
  %phi.366 = phi i32 [ 0, %BB_4eb0 ], [ %iadd3_n1.148, %BB_4f80 ]
  %phi.371 = phi float [ %phi.263, %BB_4eb0 ], [ %fadd.15, %BB_4f80 ]
  %phi.372 = phi float [ %phi.264, %BB_4eb0 ], [ %fadd.14, %BB_4f80 ]
  %phi.373 = phi float [ %phi.265, %BB_4eb0 ], [ %fadd.13, %BB_4f80 ]
  %phi.374 = phi float [ %phi.266, %BB_4eb0 ], [ %fadd.12, %BB_4f80 ]
  %phi.375 = phi float [ %phi.267, %BB_4eb0 ], [ %fadd.11, %BB_4f80 ]
  %phi.376 = phi float [ %phi.268, %BB_4eb0 ], [ %fadd.10, %BB_4f80 ]
  %phi.377 = phi float [ %phi.269, %BB_4eb0 ], [ %fadd.9, %BB_4f80 ]
  %phi.378 = phi float [ %phi.270, %BB_4eb0 ], [ %fadd.8, %BB_4f80 ]
  %ldv_volatile.2 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %797) #10
  %ldstrongv_lane3.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 3
  %fadd_lhs_bitcast.11 = bitcast i32 %ldstrongv_lane3.2 to float
  %ldstrongv_lane2.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 2
  %fadd_lhs_bitcast.10 = bitcast i32 %ldstrongv_lane2.2 to float
  %ldstrongv_lane1.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 1
  %fadd_lhs_bitcast.9 = bitcast i32 %ldstrongv_lane1.2 to float
  %ldstrongv_lane0.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 0
  %fadd_lhs_bitcast.8 = bitcast i32 %ldstrongv_lane0.2 to float
  %fadd.8 = fadd float %phi.378, %fadd_lhs_bitcast.8
  %fadd.9 = fadd float %phi.377, %fadd_lhs_bitcast.9
  %fadd.10 = fadd float %phi.376, %fadd_lhs_bitcast.10
  %fadd.11 = fadd float %phi.375, %fadd_lhs_bitcast.11
  %ldv_volatile.3 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %796) #10
  %ldstrongv_lane3.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 3
  %fadd_lhs_bitcast.15 = bitcast i32 %ldstrongv_lane3.3 to float
  %ldstrongv_lane2.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 2
  %fadd_lhs_bitcast.14 = bitcast i32 %ldstrongv_lane2.3 to float
  %ldstrongv_lane1.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 1
  %fadd_lhs_bitcast.13 = bitcast i32 %ldstrongv_lane1.3 to float
  %ldstrongv_lane0.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 0
  %fadd_lhs_bitcast.12 = bitcast i32 %ldstrongv_lane0.3 to float
  %fadd.12 = fadd float %phi.374, %fadd_lhs_bitcast.12
  %fadd.13 = fadd float %phi.373, %fadd_lhs_bitcast.13
  %fadd.14 = fadd float %phi.372, %fadd_lhs_bitcast.14
  %fadd.15 = fadd float %phi.371, %fadd_lhs_bitcast.15
  %iadd3_o2.58 = load i32, ptr %.2433, align 4
  %798 = zext i32 %iadd3_o2.58 to i64
  %799 = add i64 %796, %798
  %iadd3_o2.60 = load i32, ptr %.2435, align 4
  %800 = zext i32 %iadd3_o2.60 to i64
  %801 = shl nuw i64 %800, 32
  %802 = add i64 %799, %801
  %803 = zext i32 %iadd3_o2.60 to i64
  %804 = shl nuw i64 %803, 32
  %iadd3_n1.148 = add i32 %phi.366, 1
  %isetrp_cmp1.173.not = icmp sgt i32 %phi.302, %iadd3_n1.148
  %805 = zext i32 %iadd3_o2.58 to i64
  %806 = add i64 %797, %805
  %807 = add i64 %806, %804
  br i1 %isetrp_cmp1.173.not, label %BB_4f80, label %BB_50d0.loopexit

BB_50d0.loopexit:                                 ; preds = %BB_4f80
  %808 = trunc i64 %796 to i32
  %iadd3_trunc.18 = add i32 %iadd3_o2.58, %808
  %phi_cast_R1911_bitcast = bitcast float %fadd.13 to i32
  %809 = zext i32 %phi_cast_R1911_bitcast to i64
  %810 = shl nuw i64 %809, 32
  %phi_cast_R1894_bitcast = bitcast float %fadd.12 to i32
  %811 = zext i32 %phi_cast_R1894_bitcast to i64
  %812 = or disjoint i64 %810, %811
  %phi_cast_R2021_bitcast = bitcast float %fadd.15 to i32
  %813 = zext i32 %phi_cast_R2021_bitcast to i64
  %814 = shl nuw i64 %813, 32
  %phi_cast_R2000_bitcast = bitcast float %fadd.14 to i32
  %815 = zext i32 %phi_cast_R2000_bitcast to i64
  %816 = or disjoint i64 %814, %815
  %phi_cast_R1606_bitcast = bitcast float %fadd.9 to i32
  %817 = zext i32 %phi_cast_R1606_bitcast to i64
  %818 = shl nuw i64 %817, 32
  %phi_cast_R926_bitcast = bitcast float %fadd.8 to i32
  %819 = zext i32 %phi_cast_R926_bitcast to i64
  %820 = or disjoint i64 %818, %819
  %phi_cast_R1735_bitcast = bitcast float %fadd.11 to i32
  %821 = zext i32 %phi_cast_R1735_bitcast to i64
  %822 = shl nuw i64 %821, 32
  %phi_cast_R1333_bitcast = bitcast float %fadd.10 to i32
  %823 = zext i32 %phi_cast_R1333_bitcast to i64
  %824 = or disjoint i64 %822, %823
  br label %BB_50d0

BB_50d0:                                          ; preds = %BB_50d0.loopexit, %BB_4e60
  %825 = phi i64 [ %766, %BB_4e60 ], [ %816, %BB_50d0.loopexit ]
  %826 = phi i64 [ %774, %BB_4e60 ], [ %824, %BB_50d0.loopexit ]
  %827 = phi i64 [ %770, %BB_4e60 ], [ %812, %BB_50d0.loopexit ]
  %828 = phi i64 [ %778, %BB_4e60 ], [ %820, %BB_50d0.loopexit ]
  %phi.379 = phi i32 [ %phi.363, %BB_4e60 ], [ %ldstrongv_lane0.3, %BB_50d0.loopexit ]
  %phi.380 = phi i32 [ %phi.365, %BB_4e60 ], [ %iadd3_trunc.18, %BB_50d0.loopexit ]
  br i1 %isetrp_cmp2.166, label %BB_51a0, label %BB_50f0

BB_50f0:                                          ; preds = %BB_50d0
  %829 = lshr i64 %826, 32
  %830 = lshr i64 %825, 32
  %imad_lhs_64.40 = sext i32 %imad_tmp.242 to i64
  %imad_tmp_64.40 = shl nsw i64 %imad_lhs_64.40, 5
  %831 = add i64 %imad_tmp_64.40, %574
  %imad_lhs_64.41 = sext i32 %imad.266 to i64
  %imad_tmp_64.41 = shl nsw i64 %imad_lhs_64.41, 4
  %imad.273 = add i64 %imad_tmp_64.41, %831
  %832 = add i64 %imad_tmp_64.41, %831
  %.2700 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.62 = load i32, ptr %.2700, align 4
  %833 = trunc i64 %imad.273 to i32
  %iadd3_trunc.19 = add i32 %iadd3_o2.62, %833
  %.2702 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.63 = load i32, ptr %.2702, align 4
  %834 = and i64 %imad.273, 4294967295
  %835 = zext i32 %iadd3_o2.62 to i64
  %836 = add nuw nsw i64 %834, %835
  %837 = zext i32 %iadd3_o2.62 to i64
  %838 = zext i32 %iadd3_o2.63 to i64
  %839 = shl nuw i64 %838, 32
  %840 = add i64 %832, %837
  %841 = add i64 %840, %839
  %.2707 = shl i32 %imad_tmp.215, 11
  %.2709 = add i32 %.2707, %iadd3_trunc.19
  %stg_val_packed_1.3 = zext i64 %828 to i128
  %.mask26 = and i64 %826, 4294967295
  %stg_val_r2_ext.3 = zext nneg i64 %.mask26 to i128
  %stg_val_r2_shift.3 = shl nuw nsw i128 %stg_val_r2_ext.3, 64
  %stg_val_packed_2.3 = or disjoint i128 %stg_val_r2_shift.3, %stg_val_packed_1.3
  %stg_val_r3_ext.3 = zext nneg i64 %829 to i128
  %stg_val_r3_shift.3 = shl nuw i128 %stg_val_r3_ext.3, 96
  %stg_val_packed_3.3 = or disjoint i128 %stg_val_packed_2.3, %stg_val_r3_shift.3
  %"R1420:R1309_addr_ptr" = inttoptr i64 %841 to ptr addrspace(1)
  store i128 %stg_val_packed_3.3, ptr addrspace(1) %"R1420:R1309_addr_ptr", align 8
  %.2719 = shl nsw i64 %779, 4
  %842 = and i64 %imad.273, -4294967296
  %843 = zext i32 %iadd3_o2.63 to i64
  %844 = shl nuw i64 %843, 32
  %845 = add nsw i64 %836, %.2719
  %846 = add i64 %845, %842
  %847 = add i64 %846, %844
  %stg_val_packed_1.4 = zext i64 %827 to i128
  %.mask31 = and i64 %825, 4294967295
  %stg_val_r2_ext.4 = zext nneg i64 %.mask31 to i128
  %stg_val_r2_shift.4 = shl nuw nsw i128 %stg_val_r2_ext.4, 64
  %stg_val_packed_2.4 = or disjoint i128 %stg_val_r2_shift.4, %stg_val_packed_1.4
  %stg_val_r3_ext.4 = zext nneg i64 %830 to i128
  %stg_val_r3_shift.4 = shl nuw i128 %stg_val_r3_ext.4, 96
  %stg_val_packed_3.4 = or disjoint i128 %stg_val_packed_2.4, %stg_val_r3_shift.4
  %"R102:R1033_addr_ptr" = inttoptr i64 %847 to ptr addrspace(1)
  store i128 %stg_val_packed_3.4, ptr addrspace(1) %"R102:R1033_addr_ptr", align 8
  br label %BB_51a0

BB_51a0:                                          ; preds = %BB_4e40, %BB_50d0, %BB_50f0
  %848 = phi i64 [ %825, %BB_50f0 ], [ %766, %BB_4e40 ], [ %825, %BB_50d0 ]
  %849 = phi i64 [ %826, %BB_50f0 ], [ %774, %BB_4e40 ], [ %826, %BB_50d0 ]
  %850 = phi i64 [ %827, %BB_50f0 ], [ %770, %BB_4e40 ], [ %827, %BB_50d0 ]
  %851 = phi i64 [ %828, %BB_50f0 ], [ %778, %BB_4e40 ], [ %828, %BB_50d0 ]
  %phi.389 = phi i32 [ %.2709, %BB_50f0 ], [ %phi.363, %BB_4e40 ], [ %phi.379, %BB_50d0 ]
  %phi.390 = phi i32 [ %phi.380, %BB_50f0 ], [ %phi.365, %BB_4e40 ], [ %phi.380, %BB_50d0 ]
  br i1 %isetrp_cmp2.166, label %BB_51b0, label %BB_5660

BB_51b0:                                          ; preds = %BB_51a0
  %iadd3_n1.152 = add i32 %iadd3_n1.126, 32
  %852 = zext nneg i32 %imad.217 to i64
  %.2734 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %852
  store volatile i64 %851, ptr addrspace(3) %.2734, align 8
  %sts_addr_memaddr_offset_add.3 = add nuw nsw i32 %imad.217, 16
  %853 = zext nneg i32 %sts_addr_memaddr_offset_add.3 to i64
  %.2736 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %853
  store volatile i64 %850, ptr addrspace(3) %.2736, align 8
  br i1 %isetrp_cmp1.146.not, label %BB_5210, label %BB_80005200

BB_80005200:                                      ; preds = %BB_51b0
  %.2740 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.115 = load i32, ptr %.2740, align 4
  %imad_lhs_64.42 = zext i32 %iadd3_n1.152 to i64
  %imad_rhs_64.42 = zext i32 %imad_rhs.115 to i64
  %imad_tmp_64.42 = mul nuw i64 %imad_lhs_64.42, %imad_rhs_64.42
  %imad_tmp_hi.15 = lshr i64 %imad_tmp_64.42, 32
  %imad_tmp_hi_trunc.15 = trunc nuw i64 %imad_tmp_hi.15 to i32
  br label %BB_5210

BB_5210:                                          ; preds = %BB_80005200, %BB_51b0
  %phi.399 = phi i32 [ %imad_tmp_hi_trunc.15, %BB_80005200 ], [ %iadd3_n1.126, %BB_51b0 ]
  %isetrp_rhs.90 = load i32, ptr %.355, align 4
  %isetrp_cmp1.174.not = icmp slt i32 %iadd3_n1.152, %isetrp_rhs.90
  %sts_addr_memaddr_offset_add.4 = add nuw nsw i32 %imad.217, 1280
  %854 = zext nneg i32 %sts_addr_memaddr_offset_add.4 to i64
  %.2745 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %854
  store volatile i64 %849, ptr addrspace(3) %.2745, align 8
  br i1 %isetrp_cmp1.146.not, label %BB_5240, label %BB_80005230

BB_80005230:                                      ; preds = %BB_5210
  %.2749 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %shf_shift.15 = load i32, ptr %.2749, align 4
  %.2752 = zext i32 %phi.399 to i64
  %.2753 = shl nuw i64 %.2752, 32
  %shf_shift_64.56 = zext nneg i32 %shf_shift.15 to i64
  %.2754 = lshr i64 %.2753, %shf_shift_64.56
  %shf_hi.32 = lshr i64 %.2754, 32
  %shf_result.56 = trunc nuw i64 %shf_hi.32 to i32
  br label %BB_5240

BB_5240:                                          ; preds = %BB_80005230, %BB_5210
  %phi.402 = phi i32 [ %shf_result.56, %BB_80005230 ], [ %iadd3_n1.152, %BB_5210 ]
  %phi.400 = phi i32 [ %shf_result.56, %BB_80005230 ], [ %phi.399, %BB_5210 ]
  %sts_addr_memaddr_offset_add.5 = add nuw nsw i32 %imad.217, 1296
  %855 = zext nneg i32 %sts_addr_memaddr_offset_add.5 to i64
  %.2756 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %855
  store volatile i64 %848, ptr addrspace(3) %.2756, align 8
  call void @llvm.nvvm.barrier0()
  %imad_addend_neg.25 = sub i32 0, %phi.400
  %phi.401 = select i1 %isetrp_cmp1.146.not, i32 %phi.389, i32 %imad_addend_neg.25
  %isetrp_cmp1.175 = icmp slt i32 %.2177, %imad_tmp.216
  %isetrp_cmp2.175 = and i1 %isetrp_cmp1.175, %isetrp_cmp1.174.not
  %imad_rhs.116 = load i32, ptr %.187, align 4
  %imad_tmp.248 = mul i32 %phi.401, %imad_rhs.116
  %imad.275 = add i32 %imad_tmp.248, %iadd3_n1.152
  %phi.403 = select i1 %isetrp_cmp1.146.not, i32 0, i32 %imad.275
  br i1 %isetrp_cmp1.147.not, label %BB_52b0, label %BB_800052a0

BB_800052a0:                                      ; preds = %BB_5240
  %.2767 = getelementptr inbounds nuw i8, ptr %param_local, i64 992
  %imad_rhs.117 = load i32, ptr %.2767, align 4
  %imad_lhs_64.43 = zext i32 %phi.403 to i64
  %imad_rhs_64.43 = zext i32 %imad_rhs.117 to i64
  %imad_tmp_64.43 = mul nuw i64 %imad_lhs_64.43, %imad_rhs_64.43
  %imad_tmp_hi.16 = lshr i64 %imad_tmp_64.43, 32
  %imad_tmp_hi_trunc.16 = trunc nuw i64 %imad_tmp_hi.16 to i32
  br label %BB_52b0

BB_52b0:                                          ; preds = %BB_800052a0, %BB_5240
  %phi.404 = phi i32 [ %imad_tmp_hi_trunc.16, %BB_800052a0 ], [ %phi.390, %BB_5240 ]
  %.2770 = getelementptr inbounds nuw i8, ptr %param_local, i64 596
  %imad_rhs.118 = load i32, ptr %.2770, align 4
  %imad_tmp.249 = mul i32 %.2177, %imad_rhs.118
  br i1 %isetrp_cmp1.147.not, label %BB_52e0, label %BB_800052d0

BB_800052d0:                                      ; preds = %BB_52b0
  %.2774 = getelementptr inbounds nuw i8, ptr %param_local, i64 996
  %shf_shift.16 = load i32, ptr %.2774, align 4
  %.2777 = zext i32 %phi.404 to i64
  %.2778 = shl nuw i64 %.2777, 32
  %shf_shift_64.57 = zext nneg i32 %shf_shift.16 to i64
  %.2779 = lshr i64 %.2778, %shf_shift_64.57
  %shf_hi.33 = lshr i64 %.2779, 32
  %shf_result.57 = trunc nuw i64 %shf_hi.33 to i32
  br label %BB_52e0

BB_52e0:                                          ; preds = %BB_800052d0, %BB_52b0
  %phi.408 = phi i32 [ %shf_result.57, %BB_800052d0 ], [ %phi.403, %BB_52b0 ]
  %phi.405 = phi i32 [ %shf_result.57, %BB_800052d0 ], [ %phi.404, %BB_52b0 ]
  %856 = shl i32 %phi.282, 16
  %857 = lshr exact i32 %856, 3
  %858 = and i32 %857, 268427264
  %859 = icmp samesign ugt i32 %858, 260046847
  %860 = select i1 %859, i32 2139095040, i32 0
  %861 = or i32 %858, %860
  %862 = bitcast i32 %861 to float
  %863 = fmul float %862, 0x46F0000000000000
  %864 = bitcast i32 %856 to float
  %865 = call float @llvm.copysign.f32(float %863, float %864)
  %.2781 = getelementptr inbounds nuw i8, ptr %param_local, i64 580
  %imad_rhs.119 = load i32, ptr %.2781, align 4
  %imad_tmp.250 = mul i32 %phi.402, %imad_rhs.119
  %imad.277 = add i32 %imad_tmp.250, %imad_tmp.249
  %extelt.offset33 = and i32 %phi.282, -65536
  %866 = lshr i32 %phi.282, 3
  %867 = and i32 %866, 268427264
  %868 = icmp samesign ugt i32 %867, 260046847
  %869 = select i1 %868, i32 2139095040, i32 0
  %870 = or i32 %867, %869
  %871 = bitcast i32 %870 to float
  %872 = fmul float %871, 0x46F0000000000000
  %873 = bitcast i32 %extelt.offset33 to float
  %874 = call float @llvm.copysign.f32(float %872, float %873)
  %imad_addend_neg.26 = sub i32 0, %phi.405
  %phi.406 = select i1 %isetrp_cmp1.147.not, i32 %phi.364, i32 %imad_addend_neg.26
  %875 = shl i32 %phi.283, 16
  %876 = lshr exact i32 %875, 3
  %877 = and i32 %876, 268427264
  %878 = icmp samesign ugt i32 %877, 260046847
  %879 = select i1 %878, i32 2139095040, i32 0
  %880 = or i32 %877, %879
  %881 = bitcast i32 %880 to float
  %882 = fmul float %881, 0x46F0000000000000
  %883 = bitcast i32 %875 to float
  %884 = call float @llvm.copysign.f32(float %882, float %883)
  %extelt.offset34 = and i32 %phi.283, -65536
  %885 = lshr i32 %phi.283, 3
  %886 = and i32 %885, 268427264
  %887 = icmp samesign ugt i32 %886, 260046847
  %888 = select i1 %887, i32 2139095040, i32 0
  %889 = or i32 %886, %888
  %890 = bitcast i32 %889 to float
  %891 = fmul float %890, 0x46F0000000000000
  %892 = bitcast i32 %extelt.offset34 to float
  %893 = call float @llvm.copysign.f32(float %891, float %892)
  %imad_rhs.120 = load i32, ptr %.193, align 4
  %imad_tmp.252 = mul i32 %phi.406, %imad_rhs.120
  %imad.279 = add i32 %imad_tmp.252, %phi.403
  %phi.407 = select i1 %isetrp_cmp1.147.not, i32 0, i32 %imad.279
  %lds_shared_addr_winoff.2.xscale = shl i32 %imad.219, 4
  %lds_shared_addr_winoff.2 = and i32 %lds_shared_addr_winoff.2.xscale, 16777200
  %894 = zext nneg i32 %lds_shared_addr_winoff.2 to i64
  %.2791 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %894
  %lds.2 = load volatile i128, ptr addrspace(3) %.2791, align 8
  %"R7:R6:R5:R4_r0" = trunc i128 %lds.2 to i32
  %"R7:R6:R5:R4_r1_shift" = lshr i128 %lds.2, 32
  %"R7:R6:R5:R4_r1" = trunc i128 %"R7:R6:R5:R4_r1_shift" to i32
  %"R7:R6:R5:R4_r2_shift" = lshr i128 %lds.2, 64
  %"R7:R6:R5:R4_r2" = trunc i128 %"R7:R6:R5:R4_r2_shift" to i32
  %"R7:R6:R5:R4_r3_shift" = lshr i128 %lds.2, 96
  %"R7:R6:R5:R4_r3" = trunc nuw i128 %"R7:R6:R5:R4_r3_shift" to i32
  %895 = shl i32 %phi.281, 16
  %896 = lshr exact i32 %895, 3
  %897 = and i32 %896, 268427264
  %898 = icmp samesign ugt i32 %897, 260046847
  %899 = select i1 %898, i32 2139095040, i32 0
  %900 = or i32 %897, %899
  %901 = bitcast i32 %900 to float
  %902 = fmul float %901, 0x46F0000000000000
  %903 = bitcast i32 %895 to float
  %904 = call float @llvm.copysign.f32(float %902, float %903)
  br i1 %isetrp_cmp1.148.not, label %BB_5390, label %BB_80005380

BB_80005380:                                      ; preds = %BB_52e0
  %.2797 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.121 = load i32, ptr %.2797, align 4
  %imad_lhs_64.44 = zext i32 %phi.407 to i64
  %imad_rhs_64.44 = zext i32 %imad_rhs.121 to i64
  %imad_tmp_64.44 = mul nuw i64 %imad_lhs_64.44, %imad_rhs_64.44
  %imad_tmp_hi.17 = lshr i64 %imad_tmp_64.44, 32
  br label %BB_5390

BB_5390:                                          ; preds = %BB_80005380, %BB_52e0
  %phi.409.in = phi i64 [ %imad_tmp_hi.17, %BB_80005380 ], [ %851, %BB_52e0 ]
  %lds_addr_memaddr_offset_add.1 = add i32 %lds_shared_addr_winoff.2.xscale, 80
  %lds_shared_addr_winoff.3 = and i32 %lds_addr_memaddr_offset_add.1, 16777200
  %905 = zext nneg i32 %lds_shared_addr_winoff.3 to i64
  %.2800 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %905
  %lds.3 = load volatile i128, ptr addrspace(3) %.2800, align 8
  %"R11:R10:R9:R8_r0" = trunc i128 %lds.3 to i32
  %"R11:R10:R9:R8_r1_shift" = lshr i128 %lds.3, 32
  %"R11:R10:R9:R8_r1" = trunc i128 %"R11:R10:R9:R8_r1_shift" to i32
  %"R11:R10:R9:R8_r2_shift" = lshr i128 %lds.3, 64
  %"R11:R10:R9:R8_r2" = trunc i128 %"R11:R10:R9:R8_r2_shift" to i32
  %"R11:R10:R9:R8_r3_shift" = lshr i128 %lds.3, 96
  %"R11:R10:R9:R8_r3" = trunc nuw i128 %"R11:R10:R9:R8_r3_shift" to i32
  %extelt.offset35 = and i32 %phi.281, -65536
  %906 = lshr i32 %phi.281, 3
  %907 = and i32 %906, 268427264
  %908 = icmp samesign ugt i32 %907, 260046847
  %909 = select i1 %908, i32 2139095040, i32 0
  %910 = or i32 %907, %909
  %911 = bitcast i32 %910 to float
  %912 = fmul float %911, 0x46F0000000000000
  %913 = bitcast i32 %extelt.offset35 to float
  %914 = call float @llvm.copysign.f32(float %912, float %913)
  %.2801 = getelementptr inbounds nuw i8, ptr %param_local, i64 584
  %imad_rhs.122 = load i32, ptr %.2801, align 4
  %imad_tmp.253 = mul i32 %phi.408, %imad_rhs.122
  %imad.280 = add i32 %imad_tmp.253, %imad.277
  br i1 %isetrp_cmp1.148.not, label %BB_5400, label %BB_800053c0

BB_800053c0:                                      ; preds = %BB_5390
  %.2805 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.17 = load i32, ptr %.2805, align 4
  %.2809 = shl i64 %phi.409.in, 32
  %shf_shift_64.58 = zext nneg i32 %shf_shift.17 to i64
  %.2810 = lshr i64 %.2809, %shf_shift_64.58
  %shf_hi.34 = lshr i64 %.2810, 32
  %shf_result.58 = trunc nuw i64 %shf_hi.34 to i32
  %imad_rhs.123 = load i32, ptr %.197, align 4
  %915 = mul i32 %imad_rhs.123, %shf_result.58
  %imad.282 = sub i32 %phi.407, %915
  br label %BB_5400

BB_5400:                                          ; preds = %BB_800053c0, %BB_5390
  %phi.410 = phi i32 [ %shf_result.58, %BB_800053c0 ], [ %phi.407, %BB_5390 ]
  %phi.411 = phi i32 [ %imad.282, %BB_800053c0 ], [ 0, %BB_5390 ]
  %ffma_lhs_bitcast.8 = bitcast i32 %"R7:R6:R5:R4_r1" to float
  %ffma_lhs_bitcast.9 = bitcast i32 %"R7:R6:R5:R4_r2" to float
  %ffma_lhs_bitcast.10 = bitcast i32 %"R7:R6:R5:R4_r0" to float
  %ffma_lhs_bitcast.11 = bitcast i32 %"R7:R6:R5:R4_r3" to float
  %ffma_lhs_bitcast.12 = bitcast i32 %"R11:R10:R9:R8_r0" to float
  %ffma_lhs_bitcast.13 = bitcast i32 %"R11:R10:R9:R8_r1" to float
  %ffma_lhs_bitcast.14 = bitcast i32 %"R11:R10:R9:R8_r2" to float
  %ffma_lhs_bitcast.15 = bitcast i32 %"R11:R10:R9:R8_r3" to float
  %ffma.15 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.15, float %phi.292, float %914)
  %ffma.14 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.14, float %phi.292, float %904)
  %ffma.13 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.13, float %phi.292, float %874)
  %ffma.12 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.12, float %phi.292, float %865)
  %ffma.11 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.11, float %phi.292, float %893)
  %ffma.9 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.9, float %phi.292, float %884)
  %extelt.offset36 = and i32 %phi.284, -65536
  %916 = lshr i32 %phi.284, 3
  %917 = and i32 %916, 268427264
  %918 = icmp samesign ugt i32 %917, 260046847
  %919 = select i1 %918, i32 2139095040, i32 0
  %920 = or i32 %917, %919
  %921 = bitcast i32 %920 to float
  %922 = fmul float %921, 0x46F0000000000000
  %923 = bitcast i32 %extelt.offset36 to float
  %924 = call float @llvm.copysign.f32(float %922, float %923)
  %ffma.8 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.8, float %phi.292, float %924)
  %.2818 = getelementptr inbounds nuw i8, ptr %param_local, i64 528
  %fmnmx_rhs.16 = load float, ptr %.2818, align 4
  %fmnmx_max.8 = call float @llvm.maximum.f32(float %ffma.8, float %fmnmx_rhs.16)
  %fmnmx_max.9 = call float @llvm.maximum.f32(float %ffma.9, float %fmnmx_rhs.16)
  %925 = shl i32 %phi.284, 16
  %926 = lshr exact i32 %925, 3
  %927 = and i32 %926, 268427264
  %928 = icmp samesign ugt i32 %927, 260046847
  %929 = select i1 %928, i32 2139095040, i32 0
  %930 = or i32 %927, %929
  %931 = bitcast i32 %930 to float
  %932 = fmul float %931, 0x46F0000000000000
  %933 = bitcast i32 %925 to float
  %934 = call float @llvm.copysign.f32(float %932, float %933)
  %ffma.10 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.10, float %phi.292, float %934)
  %fmnmx_max.10 = call float @llvm.maximum.f32(float %ffma.10, float %fmnmx_rhs.16)
  %fmnmx_max.11 = call float @llvm.maximum.f32(float %ffma.11, float %fmnmx_rhs.16)
  %fmnmx_max.12 = call float @llvm.maximum.f32(float %ffma.12, float %fmnmx_rhs.16)
  %fmnmx_max.13 = call float @llvm.maximum.f32(float %ffma.13, float %fmnmx_rhs.16)
  %fmnmx_max.14 = call float @llvm.maximum.f32(float %ffma.14, float %fmnmx_rhs.16)
  %fmnmx_max.15 = call float @llvm.maximum.f32(float %ffma.15, float %fmnmx_rhs.16)
  %.2834 = getelementptr inbounds nuw i8, ptr %param_local, i64 544
  %fmnmx_rhs.24 = load float, ptr %.2834, align 4
  %fmnmx_min.8 = call float @llvm.minimum.f32(float %fmnmx_max.8, float %fmnmx_rhs.24)
  %fmnmx_min.9 = call float @llvm.minimum.f32(float %fmnmx_max.9, float %fmnmx_rhs.24)
  %fmnmx_min.10 = call float @llvm.minimum.f32(float %fmnmx_max.10, float %fmnmx_rhs.24)
  %phi_cast_R716_bitcast = bitcast float %fmnmx_min.10 to i32
  %935 = zext i32 %phi_cast_R716_bitcast to i64
  %936 = shl nuw i64 %935, 32
  %fmnmx_min.11 = call float @llvm.minimum.f32(float %fmnmx_max.11, float %fmnmx_rhs.24)
  %fmnmx_min.12 = call float @llvm.minimum.f32(float %fmnmx_max.12, float %fmnmx_rhs.24)
  %fmnmx_min.13 = call float @llvm.minimum.f32(float %fmnmx_max.13, float %fmnmx_rhs.24)
  %937 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.10, float %fmnmx_min.8)
  %938 = extractvalue { i32, i32 } %937, 0
  %939 = extractvalue { i32, i32 } %937, 1
  %f2fp_a_shift.4 = shl nuw i32 %939, 16
  %f2fp_packed.4 = or disjoint i32 %f2fp_a_shift.4, %938
  %fmnmx_rhs.30 = load float, ptr %.2834, align 4
  %fmnmx_min.14 = call float @llvm.minimum.f32(float %fmnmx_max.14, float %fmnmx_rhs.30)
  %fmnmx_min.15 = call float @llvm.minimum.f32(float %fmnmx_max.15, float %fmnmx_rhs.30)
  %.2814 = getelementptr inbounds nuw i8, ptr %param_local, i64 588
  %imad_rhs.124 = load i32, ptr %.2814, align 4
  %imad_tmp.256 = mul i32 %phi.410, %imad_rhs.124
  %imad.283 = add i32 %imad_tmp.256, %imad.280
  %.2816 = getelementptr inbounds nuw i8, ptr %param_local, i64 592
  %imad_rhs.125 = load i32, ptr %.2816, align 4
  %imad_tmp.257 = mul i32 %phi.411, %imad_rhs.125
  %imad.284 = add i32 %imad_tmp.257, %imad.283
  %sel.95 = select i1 %isetrp_cmp2.175, i32 %imad.284, i32 -1
  %isetrp_cmp1.176 = icmp sgt i32 %sel.95, -1
  %940 = zext i32 %sel.95 to i64
  %941 = or disjoint i64 %936, %940
  br i1 %isetrp_cmp1.176, label %BB_80005600, label %BB_5610

BB_80005600:                                      ; preds = %BB_5400
  %.2855 = getelementptr inbounds nuw i8, ptr %param_local, i64 368
  %imad_addend.43 = load i64, ptr %.2855, align 8
  %942 = shl nuw i32 %sel.95, 1
  %imad_tmp_64.45 = zext i32 %942 to i64
  %943 = add i64 %imad_addend.43, %imad_tmp_64.45
  br label %BB_5610

BB_5610:                                          ; preds = %BB_80005600, %BB_5400
  %944 = phi i64 [ %943, %BB_80005600 ], [ %941, %BB_5400 ]
  br i1 %isetrp_cmp1.176, label %BB_80005640, label %BB_5660

BB_80005640:                                      ; preds = %BB_5610
  %945 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min.15, float %fmnmx_min.14, float %fmnmx_min.13, float %fmnmx_min.12)
  %946 = extractvalue { i32, i32, i32, i32 } %945, 0
  %947 = extractvalue { i32, i32, i32, i32 } %945, 1
  %948 = extractvalue { i32, i32, i32, i32 } %945, 2
  %949 = extractvalue { i32, i32, i32, i32 } %945, 3
  %f2fp_a_shift.7 = shl nuw i32 %946, 16
  %f2fp_packed.7 = or disjoint i32 %f2fp_a_shift.7, %947
  %f2fp_a_shift.6 = shl nuw i32 %948, 16
  %f2fp_packed.6 = or disjoint i32 %f2fp_a_shift.6, %949
  %950 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.11, float %fmnmx_min.9)
  %951 = extractvalue { i32, i32 } %950, 0
  %952 = extractvalue { i32, i32 } %950, 1
  %f2fp_a_shift.5 = shl nuw i32 %951, 16
  %f2fp_packed.5 = or disjoint i32 %f2fp_a_shift.5, %952
  %stg_val_r0_ext.5 = zext i32 %f2fp_packed.4 to i128
  %stg_val_r1_ext.5 = zext i32 %f2fp_packed.5 to i128
  %stg_val_r1_shift.5 = shl nuw nsw i128 %stg_val_r1_ext.5, 32
  %stg_val_packed_1.5 = or disjoint i128 %stg_val_r1_shift.5, %stg_val_r0_ext.5
  %stg_val_r2_ext.5 = zext i32 %f2fp_packed.6 to i128
  %stg_val_r2_shift.5 = shl nuw nsw i128 %stg_val_r2_ext.5, 64
  %stg_val_packed_2.5 = or disjoint i128 %stg_val_packed_1.5, %stg_val_r2_shift.5
  %stg_val_r3_ext.5 = zext i32 %f2fp_packed.7 to i128
  %stg_val_r3_shift.5 = shl nuw i128 %stg_val_r3_ext.5, 96
  %stg_val_packed_3.5 = or disjoint i128 %stg_val_packed_2.5, %stg_val_r3_shift.5
  %"R718:R744_addr_ptr" = inttoptr i64 %944 to ptr addrspace(1)
  store i128 %stg_val_packed_3.5, ptr addrspace(1) %"R718:R744_addr_ptr", align 8
  br label %BB_5660

BB_5660:                                          ; preds = %BB_51a0, %BB_5610, %BB_80005640
  %953 = zext i1 %isetrp_cmp1.177.not to i32
  %954 = icmp ne i32 %953, 0
  br i1 %954, label %BB_5670, label %BB_71b0

BB_5670:                                          ; preds = %BB_5660
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.178.not = icmp eq i32 %tid_x, 0
  br i1 %isetrp_cmp1.178.not, label %BB_56f0, label %BB_71b0

BB_56f0:                                          ; preds = %BB_5670
  %warp_reconv_mask.1 = call i32 asm sideeffect "activemask.b32 $0;", "=r"() #10
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  call void @llvm.nvvm.membar.gl()
  br i1 %isetrp_cmp2.149, label %BB_5760, label %BB_5740

BB_5740:                                          ; preds = %BB_56f0
  %red_add = atomicrmw add ptr addrspace(1) %phi.303, i32 1 monotonic, align 4
  br label %BB_5760

BB_5760:                                          ; preds = %BB_5740, %BB_56f0
  %red_ptr.1 = inttoptr i64 %phi.304 to ptr addrspace(1)
  %red_add.1 = atomicrmw add ptr addrspace(1) %red_ptr.1, i32 1 monotonic, align 4
  br label %BB_71b0

BB_5810:                                          ; preds = %BB_3ea0
  %isetrp_cmp1.179.not = icmp eq i32 %ldc_const.25, 1
  br i1 %isetrp_cmp1.179.not, label %BB_5dd0, label %BB_5820

BB_5820:                                          ; preds = %BB_5810
  %.2884 = getelementptr inbounds nuw i8, ptr %param_local, i64 660
  %ldc_const.32 = load i32, ptr %.2884, align 4
  %.2886 = getelementptr inbounds nuw i8, ptr %param_local, i64 664
  %imad_addend.44 = load i32, ptr %.2886, align 4
  %isetrp_cmp1.180.not = icmp ne i32 %ldc_const.25, %ldc_const.32
  %isetrp_cmp1.181 = icmp ne i32 %imad_addend.44, 2
  %brmerge80 = select i1 %isetrp_cmp1.180.not, i1 true, i1 %isetrp_cmp1.181
  br i1 %brmerge80, label %BB_5890, label %BB_5dd0

BB_5890:                                          ; preds = %BB_5820
  %isetrp_cmp1.182 = icmp eq i32 %imad_addend.44, 1
  %brmerge82.not = select i1 %isetrp_cmp2.149, i1 %isetrp_cmp1.182, i1 false
  br i1 %brmerge82.not, label %BB_5c50, label %BB_58c0

BB_58c0:                                          ; preds = %BB_5890
  %iabs_src.1 = load i32, ptr %.2884, align 4
  %iabs.2 = call i32 @llvm.abs.i32(i32 %iabs_src.1, i1 false)
  %iabs.3 = call i32 @llvm.abs.i32(i32 %ctaid_z, i1 false)
  %i2f_directed.1 = call float asm "cvt.rp.f32.s32 $0, $1;", "=f,r"(i32 %iabs.2) #10
  %mufu_rcp.1 = call float @llvm.nvvm.rcp.approx.ftz.f(float %i2f_directed.1)
  %cast.2 = bitcast float %mufu_rcp.1 to i32
  %iadd3_n1.153 = add i32 %cast.2, 268435454
  %cast.3 = bitcast i32 %iadd3_n1.153 to float
  %f2i.1 = fptoui float %cast.3 to i32
  %955 = mul i32 %iabs.2, %f2i.1
  %imad_tmp.262 = sub i32 0, %955
  %imad_addend_r1_ext.41 = zext i32 %f2i.1 to i64
  %imad_rhs_64.46 = zext i32 %imad_tmp.262 to i64
  %imad_addend_r1_shift.4137 = or disjoint i64 %imad_rhs_64.46, 4294967296
  %imad.291 = mul i64 %imad_addend_r1_shift.4137, %imad_addend_r1_ext.41
  %"UR11:UR10_r1_shift.5" = lshr i64 %imad.291, 32
  %imad_rhs_64.47 = zext i32 %iabs.3 to i64
  %imad_tmp_64.47 = mul nuw i64 %"UR11:UR10_r1_shift.5", %imad_rhs_64.47
  %"UR11:UR10_r1_shift.6" = lshr i64 %imad_tmp_64.47, 32
  %"UR11:UR10_r1.6" = trunc nuw i64 %"UR11:UR10_r1_shift.6" to i32
  %956 = mul i32 %iabs.2, %"UR11:UR10_r1.6"
  %imad.293 = sub i32 %iabs.3, %956
  %isetrp_cmp1.183.not = icmp ule i32 %iabs.2, %imad.293
  %iadd3_n1.157 = zext i1 %isetrp_cmp1.183.not to i32
  %phi.415 = add i32 %"UR11:UR10_r1.6", %iadd3_n1.157
  %iadd3_n1.156 = select i1 %isetrp_cmp1.183.not, i32 %iabs.2, i32 0
  %phi.416 = sub nuw i32 %imad.293, %iadd3_n1.156
  %ldc_const.33 = load i32, ptr %.2884, align 4
  %.2921 = xor i32 %ldc_const.33, %ctaid_z
  %isetrp_cmp1.185 = icmp slt i32 %.2921, 0
  %isetrp_cmp1.184.not = icmp uge i32 %phi.416, %iabs.2
  %iadd3_n1.158 = zext i1 %isetrp_cmp1.184.not to i32
  %phi.417 = add i32 %phi.415, %iadd3_n1.158
  %isetrp_cmp1.186.not = icmp eq i32 %ldc_const.33, 0
  %iadd3_o1_neg.14 = sub i32 0, %phi.417
  %phi.418 = select i1 %isetrp_cmp1.185, i32 %iadd3_o1_neg.14, i32 %phi.417
  %phi.419 = select i1 %isetrp_cmp1.186.not, i32 -1, i32 %phi.418
  %isetrp_cmp1.187.not = icmp eq i32 %phi.419, 0
  %957 = mul i32 %phi.419, %ldc_const.33
  %imad.294 = sub i32 %ctaid_z, %957
  %not.isetrp_cmp1.187.not = xor i1 %isetrp_cmp1.187.not, true
  %sel.96 = zext i1 %not.isetrp_cmp1.187.not to i32
  %imad_tmp.265 = mul i32 %imad_tmp.215, %imad.294
  %imad.295 = add i32 %imad_tmp.265, %imad.232
  %.2947 = getelementptr inbounds nuw i8, ptr %param_local, i64 696
  %imad_addend.45 = load i64, ptr %.2947, align 8
  %imad_lhs_64.48 = sext i32 %imad.295 to i64
  %imad_tmp_64.48 = shl nsw i64 %imad_lhs_64.48, 2
  %imad.297 = add i64 %imad_tmp_64.48, %imad_addend.45
  %958 = add i64 %imad_tmp_64.48, %imad_addend.45
  %.2949 = getelementptr inbounds nuw i8, ptr %param_local, i64 704
  %imad_addend.46 = load i64, ptr %.2949, align 8
  %imad_lhs_64.49 = sext i32 %imad.232 to i64
  %imad_tmp_64.49 = shl nsw i64 %imad_lhs_64.49, 2
  %imad.298 = add i64 %imad_tmp_64.49, %imad_addend.46
  %isetrp_cmp1.189 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.189 = or i1 %isetrp_cmp1.189, %isetrp_cmp1.187.not
  br i1 %isetrp_cmp2.189, label %BB_5c00, label %BB_5b70.preheader

BB_5b70.preheader:                                ; preds = %BB_58c0
  br label %BB_5b70

BB_5b70:                                          ; preds = %BB_5b70.preheader, %BB_5b70
  %ld_volatile.2 = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %958) #10
  %isetrp_cmp1.190.not = icmp eq i32 %ld_volatile.2, %phi.419
  br i1 %isetrp_cmp1.190.not, label %BB_5c00.loopexit, label %BB_5b70

BB_5c00.loopexit:                                 ; preds = %BB_5b70
  br label %BB_5c00

BB_5c00:                                          ; preds = %BB_5c00.loopexit, %BB_58c0
  call void @llvm.nvvm.barrier0()
  %phi_cast_R845_zext = and i64 %imad.297, 4294967295
  %phi_cast_R811_zext = and i64 %imad.298, 4294967295
  %959 = inttoptr i64 %phi_cast_R845_zext to ptr addrspace(1)
  br label %BB_5dd0

BB_5c50:                                          ; preds = %BB_5890
  %isetrp_cmp1.191.not = icmp eq i32 %iadd3_n1.127, 0
  %ldc_const.34 = load i32, ptr %.2884, align 4
  %isetrp_cmp1.192 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.192 = or i1 %isetrp_cmp1.192, %isetrp_cmp1.191.not
  %not.isetrp_cmp1.180.not = xor i1 %isetrp_cmp1.180.not, true
  %iadd3_n1.161 = sext i1 %not.isetrp_cmp1.180.not to i32
  %phi.420 = add i32 %ldc_const.34, %iadd3_n1.161
  %.2961 = getelementptr inbounds nuw i8, ptr %param_local, i64 704
  %imad_addend.47 = load i64, ptr %.2961, align 8
  %imad_lhs_64.50 = sext i32 %imad.232 to i64
  %imad_tmp_64.50 = shl nsw i64 %imad_lhs_64.50, 2
  %imad.300 = add i64 %imad_tmp_64.50, %imad_addend.47
  %960 = add i64 %imad_tmp_64.50, %imad_addend.47
  br i1 %isetrp_cmp2.192, label %BB_5d80, label %BB_5cf0.preheader

BB_5cf0.preheader:                                ; preds = %BB_5c50
  br label %BB_5cf0

BB_5cf0:                                          ; preds = %BB_5cf0.preheader, %BB_5cf0
  %ld_volatile.3 = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %960) #10
  %isetrp_cmp1.193.not = icmp eq i32 %ld_volatile.3, %iadd3_n1.127
  br i1 %isetrp_cmp1.193.not, label %BB_5d80.loopexit, label %BB_5cf0

BB_5d80.loopexit:                                 ; preds = %BB_5cf0
  br label %BB_5d80

BB_5d80:                                          ; preds = %BB_5d80.loopexit, %BB_5c50
  call void @llvm.nvvm.barrier0()
  %phi_cast_R810_zext = and i64 %imad.300, 4294967295
  br label %BB_5dd0

BB_5dd0:                                          ; preds = %BB_5820, %BB_5d80, %BB_5c00, %BB_5810
  %isetrp_cmp1.206.not = phi i1 [ true, %BB_5c00 ], [ true, %BB_5d80 ], [ false, %BB_5810 ], [ false, %BB_5820 ]
  %phi.422 = phi i32 [ %imad.294, %BB_5c00 ], [ 0, %BB_5d80 ], [ 0, %BB_5810 ], [ %ctaid_z, %BB_5820 ]
  %phi.423 = phi ptr addrspace(1) [ %959, %BB_5c00 ], [ null, %BB_5d80 ], [ null, %BB_5810 ], [ null, %BB_5820 ]
  %phi.424 = phi i64 [ %phi_cast_R811_zext, %BB_5c00 ], [ %phi_cast_R810_zext, %BB_5d80 ], [ 0, %BB_5810 ], [ 0, %BB_5820 ]
  %phi.425 = phi i32 [ %sel.96, %BB_5c00 ], [ %phi.420, %BB_5d80 ], [ 0, %BB_5810 ], [ 0, %BB_5820 ]
  %phi.426 = phi i32 [ %iadd3_n1.153, %BB_5c00 ], [ %phi.293, %BB_5d80 ], [ %phi.293, %BB_5810 ], [ %phi.293, %BB_5820 ]
  %phi.427 = phi i32 [ %iabs.3, %BB_5c00 ], [ %s2ur_ctaid_y, %BB_5d80 ], [ %s2ur_ctaid_y, %BB_5810 ], [ %s2ur_ctaid_y, %BB_5820 ]
  %mov.15 = load i32, ptr %.2316, align 4
  %.2970 = getelementptr inbounds nuw i8, ptr %param_local, i64 664
  %ldc_const.35 = load i32, ptr %.2970, align 4
  %961 = sext i32 %phi.422 to i64
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.195 = icmp eq i32 %ldc_const.35, 1
  %isetrp_cmp2.195 = and i1 %isetrp_cmp1.195, %isetrp_cmp2.149
  %.2976 = getelementptr inbounds nuw i8, ptr %param_local, i64 672
  %imad_rhs.126 = load i32, ptr %.2976, align 4
  %.2978 = getelementptr inbounds nuw i8, ptr %param_local, i64 676
  %imad_rhs.127 = load i32, ptr %.2978, align 4
  %962 = zext i32 %imad_rhs.127 to i64
  %963 = shl nuw i64 %962, 32
  %964 = zext i32 %imad_rhs.126 to i64
  %965 = or disjoint i64 %963, %964
  %966 = mul i64 %965, %961
  %isetrp_cmp1.194 = icmp slt i32 %mov.15, 2
  %phi_cast_R1587_bitcast.3 = bitcast float %phi.250 to i32
  %phi_cast_R1507_bitcast.3 = bitcast float %phi.251 to i32
  %967 = zext i32 %phi_cast_R1587_bitcast.3 to i64
  %968 = shl nuw i64 %967, 32
  %969 = zext i32 %phi_cast_R1507_bitcast.3 to i64
  %970 = or disjoint i64 %968, %969
  %phi_cast_R1400_bitcast.3 = bitcast float %phi.252 to i32
  %phi_cast_R1287_bitcast.3 = bitcast float %phi.253 to i32
  %971 = zext i32 %phi_cast_R1400_bitcast.3 to i64
  %972 = shl nuw i64 %971, 32
  %973 = zext i32 %phi_cast_R1287_bitcast.3 to i64
  %974 = or disjoint i64 %972, %973
  %phi_cast_R1939_bitcast.3 = bitcast float %phi.254 to i32
  %phi_cast_R1007_bitcast.3 = bitcast float %phi.257 to i32
  %975 = zext i32 %phi_cast_R1939_bitcast.3 to i64
  %976 = shl nuw i64 %975, 32
  %977 = zext i32 %phi_cast_R1007_bitcast.3 to i64
  %978 = or disjoint i64 %976, %977
  %phi_cast_R1232_bitcast.3 = bitcast float %phi.271 to i32
  %phi_cast_R179_bitcast.3 = bitcast float %phi.272 to i32
  %979 = zext i32 %phi_cast_R1232_bitcast.3 to i64
  %980 = shl nuw i64 %979, 32
  %981 = zext i32 %phi_cast_R179_bitcast.3 to i64
  %982 = or disjoint i64 %980, %981
  br i1 %isetrp_cmp1.194, label %BB_6120, label %BB_5e80

BB_5e80:                                          ; preds = %BB_5dd0
  %imad_tmp.270 = shl i32 %imad_tmp.215, 7
  %imad_tmp.271 = shl i32 %imad.232, 7
  %imad.305 = add i32 %imad_tmp.271, %tid_x
  %.2985 = zext i32 %imad_tmp.270 to i64
  %983 = sext i32 %imad_tmp.270 to i64
  %isetrp_cmp1.196 = icmp slt i32 %phi.425, 1
  br i1 %isetrp_cmp1.196, label %BB_6070, label %BB_5ed0

BB_5ed0:                                          ; preds = %BB_5e80
  %imad_tmp.272 = shl i32 %imad.305, 4
  %.2999 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.64 = load i32, ptr %.2999, align 4
  %984 = sext i32 %imad_tmp.272 to i64
  %.3010 = shl nsw i64 %983, 4
  %985 = add i64 %966, %.3010
  %.3016 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.65 = load i32, ptr %.3016, align 4
  %986 = zext i32 %iadd3_o2.64 to i64
  %987 = zext i32 %iadd3_o2.65 to i64
  %988 = shl nuw i64 %987, 32
  %989 = add i64 %985, %984
  %990 = add i64 %989, %986
  %991 = add i64 %990, %988
  %992 = zext i32 %iadd3_o2.64 to i64
  %993 = zext i32 %iadd3_o2.65 to i64
  %994 = shl nuw i64 %993, 32
  %995 = add i64 %966, %984
  %996 = add i64 %995, %992
  %997 = add i64 %996, %994
  br label %BB_5f60

BB_5f60:                                          ; preds = %BB_5f60, %BB_5ed0
  %998 = phi i64 [ %991, %BB_5ed0 ], [ %1006, %BB_5f60 ]
  %999 = phi i64 [ %997, %BB_5ed0 ], [ %1009, %BB_5f60 ]
  %phi.428 = phi i32 [ 0, %BB_5ed0 ], [ %iadd3_n1.166, %BB_5f60 ]
  %phi.429 = phi float [ %phi.250, %BB_5ed0 ], [ %fadd.21, %BB_5f60 ]
  %phi.430 = phi float [ %phi.251, %BB_5ed0 ], [ %fadd.20, %BB_5f60 ]
  %phi.431 = phi float [ %phi.252, %BB_5ed0 ], [ %fadd.19, %BB_5f60 ]
  %phi.432 = phi float [ %phi.253, %BB_5ed0 ], [ %fadd.18, %BB_5f60 ]
  %phi.437 = phi float [ %phi.254, %BB_5ed0 ], [ %fadd.17, %BB_5f60 ]
  %phi.438 = phi float [ %phi.257, %BB_5ed0 ], [ %fadd.16, %BB_5f60 ]
  %phi.439 = phi float [ %phi.271, %BB_5ed0 ], [ %fadd.23, %BB_5f60 ]
  %phi.440 = phi float [ %phi.272, %BB_5ed0 ], [ %fadd.22, %BB_5f60 ]
  %ldv_volatile.4 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %999) #10
  %ldstrongv_lane3.4 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.4, 3
  %fadd_lhs_bitcast.19 = bitcast i32 %ldstrongv_lane3.4 to float
  %ldstrongv_lane2.4 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.4, 2
  %fadd_lhs_bitcast.18 = bitcast i32 %ldstrongv_lane2.4 to float
  %ldstrongv_lane1.4 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.4, 1
  %fadd_lhs_bitcast.17 = bitcast i32 %ldstrongv_lane1.4 to float
  %ldstrongv_lane0.4 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.4, 0
  %fadd_lhs_bitcast.16 = bitcast i32 %ldstrongv_lane0.4 to float
  %fadd.16 = fadd float %phi.438, %fadd_lhs_bitcast.16
  %fadd.17 = fadd float %phi.437, %fadd_lhs_bitcast.17
  %fadd.18 = fadd float %phi.432, %fadd_lhs_bitcast.18
  %fadd.19 = fadd float %phi.431, %fadd_lhs_bitcast.19
  %ldv_volatile.5 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %998) #10
  %ldstrongv_lane3.5 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.5, 3
  %fadd_lhs_bitcast.23 = bitcast i32 %ldstrongv_lane3.5 to float
  %ldstrongv_lane2.5 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.5, 2
  %fadd_lhs_bitcast.22 = bitcast i32 %ldstrongv_lane2.5 to float
  %ldstrongv_lane1.5 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.5, 1
  %fadd_lhs_bitcast.21 = bitcast i32 %ldstrongv_lane1.5 to float
  %ldstrongv_lane0.5 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.5, 0
  %fadd_lhs_bitcast.20 = bitcast i32 %ldstrongv_lane0.5 to float
  %fadd.20 = fadd float %phi.430, %fadd_lhs_bitcast.20
  %fadd.21 = fadd float %phi.429, %fadd_lhs_bitcast.21
  %fadd.22 = fadd float %phi.440, %fadd_lhs_bitcast.22
  %fadd.23 = fadd float %phi.439, %fadd_lhs_bitcast.23
  %iadd3_o2.68 = load i32, ptr %.2976, align 4
  %1000 = zext i32 %iadd3_o2.68 to i64
  %1001 = add i64 %998, %1000
  %1002 = zext i32 %iadd3_o2.68 to i64
  %1003 = add i64 %999, %1002
  %iadd3_o2.70 = load i32, ptr %.2978, align 4
  %1004 = zext i32 %iadd3_o2.70 to i64
  %1005 = shl nuw i64 %1004, 32
  %1006 = add i64 %1001, %1005
  %1007 = zext i32 %iadd3_o2.70 to i64
  %1008 = shl nuw i64 %1007, 32
  %1009 = add i64 %1003, %1008
  %iadd3_n1.166 = add i32 %phi.428, 1
  %isetrp_cmp1.197.not = icmp sgt i32 %phi.425, %iadd3_n1.166
  br i1 %isetrp_cmp1.197.not, label %BB_5f60, label %BB_6070.loopexit

BB_6070.loopexit:                                 ; preds = %BB_5f60
  %phi_cast_R1615_bitcast = bitcast float %fadd.21 to i32
  %1010 = zext i32 %phi_cast_R1615_bitcast to i64
  %1011 = shl nuw i64 %1010, 32
  %phi_cast_R1539_bitcast = bitcast float %fadd.20 to i32
  %1012 = zext i32 %phi_cast_R1539_bitcast to i64
  %1013 = or disjoint i64 %1011, %1012
  %phi_cast_R620_bitcast = bitcast float %fadd.23 to i32
  %1014 = zext i32 %phi_cast_R620_bitcast to i64
  %1015 = shl nuw i64 %1014, 32
  %phi_cast_R383_bitcast = bitcast float %fadd.22 to i32
  %1016 = zext i32 %phi_cast_R383_bitcast to i64
  %1017 = or disjoint i64 %1015, %1016
  %phi_cast_R213_bitcast = bitcast float %fadd.17 to i32
  %1018 = zext i32 %phi_cast_R213_bitcast to i64
  %1019 = shl nuw i64 %1018, 32
  %phi_cast_R1045_bitcast = bitcast float %fadd.16 to i32
  %1020 = zext i32 %phi_cast_R1045_bitcast to i64
  %1021 = or disjoint i64 %1019, %1020
  %phi_cast_R1431_bitcast = bitcast float %fadd.19 to i32
  %1022 = zext i32 %phi_cast_R1431_bitcast to i64
  %1023 = shl nuw i64 %1022, 32
  %phi_cast_R1321_bitcast = bitcast float %fadd.18 to i32
  %1024 = zext i32 %phi_cast_R1321_bitcast to i64
  %1025 = or disjoint i64 %1023, %1024
  br label %BB_6070

BB_6070:                                          ; preds = %BB_6070.loopexit, %BB_5e80
  %1026 = phi i64 [ %982, %BB_5e80 ], [ %1017, %BB_6070.loopexit ]
  %1027 = phi i64 [ %974, %BB_5e80 ], [ %1025, %BB_6070.loopexit ]
  %1028 = phi i64 [ %970, %BB_5e80 ], [ %1013, %BB_6070.loopexit ]
  %1029 = phi i64 [ %978, %BB_5e80 ], [ %1021, %BB_6070.loopexit ]
  %phi.448 = phi i32 [ %phi.426, %BB_5e80 ], [ %ldstrongv_lane2.5, %BB_6070.loopexit ]
  %phi.449 = phi i32 [ %phi.427, %BB_5e80 ], [ %ldstrongv_lane1.5, %BB_6070.loopexit ]
  %phi.450 = phi i32 [ %mov.15, %BB_5e80 ], [ %ldstrongv_lane0.5, %BB_6070.loopexit ]
  br i1 %isetrp_cmp2.195, label %BB_6120, label %BB_6090

BB_6090:                                          ; preds = %BB_6070
  %.mask41 = and i64 %1027, 4294967295
  %stg_val_r2_ext.6 = zext nneg i64 %.mask41 to i128
  %stg_val_r2_shift.6 = shl nuw nsw i128 %stg_val_r2_ext.6, 64
  %stg_val_packed_1.6 = zext i64 %1029 to i128
  %stg_val_packed_2.6 = or disjoint i128 %stg_val_r2_shift.6, %stg_val_packed_1.6
  %1030 = lshr i64 %1027, 32
  %stg_val_r3_ext.6 = zext nneg i64 %1030 to i128
  %stg_val_r3_shift.6 = shl nuw i128 %stg_val_r3_ext.6, 96
  %stg_val_packed_3.6 = or disjoint i128 %stg_val_packed_2.6, %stg_val_r3_shift.6
  %imad_lhs_64.52 = sext i32 %imad.305 to i64
  %imad_tmp_64.52 = shl nsw i64 %imad_lhs_64.52, 4
  %1031 = add i64 %imad_tmp_64.52, %966
  %imad.307 = add i64 %imad_tmp_64.52, %966
  %.3040 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.72 = load i32, ptr %.3040, align 4
  %1032 = zext i32 %iadd3_o2.72 to i64
  %1033 = add i64 %1031, %1032
  %.3042 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.73 = load i32, ptr %.3042, align 4
  %1034 = zext i32 %iadd3_o2.73 to i64
  %1035 = shl nuw i64 %1034, 32
  %1036 = add i64 %1033, %1035
  %"R278:R216_addr_ptr" = inttoptr i64 %1036 to ptr addrspace(1)
  store i128 %stg_val_packed_3.6, ptr addrspace(1) %"R278:R216_addr_ptr", align 8
  %.mask46 = and i64 %1026, 4294967295
  %stg_val_r2_ext.7 = zext nneg i64 %.mask46 to i128
  %stg_val_r2_shift.7 = shl nuw nsw i128 %stg_val_r2_ext.7, 64
  %stg_val_packed_1.7 = zext i64 %1028 to i128
  %stg_val_packed_2.7 = or disjoint i128 %stg_val_r2_shift.7, %stg_val_packed_1.7
  %1037 = lshr i64 %1026, 32
  %stg_val_r3_ext.7 = zext nneg i64 %1037 to i128
  %stg_val_r3_shift.7 = shl nuw i128 %stg_val_r3_ext.7, 96
  %stg_val_packed_3.7 = or disjoint i128 %stg_val_packed_2.7, %stg_val_r3_shift.7
  %1038 = and i64 %imad.307, 4294967295
  %1039 = zext i32 %iadd3_o2.72 to i64
  %1040 = add nuw nsw i64 %1038, %1039
  %.3059 = shl nsw i64 %983, 4
  %1041 = add nsw i64 %1040, %.3059
  %.3060 = lshr i64 %.3059, 32
  %1042 = and i64 %imad.307, -4294967296
  %1043 = add i64 %1041, %1042
  %1044 = zext i32 %iadd3_o2.73 to i64
  %1045 = shl nuw i64 %1044, 32
  %1046 = add i64 %1043, %1045
  %"R118:R39_addr_ptr" = inttoptr i64 %1046 to ptr addrspace(1)
  store i128 %stg_val_packed_3.7, ptr addrspace(1) %"R118:R39_addr_ptr", align 8
  %"R21:R20_r1_shift.1" = lshr i64 %imad.307, 32
  %"R21:R20_r1.1" = trunc nuw i64 %"R21:R20_r1_shift.1" to i32
  %iadd3_n1.169 = add i32 %iadd3_o2.73, %"R21:R20_r1.1"
  %iadd3_o1_64.24 = and i64 %imad.307, 4294967295
  %iadd3_o2_64.24 = zext i32 %iadd3_o2.72 to i64
  %iadd3_tmp.24 = add nuw nsw i64 %iadd3_o1_64.24, %iadd3_o2_64.24
  %iadd3_trunc.24 = trunc i64 %iadd3_tmp.24 to i32
  %carry_ge_1.24 = icmp samesign ugt i64 %iadd3_tmp.24, 4294967295
  %iadd3_cin1_narrow_zext.14 = zext i1 %carry_ge_1.24 to i32
  %iadd3_cin1_add.14 = add i32 %iadd3_n1.169, %iadd3_cin1_narrow_zext.14
  %stg_addr_r1_ext.6 = zext i32 %iadd3_cin1_add.14 to i64
  %.3061 = add nuw nsw i64 %.3060, %stg_addr_r1_ext.6
  %.3045 = and i64 %iadd3_tmp.24, 4294967295
  %.3047 = shl nuw nsw i64 %.2985, 4
  %.3048 = and i64 %.3047, 4294965248
  %.3049 = add nuw nsw i64 %.3048, %.3045
  %.3050 = trunc i64 %.3049 to i32
  %.3052 = icmp samesign ugt i64 %.3049, 4294967295
  %.3062 = zext i1 %.3052 to i64
  %.3063 = add nuw nsw i64 %.3061, %.3062
  %.3064 = trunc i64 %.3063 to i32
  br label %BB_6120

BB_6120:                                          ; preds = %BB_5dd0, %BB_6070, %BB_6090
  %1047 = phi i64 [ %1026, %BB_6090 ], [ %982, %BB_5dd0 ], [ %1026, %BB_6070 ]
  %1048 = phi i64 [ %1027, %BB_6090 ], [ %974, %BB_5dd0 ], [ %1027, %BB_6070 ]
  %1049 = phi i64 [ %1028, %BB_6090 ], [ %970, %BB_5dd0 ], [ %1028, %BB_6070 ]
  %1050 = phi i64 [ %1029, %BB_6090 ], [ %978, %BB_5dd0 ], [ %1029, %BB_6070 ]
  %phi.460 = phi i32 [ %iadd3_trunc.24, %BB_6090 ], [ %phi.426, %BB_5dd0 ], [ %phi.448, %BB_6070 ]
  %phi.461 = phi i32 [ %.3064, %BB_6090 ], [ %phi.427, %BB_5dd0 ], [ %phi.449, %BB_6070 ]
  %phi.462 = phi i32 [ %.3050, %BB_6090 ], [ %mov.15, %BB_5dd0 ], [ %phi.450, %BB_6070 ]
  %1051 = lshr i64 %1050, 32
  %1052 = trunc nuw i64 %1051 to i32
  %1053 = trunc i64 %1050 to i32
  %1054 = lshr i64 %1048, 32
  %1055 = trunc nuw i64 %1054 to i32
  br i1 %isetrp_cmp2.195, label %BB_6130, label %BB_6720

BB_6130:                                          ; preds = %BB_6120
  %1056 = zext i1 %isetrp_cmp1.146.not to i32
  %1057 = icmp ne i32 %1056, 0
  br i1 %1057, label %BB_6140, label %BB_80006130

BB_80006130:                                      ; preds = %BB_6130
  %.3075 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.129 = load i32, ptr %.3075, align 4
  %imad_lhs_64.53 = zext i32 %iadd3_n1.126 to i64
  %imad_rhs_64.53 = zext i32 %imad_rhs.129 to i64
  %imad_tmp_64.53 = mul nuw i64 %imad_lhs_64.53, %imad_rhs_64.53
  %imad_tmp_hi.18 = lshr i64 %imad_tmp_64.53, 32
  %imad_tmp_hi_trunc.18 = trunc nuw i64 %imad_tmp_hi.18 to i32
  br label %BB_6140

BB_6140:                                          ; preds = %BB_80006130, %BB_6130
  %phi.465 = phi i32 [ %imad_tmp_hi_trunc.18, %BB_80006130 ], [ %phi.462, %BB_6130 ]
  %isetrp_rhs.91 = load i32, ptr %.355, align 4
  %isetrp_cmp1.198.not = icmp slt i32 %iadd3_n1.126, %isetrp_rhs.91
  br i1 %isetrp_cmp1.146.not, label %BB_6180, label %BB_80006170

BB_80006170:                                      ; preds = %BB_6140
  %.3082 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %shf_shift.18 = load i32, ptr %.3082, align 4
  %.3085 = zext i32 %phi.465 to i64
  %.3086 = shl nuw i64 %.3085, 32
  %shf_shift_64.62 = zext nneg i32 %shf_shift.18 to i64
  %.3087 = lshr i64 %.3086, %shf_shift_64.62
  %shf_hi.38 = lshr i64 %.3087, 32
  %shf_result.62 = trunc nuw i64 %shf_hi.38 to i32
  br label %BB_6180

BB_6180:                                          ; preds = %BB_80006170, %BB_6140
  %phi.466 = phi i32 [ %shf_result.62, %BB_80006170 ], [ %iadd3_n1.126, %BB_6140 ]
  %isetrp_cmp1.199 = icmp slt i32 %.2177, %imad_tmp.216
  %isetrp_cmp2.199 = and i1 %isetrp_cmp1.199, %isetrp_cmp1.198.not
  %iadd3_o1_neg.16 = sub i32 0, %phi.466
  %imad_rhs.130 = load i32, ptr %.187, align 4
  %imad_tmp.273 = mul i32 %imad_rhs.130, %iadd3_o1_neg.16
  %imad.308 = add i32 %imad_tmp.273, %iadd3_n1.126
  %phi.467 = select i1 %isetrp_cmp1.146.not, i32 0, i32 %imad.308
  %phi.468 = select i1 %isetrp_cmp1.146.not, i32 %phi.461, i32 %iadd3_o1_neg.16
  br i1 %isetrp_cmp1.147.not, label %BB_6210, label %BB_800061d0

BB_800061d0:                                      ; preds = %BB_6180
  %.3095 = getelementptr inbounds nuw i8, ptr %param_local, i64 992
  %imad_rhs.131 = load i32, ptr %.3095, align 4
  %imad_lhs_64.54 = zext i32 %phi.467 to i64
  %imad_rhs_64.54 = zext i32 %imad_rhs.131 to i64
  %imad_tmp_64.54 = mul nuw i64 %imad_lhs_64.54, %imad_rhs_64.54
  %imad_tmp_hi.19 = and i64 %imad_tmp_64.54, -4294967296
  %.3097 = getelementptr inbounds nuw i8, ptr %param_local, i64 996
  %shf_shift.19 = load i32, ptr %.3097, align 4
  %shf_shift_64.63 = zext nneg i32 %shf_shift.19 to i64
  %.3102 = lshr i64 %imad_tmp_hi.19, %shf_shift_64.63
  %shf_hi.39 = lshr i64 %.3102, 32
  %shf_result.63 = trunc nuw i64 %shf_hi.39 to i32
  %imad_rhs.132 = load i32, ptr %.193, align 4
  %1058 = mul i32 %imad_rhs.132, %shf_result.63
  %imad.309 = sub i32 %phi.467, %1058
  br label %BB_6210

BB_6210:                                          ; preds = %BB_800061d0, %BB_6180
  %spec.select83 = phi i32 [ %shf_result.63, %BB_800061d0 ], [ %phi.467, %BB_6180 ]
  %phi.469 = phi i32 [ %imad.309, %BB_800061d0 ], [ 0, %BB_6180 ]
  %.3106 = getelementptr inbounds nuw i8, ptr %param_local, i64 596
  %imad_rhs.133 = load i32, ptr %.3106, align 4
  %imad_tmp.275 = mul i32 %.2177, %imad_rhs.133
  br i1 %isetrp_cmp1.148.not, label %BB_6230, label %BB_80006220

BB_80006220:                                      ; preds = %BB_6210
  %.3110 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.134 = load i32, ptr %.3110, align 4
  %imad_lhs_64.55 = zext i32 %phi.469 to i64
  %imad_rhs_64.55 = zext i32 %imad_rhs.134 to i64
  %imad_tmp_64.55 = mul nuw i64 %imad_lhs_64.55, %imad_rhs_64.55
  %imad_tmp_hi.20 = lshr i64 %imad_tmp_64.55, 32
  %imad_tmp_hi_trunc.20 = trunc nuw i64 %imad_tmp_hi.20 to i32
  br label %BB_6230

BB_6230:                                          ; preds = %BB_80006220, %BB_6210
  %phi.471 = phi i32 [ %imad_tmp_hi_trunc.20, %BB_80006220 ], [ %phi.460, %BB_6210 ]
  br i1 %isetrp_cmp1.148.not, label %BB_6250, label %BB_80006240

BB_80006240:                                      ; preds = %BB_6230
  %.3116 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.20 = load i32, ptr %.3116, align 4
  %.3119 = zext i32 %phi.471 to i64
  %.3120 = shl nuw i64 %.3119, 32
  %shf_shift_64.64 = zext nneg i32 %shf_shift.20 to i64
  %.3121 = lshr i64 %.3120, %shf_shift_64.64
  %shf_hi.40 = lshr i64 %.3121, 32
  %shf_result.64 = trunc nuw i64 %shf_hi.40 to i32
  br label %BB_6250

BB_6250:                                          ; preds = %BB_80006240, %BB_6230
  %phi.475 = phi i32 [ %shf_result.64, %BB_80006240 ], [ %phi.469, %BB_6230 ]
  %phi.473 = phi i32 [ %shf_result.64, %BB_80006240 ], [ %phi.471, %BB_6230 ]
  %.3123 = getelementptr inbounds nuw i8, ptr %param_local, i64 580
  %imad_rhs.135 = load i32, ptr %.3123, align 4
  %imad_tmp.276 = mul i32 %phi.466, %imad_rhs.135
  %imad.311 = add i32 %imad_tmp.276, %imad_tmp.275
  %iadd3_o1_neg.18 = sub i32 0, %phi.473
  %phi.474 = select i1 %isetrp_cmp1.148.not, i32 %phi.468, i32 %iadd3_o1_neg.18
  %.3128 = getelementptr inbounds nuw i8, ptr %param_local, i64 584
  %imad_rhs.136 = load i32, ptr %.3128, align 4
  %imad_tmp.277 = mul i32 %spec.select83, %imad_rhs.136
  %imad.312 = add i32 %imad_tmp.277, %imad.311
  %imad_rhs.137 = load i32, ptr %.197, align 4
  %imad_tmp.278 = mul i32 %phi.474, %imad_rhs.137
  %imad.313 = add i32 %imad_tmp.278, %phi.469
  %phi.476 = select i1 %isetrp_cmp1.148.not, i32 0, i32 %imad.313
  %.3135 = getelementptr inbounds nuw i8, ptr %param_local, i64 588
  %imad_rhs.138 = load i32, ptr %.3135, align 4
  %imad_tmp.279 = mul i32 %phi.475, %imad_rhs.138
  %imad.314 = add i32 %imad_tmp.279, %imad.312
  %.3137 = getelementptr inbounds nuw i8, ptr %param_local, i64 592
  %imad_rhs.139 = load i32, ptr %.3137, align 4
  %imad_tmp.280 = mul i32 %phi.476, %imad_rhs.139
  %imad.315 = add i32 %imad_tmp.280, %imad.314
  %sel.97 = select i1 %isetrp_cmp2.199, i32 %imad.315, i32 -1
  %isetrp_cmp1.200 = icmp sgt i32 %sel.97, -1
  br i1 %isetrp_cmp1.200, label %BB_80006310, label %BB_6340

BB_80006310:                                      ; preds = %BB_6250
  %.3141 = getelementptr inbounds nuw i8, ptr %param_local, i64 376
  %imad_addend.48 = load i64, ptr %.3141, align 8
  %1059 = shl nuw i32 %sel.97, 1
  %imad_tmp_64.56 = zext i32 %1059 to i64
  %1060 = add i64 %imad_addend.48, %imad_tmp_64.56
  %"R1717:R1495_addr_ptr" = inttoptr i64 %1060 to ptr addrspace(1)
  %ldg_vec.1 = load <4 x i32>, ptr addrspace(1) %"R1717:R1495_addr_ptr", align 16
  %ldg_lane0.1 = extractelement <4 x i32> %ldg_vec.1, i64 0
  %ldg_lane1.1 = extractelement <4 x i32> %ldg_vec.1, i64 1
  %ldg_lane2.1 = extractelement <4 x i32> %ldg_vec.1, i64 2
  %ldg_lane3.1 = extractelement <4 x i32> %ldg_vec.1, i64 3
  br label %BB_6340

BB_6340:                                          ; preds = %BB_80006310, %BB_6250
  %phi.477 = phi i32 [ %ldg_lane3.1, %BB_80006310 ], [ 0, %BB_6250 ]
  %phi.478 = phi i32 [ %ldg_lane2.1, %BB_80006310 ], [ 0, %BB_6250 ]
  %phi.479 = phi i32 [ %ldg_lane1.1, %BB_80006310 ], [ 0, %BB_6250 ]
  %phi.480 = phi i32 [ %ldg_lane0.1, %BB_80006310 ], [ 0, %BB_6250 ]
  %1061 = zext nneg i32 %imad.217 to i64
  %.3144 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1061
  store volatile i64 %1050, ptr addrspace(3) %.3144, align 8
  %sts_addr_memaddr_offset_add.6 = add nuw nsw i32 %imad.217, 16
  %1062 = zext nneg i32 %sts_addr_memaddr_offset_add.6 to i64
  %.3146 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1062
  store volatile i64 %1049, ptr addrspace(3) %.3146, align 8
  %sts_addr_memaddr_offset_add.7 = add nuw nsw i32 %imad.217, 1280
  %1063 = zext nneg i32 %sts_addr_memaddr_offset_add.7 to i64
  %.3148 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1063
  store volatile i64 %1048, ptr addrspace(3) %.3148, align 8
  %sts_addr_memaddr_offset_add.8 = add nuw nsw i32 %imad.217, 1296
  %1064 = zext nneg i32 %sts_addr_memaddr_offset_add.8 to i64
  %.3150 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1064
  store volatile i64 %1047, ptr addrspace(3) %.3150, align 8
  call void @llvm.nvvm.barrier0()
  %1065 = shl i32 %phi.480, 16
  %1066 = lshr exact i32 %1065, 3
  %1067 = and i32 %1066, 268427264
  %1068 = icmp samesign ugt i32 %1067, 260046847
  %1069 = select i1 %1068, i32 2139095040, i32 0
  %1070 = or i32 %1067, %1069
  %1071 = bitcast i32 %1070 to float
  %1072 = fmul float %1071, 0x46F0000000000000
  %1073 = bitcast i32 %1065 to float
  %1074 = call float @llvm.copysign.f32(float %1072, float %1073)
  %lds_shared_addr_winoff.4.xscale = shl i32 %imad.219, 4
  %lds_shared_addr_winoff.4 = and i32 %lds_shared_addr_winoff.4.xscale, 16777200
  %1075 = zext nneg i32 %lds_shared_addr_winoff.4 to i64
  %.3152 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1075
  %lds.4 = load volatile i128, ptr addrspace(3) %.3152, align 8
  %lds_addr_memaddr_offset_add.2 = add i32 %lds_shared_addr_winoff.4.xscale, 80
  %lds_shared_addr_winoff.5 = and i32 %lds_addr_memaddr_offset_add.2, 16777200
  %1076 = zext nneg i32 %lds_shared_addr_winoff.5 to i64
  %.3153 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1076
  %lds.5 = load volatile i128, ptr addrspace(3) %.3153, align 8
  %"R35:R34:R33:R32_r0.2" = trunc i128 %lds.4 to i32
  %ffma_lhs_bitcast.18 = bitcast i32 %"R35:R34:R33:R32_r0.2" to float
  %1077 = shl i32 %phi.284, 16
  %1078 = lshr exact i32 %1077, 3
  %1079 = and i32 %1078, 268427264
  %1080 = icmp samesign ugt i32 %1079, 260046847
  %1081 = select i1 %1080, i32 2139095040, i32 0
  %1082 = or i32 %1079, %1081
  %1083 = bitcast i32 %1082 to float
  %1084 = fmul float %1083, 0x46F0000000000000
  %1085 = bitcast i32 %1077 to float
  %1086 = call float @llvm.copysign.f32(float %1084, float %1085)
  %ffma.18 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.18, float %phi.292, float %1086)
  %ffma.24 = call float @llvm.fma.f32(float %1074, float %phi.291, float %ffma.18)
  %.3154 = getelementptr inbounds nuw i8, ptr %param_local, i64 528
  %fmnmx_rhs.32 = load float, ptr %.3154, align 4
  %fmnmx_max.16 = call float @llvm.maximum.f32(float %ffma.24, float %fmnmx_rhs.32)
  %extelt.offset52 = and i32 %phi.480, -65536
  %1087 = lshr i32 %phi.480, 3
  %1088 = and i32 %1087, 268427264
  %1089 = icmp samesign ugt i32 %1088, 260046847
  %1090 = select i1 %1089, i32 2139095040, i32 0
  %1091 = or i32 %1088, %1090
  %1092 = bitcast i32 %1091 to float
  %1093 = fmul float %1092, 0x46F0000000000000
  %1094 = bitcast i32 %extelt.offset52 to float
  %1095 = call float @llvm.copysign.f32(float %1093, float %1094)
  %"R35:R34:R33:R32_r1_shift.2" = lshr i128 %lds.4, 32
  %"R35:R34:R33:R32_r1.2" = trunc i128 %"R35:R34:R33:R32_r1_shift.2" to i32
  %ffma_lhs_bitcast.16 = bitcast i32 %"R35:R34:R33:R32_r1.2" to float
  %extelt.offset48 = and i32 %phi.284, -65536
  %1096 = lshr i32 %phi.284, 3
  %1097 = and i32 %1096, 268427264
  %1098 = icmp samesign ugt i32 %1097, 260046847
  %1099 = select i1 %1098, i32 2139095040, i32 0
  %1100 = or i32 %1097, %1099
  %1101 = bitcast i32 %1100 to float
  %1102 = fmul float %1101, 0x46F0000000000000
  %1103 = bitcast i32 %extelt.offset48 to float
  %1104 = call float @llvm.copysign.f32(float %1102, float %1103)
  %ffma.16 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.16, float %phi.292, float %1104)
  %ffma.22 = call float @llvm.fma.f32(float %1095, float %phi.291, float %ffma.16)
  %fmnmx_max.17 = call float @llvm.maximum.f32(float %ffma.22, float %fmnmx_rhs.32)
  %1105 = shl i32 %phi.479, 16
  %1106 = lshr exact i32 %1105, 3
  %1107 = and i32 %1106, 268427264
  %1108 = icmp samesign ugt i32 %1107, 260046847
  %1109 = select i1 %1108, i32 2139095040, i32 0
  %1110 = or i32 %1107, %1109
  %1111 = bitcast i32 %1110 to float
  %1112 = fmul float %1111, 0x46F0000000000000
  %1113 = bitcast i32 %1105 to float
  %1114 = call float @llvm.copysign.f32(float %1112, float %1113)
  %"R35:R34:R33:R32_r2_shift.2" = lshr i128 %lds.4, 64
  %"R35:R34:R33:R32_r2.2" = trunc i128 %"R35:R34:R33:R32_r2_shift.2" to i32
  %ffma_lhs_bitcast.17 = bitcast i32 %"R35:R34:R33:R32_r2.2" to float
  %1115 = shl i32 %phi.283, 16
  %1116 = lshr exact i32 %1115, 3
  %1117 = and i32 %1116, 268427264
  %1118 = icmp samesign ugt i32 %1117, 260046847
  %1119 = select i1 %1118, i32 2139095040, i32 0
  %1120 = or i32 %1117, %1119
  %1121 = bitcast i32 %1120 to float
  %1122 = fmul float %1121, 0x46F0000000000000
  %1123 = bitcast i32 %1115 to float
  %1124 = call float @llvm.copysign.f32(float %1122, float %1123)
  %ffma.17 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.17, float %phi.292, float %1124)
  %ffma.23 = call float @llvm.fma.f32(float %1114, float %phi.291, float %ffma.17)
  %fmnmx_max.18 = call float @llvm.maximum.f32(float %ffma.23, float %fmnmx_rhs.32)
  %extelt.offset53 = and i32 %phi.479, -65536
  %1125 = lshr i32 %phi.479, 3
  %1126 = and i32 %1125, 268427264
  %1127 = icmp samesign ugt i32 %1126, 260046847
  %1128 = select i1 %1127, i32 2139095040, i32 0
  %1129 = or i32 %1126, %1128
  %1130 = bitcast i32 %1129 to float
  %1131 = fmul float %1130, 0x46F0000000000000
  %1132 = bitcast i32 %extelt.offset53 to float
  %1133 = call float @llvm.copysign.f32(float %1131, float %1132)
  %"R35:R34:R33:R32_r3_shift.2" = lshr i128 %lds.4, 96
  %"R35:R34:R33:R32_r3.2" = trunc nuw i128 %"R35:R34:R33:R32_r3_shift.2" to i32
  %ffma_lhs_bitcast.19 = bitcast i32 %"R35:R34:R33:R32_r3.2" to float
  %extelt.offset49 = and i32 %phi.283, -65536
  %1134 = lshr i32 %phi.283, 3
  %1135 = and i32 %1134, 268427264
  %1136 = icmp samesign ugt i32 %1135, 260046847
  %1137 = select i1 %1136, i32 2139095040, i32 0
  %1138 = or i32 %1135, %1137
  %1139 = bitcast i32 %1138 to float
  %1140 = fmul float %1139, 0x46F0000000000000
  %1141 = bitcast i32 %extelt.offset49 to float
  %1142 = call float @llvm.copysign.f32(float %1140, float %1141)
  %hadd2_f32_i32.19 = bitcast float %1142 to i32
  %ffma.19 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.19, float %phi.292, float %1142)
  %ffma.27 = call float @llvm.fma.f32(float %1133, float %phi.291, float %ffma.19)
  %fmnmx_max.19 = call float @llvm.maximum.f32(float %ffma.27, float %fmnmx_rhs.32)
  %1143 = zext i32 %hadd2_f32_i32.19 to i64
  %1144 = shl nuw i64 %1143, 32
  %1145 = shl i32 %phi.478, 16
  %1146 = lshr exact i32 %1145, 3
  %1147 = and i32 %1146, 268427264
  %1148 = icmp samesign ugt i32 %1147, 260046847
  %1149 = select i1 %1148, i32 2139095040, i32 0
  %1150 = or i32 %1147, %1149
  %1151 = bitcast i32 %1150 to float
  %1152 = fmul float %1151, 0x46F0000000000000
  %1153 = bitcast i32 %1145 to float
  %1154 = call float @llvm.copysign.f32(float %1152, float %1153)
  %"R27:R26:R25:R24_r0.4" = trunc i128 %lds.5 to i32
  %ffma_lhs_bitcast.25 = bitcast i32 %"R27:R26:R25:R24_r0.4" to float
  %1155 = shl i32 %phi.282, 16
  %1156 = lshr exact i32 %1155, 3
  %1157 = and i32 %1156, 268427264
  %1158 = icmp samesign ugt i32 %1157, 260046847
  %1159 = select i1 %1158, i32 2139095040, i32 0
  %1160 = or i32 %1157, %1159
  %1161 = bitcast i32 %1160 to float
  %1162 = fmul float %1161, 0x46F0000000000000
  %1163 = bitcast i32 %1155 to float
  %1164 = call float @llvm.copysign.f32(float %1162, float %1163)
  %ffma.25 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.25, float %phi.292, float %1164)
  %ffma.28 = call float @llvm.fma.f32(float %1154, float %phi.291, float %ffma.25)
  %fmnmx_max.20 = call float @llvm.maximum.f32(float %ffma.28, float %fmnmx_rhs.32)
  %extelt.offset54 = and i32 %phi.478, -65536
  %1165 = lshr i32 %phi.478, 3
  %1166 = and i32 %1165, 268427264
  %1167 = icmp samesign ugt i32 %1166, 260046847
  %1168 = select i1 %1167, i32 2139095040, i32 0
  %1169 = or i32 %1166, %1168
  %1170 = bitcast i32 %1169 to float
  %1171 = fmul float %1170, 0x46F0000000000000
  %1172 = bitcast i32 %extelt.offset54 to float
  %1173 = call float @llvm.copysign.f32(float %1171, float %1172)
  %"R27:R26:R25:R24_r1_shift.4" = lshr i128 %lds.5, 32
  %"R27:R26:R25:R24_r1.4" = trunc i128 %"R27:R26:R25:R24_r1_shift.4" to i32
  %ffma_lhs_bitcast.20 = bitcast i32 %"R27:R26:R25:R24_r1.4" to float
  %extelt.offset51 = and i32 %phi.282, -65536
  %1174 = lshr i32 %phi.282, 3
  %1175 = and i32 %1174, 268427264
  %1176 = icmp samesign ugt i32 %1175, 260046847
  %1177 = select i1 %1176, i32 2139095040, i32 0
  %1178 = or i32 %1175, %1177
  %1179 = bitcast i32 %1178 to float
  %1180 = fmul float %1179, 0x46F0000000000000
  %1181 = bitcast i32 %extelt.offset51 to float
  %1182 = call float @llvm.copysign.f32(float %1180, float %1181)
  %ffma.20 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.20, float %phi.292, float %1182)
  %ffma.29 = call float @llvm.fma.f32(float %1173, float %phi.291, float %ffma.20)
  %fmnmx_max.21 = call float @llvm.maximum.f32(float %ffma.29, float %fmnmx_rhs.32)
  %1183 = shl i32 %phi.477, 16
  %1184 = lshr exact i32 %1183, 3
  %1185 = and i32 %1184, 268427264
  %1186 = icmp samesign ugt i32 %1185, 260046847
  %1187 = select i1 %1186, i32 2139095040, i32 0
  %1188 = or i32 %1185, %1187
  %1189 = bitcast i32 %1188 to float
  %1190 = fmul float %1189, 0x46F0000000000000
  %1191 = bitcast i32 %1183 to float
  %1192 = call float @llvm.copysign.f32(float %1190, float %1191)
  %"R27:R26:R25:R24_r2_shift.4" = lshr i128 %lds.5, 64
  %"R27:R26:R25:R24_r2.4" = trunc i128 %"R27:R26:R25:R24_r2_shift.4" to i32
  %ffma_lhs_bitcast.26 = bitcast i32 %"R27:R26:R25:R24_r2.4" to float
  %1193 = shl i32 %phi.281, 16
  %1194 = lshr exact i32 %1193, 3
  %1195 = and i32 %1194, 268427264
  %1196 = icmp samesign ugt i32 %1195, 260046847
  %1197 = select i1 %1196, i32 2139095040, i32 0
  %1198 = or i32 %1195, %1197
  %1199 = bitcast i32 %1198 to float
  %1200 = fmul float %1199, 0x46F0000000000000
  %1201 = bitcast i32 %1193 to float
  %1202 = call float @llvm.copysign.f32(float %1200, float %1201)
  %ffma.26 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.26, float %phi.292, float %1202)
  %ffma.30 = call float @llvm.fma.f32(float %1192, float %phi.291, float %ffma.26)
  %fmnmx_max.22 = call float @llvm.maximum.f32(float %ffma.30, float %fmnmx_rhs.32)
  %extelt.offset55 = and i32 %phi.477, -65536
  %1203 = lshr i32 %phi.477, 3
  %1204 = and i32 %1203, 268427264
  %1205 = icmp samesign ugt i32 %1204, 260046847
  %1206 = select i1 %1205, i32 2139095040, i32 0
  %1207 = or i32 %1204, %1206
  %1208 = bitcast i32 %1207 to float
  %1209 = fmul float %1208, 0x46F0000000000000
  %1210 = bitcast i32 %extelt.offset55 to float
  %1211 = call float @llvm.copysign.f32(float %1209, float %1210)
  %"R27:R26:R25:R24_r3_shift.4" = lshr i128 %lds.5, 96
  %"R27:R26:R25:R24_r3.4" = trunc nuw i128 %"R27:R26:R25:R24_r3_shift.4" to i32
  %ffma_lhs_bitcast.21 = bitcast i32 %"R27:R26:R25:R24_r3.4" to float
  %extelt.offset50 = and i32 %phi.281, -65536
  %1212 = lshr i32 %phi.281, 3
  %1213 = and i32 %1212, 268427264
  %1214 = icmp samesign ugt i32 %1213, 260046847
  %1215 = select i1 %1214, i32 2139095040, i32 0
  %1216 = or i32 %1213, %1215
  %1217 = bitcast i32 %1216 to float
  %1218 = fmul float %1217, 0x46F0000000000000
  %1219 = bitcast i32 %extelt.offset50 to float
  %1220 = call float @llvm.copysign.f32(float %1218, float %1219)
  %ffma.21 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.21, float %phi.292, float %1220)
  %ffma.31 = call float @llvm.fma.f32(float %1211, float %phi.291, float %ffma.21)
  %fmnmx_max.23 = call float @llvm.maximum.f32(float %ffma.31, float %fmnmx_rhs.32)
  %.3173 = getelementptr inbounds nuw i8, ptr %param_local, i64 544
  %fmnmx_rhs.40 = load float, ptr %.3173, align 4
  %fmnmx_min.16 = call float @llvm.minimum.f32(float %fmnmx_max.16, float %fmnmx_rhs.40)
  %fmnmx_min.17 = call float @llvm.minimum.f32(float %fmnmx_max.17, float %fmnmx_rhs.40)
  %1221 = zext i32 %sel.97 to i64
  %1222 = or disjoint i64 %1144, %1221
  br i1 %isetrp_cmp1.200, label %BB_80006660, label %BB_6670

BB_80006660:                                      ; preds = %BB_6340
  %.3179 = getelementptr inbounds nuw i8, ptr %param_local, i64 368
  %imad_addend.49 = load i64, ptr %.3179, align 8
  %1223 = shl nuw i32 %sel.97, 1
  %imad_tmp_64.57 = zext i32 %1223 to i64
  %1224 = add i64 %imad_addend.49, %imad_tmp_64.57
  br label %BB_6670

BB_6670:                                          ; preds = %BB_80006660, %BB_6340
  %1225 = phi i64 [ %1224, %BB_80006660 ], [ %1222, %BB_6340 ]
  %fmnmx_rhs.42 = load float, ptr %.3173, align 4
  %fmnmx_min.18 = call float @llvm.minimum.f32(float %fmnmx_max.18, float %fmnmx_rhs.42)
  %fmnmx_min.19 = call float @llvm.minimum.f32(float %fmnmx_max.19, float %fmnmx_rhs.42)
  %fmnmx_min.22 = call float @llvm.minimum.f32(float %fmnmx_max.22, float %fmnmx_rhs.42)
  %fmnmx_min.23 = call float @llvm.minimum.f32(float %fmnmx_max.23, float %fmnmx_rhs.42)
  %1226 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min.17, float %fmnmx_min.16, float %fmnmx_min.19, float %fmnmx_min.18)
  %1227 = extractvalue { i32, i32, i32, i32 } %1226, 0
  %1228 = extractvalue { i32, i32, i32, i32 } %1226, 1
  %1229 = extractvalue { i32, i32, i32, i32 } %1226, 2
  %1230 = extractvalue { i32, i32, i32, i32 } %1226, 3
  %f2fp_a_shift.8 = shl nuw i32 %1227, 16
  %f2fp_packed.8 = or disjoint i32 %f2fp_a_shift.8, %1228
  %f2fp_a_shift.9 = shl nuw i32 %1229, 16
  %f2fp_packed.9 = or disjoint i32 %f2fp_a_shift.9, %1230
  %1231 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.23, float %fmnmx_min.22)
  %1232 = extractvalue { i32, i32 } %1231, 0
  %1233 = extractvalue { i32, i32 } %1231, 1
  %f2fp_a_shift.11 = shl nuw i32 %1232, 16
  %f2fp_packed.11 = or disjoint i32 %f2fp_a_shift.11, %1233
  br i1 %isetrp_cmp1.200, label %BB_80006710, label %BB_6720

BB_80006710:                                      ; preds = %BB_6670
  %fmnmx_min.21 = call float @llvm.minimum.f32(float %fmnmx_max.21, float %fmnmx_rhs.42)
  %fmnmx_min.20 = call float @llvm.minimum.f32(float %fmnmx_max.20, float %fmnmx_rhs.42)
  %1234 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.21, float %fmnmx_min.20)
  %1235 = extractvalue { i32, i32 } %1234, 0
  %1236 = extractvalue { i32, i32 } %1234, 1
  %f2fp_a_shift.10 = shl nuw i32 %1235, 16
  %f2fp_packed.10 = or disjoint i32 %f2fp_a_shift.10, %1236
  %stg_val_r0_ext.8 = zext i32 %f2fp_packed.8 to i128
  %stg_val_r1_ext.8 = zext i32 %f2fp_packed.9 to i128
  %stg_val_r1_shift.8 = shl nuw nsw i128 %stg_val_r1_ext.8, 32
  %stg_val_packed_1.8 = or disjoint i128 %stg_val_r1_shift.8, %stg_val_r0_ext.8
  %stg_val_r2_ext.8 = zext i32 %f2fp_packed.10 to i128
  %stg_val_r2_shift.8 = shl nuw nsw i128 %stg_val_r2_ext.8, 64
  %stg_val_packed_2.8 = or disjoint i128 %stg_val_packed_1.8, %stg_val_r2_shift.8
  %stg_val_r3_ext.8 = zext i32 %f2fp_packed.11 to i128
  %stg_val_r3_shift.8 = shl nuw i128 %stg_val_r3_ext.8, 96
  %stg_val_packed_3.8 = or disjoint i128 %stg_val_packed_2.8, %stg_val_r3_shift.8
  %"R1129:R1106_addr_ptr" = inttoptr i64 %1225 to ptr addrspace(1)
  store i128 %stg_val_packed_3.8, ptr addrspace(1) %"R1129:R1106_addr_ptr", align 8
  br label %BB_6720

BB_6720:                                          ; preds = %BB_80006710, %BB_6670, %BB_6120
  %phi.484 = phi i32 [ %1055, %BB_6120 ], [ %f2fp_packed.11, %BB_80006710 ], [ %f2fp_packed.11, %BB_6670 ]
  %phi.485 = phi i32 [ %1052, %BB_6120 ], [ %f2fp_packed.9, %BB_80006710 ], [ %f2fp_packed.9, %BB_6670 ]
  %phi.486 = phi i32 [ %1053, %BB_6120 ], [ %f2fp_packed.8, %BB_80006710 ], [ %f2fp_packed.8, %BB_6670 ]
  call void @llvm.nvvm.barrier0()
  %phi_cast_R2019_bitcast.3 = bitcast float %phi.263 to i32
  %phi_cast_R1998_bitcast.3 = bitcast float %phi.264 to i32
  %1237 = zext i32 %phi_cast_R2019_bitcast.3 to i64
  %1238 = shl nuw i64 %1237, 32
  %1239 = zext i32 %phi_cast_R1998_bitcast.3 to i64
  %1240 = or disjoint i64 %1238, %1239
  %phi_cast_R1979_bitcast.3 = bitcast float %phi.265 to i32
  %phi_cast_R1871_bitcast.3 = bitcast float %phi.266 to i32
  %1241 = zext i32 %phi_cast_R1979_bitcast.3 to i64
  %1242 = shl nuw i64 %1241, 32
  %1243 = zext i32 %phi_cast_R1871_bitcast.3 to i64
  %1244 = or disjoint i64 %1242, %1243
  %phi_cast_R1719_bitcast.3 = bitcast float %phi.267 to i32
  %phi_cast_R1494_bitcast.3 = bitcast float %phi.268 to i32
  %1245 = zext i32 %phi_cast_R1719_bitcast.3 to i64
  %1246 = shl nuw i64 %1245, 32
  %1247 = zext i32 %phi_cast_R1494_bitcast.3 to i64
  %1248 = or disjoint i64 %1246, %1247
  %phi_cast_R1407_bitcast.3 = bitcast float %phi.269 to i32
  %phi_cast_R905_bitcast.3 = bitcast float %phi.270 to i32
  %1249 = zext i32 %phi_cast_R1407_bitcast.3 to i64
  %1250 = shl nuw i64 %1249, 32
  %1251 = zext i32 %phi_cast_R905_bitcast.3 to i64
  %1252 = or disjoint i64 %1250, %1251
  br i1 %isetrp_cmp1.194, label %BB_6a80, label %BB_6740

BB_6740:                                          ; preds = %BB_6720
  %imad_tmp.281 = shl i32 %imad_tmp.215, 7
  %imad_tmp.282 = shl i32 %imad.232, 7
  %imad.319 = add i32 %imad_tmp.282, %tid_x
  %.3201 = zext i32 %imad_tmp.281 to i64
  %1253 = sext i32 %imad_tmp.281 to i64
  %isetrp_cmp1.201 = icmp slt i32 %phi.425, 1
  br i1 %isetrp_cmp1.201, label %BB_69b0, label %BB_6790

BB_6790:                                          ; preds = %BB_6740
  %imad_tmp.283 = shl i32 %imad.319, 4
  %imad_lhs_64.59 = sext i32 %imad_tmp.281 to i64
  %imad_tmp_64.59 = shl nsw i64 %imad_lhs_64.59, 5
  %1254 = add i64 %imad_tmp_64.59, %966
  %.3206 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.74 = load i32, ptr %.3206, align 4
  %1255 = sext i32 %imad_tmp.283 to i64
  %1256 = mul nsw i64 %1253, 48
  %1257 = add i64 %1256, %966
  %.3214 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.76 = load i32, ptr %.3214, align 4
  %1258 = zext i32 %iadd3_o2.74 to i64
  %1259 = zext i32 %iadd3_o2.76 to i64
  %1260 = shl nuw i64 %1259, 32
  %1261 = add i64 %1254, %1255
  %1262 = add i64 %1261, %1258
  %1263 = add i64 %1262, %1260
  %1264 = zext i32 %iadd3_o2.74 to i64
  %1265 = zext i32 %iadd3_o2.76 to i64
  %1266 = shl nuw i64 %1265, 32
  %1267 = add i64 %1257, %1255
  %1268 = add i64 %1267, %1264
  %1269 = add i64 %1268, %1266
  br label %BB_6860

BB_6860:                                          ; preds = %BB_6860, %BB_6790
  %1270 = phi i64 [ %1269, %BB_6790 ], [ %1278, %BB_6860 ]
  %1271 = phi i64 [ %1263, %BB_6790 ], [ %1281, %BB_6860 ]
  %phi.487 = phi i32 [ 0, %BB_6790 ], [ %iadd3_n1.175, %BB_6860 ]
  %phi.492 = phi float [ %phi.263, %BB_6790 ], [ %fadd.31, %BB_6860 ]
  %phi.493 = phi float [ %phi.264, %BB_6790 ], [ %fadd.30, %BB_6860 ]
  %phi.494 = phi float [ %phi.265, %BB_6790 ], [ %fadd.29, %BB_6860 ]
  %phi.495 = phi float [ %phi.266, %BB_6790 ], [ %fadd.28, %BB_6860 ]
  %phi.496 = phi float [ %phi.267, %BB_6790 ], [ %fadd.27, %BB_6860 ]
  %phi.497 = phi float [ %phi.268, %BB_6790 ], [ %fadd.26, %BB_6860 ]
  %phi.498 = phi float [ %phi.269, %BB_6790 ], [ %fadd.25, %BB_6860 ]
  %phi.499 = phi float [ %phi.270, %BB_6790 ], [ %fadd.24, %BB_6860 ]
  %ldv_volatile.6 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %1271) #10
  %ldstrongv_lane3.6 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.6, 3
  %fadd_lhs_bitcast.27 = bitcast i32 %ldstrongv_lane3.6 to float
  %ldstrongv_lane2.6 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.6, 2
  %fadd_lhs_bitcast.26 = bitcast i32 %ldstrongv_lane2.6 to float
  %ldstrongv_lane1.6 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.6, 1
  %fadd_lhs_bitcast.25 = bitcast i32 %ldstrongv_lane1.6 to float
  %ldstrongv_lane0.6 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.6, 0
  %fadd_lhs_bitcast.24 = bitcast i32 %ldstrongv_lane0.6 to float
  %fadd.24 = fadd float %phi.499, %fadd_lhs_bitcast.24
  %fadd.25 = fadd float %phi.498, %fadd_lhs_bitcast.25
  %fadd.26 = fadd float %phi.497, %fadd_lhs_bitcast.26
  %fadd.27 = fadd float %phi.496, %fadd_lhs_bitcast.27
  %ldv_volatile.7 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %1270) #10
  %ldstrongv_lane3.7 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.7, 3
  %fadd_lhs_bitcast.31 = bitcast i32 %ldstrongv_lane3.7 to float
  %ldstrongv_lane2.7 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.7, 2
  %fadd_lhs_bitcast.30 = bitcast i32 %ldstrongv_lane2.7 to float
  %ldstrongv_lane1.7 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.7, 1
  %fadd_lhs_bitcast.29 = bitcast i32 %ldstrongv_lane1.7 to float
  %ldstrongv_lane0.7 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.7, 0
  %fadd_lhs_bitcast.28 = bitcast i32 %ldstrongv_lane0.7 to float
  %fadd.28 = fadd float %phi.495, %fadd_lhs_bitcast.28
  %fadd.29 = fadd float %phi.494, %fadd_lhs_bitcast.29
  %fadd.30 = fadd float %phi.493, %fadd_lhs_bitcast.30
  %fadd.31 = fadd float %phi.492, %fadd_lhs_bitcast.31
  %iadd3_o2.78 = load i32, ptr %.2976, align 4
  %1272 = zext i32 %iadd3_o2.78 to i64
  %1273 = add i64 %1270, %1272
  %1274 = zext i32 %iadd3_o2.78 to i64
  %1275 = add i64 %1271, %1274
  %iadd3_o2.80 = load i32, ptr %.2978, align 4
  %1276 = zext i32 %iadd3_o2.80 to i64
  %1277 = shl nuw i64 %1276, 32
  %1278 = add i64 %1273, %1277
  %1279 = zext i32 %iadd3_o2.80 to i64
  %1280 = shl nuw i64 %1279, 32
  %1281 = add i64 %1275, %1280
  %iadd3_n1.175 = add i32 %phi.487, 1
  %isetrp_cmp1.202.not = icmp sgt i32 %phi.425, %iadd3_n1.175
  br i1 %isetrp_cmp1.202.not, label %BB_6860, label %BB_69b0.loopexit

BB_69b0.loopexit:                                 ; preds = %BB_6860
  %phi_cast_R1964_bitcast = bitcast float %fadd.29 to i32
  %1282 = zext i32 %phi_cast_R1964_bitcast to i64
  %1283 = shl nuw i64 %1282, 32
  %phi_cast_R1783_bitcast = bitcast float %fadd.28 to i32
  %1284 = zext i32 %phi_cast_R1783_bitcast to i64
  %1285 = or disjoint i64 %1283, %1284
  %phi_cast_R2008_bitcast = bitcast float %fadd.31 to i32
  %1286 = zext i32 %phi_cast_R2008_bitcast to i64
  %1287 = shl nuw i64 %1286, 32
  %phi_cast_R1987_bitcast = bitcast float %fadd.30 to i32
  %1288 = zext i32 %phi_cast_R1987_bitcast to i64
  %1289 = or disjoint i64 %1287, %1288
  %phi_cast_R669_bitcast = bitcast float %fadd.25 to i32
  %1290 = zext i32 %phi_cast_R669_bitcast to i64
  %1291 = shl nuw i64 %1290, 32
  %phi_cast_R1026_bitcast = bitcast float %fadd.24 to i32
  %1292 = zext i32 %phi_cast_R1026_bitcast to i64
  %1293 = or disjoint i64 %1291, %1292
  %phi_cast_R1575_bitcast = bitcast float %fadd.27 to i32
  %1294 = zext i32 %phi_cast_R1575_bitcast to i64
  %1295 = shl nuw i64 %1294, 32
  %phi_cast_R1401_bitcast = bitcast float %fadd.26 to i32
  %1296 = zext i32 %phi_cast_R1401_bitcast to i64
  %1297 = or disjoint i64 %1295, %1296
  br label %BB_69b0

BB_69b0:                                          ; preds = %BB_69b0.loopexit, %BB_6740
  %1298 = phi i64 [ %1240, %BB_6740 ], [ %1289, %BB_69b0.loopexit ]
  %1299 = phi i64 [ %1248, %BB_6740 ], [ %1297, %BB_69b0.loopexit ]
  %1300 = phi i64 [ %1244, %BB_6740 ], [ %1285, %BB_69b0.loopexit ]
  %1301 = phi i64 [ %1252, %BB_6740 ], [ %1293, %BB_69b0.loopexit ]
  %phi.500 = phi i32 [ %phi.484, %BB_6740 ], [ %ldstrongv_lane3.7, %BB_69b0.loopexit ]
  %phi.501 = phi i32 [ %phi.485, %BB_6740 ], [ %ldstrongv_lane1.7, %BB_69b0.loopexit ]
  %phi.502 = phi i32 [ %phi.486, %BB_6740 ], [ %ldstrongv_lane0.7, %BB_69b0.loopexit ]
  br i1 %isetrp_cmp2.195, label %BB_6a80, label %BB_69d0

BB_69d0:                                          ; preds = %BB_69b0
  %.mask59 = and i64 %1299, 4294967295
  %stg_val_r2_ext.9 = zext nneg i64 %.mask59 to i128
  %stg_val_r2_shift.9 = shl nuw nsw i128 %stg_val_r2_ext.9, 64
  %stg_val_packed_1.9 = zext i64 %1301 to i128
  %stg_val_packed_2.9 = or disjoint i128 %stg_val_r2_shift.9, %stg_val_packed_1.9
  %1302 = lshr i64 %1299, 32
  %stg_val_r3_ext.9 = zext nneg i64 %1302 to i128
  %stg_val_r3_shift.9 = shl nuw i128 %stg_val_r3_ext.9, 96
  %stg_val_packed_3.9 = or disjoint i128 %stg_val_packed_2.9, %stg_val_r3_shift.9
  %imad_lhs_64.61 = sext i32 %imad.319 to i64
  %imad_tmp_64.61 = shl nsw i64 %imad_lhs_64.61, 4
  %imad_lhs_64.60 = sext i32 %imad_tmp.281 to i64
  %imad_tmp_64.60 = shl nsw i64 %imad_lhs_64.60, 5
  %1303 = add i64 %imad_tmp_64.60, %966
  %1304 = add i64 %imad_tmp_64.61, %1303
  %imad.326 = add i64 %imad_tmp_64.61, %1303
  %.3236 = getelementptr inbounds nuw i8, ptr %param_local, i64 680
  %iadd3_o2.82 = load i32, ptr %.3236, align 4
  %1305 = zext i32 %iadd3_o2.82 to i64
  %1306 = add i64 %1304, %1305
  %.3238 = getelementptr inbounds nuw i8, ptr %param_local, i64 684
  %iadd3_o2.83 = load i32, ptr %.3238, align 4
  %1307 = zext i32 %iadd3_o2.83 to i64
  %1308 = shl nuw i64 %1307, 32
  %1309 = add i64 %1306, %1308
  %"R1452:R1337_addr_ptr" = inttoptr i64 %1309 to ptr addrspace(1)
  store i128 %stg_val_packed_3.9, ptr addrspace(1) %"R1452:R1337_addr_ptr", align 8
  %.mask64 = and i64 %1298, 4294967295
  %stg_val_r2_ext.10 = zext nneg i64 %.mask64 to i128
  %stg_val_r2_shift.10 = shl nuw nsw i128 %stg_val_r2_ext.10, 64
  %stg_val_packed_1.10 = zext i64 %1300 to i128
  %stg_val_packed_2.10 = or disjoint i128 %stg_val_r2_shift.10, %stg_val_packed_1.10
  %1310 = lshr i64 %1298, 32
  %stg_val_r3_ext.10 = zext nneg i64 %1310 to i128
  %stg_val_r3_shift.10 = shl nuw i128 %stg_val_r3_ext.10, 96
  %stg_val_packed_3.10 = or disjoint i128 %stg_val_packed_2.10, %stg_val_r3_shift.10
  %1311 = and i64 %imad.326, 4294967295
  %1312 = zext i32 %iadd3_o2.82 to i64
  %1313 = add nuw nsw i64 %1311, %1312
  %.3255 = shl nsw i64 %1253, 4
  %1314 = add nsw i64 %1313, %.3255
  %.3256 = lshr i64 %.3255, 32
  %1315 = and i64 %imad.326, -4294967296
  %1316 = add i64 %1314, %1315
  %1317 = zext i32 %iadd3_o2.83 to i64
  %1318 = shl nuw i64 %1317, 32
  %1319 = add i64 %1316, %1318
  %"R413:R1066_addr_ptr" = inttoptr i64 %1319 to ptr addrspace(1)
  store i128 %stg_val_packed_3.10, ptr addrspace(1) %"R413:R1066_addr_ptr", align 8
  %"R5:R4_r1_shift.4" = lshr i64 %imad.326, 32
  %"R5:R4_r1.4" = trunc nuw i64 %"R5:R4_r1_shift.4" to i32
  %iadd3_n1.178 = add i32 %iadd3_o2.83, %"R5:R4_r1.4"
  %iadd3_o1_64.29 = and i64 %imad.326, 4294967295
  %iadd3_o2_64.29 = zext i32 %iadd3_o2.82 to i64
  %iadd3_tmp.29 = add nuw nsw i64 %iadd3_o1_64.29, %iadd3_o2_64.29
  %carry_ge_1.29 = icmp samesign ugt i64 %iadd3_tmp.29, 4294967295
  %iadd3_cin1_narrow_zext.19 = zext i1 %carry_ge_1.29 to i32
  %iadd3_cin1_add.19 = add i32 %iadd3_n1.178, %iadd3_cin1_narrow_zext.19
  %.3241 = and i64 %iadd3_tmp.29, 4294967295
  %.3243 = shl nuw nsw i64 %.3201, 4
  %.3244 = and i64 %.3243, 4294965248
  %.3245 = add nuw nsw i64 %.3244, %.3241
  %.3246 = trunc i64 %.3245 to i32
  %.3248 = icmp samesign ugt i64 %.3245, 4294967295
  %.3258 = zext i1 %.3248 to i64
  %stg_addr_r1_ext.9 = zext i32 %iadd3_cin1_add.19 to i64
  %.3257 = add nuw nsw i64 %.3256, %stg_addr_r1_ext.9
  %.3259 = add nuw nsw i64 %.3257, %.3258
  %.3260 = trunc i64 %.3259 to i32
  br label %BB_6a80

BB_6a80:                                          ; preds = %BB_6720, %BB_69b0, %BB_69d0
  %1320 = phi i64 [ %1298, %BB_69d0 ], [ %1240, %BB_6720 ], [ %1298, %BB_69b0 ]
  %1321 = phi i64 [ %1299, %BB_69d0 ], [ %1248, %BB_6720 ], [ %1299, %BB_69b0 ]
  %1322 = phi i64 [ %1300, %BB_69d0 ], [ %1244, %BB_6720 ], [ %1300, %BB_69b0 ]
  %1323 = phi i64 [ %1301, %BB_69d0 ], [ %1252, %BB_6720 ], [ %1301, %BB_69b0 ]
  %phi.511 = phi i32 [ %iadd3_cin1_add.19, %BB_69d0 ], [ %phi.484, %BB_6720 ], [ %phi.500, %BB_69b0 ]
  %phi.512 = phi i32 [ %.3260, %BB_69d0 ], [ %phi.485, %BB_6720 ], [ %phi.501, %BB_69b0 ]
  %phi.513 = phi i32 [ %.3246, %BB_69d0 ], [ %phi.486, %BB_6720 ], [ %phi.502, %BB_69b0 ]
  br i1 %isetrp_cmp2.195, label %BB_6a90, label %BB_7090

BB_6a90:                                          ; preds = %BB_6a80
  %iadd3_n1.179 = add i32 %iadd3_n1.126, 32
  %isetrp_rhs.92 = load i32, ptr %.355, align 4
  %isetrp_cmp1.203.not = icmp slt i32 %iadd3_n1.179, %isetrp_rhs.92
  br i1 %isetrp_cmp1.146.not, label %BB_6ae0, label %BB_80006ad0

BB_80006ad0:                                      ; preds = %BB_6a90
  %.3274 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %imad_rhs.140 = load i32, ptr %.3274, align 4
  %imad_lhs_64.62 = zext i32 %iadd3_n1.179 to i64
  %imad_rhs_64.62 = zext i32 %imad_rhs.140 to i64
  %imad_tmp_64.62 = mul nuw i64 %imad_lhs_64.62, %imad_rhs_64.62
  %imad_tmp_hi.21 = lshr i64 %imad_tmp_64.62, 32
  %imad_tmp_hi_trunc.21 = trunc nuw i64 %imad_tmp_hi.21 to i32
  br label %BB_6ae0

BB_6ae0:                                          ; preds = %BB_80006ad0, %BB_6a90
  %phi.522 = phi i32 [ %imad_tmp_hi_trunc.21, %BB_80006ad0 ], [ %phi.513, %BB_6a90 ]
  %isetrp_cmp1.204 = icmp slt i32 %.2177, %imad_tmp.216
  %isetrp_cmp2.204 = and i1 %isetrp_cmp1.204, %isetrp_cmp1.203.not
  br i1 %isetrp_cmp1.146.not, label %BB_6b20, label %BB_80006af0

BB_80006af0:                                      ; preds = %BB_6ae0
  %.3279 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %shf_shift.21 = load i32, ptr %.3279, align 4
  %.3282 = zext i32 %phi.522 to i64
  %.3283 = shl nuw i64 %.3282, 32
  %shf_shift_64.67 = zext nneg i32 %shf_shift.21 to i64
  %.3284 = lshr i64 %.3283, %shf_shift_64.67
  %shf_hi.43 = lshr i64 %.3284, 32
  %shf_result.67 = trunc nuw i64 %shf_hi.43 to i32
  %imad_rhs.141 = load i32, ptr %.187, align 4
  %1324 = mul i32 %imad_rhs.141, %shf_result.67
  %imad.327 = sub i32 %iadd3_n1.179, %1324
  br label %BB_6b20

BB_6b20:                                          ; preds = %BB_80006af0, %BB_6ae0
  %spec.select84 = phi i32 [ %shf_result.67, %BB_80006af0 ], [ %iadd3_n1.179, %BB_6ae0 ]
  %phi.523 = phi i32 [ %imad.327, %BB_80006af0 ], [ 0, %BB_6ae0 ]
  %.3288 = getelementptr inbounds nuw i8, ptr %param_local, i64 596
  %imad_rhs.142 = load i32, ptr %.3288, align 4
  %imad_tmp.287 = mul i32 %.2177, %imad_rhs.142
  br i1 %isetrp_cmp1.147.not, label %BB_6b40, label %BB_80006b30

BB_80006b30:                                      ; preds = %BB_6b20
  %.3292 = getelementptr inbounds nuw i8, ptr %param_local, i64 992
  %imad_rhs.143 = load i32, ptr %.3292, align 4
  %imad_lhs_64.63 = zext i32 %phi.523 to i64
  %imad_rhs_64.63 = zext i32 %imad_rhs.143 to i64
  %imad_tmp_64.63 = mul nuw i64 %imad_lhs_64.63, %imad_rhs_64.63
  %imad_tmp_hi.22 = lshr i64 %imad_tmp_64.63, 32
  %imad_tmp_hi_trunc.22 = trunc nuw i64 %imad_tmp_hi.22 to i32
  br label %BB_6b40

BB_6b40:                                          ; preds = %BB_80006b30, %BB_6b20
  %phi.525 = phi i32 [ %imad_tmp_hi_trunc.22, %BB_80006b30 ], [ %phi.511, %BB_6b20 ]
  br i1 %isetrp_cmp1.147.not, label %BB_6b60, label %BB_80006b50

BB_80006b50:                                      ; preds = %BB_6b40
  %.3298 = getelementptr inbounds nuw i8, ptr %param_local, i64 996
  %shf_shift.22 = load i32, ptr %.3298, align 4
  %.3301 = zext i32 %phi.525 to i64
  %.3302 = shl nuw i64 %.3301, 32
  %shf_shift_64.68 = zext nneg i32 %shf_shift.22 to i64
  %.3303 = lshr i64 %.3302, %shf_shift_64.68
  %shf_hi.44 = lshr i64 %.3303, 32
  %shf_result.68 = trunc nuw i64 %shf_hi.44 to i32
  br label %BB_6b60

BB_6b60:                                          ; preds = %BB_80006b50, %BB_6b40
  %phi.529 = phi i32 [ %shf_result.68, %BB_80006b50 ], [ %phi.523, %BB_6b40 ]
  %phi.527 = phi i32 [ %shf_result.68, %BB_80006b50 ], [ %phi.525, %BB_6b40 ]
  %.3305 = getelementptr inbounds nuw i8, ptr %param_local, i64 580
  %imad_rhs.144 = load i32, ptr %.3305, align 4
  %imad_tmp.288 = mul i32 %spec.select84, %imad_rhs.144
  %imad.329 = add i32 %imad_tmp.288, %imad_tmp.287
  %iadd3_o1_neg.20 = sub i32 0, %phi.527
  %imad_rhs.145 = load i32, ptr %.193, align 4
  %imad_tmp.289 = mul i32 %imad_rhs.145, %iadd3_o1_neg.20
  %imad.330 = add i32 %imad_tmp.289, %phi.523
  %phi.528 = select i1 %isetrp_cmp1.147.not, i32 0, i32 %imad.330
  %phi.530 = select i1 %isetrp_cmp1.147.not, i32 %phi.512, i32 %iadd3_o1_neg.20
  br i1 %isetrp_cmp1.148.not, label %BB_6bb0, label %BB_80006ba0

BB_80006ba0:                                      ; preds = %BB_6b60
  %.3313 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.146 = load i32, ptr %.3313, align 4
  %imad_lhs_64.64 = zext i32 %phi.528 to i64
  %imad_rhs_64.64 = zext i32 %imad_rhs.146 to i64
  %imad_tmp_64.64 = mul nuw i64 %imad_lhs_64.64, %imad_rhs_64.64
  %imad_tmp_hi.23 = lshr i64 %imad_tmp_64.64, 32
  %imad_tmp_hi_trunc.23 = trunc nuw i64 %imad_tmp_hi.23 to i32
  br label %BB_6bb0

BB_6bb0:                                          ; preds = %BB_80006ba0, %BB_6b60
  %phi.531 = phi i32 [ %imad_tmp_hi_trunc.23, %BB_80006ba0 ], [ %phi.530, %BB_6b60 ]
  %.3316 = getelementptr inbounds nuw i8, ptr %param_local, i64 584
  %imad_rhs.147 = load i32, ptr %.3316, align 4
  %imad_tmp.290 = mul i32 %phi.529, %imad_rhs.147
  %imad.331 = add i32 %imad_tmp.290, %imad.329
  br i1 %isetrp_cmp1.148.not, label %BB_6c00, label %BB_80006bc0

BB_80006bc0:                                      ; preds = %BB_6bb0
  %.3320 = getelementptr inbounds nuw i8, ptr %param_local, i64 1004
  %shf_shift.23 = load i32, ptr %.3320, align 4
  %.3323 = zext i32 %phi.531 to i64
  %.3324 = shl nuw i64 %.3323, 32
  %shf_shift_64.69 = zext nneg i32 %shf_shift.23 to i64
  %.3325 = lshr i64 %.3324, %shf_shift_64.69
  %shf_hi.45 = lshr i64 %.3325, 32
  %shf_result.69 = trunc nuw i64 %shf_hi.45 to i32
  %imad_rhs.148 = load i32, ptr %.197, align 4
  %1325 = mul i32 %imad_rhs.148, %shf_result.69
  %imad.333 = sub i32 %phi.528, %1325
  br label %BB_6c00

BB_6c00:                                          ; preds = %BB_80006bc0, %BB_6bb0
  %phi.532 = phi i32 [ %shf_result.69, %BB_80006bc0 ], [ %phi.528, %BB_6bb0 ]
  %phi.533 = phi i32 [ %imad.333, %BB_80006bc0 ], [ 0, %BB_6bb0 ]
  %.3329 = getelementptr inbounds nuw i8, ptr %param_local, i64 588
  %imad_rhs.149 = load i32, ptr %.3329, align 4
  %imad_tmp.293 = mul i32 %phi.532, %imad_rhs.149
  %imad.334 = add i32 %imad_tmp.293, %imad.331
  %.3331 = getelementptr inbounds nuw i8, ptr %param_local, i64 592
  %imad_rhs.150 = load i32, ptr %.3331, align 4
  %imad_tmp.294 = mul i32 %phi.533, %imad_rhs.150
  %imad.335 = add i32 %imad_tmp.294, %imad.334
  %sel.98 = select i1 %isetrp_cmp2.204, i32 %imad.335, i32 -1
  %isetrp_cmp1.205 = icmp sgt i32 %sel.98, -1
  br i1 %isetrp_cmp1.205, label %BB_80006c60, label %BB_6c90

BB_80006c60:                                      ; preds = %BB_6c00
  %.3335 = getelementptr inbounds nuw i8, ptr %param_local, i64 376
  %imad_addend.50 = load i64, ptr %.3335, align 8
  %1326 = shl nuw i32 %sel.98, 1
  %imad_tmp_64.65 = zext i32 %1326 to i64
  %1327 = add i64 %imad_addend.50, %imad_tmp_64.65
  %"R38:R1656_addr_ptr" = inttoptr i64 %1327 to ptr addrspace(1)
  %ldg_vec.2 = load <4 x i32>, ptr addrspace(1) %"R38:R1656_addr_ptr", align 16
  %ldg_lane0.2 = extractelement <4 x i32> %ldg_vec.2, i64 0
  %ldg_lane1.2 = extractelement <4 x i32> %ldg_vec.2, i64 1
  %ldg_lane2.2 = extractelement <4 x i32> %ldg_vec.2, i64 2
  %ldg_lane3.2 = extractelement <4 x i32> %ldg_vec.2, i64 3
  br label %BB_6c90

BB_6c90:                                          ; preds = %BB_80006c60, %BB_6c00
  %phi.534 = phi i32 [ %ldg_lane3.2, %BB_80006c60 ], [ 0, %BB_6c00 ]
  %phi.535 = phi i32 [ %ldg_lane2.2, %BB_80006c60 ], [ 0, %BB_6c00 ]
  %phi.536 = phi i32 [ %ldg_lane1.2, %BB_80006c60 ], [ 0, %BB_6c00 ]
  %phi.537 = phi i32 [ %ldg_lane0.2, %BB_80006c60 ], [ 0, %BB_6c00 ]
  %1328 = zext nneg i32 %imad.217 to i64
  %.3338 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1328
  store volatile i64 %1323, ptr addrspace(3) %.3338, align 8
  %sts_addr_memaddr_offset_add.9 = add nuw nsw i32 %imad.217, 16
  %1329 = zext nneg i32 %sts_addr_memaddr_offset_add.9 to i64
  %.3340 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1329
  store volatile i64 %1322, ptr addrspace(3) %.3340, align 8
  %sts_addr_memaddr_offset_add.10 = add nuw nsw i32 %imad.217, 1280
  %1330 = zext nneg i32 %sts_addr_memaddr_offset_add.10 to i64
  %.3342 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1330
  store volatile i64 %1321, ptr addrspace(3) %.3342, align 8
  %sts_addr_memaddr_offset_add.11 = add nuw nsw i32 %imad.217, 1296
  %1331 = zext nneg i32 %sts_addr_memaddr_offset_add.11 to i64
  %.3344 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1331
  store volatile i64 %1320, ptr addrspace(3) %.3344, align 8
  call void @llvm.nvvm.barrier0()
  %1332 = shl i32 %phi.537, 16
  %1333 = lshr exact i32 %1332, 3
  %1334 = and i32 %1333, 268427264
  %1335 = icmp samesign ugt i32 %1334, 260046847
  %1336 = select i1 %1335, i32 2139095040, i32 0
  %1337 = or i32 %1334, %1336
  %1338 = bitcast i32 %1337 to float
  %1339 = fmul float %1338, 0x46F0000000000000
  %1340 = bitcast i32 %1332 to float
  %1341 = call float @llvm.copysign.f32(float %1339, float %1340)
  %lds_shared_addr_winoff.6.xscale = shl i32 %imad.219, 4
  %lds_shared_addr_winoff.6 = and i32 %lds_shared_addr_winoff.6.xscale, 16777200
  %1342 = zext nneg i32 %lds_shared_addr_winoff.6 to i64
  %.3346 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1342
  %lds.6 = load volatile i128, ptr addrspace(3) %.3346, align 8
  %lds_addr_memaddr_offset_add.3 = add i32 %lds_shared_addr_winoff.6.xscale, 80
  %lds_shared_addr_winoff.7 = and i32 %lds_addr_memaddr_offset_add.3, 16777200
  %1343 = zext nneg i32 %lds_shared_addr_winoff.7 to i64
  %.3347 = getelementptr inbounds nuw [12288 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %1343
  %lds.7 = load volatile i128, ptr addrspace(3) %.3347, align 8
  %"R11:R10:R9:R8_r0.1" = trunc i128 %lds.6 to i32
  %ffma_lhs_bitcast.32 = bitcast i32 %"R11:R10:R9:R8_r0.1" to float
  %1344 = shl i32 %phi.284, 16
  %1345 = lshr exact i32 %1344, 3
  %1346 = and i32 %1345, 268427264
  %1347 = icmp samesign ugt i32 %1346, 260046847
  %1348 = select i1 %1347, i32 2139095040, i32 0
  %1349 = or i32 %1346, %1348
  %1350 = bitcast i32 %1349 to float
  %1351 = fmul float %1350, 0x46F0000000000000
  %1352 = bitcast i32 %1344 to float
  %1353 = call float @llvm.copysign.f32(float %1351, float %1352)
  %ffma.32 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.32, float %phi.292, float %1353)
  %ffma.40 = call float @llvm.fma.f32(float %1341, float %phi.291, float %ffma.32)
  %.3348 = getelementptr inbounds nuw i8, ptr %param_local, i64 528
  %fmnmx_rhs.48 = load float, ptr %.3348, align 4
  %fmnmx_max.24 = call float @llvm.maximum.f32(float %ffma.40, float %fmnmx_rhs.48)
  %1354 = shl i32 %phi.536, 16
  %1355 = lshr exact i32 %1354, 3
  %1356 = and i32 %1355, 268427264
  %1357 = icmp samesign ugt i32 %1356, 260046847
  %1358 = select i1 %1357, i32 2139095040, i32 0
  %1359 = or i32 %1356, %1358
  %1360 = bitcast i32 %1359 to float
  %1361 = fmul float %1360, 0x46F0000000000000
  %1362 = bitcast i32 %1354 to float
  %1363 = call float @llvm.copysign.f32(float %1361, float %1362)
  %"R11:R10:R9:R8_r2_shift.1" = lshr i128 %lds.6, 64
  %"R11:R10:R9:R8_r2.1" = trunc i128 %"R11:R10:R9:R8_r2_shift.1" to i32
  %ffma_lhs_bitcast.33 = bitcast i32 %"R11:R10:R9:R8_r2.1" to float
  %1364 = shl i32 %phi.283, 16
  %1365 = lshr exact i32 %1364, 3
  %1366 = and i32 %1365, 268427264
  %1367 = icmp samesign ugt i32 %1366, 260046847
  %1368 = select i1 %1367, i32 2139095040, i32 0
  %1369 = or i32 %1366, %1368
  %1370 = bitcast i32 %1369 to float
  %1371 = fmul float %1370, 0x46F0000000000000
  %1372 = bitcast i32 %1364 to float
  %1373 = call float @llvm.copysign.f32(float %1371, float %1372)
  %ffma.33 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.33, float %phi.292, float %1373)
  %ffma.41 = call float @llvm.fma.f32(float %1363, float %phi.291, float %ffma.33)
  %fmnmx_max.25 = call float @llvm.maximum.f32(float %ffma.41, float %fmnmx_rhs.48)
  %extelt.offset70 = and i32 %phi.536, -65536
  %1374 = lshr i32 %phi.536, 3
  %1375 = and i32 %1374, 268427264
  %1376 = icmp samesign ugt i32 %1375, 260046847
  %1377 = select i1 %1376, i32 2139095040, i32 0
  %1378 = or i32 %1375, %1377
  %1379 = bitcast i32 %1378 to float
  %1380 = fmul float %1379, 0x46F0000000000000
  %1381 = bitcast i32 %extelt.offset70 to float
  %1382 = call float @llvm.copysign.f32(float %1380, float %1381)
  %"R11:R10:R9:R8_r3_shift.1" = lshr i128 %lds.6, 96
  %"R11:R10:R9:R8_r3.1" = trunc nuw i128 %"R11:R10:R9:R8_r3_shift.1" to i32
  %ffma_lhs_bitcast.34 = bitcast i32 %"R11:R10:R9:R8_r3.1" to float
  %extelt.offset66 = and i32 %phi.283, -65536
  %1383 = lshr i32 %phi.283, 3
  %1384 = and i32 %1383, 268427264
  %1385 = icmp samesign ugt i32 %1384, 260046847
  %1386 = select i1 %1385, i32 2139095040, i32 0
  %1387 = or i32 %1384, %1386
  %1388 = bitcast i32 %1387 to float
  %1389 = fmul float %1388, 0x46F0000000000000
  %1390 = bitcast i32 %extelt.offset66 to float
  %1391 = call float @llvm.copysign.f32(float %1389, float %1390)
  %ffma.34 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.34, float %phi.292, float %1391)
  %ffma.42 = call float @llvm.fma.f32(float %1382, float %phi.291, float %ffma.34)
  %fmnmx_max.26 = call float @llvm.maximum.f32(float %ffma.42, float %fmnmx_rhs.48)
  %extelt.offset71 = and i32 %phi.537, -65536
  %1392 = lshr i32 %phi.537, 3
  %1393 = and i32 %1392, 268427264
  %1394 = icmp samesign ugt i32 %1393, 260046847
  %1395 = select i1 %1394, i32 2139095040, i32 0
  %1396 = or i32 %1393, %1395
  %1397 = bitcast i32 %1396 to float
  %1398 = fmul float %1397, 0x46F0000000000000
  %1399 = bitcast i32 %extelt.offset71 to float
  %1400 = call float @llvm.copysign.f32(float %1398, float %1399)
  %"R11:R10:R9:R8_r1_shift.1" = lshr i128 %lds.6, 32
  %"R11:R10:R9:R8_r1.1" = trunc i128 %"R11:R10:R9:R8_r1_shift.1" to i32
  %ffma_lhs_bitcast.35 = bitcast i32 %"R11:R10:R9:R8_r1.1" to float
  %extelt.offset67 = and i32 %phi.284, -65536
  %1401 = lshr i32 %phi.284, 3
  %1402 = and i32 %1401, 268427264
  %1403 = icmp samesign ugt i32 %1402, 260046847
  %1404 = select i1 %1403, i32 2139095040, i32 0
  %1405 = or i32 %1402, %1404
  %1406 = bitcast i32 %1405 to float
  %1407 = fmul float %1406, 0x46F0000000000000
  %1408 = bitcast i32 %extelt.offset67 to float
  %1409 = call float @llvm.copysign.f32(float %1407, float %1408)
  %ffma.35 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.35, float %phi.292, float %1409)
  %ffma.44 = call float @llvm.fma.f32(float %1400, float %phi.291, float %ffma.35)
  %fmnmx_max.27 = call float @llvm.maximum.f32(float %ffma.44, float %fmnmx_rhs.48)
  %1410 = shl i32 %phi.535, 16
  %1411 = lshr exact i32 %1410, 3
  %1412 = and i32 %1411, 268427264
  %1413 = icmp samesign ugt i32 %1412, 260046847
  %1414 = select i1 %1413, i32 2139095040, i32 0
  %1415 = or i32 %1412, %1414
  %1416 = bitcast i32 %1415 to float
  %1417 = fmul float %1416, 0x46F0000000000000
  %1418 = bitcast i32 %1410 to float
  %1419 = call float @llvm.copysign.f32(float %1417, float %1418)
  %"R23:R22:R21:R20_r0.4" = trunc i128 %lds.7 to i32
  %ffma_lhs_bitcast.36 = bitcast i32 %"R23:R22:R21:R20_r0.4" to float
  %1420 = shl i32 %phi.282, 16
  %1421 = lshr exact i32 %1420, 3
  %1422 = and i32 %1421, 268427264
  %1423 = icmp samesign ugt i32 %1422, 260046847
  %1424 = select i1 %1423, i32 2139095040, i32 0
  %1425 = or i32 %1422, %1424
  %1426 = bitcast i32 %1425 to float
  %1427 = fmul float %1426, 0x46F0000000000000
  %1428 = bitcast i32 %1420 to float
  %1429 = call float @llvm.copysign.f32(float %1427, float %1428)
  %ffma.36 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.36, float %phi.292, float %1429)
  %ffma.45 = call float @llvm.fma.f32(float %1419, float %phi.291, float %ffma.36)
  %fmnmx_max.28 = call float @llvm.maximum.f32(float %ffma.45, float %fmnmx_rhs.48)
  %extelt.offset72 = and i32 %phi.535, -65536
  %1430 = lshr i32 %phi.535, 3
  %1431 = and i32 %1430, 268427264
  %1432 = icmp samesign ugt i32 %1431, 260046847
  %1433 = select i1 %1432, i32 2139095040, i32 0
  %1434 = or i32 %1431, %1433
  %1435 = bitcast i32 %1434 to float
  %1436 = fmul float %1435, 0x46F0000000000000
  %1437 = bitcast i32 %extelt.offset72 to float
  %1438 = call float @llvm.copysign.f32(float %1436, float %1437)
  %"R23:R22:R21:R20_r1_shift.4" = lshr i128 %lds.7, 32
  %"R23:R22:R21:R20_r1.4" = trunc i128 %"R23:R22:R21:R20_r1_shift.4" to i32
  %ffma_lhs_bitcast.37 = bitcast i32 %"R23:R22:R21:R20_r1.4" to float
  %extelt.offset68 = and i32 %phi.282, -65536
  %1439 = lshr i32 %phi.282, 3
  %1440 = and i32 %1439, 268427264
  %1441 = icmp samesign ugt i32 %1440, 260046847
  %1442 = select i1 %1441, i32 2139095040, i32 0
  %1443 = or i32 %1440, %1442
  %1444 = bitcast i32 %1443 to float
  %1445 = fmul float %1444, 0x46F0000000000000
  %1446 = bitcast i32 %extelt.offset68 to float
  %1447 = call float @llvm.copysign.f32(float %1445, float %1446)
  %ffma.37 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.37, float %phi.292, float %1447)
  %ffma.46 = call float @llvm.fma.f32(float %1438, float %phi.291, float %ffma.37)
  %fmnmx_max.29 = call float @llvm.maximum.f32(float %ffma.46, float %fmnmx_rhs.48)
  %1448 = shl i32 %phi.534, 16
  %1449 = lshr exact i32 %1448, 3
  %1450 = and i32 %1449, 268427264
  %1451 = icmp samesign ugt i32 %1450, 260046847
  %1452 = select i1 %1451, i32 2139095040, i32 0
  %1453 = or i32 %1450, %1452
  %1454 = bitcast i32 %1453 to float
  %1455 = fmul float %1454, 0x46F0000000000000
  %1456 = bitcast i32 %1448 to float
  %1457 = call float @llvm.copysign.f32(float %1455, float %1456)
  %"R23:R22:R21:R20_r2_shift.4" = lshr i128 %lds.7, 64
  %"R23:R22:R21:R20_r2.4" = trunc i128 %"R23:R22:R21:R20_r2_shift.4" to i32
  %ffma_lhs_bitcast.38 = bitcast i32 %"R23:R22:R21:R20_r2.4" to float
  %1458 = shl i32 %phi.281, 16
  %1459 = lshr exact i32 %1458, 3
  %1460 = and i32 %1459, 268427264
  %1461 = icmp samesign ugt i32 %1460, 260046847
  %1462 = select i1 %1461, i32 2139095040, i32 0
  %1463 = or i32 %1460, %1462
  %1464 = bitcast i32 %1463 to float
  %1465 = fmul float %1464, 0x46F0000000000000
  %1466 = bitcast i32 %1458 to float
  %1467 = call float @llvm.copysign.f32(float %1465, float %1466)
  %ffma.38 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.38, float %phi.292, float %1467)
  %ffma.43 = call float @llvm.fma.f32(float %1457, float %phi.291, float %ffma.38)
  %fmnmx_max.30 = call float @llvm.maximum.f32(float %ffma.43, float %fmnmx_rhs.48)
  %extelt.offset73 = and i32 %phi.534, -65536
  %1468 = lshr i32 %phi.534, 3
  %1469 = and i32 %1468, 268427264
  %1470 = icmp samesign ugt i32 %1469, 260046847
  %1471 = select i1 %1470, i32 2139095040, i32 0
  %1472 = or i32 %1469, %1471
  %1473 = bitcast i32 %1472 to float
  %1474 = fmul float %1473, 0x46F0000000000000
  %1475 = bitcast i32 %extelt.offset73 to float
  %1476 = call float @llvm.copysign.f32(float %1474, float %1475)
  %"R23:R22:R21:R20_r3_shift.4" = lshr i128 %lds.7, 96
  %"R23:R22:R21:R20_r3.4" = trunc nuw i128 %"R23:R22:R21:R20_r3_shift.4" to i32
  %ffma_lhs_bitcast.39 = bitcast i32 %"R23:R22:R21:R20_r3.4" to float
  %extelt.offset69 = and i32 %phi.281, -65536
  %1477 = lshr i32 %phi.281, 3
  %1478 = and i32 %1477, 268427264
  %1479 = icmp samesign ugt i32 %1478, 260046847
  %1480 = select i1 %1479, i32 2139095040, i32 0
  %1481 = or i32 %1478, %1480
  %1482 = bitcast i32 %1481 to float
  %1483 = fmul float %1482, 0x46F0000000000000
  %1484 = bitcast i32 %extelt.offset69 to float
  %1485 = call float @llvm.copysign.f32(float %1483, float %1484)
  %ffma.39 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.39, float %phi.292, float %1485)
  %ffma.47 = call float @llvm.fma.f32(float %1476, float %phi.291, float %ffma.39)
  %fmnmx_max.31 = call float @llvm.maximum.f32(float %ffma.47, float %fmnmx_rhs.48)
  %.3367 = getelementptr inbounds nuw i8, ptr %param_local, i64 544
  %fmnmx_rhs.56 = load float, ptr %.3367, align 4
  %fmnmx_min.24 = call float @llvm.minimum.f32(float %fmnmx_max.24, float %fmnmx_rhs.56)
  %fmnmx_min.25 = call float @llvm.minimum.f32(float %fmnmx_max.25, float %fmnmx_rhs.56)
  %phi_cast_R728_bitcast = bitcast float %fmnmx_min.25 to i32
  %1486 = zext i32 %phi_cast_R728_bitcast to i64
  %1487 = shl nuw i64 %1486, 32
  %fmnmx_min.26 = call float @llvm.minimum.f32(float %fmnmx_max.26, float %fmnmx_rhs.56)
  %phi_cast_R1112_bitcast = bitcast float %fmnmx_min.26 to i32
  %1488 = zext i32 %phi_cast_R1112_bitcast to i64
  %1489 = or disjoint i64 %1487, %1488
  %fmnmx_min.27 = call float @llvm.minimum.f32(float %fmnmx_max.27, float %fmnmx_rhs.56)
  %fmnmx_min.28 = call float @llvm.minimum.f32(float %fmnmx_max.28, float %fmnmx_rhs.56)
  %fmnmx_min.29 = call float @llvm.minimum.f32(float %fmnmx_max.29, float %fmnmx_rhs.56)
  %fmnmx_min.30 = call float @llvm.minimum.f32(float %fmnmx_max.30, float %fmnmx_rhs.56)
  %fmnmx_min.31 = call float @llvm.minimum.f32(float %fmnmx_max.31, float %fmnmx_rhs.56)
  %1490 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.26, float %fmnmx_min.25)
  %1491 = extractvalue { i32, i32 } %1490, 0
  %1492 = extractvalue { i32, i32 } %1490, 1
  %f2fp_a_shift.12 = shl nuw i32 %1491, 16
  %f2fp_packed.12 = or disjoint i32 %f2fp_a_shift.12, %1492
  br i1 %isetrp_cmp1.205, label %BB_80007020, label %BB_7030

BB_80007020:                                      ; preds = %BB_6c90
  %.3385 = getelementptr inbounds nuw i8, ptr %param_local, i64 368
  %imad_addend.51 = load i64, ptr %.3385, align 8
  %1493 = shl nuw i32 %sel.98, 1
  %imad_tmp_64.66 = zext i32 %1493 to i64
  %1494 = add i64 %imad_addend.51, %imad_tmp_64.66
  br label %BB_7030

BB_7030:                                          ; preds = %BB_80007020, %BB_6c90
  %1495 = phi i64 [ %1494, %BB_80007020 ], [ %1489, %BB_6c90 ]
  br i1 %isetrp_cmp1.205, label %BB_80007060, label %BB_7090

BB_80007060:                                      ; preds = %BB_7030
  %1496 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min.31, float %fmnmx_min.30, float %fmnmx_min.29, float %fmnmx_min.28)
  %1497 = extractvalue { i32, i32, i32, i32 } %1496, 0
  %1498 = extractvalue { i32, i32, i32, i32 } %1496, 1
  %1499 = extractvalue { i32, i32, i32, i32 } %1496, 2
  %1500 = extractvalue { i32, i32, i32, i32 } %1496, 3
  %f2fp_a_shift.15 = shl nuw i32 %1497, 16
  %f2fp_packed.15 = or disjoint i32 %f2fp_a_shift.15, %1498
  %f2fp_a_shift.14 = shl nuw i32 %1499, 16
  %f2fp_packed.14 = or disjoint i32 %f2fp_a_shift.14, %1500
  %1501 = call { i32, i32 } @lo.cvt.a2(float %fmnmx_min.27, float %fmnmx_min.24)
  %1502 = extractvalue { i32, i32 } %1501, 0
  %1503 = extractvalue { i32, i32 } %1501, 1
  %f2fp_a_shift.13 = shl nuw i32 %1502, 16
  %f2fp_packed.13 = or disjoint i32 %f2fp_a_shift.13, %1503
  %stg_val_r0_ext.11 = zext i32 %f2fp_packed.13 to i128
  %stg_val_r1_ext.11 = zext i32 %f2fp_packed.12 to i128
  %stg_val_r1_shift.11 = shl nuw nsw i128 %stg_val_r1_ext.11, 32
  %stg_val_packed_1.11 = or disjoint i128 %stg_val_r1_shift.11, %stg_val_r0_ext.11
  %stg_val_r2_ext.11 = zext i32 %f2fp_packed.14 to i128
  %stg_val_r2_shift.11 = shl nuw nsw i128 %stg_val_r2_ext.11, 64
  %stg_val_packed_2.11 = or disjoint i128 %stg_val_packed_1.11, %stg_val_r2_shift.11
  %stg_val_r3_ext.11 = zext i32 %f2fp_packed.15 to i128
  %stg_val_r3_shift.11 = shl nuw i128 %stg_val_r3_ext.11, 96
  %stg_val_packed_3.11 = or disjoint i128 %stg_val_packed_2.11, %stg_val_r3_shift.11
  %"R730:R1275_addr_ptr" = inttoptr i64 %1495 to ptr addrspace(1)
  store i128 %stg_val_packed_3.11, ptr addrspace(1) %"R730:R1275_addr_ptr", align 8
  br label %BB_7090

BB_7090:                                          ; preds = %BB_6a80, %BB_7030, %BB_80007060
  %1504 = zext i1 %isetrp_cmp1.206.not to i32
  %1505 = icmp ne i32 %1504, 0
  br i1 %1505, label %BB_70a0, label %BB_71b0

BB_70a0:                                          ; preds = %BB_7090
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.207.not = icmp eq i32 %tid_x, 0
  br i1 %isetrp_cmp1.207.not, label %BB_7110, label %BB_71b0

BB_7110:                                          ; preds = %BB_70a0
  %warp_reconv_mask.2 = call i32 asm sideeffect "activemask.b32 $0;", "=r"() #10
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.2)
  call void @llvm.nvvm.membar.gl()
  br i1 %isetrp_cmp2.149, label %BB_7180, label %BB_7160

BB_7160:                                          ; preds = %BB_7110
  %red_add.2 = atomicrmw add ptr addrspace(1) %phi.423, i32 1 monotonic, align 4
  br label %BB_7180

BB_7180:                                          ; preds = %BB_7160, %BB_7110
  %red_ptr.3 = inttoptr i64 %phi.424 to ptr addrspace(1)
  %red_add.3 = atomicrmw add ptr addrspace(1) %red_ptr.3, i32 1 monotonic, align 4
  br label %BB_71b0

BB_71b0:                                          ; preds = %BB_7180, %BB_70a0, %BB_7090, %BB_5760, %BB_5670, %BB_5660
  call void @llvm.nvvm.barrier0()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #2

; Function Attrs: nocallback nounwind memory(none)
declare { float, float, float, float } @llvm.nvvm.mma.m16n8k16.row.col.f32.f32(<2 x half>, <2 x half>, <2 x half>, <2 x half>, <2 x half>, <2 x half>, float, float, float, float) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rcp.approx.ftz.f(float) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.minimum.f32(float, float) #1

; Function Attrs: nocallback nounwind
declare void @llvm.nvvm.membar.gl() #5

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.laneid() #1

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.shfl.sync.idx.i32(i32, i32, i32, i32) #6

; Function Attrs: alwaysinline
define internal { i32, i32 } @lo.cvt.a2(float %0, float %1) #7 {
entry:
  %2 = call float @llvm.fabs.f32(float %0)
  %3 = bitcast float %2 to i32
  %4 = add nsw i32 %3, -947912704
  %5 = icmp ult i32 %4, 251654144
  %6 = call float @llvm.fabs.f32(float %1)
  %7 = bitcast float %6 to i32
  %8 = add nsw i32 %7, -947912704
  %9 = icmp ult i32 %8, 251654144
  %10 = and i1 %5, %9
  br i1 %10, label %fast, label %slow

fast:                                             ; preds = %entry
  %11 = bitcast float %1 to i32
  %12 = bitcast float %0 to i32
  %13 = lshr i32 %3, 13
  %14 = and i32 %13, 1
  %15 = add nsw i32 %3, -939520001
  %16 = add nsw i32 %15, %14
  %17 = lshr i32 %16, 13
  %18 = lshr i32 %12, 16
  %19 = and i32 %18, 32768
  %20 = or i32 %17, %19
  %21 = lshr i32 %7, 13
  %22 = and i32 %21, 1
  %23 = add nsw i32 %7, -939520001
  %24 = add nsw i32 %23, %22
  %25 = lshr i32 %24, 13
  %26 = lshr i32 %11, 16
  %27 = and i32 %26, 32768
  %28 = or i32 %25, %27
  br label %join

slow:                                             ; preds = %entry
  %29 = fptrunc float %0 to half
  %30 = bitcast half %29 to i16
  %31 = zext i16 %30 to i32
  %32 = fptrunc float %1 to half
  %33 = bitcast half %32 to i16
  %34 = zext i16 %33 to i32
  br label %join

join:                                             ; preds = %slow, %fast
  %35 = phi i32 [ %20, %fast ], [ %31, %slow ]
  %36 = phi i32 [ %28, %fast ], [ %34, %slow ]
  %37 = insertvalue { i32, i32 } poison, i32 %35, 0
  %38 = insertvalue { i32, i32 } %37, i32 %36, 1
  ret { i32, i32 } %38
}

; Function Attrs: alwaysinline
define internal { i32, i32, i32, i32 } @lo.cvt.a4(float %0, float %1, float %2, float %3) #7 {
entry:
  %4 = call float @llvm.fabs.f32(float %0)
  %5 = bitcast float %4 to i32
  %6 = add nsw i32 %5, -947912704
  %7 = icmp ult i32 %6, 251654144
  %8 = call float @llvm.fabs.f32(float %1)
  %9 = bitcast float %8 to i32
  %10 = add nsw i32 %9, -947912704
  %11 = icmp ult i32 %10, 251654144
  %12 = and i1 %7, %11
  %13 = call float @llvm.fabs.f32(float %2)
  %14 = bitcast float %13 to i32
  %15 = add nsw i32 %14, -947912704
  %16 = icmp ult i32 %15, 251654144
  %17 = and i1 %12, %16
  %18 = call float @llvm.fabs.f32(float %3)
  %19 = bitcast float %18 to i32
  %20 = add nsw i32 %19, -947912704
  %21 = icmp ult i32 %20, 251654144
  %22 = and i1 %17, %21
  br i1 %22, label %fast, label %slow

fast:                                             ; preds = %entry
  %23 = bitcast float %3 to i32
  %24 = bitcast float %2 to i32
  %25 = bitcast float %1 to i32
  %26 = bitcast float %0 to i32
  %27 = lshr i32 %5, 13
  %28 = and i32 %27, 1
  %29 = add nsw i32 %5, -939520001
  %30 = add nsw i32 %29, %28
  %31 = lshr i32 %30, 13
  %32 = lshr i32 %26, 16
  %33 = and i32 %32, 32768
  %34 = or i32 %31, %33
  %35 = lshr i32 %9, 13
  %36 = and i32 %35, 1
  %37 = add nsw i32 %9, -939520001
  %38 = add nsw i32 %37, %36
  %39 = lshr i32 %38, 13
  %40 = lshr i32 %25, 16
  %41 = and i32 %40, 32768
  %42 = or i32 %39, %41
  %43 = lshr i32 %14, 13
  %44 = and i32 %43, 1
  %45 = add nsw i32 %14, -939520001
  %46 = add nsw i32 %45, %44
  %47 = lshr i32 %46, 13
  %48 = lshr i32 %24, 16
  %49 = and i32 %48, 32768
  %50 = or i32 %47, %49
  %51 = lshr i32 %19, 13
  %52 = and i32 %51, 1
  %53 = add nsw i32 %19, -939520001
  %54 = add nsw i32 %53, %52
  %55 = lshr i32 %54, 13
  %56 = lshr i32 %23, 16
  %57 = and i32 %56, 32768
  %58 = or i32 %55, %57
  br label %join

slow:                                             ; preds = %entry
  %59 = fptrunc float %0 to half
  %60 = bitcast half %59 to i16
  %61 = zext i16 %60 to i32
  %62 = fptrunc float %1 to half
  %63 = bitcast half %62 to i16
  %64 = zext i16 %63 to i32
  %65 = fptrunc float %2 to half
  %66 = bitcast half %65 to i16
  %67 = zext i16 %66 to i32
  %68 = fptrunc float %3 to half
  %69 = bitcast half %68 to i16
  %70 = zext i16 %69 to i32
  br label %join

join:                                             ; preds = %slow, %fast
  %71 = phi i32 [ %34, %fast ], [ %61, %slow ]
  %72 = phi i32 [ %42, %fast ], [ %64, %slow ]
  %73 = phi i32 [ %50, %fast ], [ %67, %slow ]
  %74 = phi i32 [ %58, %fast ], [ %70, %slow ]
  %75 = insertvalue { i32, i32, i32, i32 } poison, i32 %71, 0
  %76 = insertvalue { i32, i32, i32, i32 } %75, i32 %72, 1
  %77 = insertvalue { i32, i32, i32, i32 } %76, i32 %73, 2
  %78 = insertvalue { i32, i32, i32, i32 } %77, i32 %74, 3
  ret { i32, i32, i32, i32 } %78
}

; Function Attrs: convergent
declare void @__vx_wmma_mma_m16n16k16_row_row_f16_f16_f32(ptr, ptr, ptr, ptr) #8

; Function Attrs: alwaysinline convergent
define internal { float, float, float, float, float, float, float, float } @lo.wmma(ptr %0, float %1, float %2, float %3, float %4, float %5, float %6, float %7, float %8, float %9, float %10, float %11, float %12, float %13, float %14, float %15, float %16, float %17, float %18, float %19, float %20, float %21, float %22, float %23, float %24) #9 {
entry:
  store float %1, ptr %0, align 4
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store float %9, ptr %25, align 4
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 64
  store float %17, ptr %26, align 4
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 4
  store float %2, ptr %27, align 4
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 36
  store float %10, ptr %28, align 4
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 68
  store float %18, ptr %29, align 4
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store float %3, ptr %30, align 4
  %31 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store float %11, ptr %31, align 4
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 72
  store float %19, ptr %32, align 4
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 12
  store float %4, ptr %33, align 4
  %34 = getelementptr inbounds nuw i8, ptr %0, i64 44
  store float %12, ptr %34, align 4
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 76
  store float %20, ptr %35, align 4
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store float %5, ptr %36, align 4
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 48
  store float %13, ptr %37, align 4
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 80
  store float %21, ptr %38, align 4
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 20
  store float %6, ptr %39, align 4
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 52
  store float %14, ptr %40, align 4
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 84
  store float %22, ptr %41, align 4
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store float %7, ptr %42, align 4
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 56
  store float %15, ptr %43, align 4
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 88
  store float %23, ptr %44, align 4
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 28
  store float %8, ptr %45, align 4
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 60
  store float %16, ptr %46, align 4
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 92
  store float %24, ptr %47, align 4
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 64
  call void @__vx_wmma_mma_m16n16k16_row_row_f16_f16_f32(ptr nonnull %48, ptr %0, ptr nonnull %49, ptr nonnull %50) #8
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %52 = load float, ptr %51, align 4
  %53 = insertvalue { float, float, float, float, float, float, float, float } poison, float %52, 0
  %54 = getelementptr inbounds nuw i8, ptr %0, i64 100
  %55 = load float, ptr %54, align 4
  %56 = insertvalue { float, float, float, float, float, float, float, float } %53, float %55, 1
  %57 = getelementptr inbounds nuw i8, ptr %0, i64 104
  %58 = load float, ptr %57, align 4
  %59 = insertvalue { float, float, float, float, float, float, float, float } %56, float %58, 2
  %60 = getelementptr inbounds nuw i8, ptr %0, i64 108
  %61 = load float, ptr %60, align 4
  %62 = insertvalue { float, float, float, float, float, float, float, float } %59, float %61, 3
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %64 = load float, ptr %63, align 4
  %65 = insertvalue { float, float, float, float, float, float, float, float } %62, float %64, 4
  %66 = getelementptr inbounds nuw i8, ptr %0, i64 116
  %67 = load float, ptr %66, align 4
  %68 = insertvalue { float, float, float, float, float, float, float, float } %65, float %67, 5
  %69 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %70 = load float, ptr %69, align 4
  %71 = insertvalue { float, float, float, float, float, float, float, float } %68, float %70, 6
  %72 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %73 = load float, ptr %72, align 4
  %74 = insertvalue { float, float, float, float, float, float, float, float } %71, float %73, 7
  ret { float, float, float, float, float, float, float, float } %74
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.copysign.f32(float, float) #1

attributes #0 = { "frame-pointer"="all" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { convergent nocallback nounwind }
attributes #3 = { nocallback nounwind memory(none) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #5 = { nocallback nounwind }
attributes #6 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }
attributes #7 = { alwaysinline }
attributes #8 = { convergent }
attributes #9 = { alwaysinline convergent }
attributes #10 = { nounwind }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1, !2, !3, !4}

!0 = !{i32 2, i32 0}
!1 = !{ptr @sm80_xmma_fprop_implicit_gemm_f16f16_f16f32_f32_nhwckrsc_nhwc_tilesize64x32x64_stage5_warpsize2x2x1_g1_tensor16x8x16_execute_kernel__5x_cudnn, !"kernel", i32 1}
!2 = !{ptr @sm80_xmma_fprop_implicit_gemm_f16f16_f16f32_f32_nhwckrsc_nhwc_tilesize64x32x64_stage5_warpsize2x2x1_g1_tensor16x8x16_execute_kernel__5x_cudnn, !"maxntidx", i32 128}
!3 = !{ptr @sm80_xmma_fprop_implicit_gemm_f16f16_f16f32_f32_nhwckrsc_nhwc_tilesize64x32x64_stage5_warpsize2x2x1_g1_tensor16x8x16_execute_kernel__5x_cudnn, !"maxntidy", i32 1}
!4 = !{ptr @sm80_xmma_fprop_implicit_gemm_f16f16_f16f32_f32_nhwckrsc_nhwc_tilesize64x32x64_stage5_warpsize2x2x1_g1_tensor16x8x16_execute_kernel__5x_cudnn, !"maxntidz", i32 1}
