; lift_addr: not a lift; written by hand in the form of the sm_5x lifts (IADD, IADD.X): a 64-bit address as two 32-bit halves and a carry, with a negative 32-bit index. No lifted kernel here
; takes a negative index or crosses 2^32, so the switch CUPBOP_ADDR_CARRY and lo-pair could lose the sign or the carry without an answer changing.
; out[i] = base[i - shift], i = global thread index.
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [32768 x i8], align 16
define void @"_Z9addr_unitPfS_i"(i64 %"arg_320", i64 %"arg_328", i32 %"arg_336")
{
EntryBB_0008:
  %"ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  %"ntid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ntid.x"()
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"blk" = mul i32 %"ctaid_x", %"ntid_x"
  %"i" = add i32 %"blk", %"tid_x"
  %"x" = sub i32 %"i", %"arg_336"
  %"a" = shl i32 %"x", 2
  %"ah" = ashr i32 %"x", 30
  %"bl" = and i64 %"arg_320", 4294967295
  %"za" = zext i32 %"a" to i64
  %"lo" = add i64 %"bl", %"za"
  %"cy" = icmp ugt i64 %"lo", 4294967295
  %"zc" = zext i1 %"cy" to i64
  %"bh" = lshr i64 %"arg_320", 32
  %"zh" = zext i32 %"ah" to i64
  %"r" = add i64 %"bh", %"zh"
  %"hi" = add i64 %"r", %"zc"
  %"sh" = shl i64 %"hi", 32
  %"lom" = and i64 %"lo", 4294967295
  %"addr" = or i64 %"sh", %"lom"
  %"p" = inttoptr i64 %"addr" to float*
  %"v" = load float, float* %"p", align 4
  %"zi" = zext i32 %"i" to i64
  %"oa" = shl i64 %"zi", 2
  %"oaddr" = add i64 %"arg_328", %"oa"
  %"q" = inttoptr i64 %"oaddr" to float*
  store float %"v", float* %"q", align 4
  ret void
}
declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ntid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64, i32)* @"_Z9addr_unitPfS_i", !"kernel", i32 1 }
