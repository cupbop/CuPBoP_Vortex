; ModuleID = "tcgen05_transfer_sm100a"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [1040 x i8], align 16
define void @"_Z8transferPj"(i64 %"arg_896")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".3" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".4" = bitcast i8* %".3" to i64*
  store i64 %"arg_896", i64* %".4", align 128
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".6" = zext i32 0 to i64
  %".7" = zext i32 %"tid_x" to i64
  %".8" = shl i64 %".7", 32
  %"shf_concat" = or i64 %".6", %".8"
  %"shf_shift_64" = zext i32 5 to i64
  %".9" = lshr i64 %"shf_concat", %"shf_shift_64"
  %"shf_hi" = lshr i64 %".9", 32
  %"shf_result" = trunc i64 %"shf_hi" to i32
  %"isetrp_cmp1" = icmp ne i32 %"shf_result", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_0050"
BB_0050:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0220", label %"BB_0060"
BB_0060:
  %"allocation_slot_winoff" = and i32 1024, 16777215
  %".12" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".13" = ptrtoint i8 addrspace(3)* %".12" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".13", i32 128) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P3_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0080"
BB_0080:
  %"cond_trunc.1" = trunc i32 %"P3_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0220", label %"BB_0090"
BB_0090:
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", 15
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", 1
  %".17" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".18" = zext i32 1024 to i64
  %".19" = zext i32 24 to i64
  %".20" = shl i64 %".17", %".19"
  %".21" = and i64 %".20", 4294967295
  %".22" = add i64 %".21", %".18"
  %".23" = trunc i64 %".22" to i32
  %"tmem_alloc_winoff" = and i32 1024, 16777215
  %".24" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".25" = bitcast i8 addrspace(3)* %".24" to i32 addrspace(3)*
  %".26" = load i32, i32 addrspace(3)* %".25"
  %".27" = lshr i32 %".26", 5
  %"P5_to_i32" = zext i1 1 to i32
  %".28" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".29" = zext i32 64 to i64
  %".30" = zext i32 24 to i64
  %".31" = shl i64 %".28", %".30"
  %".32" = and i64 %".31", 4294967295
  %".33" = add i64 %".32", %".29"
  %".34" = trunc i64 %".33" to i32
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.2", %".27"
  %"bra_cond_trunc" = trunc i32 %"P5_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_01b0", label %"BB_0150"
BB_0150:
  %"tmem_alloc_winoff.1" = and i32 1024, 16777215
  %".36" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".37" = bitcast i8 addrspace(3)* %".36" to i32 addrspace(3)*
  %".38" = load i32, i32 addrspace(3)* %".37"
  %".39" = lshr i32 %".38", 5
  %"P6_to_i32" = zext i1 1 to i32
  %"bra_cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0150", label %"BB_01b0"
BB_01b0:
  %"phi" = phi  i32 [%"imad.2", %"BB_0090"], [%".39", %"BB_0150"]
  %".41" = zext i32 %"imad" to i64
  %".42" = zext i32 0 to i64
  %".43" = shl i64 %".42", 32
  %"shf_concat.1" = or i64 %".41", %".43"
  %"shf_shift_64.1" = zext i32 %"phi" to i64
  %".44" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".44" to i32
  %".45" = zext i32 %"imad.1" to i64
  %".46" = zext i32 0 to i64
  %".47" = shl i64 %".46", 32
  %"shf_concat.2" = or i64 %".45", %".47"
  %"shf_shift_64.2" = zext i32 %"phi" to i64
  %".48" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".48" to i32
  %"imad_tmp.3" = mul i32 %"phi", 32
  %"imad.3" = add i32 %"imad_tmp.3", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".34", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".49" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".49" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.1" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".34", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".50" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_shared_addr_winoff" = and i32 %".23", 16777215
  %".51" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".51" to i32 addrspace(3)*
  store volatile i32 %"imad.3", i32 addrspace(3)* %"sts_shared_addr_cast"
  br label %"BB_0220"
BB_0220:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.4" = mul i32 %"tid_x", 65536
  %"imad.4" = add i32 %"imad_tmp.4", 0
  %".54" = xor i32 %"tid_x", -1
  %".55" = xor i32 16, -1
  %".56" = xor i32 0, -1
  %".57" = and i32 %"tid_x", 16
  %".58" = and i32 %".57", %".56"
  %".59" = and i32 %"tid_x", 16
  %".60" = and i32 %".59", 0
  %".61" = or i32 %".58", %".60"
  %"lop3_pred_cmp" = icmp ne i32 %".61", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P4_to_i32" = zext i1 %"lop3_p" to i32
  %"imad_tmp.5" = mul i32 %"tid_x", 1000
  %"imad.5" = add i32 %"imad_tmp.5", 0
  %"imad_tmp.6" = mul i32 %"shf_result", 1048576
  %"imad.6" = add i32 %"imad_tmp.6", 0
  %".62" = xor i32 %"imad.4", -1
  %".63" = xor i32 65011712, -1
  %".64" = xor i32 0, -1
  %".65" = and i32 %"imad.4", 65011712
  %".66" = and i32 %".65", %".64"
  %".67" = and i32 %"imad.4", 65011712
  %".68" = and i32 %".67", 0
  %".69" = or i32 %".66", %".68"
  %"viadd" = add i32 %"imad.5", 2
  %"iadd3_n1" = add i32 %"imad.5", 1
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"viadd.1" = add i32 %"imad.5", 3
  %"iadd3_n1.1" = add i32 %"imad.5", 5
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"viadd.2" = add i32 %"imad.5", 4
  %".70" = xor i32 %"imad.6", -1
  %".71" = xor i32 1048576, -1
  %".72" = xor i32 0, -1
  %".73" = and i32 %"imad.6", 1048576
  %".74" = and i32 %".73", %".72"
  %".75" = and i32 %"imad.6", 1048576
  %".76" = and i32 %".75", 0
  %".77" = or i32 %".74", %".76"
  %"viadd.3" = add i32 %"imad.5", 6
  %"iadd3_n1.2" = add i32 %"imad.5", 9
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"viadd.4" = add i32 %"imad.5", 7
  %"iadd3_n1.3" = add i32 %"imad.5", 16
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"viadd.5" = add i32 %"imad.5", 8
  %"iadd3_n1.4" = add i32 %"imad.5", 20
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"viadd.6" = add i32 %"imad.5", 10
  %"viadd.7" = add i32 %"imad.5", 11
  %".78" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".79" = zext i32 1024 to i64
  %".80" = zext i32 24 to i64
  %".81" = shl i64 %".78", %".80"
  %".82" = and i64 %".81", 4294967295
  %".83" = add i64 %".82", %".79"
  %".84" = trunc i64 %".83" to i32
  %"viadd.8" = add i32 %"imad.5", 17
  %"viadd.9" = add i32 %"imad.5", 18
  %"viadd.10" = add i32 %"imad.5", 19
  %"viadd.11" = add i32 %"imad.5", 21
  %"lds_shared_addr_winoff" = and i32 %".84", 16777215
  %".85" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".85" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"viadd.12" = add i32 %"imad.5", 22
  %"viadd.13" = add i32 %"imad.5", 23
  %"imad_tmp.7" = mul i32 %"lds", 1
  %"imad.7" = add i32 %"imad_tmp.7", %".69"
  %"iadd3_n1.5" = add i32 %"imad.7", %".77"
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".86" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".87" = bitcast i8* %".86" to i64*
  %"ldc_const" = load i64, i64* %".87"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.7", i32 %"imad.5", i32 %"iadd3_n2", i32 %"viadd", i32 %"viadd.1")
  %"sttm_memaddr_offset_add" = add i32 %"imad.7", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"viadd.2", i32 %"iadd3_n2.1", i32 %"viadd.3", i32 %"viadd.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.7", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"viadd.5", i32 %"iadd3_n2.2", i32 %"viadd.6", i32 %"viadd.7")
  %"viadd.14" = add i32 %"imad.5", 12
  %"iadd3_n1.6" = add i32 %"imad.5", 13
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"viadd.15" = add i32 %"imad.5", 14
  %"iadd3_n1.7" = add i32 %"imad.5", 27
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"viadd.16" = add i32 %"imad.5", 15
  %"viadd.17" = add i32 %"imad.5", 24
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.7", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"viadd.14", i32 %"iadd3_n2.6", i32 %"viadd.15", i32 %"viadd.16")
  %"viadd.18" = add i32 %"imad.5", 25
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.7", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"iadd3_n2.3", i32 %"viadd.8", i32 %"viadd.9", i32 %"viadd.10")
  %"viadd.19" = add i32 %"imad.5", 26
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.7", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"iadd3_n2.4", i32 %"viadd.11", i32 %"viadd.12", i32 %"viadd.13")
  %"sttm_memaddr_offset_add.5" = add i32 %"imad.7", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.5", i32 %"viadd.17", i32 %"viadd.18", i32 %"viadd.19", i32 %"iadd3_n2.7")
  %"viadd.20" = add i32 %"imad.5", 28
  %"iadd3_n1.8" = add i32 %"imad.5", 31
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"viadd.21" = add i32 %"imad.5", 29
  %"viadd.22" = add i32 %"imad.5", 30
  %"imad_tmp.8" = mul i32 %"tid_x", 50
  %"imad.8" = add i32 %"imad_tmp.8", 0
  %"sttm_memaddr_offset_add.6" = add i32 %"imad.7", 28
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.6", i32 %"viadd.20", i32 %"viadd.21", i32 %"viadd.22", i32 %"iadd3_n2.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldtm_addr_memaddr_offset_add" = add i32 %"iadd3_n2.5", 4
  %"ldtm" = call {i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.16x64b.x2.b32 {$0, $1}, [$2];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".97" = extractvalue {i32, i32} %"ldtm", 0
  %".98" = extractvalue {i32, i32} %"ldtm", 1
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"iadd3_n2.5", 8
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.16x128b.x2.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".99" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".100" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".101" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".102" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad.8" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.9" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R149:R133_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".97", i32 addrspace(1)* %"R149:R133_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R149:R133_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".98", i32 addrspace(1)* %"R149:R133_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R149:R133_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".99", i32 addrspace(1)* %"R149:R133_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R149:R133_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".100", i32 addrspace(1)* %"R149:R133_addr_ptr.3"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"iadd3_n2.5", 16
  %"ldtm.2" = call {i32, i32, i32, i32, i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.16x256b.x2.b32 {$0, $1, $2, $3, $4, $5, $6, $7}, [$8];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".107" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 0
  %".108" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 1
  %".109" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 2
  %".110" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 3
  %".111" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 4
  %".112" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 5
  %".113" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 6
  %".114" = extractvalue {i32, i32, i32, i32, i32, i32, i32, i32} %"ldtm.2", 7
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R149:R133_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".101", i32 addrspace(1)* %"R149:R133_addr_ptr.4"
  %"imad_tmp.9" = mul i32 %"tid_x", 16
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R149:R133_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".102", i32 addrspace(1)* %"R149:R133_addr_ptr.5"
  %"ldtm.3" = call {i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.16x32bx2.x2.b32 {$0, $1}, [$2], 1048580;
	tcgen05.wait::ld.sync.aligned;", "=r,=r,r,~{memory}"(i32 %"imad.7")
  %".117" = extractvalue {i32, i32} %"ldtm.3", 0
  %".118" = extractvalue {i32, i32} %"ldtm.3", 1
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R149:R133_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".107", i32 addrspace(1)* %"R149:R133_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R149:R133_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".108", i32 addrspace(1)* %"R149:R133_addr_ptr.7"
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R149:R133_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".109", i32 addrspace(1)* %"R149:R133_addr_ptr.8"
  %"viadd.23" = add i32 %"imad.10", 200000
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R149:R133_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".110", i32 addrspace(1)* %"R149:R133_addr_ptr.9"
  %"viadd.24" = add i32 %"imad.10", 200001
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R149:R133_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".111", i32 addrspace(1)* %"R149:R133_addr_ptr.10"
  %"iadd3_n1.9" = add i32 %"imad.10", 200002
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R149:R133_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".112", i32 addrspace(1)* %"R149:R133_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R149:R133_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".113", i32 addrspace(1)* %"R149:R133_addr_ptr.12"
  %"viadd.25" = add i32 %"imad.10", 200003
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R149:R133_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".114", i32 addrspace(1)* %"R149:R133_addr_ptr.13"
  %"viadd.26" = add i32 %"imad.10", 200004
  call void asm sideeffect "tcgen05.st.sync.aligned.16x64b.x1.b32 [$0], {$1}; tcgen05.wait::st.sync.aligned;", "r,r,~{memory}"(i32 %"iadd3_n2.5", i32 %"viadd.23")
  %"viadd.27" = add i32 %"imad.10", 200005
  %"sttm_memaddr_offset_add.7" = add i32 %"iadd3_n2.5", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.16x64b.x2.b32 [$0], {$1,$2}; tcgen05.wait::st.sync.aligned;", "r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.7", i32 %"viadd.23", i32 %"viadd.24")
  %"iadd3_n1.10" = add i32 %"imad.10", 200006
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %"sttm_memaddr_offset_add.8" = add i32 %"iadd3_n2.5", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.16x128b.x2.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.8", i32 %"viadd.23", i32 %"viadd.24", i32 %"iadd3_n2.9", i32 %"viadd.25")
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R149:R133_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".117", i32 addrspace(1)* %"R149:R133_addr_ptr.14"
  %"viadd.28" = add i32 %"imad.10", 200007
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R149:R133_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".118", i32 addrspace(1)* %"R149:R133_addr_ptr.15"
  %"sttm_memaddr_offset_add.9" = add i32 %"iadd3_n2.5", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.16x256b.x2.b32 [$0], {$1,$2,$3,$4,$5,$6,$7,$8}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.9", i32 %"viadd.23", i32 %"viadd.24", i32 %"iadd3_n2.9", i32 %"viadd.25", i32 %"viadd.26", i32 %"viadd.27", i32 %"iadd3_n2.10", i32 %"viadd.28")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.7")
  %".134" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".135" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".136" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".137" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.7", 4
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".138" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".139" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".140" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".141" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R149:R133_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".134", i32 addrspace(1)* %"R149:R133_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R149:R133_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".135", i32 addrspace(1)* %"R149:R133_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R149:R133_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".136", i32 addrspace(1)* %"R149:R133_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R149:R133_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".137", i32 addrspace(1)* %"R149:R133_addr_ptr.19"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.7", 8
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".146" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".147" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".148" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".149" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.20" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R149:R133_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".138", i32 addrspace(1)* %"R149:R133_addr_ptr.20"
  %"stg_addr_r0_ext.21" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R149:R133_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".139", i32 addrspace(1)* %"R149:R133_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R149:R133_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".140", i32 addrspace(1)* %"R149:R133_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R149:R133_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".141", i32 addrspace(1)* %"R149:R133_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.7", 12
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".154" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".155" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".156" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".157" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R149:R133_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".146", i32 addrspace(1)* %"R149:R133_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R149:R133_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".147", i32 addrspace(1)* %"R149:R133_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R149:R133_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".148", i32 addrspace(1)* %"R149:R133_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R149:R133_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".149", i32 addrspace(1)* %"R149:R133_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R149:R133_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".154", i32 addrspace(1)* %"R149:R133_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R149:R133_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".155", i32 addrspace(1)* %"R149:R133_addr_ptr.29"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.7", 16
  %"ldtm.8" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".164" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 0
  %".165" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 1
  %".166" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 2
  %".167" = extractvalue {i32, i32, i32, i32} %"ldtm.8", 3
  %"stg_addr_r0_ext.30" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R149:R133_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".156", i32 addrspace(1)* %"R149:R133_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R149:R133_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".157", i32 addrspace(1)* %"R149:R133_addr_ptr.31"
  %"ldtm_addr_memaddr_offset_add.7" = add i32 %"imad.7", 20
  %"ldtm.9" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.7")
  %".170" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 0
  %".171" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 1
  %".172" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 2
  %".173" = extractvalue {i32, i32, i32, i32} %"ldtm.9", 3
  %"stg_addr_r0_ext.32" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.32" = or i64 0, %"stg_addr_r0_ext.32"
  %"stg_addr_r1_ext.32" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.32" = shl i64 %"stg_addr_r1_ext.32", 32
  %"stg_addr_packed_1.32" = or i64 %"stg_addr_packed_0.32", %"stg_addr_r1_shift.32"
  %"stg_addr_memaddr_offset_add.31" = add i64 %"stg_addr_packed_1.32", 128
  %"R149:R133_addr_ptr.32" = inttoptr i64 %"stg_addr_memaddr_offset_add.31" to i32 addrspace(1)*
  store i32 %".164", i32 addrspace(1)* %"R149:R133_addr_ptr.32"
  %"stg_addr_r0_ext.33" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.33" = or i64 0, %"stg_addr_r0_ext.33"
  %"stg_addr_r1_ext.33" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.33" = shl i64 %"stg_addr_r1_ext.33", 32
  %"stg_addr_packed_1.33" = or i64 %"stg_addr_packed_0.33", %"stg_addr_r1_shift.33"
  %"stg_addr_memaddr_offset_add.32" = add i64 %"stg_addr_packed_1.33", 132
  %"R149:R133_addr_ptr.33" = inttoptr i64 %"stg_addr_memaddr_offset_add.32" to i32 addrspace(1)*
  store i32 %".165", i32 addrspace(1)* %"R149:R133_addr_ptr.33"
  %"stg_addr_r0_ext.34" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.34" = or i64 0, %"stg_addr_r0_ext.34"
  %"stg_addr_r1_ext.34" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.34" = shl i64 %"stg_addr_r1_ext.34", 32
  %"stg_addr_packed_1.34" = or i64 %"stg_addr_packed_0.34", %"stg_addr_r1_shift.34"
  %"stg_addr_memaddr_offset_add.33" = add i64 %"stg_addr_packed_1.34", 136
  %"R149:R133_addr_ptr.34" = inttoptr i64 %"stg_addr_memaddr_offset_add.33" to i32 addrspace(1)*
  store i32 %".166", i32 addrspace(1)* %"R149:R133_addr_ptr.34"
  %"stg_addr_r0_ext.35" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.35" = or i64 0, %"stg_addr_r0_ext.35"
  %"stg_addr_r1_ext.35" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.35" = shl i64 %"stg_addr_r1_ext.35", 32
  %"stg_addr_packed_1.35" = or i64 %"stg_addr_packed_0.35", %"stg_addr_r1_shift.35"
  %"stg_addr_memaddr_offset_add.34" = add i64 %"stg_addr_packed_1.35", 140
  %"R149:R133_addr_ptr.35" = inttoptr i64 %"stg_addr_memaddr_offset_add.34" to i32 addrspace(1)*
  store i32 %".167", i32 addrspace(1)* %"R149:R133_addr_ptr.35"
  %"stg_addr_r0_ext.36" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.36" = or i64 0, %"stg_addr_r0_ext.36"
  %"stg_addr_r1_ext.36" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.36" = shl i64 %"stg_addr_r1_ext.36", 32
  %"stg_addr_packed_1.36" = or i64 %"stg_addr_packed_0.36", %"stg_addr_r1_shift.36"
  %"stg_addr_memaddr_offset_add.35" = add i64 %"stg_addr_packed_1.36", 144
  %"R149:R133_addr_ptr.36" = inttoptr i64 %"stg_addr_memaddr_offset_add.35" to i32 addrspace(1)*
  store i32 %".170", i32 addrspace(1)* %"R149:R133_addr_ptr.36"
  %"stg_addr_r0_ext.37" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.37" = or i64 0, %"stg_addr_r0_ext.37"
  %"stg_addr_r1_ext.37" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.37" = shl i64 %"stg_addr_r1_ext.37", 32
  %"stg_addr_packed_1.37" = or i64 %"stg_addr_packed_0.37", %"stg_addr_r1_shift.37"
  %"stg_addr_memaddr_offset_add.36" = add i64 %"stg_addr_packed_1.37", 148
  %"R149:R133_addr_ptr.37" = inttoptr i64 %"stg_addr_memaddr_offset_add.36" to i32 addrspace(1)*
  store i32 %".171", i32 addrspace(1)* %"R149:R133_addr_ptr.37"
  %"ldtm_addr_memaddr_offset_add.8" = add i32 %"imad.7", 24
  %"ldtm.10" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.8")
  %".180" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 0
  %".181" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 1
  %".182" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 2
  %".183" = extractvalue {i32, i32, i32, i32} %"ldtm.10", 3
  %"stg_addr_r0_ext.38" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.38" = or i64 0, %"stg_addr_r0_ext.38"
  %"stg_addr_r1_ext.38" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.38" = shl i64 %"stg_addr_r1_ext.38", 32
  %"stg_addr_packed_1.38" = or i64 %"stg_addr_packed_0.38", %"stg_addr_r1_shift.38"
  %"stg_addr_memaddr_offset_add.37" = add i64 %"stg_addr_packed_1.38", 152
  %"R149:R133_addr_ptr.38" = inttoptr i64 %"stg_addr_memaddr_offset_add.37" to i32 addrspace(1)*
  store i32 %".172", i32 addrspace(1)* %"R149:R133_addr_ptr.38"
  %"stg_addr_r0_ext.39" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.39" = or i64 0, %"stg_addr_r0_ext.39"
  %"stg_addr_r1_ext.39" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.39" = shl i64 %"stg_addr_r1_ext.39", 32
  %"stg_addr_packed_1.39" = or i64 %"stg_addr_packed_0.39", %"stg_addr_r1_shift.39"
  %"stg_addr_memaddr_offset_add.38" = add i64 %"stg_addr_packed_1.39", 156
  %"R149:R133_addr_ptr.39" = inttoptr i64 %"stg_addr_memaddr_offset_add.38" to i32 addrspace(1)*
  store i32 %".173", i32 addrspace(1)* %"R149:R133_addr_ptr.39"
  %"ldtm_addr_memaddr_offset_add.9" = add i32 %"imad.7", 28
  %"ldtm.11" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.9")
  %".186" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 0
  %".187" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 1
  %".188" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 2
  %".189" = extractvalue {i32, i32, i32, i32} %"ldtm.11", 3
  %"stg_addr_r0_ext.40" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.40" = or i64 0, %"stg_addr_r0_ext.40"
  %"stg_addr_r1_ext.40" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.40" = shl i64 %"stg_addr_r1_ext.40", 32
  %"stg_addr_packed_1.40" = or i64 %"stg_addr_packed_0.40", %"stg_addr_r1_shift.40"
  %"stg_addr_memaddr_offset_add.39" = add i64 %"stg_addr_packed_1.40", 160
  %"R149:R133_addr_ptr.40" = inttoptr i64 %"stg_addr_memaddr_offset_add.39" to i32 addrspace(1)*
  store i32 %".180", i32 addrspace(1)* %"R149:R133_addr_ptr.40"
  %"stg_addr_r0_ext.41" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.41" = or i64 0, %"stg_addr_r0_ext.41"
  %"stg_addr_r1_ext.41" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.41" = shl i64 %"stg_addr_r1_ext.41", 32
  %"stg_addr_packed_1.41" = or i64 %"stg_addr_packed_0.41", %"stg_addr_r1_shift.41"
  %"stg_addr_memaddr_offset_add.40" = add i64 %"stg_addr_packed_1.41", 164
  %"R149:R133_addr_ptr.41" = inttoptr i64 %"stg_addr_memaddr_offset_add.40" to i32 addrspace(1)*
  store i32 %".181", i32 addrspace(1)* %"R149:R133_addr_ptr.41"
  %"stg_addr_r0_ext.42" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.42" = or i64 0, %"stg_addr_r0_ext.42"
  %"stg_addr_r1_ext.42" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.42" = shl i64 %"stg_addr_r1_ext.42", 32
  %"stg_addr_packed_1.42" = or i64 %"stg_addr_packed_0.42", %"stg_addr_r1_shift.42"
  %"stg_addr_memaddr_offset_add.41" = add i64 %"stg_addr_packed_1.42", 168
  %"R149:R133_addr_ptr.42" = inttoptr i64 %"stg_addr_memaddr_offset_add.41" to i32 addrspace(1)*
  store i32 %".182", i32 addrspace(1)* %"R149:R133_addr_ptr.42"
  %"viadd.29" = add i32 %"imad.10", 200008
  %"stg_addr_r0_ext.43" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.43" = or i64 0, %"stg_addr_r0_ext.43"
  %"stg_addr_r1_ext.43" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.43" = shl i64 %"stg_addr_r1_ext.43", 32
  %"stg_addr_packed_1.43" = or i64 %"stg_addr_packed_0.43", %"stg_addr_r1_shift.43"
  %"stg_addr_memaddr_offset_add.42" = add i64 %"stg_addr_packed_1.43", 172
  %"R149:R133_addr_ptr.43" = inttoptr i64 %"stg_addr_memaddr_offset_add.42" to i32 addrspace(1)*
  store i32 %".183", i32 addrspace(1)* %"R149:R133_addr_ptr.43"
  %"iadd3_n1.11" = add i32 %"imad.10", 200009
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"stg_addr_r0_ext.44" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.44" = or i64 0, %"stg_addr_r0_ext.44"
  %"stg_addr_r1_ext.44" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.44" = shl i64 %"stg_addr_r1_ext.44", 32
  %"stg_addr_packed_1.44" = or i64 %"stg_addr_packed_0.44", %"stg_addr_r1_shift.44"
  %"stg_addr_memaddr_offset_add.43" = add i64 %"stg_addr_packed_1.44", 176
  %"R149:R133_addr_ptr.44" = inttoptr i64 %"stg_addr_memaddr_offset_add.43" to i32 addrspace(1)*
  store i32 %".186", i32 addrspace(1)* %"R149:R133_addr_ptr.44"
  call void asm sideeffect "tcgen05.st.sync.aligned.16x32bx2.x2.b32 [$0], 1048580, {$1,$2}; tcgen05.wait::st.sync.aligned;", "r,r,r,~{memory}"(i32 %"imad.7", i32 %"viadd.29", i32 %"iadd3_n2.11")
  %"stg_addr_r0_ext.45" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.45" = or i64 0, %"stg_addr_r0_ext.45"
  %"stg_addr_r1_ext.45" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.45" = shl i64 %"stg_addr_r1_ext.45", 32
  %"stg_addr_packed_1.45" = or i64 %"stg_addr_packed_0.45", %"stg_addr_r1_shift.45"
  %"stg_addr_memaddr_offset_add.44" = add i64 %"stg_addr_packed_1.45", 180
  %"R149:R133_addr_ptr.45" = inttoptr i64 %"stg_addr_memaddr_offset_add.44" to i32 addrspace(1)*
  store i32 %".187", i32 addrspace(1)* %"R149:R133_addr_ptr.45"
  %"stg_addr_r0_ext.46" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.46" = or i64 0, %"stg_addr_r0_ext.46"
  %"stg_addr_r1_ext.46" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.46" = shl i64 %"stg_addr_r1_ext.46", 32
  %"stg_addr_packed_1.46" = or i64 %"stg_addr_packed_0.46", %"stg_addr_r1_shift.46"
  %"stg_addr_memaddr_offset_add.45" = add i64 %"stg_addr_packed_1.46", 184
  %"R149:R133_addr_ptr.46" = inttoptr i64 %"stg_addr_memaddr_offset_add.45" to i32 addrspace(1)*
  store i32 %".188", i32 addrspace(1)* %"R149:R133_addr_ptr.46"
  %"stg_addr_r0_ext.47" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.47" = or i64 0, %"stg_addr_r0_ext.47"
  %"stg_addr_r1_ext.47" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.47" = shl i64 %"stg_addr_r1_ext.47", 32
  %"stg_addr_packed_1.47" = or i64 %"stg_addr_packed_0.47", %"stg_addr_r1_shift.47"
  %"stg_addr_memaddr_offset_add.46" = add i64 %"stg_addr_packed_1.47", 188
  %"R149:R133_addr_ptr.47" = inttoptr i64 %"stg_addr_memaddr_offset_add.46" to i32 addrspace(1)*
  store i32 %".189", i32 addrspace(1)* %"R149:R133_addr_ptr.47"
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldtm.12" = call {i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x2.b32 {$0, $1}, [$2];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,r,~{memory}"(i32 %"imad.7")
  %".200" = extractvalue {i32, i32} %"ldtm.12", 0
  %".201" = extractvalue {i32, i32} %"ldtm.12", 1
  %"ldtm_addr_memaddr_offset_add.10" = add i32 %"imad.7", 4
  %"ldtm.13" = call {i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x2.b32 {$0, $1}, [$2];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.10")
  %".202" = extractvalue {i32, i32} %"ldtm.13", 0
  %".203" = extractvalue {i32, i32} %"ldtm.13", 1
  %"sel_pred_trunc" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 %".200", i32 %".202"
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 %".201", i32 %".203"
  %"stg_addr_r0_ext.48" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.48" = or i64 0, %"stg_addr_r0_ext.48"
  %"stg_addr_r1_ext.48" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.48" = shl i64 %"stg_addr_r1_ext.48", 32
  %"stg_addr_packed_1.48" = or i64 %"stg_addr_packed_0.48", %"stg_addr_r1_shift.48"
  %"stg_addr_memaddr_offset_add.47" = add i64 %"stg_addr_packed_1.48", 192
  %"R149:R133_addr_ptr.48" = inttoptr i64 %"stg_addr_memaddr_offset_add.47" to i32 addrspace(1)*
  store i32 %"sel", i32 addrspace(1)* %"R149:R133_addr_ptr.48"
  %"stg_addr_r0_ext.49" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.49" = or i64 0, %"stg_addr_r0_ext.49"
  %"stg_addr_r1_ext.49" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.49" = shl i64 %"stg_addr_r1_ext.49", 32
  %"stg_addr_packed_1.49" = or i64 %"stg_addr_packed_0.49", %"stg_addr_r1_shift.49"
  %"stg_addr_memaddr_offset_add.48" = add i64 %"stg_addr_packed_1.49", 196
  %"R149:R133_addr_ptr.49" = inttoptr i64 %"stg_addr_memaddr_offset_add.48" to i32 addrspace(1)*
  store i32 %"sel.1", i32 addrspace(1)* %"R149:R133_addr_ptr.49"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0cd0"
BB_0cd0:
  %"cond_trunc.2" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_trunc.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_80000cd0", label %"BB_0ce0"
BB_0ce0:
  %"lds_shared_addr_winoff.1" = and i32 %".84", 16777215
  %".208" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".208" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.10", 15
  %".209" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".210" = zext i32 64 to i64
  %".211" = zext i32 24 to i64
  %".212" = shl i64 %".209", %".211"
  %".213" = and i64 %".212", 4294967295
  %".214" = add i64 %".213", %".210"
  %".215" = trunc i64 %".214" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".215", 20
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".216" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".216" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %".217" = xor i32 %"lds.1", -1
  %".218" = xor i32 65535, -1
  %".219" = xor i32 0, -1
  %".220" = and i32 %"lds.1", 65535
  %".221" = and i32 %".220", %".219"
  %".222" = and i32 %"lds.1", 65535
  %".223" = and i32 %".222", 0
  %".224" = or i32 %".221", %".223"
  %".225" = zext i32 0 to i64
  %".226" = zext i32 %".224" to i64
  %".227" = shl i64 %".226", 32
  %"shf_concat.3" = or i64 %".225", %".227"
  %"shf_shift_64.3" = zext i32 5 to i64
  %".228" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".228", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".229" = zext i32 %"imad.11" to i64
  %".230" = zext i32 0 to i64
  %".231" = shl i64 %".230", 32
  %"shf_concat.4" = or i64 %".229", %".231"
  %"shf_shift_64.4" = zext i32 %"shf_result.3" to i64
  %".232" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".232" to i32
  %".233" = xor i32 %"lds.2", -1
  %".234" = xor i32 %"shf_result.4", -1
  %".235" = xor i32 0, -1
  %".236" = and i32 %"lds.2", %"shf_result.4"
  %".237" = and i32 %".236", %".235"
  %".238" = and i32 %"lds.2", %"shf_result.4"
  %".239" = and i32 %".238", 0
  %".240" = or i32 %".237", %".239"
  %"isetrp_cmp1.1" = icmp ne i32 %".240", %"shf_result.4"
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.11", 1
  %".241" = zext i32 %"imad.12" to i64
  %".242" = zext i32 0 to i64
  %".243" = shl i64 %".242", 32
  %"shf_concat.5" = or i64 %".241", %".243"
  %"shf_shift_64.5" = zext i32 %"shf_result.3" to i64
  %".244" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".244" to i32
  br label %"BB_0db0"
BB_0db0:
  %"cond_trunc.3" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_trunc.3" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_0f40_0fa0", label %"BB_0dc0"
BB_0dc0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".215", 24
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".247" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".247" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".248" = xor i32 %"lds.3", -1
  %".249" = xor i32 %"shf_result.5", -1
  %".250" = xor i32 0, -1
  %".251" = and i32 %"lds.3", %"shf_result.5"
  %".252" = and i32 %".251", %".250"
  %".253" = and i32 %"lds.3", %"shf_result.5"
  %".254" = and i32 %".253", 0
  %".255" = or i32 %".252", %".254"
  %"isetrp_cmp1.2" = icmp ne i32 %".255", %"shf_result.5"
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0df0"
BB_0df0:
  %"cond_trunc.4" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0f10_0f70", label %"BB_0e00"
BB_0e00:
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".258" = xor i32 0, -1
  %".259" = xor i32 %"shf_result.5", -1
  %".260" = xor i32 0, -1
  %".261" = and i32 %".258", %".259"
  %".262" = and i32 %".261", %".260"
  %".263" = and i32 %".258", %".259"
  %".264" = and i32 %".263", 0
  %".265" = or i32 %".262", %".264"
  %".266" = and i32 0, %".259"
  %".267" = and i32 %".266", %".260"
  %".268" = or i32 %".265", %".267"
  %".269" = and i32 0, %".259"
  %".270" = and i32 %".269", 0
  %".271" = or i32 %".268", %".270"
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".271", i32 %"redux_mask")
  %".272" = xor i32 0, -1
  %".273" = xor i32 %"shf_result.4", -1
  %".274" = xor i32 0, -1
  %".275" = and i32 %".272", %".273"
  %".276" = and i32 %".275", %".274"
  %".277" = and i32 %".272", %".273"
  %".278" = and i32 %".277", 0
  %".279" = or i32 %".276", %".278"
  %".280" = and i32 0, %".273"
  %".281" = and i32 %".280", %".274"
  %".282" = or i32 %".279", %".281"
  %".283" = and i32 0, %".273"
  %".284" = and i32 %".283", 0
  %".285" = or i32 %".282", %".284"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".285", i32 %"redux_mask.1")
  %".286" = xor i32 %".285", -1
  %".287" = call i32 @"llvm.cttz.i32"(i32 %".286", i1 0)
  %".288" = shl i32 %".287", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 128;", "r,~{memory}"(i32 %".288") convergent
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.12", %"redux_sync_and"
  %"isetrp_cmp1.3" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.13", %"redux_sync_and.1"
  br label %"BB_0ed0"
BB_0ed0:
  %"cond_trunc.5" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000ed0", label %"BB_0f50"
BB_80000ed0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".215", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".292" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".292" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.14" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".215", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".293" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".293" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.13" monotonic
  br label %"BB_0f50"
BB_0f10_0f70:
  call void @"llvm.trap"()
  br label %"BB_0f50"
BB_0f40_0fa0:
  call void @"llvm.trap"()
  br label %"BB_0f50"
BB_0f50:
  ret void
BB_80000cd0:
  ret void
}

@"const_mem" = global [5 x [904 x i8]] [[904 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [904 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [904 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [904 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [904 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64)* @"_Z8transferPj", !"kernel", i32 1 }
