; ModuleID = "tcgen05_tmem_a_pair.ll"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [10256 x i8], align 16
@"__slifter_nv_global" = addrspace(1) global [1 x i8] zeroinitializer, align 16
define void @"_Z8mma_caseILj1188EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P7_to_i32" = zext i1 0 to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"UR11:UR10_r0" = trunc i64 %"ldc_const" to i32
  %"UR11:UR10_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR11:UR10_r1" = trunc i64 %"UR11:UR10_r1_shift" to i32
  %"imad_tmp" = mul i32 %"s2ur_cluster_ctarank", 2560
  %"imad" = add i32 %"imad_tmp", 0
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.1" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"UR5:UR4_r0" = trunc i64 %"imad.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"imad.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"UR5:UR4_r0"
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"UR5:UR4_r1"
  %"imad_addend_r0_ext.1" = zext i32 %"imad.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"imad.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"tid_x" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.4", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0" to i64
  %"iadd3_o2_64" = zext i32 %"UR11:UR10_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"iadd3_n1" = add i32 %"R3:R2_r1", %"UR11:UR10_r1"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P1_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"iadd3_cin2_add", %"EntryBB_0000"], [%"imad_with_cin", %"BB_01b0"]
  %"phi.1" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_01b0"]
  %"phi.2" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_01b0"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"EntryBB_0000"], [%"iadd3_trunc.1", %"BB_01b0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R101:R129_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R101:R129_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P2_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.3", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P2_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.5", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc" = trunc i32 %"P34_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0130", label %"BB_01c0"
BB_01c0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0210"
BB_0210:
  %"cond_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0310", label %"BB_0220"
BB_0220:
  %"iadd3_n1.1" = add i32 1024, 8192
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_64.2" = zext i32 %"iadd3_trunc" to i64
  %"iadd3_o2_64.2" = zext i32 8192 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P37_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2.1" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.4", %"iadd3_cin2_add"
  %"imad_cin_trunc.1" = trunc i32 %"P37_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.6", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0280"
BB_0280:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_0220"], [%"imad_with_cin.2", %"BB_0300"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_0220"], [%"viadd.2", %"BB_0300"]
  %"phi.6" = phi  i32 [%".46", %"BB_0220"], [%"viadd.3", %"BB_0300"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.2", %"BB_0220"], [%"iadd3_trunc.3", %"BB_0300"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R121:R35_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R121:R35_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.3" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.3" = zext i32 512 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P4_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.5", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P4_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.7", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.2" = trunc i32 %"P38_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0280", label %"BB_0310"
BB_0310:
  %"vote_pred_trunc" = trunc i32 %"P6_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.3" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000360", label %"BB_03b0"
BB_80000360:
  %"iadd3_n1.2" = add i32 1024, 9216
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.3" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".54" = zext i32 %"iadd3_n2.3" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.3" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.2" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_03b0"
BB_03b0:
  %"phi.8" = phi  i32 [%".68", %"BB_80000360"], [0, %"BB_0360"]
  %"phi.9" = phi  i32 [%"shf_result", %"BB_80000360"], [%"UR5:UR4_r1", %"BB_0360"]
  %"phi.10" = phi  i32 [%"shf_result.1", %"BB_80000360"], [1, %"BB_0360"]
  %"vote_pred_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P26_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.4" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800003d0", label %"BB_03e0"
BB_800003d0:
  %"mbar_shared_winoff" = and i32 %"phi.8", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_03e0"
BB_03e0:
  %"cond_trunc.5" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800003e0", label %"BB_03f0"
BB_800003e0:
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.6" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0860", label %"BB_0400"
BB_0400:
  %"pair_shared_winoff" = and i32 10248, 16777215
  %".80" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"pair_shared_winoff"
  %".81" = ptrtoint i8 addrspace(3)* %".80" to i32
  call void asm sideeffect "tcgen05.alloc.cta_group::2.sync.aligned.shared::cta.b32 [$0], $1;", "r,r,~{memory}"(i32 %".81", i32 64) convergent
  br label %"BB_0860"
BB_0860:
  call void @"llvm.nvvm.barrier0"()
  %".84" = zext i32 %"imad" to i64
  %".85" = zext i32 %"UR11:UR10_r0" to i64
  %".86" = zext i32 2 to i64
  %".87" = shl i64 %".84", %".86"
  %".88" = and i64 %".87", 4294967295
  %".89" = add i64 %".88", %".85"
  %".90" = trunc i64 %".89" to i32
  %".91" = lshr i64 %".89", 32
  %".92" = trunc i64 %".91" to i1
  %"P27_to_i32" = zext i1 %".92" to i32
  %"imad_tmp.6" = mul i32 %"tid_x", 2
  %"imad.8" = add i32 %"imad_tmp.6", 0
  %".93" = zext i32 %"imad" to i64
  %".94" = zext i32 0 to i64
  %".95" = shl i64 %".94", 32
  %"lea_funnel" = or i64 %".93", %".95"
  %".96" = zext i32 %"UR11:UR10_r1" to i64
  %".97" = zext i32 2 to i64
  %".98" = shl i64 %"lea_funnel", %".97"
  %".99" = lshr i64 %".98", 32
  %".100" = add i64 %".99", %".96"
  %"lea_cin_trunc" = trunc i32 %"P27_to_i32" to i1
  %".101" = zext i1 %"lea_cin_trunc" to i64
  %".102" = add i64 %".100", %".101"
  %".103" = trunc i64 %".102" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.7", %".90"
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.8", %".103"
  %"imad_addend_r0_ext.2" = zext i32 %"imad.9" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"imad.10" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.11" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R9:R8_r0" = trunc i64 %"imad.11" to i32
  %"R9:R8_r1_shift" = lshr i64 %"imad.11", 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R9:R8_r0" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R9:R8_r1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R84:R24_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R84:R24_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R9:R8_r0" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R9:R8_r1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R84:R24_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R84:R24_addr_ptr.1"
  %"imad_tmp.9" = mul i32 %"tid_x", 65536
  %"imad.12" = add i32 %"imad_tmp.9", 0
  %"R7:R6_r0" = trunc i64 0 to i32
  %"R7:R6_r1_shift" = lshr i64 0, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %".104" = xor i32 %"tid_x", -1
  %".105" = xor i32 %"s2ur_cluster_ctarank", -1
  %".106" = xor i32 0, -1
  %".107" = and i32 %".104", %"s2ur_cluster_ctarank"
  %".108" = and i32 %".107", %".106"
  %".109" = and i32 %".104", %"s2ur_cluster_ctarank"
  %".110" = and i32 %".109", 0
  %".111" = or i32 %".108", %".110"
  %".112" = and i32 %"tid_x", %".105"
  %".113" = and i32 %".112", %".106"
  %".114" = or i32 %".111", %".113"
  %".115" = and i32 %"tid_x", %".105"
  %".116" = and i32 %".115", 0
  %".117" = or i32 %".114", %".116"
  %".118" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".119" = and i32 %".118", %".106"
  %".120" = or i32 %".117", %".119"
  %".121" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".122" = and i32 %".121", 0
  %".123" = or i32 %".120", %".122"
  %"lop3_pred_cmp" = icmp ne i32 %".123", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P39_to_i32" = zext i1 %"lop3_p" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".124" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".124" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".125" = xor i32 %"imad.12", -1
  %".126" = xor i32 65011712, -1
  %".127" = xor i32 0, -1
  %".128" = and i32 %"imad.12", 65011712
  %".129" = and i32 %".128", %".127"
  %".130" = and i32 %"imad.12", 65011712
  %".131" = and i32 %".130", 0
  %".132" = or i32 %".129", %".131"
  %"imad_tmp.10" = mul i32 %"lds", 1
  %"imad.13" = add i32 %"imad_tmp.10", %".132"
  %"sttm_memaddr_offset_add" = add i32 %"imad.13", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.2", i32 %"ldg.3", i32 %"R7:R6_r0", i32 %"R7:R6_r1")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0a50"
BB_0a50:
  %"cond_trunc.7" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0cc0", label %"BB_0a60"
BB_0a60:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".140" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".140" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.4" = add i32 1024, 8192
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".141" = xor i32 %"plop3_a_bit", 1
  %".142" = xor i32 %"plop3_b_bit", 1
  %".143" = xor i32 %"plop3_c_bit", 1
  %".144" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".145" = and i32 %".144", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".145", 0
  %"P23_to_i32" = zext i1 %"plop3_pred" to i32
  %".146" = zext i32 0 to i64
  %".147" = zext i32 %".18" to i64
  %".148" = shl i64 %".147", 32
  %"shf_concat.2" = or i64 %".146", %".148"
  %"shf_shift_64.2" = zext i32 4 to i64
  %".149" = lshr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi" = lshr i64 %".149", 32
  %"shf_result.2" = trunc i64 %"shf_hi" to i32
  %"viadd.4" = add i32 %"lds", 32
  %".150" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".151" = zext i32 %"iadd3_n2.4" to i64
  %".152" = zext i32 24 to i64
  %".153" = shl i64 %".150", %".152"
  %".154" = and i64 %".153", 4294967295
  %".155" = add i64 %".154", %".151"
  %".156" = trunc i64 %".155" to i32
  %".157" = xor i32 %"shf_result.2", -1
  %".158" = xor i32 16376, -1
  %".159" = xor i32 0, -1
  %".160" = and i32 %"shf_result.2", 16376
  %".161" = and i32 %".160", %".159"
  %".162" = and i32 %"shf_result.2", 16376
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %".165" = zext i32 0 to i64
  %".166" = zext i32 %".156" to i64
  %".167" = shl i64 %".166", 32
  %"shf_concat.3" = or i64 %".165", %".167"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".168" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".168", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".169" = xor i32 %".164", -1
  %".170" = xor i32 524288, -1
  %".171" = xor i32 0, -1
  %".172" = and i32 %".169", 524288
  %".173" = and i32 %".172", %".171"
  %".174" = and i32 %".169", 524288
  %".175" = and i32 %".174", 0
  %".176" = or i32 %".173", %".175"
  %".177" = and i32 %".164", %".170"
  %".178" = and i32 %".177", %".171"
  %".179" = or i32 %".176", %".178"
  %".180" = and i32 %".164", %".170"
  %".181" = and i32 %".180", 0
  %".182" = or i32 %".179", %".181"
  %".183" = and i32 %".164", 524288
  %".184" = and i32 %".183", %".171"
  %".185" = or i32 %".182", %".184"
  %".186" = and i32 %".164", 524288
  %".187" = and i32 %".186", 0
  %".188" = or i32 %".185", %".187"
  %".189" = xor i32 %"shf_result.3", -1
  %".190" = xor i32 16376, -1
  %".191" = xor i32 0, -1
  %".192" = and i32 %"shf_result.3", 16376
  %".193" = and i32 %".192", %".191"
  %".194" = and i32 %"shf_result.3", 16376
  %".195" = and i32 %".194", 0
  %".196" = or i32 %".193", %".195"
  %".197" = xor i32 %".196", -1
  %".198" = xor i32 524288, -1
  %".199" = xor i32 0, -1
  %".200" = and i32 %".197", 524288
  %".201" = and i32 %".200", %".199"
  %".202" = and i32 %".197", 524288
  %".203" = and i32 %".202", 0
  %".204" = or i32 %".201", %".203"
  %".205" = and i32 %".196", %".198"
  %".206" = and i32 %".205", %".199"
  %".207" = or i32 %".204", %".206"
  %".208" = and i32 %".196", %".198"
  %".209" = and i32 %".208", 0
  %".210" = or i32 %".207", %".209"
  %".211" = and i32 %".196", 524288
  %".212" = and i32 %".211", %".199"
  %".213" = or i32 %".210", %".212"
  %".214" = and i32 %".196", 524288
  %".215" = and i32 %".214", 0
  %".216" = or i32 %".213", %".215"
  %"iadd3_n1.5" = add i32 %"lds.1", 40
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0b40"
BB_0b40:
  %"phi.11" = phi  i32 [%"P7_to_i32", %"BB_0a60"], [%"P17_to_i32", %"BB_0b70"]
  %"phi.12" = phi  i32 [%"P23_to_i32", %"BB_0a60"], [%"phi.14", %"BB_0b70"]
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000b40", label %"BB_0b50"
BB_80000b40:
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P15_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0b50"
BB_0b50:
  %"phi.13" = phi  i32 [%"P15_to_i32", %"BB_80000b40"], [%"phi.11", %"BB_0b40"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.1", 40
  %"copy_desc_r0_ext" = zext i32 %".188" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".220" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".221" = sub i64 %".220", 0
  %".222" = lshr i64 %".221", 4
  %".223" = add i64 %"copy_desc_packed_1", %".222"
  %".224" = and i64 %".223", 16383
  %".225" = and i64 %"copy_desc_packed_1", -16384
  %".226" = or i64 %".225", %".224"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::2.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".226")
  br label %"BB_0b60"
BB_0b60:
  %"cond_trunc.9" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000b60", label %"BB_0b70"
BB_80000b60:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".230" = xor i32 %"plop3_a_bit.1", 1
  %".231" = xor i32 %"plop3_b_bit.1", 1
  %".232" = xor i32 %"plop3_c_bit.1", 1
  %".233" = and i32 %".230", %"plop3_b_bit.1"
  %".234" = and i32 %".233", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".234", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0b70"
BB_0b70:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_80000b60"], [%"phi.12", %"BB_0b60"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".236" = xor i32 %"plop3_a_bit.2", 1
  %".237" = xor i32 %"plop3_b_bit.2", 1
  %".238" = xor i32 %"plop3_c_bit.2", 1
  %".239" = and i32 %".236", %"plop3_b_bit.2"
  %".240" = and i32 %".239", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".240", 0
  %"P17_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0b40", label %"BB_0b90"
BB_0b90:
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".242" = xor i32 %"plop3_a_bit.3", 1
  %".243" = xor i32 %"plop3_b_bit.3", 1
  %".244" = xor i32 %"plop3_c_bit.3", 1
  %".245" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".246" = and i32 %".245", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".246", 0
  %"P28_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0be0"
BB_0be0:
  %"phi.15" = phi  i32 [%"P17_to_i32", %"BB_0b90"], [%"P21_to_i32", %"BB_0c10"]
  %"phi.16" = phi  i32 [%"P28_to_i32", %"BB_0b90"], [%"phi.18", %"BB_0c10"]
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000be0", label %"BB_0bf0"
BB_80000be0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P19_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0bf0"
BB_0bf0:
  %"phi.17" = phi  i32 [%"P19_to_i32", %"BB_80000be0"], [%"phi.15", %"BB_0be0"]
  %"mma_b_r0_ext" = zext i32 %".216" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16416 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".250" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".251" = sub i64 %".250", 0
  %".252" = lshr i64 %".251", 4
  %".253" = add i64 %"mma_b_packed_1", %".252"
  %".254" = and i64 %".253", 16383
  %".255" = and i64 %"mma_b_packed_1", -16384
  %".256" = or i64 %".255", %".254"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.sp.cta_group::2.kind::i8 [$0], [$1], $2, [$5], $3, use_d; } }", "r,r,l,r,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.5", i64 %".256", i32 268960932, i32 %"mma_arg_zext", i32 %"viadd.4")
  br label %"BB_0c00"
BB_0c00:
  %"cond_trunc.11" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000c00", label %"BB_0c10"
BB_80000c00:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".260" = xor i32 %"plop3_a_bit.4", 1
  %".261" = xor i32 %"plop3_b_bit.4", 1
  %".262" = xor i32 %"plop3_c_bit.4", 1
  %".263" = and i32 %".260", %"plop3_b_bit.4"
  %".264" = and i32 %".263", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".264", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0c10"
BB_0c10:
  %"phi.18" = phi  i32 [%"P31_to_i32", %"BB_80000c00"], [%"phi.16", %"BB_0c00"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".266" = xor i32 %"plop3_a_bit.5", 1
  %".267" = xor i32 %"plop3_b_bit.5", 1
  %".268" = xor i32 %"plop3_c_bit.5", 1
  %".269" = and i32 %".266", %"plop3_b_bit.5"
  %".270" = and i32 %".269", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".270", 0
  %"P21_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0be0", label %"BB_0c30"
BB_0c30:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".272" = xor i32 %"plop3_a_bit.6", 1
  %".273" = xor i32 %"plop3_b_bit.6", 1
  %".274" = xor i32 %"plop3_c_bit.6", 1
  %".275" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".276" = and i32 %".275", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".276", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.6" to i32
  %".277" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".278" = zext i32 %"iadd3_n2.6" to i64
  %".279" = zext i32 24 to i64
  %".280" = shl i64 %".277", %".279"
  %".281" = and i64 %".280", 4294967295
  %".282" = add i64 %".281", %".278"
  %".283" = trunc i64 %".282" to i32
  br label %"BB_0c70"
BB_0c70:
  %"phi.19" = phi  i32 [%"P21_to_i32", %"BB_0c30"], [%"P13_to_i32", %"BB_0ca0"]
  %"phi.20" = phi  i32 [%"P40_to_i32", %"BB_0c30"], [%"phi.22", %"BB_0ca0"]
  %"cond_trunc.12" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000c70", label %"BB_0c80"
BB_80000c70:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P10_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0c80"
BB_0c80:
  %"phi.21" = phi  i32 [%"P10_to_i32", %"BB_80000c70"], [%"phi.19", %"BB_0c70"]
  %"utcbar_local_winoff" = and i32 %".283", 16777215
  %".287" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".288" = ptrtoint i8 addrspace(3)* %".287" to i32
  %".289" = lshr i32 %".283", 24
  %"utcbar_mask16_trunc" = trunc i32 3 to i16
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], $2; } }", "r,r,h,~{memory}"(i32 %".288", i32 %".289", i16 %"utcbar_mask16_trunc")
  br label %"BB_0c90"
BB_0c90:
  %"cond_trunc.13" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000c90", label %"BB_0ca0"
BB_80000c90:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".293" = xor i32 %"plop3_a_bit.7", 1
  %".294" = xor i32 %"plop3_b_bit.7", 1
  %".295" = xor i32 %"plop3_c_bit.7", 1
  %".296" = and i32 %".293", %"plop3_b_bit.7"
  %".297" = and i32 %".296", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".297", 0
  %"P30_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_0ca0"
BB_0ca0:
  %"phi.22" = phi  i32 [%"P30_to_i32", %"BB_80000c90"], [%"phi.20", %"BB_0c90"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".299" = xor i32 %"plop3_a_bit.8", 1
  %".300" = xor i32 %"plop3_b_bit.8", 1
  %".301" = xor i32 %"plop3_c_bit.8", 1
  %".302" = and i32 %".299", %"plop3_b_bit.8"
  %".303" = and i32 %".302", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".303", 0
  %"P13_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0c70", label %"BB_0cc0"
BB_0cc0:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0d10"
BB_0d10:
  %"cond_trunc.14" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0d90", label %"BB_0d20"
BB_0d20:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".307" = zext i32 0 to i64
  %".308" = zext i32 0 to i64
  %".309" = shl i64 %".308", 32
  %"shf_concat.4" = or i64 %".307", %".309"
  %"shf_shift_64.4" = zext i32 31 to i64
  %".310" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".310" to i32
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", %"iadd3_n2.7"
  %".311" = zext i32 %"cluster_ctarank.1" to i64
  %".312" = zext i32 %"imad.14" to i64
  %".313" = zext i32 24 to i64
  %".314" = shl i64 %".311", %".313"
  %".315" = and i64 %".314", 4294967295
  %".316" = add i64 %".315", %".312"
  %".317" = trunc i64 %".316" to i32
  %"iadd3_n1.8" = add i32 %".317", 0
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"mbar_shared_winoff.1" = and i32 %"iadd3_n2.8", 16777215
  %".318" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".318" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0d80"
BB_0d80:
  %"cond_trunc.15" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1550", label %"BB_0d90"
BB_1550:
  %"iadd3_n1.9" = add i32 %".317", 0
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"mbar_shared_winoff.2" = and i32 %"iadd3_n2.9", 16777215
  %".321" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".321" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1570"
BB_1570:
  %"cond_trunc.16" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1550", label %"BB_0d90"
BB_0d90:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.12" = mul i32 %"cluster_ctarank", 128
  %"imad.15" = add i32 %"imad_tmp.12", %"tid_x"
  %".324" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".325" = bitcast i8* %".324" to i64*
  %"ldc_const.1" = load i64, i64* %".325"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.13" = mul i32 %"imad.15", 32
  %"imad.16" = add i32 %"imad_tmp.13", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.13")
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".328" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.13", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".331" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".332" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".333" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.3" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.3" = or i64 0, %"imad_addend_r0_ext.3"
  %"imad_addend_r1_ext.3" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.3" = shl i64 %"imad_addend_r1_ext.3", 32
  %"imad_addend_packed_1.3" = or i64 %"imad_addend_packed_0.3", %"imad_addend_r1_shift.3"
  %"imad_lhs_64.3" = zext i32 %"imad.16" to i64
  %"imad_rhs_64.3" = zext i32 4 to i64
  %"imad_tmp_64.3" = mul i64 %"imad_lhs_64.3", %"imad_rhs_64.3"
  %"imad.17" = add i64 %"imad_tmp_64.3", %"imad_addend_packed_1.3"
  %"R13:R12_r0.1" = trunc i64 %"imad.17" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.17", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R105:R82_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R105:R82_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R105:R82_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R105:R82_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R105:R82_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".328", i32 addrspace(1)* %"R105:R82_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R105:R82_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R105:R82_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R105:R82_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R105:R82_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.13", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R105:R82_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".331", i32 addrspace(1)* %"R105:R82_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R105:R82_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".332", i32 addrspace(1)* %"R105:R82_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R105:R82_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".333", i32 addrspace(1)* %"R105:R82_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.13", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".346" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".347" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".348" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R105:R82_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R105:R82_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R105:R82_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R105:R82_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R105:R82_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R105:R82_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R105:R82_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R105:R82_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R105:R82_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".346", i32 addrspace(1)* %"R105:R82_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.13", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".355" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R105:R82_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".347", i32 addrspace(1)* %"R105:R82_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R105:R82_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".348", i32 addrspace(1)* %"R105:R82_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R105:R82_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R105:R82_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.13", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".362" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".363" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".364" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".365" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R105:R82_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".355", i32 addrspace(1)* %"R105:R82_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R105:R82_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R105:R82_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R105:R82_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R105:R82_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R105:R82_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R105:R82_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R105:R82_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".362", i32 addrspace(1)* %"R105:R82_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.13", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".371" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".372" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".373" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R105:R82_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".363", i32 addrspace(1)* %"R105:R82_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R105:R82_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".364", i32 addrspace(1)* %"R105:R82_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R105:R82_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".365", i32 addrspace(1)* %"R105:R82_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.13", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".378" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".379" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".380" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".381" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R105:R82_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".371", i32 addrspace(1)* %"R105:R82_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R105:R82_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".372", i32 addrspace(1)* %"R105:R82_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R105:R82_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".373", i32 addrspace(1)* %"R105:R82_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R105:R82_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R105:R82_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R105:R82_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".378", i32 addrspace(1)* %"R105:R82_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R105:R82_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".379", i32 addrspace(1)* %"R105:R82_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R105:R82_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".380", i32 addrspace(1)* %"R105:R82_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R105:R82_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".381", i32 addrspace(1)* %"R105:R82_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_1210"
BB_1210:
  %"cond_trunc.17" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001210", label %"BB_1220"
BB_1220:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".394" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".394" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  call void asm sideeffect "tcgen05.dealloc.cta_group::2.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %"lds.2", i32 64) convergent
  ret void
BB_80001210:
  ret void
}

define void @"_Z8mma_caseILj74896EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P7_to_i32" = zext i1 0 to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"UR13:UR12_r0" = trunc i64 %"ldc_const" to i32
  %"UR13:UR12_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR13:UR12_r1" = trunc i64 %"UR13:UR12_r1_shift" to i32
  %"imad_tmp" = mul i32 %"s2ur_cluster_ctarank", 2560
  %"imad" = add i32 %"imad_tmp", 0
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.1" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"UR5:UR4_r0" = trunc i64 %"imad.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"imad.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"UR5:UR4_r0"
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"UR5:UR4_r1"
  %"imad_addend_r0_ext.1" = zext i32 %"imad.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"imad.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"tid_x" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.4", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0" to i64
  %"iadd3_o2_64" = zext i32 %"UR13:UR12_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"iadd3_n1" = add i32 %"R3:R2_r1", %"UR13:UR12_r1"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P1_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"iadd3_cin2_add", %"EntryBB_0000"], [%"imad_with_cin", %"BB_01b0"]
  %"phi.1" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_01b0"]
  %"phi.2" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_01b0"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"EntryBB_0000"], [%"iadd3_trunc.1", %"BB_01b0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R64:R25_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R64:R25_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P2_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.3", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P2_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.5", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc" = trunc i32 %"P34_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0130", label %"BB_01c0"
BB_01c0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0210"
BB_0210:
  %"cond_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0310", label %"BB_0220"
BB_0220:
  %"iadd3_n1.1" = add i32 1024, 8192
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_64.2" = zext i32 %"iadd3_trunc" to i64
  %"iadd3_o2_64.2" = zext i32 8192 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P36_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2.1" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.4", %"iadd3_cin2_add"
  %"imad_cin_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.6", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0280"
BB_0280:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_0220"], [%"imad_with_cin.2", %"BB_0300"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_0220"], [%"viadd.2", %"BB_0300"]
  %"phi.6" = phi  i32 [%".46", %"BB_0220"], [%"viadd.3", %"BB_0300"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.2", %"BB_0220"], [%"iadd3_trunc.3", %"BB_0300"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R67:R28_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R28_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.3" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.3" = zext i32 512 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P4_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.5", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P4_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.7", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0280", label %"BB_0310"
BB_0310:
  %"vote_pred_trunc" = trunc i32 %"P6_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.3" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000360", label %"BB_03b0"
BB_80000360:
  %"iadd3_n1.2" = add i32 1024, 9216
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.3" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".54" = zext i32 %"iadd3_n2.3" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.3" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.2" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_03b0"
BB_03b0:
  %"phi.8" = phi  i32 [%".68", %"BB_80000360"], [0, %"BB_0360"]
  %"phi.9" = phi  i32 [%"shf_result", %"BB_80000360"], [%"UR5:UR4_r1", %"BB_0360"]
  %"phi.10" = phi  i32 [%"shf_result.1", %"BB_80000360"], [1, %"BB_0360"]
  %"vote_pred_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P26_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.4" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800003d0", label %"BB_03e0"
BB_800003d0:
  %"mbar_shared_winoff" = and i32 %"phi.8", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_03e0"
BB_03e0:
  %"cond_trunc.5" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800003e0", label %"BB_03f0"
BB_800003e0:
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.6" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0860", label %"BB_0400"
BB_0400:
  %"pair_shared_winoff" = and i32 10248, 16777215
  %".80" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"pair_shared_winoff"
  %".81" = ptrtoint i8 addrspace(3)* %".80" to i32
  call void asm sideeffect "tcgen05.alloc.cta_group::2.sync.aligned.shared::cta.b32 [$0], $1;", "r,r,~{memory}"(i32 %".81", i32 64) convergent
  br label %"BB_0860"
BB_0860:
  call void @"llvm.nvvm.barrier0"()
  %".84" = xor i32 %"tid_x", -1
  %".85" = xor i32 %"s2ur_cluster_ctarank", -1
  %".86" = xor i32 0, -1
  %".87" = and i32 %".84", %"s2ur_cluster_ctarank"
  %".88" = and i32 %".87", %".86"
  %".89" = and i32 %".84", %"s2ur_cluster_ctarank"
  %".90" = and i32 %".89", 0
  %".91" = or i32 %".88", %".90"
  %".92" = and i32 %"tid_x", %".85"
  %".93" = and i32 %".92", %".86"
  %".94" = or i32 %".91", %".93"
  %".95" = and i32 %"tid_x", %".85"
  %".96" = and i32 %".95", 0
  %".97" = or i32 %".94", %".96"
  %".98" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".99" = and i32 %".98", %".86"
  %".100" = or i32 %".97", %".99"
  %".101" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".102" = and i32 %".101", 0
  %".103" = or i32 %".100", %".102"
  %"lop3_pred_cmp" = icmp ne i32 %".103", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P38_to_i32" = zext i1 %"lop3_p" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.7" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0bc0", label %"BB_0970"
BB_0970:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".110" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".110" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.4" = add i32 1024, 8192
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".111" = xor i32 %"plop3_a_bit", 1
  %".112" = xor i32 %"plop3_b_bit", 1
  %".113" = xor i32 %"plop3_c_bit", 1
  %".114" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".115" = and i32 %".114", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".115", 0
  %"P23_to_i32" = zext i1 %"plop3_pred" to i32
  %".116" = zext i32 0 to i64
  %".117" = zext i32 %".18" to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.2" = or i64 %".116", %".118"
  %"shf_shift_64.2" = zext i32 4 to i64
  %".119" = lshr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi" = lshr i64 %".119", 32
  %"shf_result.2" = trunc i64 %"shf_hi" to i32
  %".120" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".121" = zext i32 %"iadd3_n2.4" to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = xor i32 %"shf_result.2", -1
  %".128" = xor i32 16376, -1
  %".129" = xor i32 0, -1
  %".130" = and i32 %"shf_result.2", 16376
  %".131" = and i32 %".130", %".129"
  %".132" = and i32 %"shf_result.2", 16376
  %".133" = and i32 %".132", 0
  %".134" = or i32 %".131", %".133"
  %".135" = zext i32 0 to i64
  %".136" = zext i32 %".126" to i64
  %".137" = shl i64 %".136", 32
  %"shf_concat.3" = or i64 %".135", %".137"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".138" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".138", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".139" = xor i32 %".134", -1
  %".140" = xor i32 524288, -1
  %".141" = xor i32 0, -1
  %".142" = and i32 %".139", 524288
  %".143" = and i32 %".142", %".141"
  %".144" = and i32 %".139", 524288
  %".145" = and i32 %".144", 0
  %".146" = or i32 %".143", %".145"
  %".147" = and i32 %".134", %".140"
  %".148" = and i32 %".147", %".141"
  %".149" = or i32 %".146", %".148"
  %".150" = and i32 %".134", %".140"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %".134", 524288
  %".154" = and i32 %".153", %".141"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %".134", 524288
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = xor i32 %"shf_result.3", -1
  %".160" = xor i32 16376, -1
  %".161" = xor i32 0, -1
  %".162" = and i32 %"shf_result.3", 16376
  %".163" = and i32 %".162", %".161"
  %".164" = and i32 %"shf_result.3", 16376
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = xor i32 %".166", -1
  %".168" = xor i32 1048576, -1
  %".169" = xor i32 0, -1
  %".170" = and i32 %".167", 1048576
  %".171" = and i32 %".170", %".169"
  %".172" = and i32 %".167", 1048576
  %".173" = and i32 %".172", 0
  %".174" = or i32 %".171", %".173"
  %".175" = and i32 %".166", %".168"
  %".176" = and i32 %".175", %".169"
  %".177" = or i32 %".174", %".176"
  %".178" = and i32 %".166", %".168"
  %".179" = and i32 %".178", 0
  %".180" = or i32 %".177", %".179"
  %".181" = and i32 %".166", 1048576
  %".182" = and i32 %".181", %".169"
  %".183" = or i32 %".180", %".182"
  %".184" = and i32 %".166", 1048576
  %".185" = and i32 %".184", 0
  %".186" = or i32 %".183", %".185"
  %"iadd3_n1.5" = add i32 %"lds.1", 40
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0a40"
BB_0a40:
  %"phi.11" = phi  i32 [%"P7_to_i32", %"BB_0970"], [%"P17_to_i32", %"BB_0a70"]
  %"phi.12" = phi  i32 [%"P23_to_i32", %"BB_0970"], [%"phi.14", %"BB_0a70"]
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000a40", label %"BB_0a50"
BB_80000a40:
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P15_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0a50"
BB_0a50:
  %"phi.13" = phi  i32 [%"P15_to_i32", %"BB_80000a40"], [%"phi.11", %"BB_0a40"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.1", 40
  %"copy_desc_r0_ext" = zext i32 %".158" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".190" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".191" = sub i64 %".190", 0
  %".192" = lshr i64 %".191", 4
  %".193" = add i64 %"copy_desc_packed_1", %".192"
  %".194" = and i64 %".193", 16383
  %".195" = and i64 %"copy_desc_packed_1", -16384
  %".196" = or i64 %".195", %".194"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::2.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".196")
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.9" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000a60", label %"BB_0a70"
BB_80000a60:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".200" = xor i32 %"plop3_a_bit.1", 1
  %".201" = xor i32 %"plop3_b_bit.1", 1
  %".202" = xor i32 %"plop3_c_bit.1", 1
  %".203" = and i32 %".200", %"plop3_b_bit.1"
  %".204" = and i32 %".203", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".204", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0a70"
BB_0a70:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_80000a60"], [%"phi.12", %"BB_0a60"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".206" = xor i32 %"plop3_a_bit.2", 1
  %".207" = xor i32 %"plop3_b_bit.2", 1
  %".208" = xor i32 %"plop3_c_bit.2", 1
  %".209" = and i32 %".206", %"plop3_b_bit.2"
  %".210" = and i32 %".209", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".210", 0
  %"P17_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0a40", label %"BB_0a90"
BB_0a90:
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".212" = xor i32 %"plop3_a_bit.3", 1
  %".213" = xor i32 %"plop3_b_bit.3", 1
  %".214" = xor i32 %"plop3_c_bit.3", 1
  %".215" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".216" = and i32 %".215", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".216", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0ae0"
BB_0ae0:
  %"phi.15" = phi  i32 [%"P17_to_i32", %"BB_0a90"], [%"P21_to_i32", %"BB_0b10"]
  %"phi.16" = phi  i32 [%"P27_to_i32", %"BB_0a90"], [%"phi.18", %"BB_0b10"]
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000ae0", label %"BB_0af0"
BB_80000ae0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P19_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0af0"
BB_0af0:
  %"phi.17" = phi  i32 [%"P19_to_i32", %"BB_80000ae0"], [%"phi.15", %"BB_0ae0"]
  %"mma_b_r0_ext" = zext i32 %".186" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16392 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".220" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".221" = sub i64 %".220", 0
  %".222" = lshr i64 %".221", 4
  %".223" = add i64 %"mma_b_packed_1", %".222"
  %".224" = and i64 %".223", 16383
  %".225" = and i64 %"mma_b_packed_1", -16384
  %".226" = or i64 %".225", %".224"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::2.kind::f16 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.5", i64 %".226", i32 269034640, i32 %"mma_arg_zext")
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.11" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000b00", label %"BB_0b10"
BB_80000b00:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".230" = xor i32 %"plop3_a_bit.4", 1
  %".231" = xor i32 %"plop3_b_bit.4", 1
  %".232" = xor i32 %"plop3_c_bit.4", 1
  %".233" = and i32 %".230", %"plop3_b_bit.4"
  %".234" = and i32 %".233", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".234", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0b10"
BB_0b10:
  %"phi.18" = phi  i32 [%"P29_to_i32", %"BB_80000b00"], [%"phi.16", %"BB_0b00"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".236" = xor i32 %"plop3_a_bit.5", 1
  %".237" = xor i32 %"plop3_b_bit.5", 1
  %".238" = xor i32 %"plop3_c_bit.5", 1
  %".239" = and i32 %".236", %"plop3_b_bit.5"
  %".240" = and i32 %".239", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".240", 0
  %"P21_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0ae0", label %"BB_0b30"
BB_0b30:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".242" = xor i32 %"plop3_a_bit.6", 1
  %".243" = xor i32 %"plop3_b_bit.6", 1
  %".244" = xor i32 %"plop3_c_bit.6", 1
  %".245" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".246" = and i32 %".245", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".246", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.6" to i32
  %".247" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".248" = zext i32 %"iadd3_n2.6" to i64
  %".249" = zext i32 24 to i64
  %".250" = shl i64 %".247", %".249"
  %".251" = and i64 %".250", 4294967295
  %".252" = add i64 %".251", %".248"
  %".253" = trunc i64 %".252" to i32
  br label %"BB_0b70"
BB_0b70:
  %"phi.19" = phi  i32 [%"P21_to_i32", %"BB_0b30"], [%"P13_to_i32", %"BB_0ba0"]
  %"phi.20" = phi  i32 [%"P39_to_i32", %"BB_0b30"], [%"phi.22", %"BB_0ba0"]
  %"cond_trunc.12" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000b70", label %"BB_0b80"
BB_80000b70:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P10_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0b80"
BB_0b80:
  %"phi.21" = phi  i32 [%"P10_to_i32", %"BB_80000b70"], [%"phi.19", %"BB_0b70"]
  %"utcbar_local_winoff" = and i32 %".253", 16777215
  %".257" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".258" = ptrtoint i8 addrspace(3)* %".257" to i32
  %".259" = lshr i32 %".253", 24
  %"utcbar_mask16_trunc" = trunc i32 3 to i16
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], $2; } }", "r,r,h,~{memory}"(i32 %".258", i32 %".259", i16 %"utcbar_mask16_trunc")
  br label %"BB_0b90"
BB_0b90:
  %"cond_trunc.13" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".263" = xor i32 %"plop3_a_bit.7", 1
  %".264" = xor i32 %"plop3_b_bit.7", 1
  %".265" = xor i32 %"plop3_c_bit.7", 1
  %".266" = and i32 %".263", %"plop3_b_bit.7"
  %".267" = and i32 %".266", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".267", 0
  %"P30_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.22" = phi  i32 [%"P30_to_i32", %"BB_80000b90"], [%"phi.20", %"BB_0b90"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".269" = xor i32 %"plop3_a_bit.8", 1
  %".270" = xor i32 %"plop3_b_bit.8", 1
  %".271" = xor i32 %"plop3_c_bit.8", 1
  %".272" = and i32 %".269", %"plop3_b_bit.8"
  %".273" = and i32 %".272", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".273", 0
  %"P13_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0b70", label %"BB_0bc0"
BB_0bc0:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.6" = mul i32 %"tid_x", 65536
  %"imad.8" = add i32 %"imad_tmp.6", 0
  call void @"llvm.nvvm.barrier0"()
  %".275" = xor i32 %"imad.8", -1
  %".276" = xor i32 65011712, -1
  %".277" = xor i32 0, -1
  %".278" = and i32 %"imad.8", 65011712
  %".279" = and i32 %".278", %".277"
  %".280" = and i32 %"imad.8", 65011712
  %".281" = and i32 %".280", 0
  %".282" = or i32 %".279", %".281"
  %"imad_tmp.7" = mul i32 %"lds", 1
  %"imad.9" = add i32 %"imad_tmp.7", %".282"
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.14" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0cc0", label %"BB_0c50"
BB_0c50:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".285" = zext i32 0 to i64
  %".286" = zext i32 0 to i64
  %".287" = shl i64 %".286", 32
  %"shf_concat.4" = or i64 %".285", %".287"
  %"shf_shift_64.4" = zext i32 31 to i64
  %".288" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".288" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.8", %"iadd3_n2.7"
  %".289" = zext i32 %"cluster_ctarank.1" to i64
  %".290" = zext i32 %"imad.10" to i64
  %".291" = zext i32 24 to i64
  %".292" = shl i64 %".289", %".291"
  %".293" = and i64 %".292", 4294967295
  %".294" = add i64 %".293", %".290"
  %".295" = trunc i64 %".294" to i32
  %"iadd3_n1.8" = add i32 %".295", 0
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"mbar_shared_winoff.1" = and i32 %"iadd3_n2.8", 16777215
  %".296" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".296" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P33_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.15" = trunc i32 %"P33_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1480", label %"BB_0cc0"
BB_1480:
  %"iadd3_n1.9" = add i32 %".295", 0
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"mbar_shared_winoff.2" = and i32 %"iadd3_n2.9", 16777215
  %".299" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_14a0"
BB_14a0:
  %"cond_trunc.16" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1480", label %"BB_0cc0"
BB_0cc0:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.9" = mul i32 %"cluster_ctarank", 128
  %"imad.11" = add i32 %"imad_tmp.9", %"tid_x"
  %".302" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".303" = bitcast i8* %".302" to i64*
  %"ldc_const.1" = load i64, i64* %".303"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.10" = mul i32 %"imad.11", 32
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.9")
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.9", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.1" = trunc i64 %"imad.13" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.13", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R74:R54_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R74:R54_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R74:R54_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R74:R54_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R74:R54_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R74:R54_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R74:R54_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R74:R54_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R74:R54_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R74:R54_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.9", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".317" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".318" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".319" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R74:R54_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R74:R54_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R74:R54_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R74:R54_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R74:R54_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R74:R54_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.9", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R74:R54_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".317", i32 addrspace(1)* %"R74:R54_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R74:R54_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".318", i32 addrspace(1)* %"R74:R54_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R74:R54_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".319", i32 addrspace(1)* %"R74:R54_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R74:R54_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R74:R54_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R74:R54_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R74:R54_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.9", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".333" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".334" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".335" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".336" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R74:R54_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R74:R54_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R74:R54_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R74:R54_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R74:R54_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R74:R54_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.9", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R74:R54_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".333", i32 addrspace(1)* %"R74:R54_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R74:R54_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".334", i32 addrspace(1)* %"R74:R54_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R74:R54_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".335", i32 addrspace(1)* %"R74:R54_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R74:R54_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".336", i32 addrspace(1)* %"R74:R54_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R74:R54_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R74:R54_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.9", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".350" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R74:R54_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R74:R54_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R74:R54_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R74:R54_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R74:R54_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R74:R54_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.9", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R74:R54_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R74:R54_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R74:R54_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".350", i32 addrspace(1)* %"R74:R54_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R74:R54_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R74:R54_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R74:R54_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R74:R54_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R74:R54_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R74:R54_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R74:R54_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R74:R54_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R74:R54_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R74:R54_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R74:R54_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R74:R54_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_1140"
BB_1140:
  %"cond_trunc.17" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001140", label %"BB_1150"
BB_1150:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".372" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".372" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  call void asm sideeffect "tcgen05.dealloc.cta_group::2.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %"lds.2", i32 64) convergent
  ret void
BB_80001140:
  ret void
}

define void @"_Z8mma_caseILj65696EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P7_to_i32" = zext i1 0 to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"UR13:UR12_r0" = trunc i64 %"ldc_const" to i32
  %"UR13:UR12_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR13:UR12_r1" = trunc i64 %"UR13:UR12_r1_shift" to i32
  %"imad_tmp" = mul i32 %"s2ur_cluster_ctarank", 2560
  %"imad" = add i32 %"imad_tmp", 0
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.1" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"UR5:UR4_r0" = trunc i64 %"imad.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"imad.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"UR5:UR4_r0"
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"UR5:UR4_r1"
  %"imad_addend_r0_ext.1" = zext i32 %"imad.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"imad.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"tid_x" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.4", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0" to i64
  %"iadd3_o2_64" = zext i32 %"UR13:UR12_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"iadd3_n1" = add i32 %"R3:R2_r1", %"UR13:UR12_r1"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P1_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"iadd3_cin2_add", %"EntryBB_0000"], [%"imad_with_cin", %"BB_01b0"]
  %"phi.1" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_01b0"]
  %"phi.2" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_01b0"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"EntryBB_0000"], [%"iadd3_trunc.1", %"BB_01b0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R64:R25_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R64:R25_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P2_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.3", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P2_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.5", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc" = trunc i32 %"P34_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0130", label %"BB_01c0"
BB_01c0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0210"
BB_0210:
  %"cond_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0310", label %"BB_0220"
BB_0220:
  %"iadd3_n1.1" = add i32 1024, 8192
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_64.2" = zext i32 %"iadd3_trunc" to i64
  %"iadd3_o2_64.2" = zext i32 8192 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P36_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2.1" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.4", %"iadd3_cin2_add"
  %"imad_cin_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.6", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0280"
BB_0280:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_0220"], [%"imad_with_cin.2", %"BB_0300"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_0220"], [%"viadd.2", %"BB_0300"]
  %"phi.6" = phi  i32 [%".46", %"BB_0220"], [%"viadd.3", %"BB_0300"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.2", %"BB_0220"], [%"iadd3_trunc.3", %"BB_0300"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R67:R28_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R28_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.3" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.3" = zext i32 512 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P4_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.5", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P4_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.7", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0280", label %"BB_0310"
BB_0310:
  %"vote_pred_trunc" = trunc i32 %"P6_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.3" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000360", label %"BB_03b0"
BB_80000360:
  %"iadd3_n1.2" = add i32 1024, 9216
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.3" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".54" = zext i32 %"iadd3_n2.3" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.3" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.2" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_03b0"
BB_03b0:
  %"phi.8" = phi  i32 [%".68", %"BB_80000360"], [0, %"BB_0360"]
  %"phi.9" = phi  i32 [%"shf_result", %"BB_80000360"], [%"UR5:UR4_r1", %"BB_0360"]
  %"phi.10" = phi  i32 [%"shf_result.1", %"BB_80000360"], [1, %"BB_0360"]
  %"vote_pred_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P26_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.4" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800003d0", label %"BB_03e0"
BB_800003d0:
  %"mbar_shared_winoff" = and i32 %"phi.8", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_03e0"
BB_03e0:
  %"cond_trunc.5" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800003e0", label %"BB_03f0"
BB_800003e0:
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.6" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0860", label %"BB_0400"
BB_0400:
  %"pair_shared_winoff" = and i32 10248, 16777215
  %".80" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"pair_shared_winoff"
  %".81" = ptrtoint i8 addrspace(3)* %".80" to i32
  call void asm sideeffect "tcgen05.alloc.cta_group::2.sync.aligned.shared::cta.b32 [$0], $1;", "r,r,~{memory}"(i32 %".81", i32 64) convergent
  br label %"BB_0860"
BB_0860:
  call void @"llvm.nvvm.barrier0"()
  %".84" = xor i32 %"tid_x", -1
  %".85" = xor i32 %"s2ur_cluster_ctarank", -1
  %".86" = xor i32 0, -1
  %".87" = and i32 %".84", %"s2ur_cluster_ctarank"
  %".88" = and i32 %".87", %".86"
  %".89" = and i32 %".84", %"s2ur_cluster_ctarank"
  %".90" = and i32 %".89", 0
  %".91" = or i32 %".88", %".90"
  %".92" = and i32 %"tid_x", %".85"
  %".93" = and i32 %".92", %".86"
  %".94" = or i32 %".91", %".93"
  %".95" = and i32 %"tid_x", %".85"
  %".96" = and i32 %".95", 0
  %".97" = or i32 %".94", %".96"
  %".98" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".99" = and i32 %".98", %".86"
  %".100" = or i32 %".97", %".99"
  %".101" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".102" = and i32 %".101", 0
  %".103" = or i32 %".100", %".102"
  %"lop3_pred_cmp" = icmp ne i32 %".103", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P38_to_i32" = zext i1 %"lop3_p" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.7" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0bc0", label %"BB_0970"
BB_0970:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".110" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".110" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.4" = add i32 1024, 8192
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".111" = xor i32 %"plop3_a_bit", 1
  %".112" = xor i32 %"plop3_b_bit", 1
  %".113" = xor i32 %"plop3_c_bit", 1
  %".114" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".115" = and i32 %".114", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".115", 0
  %"P23_to_i32" = zext i1 %"plop3_pred" to i32
  %".116" = zext i32 0 to i64
  %".117" = zext i32 %".18" to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.2" = or i64 %".116", %".118"
  %"shf_shift_64.2" = zext i32 4 to i64
  %".119" = lshr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi" = lshr i64 %".119", 32
  %"shf_result.2" = trunc i64 %"shf_hi" to i32
  %".120" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".121" = zext i32 %"iadd3_n2.4" to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = xor i32 %"shf_result.2", -1
  %".128" = xor i32 16376, -1
  %".129" = xor i32 0, -1
  %".130" = and i32 %"shf_result.2", 16376
  %".131" = and i32 %".130", %".129"
  %".132" = and i32 %"shf_result.2", 16376
  %".133" = and i32 %".132", 0
  %".134" = or i32 %".131", %".133"
  %".135" = zext i32 0 to i64
  %".136" = zext i32 %".126" to i64
  %".137" = shl i64 %".136", 32
  %"shf_concat.3" = or i64 %".135", %".137"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".138" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".138", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".139" = xor i32 %".134", -1
  %".140" = xor i32 524288, -1
  %".141" = xor i32 0, -1
  %".142" = and i32 %".139", 524288
  %".143" = and i32 %".142", %".141"
  %".144" = and i32 %".139", 524288
  %".145" = and i32 %".144", 0
  %".146" = or i32 %".143", %".145"
  %".147" = and i32 %".134", %".140"
  %".148" = and i32 %".147", %".141"
  %".149" = or i32 %".146", %".148"
  %".150" = and i32 %".134", %".140"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %".134", 524288
  %".154" = and i32 %".153", %".141"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %".134", 524288
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = xor i32 %"shf_result.3", -1
  %".160" = xor i32 16376, -1
  %".161" = xor i32 0, -1
  %".162" = and i32 %"shf_result.3", 16376
  %".163" = and i32 %".162", %".161"
  %".164" = and i32 %"shf_result.3", 16376
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = xor i32 %".166", -1
  %".168" = xor i32 524288, -1
  %".169" = xor i32 0, -1
  %".170" = and i32 %".167", 524288
  %".171" = and i32 %".170", %".169"
  %".172" = and i32 %".167", 524288
  %".173" = and i32 %".172", 0
  %".174" = or i32 %".171", %".173"
  %".175" = and i32 %".166", %".168"
  %".176" = and i32 %".175", %".169"
  %".177" = or i32 %".174", %".176"
  %".178" = and i32 %".166", %".168"
  %".179" = and i32 %".178", 0
  %".180" = or i32 %".177", %".179"
  %".181" = and i32 %".166", 524288
  %".182" = and i32 %".181", %".169"
  %".183" = or i32 %".180", %".182"
  %".184" = and i32 %".166", 524288
  %".185" = and i32 %".184", 0
  %".186" = or i32 %".183", %".185"
  %"iadd3_n1.5" = add i32 %"lds.1", 40
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0a40"
BB_0a40:
  %"phi.11" = phi  i32 [%"P7_to_i32", %"BB_0970"], [%"P17_to_i32", %"BB_0a70"]
  %"phi.12" = phi  i32 [%"P23_to_i32", %"BB_0970"], [%"phi.14", %"BB_0a70"]
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000a40", label %"BB_0a50"
BB_80000a40:
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P15_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0a50"
BB_0a50:
  %"phi.13" = phi  i32 [%"P15_to_i32", %"BB_80000a40"], [%"phi.11", %"BB_0a40"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.1", 40
  %"copy_desc_r0_ext" = zext i32 %".158" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".190" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".191" = sub i64 %".190", 0
  %".192" = lshr i64 %".191", 4
  %".193" = add i64 %"copy_desc_packed_1", %".192"
  %".194" = and i64 %".193", 16383
  %".195" = and i64 %"copy_desc_packed_1", -16384
  %".196" = or i64 %".195", %".194"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::2.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".196")
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.9" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000a60", label %"BB_0a70"
BB_80000a60:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".200" = xor i32 %"plop3_a_bit.1", 1
  %".201" = xor i32 %"plop3_b_bit.1", 1
  %".202" = xor i32 %"plop3_c_bit.1", 1
  %".203" = and i32 %".200", %"plop3_b_bit.1"
  %".204" = and i32 %".203", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".204", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0a70"
BB_0a70:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_80000a60"], [%"phi.12", %"BB_0a60"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".206" = xor i32 %"plop3_a_bit.2", 1
  %".207" = xor i32 %"plop3_b_bit.2", 1
  %".208" = xor i32 %"plop3_c_bit.2", 1
  %".209" = and i32 %".206", %"plop3_b_bit.2"
  %".210" = and i32 %".209", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".210", 0
  %"P17_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0a40", label %"BB_0a90"
BB_0a90:
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".212" = xor i32 %"plop3_a_bit.3", 1
  %".213" = xor i32 %"plop3_b_bit.3", 1
  %".214" = xor i32 %"plop3_c_bit.3", 1
  %".215" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".216" = and i32 %".215", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".216", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0ae0"
BB_0ae0:
  %"phi.15" = phi  i32 [%"P17_to_i32", %"BB_0a90"], [%"P21_to_i32", %"BB_0b10"]
  %"phi.16" = phi  i32 [%"P27_to_i32", %"BB_0a90"], [%"phi.18", %"BB_0b10"]
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000ae0", label %"BB_0af0"
BB_80000ae0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P19_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0af0"
BB_0af0:
  %"phi.17" = phi  i32 [%"P19_to_i32", %"BB_80000ae0"], [%"phi.15", %"BB_0ae0"]
  %"mma_b_r0_ext" = zext i32 %".186" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16392 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".220" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".221" = sub i64 %".220", 0
  %".222" = lshr i64 %".221", 4
  %".223" = add i64 %"mma_b_packed_1", %".222"
  %".224" = and i64 %".223", 16383
  %".225" = and i64 %"mma_b_packed_1", -16384
  %".226" = or i64 %".225", %".224"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::2.kind::i8 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.5", i64 %".226", i32 269025440, i32 %"mma_arg_zext")
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.11" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000b00", label %"BB_0b10"
BB_80000b00:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".230" = xor i32 %"plop3_a_bit.4", 1
  %".231" = xor i32 %"plop3_b_bit.4", 1
  %".232" = xor i32 %"plop3_c_bit.4", 1
  %".233" = and i32 %".230", %"plop3_b_bit.4"
  %".234" = and i32 %".233", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".234", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0b10"
BB_0b10:
  %"phi.18" = phi  i32 [%"P29_to_i32", %"BB_80000b00"], [%"phi.16", %"BB_0b00"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".236" = xor i32 %"plop3_a_bit.5", 1
  %".237" = xor i32 %"plop3_b_bit.5", 1
  %".238" = xor i32 %"plop3_c_bit.5", 1
  %".239" = and i32 %".236", %"plop3_b_bit.5"
  %".240" = and i32 %".239", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".240", 0
  %"P21_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0ae0", label %"BB_0b30"
BB_0b30:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".242" = xor i32 %"plop3_a_bit.6", 1
  %".243" = xor i32 %"plop3_b_bit.6", 1
  %".244" = xor i32 %"plop3_c_bit.6", 1
  %".245" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".246" = and i32 %".245", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".246", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.6" to i32
  %".247" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".248" = zext i32 %"iadd3_n2.6" to i64
  %".249" = zext i32 24 to i64
  %".250" = shl i64 %".247", %".249"
  %".251" = and i64 %".250", 4294967295
  %".252" = add i64 %".251", %".248"
  %".253" = trunc i64 %".252" to i32
  br label %"BB_0b70"
BB_0b70:
  %"phi.19" = phi  i32 [%"P21_to_i32", %"BB_0b30"], [%"P13_to_i32", %"BB_0ba0"]
  %"phi.20" = phi  i32 [%"P39_to_i32", %"BB_0b30"], [%"phi.22", %"BB_0ba0"]
  %"cond_trunc.12" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000b70", label %"BB_0b80"
BB_80000b70:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P10_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0b80"
BB_0b80:
  %"phi.21" = phi  i32 [%"P10_to_i32", %"BB_80000b70"], [%"phi.19", %"BB_0b70"]
  %"utcbar_local_winoff" = and i32 %".253", 16777215
  %".257" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".258" = ptrtoint i8 addrspace(3)* %".257" to i32
  %".259" = lshr i32 %".253", 24
  %"utcbar_mask16_trunc" = trunc i32 3 to i16
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], $2; } }", "r,r,h,~{memory}"(i32 %".258", i32 %".259", i16 %"utcbar_mask16_trunc")
  br label %"BB_0b90"
BB_0b90:
  %"cond_trunc.13" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".263" = xor i32 %"plop3_a_bit.7", 1
  %".264" = xor i32 %"plop3_b_bit.7", 1
  %".265" = xor i32 %"plop3_c_bit.7", 1
  %".266" = and i32 %".263", %"plop3_b_bit.7"
  %".267" = and i32 %".266", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".267", 0
  %"P30_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.22" = phi  i32 [%"P30_to_i32", %"BB_80000b90"], [%"phi.20", %"BB_0b90"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".269" = xor i32 %"plop3_a_bit.8", 1
  %".270" = xor i32 %"plop3_b_bit.8", 1
  %".271" = xor i32 %"plop3_c_bit.8", 1
  %".272" = and i32 %".269", %"plop3_b_bit.8"
  %".273" = and i32 %".272", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".273", 0
  %"P13_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0b70", label %"BB_0bc0"
BB_0bc0:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.6" = mul i32 %"tid_x", 65536
  %"imad.8" = add i32 %"imad_tmp.6", 0
  call void @"llvm.nvvm.barrier0"()
  %".275" = xor i32 %"imad.8", -1
  %".276" = xor i32 65011712, -1
  %".277" = xor i32 0, -1
  %".278" = and i32 %"imad.8", 65011712
  %".279" = and i32 %".278", %".277"
  %".280" = and i32 %"imad.8", 65011712
  %".281" = and i32 %".280", 0
  %".282" = or i32 %".279", %".281"
  %"imad_tmp.7" = mul i32 %"lds", 1
  %"imad.9" = add i32 %"imad_tmp.7", %".282"
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.14" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0cc0", label %"BB_0c50"
BB_0c50:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".285" = zext i32 0 to i64
  %".286" = zext i32 0 to i64
  %".287" = shl i64 %".286", 32
  %"shf_concat.4" = or i64 %".285", %".287"
  %"shf_shift_64.4" = zext i32 31 to i64
  %".288" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".288" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.8", %"iadd3_n2.7"
  %".289" = zext i32 %"cluster_ctarank.1" to i64
  %".290" = zext i32 %"imad.10" to i64
  %".291" = zext i32 24 to i64
  %".292" = shl i64 %".289", %".291"
  %".293" = and i64 %".292", 4294967295
  %".294" = add i64 %".293", %".290"
  %".295" = trunc i64 %".294" to i32
  %"iadd3_n1.8" = add i32 %".295", 0
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"mbar_shared_winoff.1" = and i32 %"iadd3_n2.8", 16777215
  %".296" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".296" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P33_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.15" = trunc i32 %"P33_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1480", label %"BB_0cc0"
BB_1480:
  %"iadd3_n1.9" = add i32 %".295", 0
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"mbar_shared_winoff.2" = and i32 %"iadd3_n2.9", 16777215
  %".299" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_14a0"
BB_14a0:
  %"cond_trunc.16" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1480", label %"BB_0cc0"
BB_0cc0:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.9" = mul i32 %"cluster_ctarank", 128
  %"imad.11" = add i32 %"imad_tmp.9", %"tid_x"
  %".302" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".303" = bitcast i8* %".302" to i64*
  %"ldc_const.1" = load i64, i64* %".303"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.10" = mul i32 %"imad.11", 32
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.9")
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.9", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.1" = trunc i64 %"imad.13" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.13", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R74:R54_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R74:R54_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R74:R54_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R74:R54_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R74:R54_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R74:R54_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R74:R54_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R74:R54_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R74:R54_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R74:R54_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.9", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".317" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".318" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".319" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R74:R54_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R74:R54_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R74:R54_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R74:R54_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R74:R54_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R74:R54_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.9", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R74:R54_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".317", i32 addrspace(1)* %"R74:R54_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R74:R54_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".318", i32 addrspace(1)* %"R74:R54_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R74:R54_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".319", i32 addrspace(1)* %"R74:R54_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R74:R54_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R74:R54_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R74:R54_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R74:R54_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.9", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".333" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".334" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".335" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".336" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R74:R54_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R74:R54_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R74:R54_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R74:R54_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R74:R54_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R74:R54_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.9", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R74:R54_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".333", i32 addrspace(1)* %"R74:R54_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R74:R54_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".334", i32 addrspace(1)* %"R74:R54_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R74:R54_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".335", i32 addrspace(1)* %"R74:R54_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R74:R54_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".336", i32 addrspace(1)* %"R74:R54_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R74:R54_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R74:R54_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.9", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".350" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R74:R54_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R74:R54_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R74:R54_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R74:R54_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R74:R54_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R74:R54_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.9", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R74:R54_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R74:R54_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R74:R54_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".350", i32 addrspace(1)* %"R74:R54_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R74:R54_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R74:R54_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R74:R54_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R74:R54_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R74:R54_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R74:R54_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R74:R54_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R74:R54_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R74:R54_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R74:R54_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R74:R54_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R74:R54_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_1140"
BB_1140:
  %"cond_trunc.17" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001140", label %"BB_1150"
BB_1150:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".372" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".372" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  call void asm sideeffect "tcgen05.dealloc.cta_group::2.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %"lds.2", i32 64) convergent
  ret void
BB_80001140:
  ret void
}

define void @"_Z8mma_caseILj1184EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P7_to_i32" = zext i1 0 to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"UR13:UR12_r0" = trunc i64 %"ldc_const" to i32
  %"UR13:UR12_r1_shift" = lshr i64 %"ldc_const", 32
  %"UR13:UR12_r1" = trunc i64 %"UR13:UR12_r1_shift" to i32
  %"imad_tmp" = mul i32 %"s2ur_cluster_ctarank", 2560
  %"imad" = add i32 %"imad_tmp", 0
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %"imad_addend_r0_ext" = zext i32 0 to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 0 to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"imad" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.1" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"UR5:UR4_r0" = trunc i64 %"imad.1" to i32
  %"UR5:UR4_r1_shift" = lshr i64 %"imad.1", 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"UR5:UR4_r0"
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"UR5:UR4_r1"
  %"imad_addend_r0_ext.1" = zext i32 %"imad.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"imad.3" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"tid_x" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.4", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0" to i64
  %"iadd3_o2_64" = zext i32 %"UR13:UR12_r0" to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P1_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"iadd3_n1" = add i32 %"R3:R2_r1", %"UR13:UR12_r1"
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P1_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  br label %"BB_0130"
BB_0130:
  %"phi" = phi  i32 [%"iadd3_cin2_add", %"EntryBB_0000"], [%"imad_with_cin", %"BB_01b0"]
  %"phi.1" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_01b0"]
  %"phi.2" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_01b0"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"EntryBB_0000"], [%"iadd3_trunc.1", %"BB_01b0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R64:R25_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R64:R25_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P2_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.3", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P2_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.5", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".27" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc" = trunc i32 %"P34_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0130", label %"BB_01c0"
BB_01c0:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_0210"
BB_0210:
  %"cond_trunc.1" = trunc i32 %"P35_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0310", label %"BB_0220"
BB_0220:
  %"iadd3_n1.1" = add i32 1024, 8192
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_64.2" = zext i32 %"iadd3_trunc" to i64
  %"iadd3_o2_64.2" = zext i32 8192 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P36_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2.1" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.4", %"iadd3_cin2_add"
  %"imad_cin_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.6", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0280"
BB_0280:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_0220"], [%"imad_with_cin.2", %"BB_0300"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_0220"], [%"viadd.2", %"BB_0300"]
  %"phi.6" = phi  i32 [%".46", %"BB_0220"], [%"viadd.3", %"BB_0300"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.2", %"BB_0220"], [%"iadd3_trunc.3", %"BB_0300"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R67:R28_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R28_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.3" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.3" = zext i32 512 to i64
  %"iadd3_o3_64.3" = zext i32 0 to i64
  %"iadd3_tmp.3" = add i64 %"iadd3_o1_64.3", %"iadd3_o2_64.3"
  %"iadd3_tmp2.3" = add i64 %"iadd3_tmp.3", %"iadd3_o3_64.3"
  %"iadd3_trunc.3" = trunc i64 %"iadd3_tmp2.3" to i32
  %"iadd3_carry_val.3" = lshr i64 %"iadd3_tmp2.3", 32
  %"carry_ge_1.3" = icmp uge i64 %"iadd3_carry_val.3", 1
  %"P4_to_i32" = zext i1 %"carry_ge_1.3" to i32
  %"carry_ge_2.3" = icmp uge i64 %"iadd3_carry_val.3", 2
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.7" = add i32 %"imad_tmp.5", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P4_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.7", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.2" = trunc i32 %"P37_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0280", label %"BB_0310"
BB_0310:
  %"vote_pred_trunc" = trunc i32 %"P6_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.3" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000360", label %"BB_03b0"
BB_80000360:
  %"iadd3_n1.2" = add i32 1024, 9216
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.3" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".54" = zext i32 %"iadd3_n2.3" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.3" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.2" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_03b0"
BB_03b0:
  %"phi.8" = phi  i32 [%".68", %"BB_80000360"], [0, %"BB_0360"]
  %"phi.9" = phi  i32 [%"shf_result", %"BB_80000360"], [%"UR5:UR4_r1", %"BB_0360"]
  %"phi.10" = phi  i32 [%"shf_result.1", %"BB_80000360"], [1, %"BB_0360"]
  %"vote_pred_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P26_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.4" = trunc i32 %"P26_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800003d0", label %"BB_03e0"
BB_800003d0:
  %"mbar_shared_winoff" = and i32 %"phi.8", 16777215
  %".73" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_03e0"
BB_03e0:
  %"cond_trunc.5" = trunc i32 %"P6_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_800003e0", label %"BB_03f0"
BB_800003e0:
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.6" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0860", label %"BB_0400"
BB_0400:
  %"pair_shared_winoff" = and i32 10248, 16777215
  %".80" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"pair_shared_winoff"
  %".81" = ptrtoint i8 addrspace(3)* %".80" to i32
  call void asm sideeffect "tcgen05.alloc.cta_group::2.sync.aligned.shared::cta.b32 [$0], $1;", "r,r,~{memory}"(i32 %".81", i32 64) convergent
  br label %"BB_0860"
BB_0860:
  call void @"llvm.nvvm.barrier0"()
  %".84" = xor i32 %"tid_x", -1
  %".85" = xor i32 %"s2ur_cluster_ctarank", -1
  %".86" = xor i32 0, -1
  %".87" = and i32 %".84", %"s2ur_cluster_ctarank"
  %".88" = and i32 %".87", %".86"
  %".89" = and i32 %".84", %"s2ur_cluster_ctarank"
  %".90" = and i32 %".89", 0
  %".91" = or i32 %".88", %".90"
  %".92" = and i32 %"tid_x", %".85"
  %".93" = and i32 %".92", %".86"
  %".94" = or i32 %".91", %".93"
  %".95" = and i32 %"tid_x", %".85"
  %".96" = and i32 %".95", 0
  %".97" = or i32 %".94", %".96"
  %".98" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".99" = and i32 %".98", %".86"
  %".100" = or i32 %".97", %".99"
  %".101" = and i32 %"tid_x", %"s2ur_cluster_ctarank"
  %".102" = and i32 %".101", 0
  %".103" = or i32 %".100", %".102"
  %"lop3_pred_cmp" = icmp ne i32 %".103", 0
  %"lop3_q_to_i32" = zext i1 0 to i32
  %"lop3_q_to_i1" = icmp ne i32 %"lop3_q_to_i32", 0
  %"lop3_p" = or i1 %"lop3_pred_cmp", %"lop3_q_to_i1"
  %"P38_to_i32" = zext i1 %"lop3_p" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 9224
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.7" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0bc0", label %"BB_0970"
BB_0970:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".110" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".110" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.4" = add i32 1024, 8192
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".111" = xor i32 %"plop3_a_bit", 1
  %".112" = xor i32 %"plop3_b_bit", 1
  %".113" = xor i32 %"plop3_c_bit", 1
  %".114" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".115" = and i32 %".114", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".115", 0
  %"P23_to_i32" = zext i1 %"plop3_pred" to i32
  %".116" = zext i32 0 to i64
  %".117" = zext i32 %".18" to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.2" = or i64 %".116", %".118"
  %"shf_shift_64.2" = zext i32 4 to i64
  %".119" = lshr i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_hi" = lshr i64 %".119", 32
  %"shf_result.2" = trunc i64 %"shf_hi" to i32
  %".120" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".121" = zext i32 %"iadd3_n2.4" to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = xor i32 %"shf_result.2", -1
  %".128" = xor i32 16376, -1
  %".129" = xor i32 0, -1
  %".130" = and i32 %"shf_result.2", 16376
  %".131" = and i32 %".130", %".129"
  %".132" = and i32 %"shf_result.2", 16376
  %".133" = and i32 %".132", 0
  %".134" = or i32 %".131", %".133"
  %".135" = zext i32 0 to i64
  %".136" = zext i32 %".126" to i64
  %".137" = shl i64 %".136", 32
  %"shf_concat.3" = or i64 %".135", %".137"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".138" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi.1" = lshr i64 %".138", 32
  %"shf_result.3" = trunc i64 %"shf_hi.1" to i32
  %".139" = xor i32 %".134", -1
  %".140" = xor i32 524288, -1
  %".141" = xor i32 0, -1
  %".142" = and i32 %".139", 524288
  %".143" = and i32 %".142", %".141"
  %".144" = and i32 %".139", 524288
  %".145" = and i32 %".144", 0
  %".146" = or i32 %".143", %".145"
  %".147" = and i32 %".134", %".140"
  %".148" = and i32 %".147", %".141"
  %".149" = or i32 %".146", %".148"
  %".150" = and i32 %".134", %".140"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %".134", 524288
  %".154" = and i32 %".153", %".141"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %".134", 524288
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = xor i32 %"shf_result.3", -1
  %".160" = xor i32 16376, -1
  %".161" = xor i32 0, -1
  %".162" = and i32 %"shf_result.3", 16376
  %".163" = and i32 %".162", %".161"
  %".164" = and i32 %"shf_result.3", 16376
  %".165" = and i32 %".164", 0
  %".166" = or i32 %".163", %".165"
  %".167" = xor i32 %".166", -1
  %".168" = xor i32 524288, -1
  %".169" = xor i32 0, -1
  %".170" = and i32 %".167", 524288
  %".171" = and i32 %".170", %".169"
  %".172" = and i32 %".167", 524288
  %".173" = and i32 %".172", 0
  %".174" = or i32 %".171", %".173"
  %".175" = and i32 %".166", %".168"
  %".176" = and i32 %".175", %".169"
  %".177" = or i32 %".174", %".176"
  %".178" = and i32 %".166", %".168"
  %".179" = and i32 %".178", 0
  %".180" = or i32 %".177", %".179"
  %".181" = and i32 %".166", 524288
  %".182" = and i32 %".181", %".169"
  %".183" = or i32 %".180", %".182"
  %".184" = and i32 %".166", 524288
  %".185" = and i32 %".184", 0
  %".186" = or i32 %".183", %".185"
  %"iadd3_n1.5" = add i32 %"lds.1", 40
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_0a40"
BB_0a40:
  %"phi.11" = phi  i32 [%"P7_to_i32", %"BB_0970"], [%"P17_to_i32", %"BB_0a70"]
  %"phi.12" = phi  i32 [%"P23_to_i32", %"BB_0970"], [%"phi.14", %"BB_0a70"]
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000a40", label %"BB_0a50"
BB_80000a40:
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P15_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0a50"
BB_0a50:
  %"phi.13" = phi  i32 [%"P15_to_i32", %"BB_80000a40"], [%"phi.11", %"BB_0a40"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.1", 40
  %"copy_desc_r0_ext" = zext i32 %".158" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16400 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".190" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".191" = sub i64 %".190", 0
  %".192" = lshr i64 %".191", 4
  %".193" = add i64 %"copy_desc_packed_1", %".192"
  %".194" = and i64 %".193", 16383
  %".195" = and i64 %"copy_desc_packed_1", -16384
  %".196" = or i64 %".195", %".194"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::2.128x256b [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".196")
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.9" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000a60", label %"BB_0a70"
BB_80000a60:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".200" = xor i32 %"plop3_a_bit.1", 1
  %".201" = xor i32 %"plop3_b_bit.1", 1
  %".202" = xor i32 %"plop3_c_bit.1", 1
  %".203" = and i32 %".200", %"plop3_b_bit.1"
  %".204" = and i32 %".203", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".204", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0a70"
BB_0a70:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_80000a60"], [%"phi.12", %"BB_0a60"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".206" = xor i32 %"plop3_a_bit.2", 1
  %".207" = xor i32 %"plop3_b_bit.2", 1
  %".208" = xor i32 %"plop3_c_bit.2", 1
  %".209" = and i32 %".206", %"plop3_b_bit.2"
  %".210" = and i32 %".209", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".210", 0
  %"P17_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0a40", label %"BB_0a90"
BB_0a90:
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".212" = xor i32 %"plop3_a_bit.3", 1
  %".213" = xor i32 %"plop3_b_bit.3", 1
  %".214" = xor i32 %"plop3_c_bit.3", 1
  %".215" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".216" = and i32 %".215", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".216", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0ae0"
BB_0ae0:
  %"phi.15" = phi  i32 [%"P17_to_i32", %"BB_0a90"], [%"P21_to_i32", %"BB_0b10"]
  %"phi.16" = phi  i32 [%"P27_to_i32", %"BB_0a90"], [%"phi.18", %"BB_0b10"]
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000ae0", label %"BB_0af0"
BB_80000ae0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P19_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0af0"
BB_0af0:
  %"phi.17" = phi  i32 [%"P19_to_i32", %"BB_80000ae0"], [%"phi.15", %"BB_0ae0"]
  %"mma_b_r0_ext" = zext i32 %".186" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".220" = ptrtoint [10256 x i8] addrspace(3)* @"shared_mem" to i64
  %".221" = sub i64 %".220", 0
  %".222" = lshr i64 %".221", 4
  %".223" = add i64 %"mma_b_packed_1", %".222"
  %".224" = and i64 %".223", 16383
  %".225" = and i64 %"mma_b_packed_1", -16384
  %".226" = or i64 %".225", %".224"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::2.kind::i8 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.5", i64 %".226", i32 268960928, i32 %"mma_arg_zext")
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.11" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000b00", label %"BB_0b10"
BB_80000b00:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".230" = xor i32 %"plop3_a_bit.4", 1
  %".231" = xor i32 %"plop3_b_bit.4", 1
  %".232" = xor i32 %"plop3_c_bit.4", 1
  %".233" = and i32 %".230", %"plop3_b_bit.4"
  %".234" = and i32 %".233", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".234", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0b10"
BB_0b10:
  %"phi.18" = phi  i32 [%"P29_to_i32", %"BB_80000b00"], [%"phi.16", %"BB_0b00"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".236" = xor i32 %"plop3_a_bit.5", 1
  %".237" = xor i32 %"plop3_b_bit.5", 1
  %".238" = xor i32 %"plop3_c_bit.5", 1
  %".239" = and i32 %".236", %"plop3_b_bit.5"
  %".240" = and i32 %".239", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".240", 0
  %"P21_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0ae0", label %"BB_0b30"
BB_0b30:
  %"iadd3_n1.6" = add i32 1024, 9216
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".242" = xor i32 %"plop3_a_bit.6", 1
  %".243" = xor i32 %"plop3_b_bit.6", 1
  %".244" = xor i32 %"plop3_c_bit.6", 1
  %".245" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".246" = and i32 %".245", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".246", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.6" to i32
  %".247" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".248" = zext i32 %"iadd3_n2.6" to i64
  %".249" = zext i32 24 to i64
  %".250" = shl i64 %".247", %".249"
  %".251" = and i64 %".250", 4294967295
  %".252" = add i64 %".251", %".248"
  %".253" = trunc i64 %".252" to i32
  br label %"BB_0b70"
BB_0b70:
  %"phi.19" = phi  i32 [%"P21_to_i32", %"BB_0b30"], [%"P13_to_i32", %"BB_0ba0"]
  %"phi.20" = phi  i32 [%"P39_to_i32", %"BB_0b30"], [%"phi.22", %"BB_0ba0"]
  %"cond_trunc.12" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000b70", label %"BB_0b80"
BB_80000b70:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P10_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0b80"
BB_0b80:
  %"phi.21" = phi  i32 [%"P10_to_i32", %"BB_80000b70"], [%"phi.19", %"BB_0b70"]
  %"utcbar_local_winoff" = and i32 %".253", 16777215
  %".257" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".258" = ptrtoint i8 addrspace(3)* %".257" to i32
  %".259" = lshr i32 %".253", 24
  %"utcbar_mask16_trunc" = trunc i32 3 to i16
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], $2; } }", "r,r,h,~{memory}"(i32 %".258", i32 %".259", i16 %"utcbar_mask16_trunc")
  br label %"BB_0b90"
BB_0b90:
  %"cond_trunc.13" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".263" = xor i32 %"plop3_a_bit.7", 1
  %".264" = xor i32 %"plop3_b_bit.7", 1
  %".265" = xor i32 %"plop3_c_bit.7", 1
  %".266" = and i32 %".263", %"plop3_b_bit.7"
  %".267" = and i32 %".266", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".267", 0
  %"P30_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.22" = phi  i32 [%"P30_to_i32", %"BB_80000b90"], [%"phi.20", %"BB_0b90"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".269" = xor i32 %"plop3_a_bit.8", 1
  %".270" = xor i32 %"plop3_b_bit.8", 1
  %".271" = xor i32 %"plop3_c_bit.8", 1
  %".272" = and i32 %".269", %"plop3_b_bit.8"
  %".273" = and i32 %".272", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".273", 0
  %"P13_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0b70", label %"BB_0bc0"
BB_0bc0:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.6" = mul i32 %"tid_x", 65536
  %"imad.8" = add i32 %"imad_tmp.6", 0
  call void @"llvm.nvvm.barrier0"()
  %".275" = xor i32 %"imad.8", -1
  %".276" = xor i32 65011712, -1
  %".277" = xor i32 0, -1
  %".278" = and i32 %"imad.8", 65011712
  %".279" = and i32 %".278", %".277"
  %".280" = and i32 %"imad.8", 65011712
  %".281" = and i32 %".280", 0
  %".282" = or i32 %".279", %".281"
  %"imad_tmp.7" = mul i32 %"lds", 1
  %"imad.9" = add i32 %"imad_tmp.7", %".282"
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.14" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0cc0", label %"BB_0c50"
BB_0c50:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"iadd3_n1.7" = add i32 1024, 9216
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".285" = zext i32 0 to i64
  %".286" = zext i32 0 to i64
  %".287" = shl i64 %".286", 32
  %"shf_concat.4" = or i64 %".285", %".287"
  %"shf_shift_64.4" = zext i32 31 to i64
  %".288" = shl i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_result.4" = trunc i64 %".288" to i32
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.8", %"iadd3_n2.7"
  %".289" = zext i32 %"cluster_ctarank.1" to i64
  %".290" = zext i32 %"imad.10" to i64
  %".291" = zext i32 24 to i64
  %".292" = shl i64 %".289", %".291"
  %".293" = and i64 %".292", 4294967295
  %".294" = add i64 %".293", %".290"
  %".295" = trunc i64 %".294" to i32
  %"iadd3_n1.8" = add i32 %".295", 0
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %"mbar_shared_winoff.1" = and i32 %"iadd3_n2.8", 16777215
  %".296" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".296" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P33_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0cb0"
BB_0cb0:
  %"cond_trunc.15" = trunc i32 %"P33_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_1480", label %"BB_0cc0"
BB_1480:
  %"iadd3_n1.9" = add i32 %".295", 0
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %"mbar_shared_winoff.2" = and i32 %"iadd3_n2.9", 16777215
  %".299" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.4", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_14a0"
BB_14a0:
  %"cond_trunc.16" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_1480", label %"BB_0cc0"
BB_0cc0:
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.9" = mul i32 %"cluster_ctarank", 128
  %"imad.11" = add i32 %"imad_tmp.9", %"tid_x"
  %".302" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".303" = bitcast i8* %".302" to i64*
  %"ldc_const.1" = load i64, i64* %".303"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.10" = mul i32 %"imad.11", 32
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.9")
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.9", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.1" = trunc i64 %"imad.13" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.13", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R74:R54_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R74:R54_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R74:R54_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R74:R54_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R74:R54_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R74:R54_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R74:R54_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R74:R54_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R74:R54_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R74:R54_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.9", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".317" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".318" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".319" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R74:R54_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R74:R54_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R74:R54_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R74:R54_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R74:R54_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R74:R54_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.9", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R74:R54_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".317", i32 addrspace(1)* %"R74:R54_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R74:R54_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".318", i32 addrspace(1)* %"R74:R54_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R74:R54_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".319", i32 addrspace(1)* %"R74:R54_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R74:R54_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R74:R54_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R74:R54_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R74:R54_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.9", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".333" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".334" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".335" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".336" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R74:R54_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R74:R54_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R74:R54_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R74:R54_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R74:R54_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R74:R54_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.9", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R74:R54_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".333", i32 addrspace(1)* %"R74:R54_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R74:R54_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".334", i32 addrspace(1)* %"R74:R54_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R74:R54_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".335", i32 addrspace(1)* %"R74:R54_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R74:R54_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".336", i32 addrspace(1)* %"R74:R54_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R74:R54_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R74:R54_addr_ptr.20"
  %"ldtm_addr_memaddr_offset_add.5" = add i32 %"imad.9", 24
  %"ldtm.6" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.5")
  %".349" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 0
  %".350" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 1
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 2
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm.6", 3
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R74:R54_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R74:R54_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R74:R54_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R74:R54_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R74:R54_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R74:R54_addr_ptr.23"
  %"ldtm_addr_memaddr_offset_add.6" = add i32 %"imad.9", 28
  %"ldtm.7" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.6")
  %".356" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 0
  %".357" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 1
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 2
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.7", 3
  %"stg_addr_r0_ext.24" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.24" = or i64 0, %"stg_addr_r0_ext.24"
  %"stg_addr_r1_ext.24" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.24" = shl i64 %"stg_addr_r1_ext.24", 32
  %"stg_addr_packed_1.24" = or i64 %"stg_addr_packed_0.24", %"stg_addr_r1_shift.24"
  %"stg_addr_memaddr_offset_add.23" = add i64 %"stg_addr_packed_1.24", 96
  %"R74:R54_addr_ptr.24" = inttoptr i64 %"stg_addr_memaddr_offset_add.23" to i32 addrspace(1)*
  store i32 %".349", i32 addrspace(1)* %"R74:R54_addr_ptr.24"
  %"stg_addr_r0_ext.25" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.25" = or i64 0, %"stg_addr_r0_ext.25"
  %"stg_addr_r1_ext.25" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.25" = shl i64 %"stg_addr_r1_ext.25", 32
  %"stg_addr_packed_1.25" = or i64 %"stg_addr_packed_0.25", %"stg_addr_r1_shift.25"
  %"stg_addr_memaddr_offset_add.24" = add i64 %"stg_addr_packed_1.25", 100
  %"R74:R54_addr_ptr.25" = inttoptr i64 %"stg_addr_memaddr_offset_add.24" to i32 addrspace(1)*
  store i32 %".350", i32 addrspace(1)* %"R74:R54_addr_ptr.25"
  %"stg_addr_r0_ext.26" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.26" = or i64 0, %"stg_addr_r0_ext.26"
  %"stg_addr_r1_ext.26" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.26" = shl i64 %"stg_addr_r1_ext.26", 32
  %"stg_addr_packed_1.26" = or i64 %"stg_addr_packed_0.26", %"stg_addr_r1_shift.26"
  %"stg_addr_memaddr_offset_add.25" = add i64 %"stg_addr_packed_1.26", 104
  %"R74:R54_addr_ptr.26" = inttoptr i64 %"stg_addr_memaddr_offset_add.25" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R74:R54_addr_ptr.26"
  %"stg_addr_r0_ext.27" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.27" = or i64 0, %"stg_addr_r0_ext.27"
  %"stg_addr_r1_ext.27" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.27" = shl i64 %"stg_addr_r1_ext.27", 32
  %"stg_addr_packed_1.27" = or i64 %"stg_addr_packed_0.27", %"stg_addr_r1_shift.27"
  %"stg_addr_memaddr_offset_add.26" = add i64 %"stg_addr_packed_1.27", 108
  %"R74:R54_addr_ptr.27" = inttoptr i64 %"stg_addr_memaddr_offset_add.26" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R74:R54_addr_ptr.27"
  %"stg_addr_r0_ext.28" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.28" = or i64 0, %"stg_addr_r0_ext.28"
  %"stg_addr_r1_ext.28" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.28" = shl i64 %"stg_addr_r1_ext.28", 32
  %"stg_addr_packed_1.28" = or i64 %"stg_addr_packed_0.28", %"stg_addr_r1_shift.28"
  %"stg_addr_memaddr_offset_add.27" = add i64 %"stg_addr_packed_1.28", 112
  %"R74:R54_addr_ptr.28" = inttoptr i64 %"stg_addr_memaddr_offset_add.27" to i32 addrspace(1)*
  store i32 %".356", i32 addrspace(1)* %"R74:R54_addr_ptr.28"
  %"stg_addr_r0_ext.29" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.29" = or i64 0, %"stg_addr_r0_ext.29"
  %"stg_addr_r1_ext.29" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.29" = shl i64 %"stg_addr_r1_ext.29", 32
  %"stg_addr_packed_1.29" = or i64 %"stg_addr_packed_0.29", %"stg_addr_r1_shift.29"
  %"stg_addr_memaddr_offset_add.28" = add i64 %"stg_addr_packed_1.29", 116
  %"R74:R54_addr_ptr.29" = inttoptr i64 %"stg_addr_memaddr_offset_add.28" to i32 addrspace(1)*
  store i32 %".357", i32 addrspace(1)* %"R74:R54_addr_ptr.29"
  %"stg_addr_r0_ext.30" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.30" = or i64 0, %"stg_addr_r0_ext.30"
  %"stg_addr_r1_ext.30" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.30" = shl i64 %"stg_addr_r1_ext.30", 32
  %"stg_addr_packed_1.30" = or i64 %"stg_addr_packed_0.30", %"stg_addr_r1_shift.30"
  %"stg_addr_memaddr_offset_add.29" = add i64 %"stg_addr_packed_1.30", 120
  %"R74:R54_addr_ptr.30" = inttoptr i64 %"stg_addr_memaddr_offset_add.29" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R74:R54_addr_ptr.30"
  %"stg_addr_r0_ext.31" = zext i32 %"R13:R12_r0.1" to i64
  %"stg_addr_packed_0.31" = or i64 0, %"stg_addr_r0_ext.31"
  %"stg_addr_r1_ext.31" = zext i32 %"R13:R12_r1.1" to i64
  %"stg_addr_r1_shift.31" = shl i64 %"stg_addr_r1_ext.31", 32
  %"stg_addr_packed_1.31" = or i64 %"stg_addr_packed_0.31", %"stg_addr_r1_shift.31"
  %"stg_addr_memaddr_offset_add.30" = add i64 %"stg_addr_packed_1.31", 124
  %"R74:R54_addr_ptr.31" = inttoptr i64 %"stg_addr_memaddr_offset_add.30" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R74:R54_addr_ptr.31"
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_1140"
BB_1140:
  %"cond_trunc.17" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80001140", label %"BB_1150"
BB_1150:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 9224
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".372" = getelementptr inbounds [10256 x i8], [10256 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".372" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  call void asm sideeffect "tcgen05.dealloc.cta_group::2.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %"lds.2", i32 64) convergent
  ret void
BB_80001140:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare void @"llvm.nvvm.membar.gl"()

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4, !5, !6, !7, !8, !9, !10, !11, !12, !13, !14, !15, !16 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z8mma_caseILj1188EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z8mma_caseILj1188EEvPKjPj", !"cluster_dim_x", i32 2 }
!3 = !{ void (i64, i64)* @"_Z8mma_caseILj1188EEvPKjPj", !"cluster_dim_y", i32 1 }
!4 = !{ void (i64, i64)* @"_Z8mma_caseILj1188EEvPKjPj", !"cluster_dim_z", i32 1 }
!5 = !{ void (i64, i64)* @"_Z8mma_caseILj74896EEvPKjPj", !"kernel", i32 1 }
!6 = !{ void (i64, i64)* @"_Z8mma_caseILj74896EEvPKjPj", !"cluster_dim_x", i32 2 }
!7 = !{ void (i64, i64)* @"_Z8mma_caseILj74896EEvPKjPj", !"cluster_dim_y", i32 1 }
!8 = !{ void (i64, i64)* @"_Z8mma_caseILj74896EEvPKjPj", !"cluster_dim_z", i32 1 }
!9 = !{ void (i64, i64)* @"_Z8mma_caseILj65696EEvPKjPj", !"kernel", i32 1 }
!10 = !{ void (i64, i64)* @"_Z8mma_caseILj65696EEvPKjPj", !"cluster_dim_x", i32 2 }
!11 = !{ void (i64, i64)* @"_Z8mma_caseILj65696EEvPKjPj", !"cluster_dim_y", i32 1 }
!12 = !{ void (i64, i64)* @"_Z8mma_caseILj65696EEvPKjPj", !"cluster_dim_z", i32 1 }
!13 = !{ void (i64, i64)* @"_Z8mma_caseILj1184EEvPKjPj", !"kernel", i32 1 }
!14 = !{ void (i64, i64)* @"_Z8mma_caseILj1184EEvPKjPj", !"cluster_dim_x", i32 2 }
!15 = !{ void (i64, i64)* @"_Z8mma_caseILj1184EEvPKjPj", !"cluster_dim_y", i32 1 }
!16 = !{ void (i64, i64)* @"_Z8mma_caseILj1184EEvPKjPj", !"cluster_dim_z", i32 1 }
