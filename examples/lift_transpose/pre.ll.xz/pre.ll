; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../sweep_sb1/lifted/transpose_sm90_lifted.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../sweep_sb1/lifted/transpose_sm90_lifted.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16
@const_mem = global [5 x [552 x i8]] zeroinitializer, align 16

define void @_Z15transpose_naivePfPKfii(i64 %arg_528, i64 %arg_536, i32 %arg_544, i32 %arg_548) {
EntryBB_0000:
  %param_local = alloca [560 x i8], align 16
  %.6 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 528
  store i64 %arg_528, ptr %.6, align 16
  %.9 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 536
  store i64 %arg_536, ptr %.9, align 8
  %.12 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 544
  store i32 %arg_544, ptr %.12, align 32
  %.15 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 548
  store i32 %arg_548, ptr %.15, align 4
  %ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %s2ur_ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %ldc_const = load i64, ptr %.12, align 8
  %"UR7:UR6_r0" = trunc i64 %ldc_const to i32
  %"UR7:UR6_r1_shift" = lshr i64 %ldc_const, 32
  %"UR7:UR6_r1" = trunc i64 %"UR7:UR6_r1_shift" to i32
  %tid_y = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %ntid_x = call i32 @llvm.nvvm.read.ptx.sreg.ntid.x()
  %ntid_y = call i32 @llvm.nvvm.read.ptx.sreg.ntid.y()
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %imad_tmp = mul i32 %ctaid_y, %ntid_y
  %imad = add i32 %imad_tmp, %tid_y
  %isetrp_cmp1 = icmp sge i32 %imad, %"UR7:UR6_r1"
  %imad_tmp.1 = mul i32 %ntid_x, %s2ur_ctaid_x
  %imad.1 = add i32 %imad_tmp.1, %tid_x
  %isetrp_cmp1.1 = icmp sge i32 %imad.1, %"UR7:UR6_r0"
  %isetrp_cmp2.1 = or i1 %isetrp_cmp1.1, %isetrp_cmp1
  br label %BB_00c0

BB_00c0:                                          ; preds = %EntryBB_0000
  %0 = zext i1 %isetrp_cmp2.1 to i32
  %1 = icmp ne i32 %0, 0
  br i1 %1, label %BB_800000c0, label %BB_00d0

BB_00d0:                                          ; preds = %BB_00c0
  %ldc_const.1 = load i64, ptr %.9, align 8
  %imad_tmp.2 = mul i32 %imad, %"UR7:UR6_r0"
  %imad.2 = add i32 %imad_tmp.2, %imad.1
  %imad_lhs_64 = sext i32 %imad.2 to i64
  %imad_tmp_64 = mul i64 %imad_lhs_64, 4
  %2 = add i64 %imad_tmp_64, %ldc_const.1
  %ldc_const.2 = load i64, ptr %.6, align 8
  %"R8:R5_addr_ptr" = inttoptr i64 %2 to ptr addrspace(1)
  %ldg = load i32, ptr addrspace(1) %"R8:R5_addr_ptr", align 4
  %imad_tmp.3 = mul i32 %imad.1, %"UR7:UR6_r1"
  %imad.4 = add i32 %imad_tmp.3, %imad
  %imad_lhs_64.1 = sext i32 %imad.4 to i64
  %imad_tmp_64.1 = mul i64 %imad_lhs_64.1, 4
  %3 = add i64 %imad_tmp_64.1, %ldc_const.2
  %"R14:R10_addr_ptr" = inttoptr i64 %3 to ptr addrspace(1)
  store i32 %ldg, ptr addrspace(1) %"R14:R10_addr_ptr", align 4
  ret void

BB_800000c0:                                      ; preds = %BB_00c0
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z15transpose_naivePfPKfii, !"kernel", i32 1}
