; ModuleID = "raw"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [1040 x i8], align 16
define void @"dsm"(i64 %"arg_528")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [544 x i8], align 16
  %".3" = getelementptr inbounds [544 x i8], [544 x i8]* %"param_local", i64 0, i64 528
  %".4" = bitcast i8* %".3" to i64*
  store i64 %"arg_528", i64* %".4", align 16
  %"ldc_const" = call i32 asm  "{ .reg .pred p; mov.pred p, %is_explicit_cluster; selp.u32 $0, 1, 0, p; }", "=r"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  %"prmt_a64" = zext i32 %"s2ur_cluster_ctarank" to i64
  %"prmt_b64" = zext i32 1024 to i64
  %"prmt_bsh" = shl i64 %"prmt_b64", 32
  %"prmt_src8" = or i64 %"prmt_a64", %"prmt_bsh"
  %"prmt_nib0_sh" = lshr i32 1620, 0
  %"prmt_idx0" = and i32 %"prmt_nib0_sh", 7
  %"prmt_sign0" = and i32 %"prmt_nib0_sh", 8
  %"prmt_idx0_64" = zext i32 %"prmt_idx0" to i64
  %"prmt_bsh0" = shl i64 %"prmt_idx0_64", 3
  %"prmt_ext0" = lshr i64 %"prmt_src8", %"prmt_bsh0"
  %"prmt_byte0" = trunc i64 %"prmt_ext0" to i8
  %"prmt_hassign0" = icmp ne i32 %"prmt_sign0", 0
  %"prmt_zext0" = zext i8 %"prmt_byte0" to i32
  %"prmt_sfill0" = ashr i8 %"prmt_byte0", 7
  %"prmt_sfill32_0" = zext i8 %"prmt_sfill0" to i32
  %"prmt_smask0" = and i32 %"prmt_sfill32_0", 255
  %"prmt_sel0" = select  i1 %"prmt_hassign0", i32 %"prmt_smask0", i32 %"prmt_zext0"
  %"prmt_place0" = shl i32 %"prmt_sel0", 0
  %"prmt_res0" = or i32 0, %"prmt_place0"
  %"prmt_nib1_sh" = lshr i32 1620, 4
  %"prmt_idx1" = and i32 %"prmt_nib1_sh", 7
  %"prmt_sign1" = and i32 %"prmt_nib1_sh", 8
  %"prmt_idx1_64" = zext i32 %"prmt_idx1" to i64
  %"prmt_bsh1" = shl i64 %"prmt_idx1_64", 3
  %"prmt_ext1" = lshr i64 %"prmt_src8", %"prmt_bsh1"
  %"prmt_byte1" = trunc i64 %"prmt_ext1" to i8
  %"prmt_hassign1" = icmp ne i32 %"prmt_sign1", 0
  %"prmt_zext1" = zext i8 %"prmt_byte1" to i32
  %"prmt_sfill1" = ashr i8 %"prmt_byte1", 7
  %"prmt_sfill32_1" = zext i8 %"prmt_sfill1" to i32
  %"prmt_smask1" = and i32 %"prmt_sfill32_1", 255
  %"prmt_sel1" = select  i1 %"prmt_hassign1", i32 %"prmt_smask1", i32 %"prmt_zext1"
  %"prmt_place1" = shl i32 %"prmt_sel1", 8
  %"prmt_res1" = or i32 %"prmt_res0", %"prmt_place1"
  %"prmt_nib2_sh" = lshr i32 1620, 8
  %"prmt_idx2" = and i32 %"prmt_nib2_sh", 7
  %"prmt_sign2" = and i32 %"prmt_nib2_sh", 8
  %"prmt_idx2_64" = zext i32 %"prmt_idx2" to i64
  %"prmt_bsh2" = shl i64 %"prmt_idx2_64", 3
  %"prmt_ext2" = lshr i64 %"prmt_src8", %"prmt_bsh2"
  %"prmt_byte2" = trunc i64 %"prmt_ext2" to i8
  %"prmt_hassign2" = icmp ne i32 %"prmt_sign2", 0
  %"prmt_zext2" = zext i8 %"prmt_byte2" to i32
  %"prmt_sfill2" = ashr i8 %"prmt_byte2", 7
  %"prmt_sfill32_2" = zext i8 %"prmt_sfill2" to i32
  %"prmt_smask2" = and i32 %"prmt_sfill32_2", 255
  %"prmt_sel2" = select  i1 %"prmt_hassign2", i32 %"prmt_smask2", i32 %"prmt_zext2"
  %"prmt_place2" = shl i32 %"prmt_sel2", 16
  %"prmt_res2" = or i32 %"prmt_res1", %"prmt_place2"
  %"prmt_nib3_sh" = lshr i32 1620, 12
  %"prmt_idx3" = and i32 %"prmt_nib3_sh", 7
  %"prmt_sign3" = and i32 %"prmt_nib3_sh", 8
  %"prmt_idx3_64" = zext i32 %"prmt_idx3" to i64
  %"prmt_bsh3" = shl i64 %"prmt_idx3_64", 3
  %"prmt_ext3" = lshr i64 %"prmt_src8", %"prmt_bsh3"
  %"prmt_byte3" = trunc i64 %"prmt_ext3" to i8
  %"prmt_hassign3" = icmp ne i32 %"prmt_sign3", 0
  %"prmt_zext3" = zext i8 %"prmt_byte3" to i32
  %"prmt_sfill3" = ashr i8 %"prmt_byte3", 7
  %"prmt_sfill32_3" = zext i8 %"prmt_sfill3" to i32
  %"prmt_smask3" = and i32 %"prmt_sfill32_3", 255
  %"prmt_sel3" = select  i1 %"prmt_hassign3", i32 %"prmt_smask3", i32 %"prmt_zext3"
  %"prmt_place3" = shl i32 %"prmt_sel3", 24
  %"prmt_res3" = or i32 %"prmt_res2", %"prmt_place3"
  %"isetrp_cmp1" = icmp eq i32 %"ldc_const", 1
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"iadd3_n1" = add i32 %"ctaid_x", 40
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"sts_shared_addr_winoff" = and i32 %"prmt_res3", 16777215
  %".6" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".6" to i32 addrspace(3)*
  store volatile i32 %"iadd3_n2", i32 addrspace(3)* %"sts_shared_addr_cast"
  br label %"BB_00a0"
BB_00a0:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0120", label %"BB_00b0"
BB_00b0:
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  br label %"BB_0120"
BB_0120:
  %"cond_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0160", label %"BB_0130"
BB_0130:
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0170"
BB_0160:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0170"
BB_0170:
  %"s2ur_swin_sm_i8" = bitcast [1040 x i8] addrspace(3)* @"shared_mem" to i8 addrspace(3)*
  %"s2ur_swin_gen" = addrspacecast i8 addrspace(3)* %"s2ur_swin_sm_i8" to i8*
  %"s2ur_swin_base" = ptrtoint i8* %"s2ur_swin_gen" to i64
  %"s2ur_swin_hi_shr" = lshr i64 %"s2ur_swin_base", 32
  %"s2ur_swin" = trunc i64 %"s2ur_swin_hi_shr" to i32
  %"s2ur_swin.1" = call i32 @"__culifter_shared_window_hi"(i32 %"s2ur_swin")
  %".16" = xor i32 %"s2ur_cluster_ctarank", -1
  %".17" = xor i32 1, -1
  %".18" = xor i32 0, -1
  %".19" = and i32 %".16", 1
  %".20" = and i32 %".19", %".18"
  %".21" = and i32 %".16", 1
  %".22" = and i32 %".21", 0
  %".23" = or i32 %".20", %".22"
  %".24" = and i32 %"s2ur_cluster_ctarank", %".17"
  %".25" = and i32 %".24", %".18"
  %".26" = or i32 %".23", %".25"
  %".27" = and i32 %"s2ur_cluster_ctarank", %".17"
  %".28" = and i32 %".27", 0
  %".29" = or i32 %".26", %".28"
  %"prmt_a64.1" = zext i32 %".29" to i64
  %"prmt_b64.1" = zext i32 %"prmt_res3" to i64
  %"prmt_bsh.1" = shl i64 %"prmt_b64.1", 32
  %"prmt_src8.1" = or i64 %"prmt_a64.1", %"prmt_bsh.1"
  %"prmt_nib0_sh.1" = lshr i32 1620, 0
  %"prmt_idx0.1" = and i32 %"prmt_nib0_sh.1", 7
  %"prmt_sign0.1" = and i32 %"prmt_nib0_sh.1", 8
  %"prmt_idx0_64.1" = zext i32 %"prmt_idx0.1" to i64
  %"prmt_bsh0.1" = shl i64 %"prmt_idx0_64.1", 3
  %"prmt_ext0.1" = lshr i64 %"prmt_src8.1", %"prmt_bsh0.1"
  %"prmt_byte0.1" = trunc i64 %"prmt_ext0.1" to i8
  %"prmt_hassign0.1" = icmp ne i32 %"prmt_sign0.1", 0
  %"prmt_zext0.1" = zext i8 %"prmt_byte0.1" to i32
  %"prmt_sfill0.1" = ashr i8 %"prmt_byte0.1", 7
  %"prmt_sfill32_0.1" = zext i8 %"prmt_sfill0.1" to i32
  %"prmt_smask0.1" = and i32 %"prmt_sfill32_0.1", 255
  %"prmt_sel0.1" = select  i1 %"prmt_hassign0.1", i32 %"prmt_smask0.1", i32 %"prmt_zext0.1"
  %"prmt_place0.1" = shl i32 %"prmt_sel0.1", 0
  %"prmt_res0.1" = or i32 0, %"prmt_place0.1"
  %"prmt_nib1_sh.1" = lshr i32 1620, 4
  %"prmt_idx1.1" = and i32 %"prmt_nib1_sh.1", 7
  %"prmt_sign1.1" = and i32 %"prmt_nib1_sh.1", 8
  %"prmt_idx1_64.1" = zext i32 %"prmt_idx1.1" to i64
  %"prmt_bsh1.1" = shl i64 %"prmt_idx1_64.1", 3
  %"prmt_ext1.1" = lshr i64 %"prmt_src8.1", %"prmt_bsh1.1"
  %"prmt_byte1.1" = trunc i64 %"prmt_ext1.1" to i8
  %"prmt_hassign1.1" = icmp ne i32 %"prmt_sign1.1", 0
  %"prmt_zext1.1" = zext i8 %"prmt_byte1.1" to i32
  %"prmt_sfill1.1" = ashr i8 %"prmt_byte1.1", 7
  %"prmt_sfill32_1.1" = zext i8 %"prmt_sfill1.1" to i32
  %"prmt_smask1.1" = and i32 %"prmt_sfill32_1.1", 255
  %"prmt_sel1.1" = select  i1 %"prmt_hassign1.1", i32 %"prmt_smask1.1", i32 %"prmt_zext1.1"
  %"prmt_place1.1" = shl i32 %"prmt_sel1.1", 8
  %"prmt_res1.1" = or i32 %"prmt_res0.1", %"prmt_place1.1"
  %"prmt_nib2_sh.1" = lshr i32 1620, 8
  %"prmt_idx2.1" = and i32 %"prmt_nib2_sh.1", 7
  %"prmt_sign2.1" = and i32 %"prmt_nib2_sh.1", 8
  %"prmt_idx2_64.1" = zext i32 %"prmt_idx2.1" to i64
  %"prmt_bsh2.1" = shl i64 %"prmt_idx2_64.1", 3
  %"prmt_ext2.1" = lshr i64 %"prmt_src8.1", %"prmt_bsh2.1"
  %"prmt_byte2.1" = trunc i64 %"prmt_ext2.1" to i8
  %"prmt_hassign2.1" = icmp ne i32 %"prmt_sign2.1", 0
  %"prmt_zext2.1" = zext i8 %"prmt_byte2.1" to i32
  %"prmt_sfill2.1" = ashr i8 %"prmt_byte2.1", 7
  %"prmt_sfill32_2.1" = zext i8 %"prmt_sfill2.1" to i32
  %"prmt_smask2.1" = and i32 %"prmt_sfill32_2.1", 255
  %"prmt_sel2.1" = select  i1 %"prmt_hassign2.1", i32 %"prmt_smask2.1", i32 %"prmt_zext2.1"
  %"prmt_place2.1" = shl i32 %"prmt_sel2.1", 16
  %"prmt_res2.1" = or i32 %"prmt_res1.1", %"prmt_place2.1"
  %"prmt_nib3_sh.1" = lshr i32 1620, 12
  %"prmt_idx3.1" = and i32 %"prmt_nib3_sh.1", 7
  %"prmt_sign3.1" = and i32 %"prmt_nib3_sh.1", 8
  %"prmt_idx3_64.1" = zext i32 %"prmt_idx3.1" to i64
  %"prmt_bsh3.1" = shl i64 %"prmt_idx3_64.1", 3
  %"prmt_ext3.1" = lshr i64 %"prmt_src8.1", %"prmt_bsh3.1"
  %"prmt_byte3.1" = trunc i64 %"prmt_ext3.1" to i8
  %"prmt_hassign3.1" = icmp ne i32 %"prmt_sign3.1", 0
  %"prmt_zext3.1" = zext i8 %"prmt_byte3.1" to i32
  %"prmt_sfill3.1" = ashr i8 %"prmt_byte3.1", 7
  %"prmt_sfill32_3.1" = zext i8 %"prmt_sfill3.1" to i32
  %"prmt_smask3.1" = and i32 %"prmt_sfill32_3.1", 255
  %"prmt_sel3.1" = select  i1 %"prmt_hassign3.1", i32 %"prmt_smask3.1", i32 %"prmt_zext3.1"
  %"prmt_place3.1" = shl i32 %"prmt_sel3.1", 24
  %"prmt_res3.1" = or i32 %"prmt_res2.1", %"prmt_place3.1"
  %"iadd_lhs_r0_ext" = zext i32 0 to i64
  %"iadd_lhs_packed_0" = or i64 0, %"iadd_lhs_r0_ext"
  %"iadd_lhs_r1_ext" = zext i32 0 to i64
  %"iadd_lhs_r1_shift" = shl i64 %"iadd_lhs_r1_ext", 32
  %"iadd_lhs_packed_1" = or i64 %"iadd_lhs_packed_0", %"iadd_lhs_r1_shift"
  %"iadd_rhs_r0_ext" = zext i32 %"prmt_res3.1" to i64
  %"iadd_rhs_packed_0" = or i64 0, %"iadd_rhs_r0_ext"
  %"iadd_rhs_r1_ext" = zext i32 %"s2ur_swin.1" to i64
  %"iadd_rhs_r1_shift" = shl i64 %"iadd_rhs_r1_ext", 32
  %"iadd_rhs_packed_1" = or i64 %"iadd_rhs_packed_0", %"iadd_rhs_r1_shift"
  %"iadd" = add i64 %"iadd_lhs_packed_1", %"iadd_rhs_packed_1"
  %"RZ_idx64h_1:RZ_idx64_1_r0" = trunc i64 %"iadd" to i32
  %"RZ_idx64h_1:RZ_idx64_1_r1_shift" = lshr i64 %"iadd", 32
  %"RZ_idx64h_1:RZ_idx64_1_r1" = trunc i64 %"RZ_idx64h_1:RZ_idx64_1_r1_shift" to i32
  %"ldg_addr_r0_ext" = zext i32 %"RZ_idx64h_1:RZ_idx64_1_r0" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"RZ_idx64h_1:RZ_idx64_1_r1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %".30" = bitcast [1040 x i8] addrspace(3)* @"shared_mem" to i8 addrspace(3)*
  %".31" = addrspacecast i8 addrspace(3)* %".30" to i8*
  %"R7:R5_addr_ptr" = call i64 @"__culifter_shared_window_resolve"(i64 %"ldg_addr_packed_1", i8* %".31", i64 0)
  %"R7:R5_addr_ptr.1" = inttoptr i64 %"R7:R5_addr_ptr" to i32*
  %"ldg" = load i32, i32* %"R7:R5_addr_ptr.1"
  %"iadd_lhs_r0_ext.1" = zext i32 0 to i64
  %"iadd_lhs_packed_0.1" = or i64 0, %"iadd_lhs_r0_ext.1"
  %"iadd_lhs_r1_ext.1" = zext i32 0 to i64
  %"iadd_lhs_r1_shift.1" = shl i64 %"iadd_lhs_r1_ext.1", 32
  %"iadd_lhs_packed_1.1" = or i64 %"iadd_lhs_packed_0.1", %"iadd_lhs_r1_shift.1"
  %"iadd_rhs_r0_ext.1" = zext i32 %"prmt_res3.1" to i64
  %"iadd_rhs_packed_0.1" = or i64 0, %"iadd_rhs_r0_ext.1"
  %"iadd_rhs_r1_ext.1" = zext i32 %"s2ur_swin.1" to i64
  %"iadd_rhs_r1_shift.1" = shl i64 %"iadd_rhs_r1_ext.1", 32
  %"iadd_rhs_packed_1.1" = or i64 %"iadd_rhs_packed_0.1", %"iadd_rhs_r1_shift.1"
  %"iadd.1" = add i64 %"iadd_lhs_packed_1.1", %"iadd_rhs_packed_1.1"
  %"RZ_idx64h_2:RZ_idx64_2_r0" = trunc i64 %"iadd.1" to i32
  %"RZ_idx64h_2:RZ_idx64_2_r1_shift" = lshr i64 %"iadd.1", 32
  %"RZ_idx64h_2:RZ_idx64_2_r1" = trunc i64 %"RZ_idx64h_2:RZ_idx64_2_r1_shift" to i32
  %"stg_addr_r0_ext" = zext i32 %"RZ_idx64h_2:RZ_idx64_2_r0" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"RZ_idx64h_2:RZ_idx64_2_r1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1", 4
  %".32" = bitcast [1040 x i8] addrspace(3)* @"shared_mem" to i8 addrspace(3)*
  %".33" = addrspacecast i8 addrspace(3)* %".32" to i8*
  %"R8:R6_addr_ptr" = call i64 @"__culifter_shared_window_resolve"(i64 %"stg_addr_memaddr_offset_add", i8* %".33", i64 0)
  %"R8:R6_addr_ptr.1" = inttoptr i64 %"R8:R6_addr_ptr" to i32*
  store i32 %"iadd3_n2", i32* %"R8:R6_addr_ptr.1"
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0240", label %"BB_01d0"
BB_01d0:
  call void @"llvm.nvvm.membar.cta"()
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  br label %"BB_0240"
BB_0240:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_0280", label %"BB_0250"
BB_0250:
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0290"
BB_0280:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0290"
BB_0290:
  %"lds_addr_memaddr_offset_add" = add i32 %"prmt_res3", 4
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".43" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".43" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".44" = getelementptr inbounds [544 x i8], [544 x i8]* %"param_local", i64 0, i64 528
  %".45" = bitcast i8* %".44" to i64*
  %"ldc_const.1" = load i64, i64* %".45"
  %"R3:R2_r0" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"ctaid_x" to i64
  %"imad_rhs_64" = zext i32 8 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_val_r0_ext" = zext i32 %"ldg" to i64
  %"stg_val_packed_0" = or i64 0, %"stg_val_r0_ext"
  %"stg_val_r1_ext" = zext i32 %"lds" to i64
  %"stg_val_r1_shift" = shl i64 %"stg_val_r1_ext", 32
  %"stg_val_packed_1" = or i64 %"stg_val_packed_0", %"stg_val_r1_shift"
  %"R2:R17_addr_ptr" = inttoptr i64 %"stg_addr_packed_1.1" to i64 addrspace(1)*
  store i64 %"stg_val_packed_1", i64 addrspace(1)* %"R2:R17_addr_ptr"
  ret void
}

@"const_mem" = global [5 x [536 x i8]] [[536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare void @"llvm.nvvm.membar.cta"()

declare void @"llvm.nvvm.membar.gl"()

declare void @"llvm.nvvm.barrier0"()

define internal i32 @"__culifter_shared_window_hi"(i32 %".1") noinline
{
entry:
  ret i32 %".1"
}

define internal i64 @"__culifter_shared_window_resolve"(i64 %".1", i8* %".2", i64 %".3") noinline
{
entry:
  %".5" = ptrtoint i8* %".2" to i64
  %".6" = lshr i64 %".1", 32
  %".7" = lshr i64 %".5", 32
  %".8" = icmp eq i64 %".6", %".7"
  %".9" = and i64 %".5", 16777215
  %".10" = sub i64 %".9", %".3"
  %".11" = add i64 %".1", %".10"
  %".12" = select  i1 %".8", i64 %".11", i64 %".1"
  ret i64 %".12"
}

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64)* @"dsm", !"kernel", i32 1 }
