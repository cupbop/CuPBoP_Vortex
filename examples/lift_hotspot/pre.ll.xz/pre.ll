; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/hotspot.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../lift2vortex/ir_cross_sm/raw/hotspot.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [3072 x i8], align 16
@const_mem = internal global [5 x [392 x i8]] [[392 x i8] zeroinitializer, [392 x i8] zeroinitializer, [392 x i8] c"\FF\FF\FF\01\00\00\80\BF\FF\FF\FF\7F\00\00\80?\00\00\00\80\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", [392 x i8] zeroinitializer, [392 x i8] zeroinitializer], align 16

define void @_Z14calculate_tempiPfS_S_iiiiffffff(i32 %arg_320, i64 %arg_328, i64 %arg_336, i64 %arg_344, i32 %arg_352, i32 %arg_356, i32 %arg_360, i32 %arg_364, i32 %arg_368, i32 %arg_372, i32 %arg_376, i32 %arg_380, i32 %arg_384, i32 %arg_388) {
EntryBB_0000:
  %param_local = alloca [400 x i8], align 16
  %.16 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 320
  store i32 %arg_320, ptr %.16, align 64
  %.19 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 328
  store i64 %arg_328, ptr %.19, align 8
  %.22 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 336
  store i64 %arg_336, ptr %.22, align 16
  %.25 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 344
  store i64 %arg_344, ptr %.25, align 8
  %.28 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 352
  store i32 %arg_352, ptr %.28, align 32
  %.31 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 356
  store i32 %arg_356, ptr %.31, align 4
  %.34 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 360
  store i32 %arg_360, ptr %.34, align 8
  %.37 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 364
  store i32 %arg_364, ptr %.37, align 4
  %.40 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 368
  store i32 %arg_368, ptr %.40, align 16
  %.43 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 372
  store i32 %arg_372, ptr %.43, align 4
  %.46 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 376
  store i32 %arg_376, ptr %.46, align 8
  %.49 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 380
  store i32 %arg_380, ptr %.49, align 4
  %.52 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 384
  store i32 %arg_384, ptr %.52, align 128
  %.55 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 388
  store i32 %arg_388, ptr %.55, align 4
  %legacy_entry_mask = call i32 @llvm.nvvm.vote.ballot.sync(i32 -1, i1 true)
  %mov = load i32, ptr %.16, align 4
  %ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %legacy_b = load i32, ptr %.37, align 4
  %legacy_b_wide = zext i32 %legacy_b to i64
  %legacy_b_complement = xor i64 %legacy_b_wide, 4294967295
  %legacy_b_negate = add i64 %legacy_b_complement, 1
  %legacy_result = trunc i64 %legacy_b_negate to i32
  %ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %legacy_b.1 = load i32, ptr %.34, align 4
  %legacy_b_wide.1 = zext i32 %legacy_b.1 to i64
  %legacy_b_complement.1 = xor i64 %legacy_b_wide.1, 4294967295
  %legacy_b_negate.1 = add i64 %legacy_b_complement.1, 1
  %legacy_result.1 = trunc i64 %legacy_b_negate.1 to i32
  %tid_y = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %legacy_a_shift = shl i32 %mov, 1
  %legacy_a_wide.2 = zext i32 %legacy_a_shift to i64
  %legacy_a_complement = xor i64 %legacy_a_wide.2, 4294967295
  %legacy_a_negate = add i64 %legacy_a_complement, 1
  %legacy_sum.2 = add i64 %legacy_a_negate, 16
  %legacy_result.2 = trunc i64 %legacy_sum.2 to i32
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %.64 = trunc i32 %legacy_result.2 to i16
  %.65 = zext i16 %.64 to i32
  %.66 = trunc i32 %ctaid_y to i16
  %.67 = zext i16 %.66 to i32
  %xmad_product = mul i32 %.65, %.67
  %xmad_sum = add i32 %xmad_product, %legacy_result
  %.70 = lshr i32 %ctaid_y, 16
  %.71 = trunc i32 %.70 to i16
  %.72 = zext i16 %.71 to i32
  %xmad_product.1 = mul i32 %.65, %.72
  %.73 = and i32 %xmad_product.1, 65535
  %.74 = shl i32 %ctaid_y, 16
  %xmad_merge = or i32 %.73, %.74
  %.77 = trunc i32 %ctaid_x to i16
  %.78 = zext i16 %.77 to i32
  %xmad_product.2 = mul i32 %.65, %.78
  %xmad_sum.2 = add i32 %xmad_product.2, %legacy_result.1
  %.81 = lshr i32 %ctaid_x, 16
  %.82 = trunc i32 %.81 to i16
  %.83 = zext i16 %.82 to i32
  %xmad_product.3 = mul i32 %.65, %.83
  %.84 = and i32 %xmad_product.3, 65535
  %.85 = shl i32 %ctaid_x, 16
  %xmad_merge.1 = or i32 %.84, %.85
  %.86 = lshr i32 %legacy_result.2, 16
  %.87 = trunc i32 %.86 to i16
  %.88 = zext i16 %.87 to i32
  %.89 = lshr i32 %xmad_merge, 16
  %.90 = trunc i32 %.89 to i16
  %.91 = zext i16 %.90 to i32
  %xmad_product.4 = mul i32 %.88, %.91
  %xmad_psl = shl i32 %xmad_product.4, 16
  %.92 = shl i32 %xmad_merge, 16
  %xmad_cbcc = add i32 %xmad_sum, %.92
  %xmad_sum.4 = add i32 %xmad_psl, %xmad_cbcc
  %.96 = lshr i32 %xmad_merge.1, 16
  %.97 = trunc i32 %.96 to i16
  %.98 = zext i16 %.97 to i32
  %xmad_product.5 = mul i32 %.88, %.98
  %xmad_psl.1 = shl i32 %xmad_product.5, 16
  %.99 = shl i32 %xmad_merge.1, 16
  %xmad_cbcc.1 = add i32 %xmad_sum.2, %.99
  %xmad_sum.5 = add i32 %xmad_psl.1, %xmad_cbcc.1
  %legacy_a_wide.3 = zext i32 %xmad_sum.4 to i64
  %legacy_b_wide.3 = zext i32 %tid_y to i64
  %legacy_sum.3 = add i64 %legacy_a_wide.3, %legacy_b_wide.3
  %legacy_result.3 = trunc i64 %legacy_sum.3 to i32
  %legacy_a_wide.4 = zext i32 %xmad_sum.5 to i64
  %legacy_b_wide.4 = zext i32 %tid_x to i64
  %legacy_sum.4 = add i64 %legacy_a_wide.4, %legacy_b_wide.4
  %legacy_result.4 = trunc i64 %legacy_sum.4 to i32
  %isetrp_rhs = load i32, ptr %.31, align 4
  %isetrp_cmp1 = icmp sge i32 %legacy_result.3, %isetrp_rhs
  %xmad_src1 = load i32, ptr %.28, align 4
  %.104 = trunc i32 %legacy_result.3 to i16
  %.105 = zext i16 %.104 to i32
  %.106 = lshr i32 %xmad_src1, 16
  %.107 = trunc i32 %.106 to i16
  %.108 = zext i16 %.107 to i32
  %xmad_product.6 = mul i32 %.105, %.108
  %.109 = and i32 %xmad_product.6, 65535
  %.110 = shl i32 %xmad_src1, 16
  %xmad_merge.2 = or i32 %.109, %.110
  %isetrp_cmp1.1 = icmp sge i32 %legacy_result.4, %xmad_src1
  %isetrp_src_not = xor i1 %isetrp_cmp1, true
  %isetrp_cmp1.2 = icmp sgt i32 %legacy_result.3, -1
  %isetrp_cmp2.2 = and i1 %isetrp_cmp1.2, %isetrp_src_not
  %isetrp_src_not.1 = xor i1 %isetrp_cmp1.1, true
  %isetrp_cmp1.3 = icmp sgt i32 %legacy_result.4, -1
  %isetrp_cmp2.3 = and i1 %isetrp_cmp1.3, %isetrp_src_not.1
  %.117 = trunc i32 %xmad_src1 to i16
  %.118 = zext i16 %.117 to i32
  %xmad_product.7 = mul i32 %.105, %.118
  %xmad_sum.7 = add i32 %xmad_product.7, %legacy_result.4
  %.119 = lshr i32 %legacy_result.3, 16
  %.120 = trunc i32 %.119 to i16
  %.121 = zext i16 %.120 to i32
  %.122 = lshr i32 %xmad_merge.2, 16
  %.123 = trunc i32 %.122 to i16
  %.124 = zext i16 %.123 to i32
  %xmad_product.8 = mul i32 %.121, %.124
  %xmad_psl.2 = shl i32 %xmad_product.8, 16
  %.125 = shl i32 %xmad_merge.2, 16
  %xmad_cbcc.2 = add i32 %xmad_sum.7, %.125
  %xmad_sum.8 = add i32 %xmad_psl.2, %xmad_cbcc.2
  %.126 = and i1 %isetrp_cmp2.3, %isetrp_cmp2.2
  br label %BB_00d0

BB_00d0:                                          ; preds = %EntryBB_0000
  %0 = zext i1 %.126 to i32
  %1 = icmp ne i32 %0, 0
  br i1 %1, label %BB_800000d0, label %BB_0110

BB_800000d0:                                      ; preds = %BB_00d0
  %shl = shl i32 %xmad_sum.8, 2
  %shr_result = ashr i32 %xmad_sum.8, 30
  %legacy_b.2 = load i32, ptr %.22, align 4
  %.135 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 340
  %legacy_b.3 = load i32, ptr %.135, align 4
  %2 = zext i32 %shl to i64
  %3 = zext i32 %legacy_b.2 to i64
  %4 = zext i32 %shr_result to i64
  %5 = shl i64 %4, 32
  %6 = zext i32 %legacy_b.3 to i64
  %7 = shl i64 %6, 32
  %8 = add i64 %2, %3
  %9 = add i64 %8, %5
  %10 = add i64 %9, %7
  %legacy_b.4 = load i32, ptr %.19, align 4
  %"R213:R165_addr_ptr" = inttoptr i64 %10 to ptr addrspace(1)
  %ldg = load i32, ptr addrspace(1) %"R213:R165_addr_ptr", align 4
  %.141 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 332
  %legacy_b.5 = load i32, ptr %.141, align 4
  %11 = zext i32 %shl to i64
  %12 = zext i32 %legacy_b.4 to i64
  %13 = zext i32 %shr_result to i64
  %14 = shl i64 %13, 32
  %15 = zext i32 %legacy_b.5 to i64
  %16 = shl i64 %15, 32
  %17 = add i64 %11, %12
  %18 = add i64 %17, %14
  %19 = add i64 %18, %16
  %"R136:R70_addr_ptr" = inttoptr i64 %19 to ptr addrspace(1)
  %ldg.1 = load i32, ptr addrspace(1) %"R136:R70_addr_ptr", align 4
  br label %BB_0110

BB_0110:                                          ; preds = %BB_800000d0, %BB_00d0
  %phi = phi i32 [ %ldg, %BB_800000d0 ], [ %xmad_merge.2, %BB_00d0 ]
  %phi.1 = phi i32 [ %ldg.1, %BB_800000d0 ], [ 0, %BB_00d0 ]
  %isetrp_cmp1.4 = icmp sge i32 %mov, 1
  %shl.1 = shl i32 %tid_y, 6
  %shl.2 = shl i32 %tid_x, 2
  %legacy_a_wide.9 = zext i32 %shl.1 to i64
  %legacy_b_wide.9 = zext i32 %shl.2 to i64
  %legacy_sum.9 = add i64 %legacy_a_wide.9, %legacy_b_wide.9
  %legacy_result.9 = trunc i64 %legacy_sum.9 to i32
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0138

BB_0138:                                          ; preds = %BB_0110
  %20 = zext i1 %.126 to i32
  %21 = icmp ne i32 %20, 0
  br i1 %21, label %BB_80000138, label %BB_0140

BB_80000138:                                      ; preds = %BB_0138
  %sts_shared_addr_winoff = and i32 %legacy_result.9, 16777215
  %.147 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_shared_addr_winoff
  store volatile i32 %phi, ptr addrspace(3) %.147, align 4
  br label %BB_0140

BB_0140:                                          ; preds = %BB_80000138, %BB_0138
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  br label %BB_0150

BB_0150:                                          ; preds = %BB_0140
  %22 = zext i1 %.126 to i32
  %23 = icmp ne i32 %22, 0
  br i1 %23, label %BB_80000150, label %BB_0158

BB_80000150:                                      ; preds = %BB_0150
  %sts_addr_memaddr_offset_add = add i32 %legacy_result.9, 1024
  %sts_shared_addr_winoff.1 = and i32 %sts_addr_memaddr_offset_add, 16777215
  %.152 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_shared_addr_winoff.1
  store volatile i32 %phi.1, ptr addrspace(3) %.152, align 4
  br label %BB_0158

BB_0158:                                          ; preds = %BB_80000150, %BB_0150
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_entry_mask)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %legacy_branch_predicate_not = xor i1 %isetrp_cmp1.4, true
  %legacy_taken_mask = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_entry_mask, i1 %legacy_branch_predicate_not)
  %.155 = xor i32 %legacy_taken_mask, -1
  %legacy_fallthrough_mask = and i32 %legacy_entry_mask, %.155
  %legacy_path_mask = select i1 %legacy_branch_predicate_not, i32 %legacy_taken_mask, i32 %legacy_fallthrough_mask
  br label %BB_0178

BB_0178:                                          ; preds = %BB_0158
  %24 = zext i1 %legacy_branch_predicate_not to i32
  %25 = icmp ne i32 %24, 0
  br i1 %25, label %BB_0728, label %BB_0180

BB_0180:                                          ; preds = %BB_0178
  %mov.1 = load float, ptr %.40, align 4
  %mufu_rcp = call float @llvm.nvvm.rcp.approx.ftz.f(float %mov.1)
  %legacy_sum.10 = add i64 %legacy_a_wide.3, 15
  %legacy_result.10 = trunc i64 %legacy_sum.10 to i32
  %legacy_a_complement.1 = xor i64 %legacy_a_wide.3, 4294967295
  %legacy_a_negate.1 = add i64 %legacy_a_complement.1, 1
  %legacy_result.11 = trunc i64 %legacy_a_negate.1 to i32
  %shr_result.1 = ashr i32 %xmad_sum.4, 31
  %legacy_sum.12 = add i64 %legacy_a_negate.1, 4294967281
  %legacy_result.12 = trunc i64 %legacy_sum.12 to i32
  %legacy_sum.13 = add i64 %legacy_a_wide.4, 15
  %legacy_result.13 = trunc i64 %legacy_sum.13 to i32
  %legacy_a_complement.3 = xor i64 %legacy_a_wide.4, 4294967295
  %legacy_a_negate.3 = add i64 %legacy_a_complement.3, 1
  %legacy_result.14 = trunc i64 %legacy_a_negate.3 to i32
  %isetrp_rhs.2 = load i32, ptr %.31, align 4
  %isetrp_cmp1.5 = icmp sge i32 %legacy_result.10, %isetrp_rhs.2
  %mov.2 = load float, ptr %.52, align 4
  %shr_result.2 = ashr i32 %xmad_sum.5, 31
  %legacy_sum.15 = add i64 %legacy_a_negate.3, 4294967281
  %legacy_result.15 = trunc i64 %legacy_sum.15 to i32
  %isetrp_rhs.3 = load i32, ptr %.28, align 4
  %isetrp_cmp1.6 = icmp sge i32 %legacy_result.13, %isetrp_rhs.3
  %legacy_a_wide.16 = zext i32 %legacy_result.12 to i64
  %legacy_b_wide.16 = zext i32 %isetrp_rhs.2 to i64
  %legacy_sum.16 = add i64 %legacy_a_wide.16, %legacy_b_wide.16
  %legacy_result.16 = trunc i64 %legacy_sum.16 to i32
  %ffma_rhs_fneg = fneg float %mov.1
  %ffma = call float @llvm.fma.f32(float %mufu_rcp, float %ffma_rhs_fneg, float 1.000000e+00)
  %fchk_num_bits = bitcast float %mov.2 to i32
  %fchk_den_bits = bitcast float %mov.1 to i32
  %fchk_aden = and i32 %fchk_den_bits, 2147483647
  %fchk_anum = and i32 %fchk_num_bits, 2147483647
  %fchk_den_subz = icmp ult i32 %fchk_aden, 8388608
  %fchk_den_infnan = icmp uge i32 %fchk_aden, 2139095040
  %fchk_num_infnan = icmp uge i32 %fchk_anum, 2139095040
  %fchk_den_bad = or i1 %fchk_den_subz, %fchk_den_infnan
  %fchk_px = or i1 %fchk_den_bad, %fchk_num_infnan
  %.172 = and i32 %shr_result.2, %legacy_result.14
  %legacy_a_wide.17 = zext i32 %legacy_result.15 to i64
  %legacy_b_wide.17 = zext i32 %isetrp_rhs.3 to i64
  %legacy_sum.17 = add i64 %legacy_a_wide.17, %legacy_b_wide.17
  %legacy_result.17 = trunc i64 %legacy_sum.17 to i32
  %.175 = and i32 %shr_result.1, %legacy_result.11
  %legacy_a_wide.18 = zext i32 %legacy_result.16 to i64
  %legacy_sum.18 = add i64 %legacy_a_wide.18, 14
  %legacy_result.18 = trunc i64 %legacy_sum.18 to i32
  %ffma.1 = call float @llvm.fma.f32(float %mufu_rcp, float %ffma, float %mufu_rcp)
  %legacy_sum.19 = add i64 %legacy_b_wide.3, 4294967295
  %legacy_result.19 = trunc i64 %legacy_sum.19 to i32
  %isetrp_cmp1.7 = icmp sge i32 %tid_x, %.172
  %legacy_a_wide.20 = zext i32 %legacy_result.17 to i64
  %legacy_sum.20 = add i64 %legacy_a_wide.20, 14
  %legacy_result.20 = trunc i64 %legacy_sum.20 to i32
  %legacy_sum.21 = add i64 %legacy_b_wide.3, 1
  %legacy_result.21 = trunc i64 %legacy_sum.21 to i32
  %sel = select i1 %isetrp_cmp1.5, i32 %legacy_result.18, i32 15
  %ffma.2 = call float @llvm.fma.f32(float %ffma.1, float %mov.2, float 0.000000e+00)
  %legacy_sum.22 = add i64 %legacy_b_wide.4, 4294967295
  %legacy_result.22 = trunc i64 %legacy_sum.22 to i32
  %legacy_sum.23 = add i64 %legacy_b_wide.4, 1
  %legacy_result.23 = trunc i64 %legacy_sum.23 to i32
  %sel.1 = select i1 %isetrp_cmp1.6, i32 %legacy_result.20, i32 15
  %ffma.3 = call float @llvm.fma.f32(float %ffma.2, float %ffma_rhs_fneg, float %mov.2)
  %ffma.4 = call float @llvm.fma.f32(float %ffma.1, float %ffma.3, float %ffma.2)
  %legacy_branch_predicate_not.1 = xor i1 %fchk_px, true
  %legacy_taken_mask.1 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask, i1 %legacy_branch_predicate_not.1)
  %.180 = xor i32 %legacy_taken_mask.1, -1
  %legacy_fallthrough_mask.1 = and i32 %legacy_path_mask, %.180
  %legacy_path_mask.1 = select i1 %legacy_branch_predicate_not.1, i32 %legacy_taken_mask.1, i32 %legacy_fallthrough_mask.1
  br label %BB_0298

BB_0298:                                          ; preds = %BB_0180
  %26 = zext i1 %legacy_branch_predicate_not.1 to i32
  %27 = icmp ne i32 %26, 0
  br i1 %27, label %BB_02c0, label %BB_02a8_0938

BB_02a8_0938:                                     ; preds = %BB_0298
  %mov.3 = load i32, ptr %.40, align 4
  %mov.4 = load i32, ptr %.52, align 4
  %.197 = zext i32 %mov.3 to i64
  %.200 = lshr i64 %.197, 23
  %.203 = and i64 %.200, 255
  %.204 = trunc i64 %.203 to i32
  %.211 = zext i32 %mov.4 to i64
  %.214 = lshr i64 %.211, 23
  %.217 = and i64 %.214, 255
  %.218 = trunc i64 %.217 to i32
  %legacy_a_wide.24 = zext i32 %.204 to i64
  %legacy_sum.24 = add i64 %legacy_a_wide.24, 4294967295
  %legacy_result.24 = trunc i64 %legacy_sum.24 to i32
  %legacy_a_wide.25 = zext i32 %.218 to i64
  %legacy_sum.25 = add i64 %legacy_a_wide.25, 4294967295
  %legacy_result.25 = trunc i64 %legacy_sum.25 to i32
  %isetrp_cmp1.8 = icmp ugt i32 %legacy_result.24, 253
  %isetrp_cmp1.9 = icmp ugt i32 %legacy_result.25, 253
  %isetrp_cmp2.9 = or i1 %isetrp_cmp1.9, %isetrp_cmp1.8
  br label %BB_02a8_0988

BB_02a8_0988:                                     ; preds = %BB_02a8_0938
  %cond_not.2 = xor i1 %isetrp_cmp2.9, true
  br i1 %cond_not.2, label %BB_02a8_80000988, label %BB_02a8_0990

BB_02a8_80000988:                                 ; preds = %BB_02a8_0988
  br label %BB_02a8_0990

BB_02a8_0990:                                     ; preds = %BB_02a8_80000988, %BB_02a8_0988
  %phi.2 = phi float [ 0.000000e+00, %BB_02a8_80000988 ], [ %ffma.4, %BB_02a8_0988 ]
  %legacy_taken_mask.2 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.1, i1 %cond_not.2)
  %.222 = xor i32 %legacy_taken_mask.2, -1
  %legacy_fallthrough_mask.2 = and i32 %legacy_path_mask.1, %.222
  %legacy_path_mask.2 = select i1 %cond_not.2, i32 %legacy_taken_mask.2, i32 %legacy_fallthrough_mask.2
  br label %BB_02a8_0998

BB_02a8_0998:                                     ; preds = %BB_02a8_0990
  %phi_cast_R195_bitcast = bitcast float %phi.2 to i32
  br i1 %cond_not.2, label %BB_02a8_0a98, label %BB_02a8_09a0

BB_02a8_09a0:                                     ; preds = %BB_02a8_0998
  %.226 = and i32 %mov.4, 2147483647
  %.227 = and i32 %.226, 2139095040
  %.228 = icmp eq i32 %.227, 0
  %.230 = select i1 %.228, i32 0, i32 %.226
  %.231 = bitcast i32 %.230 to float
  %.238 = fcmp ugt float %.231, 0x7FF0000000000000
  %.240 = select i1 %.238, i32 -1, i32 0
  %.242 = and i32 %mov.3, 2147483647
  %.243 = and i32 %.242, 2139095040
  %.244 = icmp eq i32 %.243, 0
  %.246 = select i1 %.244, i32 0, i32 %.242
  %.247 = bitcast i32 %.246 to float
  %.254 = fcmp ugt float %.247, 0x7FF0000000000000
  %.256 = select i1 %.254, i32 -1, i32 0
  %.257 = or i32 %.240, %.256
  %.258 = icmp ne i32 %.257, 0
  %legacy_taken_mask.3 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.2, i1 %.258)
  %.259 = xor i32 %legacy_taken_mask.3, -1
  %legacy_fallthrough_mask.3 = and i32 %legacy_path_mask.2, %.259
  %legacy_path_mask.3 = select i1 %.258, i32 %legacy_taken_mask.3, i32 %legacy_fallthrough_mask.3
  br label %BB_02a8_09c0

BB_02a8_09c0:                                     ; preds = %BB_02a8_09a0
  %28 = zext i1 %.258 to i32
  %29 = icmp ne i32 %28, 0
  br i1 %29, label %BB_02a8_0ca0, label %BB_02a8_09c8

BB_02a8_09c8:                                     ; preds = %BB_02a8_09c0
  %.262 = xor i32 %mov.3, -1
  %.263 = and i32 %.262, 2147483647
  %.264 = and i32 %.263, %mov.4
  %.266 = xor i32 %mov.4, -1
  %.268 = and i32 %.242, %.266
  %.269 = or i32 %.264, %.268
  %.271 = and i32 %.242, %mov.4
  %.272 = or i32 %.269, %.271
  %.273 = icmp ne i32 %.272, 0
  %legacy_branch_predicate_not.3 = xor i1 %.273, true
  %legacy_taken_mask.4 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.3, i1 %legacy_branch_predicate_not.3)
  %.274 = xor i32 %legacy_taken_mask.4, -1
  %legacy_fallthrough_mask.4 = and i32 %legacy_path_mask.3, %.274
  %legacy_path_mask.4 = select i1 %legacy_branch_predicate_not.3, i32 %legacy_taken_mask.4, i32 %legacy_fallthrough_mask.4
  br label %BB_02a8_09e0

BB_02a8_09e0:                                     ; preds = %BB_02a8_09c8
  %30 = zext i1 %legacy_branch_predicate_not.3 to i32
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %BB_02a8_0c88, label %BB_02a8_09e8

BB_02a8_09e8:                                     ; preds = %BB_02a8_09e0
  %.290 = fcmp une float %.231, 0x7FF0000000000000
  %.292 = select i1 %.290, i32 -1, i32 0
  %.306 = fcmp une float %.247, 0x7FF0000000000000
  %.308 = select i1 %.306, i32 -1, i32 0
  %legacy_not = xor i32 %.292, -1
  %legacy_not.1 = xor i32 %.308, -1
  %.309 = and i32 %legacy_not, %legacy_not.1
  %.310 = icmp ne i32 %.309, 0
  %legacy_taken_mask.5 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.4, i1 %.310)
  %.311 = xor i32 %legacy_taken_mask.5, -1
  %legacy_fallthrough_mask.5 = and i32 %legacy_path_mask.4, %.311
  %legacy_path_mask.5 = select i1 %.310, i32 %legacy_taken_mask.5, i32 %legacy_fallthrough_mask.5
  br label %BB_02a8_0a08

BB_02a8_0a08:                                     ; preds = %BB_02a8_09e8
  %32 = zext i1 %.310 to i32
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %BB_02a8_0c88, label %BB_02a8_0a10

BB_02a8_0a10:                                     ; preds = %BB_02a8_0a08
  %.332 = icmp ne i32 %.226, 0
  %legacy_not.2 = xor i1 %.306, true
  %legacy_not.3 = xor i1 %.332, true
  %.333 = or i1 %legacy_not.2, %legacy_not.3
  %legacy_taken_mask.6 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.5, i1 %.333)
  %.337 = xor i32 %legacy_taken_mask.6, -1
  %legacy_fallthrough_mask.6 = and i32 %legacy_path_mask.5, %.337
  %legacy_path_mask.6 = select i1 %.333, i32 %legacy_taken_mask.6, i32 %legacy_fallthrough_mask.6
  br label %BB_02a8_0a30

BB_02a8_0a30:                                     ; preds = %BB_02a8_0a10
  %34 = zext i1 %.333 to i32
  %35 = icmp ne i32 %34, 0
  br i1 %35, label %BB_02a8_0c78, label %BB_02a8_0a38

BB_02a8_0a38:                                     ; preds = %BB_02a8_0a30
  %.358 = icmp ne i32 %.242, 0
  %legacy_not.4 = xor i1 %.290, true
  %legacy_not.5 = xor i1 %.358, true
  %.359 = or i1 %legacy_not.4, %legacy_not.5
  %legacy_taken_mask.7 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.6, i1 %.359)
  %.363 = xor i32 %legacy_taken_mask.7, -1
  %legacy_fallthrough_mask.7 = and i32 %legacy_path_mask.6, %.363
  %legacy_path_mask.7 = select i1 %.359, i32 %legacy_taken_mask.7, i32 %legacy_fallthrough_mask.7
  br label %BB_02a8_0a58

BB_02a8_0a58:                                     ; preds = %BB_02a8_0a38
  %36 = zext i1 %.359 to i32
  %37 = icmp ne i32 %36, 0
  br i1 %37, label %BB_02a8_0c60, label %BB_02a8_0a60

BB_02a8_0a60:                                     ; preds = %BB_02a8_0a58
  %isetrp_cmp1.10 = icmp sge i32 %legacy_result.25, 0
  %isetrp_cmp1.11 = icmp sge i32 %legacy_result.24, 0
  br label %BB_02a8_0a70

BB_02a8_0a70:                                     ; preds = %BB_02a8_0a60
  %38 = zext i1 %isetrp_cmp1.10 to i32
  %39 = icmp ne i32 %38, 0
  br i1 %39, label %BB_02a8_80000a70, label %BB_02a8_0a78

BB_02a8_80000a70:                                 ; preds = %BB_02a8_0a70
  br label %BB_02a8_0a78

BB_02a8_0a78:                                     ; preds = %BB_02a8_80000a70, %BB_02a8_0a70
  %phi.3 = phi i32 [ 0, %BB_02a8_80000a70 ], [ %.292, %BB_02a8_0a70 ]
  %cond_not.5 = xor i1 %isetrp_cmp1.10, true
  br i1 %cond_not.5, label %BB_02a8_80000a78, label %BB_02a8_0a88

BB_02a8_80000a78:                                 ; preds = %BB_02a8_0a78
  %ffma_lhs_bitcast = bitcast i32 %mov.4 to float
  %ffma.5 = call float @llvm.fma.f32(float %ffma_lhs_bitcast, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R366_bitcast = bitcast float %ffma.5 to i32
  br label %BB_02a8_0a88

BB_02a8_0a88:                                     ; preds = %BB_02a8_80000a78, %BB_02a8_0a78
  %phi.4 = phi i32 [ -64, %BB_02a8_80000a78 ], [ %phi.3, %BB_02a8_0a78 ]
  %phi.5 = phi i32 [ %phi_cast_R366_bitcast, %BB_02a8_80000a78 ], [ %mov.4, %BB_02a8_0a78 ]
  %cond_not.6 = xor i1 %isetrp_cmp1.11, true
  br i1 %cond_not.6, label %BB_02a8_80000a88, label %BB_02a8_0a98

BB_02a8_80000a88:                                 ; preds = %BB_02a8_0a88
  %ffma_lhs_bitcast.1 = bitcast i32 %mov.3 to float
  %ffma.6 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.1, float 0x43F0000000000000, float 0.000000e+00)
  %legacy_a_wide.26 = zext i32 %phi.4 to i64
  %legacy_sum.26 = add i64 %legacy_a_wide.26, 64
  %legacy_result.26 = trunc i64 %legacy_sum.26 to i32
  %phi_cast_R315_bitcast = bitcast float %ffma.6 to i32
  br label %BB_02a8_0a98

BB_02a8_0c60:                                     ; preds = %BB_02a8_0a58
  %.374 = and i32 %.262, -2147483648
  %.375 = and i32 %.374, %mov.4
  %.378 = and i32 %mov.3, -2147483648
  %.379 = and i32 %.378, %.266
  %.380 = or i32 %.375, %.379
  %.381 = or i32 %.380, 2139095040
  %phi_cast_R199_bitcast = bitcast i32 %.381 to float
  br label %BB_02b0

BB_02a8_0c78:                                     ; preds = %BB_02a8_0a30
  %.384 = and i32 %.262, -2147483648
  %.385 = and i32 %.384, %mov.4
  %.388 = and i32 %mov.3, -2147483648
  %.389 = and i32 %.388, %.266
  %.390 = or i32 %.385, %.389
  %phi_cast_R200_bitcast = bitcast i32 %.390 to float
  br label %BB_02b0

BB_02a8_0c88:                                     ; preds = %BB_02a8_0a08, %BB_02a8_09e0
  %mufu_rsq = call float @llvm.nvvm.rsqrt.approx.ftz.f(float 0xFFF8000000000000)
  br label %BB_02b0

BB_02a8_0ca0:                                     ; preds = %BB_02a8_09c0
  %fadd_lhs_bitcast = bitcast i32 %mov.4 to float
  %fadd_rhs = load float, ptr %.40, align 4
  %fadd = fadd float %fadd_lhs_bitcast, %fadd_rhs
  br label %BB_02b0

BB_02a8_0a98:                                     ; preds = %BB_02a8_80000a88, %BB_02a8_0a88, %BB_02a8_0998
  %phi.6 = phi i32 [ %phi_cast_R195_bitcast, %BB_02a8_0998 ], [ %legacy_result.26, %BB_02a8_80000a88 ], [ %phi.4, %BB_02a8_0a88 ]
  %phi.7 = phi i32 [ %legacy_path_mask.2, %BB_02a8_0998 ], [ %legacy_path_mask.7, %BB_02a8_80000a88 ], [ %legacy_path_mask.7, %BB_02a8_0a88 ]
  %phi.8 = phi i32 [ %mov.3, %BB_02a8_0998 ], [ %phi_cast_R315_bitcast, %BB_02a8_80000a88 ], [ %mov.3, %BB_02a8_0a88 ]
  %phi.9 = phi i32 [ %mov.4, %BB_02a8_0998 ], [ %phi.5, %BB_02a8_80000a88 ], [ %phi.5, %BB_02a8_0a88 ]
  %legacy_a_shift.1 = shl i32 %.204, 23
  %legacy_a_wide.27 = zext i32 %legacy_a_shift.1 to i64
  %legacy_sum.27 = add i64 %legacy_a_wide.27, 3229614080
  %legacy_result.27 = trunc i64 %legacy_sum.27 to i32
  %legacy_sum.28 = add i64 %legacy_a_wide.25, 4294967169
  %legacy_result.28 = trunc i64 %legacy_sum.28 to i32
  %legacy_a_wide.29 = zext i32 %legacy_result.27 to i64
  %legacy_a_complement.5 = xor i64 %legacy_a_wide.29, 4294967295
  %legacy_a_negate.5 = add i64 %legacy_a_complement.5, 1
  %legacy_b_wide.29 = zext i32 %phi.8 to i64
  %legacy_sum.29 = add i64 %legacy_a_negate.5, %legacy_b_wide.29
  %legacy_result.29 = trunc i64 %legacy_sum.29 to i32
  %legacy_a_shift.2 = shl i32 %legacy_result.28, 23
  %legacy_a_wide.30 = zext i32 %legacy_a_shift.2 to i64
  %legacy_a_complement.6 = xor i64 %legacy_a_wide.30, 4294967295
  %legacy_a_negate.6 = add i64 %legacy_a_complement.6, 1
  %legacy_b_wide.30 = zext i32 %phi.9 to i64
  %legacy_sum.30 = add i64 %legacy_a_negate.6, %legacy_b_wide.30
  %legacy_result.30 = trunc i64 %legacy_sum.30 to i32
  %mufu_src_bitcast.1 = bitcast i32 %legacy_result.29 to float
  %mufu_rcp.1 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.1)
  %iadd3_o3_not = xor i32 %.204, -1
  %iadd3_o3_neg = add i32 %iadd3_o3_not, 1
  %iadd3_n1 = add i32 %legacy_result.28, 127
  %iadd3_n2 = add i32 %iadd3_n1, %iadd3_o3_neg
  %fadd_lhs_fneg = fneg float %mufu_src_bitcast.1
  %fadd.1 = fadd float %fadd_lhs_fneg, 0.000000e+00
  %legacy_a_wide.31 = zext i32 %iadd3_n2 to i64
  %legacy_b_wide.31 = zext i32 %phi.6 to i64
  %legacy_sum.31 = add i64 %legacy_a_wide.31, %legacy_b_wide.31
  %legacy_result.31 = trunc i64 %legacy_sum.31 to i32
  %ffma.7 = call float @llvm.fma.f32(float %mufu_rcp.1, float %fadd.1, float 1.000000e+00)
  %ffma.8 = call float @llvm.fma.f32(float %mufu_rcp.1, float %ffma.7, float %mufu_rcp.1)
  %ffma_lhs_bitcast.2 = bitcast i32 %legacy_result.30 to float
  %ffma.9 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.2, float %ffma.8, float 0.000000e+00)
  %ffma.10 = call float @llvm.fma.f32(float %fadd.1, float %ffma.9, float %ffma_lhs_bitcast.2)
  %ffma.11 = call float @llvm.fma.f32(float %ffma.8, float %ffma.10, float %ffma.9)
  %ffma.12 = call float @llvm.fma.f32(float %fadd.1, float %ffma.11, float %ffma_lhs_bitcast.2)
  %ffma.13 = call float @llvm.fma.f32(float %ffma.8, float %ffma.12, float %ffma.11)
  %legacy_source_bitcast.4 = bitcast float %ffma.13 to i32
  %.402 = zext i32 %legacy_source_bitcast.4 to i64
  %.405 = lshr i64 %.402, 23
  %.408 = and i64 %.405, 255
  %.409 = trunc i64 %.408 to i32
  %legacy_a_wide.32 = zext i32 %.409 to i64
  %legacy_b_wide.32 = zext i32 %legacy_result.31 to i64
  %legacy_sum.32 = add i64 %legacy_a_wide.32, %legacy_b_wide.32
  %legacy_result.32 = trunc i64 %legacy_sum.32 to i32
  %legacy_a_wide.33 = zext i32 %legacy_result.32 to i64
  %legacy_sum.33 = add i64 %legacy_a_wide.33, 4294967295
  %legacy_result.33 = trunc i64 %legacy_sum.33 to i32
  %isetrp_cmp1.12 = icmp uge i32 %legacy_result.33, 254
  %legacy_branch_predicate_not.4 = xor i1 %isetrp_cmp1.12, true
  %legacy_taken_mask.8 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %phi.7, i1 %legacy_branch_predicate_not.4)
  %.410 = xor i32 %legacy_taken_mask.8, -1
  %legacy_fallthrough_mask.8 = and i32 %phi.7, %.410
  %legacy_path_mask.8 = select i1 %legacy_branch_predicate_not.4, i32 %legacy_taken_mask.8, i32 %legacy_fallthrough_mask.8
  br label %BB_02a8_0b38

BB_02a8_0b38:                                     ; preds = %BB_02a8_0a98
  %40 = zext i1 %legacy_branch_predicate_not.4 to i32
  %41 = icmp ne i32 %40, 0
  br i1 %41, label %BB_02a8_0c50, label %BB_02a8_0b40

BB_02a8_0b40:                                     ; preds = %BB_02a8_0b38
  %isetrp_cmp1.13 = icmp sgt i32 %legacy_result.32, 254
  %legacy_taken_mask.9 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.8, i1 %isetrp_cmp1.13)
  %.413 = xor i32 %legacy_taken_mask.9, -1
  %legacy_fallthrough_mask.9 = and i32 %legacy_path_mask.8, %.413
  %legacy_path_mask.9 = select i1 %isetrp_cmp1.13, i32 %legacy_taken_mask.9, i32 %legacy_fallthrough_mask.9
  br label %BB_02a8_0b50

BB_02a8_0b50:                                     ; preds = %BB_02a8_0b40
  %42 = zext i1 %isetrp_cmp1.13 to i32
  %43 = icmp ne i32 %42, 0
  br i1 %43, label %BB_02a8_0c38, label %BB_02a8_0b58

BB_02a8_0b58:                                     ; preds = %BB_02a8_0b50
  %isetrp_cmp1.14 = icmp sge i32 %legacy_result.32, 1
  %legacy_taken_mask.10 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.9, i1 %isetrp_cmp1.14)
  %.416 = xor i32 %legacy_taken_mask.10, -1
  %legacy_fallthrough_mask.10 = and i32 %legacy_path_mask.9, %.416
  %legacy_path_mask.10 = select i1 %isetrp_cmp1.14, i32 %legacy_taken_mask.10, i32 %legacy_fallthrough_mask.10
  br label %BB_02a8_0b68

BB_02a8_0b68:                                     ; preds = %BB_02a8_0b58
  %44 = zext i1 %isetrp_cmp1.14 to i32
  %45 = icmp ne i32 %44, 0
  br i1 %45, label %BB_02b0, label %BB_02a8_0b70

BB_02a8_0b70:                                     ; preds = %BB_02a8_0b68
  %isetrp_cmp1.15 = icmp sge i32 %legacy_result.32, -24
  %.419 = and i32 %legacy_source_bitcast.4, -2147483648
  %legacy_branch_predicate_not.5 = xor i1 %isetrp_cmp1.15, true
  %legacy_taken_mask.11 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.10, i1 %legacy_branch_predicate_not.5)
  br label %BB_02a8_0b88

BB_02a8_0b88:                                     ; preds = %BB_02a8_0b70
  %phi_cast_R208_bitcast = bitcast i32 %.419 to float
  br i1 %legacy_branch_predicate_not.5, label %BB_02b0, label %BB_02a8_0b90

BB_02a8_0b90:                                     ; preds = %BB_02a8_0b88
  %ffma_rz = call float @llvm.nvvm.fma.rz.f(float %ffma.8, float %ffma.12, float %ffma.11)
  %isetrp_cmp1.16 = icmp ne i32 %legacy_result.32, 0
  %legacy_sum.34 = add i64 %legacy_a_wide.33, 32
  %legacy_result.34 = trunc i64 %legacy_sum.34 to i32
  %legacy_source_bitcast.6 = bitcast float %ffma_rz to i32
  %.423 = and i32 %legacy_source_bitcast.6, 8388607
  %.424 = or i32 %.423, 8388608
  %ffma_rp = call float @llvm.nvvm.fma.rp.f(float %ffma.8, float %ffma.12, float %ffma.11)
  %ffma_rm = call float @llvm.nvvm.fma.rm.f(float %ffma.8, float %ffma.12, float %ffma.11)
  %shl.3 = shl i32 %.424, %legacy_result.34
  %.425 = bitcast float %ffma_rp to i32
  %.426 = and i32 %.425, 2139095040
  %.427 = icmp eq i32 %.426, 0
  %.428 = and i32 %.425, -2147483648
  %.429 = select i1 %.427, i32 %.428, i32 %.425
  %.430 = bitcast i32 %.429 to float
  %.431 = bitcast float %ffma_rm to i32
  %.432 = and i32 %.431, 2139095040
  %.433 = icmp eq i32 %.432, 0
  %.434 = and i32 %.431, -2147483648
  %.435 = select i1 %.433, i32 %.434, i32 %.431
  %.436 = bitcast i32 %.435 to float
  %.437 = fcmp une float %.430, %.436
  %legacy_a_complement.7 = xor i64 %legacy_a_wide.33, 4294967295
  %legacy_a_negate.7 = add i64 %legacy_a_complement.7, 1
  %legacy_result.35 = trunc i64 %legacy_a_negate.7 to i32
  %isetrp_cmp1.17 = icmp ne i32 %shl.3, 0
  %isetrp_cmp2.17 = and i1 %isetrp_cmp1.17, %isetrp_cmp1.16
  %.442 = select i1 %isetrp_cmp1.16, i32 %legacy_result.35, i32 0
  %shr_overflow.3 = icmp ugt i32 %.442, 31
  %shr_clamp.3 = select i1 %shr_overflow.3, i32 31, i32 %.442
  %shr_result.3 = lshr i32 %.424, %shr_clamp.3
  %shr_zero = select i1 %shr_overflow.3, i32 0, i32 %shr_result.3
  %.443 = or i1 %.437, %isetrp_cmp2.17
  %shr_result.4 = lshr i32 %shr_zero, 1
  %sel_pred_not = xor i1 %.443, true
  %sel.2 = select i1 %sel_pred_not, i32 0, i32 1
  %.447 = xor i32 %sel.2, -1
  %.448 = and i32 %.447, 1
  %.449 = and i32 %.448, %shr_result.4
  %.460 = xor i32 %shr_result.4, -1
  %.462 = and i32 %sel.2, %.460
  %.463 = or i32 %.449, %.462
  %.465 = and i32 %sel.2, %shr_result.4
  %.466 = or i32 %.463, %.465
  %.467 = and i32 %.466, %shr_zero
  %legacy_a_wide.36 = zext i32 %shr_result.4 to i64
  %legacy_b_wide.36 = zext i32 %.467 to i64
  %legacy_sum.36 = add i64 %legacy_a_wide.36, %legacy_b_wide.36
  %legacy_result.36 = trunc i64 %legacy_sum.36 to i32
  %.468 = or i32 %legacy_result.36, %.419
  %phi_cast_R209_bitcast = bitcast i32 %.468 to float
  br label %BB_02b0

BB_02a8_0c38:                                     ; preds = %BB_02a8_0b50
  %.470 = and i32 %legacy_source_bitcast.4, -2147483648
  %.471 = or i32 %.470, 2139095040
  %phi_cast_R211_bitcast = bitcast i32 %.471 to float
  br label %BB_02b0

BB_02a8_0c50:                                     ; preds = %BB_02a8_0b38
  %legacy_a_shift.3 = shl i32 %legacy_result.31, 23
  %legacy_a_wide.37 = zext i32 %legacy_a_shift.3 to i64
  %legacy_sum.37 = add i64 %legacy_a_wide.37, %.402
  %legacy_result.37 = trunc i64 %legacy_sum.37 to i32
  %phi_cast_R214_bitcast = bitcast i32 %legacy_result.37 to float
  br label %BB_02b0

BB_02b0:                                          ; preds = %BB_02a8_0c50, %BB_02a8_0c38, %BB_02a8_0b90, %BB_02a8_0b88, %BB_02a8_0b68, %BB_02a8_0ca0, %BB_02a8_0c88, %BB_02a8_0c78, %BB_02a8_0c60
  %phi.10 = phi float [ %phi_cast_R209_bitcast, %BB_02a8_0b90 ], [ %phi_cast_R211_bitcast, %BB_02a8_0c38 ], [ %phi_cast_R214_bitcast, %BB_02a8_0c50 ], [ %phi_cast_R199_bitcast, %BB_02a8_0c60 ], [ %phi_cast_R200_bitcast, %BB_02a8_0c78 ], [ %mufu_rsq, %BB_02a8_0c88 ], [ %fadd, %BB_02a8_0ca0 ], [ %ffma.13, %BB_02a8_0b68 ], [ %phi_cast_R208_bitcast, %BB_02a8_0b88 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.1)
  %legacy_join_live_mask = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.1, i1 true)
  br label %BB_02c0

BB_02c0:                                          ; preds = %BB_02b0, %BB_0298
  %phi.11 = phi float [ %phi.10, %BB_02b0 ], [ %ffma.4, %BB_0298 ]
  %phi.12 = phi i32 [ %legacy_join_live_mask, %BB_02b0 ], [ %legacy_path_mask.1, %BB_0298 ]
  %mov.7 = load i32, ptr %.46, align 4
  %f2f_ext = fpext float %phi.11 to double
  %"R9:R8_bitcast" = bitcast double %f2f_ext to i64
  %imnmx_cmp = icmp slt i32 %sel, %legacy_result.21
  %imnmx_max = select i1 %imnmx_cmp, i32 %sel, i32 %legacy_result.21
  %legacy_a_wide.38 = zext i32 %mov.7 to i64
  %legacy_sum.38 = add i64 %legacy_a_wide.38, 25165824
  %legacy_result.38 = trunc i64 %legacy_sum.38 to i32
  %.477 = and i32 %legacy_result.38, 2139095040
  %isetrp_cmp1.18 = icmp ugt i32 %.477, 33554431
  %imnmx_cmp.1 = icmp sgt i32 %.175, %legacy_result.19
  %imnmx_max.1 = select i1 %imnmx_cmp.1, i32 %.175, i32 %legacy_result.19
  %legacy_a_shift.4 = shl i32 %imnmx_max, 6
  %legacy_a_wide.39 = zext i32 %legacy_a_shift.4 to i64
  %legacy_sum.39 = add i64 %legacy_a_wide.39, %legacy_b_wide.9
  %legacy_result.39 = trunc i64 %legacy_sum.39 to i32
  %legacy_a_shift.5 = shl i32 %imnmx_max.1, 6
  %legacy_a_wide.40 = zext i32 %legacy_a_shift.5 to i64
  %legacy_sum.40 = add i64 %legacy_a_wide.40, %legacy_b_wide.9
  %legacy_result.40 = trunc i64 %legacy_sum.40 to i32
  %legacy_taken_mask.12 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %phi.12, i1 %isetrp_cmp1.18)
  %.478 = xor i32 %legacy_taken_mask.12, -1
  %legacy_fallthrough_mask.12 = and i32 %phi.12, %.478
  %legacy_path_mask.12 = select i1 %isetrp_cmp1.18, i32 %legacy_taken_mask.12, i32 %legacy_fallthrough_mask.12
  br label %BB_0310

BB_0310:                                          ; preds = %BB_02c0
  %46 = zext i1 %isetrp_cmp1.18 to i32
  %47 = icmp ne i32 %46, 0
  br i1 %47, label %BB_0348, label %BB_0318

BB_0318:                                          ; preds = %BB_0310
  %mov.8 = load i32, ptr %.46, align 4
  br label %BB_0328_07a8

BB_0328_07a8:                                     ; preds = %BB_0318
  %legacy_a_wide.41 = zext i32 %mov.8 to i64
  %legacy_sum.41 = add i64 %legacy_a_wide.41, %legacy_a_wide.41
  %legacy_result.41 = trunc i64 %legacy_sum.41 to i32
  %shr_result.5 = lshr i32 %legacy_result.41, 24
  %isetrp_cmp1.19 = icmp ne i32 %shr_result.5, 0
  %legacy_taken_mask.13 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.12, i1 %isetrp_cmp1.19)
  %.484 = xor i32 %legacy_taken_mask.13, -1
  %legacy_fallthrough_mask.13 = and i32 %legacy_path_mask.12, %.484
  %legacy_path_mask.13 = select i1 %isetrp_cmp1.19, i32 %legacy_taken_mask.13, i32 %legacy_fallthrough_mask.13
  br label %BB_0328_07c8

BB_0328_07c8:                                     ; preds = %BB_0328_07a8
  %48 = zext i1 %isetrp_cmp1.19 to i32
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %BB_0328_0830, label %BB_0328_07d0

BB_0328_07d0:                                     ; preds = %BB_0328_07c8
  %isetrp_cmp1.20 = icmp ne i32 %legacy_result.41, 0
  br label %BB_0328_07e0

BB_0328_07e0:                                     ; preds = %BB_0328_07d0
  %cond_not.9 = xor i1 %isetrp_cmp1.20, true
  %phi_cast_R274_bitcast = bitcast i32 %legacy_result.41 to float
  br i1 %cond_not.9, label %BB_0328_800007e0, label %BB_0328_07e8

BB_0328_800007e0:                                 ; preds = %BB_0328_07e0
  %mufu_src_bitcast.2 = bitcast i32 %mov.8 to float
  %mufu_rcp.2 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.2)
  br label %BB_0328_07e8

BB_0328_07e8:                                     ; preds = %BB_0328_800007e0, %BB_0328_07e0
  %phi.13 = phi float [ %mufu_rcp.2, %BB_0328_800007e0 ], [ %phi_cast_R274_bitcast, %BB_0328_07e0 ]
  %legacy_taken_mask.14 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.13, i1 %cond_not.9)
  br label %BB_0328_07f0

BB_0328_07f0:                                     ; preds = %BB_0328_07e8
  %50 = zext i1 %cond_not.9 to i32
  %51 = icmp ne i32 %50, 0
  br i1 %51, label %BB_0330, label %BB_0328_07f8

BB_0328_07f8:                                     ; preds = %BB_0328_07f0
  %ffma_lhs_bitcast.3 = bitcast i32 %mov.8 to float
  %ffma.14 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.3, float 0x43F0000000000000, float 0.000000e+00)
  %mufu_rcp.3 = call float @llvm.nvvm.rcp.approx.ftz.f(float %ffma.14)
  %ffma.15 = call float @llvm.fma.f32(float %ffma.14, float %mufu_rcp.3, float -1.000000e+00)
  %fadd_lhs_fneg.1 = fneg float %ffma.15
  %fadd.2 = fadd float %fadd_lhs_fneg.1, 0.000000e+00
  %ffma.16 = call float @llvm.fma.f32(float %mufu_rcp.3, float %fadd.2, float %mufu_rcp.3)
  %ffma.17 = call float @llvm.fma.f32(float %ffma.16, float 0x43F0000000000000, float 0.000000e+00)
  br label %BB_0330

BB_0328_0830:                                     ; preds = %BB_0328_07c8
  %legacy_a_wide.43 = zext i32 %shr_result.5 to i64
  %legacy_sum.43 = add i64 %legacy_a_wide.43, 4294967043
  %legacy_result.43 = trunc i64 %legacy_sum.43 to i32
  %isetrp_cmp1.21 = icmp ugt i32 %legacy_result.43, 1
  %legacy_taken_mask.15 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.13, i1 %isetrp_cmp1.21)
  br label %BB_0328_0848

BB_0328_0848:                                     ; preds = %BB_0328_0830
  %52 = zext i1 %isetrp_cmp1.21 to i32
  %53 = icmp ne i32 %52, 0
  br i1 %53, label %BB_0328_0928, label %BB_0328_0850

BB_0328_0850:                                     ; preds = %BB_0328_0848
  %.497 = and i32 %mov.8, 8388607
  %legacy_sum.44 = add i64 %legacy_a_wide.43, 4294967044
  %legacy_result.44 = trunc i64 %legacy_sum.44 to i32
  %.498 = or i32 %.497, 1065353216
  %shl.4 = shl i32 3, %legacy_result.43
  %mufu_src_bitcast.3 = bitcast i32 %.498 to float
  %mufu_rcp.4 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.3)
  %ffma.18 = call float @llvm.fma.f32(float %mufu_src_bitcast.3, float %mufu_rcp.4, float -1.000000e+00)
  %fadd_lhs_fneg.2 = fneg float %ffma.18
  %fadd.3 = fadd float %fadd_lhs_fneg.2, 0.000000e+00
  %ffma_rm.1 = call float @llvm.nvvm.fma.rm.f(float %mufu_rcp.4, float %fadd.3, float %mufu_rcp.4)
  %ffma_rp.1 = call float @llvm.nvvm.fma.rp.f(float %mufu_rcp.4, float %fadd.3, float %mufu_rcp.4)
  %legacy_source_bitcast.8 = bitcast float %ffma_rm.1 to i32
  %.499 = and i32 %legacy_source_bitcast.8, 8388607
  %.501 = and i32 %legacy_source_bitcast.8, 2139095040
  %.502 = icmp eq i32 %.501, 0
  %.503 = and i32 %legacy_source_bitcast.8, -2147483648
  %.504 = select i1 %.502, i32 %.503, i32 %legacy_source_bitcast.8
  %.505 = bitcast i32 %.504 to float
  %.506 = bitcast float %ffma_rp.1 to i32
  %.507 = and i32 %.506, 2139095040
  %.508 = icmp eq i32 %.507, 0
  %.509 = and i32 %.506, -2147483648
  %.510 = select i1 %.508, i32 %.509, i32 %.506
  %.511 = bitcast i32 %.510 to float
  %.512 = fcmp une float %.505, %.511
  %.514 = select i1 %.512, i32 -1, i32 0
  %.515 = or i32 %.499, 8388608
  %legacy_a_wide.45 = zext i32 %.514 to i64
  %legacy_a_complement.8 = xor i64 %legacy_a_wide.45, 4294967295
  %legacy_a_negate.8 = add i64 %legacy_a_complement.8, 1
  %legacy_result.45 = trunc i64 %legacy_a_negate.8 to i32
  %.516 = and i32 %shl.4, %.515
  %.517 = xor i32 %legacy_result.45, -1
  %.518 = and i32 %.517, %legacy_result.43
  %.519 = and i32 %.518, %.515
  %.521 = xor i32 %legacy_result.43, -1
  %.522 = xor i32 %.515, -1
  %.523 = and i32 %legacy_result.45, %.521
  %.524 = and i32 %.523, %.522
  %.525 = or i32 %.519, %.524
  %.528 = and i32 %.523, %.515
  %.529 = or i32 %.525, %.528
  %.531 = and i32 %legacy_result.45, %legacy_result.43
  %.532 = and i32 %.531, %.522
  %.533 = or i32 %.529, %.532
  %.535 = and i32 %.531, %.515
  %.536 = or i32 %.533, %.535
  %.537 = icmp ne i32 %.536, 0
  %shr_overflow.6 = icmp ugt i32 %legacy_result.44, 31
  %shr_clamp.6 = select i1 %shr_overflow.6, i32 31, i32 %legacy_result.44
  %shr_result.6 = lshr i32 %.515, %shr_clamp.6
  %shr_zero.3 = select i1 %shr_overflow.6, i32 0, i32 %shr_result.6
  %shr_result.7 = lshr i32 %.516, %legacy_result.43
  %.538 = and i32 %shr_result.7, 2
  %.539 = icmp ne i32 %.538, 0
  %.540 = and i32 %shr_result.7, 1
  %.541 = icmp ne i32 %.540, 0
  %.542 = or i1 %.537, %.539
  %isetrp_cmp1.22 = icmp eq i32 %.497, 0
  %.546 = and i1 %.541, %.542
  br label %BB_0328_0908

BB_0328_0908:                                     ; preds = %BB_0328_0850
  %54 = zext i1 %.546 to i32
  %55 = icmp ne i32 %54, 0
  br i1 %55, label %BB_0328_80000908, label %BB_0328_0910

BB_0328_80000908:                                 ; preds = %BB_0328_0908
  %legacy_a_wide.46 = zext i32 %shr_zero.3 to i64
  %legacy_sum.46 = add i64 %legacy_a_wide.46, 1
  %legacy_result.46 = trunc i64 %legacy_sum.46 to i32
  br label %BB_0328_0910

BB_0328_0910:                                     ; preds = %BB_0328_80000908, %BB_0328_0908
  %phi.14 = phi i32 [ %legacy_result.46, %BB_0328_80000908 ], [ %shr_zero.3, %BB_0328_0908 ]
  br i1 %isetrp_cmp1.22, label %BB_0328_80000910, label %BB_0328_0918

BB_0328_80000910:                                 ; preds = %BB_0328_0910
  %shl.5 = shl i32 %phi.14, 1
  br label %BB_0328_0918

BB_0328_0918:                                     ; preds = %BB_0328_80000910, %BB_0328_0910
  %phi.15 = phi i32 [ %shl.5, %BB_0328_80000910 ], [ %phi.14, %BB_0328_0910 ]
  %.555 = xor i32 %phi.15, -1
  %.556 = and i32 %.555, -2147483648
  %.557 = and i32 %.556, %mov.8
  %.560 = xor i32 %mov.8, -1
  %.561 = and i32 %phi.15, 2147483647
  %.562 = and i32 %.561, %.560
  %.563 = or i32 %.557, %.562
  %.566 = and i32 %.561, %mov.8
  %.567 = or i32 %.563, %.566
  %.569 = and i32 %phi.15, -2147483648
  %.570 = and i32 %.569, %.560
  %.571 = or i32 %.567, %.570
  %.573 = and i32 %.569, %mov.8
  %.574 = or i32 %.571, %.573
  %phi_cast_R372_bitcast = bitcast i32 %.574 to float
  br label %BB_0330

BB_0328_0928:                                     ; preds = %BB_0328_0848
  %mufu_src_bitcast.4 = bitcast i32 %mov.8 to float
  %mufu_rcp.5 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.4)
  br label %BB_0330

BB_0330:                                          ; preds = %BB_0328_0928, %BB_0328_0918, %BB_0328_07f8, %BB_0328_07f0
  %phi.16 = phi float [ %ffma.17, %BB_0328_07f8 ], [ %phi_cast_R372_bitcast, %BB_0328_0918 ], [ %mufu_rcp.5, %BB_0328_0928 ], [ %phi.13, %BB_0328_07f0 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.12)
  %legacy_join_live_mask.1 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.12, i1 true)
  br label %BB_0370

BB_0348:                                          ; preds = %BB_0310
  %mufu_src_bitcast.5 = bitcast i32 %mov.7 to float
  %mufu_rcp.6 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.5)
  %ffma_rhs.2 = load float, ptr %.46, align 4
  %ffma.19 = call float @llvm.fma.f32(float %mufu_rcp.6, float %ffma_rhs.2, float -1.000000e+00)
  %fadd_lhs_fneg.3 = fneg float %ffma.19
  %fadd.4 = fadd float %fadd_lhs_fneg.3, 0.000000e+00
  %ffma.20 = call float @llvm.fma.f32(float %mufu_rcp.6, float %fadd.4, float %mufu_rcp.6)
  br label %BB_0370

BB_0370:                                          ; preds = %BB_0348, %BB_0330
  %phi.17 = phi i32 [ %legacy_join_live_mask.1, %BB_0330 ], [ %legacy_path_mask.12, %BB_0348 ]
  %phi.18 = phi float [ %phi.16, %BB_0330 ], [ %ffma.20, %BB_0348 ]
  %mov.9 = load i32, ptr %.43, align 4
  %f2f_ext.1 = fpext float %phi.18 to double
  %"R11:R10_bitcast" = bitcast double %f2f_ext.1 to i64
  %imnmx_cmp.2 = icmp slt i32 %sel.1, %legacy_result.23
  %imnmx_max.2 = select i1 %imnmx_cmp.2, i32 %sel.1, i32 %legacy_result.23
  %imnmx_cmp.3 = icmp sgt i32 %.172, %legacy_result.22
  %imnmx_max.3 = select i1 %imnmx_cmp.3, i32 %.172, i32 %legacy_result.22
  %legacy_a_wide.47 = zext i32 %mov.9 to i64
  %legacy_sum.47 = add i64 %legacy_a_wide.47, 25165824
  %legacy_result.47 = trunc i64 %legacy_sum.47 to i32
  %legacy_a_shift.6 = shl i32 %imnmx_max.2, 2
  %legacy_a_wide.48 = zext i32 %legacy_a_shift.6 to i64
  %legacy_sum.48 = add i64 %legacy_a_wide.48, %legacy_a_wide.9
  %legacy_result.48 = trunc i64 %legacy_sum.48 to i32
  %legacy_a_shift.7 = shl i32 %imnmx_max.3, 2
  %legacy_a_wide.49 = zext i32 %legacy_a_shift.7 to i64
  %legacy_sum.49 = add i64 %legacy_a_wide.49, %legacy_a_wide.9
  %legacy_result.49 = trunc i64 %legacy_sum.49 to i32
  %.583 = and i32 %legacy_result.47, 2139095040
  %isetrp_cmp1.23 = icmp ugt i32 %.583, 33554431
  %legacy_taken_mask.16 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %phi.17, i1 %isetrp_cmp1.23)
  %.584 = xor i32 %legacy_taken_mask.16, -1
  %legacy_fallthrough_mask.16 = and i32 %phi.17, %.584
  %legacy_path_mask.16 = select i1 %isetrp_cmp1.23, i32 %legacy_taken_mask.16, i32 %legacy_fallthrough_mask.16
  br label %BB_03c0

BB_03c0:                                          ; preds = %BB_0370
  %56 = zext i1 %isetrp_cmp1.23 to i32
  %57 = icmp ne i32 %56, 0
  br i1 %57, label %BB_03f8, label %BB_03c8

BB_03c8:                                          ; preds = %BB_03c0
  %mov.10 = load i32, ptr %.43, align 4
  br label %BB_03d8_07a8

BB_03d8_07a8:                                     ; preds = %BB_03c8
  %legacy_a_wide.50 = zext i32 %mov.10 to i64
  %legacy_sum.50 = add i64 %legacy_a_wide.50, %legacy_a_wide.50
  %legacy_result.50 = trunc i64 %legacy_sum.50 to i32
  %shr_result.8 = lshr i32 %legacy_result.50, 24
  %isetrp_cmp1.24 = icmp ne i32 %shr_result.8, 0
  %legacy_taken_mask.17 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.16, i1 %isetrp_cmp1.24)
  %.590 = xor i32 %legacy_taken_mask.17, -1
  %legacy_fallthrough_mask.17 = and i32 %legacy_path_mask.16, %.590
  %legacy_path_mask.17 = select i1 %isetrp_cmp1.24, i32 %legacy_taken_mask.17, i32 %legacy_fallthrough_mask.17
  br label %BB_03d8_07c8

BB_03d8_07c8:                                     ; preds = %BB_03d8_07a8
  %58 = zext i1 %isetrp_cmp1.24 to i32
  %59 = icmp ne i32 %58, 0
  br i1 %59, label %BB_03d8_0830, label %BB_03d8_07d0

BB_03d8_07d0:                                     ; preds = %BB_03d8_07c8
  %isetrp_cmp1.25 = icmp ne i32 %legacy_result.50, 0
  br label %BB_03d8_07e0

BB_03d8_07e0:                                     ; preds = %BB_03d8_07d0
  %cond_not.11 = xor i1 %isetrp_cmp1.25, true
  %phi_cast_R349_bitcast = bitcast i32 %legacy_result.50 to float
  br i1 %cond_not.11, label %BB_03d8_800007e0, label %BB_03d8_07e8

BB_03d8_800007e0:                                 ; preds = %BB_03d8_07e0
  %mufu_src_bitcast.6 = bitcast i32 %mov.10 to float
  %mufu_rcp.7 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.6)
  br label %BB_03d8_07e8

BB_03d8_07e8:                                     ; preds = %BB_03d8_800007e0, %BB_03d8_07e0
  %phi.19 = phi float [ %mufu_rcp.7, %BB_03d8_800007e0 ], [ %phi_cast_R349_bitcast, %BB_03d8_07e0 ]
  %legacy_taken_mask.18 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.17, i1 %cond_not.11)
  br label %BB_03d8_07f0

BB_03d8_07f0:                                     ; preds = %BB_03d8_07e8
  %60 = zext i1 %cond_not.11 to i32
  %61 = icmp ne i32 %60, 0
  br i1 %61, label %BB_03e0, label %BB_03d8_07f8

BB_03d8_07f8:                                     ; preds = %BB_03d8_07f0
  %ffma_lhs_bitcast.5 = bitcast i32 %mov.10 to float
  %ffma.21 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.5, float 0x43F0000000000000, float 0.000000e+00)
  %mufu_rcp.8 = call float @llvm.nvvm.rcp.approx.ftz.f(float %ffma.21)
  %ffma.22 = call float @llvm.fma.f32(float %ffma.21, float %mufu_rcp.8, float -1.000000e+00)
  %fadd_lhs_fneg.4 = fneg float %ffma.22
  %fadd.5 = fadd float %fadd_lhs_fneg.4, 0.000000e+00
  %ffma.23 = call float @llvm.fma.f32(float %mufu_rcp.8, float %fadd.5, float %mufu_rcp.8)
  %ffma.24 = call float @llvm.fma.f32(float %ffma.23, float 0x43F0000000000000, float 0.000000e+00)
  br label %BB_03e0

BB_03d8_0830:                                     ; preds = %BB_03d8_07c8
  %legacy_a_wide.52 = zext i32 %shr_result.8 to i64
  %legacy_sum.52 = add i64 %legacy_a_wide.52, 4294967043
  %legacy_result.52 = trunc i64 %legacy_sum.52 to i32
  %isetrp_cmp1.26 = icmp ugt i32 %legacy_result.52, 1
  %legacy_taken_mask.19 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.17, i1 %isetrp_cmp1.26)
  br label %BB_03d8_0848

BB_03d8_0848:                                     ; preds = %BB_03d8_0830
  %62 = zext i1 %isetrp_cmp1.26 to i32
  %63 = icmp ne i32 %62, 0
  br i1 %63, label %BB_03d8_0928, label %BB_03d8_0850

BB_03d8_0850:                                     ; preds = %BB_03d8_0848
  %.603 = and i32 %mov.10, 8388607
  %legacy_sum.53 = add i64 %legacy_a_wide.52, 4294967044
  %legacy_result.53 = trunc i64 %legacy_sum.53 to i32
  %.604 = or i32 %.603, 1065353216
  %shl.6 = shl i32 3, %legacy_result.52
  %mufu_src_bitcast.7 = bitcast i32 %.604 to float
  %mufu_rcp.9 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.7)
  %ffma.25 = call float @llvm.fma.f32(float %mufu_src_bitcast.7, float %mufu_rcp.9, float -1.000000e+00)
  %fadd_lhs_fneg.5 = fneg float %ffma.25
  %fadd.6 = fadd float %fadd_lhs_fneg.5, 0.000000e+00
  %ffma_rm.2 = call float @llvm.nvvm.fma.rm.f(float %mufu_rcp.9, float %fadd.6, float %mufu_rcp.9)
  %ffma_rp.2 = call float @llvm.nvvm.fma.rp.f(float %mufu_rcp.9, float %fadd.6, float %mufu_rcp.9)
  %legacy_source_bitcast.9 = bitcast float %ffma_rm.2 to i32
  %.605 = and i32 %legacy_source_bitcast.9, 8388607
  %.607 = and i32 %legacy_source_bitcast.9, 2139095040
  %.608 = icmp eq i32 %.607, 0
  %.609 = and i32 %legacy_source_bitcast.9, -2147483648
  %.610 = select i1 %.608, i32 %.609, i32 %legacy_source_bitcast.9
  %.611 = bitcast i32 %.610 to float
  %.612 = bitcast float %ffma_rp.2 to i32
  %.613 = and i32 %.612, 2139095040
  %.614 = icmp eq i32 %.613, 0
  %.615 = and i32 %.612, -2147483648
  %.616 = select i1 %.614, i32 %.615, i32 %.612
  %.617 = bitcast i32 %.616 to float
  %.618 = fcmp une float %.611, %.617
  %.620 = select i1 %.618, i32 -1, i32 0
  %.621 = or i32 %.605, 8388608
  %legacy_a_wide.54 = zext i32 %.620 to i64
  %legacy_a_complement.9 = xor i64 %legacy_a_wide.54, 4294967295
  %legacy_a_negate.9 = add i64 %legacy_a_complement.9, 1
  %legacy_result.54 = trunc i64 %legacy_a_negate.9 to i32
  %.622 = and i32 %shl.6, %.621
  %.623 = xor i32 %legacy_result.54, -1
  %.624 = and i32 %.623, %legacy_result.52
  %.625 = and i32 %.624, %.621
  %.627 = xor i32 %legacy_result.52, -1
  %.628 = xor i32 %.621, -1
  %.629 = and i32 %legacy_result.54, %.627
  %.630 = and i32 %.629, %.628
  %.631 = or i32 %.625, %.630
  %.634 = and i32 %.629, %.621
  %.635 = or i32 %.631, %.634
  %.637 = and i32 %legacy_result.54, %legacy_result.52
  %.638 = and i32 %.637, %.628
  %.639 = or i32 %.635, %.638
  %.641 = and i32 %.637, %.621
  %.642 = or i32 %.639, %.641
  %.643 = icmp ne i32 %.642, 0
  %shr_overflow.9 = icmp ugt i32 %legacy_result.53, 31
  %shr_clamp.9 = select i1 %shr_overflow.9, i32 31, i32 %legacy_result.53
  %shr_result.9 = lshr i32 %.621, %shr_clamp.9
  %shr_zero.6 = select i1 %shr_overflow.9, i32 0, i32 %shr_result.9
  %shr_result.10 = lshr i32 %.622, %legacy_result.52
  %.644 = and i32 %shr_result.10, 2
  %.645 = icmp ne i32 %.644, 0
  %.646 = and i32 %shr_result.10, 1
  %.647 = icmp ne i32 %.646, 0
  %.648 = or i1 %.643, %.645
  %isetrp_cmp1.27 = icmp eq i32 %.603, 0
  %.652 = and i1 %.647, %.648
  br label %BB_03d8_0908

BB_03d8_0908:                                     ; preds = %BB_03d8_0850
  %64 = zext i1 %.652 to i32
  %65 = icmp ne i32 %64, 0
  br i1 %65, label %BB_03d8_80000908, label %BB_03d8_0910

BB_03d8_80000908:                                 ; preds = %BB_03d8_0908
  %legacy_a_wide.55 = zext i32 %shr_zero.6 to i64
  %legacy_sum.55 = add i64 %legacy_a_wide.55, 1
  %legacy_result.55 = trunc i64 %legacy_sum.55 to i32
  br label %BB_03d8_0910

BB_03d8_0910:                                     ; preds = %BB_03d8_80000908, %BB_03d8_0908
  %phi.20 = phi i32 [ %legacy_result.55, %BB_03d8_80000908 ], [ %shr_zero.6, %BB_03d8_0908 ]
  br i1 %isetrp_cmp1.27, label %BB_03d8_80000910, label %BB_03d8_0918

BB_03d8_80000910:                                 ; preds = %BB_03d8_0910
  %shl.7 = shl i32 %phi.20, 1
  br label %BB_03d8_0918

BB_03d8_0918:                                     ; preds = %BB_03d8_80000910, %BB_03d8_0910
  %phi.21 = phi i32 [ %shl.7, %BB_03d8_80000910 ], [ %phi.20, %BB_03d8_0910 ]
  %.661 = xor i32 %phi.21, -1
  %.662 = and i32 %.661, -2147483648
  %.663 = and i32 %.662, %mov.10
  %.666 = xor i32 %mov.10, -1
  %.667 = and i32 %phi.21, 2147483647
  %.668 = and i32 %.667, %.666
  %.669 = or i32 %.663, %.668
  %.672 = and i32 %.667, %mov.10
  %.673 = or i32 %.669, %.672
  %.675 = and i32 %phi.21, -2147483648
  %.676 = and i32 %.675, %.666
  %.677 = or i32 %.673, %.676
  %.679 = and i32 %.675, %mov.10
  %.680 = or i32 %.677, %.679
  %phi_cast_R80_bitcast = bitcast i32 %.680 to float
  br label %BB_03e0

BB_03d8_0928:                                     ; preds = %BB_03d8_0848
  %mufu_src_bitcast.8 = bitcast i32 %mov.10 to float
  %mufu_rcp.10 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.8)
  br label %BB_03e0

BB_03e0:                                          ; preds = %BB_03d8_0928, %BB_03d8_0918, %BB_03d8_07f8, %BB_03d8_07f0
  %phi.22 = phi float [ %ffma.24, %BB_03d8_07f8 ], [ %phi_cast_R80_bitcast, %BB_03d8_0918 ], [ %mufu_rcp.10, %BB_03d8_0928 ], [ %phi.19, %BB_03d8_07f0 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.16)
  %legacy_join_live_mask.2 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.16, i1 true)
  br label %BB_0420

BB_03f8:                                          ; preds = %BB_03c0
  %mufu_src_bitcast.9 = bitcast i32 %mov.9 to float
  %mufu_rcp.11 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.9)
  %ffma_rhs.3 = load float, ptr %.43, align 4
  %ffma.26 = call float @llvm.fma.f32(float %mufu_rcp.11, float %ffma_rhs.3, float -1.000000e+00)
  %fadd_lhs_fneg.6 = fneg float %ffma.26
  %fadd.7 = fadd float %fadd_lhs_fneg.6, 0.000000e+00
  %ffma.27 = call float @llvm.fma.f32(float %mufu_rcp.11, float %fadd.7, float %mufu_rcp.11)
  br label %BB_0420

BB_0420:                                          ; preds = %BB_03f8, %BB_03e0
  %phi.23 = phi i32 [ %legacy_join_live_mask.2, %BB_03e0 ], [ %legacy_path_mask.16, %BB_03f8 ]
  %phi.24 = phi float [ %phi.22, %BB_03e0 ], [ %ffma.27, %BB_03f8 ]
  %mov.11 = load i32, ptr %.49, align 4
  %f2f_ext.2 = fpext float %phi.24 to double
  %"R13:R12_bitcast" = bitcast double %f2f_ext.2 to i64
  %isetrp_cmp1.28 = icmp sge i32 %tid_y, %.175
  %legacy_b.8 = load i32, ptr %.16, align 4
  %legacy_b_wide.56 = zext i32 %legacy_b.8 to i64
  %legacy_b_complement.2 = xor i64 %legacy_b_wide.56, 4294967295
  %legacy_b_negate.2 = add i64 %legacy_b_complement.2, 1
  %legacy_result.56 = trunc i64 %legacy_b_negate.2 to i32
  %isetrp_src_not.2 = xor i1 %isetrp_cmp1.7, true
  %isetrp_cmp1.29 = icmp sgt i32 %tid_x, %sel.1
  %isetrp_cmp2.29 = or i1 %isetrp_cmp1.29, %isetrp_src_not.2
  %legacy_a_wide.57 = zext i32 %mov.11 to i64
  %legacy_sum.57 = add i64 %legacy_a_wide.57, 25165824
  %legacy_result.57 = trunc i64 %legacy_sum.57 to i32
  %.691 = and i32 %legacy_result.57, 2139095040
  %isetrp_src_not.3 = xor i1 %isetrp_cmp1.28, true
  %isetrp_cmp1.30 = icmp sgt i32 %tid_y, %sel
  %isetrp_cmp2.30 = or i1 %isetrp_cmp1.30, %isetrp_src_not.3
  %isetrp_cmp1.31 = icmp ugt i32 %.691, 33554431
  %legacy_taken_mask.20 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %phi.23, i1 %isetrp_cmp1.31)
  %.692 = xor i32 %legacy_taken_mask.20, -1
  %legacy_fallthrough_mask.20 = and i32 %phi.23, %.692
  %legacy_path_mask.20 = select i1 %isetrp_cmp1.31, i32 %legacy_taken_mask.20, i32 %legacy_fallthrough_mask.20
  br label %BB_0470

BB_0470:                                          ; preds = %BB_0420
  %66 = zext i1 %isetrp_cmp1.31 to i32
  %67 = icmp ne i32 %66, 0
  br i1 %67, label %BB_04a8, label %BB_0478

BB_0478:                                          ; preds = %BB_0470
  %mov.12 = load i32, ptr %.49, align 4
  br label %BB_0488_07a8

BB_0488_07a8:                                     ; preds = %BB_0478
  %legacy_a_wide.58 = zext i32 %mov.12 to i64
  %legacy_sum.58 = add i64 %legacy_a_wide.58, %legacy_a_wide.58
  %legacy_result.58 = trunc i64 %legacy_sum.58 to i32
  %shr_result.11 = lshr i32 %legacy_result.58, 24
  %isetrp_cmp1.32 = icmp ne i32 %shr_result.11, 0
  %legacy_taken_mask.21 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.20, i1 %isetrp_cmp1.32)
  %.698 = xor i32 %legacy_taken_mask.21, -1
  %legacy_fallthrough_mask.21 = and i32 %legacy_path_mask.20, %.698
  %legacy_path_mask.21 = select i1 %isetrp_cmp1.32, i32 %legacy_taken_mask.21, i32 %legacy_fallthrough_mask.21
  br label %BB_0488_07c8

BB_0488_07c8:                                     ; preds = %BB_0488_07a8
  %68 = zext i1 %isetrp_cmp1.32 to i32
  %69 = icmp ne i32 %68, 0
  br i1 %69, label %BB_0488_0830, label %BB_0488_07d0

BB_0488_07d0:                                     ; preds = %BB_0488_07c8
  %isetrp_cmp1.33 = icmp ne i32 %legacy_result.58, 0
  br label %BB_0488_07e0

BB_0488_07e0:                                     ; preds = %BB_0488_07d0
  %cond_not.13 = xor i1 %isetrp_cmp1.33, true
  %phi_cast_R144_bitcast = bitcast i32 %legacy_result.58 to float
  br i1 %cond_not.13, label %BB_0488_800007e0, label %BB_0488_07e8

BB_0488_800007e0:                                 ; preds = %BB_0488_07e0
  %mufu_src_bitcast.10 = bitcast i32 %mov.12 to float
  %mufu_rcp.12 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.10)
  br label %BB_0488_07e8

BB_0488_07e8:                                     ; preds = %BB_0488_800007e0, %BB_0488_07e0
  %phi.25 = phi float [ %mufu_rcp.12, %BB_0488_800007e0 ], [ %phi_cast_R144_bitcast, %BB_0488_07e0 ]
  %legacy_taken_mask.22 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.21, i1 %cond_not.13)
  br label %BB_0488_07f0

BB_0488_07f0:                                     ; preds = %BB_0488_07e8
  %70 = zext i1 %cond_not.13 to i32
  %71 = icmp ne i32 %70, 0
  br i1 %71, label %BB_0490, label %BB_0488_07f8

BB_0488_07f8:                                     ; preds = %BB_0488_07f0
  %ffma_lhs_bitcast.7 = bitcast i32 %mov.12 to float
  %ffma.28 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.7, float 0x43F0000000000000, float 0.000000e+00)
  %mufu_rcp.13 = call float @llvm.nvvm.rcp.approx.ftz.f(float %ffma.28)
  %ffma.29 = call float @llvm.fma.f32(float %ffma.28, float %mufu_rcp.13, float -1.000000e+00)
  %fadd_lhs_fneg.7 = fneg float %ffma.29
  %fadd.8 = fadd float %fadd_lhs_fneg.7, 0.000000e+00
  %ffma.30 = call float @llvm.fma.f32(float %mufu_rcp.13, float %fadd.8, float %mufu_rcp.13)
  %ffma.31 = call float @llvm.fma.f32(float %ffma.30, float 0x43F0000000000000, float 0.000000e+00)
  %phi_cast_R252_bitcast = bitcast float %ffma.28 to i32
  br label %BB_0490

BB_0488_0830:                                     ; preds = %BB_0488_07c8
  %legacy_a_wide.60 = zext i32 %shr_result.11 to i64
  %legacy_sum.60 = add i64 %legacy_a_wide.60, 4294967043
  %legacy_result.60 = trunc i64 %legacy_sum.60 to i32
  %isetrp_cmp1.34 = icmp ugt i32 %legacy_result.60, 1
  %legacy_taken_mask.23 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.21, i1 %isetrp_cmp1.34)
  br label %BB_0488_0848

BB_0488_0848:                                     ; preds = %BB_0488_0830
  %72 = zext i1 %isetrp_cmp1.34 to i32
  %73 = icmp ne i32 %72, 0
  br i1 %73, label %BB_0488_0928, label %BB_0488_0850

BB_0488_0850:                                     ; preds = %BB_0488_0848
  %.711 = and i32 %mov.12, 8388607
  %legacy_sum.61 = add i64 %legacy_a_wide.60, 4294967044
  %legacy_result.61 = trunc i64 %legacy_sum.61 to i32
  %.712 = or i32 %.711, 1065353216
  %shl.8 = shl i32 3, %legacy_result.60
  %mufu_src_bitcast.11 = bitcast i32 %.712 to float
  %mufu_rcp.14 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.11)
  %ffma.32 = call float @llvm.fma.f32(float %mufu_src_bitcast.11, float %mufu_rcp.14, float -1.000000e+00)
  %fadd_lhs_fneg.8 = fneg float %ffma.32
  %fadd.9 = fadd float %fadd_lhs_fneg.8, 0.000000e+00
  %ffma_rm.3 = call float @llvm.nvvm.fma.rm.f(float %mufu_rcp.14, float %fadd.9, float %mufu_rcp.14)
  %ffma_rp.3 = call float @llvm.nvvm.fma.rp.f(float %mufu_rcp.14, float %fadd.9, float %mufu_rcp.14)
  %legacy_source_bitcast.10 = bitcast float %ffma_rm.3 to i32
  %.713 = and i32 %legacy_source_bitcast.10, 8388607
  %.715 = and i32 %legacy_source_bitcast.10, 2139095040
  %.716 = icmp eq i32 %.715, 0
  %.717 = and i32 %legacy_source_bitcast.10, -2147483648
  %.718 = select i1 %.716, i32 %.717, i32 %legacy_source_bitcast.10
  %.719 = bitcast i32 %.718 to float
  %.720 = bitcast float %ffma_rp.3 to i32
  %.721 = and i32 %.720, 2139095040
  %.722 = icmp eq i32 %.721, 0
  %.723 = and i32 %.720, -2147483648
  %.724 = select i1 %.722, i32 %.723, i32 %.720
  %.725 = bitcast i32 %.724 to float
  %.726 = fcmp une float %.719, %.725
  %.728 = select i1 %.726, i32 -1, i32 0
  %.729 = or i32 %.713, 8388608
  %legacy_a_wide.62 = zext i32 %.728 to i64
  %legacy_a_complement.10 = xor i64 %legacy_a_wide.62, 4294967295
  %legacy_a_negate.10 = add i64 %legacy_a_complement.10, 1
  %legacy_result.62 = trunc i64 %legacy_a_negate.10 to i32
  %.730 = and i32 %shl.8, %.729
  %.731 = xor i32 %legacy_result.62, -1
  %.732 = and i32 %.731, %legacy_result.60
  %.733 = and i32 %.732, %.729
  %.735 = xor i32 %legacy_result.60, -1
  %.736 = xor i32 %.729, -1
  %.737 = and i32 %legacy_result.62, %.735
  %.738 = and i32 %.737, %.736
  %.739 = or i32 %.733, %.738
  %.742 = and i32 %.737, %.729
  %.743 = or i32 %.739, %.742
  %.745 = and i32 %legacy_result.62, %legacy_result.60
  %.746 = and i32 %.745, %.736
  %.747 = or i32 %.743, %.746
  %.749 = and i32 %.745, %.729
  %.750 = or i32 %.747, %.749
  %.751 = icmp ne i32 %.750, 0
  %shr_overflow.12 = icmp ugt i32 %legacy_result.61, 31
  %shr_clamp.12 = select i1 %shr_overflow.12, i32 31, i32 %legacy_result.61
  %shr_result.12 = lshr i32 %.729, %shr_clamp.12
  %shr_zero.9 = select i1 %shr_overflow.12, i32 0, i32 %shr_result.12
  %shr_result.13 = lshr i32 %.730, %legacy_result.60
  %.752 = and i32 %shr_result.13, 2
  %.753 = icmp ne i32 %.752, 0
  %.754 = and i32 %shr_result.13, 1
  %.755 = icmp ne i32 %.754, 0
  %.756 = or i1 %.751, %.753
  %isetrp_cmp1.35 = icmp eq i32 %.711, 0
  %.760 = and i1 %.755, %.756
  br label %BB_0488_0908

BB_0488_0908:                                     ; preds = %BB_0488_0850
  %74 = zext i1 %.760 to i32
  %75 = icmp ne i32 %74, 0
  br i1 %75, label %BB_0488_80000908, label %BB_0488_0910

BB_0488_80000908:                                 ; preds = %BB_0488_0908
  %legacy_a_wide.63 = zext i32 %shr_zero.9 to i64
  %legacy_sum.63 = add i64 %legacy_a_wide.63, 1
  %legacy_result.63 = trunc i64 %legacy_sum.63 to i32
  br label %BB_0488_0910

BB_0488_0910:                                     ; preds = %BB_0488_80000908, %BB_0488_0908
  %phi.26 = phi i32 [ %legacy_result.63, %BB_0488_80000908 ], [ %shr_zero.9, %BB_0488_0908 ]
  br i1 %isetrp_cmp1.35, label %BB_0488_80000910, label %BB_0488_0918

BB_0488_80000910:                                 ; preds = %BB_0488_0910
  %shl.9 = shl i32 %phi.26, 1
  br label %BB_0488_0918

BB_0488_0918:                                     ; preds = %BB_0488_80000910, %BB_0488_0910
  %phi.27 = phi i32 [ %shl.9, %BB_0488_80000910 ], [ %phi.26, %BB_0488_0910 ]
  %.769 = xor i32 %phi.27, -1
  %.770 = and i32 %.769, -2147483648
  %.771 = and i32 %.770, %mov.12
  %.774 = xor i32 %mov.12, -1
  %.775 = and i32 %phi.27, 2147483647
  %.776 = and i32 %.775, %.774
  %.777 = or i32 %.771, %.776
  %.780 = and i32 %.775, %mov.12
  %.781 = or i32 %.777, %.780
  %.783 = and i32 %phi.27, -2147483648
  %.784 = and i32 %.783, %.774
  %.785 = or i32 %.781, %.784
  %.787 = and i32 %.783, %mov.12
  %.788 = or i32 %.785, %.787
  %phi_cast_R281_bitcast = bitcast i32 %.788 to float
  br label %BB_0490

BB_0488_0928:                                     ; preds = %BB_0488_0848
  %mufu_src_bitcast.12 = bitcast i32 %mov.12 to float
  %mufu_rcp.15 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.12)
  br label %BB_0490

BB_0490:                                          ; preds = %BB_0488_0928, %BB_0488_0918, %BB_0488_07f8, %BB_0488_07f0
  %phi.28 = phi float [ %ffma.31, %BB_0488_07f8 ], [ %phi_cast_R281_bitcast, %BB_0488_0918 ], [ %mufu_rcp.15, %BB_0488_0928 ], [ %phi.25, %BB_0488_07f0 ]
  %phi.29 = phi i32 [ %phi_cast_R252_bitcast, %BB_0488_07f8 ], [ %mov.12, %BB_0488_0918 ], [ %mov.12, %BB_0488_0928 ], [ %mov.12, %BB_0488_07f0 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.20)
  %legacy_join_live_mask.3 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.20, i1 true)
  br label %BB_04d0

BB_04a8:                                          ; preds = %BB_0470
  %mufu_src_bitcast.13 = bitcast i32 %mov.11 to float
  %mufu_rcp.16 = call float @llvm.nvvm.rcp.approx.ftz.f(float %mufu_src_bitcast.13)
  %ffma_rhs.4 = load float, ptr %.49, align 4
  %ffma.33 = call float @llvm.fma.f32(float %mufu_rcp.16, float %ffma_rhs.4, float -1.000000e+00)
  %fadd_lhs_fneg.9 = fneg float %ffma.33
  %fadd.10 = fadd float %fadd_lhs_fneg.9, 0.000000e+00
  %ffma.34 = call float @llvm.fma.f32(float %mufu_rcp.16, float %fadd.10, float %mufu_rcp.16)
  %phi_cast_R256_bitcast = bitcast float %fadd.10 to i32
  br label %BB_04d0

BB_04d0:                                          ; preds = %BB_0720, %BB_04a8, %BB_0490
  %phi.30 = phi i32 [ 0, %BB_0490 ], [ 0, %BB_04a8 ], [ %legacy_result.65, %BB_0720 ]
  %phi.31 = phi float [ %phi.28, %BB_0490 ], [ %ffma.34, %BB_04a8 ], [ %phi.31, %BB_0720 ]
  %phi.32 = phi i32 [ %legacy_result.56, %BB_0490 ], [ %legacy_result.56, %BB_04a8 ], [ %legacy_result.66, %BB_0720 ]
  %phi.33 = phi i32 [ %legacy_join_live_mask.3, %BB_0490 ], [ %legacy_path_mask.20, %BB_04a8 ], [ %legacy_path_mask.26, %BB_0720 ]
  %phi.34 = phi i32 [ %phi.29, %BB_0490 ], [ %phi_cast_R256_bitcast, %BB_04a8 ], [ %phi.35, %BB_0720 ]
  %isetrp_cmp1.36 = icmp sgt i32 %tid_y, %phi.30
  %legacy_a_wide.64 = zext i32 %phi.30 to i64
  %legacy_a_complement.11 = xor i64 %legacy_a_wide.64, 4294967295
  %legacy_a_negate.11 = add i64 %legacy_a_complement.11, 1
  %legacy_sum.64 = add i64 %legacy_a_negate.11, 14
  %legacy_result.64 = trunc i64 %legacy_sum.64 to i32
  %isetrp_cmp1.37 = icmp ne i32 %phi.32, -1
  %.795 = lshr i32 %phi.34, 16
  %.796 = trunc i32 %.795 to i16
  %.797 = zext i16 %.796 to i32
  %xmad_psl.3 = shl i32 %.797, 16
  %isetrp_cmp1.38 = icmp sgt i32 %tid_x, %legacy_result.64
  %isetrp_src_not.4 = xor i1 %isetrp_cmp1.36, true
  %isetrp_cmp1.39 = icmp sgt i32 %tid_y, %legacy_result.64
  %isetrp_cmp2.39 = or i1 %isetrp_cmp1.39, %isetrp_src_not.4
  %isetrp_cmp1.40 = icmp sle i32 %tid_x, %phi.30
  %isetrp_cmp2.40 = or i1 %isetrp_cmp1.40, %isetrp_cmp1.38
  %.800 = or i1 %isetrp_cmp2.39, %isetrp_cmp2.29
  %.804 = or i1 %.800, %isetrp_cmp2.30
  %.808 = or i1 %isetrp_cmp2.40, %.804
  %legacy_taken_mask.24 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %phi.33, i1 %.808)
  %.812 = xor i32 %legacy_taken_mask.24, -1
  %legacy_fallthrough_mask.24 = and i32 %phi.33, %.812
  %legacy_path_mask.24 = select i1 %.808, i32 %legacy_taken_mask.24, i32 %legacy_fallthrough_mask.24
  br label %BB_0530

BB_0530:                                          ; preds = %BB_04d0
  %76 = zext i1 %.808 to i32
  %77 = icmp ne i32 %76, 0
  br i1 %77, label %BB_0678, label %BB_0538

BB_0538:                                          ; preds = %BB_0530
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %lds_shared_addr_winoff = and i32 %legacy_result.40, 16777215
  %.815 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff
  %lds = load volatile float, ptr addrspace(3) %.815, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %lds_shared_addr_winoff.1 = and i32 %legacy_result.39, 16777215
  %.816 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.1
  %lds.1 = load volatile float, ptr addrspace(3) %.816, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %lds_shared_addr_winoff.2 = and i32 %legacy_result.9, 16777215
  %.817 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.2
  %lds.2 = load volatile float, ptr addrspace(3) %.817, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %lds_addr_memaddr_offset_add = add i32 %legacy_result.9, 1024
  %lds_shared_addr_winoff.3 = and i32 %lds_addr_memaddr_offset_add, 16777215
  %.818 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.3
  %lds.3 = load volatile i32, ptr addrspace(3) %.818, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %fadd.11 = fadd float %lds, %lds.1
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %lds_shared_addr_winoff.4 = and i32 %legacy_result.49, 16777215
  %.819 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.4
  %lds.4 = load volatile float, ptr addrspace(3) %.819, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %lds_shared_addr_winoff.5 = and i32 %legacy_result.48, 16777215
  %.820 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.5
  %lds.5 = load volatile float, ptr addrspace(3) %.820, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %f2f_ext.3 = fpext float %lds.2 to double
  %"R15:R14_bitcast" = bitcast double %f2f_ext.3 to i64
  %fadd_lhs_fneg.10 = fneg float %lds.2
  %fadd.12 = fadd float %fadd_lhs_fneg.10, 8.000000e+01
  %fmul = fmul float %phi.31, %fadd.12
  %fadd.13 = fadd float %lds.4, %lds.5
  %dadd_lhs_bitcast = bitcast i64 %"R15:R14_bitcast" to double
  %dadd = fadd double %dadd_lhs_bitcast, %dadd_lhs_bitcast
  %"R19:R18_bitcast" = bitcast double %dadd to i64
  %f2f_ext.4 = fpext float %fadd.11 to double
  %"R29:R28_bitcast" = bitcast double %f2f_ext.4 to i64
  %dadd_lhs_bitcast.1 = bitcast i64 %"R29:R28_bitcast" to double
  %dadd_rhs_bitcast.1 = bitcast i64 %"R19:R18_bitcast" to double
  %dadd_rhs_fneg = fneg double %dadd_rhs_bitcast.1
  %dadd.1 = fadd double %dadd_lhs_bitcast.1, %dadd_rhs_fneg
  %"R29:R28_bitcast.1" = bitcast double %dadd.1 to i64
  %f2f_src_bitcast = bitcast i32 %lds.3 to float
  %f2f_ext.5 = fpext float %f2f_src_bitcast to double
  %"R21:R20_bitcast" = bitcast double %f2f_ext.5 to i64
  %dfma_lhs_bitcast = bitcast i64 %"R11:R10_bitcast" to double
  %dfma_rhs_bitcast = bitcast i64 %"R29:R28_bitcast.1" to double
  %dfma_addend_bitcast = bitcast i64 %"R21:R20_bitcast" to double
  %dfma = call double @llvm.fma.f64(double %dfma_lhs_bitcast, double %dfma_rhs_bitcast, double %dfma_addend_bitcast)
  %"R21:R20_bitcast.1" = bitcast double %dfma to i64
  %f2f_ext.6 = fpext float %fadd.13 to double
  %"R25:R24_bitcast" = bitcast double %f2f_ext.6 to i64
  %dadd_rhs_bitcast.2 = bitcast i64 %"R25:R24_bitcast" to double
  %dadd.2 = fadd double %dadd_rhs_fneg, %dadd_rhs_bitcast.2
  %"R19:R18_bitcast.1" = bitcast double %dadd.2 to i64
  %dfma_lhs_bitcast.1 = bitcast i64 %"R13:R12_bitcast" to double
  %dfma_rhs_bitcast.1 = bitcast i64 %"R19:R18_bitcast.1" to double
  %dfma_addend_bitcast.1 = bitcast i64 %"R21:R20_bitcast.1" to double
  %dfma.1 = call double @llvm.fma.f64(double %dfma_lhs_bitcast.1, double %dfma_rhs_bitcast.1, double %dfma_addend_bitcast.1)
  %"R19:R18_bitcast.2" = bitcast double %dfma.1 to i64
  %f2f_ext.7 = fpext float %fmul to double
  %"R17:R16_bitcast" = bitcast double %f2f_ext.7 to i64
  %dadd_lhs_bitcast.3 = bitcast i64 %"R19:R18_bitcast.2" to double
  %dadd_rhs_bitcast.3 = bitcast i64 %"R17:R16_bitcast" to double
  %dadd.3 = fadd double %dadd_lhs_bitcast.3, %dadd_rhs_bitcast.3
  %"R17:R16_bitcast.1" = bitcast double %dadd.3 to i64
  %dfma_lhs_bitcast.2 = bitcast i64 %"R9:R8_bitcast" to double
  %dfma_rhs_bitcast.2 = bitcast i64 %"R17:R16_bitcast.1" to double
  %dfma.2 = call double @llvm.fma.f64(double %dfma_lhs_bitcast.2, double %dfma_rhs_bitcast.2, double %dadd_lhs_bitcast)
  %"R17:R16_bitcast.2" = bitcast double %dfma.2 to i64
  %f2f_src_bitcast.1 = bitcast i64 %"R17:R16_bitcast.2" to double
  %f2f_trunc = fptrunc double %f2f_src_bitcast.1 to float
  %R246_bitcast = bitcast float %f2f_trunc to i32
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  %sts_addr_memaddr_offset_add.1 = add i32 %legacy_result.9, 2048
  %sts_shared_addr_winoff.2 = and i32 %sts_addr_memaddr_offset_add.1, 16777215
  %.821 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_shared_addr_winoff.2
  store volatile i32 %R246_bitcast, ptr addrspace(3) %.821, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.24)
  br label %BB_0678

BB_0678:                                          ; preds = %BB_0538, %BB_0530
  %phi.35 = phi i32 [ 1, %BB_0538 ], [ %xmad_psl.3, %BB_0530 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %phi.33)
  %legacy_join_live_mask.4 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %phi.33, i1 true)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %legacy_branch_predicate_not.9 = xor i1 %isetrp_cmp1.37, true
  %legacy_taken_mask.25 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_join_live_mask.4, i1 %legacy_branch_predicate_not.9)
  %.824 = xor i32 %legacy_taken_mask.25, -1
  %legacy_fallthrough_mask.25 = and i32 %legacy_join_live_mask.4, %.824
  %legacy_path_mask.25 = select i1 %legacy_branch_predicate_not.9, i32 %legacy_taken_mask.25, i32 %legacy_fallthrough_mask.25
  br label %BB_0698

BB_0698:                                          ; preds = %BB_0678
  %78 = zext i1 %legacy_branch_predicate_not.9 to i32
  %79 = icmp ne i32 %78, 0
  br i1 %79, label %BB_0728, label %BB_06a0

BB_06a0:                                          ; preds = %BB_0698
  %.833 = sext i32 %phi.35 to i64
  %.839 = and i64 %.833, 65535
  %.843 = shl i64 %.839, 48
  %.844 = ashr i64 %.843, 48
  %.845 = trunc i64 %.844 to i32
  %legacy_sum.65 = add i64 %legacy_a_wide.64, 1
  %legacy_result.65 = trunc i64 %legacy_sum.65 to i32
  %legacy_a_wide.66 = zext i32 %phi.32 to i64
  %legacy_sum.66 = add i64 %legacy_a_wide.66, 1
  %legacy_result.66 = trunc i64 %legacy_sum.66 to i32
  %isetrp_cmp1.41 = icmp ne i32 %.845, 0
  %isetrp_rhs.4 = load i32, ptr %.16, align 4
  %isetrp_cmp1.42 = icmp sge i32 %legacy_result.65, %isetrp_rhs.4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.25)
  br label %BB_06d0

BB_06d0:                                          ; preds = %BB_06a0
  %80 = zext i1 %isetrp_cmp1.41 to i32
  %81 = icmp ne i32 %80, 0
  br i1 %81, label %BB_800006d0, label %BB_06d8

BB_800006d0:                                      ; preds = %BB_06d0
  %lds_addr_memaddr_offset_add.1 = add i32 %legacy_result.9, 2048
  %lds_shared_addr_winoff.6 = and i32 %lds_addr_memaddr_offset_add.1, 16777215
  %.850 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.6
  %lds.6 = load volatile i32, ptr addrspace(3) %.850, align 4
  br label %BB_06d8

BB_06d8:                                          ; preds = %BB_800006d0, %BB_06d0
  %phi.36 = phi i32 [ %lds.6, %BB_800006d0 ], [ %.845, %BB_06d0 ]
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.25)
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.25)
  br label %BB_06e8

BB_06e8:                                          ; preds = %BB_06d8
  %82 = zext i1 %isetrp_cmp1.41 to i32
  %83 = icmp ne i32 %82, 0
  br i1 %83, label %BB_800006e8, label %BB_06f0

BB_800006e8:                                      ; preds = %BB_06e8
  %sts_shared_addr_winoff.3 = and i32 %legacy_result.9, 16777215
  %.854 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %sts_shared_addr_winoff.3
  store volatile i32 %phi.36, ptr addrspace(3) %.854, align 4
  br label %BB_06f0

BB_06f0:                                          ; preds = %BB_800006e8, %BB_06e8
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.25)
  call void @llvm.nvvm.barrier0()
  call void @llvm.nvvm.membar.cta()
  %legacy_branch_predicate_not.10 = xor i1 %isetrp_cmp1.42, true
  %legacy_taken_mask.26 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %legacy_path_mask.25, i1 %legacy_branch_predicate_not.10)
  %.857 = xor i32 %legacy_taken_mask.26, -1
  %legacy_fallthrough_mask.26 = and i32 %legacy_path_mask.25, %.857
  %legacy_path_mask.26 = select i1 %legacy_branch_predicate_not.10, i32 %legacy_taken_mask.26, i32 %legacy_fallthrough_mask.26
  br label %BB_0720

BB_0720:                                          ; preds = %BB_06f0
  %84 = zext i1 %legacy_branch_predicate_not.10 to i32
  %85 = icmp ne i32 %84, 0
  br i1 %85, label %BB_04d0, label %BB_0728

BB_0728:                                          ; preds = %BB_0720, %BB_0698, %BB_0178
  %phi.37 = phi i32 [ %legacy_path_mask, %BB_0178 ], [ %legacy_path_mask.25, %BB_0698 ], [ %legacy_path_mask.26, %BB_0720 ]
  %phi.38 = phi i32 [ 0, %BB_0178 ], [ %phi.35, %BB_0698 ], [ %phi.35, %BB_0720 ]
  %.860 = and i32 %phi.38, 255
  %.861 = icmp ne i32 %.860, 0
  %legacy_branch_predicate_not.11 = xor i1 %.861, true
  %legacy_taken_mask.27 = call i32 @llvm.nvvm.vote.ballot.sync(i32 %phi.37, i1 %legacy_branch_predicate_not.11)
  %.862 = xor i32 %legacy_taken_mask.27, -1
  %legacy_fallthrough_mask.27 = and i32 %phi.37, %.862
  %legacy_path_mask.27 = select i1 %legacy_branch_predicate_not.11, i32 %legacy_taken_mask.27, i32 %legacy_fallthrough_mask.27
  br label %BB_0750

BB_0750:                                          ; preds = %BB_0728
  %86 = zext i1 %legacy_branch_predicate_not.11 to i32
  %87 = icmp ne i32 %86, 0
  br i1 %87, label %BB_80000750, label %BB_0758

BB_0758:                                          ; preds = %BB_0750
  %shr_result.14 = ashr i32 %xmad_sum.8, 30
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.27)
  %lds_addr_memaddr_offset_add.2 = add i32 %legacy_result.9, 2048
  %lds_shared_addr_winoff.7 = and i32 %lds_addr_memaddr_offset_add.2, 16777215
  %.865 = getelementptr inbounds [3072 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_shared_addr_winoff.7
  %lds.7 = load volatile i32, ptr addrspace(3) %.865, align 4
  call void @llvm.nvvm.bar.warp.sync(i32 %legacy_path_mask.27)
  %legacy_a_shift.8 = shl i32 %xmad_sum.8, 2
  %legacy_b.9 = load i32, ptr %.25, align 4
  %.869 = getelementptr inbounds [400 x i8], ptr %param_local, i64 0, i64 348
  %legacy_b.10 = load i32, ptr %.869, align 4
  %88 = zext i32 %legacy_a_shift.8 to i64
  %89 = zext i32 %legacy_b.9 to i64
  %90 = zext i32 %shr_result.14 to i64
  %91 = shl i64 %90, 32
  %92 = zext i32 %legacy_b.10 to i64
  %93 = shl i64 %92, 32
  %94 = add i64 %88, %89
  %95 = add i64 %94, %91
  %96 = add i64 %95, %93
  %"R127:R114_addr_ptr" = inttoptr i64 %96 to ptr addrspace(1)
  store i32 %lds.7, ptr addrspace(1) %"R127:R114_addr_ptr", align 4
  ret void

BB_80000750:                                      ; preds = %BB_0750
  ret void
}

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.vote.ballot.sync(i32, i1) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #2

; Function Attrs: nocallback nounwind
declare void @llvm.nvvm.membar.cta() #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rcp.approx.ftz.f(float) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.nvvm.rsqrt.approx.ftz.f(float) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.nvvm.fma.rz.f(float, float, float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.nvvm.fma.rp.f(float, float, float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.nvvm.fma.rm.f(float, float, float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fma.f64(double, double, double) #1

attributes #0 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { convergent nocallback nounwind }
attributes #3 = { nocallback nounwind }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(none) }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z14calculate_tempiPfS_S_iiiiffffff, !"kernel", i32 1}
