; ModuleID = "/tmp/culifter-sm52-10787/round14/hotspot"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [3072 x i8], align 16
define void @"_Z14calculate_tempiPfS_S_iiiiffffff"(i32 %"arg_320", i64 %"arg_328", i64 %"arg_336", i64 %"arg_344", i32 %"arg_352", i32 %"arg_356", i32 %"arg_360", i32 %"arg_364", i32 %"arg_368", i32 %"arg_372", i32 %"arg_376", i32 %"arg_380", i32 %"arg_384", i32 %"arg_388")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [400 x i8], align 16
  %".16" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 320
  %".17" = bitcast i8* %".16" to i32*
  store i32 %"arg_320", i32* %".17", align 64
  %".19" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 328
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_328", i64* %".20", align 8
  %".22" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 336
  %".23" = bitcast i8* %".22" to i64*
  store i64 %"arg_336", i64* %".23", align 16
  %".25" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 344
  %".26" = bitcast i8* %".25" to i64*
  store i64 %"arg_344", i64* %".26", align 8
  %".28" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 352
  %".29" = bitcast i8* %".28" to i32*
  store i32 %"arg_352", i32* %".29", align 32
  %".31" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 356
  %".32" = bitcast i8* %".31" to i32*
  store i32 %"arg_356", i32* %".32", align 4
  %".34" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 360
  %".35" = bitcast i8* %".34" to i32*
  store i32 %"arg_360", i32* %".35", align 8
  %".37" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 364
  %".38" = bitcast i8* %".37" to i32*
  store i32 %"arg_364", i32* %".38", align 4
  %".40" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 368
  %".41" = bitcast i8* %".40" to i32*
  store i32 %"arg_368", i32* %".41", align 16
  %".43" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 372
  %".44" = bitcast i8* %".43" to i32*
  store i32 %"arg_372", i32* %".44", align 4
  %".46" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 376
  %".47" = bitcast i8* %".46" to i32*
  store i32 %"arg_376", i32* %".47", align 8
  %".49" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 380
  %".50" = bitcast i8* %".49" to i32*
  store i32 %"arg_380", i32* %".50", align 4
  %".52" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 384
  %".53" = bitcast i8* %".52" to i32*
  store i32 %"arg_384", i32* %".53", align 128
  %".55" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 388
  %".56" = bitcast i8* %".55" to i32*
  store i32 %"arg_388", i32* %".56", align 4
  %"legacy_entry_mask" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 4294967295, i1 1)
  %".58" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 320
  %".59" = bitcast i8* %".58" to i32*
  %"mov" = load i32, i32* %".59"
  %"ctaid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()
  %"legacy_a_wide" = zext i32 0 to i64
  %".60" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 364
  %".61" = bitcast i8* %".60" to i32*
  %"legacy_b" = load i32, i32* %".61"
  %"legacy_b_wide" = zext i32 %"legacy_b" to i64
  %"legacy_b_complement" = xor i64 %"legacy_b_wide", 4294967295
  %"legacy_b_negate" = add i64 %"legacy_b_complement", 1
  %"legacy_sum" = add i64 %"legacy_a_wide", %"legacy_b_negate"
  %"legacy_result" = trunc i64 %"legacy_sum" to i32
  %"ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  %"legacy_a_wide.1" = zext i32 0 to i64
  %".62" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 360
  %".63" = bitcast i8* %".62" to i32*
  %"legacy_b.1" = load i32, i32* %".63"
  %"legacy_b_wide.1" = zext i32 %"legacy_b.1" to i64
  %"legacy_b_complement.1" = xor i64 %"legacy_b_wide.1", 4294967295
  %"legacy_b_negate.1" = add i64 %"legacy_b_complement.1", 1
  %"legacy_sum.1" = add i64 %"legacy_a_wide.1", %"legacy_b_negate.1"
  %"legacy_result.1" = trunc i64 %"legacy_sum.1" to i32
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"legacy_a_shift" = shl i32 %"mov", 1
  %"legacy_a_wide.2" = zext i32 %"legacy_a_shift" to i64
  %"legacy_a_complement" = xor i64 %"legacy_a_wide.2", 4294967295
  %"legacy_a_negate" = add i64 %"legacy_a_complement", 1
  %"legacy_b_wide.2" = zext i32 16 to i64
  %"legacy_sum.2" = add i64 %"legacy_a_negate", %"legacy_b_wide.2"
  %"legacy_result.2" = trunc i64 %"legacy_sum.2" to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".64" = trunc i32 %"legacy_result.2" to i16
  %".65" = zext i16 %".64" to i32
  %".66" = trunc i32 %"ctaid_y" to i16
  %".67" = zext i16 %".66" to i32
  %"xmad_product" = mul i32 %".65", %".67"
  %"xmad_sum" = add i32 %"xmad_product", %"legacy_result"
  %".68" = trunc i32 %"legacy_result.2" to i16
  %".69" = zext i16 %".68" to i32
  %".70" = lshr i32 %"ctaid_y", 16
  %".71" = trunc i32 %".70" to i16
  %".72" = zext i16 %".71" to i32
  %"xmad_product.1" = mul i32 %".69", %".72"
  %"xmad_sum.1" = add i32 %"xmad_product.1", 0
  %".73" = and i32 %"xmad_sum.1", 65535
  %".74" = shl i32 %"ctaid_y", 16
  %"xmad_merge" = or i32 %".73", %".74"
  %".75" = trunc i32 %"legacy_result.2" to i16
  %".76" = zext i16 %".75" to i32
  %".77" = trunc i32 %"ctaid_x" to i16
  %".78" = zext i16 %".77" to i32
  %"xmad_product.2" = mul i32 %".76", %".78"
  %"xmad_sum.2" = add i32 %"xmad_product.2", %"legacy_result.1"
  %".79" = trunc i32 %"legacy_result.2" to i16
  %".80" = zext i16 %".79" to i32
  %".81" = lshr i32 %"ctaid_x", 16
  %".82" = trunc i32 %".81" to i16
  %".83" = zext i16 %".82" to i32
  %"xmad_product.3" = mul i32 %".80", %".83"
  %"xmad_sum.3" = add i32 %"xmad_product.3", 0
  %".84" = and i32 %"xmad_sum.3", 65535
  %".85" = shl i32 %"ctaid_x", 16
  %"xmad_merge.1" = or i32 %".84", %".85"
  %".86" = lshr i32 %"legacy_result.2", 16
  %".87" = trunc i32 %".86" to i16
  %".88" = zext i16 %".87" to i32
  %".89" = lshr i32 %"xmad_merge", 16
  %".90" = trunc i32 %".89" to i16
  %".91" = zext i16 %".90" to i32
  %"xmad_product.4" = mul i32 %".88", %".91"
  %"xmad_psl" = shl i32 %"xmad_product.4", 16
  %".92" = shl i32 %"xmad_merge", 16
  %"xmad_cbcc" = add i32 %"xmad_sum", %".92"
  %"xmad_sum.4" = add i32 %"xmad_psl", %"xmad_cbcc"
  %".93" = lshr i32 %"legacy_result.2", 16
  %".94" = trunc i32 %".93" to i16
  %".95" = zext i16 %".94" to i32
  %".96" = lshr i32 %"xmad_merge.1", 16
  %".97" = trunc i32 %".96" to i16
  %".98" = zext i16 %".97" to i32
  %"xmad_product.5" = mul i32 %".95", %".98"
  %"xmad_psl.1" = shl i32 %"xmad_product.5", 16
  %".99" = shl i32 %"xmad_merge.1", 16
  %"xmad_cbcc.1" = add i32 %"xmad_sum.2", %".99"
  %"xmad_sum.5" = add i32 %"xmad_psl.1", %"xmad_cbcc.1"
  %"legacy_a_wide.3" = zext i32 %"xmad_sum.4" to i64
  %"legacy_b_wide.3" = zext i32 %"tid_y" to i64
  %"legacy_sum.3" = add i64 %"legacy_a_wide.3", %"legacy_b_wide.3"
  %"legacy_result.3" = trunc i64 %"legacy_sum.3" to i32
  %"legacy_a_wide.4" = zext i32 %"xmad_sum.5" to i64
  %"legacy_b_wide.4" = zext i32 %"tid_x" to i64
  %"legacy_sum.4" = add i64 %"legacy_a_wide.4", %"legacy_b_wide.4"
  %"legacy_result.4" = trunc i64 %"legacy_sum.4" to i32
  %".100" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 356
  %".101" = bitcast i8* %".100" to i32*
  %"isetrp_rhs" = load i32, i32* %".101"
  %"isetrp_cmp1" = icmp sge i32 %"legacy_result.3", %"isetrp_rhs"
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %".102" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 352
  %".103" = bitcast i8* %".102" to i32*
  %"xmad_src1" = load i32, i32* %".103"
  %".104" = trunc i32 %"legacy_result.3" to i16
  %".105" = zext i16 %".104" to i32
  %".106" = lshr i32 %"xmad_src1", 16
  %".107" = trunc i32 %".106" to i16
  %".108" = zext i16 %".107" to i32
  %"xmad_product.6" = mul i32 %".105", %".108"
  %"xmad_sum.6" = add i32 %"xmad_product.6", 0
  %".109" = and i32 %"xmad_sum.6", 65535
  %".110" = shl i32 %"xmad_src1", 16
  %"xmad_merge.2" = or i32 %".109", %".110"
  %".111" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 352
  %".112" = bitcast i8* %".111" to i32*
  %"isetrp_rhs.1" = load i32, i32* %".112"
  %"isetrp_cmp1.1" = icmp sge i32 %"legacy_result.4", %"isetrp_rhs.1"
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P70_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_src_trunc" = trunc i32 %"P1_to_i32" to i1
  %"isetrp_src_not" = xor i1 %"isetrp_src_trunc", -1
  %"isetrp_cmp1.2" = icmp sgt i32 %"legacy_result.3", -1
  %"isetrp_src_to_i32.2" = zext i1 %"isetrp_src_not" to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"isetrp_src_trunc.1" = trunc i32 %"P70_to_i32" to i1
  %"isetrp_src_not.1" = xor i1 %"isetrp_src_trunc.1", -1
  %"isetrp_cmp1.3" = icmp sgt i32 %"legacy_result.4", -1
  %"isetrp_src_to_i32.3" = zext i1 %"isetrp_src_not.1" to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P13_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %".113" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 352
  %".114" = bitcast i8* %".113" to i32*
  %"xmad_src1.1" = load i32, i32* %".114"
  %".115" = trunc i32 %"legacy_result.3" to i16
  %".116" = zext i16 %".115" to i32
  %".117" = trunc i32 %"xmad_src1.1" to i16
  %".118" = zext i16 %".117" to i32
  %"xmad_product.7" = mul i32 %".116", %".118"
  %"xmad_sum.7" = add i32 %"xmad_product.7", %"legacy_result.4"
  %".119" = lshr i32 %"legacy_result.3", 16
  %".120" = trunc i32 %".119" to i16
  %".121" = zext i16 %".120" to i32
  %".122" = lshr i32 %"xmad_merge.2", 16
  %".123" = trunc i32 %".122" to i16
  %".124" = zext i16 %".123" to i32
  %"xmad_product.8" = mul i32 %".121", %".124"
  %"xmad_psl.2" = shl i32 %"xmad_product.8", 16
  %".125" = shl i32 %"xmad_merge.2", 16
  %"xmad_cbcc.2" = add i32 %"xmad_sum.7", %".125"
  %"xmad_sum.8" = add i32 %"xmad_psl.2", %"xmad_cbcc.2"
  %"legacy_source_trunc" = trunc i32 %"P13_to_i32" to i1
  %"legacy_pred_to_i32" = zext i1 %"legacy_source_trunc" to i32
  %"legacy_pred_to_i1" = icmp ne i32 %"legacy_pred_to_i32", 0
  %"legacy_source_trunc.1" = trunc i32 %"P14_to_i32" to i1
  %"legacy_pred_to_i32.1" = zext i1 %"legacy_source_trunc.1" to i32
  %"legacy_pred_to_i1.1" = icmp ne i32 %"legacy_pred_to_i32.1", 0
  %"legacy_pred_to_i32.2" = zext i1 1 to i32
  %"legacy_pred_to_i1.2" = icmp ne i32 %"legacy_pred_to_i32.2", 0
  %".126" = and i1 %"legacy_pred_to_i1", %"legacy_pred_to_i1.1"
  %".127" = and i1 %".126", %"legacy_pred_to_i1.2"
  %".128" = xor i1 %".126", -1
  %".129" = and i1 %".128", %"legacy_pred_to_i1.2"
  %"P22_to_i32" = zext i1 %".127" to i32
  br label %"BB_00d0"
BB_00d0:
  %"cond_trunc" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_800000d0", label %"BB_0110"
BB_800000d0:
  %"shl" = shl i32 %"xmad_sum.8", 2
  %"shr_overflow" = icmp ugt i32 30, 31
  %"shr_clamp" = select  i1 %"shr_overflow", i32 31, i32 30
  %"shr_result" = ashr i32 %"xmad_sum.8", %"shr_clamp"
  %"legacy_a_wide.5" = zext i32 %"shl" to i64
  %".132" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 336
  %".133" = bitcast i8* %".132" to i32*
  %"legacy_b.2" = load i32, i32* %".133"
  %"legacy_b_wide.5" = zext i32 %"legacy_b.2" to i64
  %"legacy_sum.5" = add i64 %"legacy_a_wide.5", %"legacy_b_wide.5"
  %"legacy_result.5" = trunc i64 %"legacy_sum.5" to i32
  %".134" = lshr i64 %"legacy_sum.5", 32
  %"legacy_cout" = trunc i64 %".134" to i1
  %"P3_to_i32" = zext i1 %"legacy_cout" to i32
  %"legacy_a_wide.6" = zext i32 %"shr_result" to i64
  %".135" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 340
  %".136" = bitcast i8* %".135" to i32*
  %"legacy_b.3" = load i32, i32* %".136"
  %"legacy_b_wide.6" = zext i32 %"legacy_b.3" to i64
  %"legacy_sum.6" = add i64 %"legacy_a_wide.6", %"legacy_b_wide.6"
  %"legacy_cin_trunc" = trunc i32 %"P3_to_i32" to i1
  %".137" = zext i1 %"legacy_cin_trunc" to i64
  %"legacy_sum_cin" = add i64 %"legacy_sum.6", %".137"
  %"legacy_result.6" = trunc i64 %"legacy_sum_cin" to i32
  %"legacy_a_wide.7" = zext i32 %"shl" to i64
  %".138" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 328
  %".139" = bitcast i8* %".138" to i32*
  %"legacy_b.4" = load i32, i32* %".139"
  %"legacy_b_wide.7" = zext i32 %"legacy_b.4" to i64
  %"legacy_sum.7" = add i64 %"legacy_a_wide.7", %"legacy_b_wide.7"
  %"legacy_result.7" = trunc i64 %"legacy_sum.7" to i32
  %".140" = lshr i64 %"legacy_sum.7", 32
  %"legacy_cout.1" = trunc i64 %".140" to i1
  %"P4_to_i32" = zext i1 %"legacy_cout.1" to i32
  %"ldg_addr_r0_ext" = zext i32 %"legacy_result.5" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"legacy_result.6" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R213:R165_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R213:R165_addr_ptr"
  %"legacy_a_wide.8" = zext i32 %"shr_result" to i64
  %".141" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 332
  %".142" = bitcast i8* %".141" to i32*
  %"legacy_b.5" = load i32, i32* %".142"
  %"legacy_b_wide.8" = zext i32 %"legacy_b.5" to i64
  %"legacy_sum.8" = add i64 %"legacy_a_wide.8", %"legacy_b_wide.8"
  %"legacy_cin_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %".143" = zext i1 %"legacy_cin_trunc.1" to i64
  %"legacy_sum_cin.1" = add i64 %"legacy_sum.8", %".143"
  %"legacy_result.8" = trunc i64 %"legacy_sum_cin.1" to i32
  %"ldg_addr_r0_ext.1" = zext i32 %"legacy_result.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"legacy_result.8" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R136:R70_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R136:R70_addr_ptr"
  br label %"BB_0110"
BB_0110:
  %"phi" = phi  i32 [%"ldg", %"BB_800000d0"], [%"xmad_merge.2", %"BB_00d0"]
  %"phi.1" = phi  i32 [%"ldg.1", %"BB_800000d0"], [0, %"BB_00d0"]
  %"isetrp_cmp1.4" = icmp sge i32 %"mov", 1
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"shl.1" = shl i32 %"tid_y", 6
  %"shl.2" = shl i32 %"tid_x", 2
  %"legacy_a_wide.9" = zext i32 %"shl.1" to i64
  %"legacy_b_wide.9" = zext i32 %"shl.2" to i64
  %"legacy_sum.9" = add i64 %"legacy_a_wide.9", %"legacy_b_wide.9"
  %"legacy_result.9" = trunc i64 %"legacy_sum.9" to i32
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0138"
BB_0138:
  %"cond_trunc.1" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_80000138", label %"BB_0140"
BB_80000138:
  %"sts_shared_addr_winoff" = and i32 %"legacy_result.9", 16777215
  %".147" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".147" to i32 addrspace(3)*
  store volatile i32 %"phi", i32 addrspace(3)* %"sts_shared_addr_cast"
  br label %"BB_0140"
BB_0140:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  br label %"BB_0150"
BB_0150:
  %"cond_trunc.2" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_trunc.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_80000150", label %"BB_0158"
BB_80000150:
  %"sts_addr_memaddr_offset_add" = add i32 %"legacy_result.9", 1024
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".152" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".152" to i32 addrspace(3)*
  store volatile i32 %"phi.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0158"
BB_0158:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_entry_mask")
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  %"legacy_branch_predicate_trunc" = trunc i32 %"P24_to_i32" to i1
  %"legacy_branch_predicate_not" = xor i1 %"legacy_branch_predicate_trunc", -1
  %"legacy_taken_mask" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_entry_mask", i1 %"legacy_branch_predicate_not")
  %".155" = xor i32 %"legacy_taken_mask", -1
  %"legacy_fallthrough_mask" = and i32 %"legacy_entry_mask", %".155"
  %"legacy_path_mask" = select  i1 %"legacy_branch_predicate_not", i32 %"legacy_taken_mask", i32 %"legacy_fallthrough_mask"
  br label %"BB_0178"
BB_0178:
  %"cond_trunc.3" = trunc i32 %"P24_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_0728", label %"BB_0180"
BB_0180:
  %".158" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 368
  %".159" = bitcast i8* %".158" to float*
  %"mov.1" = load float, float* %".159"
  %"mufu_rcp" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mov.1")
  %"legacy_a_wide.10" = zext i32 %"xmad_sum.4" to i64
  %"legacy_b_wide.10" = zext i32 15 to i64
  %"legacy_sum.10" = add i64 %"legacy_a_wide.10", %"legacy_b_wide.10"
  %"legacy_result.10" = trunc i64 %"legacy_sum.10" to i32
  %"legacy_a_wide.11" = zext i32 %"xmad_sum.4" to i64
  %"legacy_a_complement.1" = xor i64 %"legacy_a_wide.11", 4294967295
  %"legacy_a_negate.1" = add i64 %"legacy_a_complement.1", 1
  %"legacy_b_wide.11" = zext i32 0 to i64
  %"legacy_sum.11" = add i64 %"legacy_a_negate.1", %"legacy_b_wide.11"
  %"legacy_result.11" = trunc i64 %"legacy_sum.11" to i32
  %"shr_overflow.1" = icmp ugt i32 31, 31
  %"shr_clamp.1" = select  i1 %"shr_overflow.1", i32 31, i32 31
  %"shr_result.1" = ashr i32 %"xmad_sum.4", %"shr_clamp.1"
  %"legacy_a_wide.12" = zext i32 %"xmad_sum.4" to i64
  %"legacy_a_complement.2" = xor i64 %"legacy_a_wide.12", 4294967295
  %"legacy_a_negate.2" = add i64 %"legacy_a_complement.2", 1
  %"legacy_b_wide.12" = zext i32 -15 to i64
  %"legacy_sum.12" = add i64 %"legacy_a_negate.2", %"legacy_b_wide.12"
  %"legacy_result.12" = trunc i64 %"legacy_sum.12" to i32
  %"legacy_a_wide.13" = zext i32 %"xmad_sum.5" to i64
  %"legacy_b_wide.13" = zext i32 15 to i64
  %"legacy_sum.13" = add i64 %"legacy_a_wide.13", %"legacy_b_wide.13"
  %"legacy_result.13" = trunc i64 %"legacy_sum.13" to i32
  %"legacy_a_wide.14" = zext i32 %"xmad_sum.5" to i64
  %"legacy_a_complement.3" = xor i64 %"legacy_a_wide.14", 4294967295
  %"legacy_a_negate.3" = add i64 %"legacy_a_complement.3", 1
  %"legacy_b_wide.14" = zext i32 0 to i64
  %"legacy_sum.14" = add i64 %"legacy_a_negate.3", %"legacy_b_wide.14"
  %"legacy_result.14" = trunc i64 %"legacy_sum.14" to i32
  %".160" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 356
  %".161" = bitcast i8* %".160" to i32*
  %"isetrp_rhs.2" = load i32, i32* %".161"
  %"isetrp_cmp1.5" = icmp sge i32 %"legacy_result.10", %"isetrp_rhs.2"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %".162" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 384
  %".163" = bitcast i8* %".162" to float*
  %"mov.2" = load float, float* %".163"
  %"shr_overflow.2" = icmp ugt i32 31, 31
  %"shr_clamp.2" = select  i1 %"shr_overflow.2", i32 31, i32 31
  %"shr_result.2" = ashr i32 %"xmad_sum.5", %"shr_clamp.2"
  %"legacy_a_wide.15" = zext i32 %"xmad_sum.5" to i64
  %"legacy_a_complement.4" = xor i64 %"legacy_a_wide.15", 4294967295
  %"legacy_a_negate.4" = add i64 %"legacy_a_complement.4", 1
  %"legacy_b_wide.15" = zext i32 -15 to i64
  %"legacy_sum.15" = add i64 %"legacy_a_negate.4", %"legacy_b_wide.15"
  %"legacy_result.15" = trunc i64 %"legacy_sum.15" to i32
  %".164" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 352
  %".165" = bitcast i8* %".164" to i32*
  %"isetrp_rhs.3" = load i32, i32* %".165"
  %"isetrp_cmp1.6" = icmp sge i32 %"legacy_result.13", %"isetrp_rhs.3"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P66_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"legacy_a_wide.16" = zext i32 %"legacy_result.12" to i64
  %".166" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 356
  %".167" = bitcast i8* %".166" to i32*
  %"legacy_b.6" = load i32, i32* %".167"
  %"legacy_b_wide.16" = zext i32 %"legacy_b.6" to i64
  %"legacy_sum.16" = add i64 %"legacy_a_wide.16", %"legacy_b_wide.16"
  %"legacy_result.16" = trunc i64 %"legacy_sum.16" to i32
  %".168" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 368
  %".169" = bitcast i8* %".168" to float*
  %"ffma_rhs" = load float, float* %".169"
  %"ffma_rhs_fneg" = fneg float %"ffma_rhs"
  %"ffma_addend_bitcast" = bitcast i32 1065353216 to float
  %"ffma" = call float @"llvm.fma.f32"(float %"mufu_rcp", float %"ffma_rhs_fneg", float %"ffma_addend_bitcast")
  %"fchk_num_bits" = bitcast float %"mov.2" to i32
  %".170" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 368
  %".171" = bitcast i8* %".170" to float*
  %"fchk_den" = load float, float* %".171"
  %"fchk_den_bits" = bitcast float %"fchk_den" to i32
  %"fchk_aden" = and i32 %"fchk_den_bits", 2147483647
  %"fchk_anum" = and i32 %"fchk_num_bits", 2147483647
  %"fchk_den_subz" = icmp ult i32 %"fchk_aden", 8388608
  %"fchk_den_infnan" = icmp uge i32 %"fchk_aden", 2139095040
  %"fchk_num_infnan" = icmp uge i32 %"fchk_anum", 2139095040
  %"fchk_den_bad" = or i1 %"fchk_den_subz", %"fchk_den_infnan"
  %"fchk_px" = or i1 %"fchk_den_bad", %"fchk_num_infnan"
  %"P25_to_i32" = zext i1 %"fchk_px" to i32
  %".172" = and i32 %"shr_result.2", %"legacy_result.14"
  %"legacy_a_wide.17" = zext i32 %"legacy_result.15" to i64
  %".173" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 352
  %".174" = bitcast i8* %".173" to i32*
  %"legacy_b.7" = load i32, i32* %".174"
  %"legacy_b_wide.17" = zext i32 %"legacy_b.7" to i64
  %"legacy_sum.17" = add i64 %"legacy_a_wide.17", %"legacy_b_wide.17"
  %"legacy_result.17" = trunc i64 %"legacy_sum.17" to i32
  %".175" = and i32 %"shr_result.1", %"legacy_result.11"
  %"legacy_a_wide.18" = zext i32 %"legacy_result.16" to i64
  %"legacy_b_wide.18" = zext i32 14 to i64
  %"legacy_sum.18" = add i64 %"legacy_a_wide.18", %"legacy_b_wide.18"
  %"legacy_result.18" = trunc i64 %"legacy_sum.18" to i32
  %"ffma.1" = call float @"llvm.fma.f32"(float %"mufu_rcp", float %"ffma", float %"mufu_rcp")
  %"legacy_a_wide.19" = zext i32 %"tid_y" to i64
  %"legacy_b_wide.19" = zext i32 -1 to i64
  %"legacy_sum.19" = add i64 %"legacy_a_wide.19", %"legacy_b_wide.19"
  %"legacy_result.19" = trunc i64 %"legacy_sum.19" to i32
  %"isetrp_cmp1.7" = icmp sge i32 %"tid_x", %".172"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P35_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"legacy_a_wide.20" = zext i32 %"legacy_result.17" to i64
  %"legacy_b_wide.20" = zext i32 14 to i64
  %"legacy_sum.20" = add i64 %"legacy_a_wide.20", %"legacy_b_wide.20"
  %"legacy_result.20" = trunc i64 %"legacy_sum.20" to i32
  %"legacy_a_wide.21" = zext i32 %"tid_y" to i64
  %"legacy_b_wide.21" = zext i32 1 to i64
  %"legacy_sum.21" = add i64 %"legacy_a_wide.21", %"legacy_b_wide.21"
  %"legacy_result.21" = trunc i64 %"legacy_sum.21" to i32
  %"sel_pred_trunc" = trunc i32 %"P32_to_i32" to i1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_trunc" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 %"legacy_result.18", i32 15
  %".176" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 384
  %".177" = bitcast i8* %".176" to float*
  %"ffma_rhs.1" = load float, float* %".177"
  %"ffma.2" = call float @"llvm.fma.f32"(float %"ffma.1", float %"ffma_rhs.1", float              0x0)
  %"legacy_a_wide.22" = zext i32 %"tid_x" to i64
  %"legacy_b_wide.22" = zext i32 -1 to i64
  %"legacy_sum.22" = add i64 %"legacy_a_wide.22", %"legacy_b_wide.22"
  %"legacy_result.22" = trunc i64 %"legacy_sum.22" to i32
  %"legacy_a_wide.23" = zext i32 %"tid_x" to i64
  %"legacy_b_wide.23" = zext i32 1 to i64
  %"legacy_sum.23" = add i64 %"legacy_a_wide.23", %"legacy_b_wide.23"
  %"legacy_result.23" = trunc i64 %"legacy_sum.23" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P66_to_i32" to i1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_trunc.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 %"legacy_result.20", i32 15
  %"ffma_rhs_fneg.1" = fneg float %"mov.1"
  %".178" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 384
  %".179" = bitcast i8* %".178" to float*
  %"ffma_addend" = load float, float* %".179"
  %"ffma.3" = call float @"llvm.fma.f32"(float %"ffma.2", float %"ffma_rhs_fneg.1", float %"ffma_addend")
  %"ffma.4" = call float @"llvm.fma.f32"(float %"ffma.1", float %"ffma.3", float %"ffma.2")
  %"legacy_branch_predicate_trunc.1" = trunc i32 %"P25_to_i32" to i1
  %"legacy_branch_predicate_not.1" = xor i1 %"legacy_branch_predicate_trunc.1", -1
  %"legacy_taken_mask.1" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask", i1 %"legacy_branch_predicate_not.1")
  %".180" = xor i32 %"legacy_taken_mask.1", -1
  %"legacy_fallthrough_mask.1" = and i32 %"legacy_path_mask", %".180"
  %"legacy_path_mask.1" = select  i1 %"legacy_branch_predicate_not.1", i32 %"legacy_taken_mask.1", i32 %"legacy_fallthrough_mask.1"
  br label %"BB_0298"
BB_0298:
  %"cond_trunc.4" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_02c0", label %"BB_02a8_0938"
BB_02a8_0938:
  %".183" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 368
  %".184" = bitcast i8* %".183" to i32*
  %"mov.3" = load i32, i32* %".184"
  %".185" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 384
  %".186" = bitcast i8* %".185" to i32*
  %"mov.4" = load i32, i32* %".186"
  %".187" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 384
  %".188" = bitcast i8* %".187" to i32*
  %"mov.5" = load i32, i32* %".188"
  %".189" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 368
  %".190" = bitcast i8* %".189" to i32*
  %"mov.6" = load i32, i32* %".190"
  %".191" = zext i32 2071 to i64
  %".192" = and i64 %".191", 255
  %".193" = lshr i64 %".191", 8
  %".194" = and i64 %".193", 255
  %".195" = icmp ugt i64 %".194", 32
  %".196" = select  i1 %".195", i64 32, i64 %".194"
  %".197" = zext i32 %"mov.3" to i64
  %".198" = icmp ugt i64 %".192", 63
  %".199" = select  i1 %".198", i64 63, i64 %".192"
  %".200" = lshr i64 %".197", %".199"
  %".201" = shl i64 1, %".196"
  %".202" = sub i64 %".201", 1
  %".203" = and i64 %".200", %".202"
  %".204" = trunc i64 %".203" to i32
  %".205" = zext i32 2071 to i64
  %".206" = and i64 %".205", 255
  %".207" = lshr i64 %".205", 8
  %".208" = and i64 %".207", 255
  %".209" = icmp ugt i64 %".208", 32
  %".210" = select  i1 %".209", i64 32, i64 %".208"
  %".211" = zext i32 %"mov.4" to i64
  %".212" = icmp ugt i64 %".206", 63
  %".213" = select  i1 %".212", i64 63, i64 %".206"
  %".214" = lshr i64 %".211", %".213"
  %".215" = shl i64 1, %".210"
  %".216" = sub i64 %".215", 1
  %".217" = and i64 %".214", %".216"
  %".218" = trunc i64 %".217" to i32
  %"legacy_a_wide.24" = zext i32 %".204" to i64
  %"legacy_b_wide.24" = zext i32 -1 to i64
  %"legacy_sum.24" = add i64 %"legacy_a_wide.24", %"legacy_b_wide.24"
  %"legacy_result.24" = trunc i64 %"legacy_sum.24" to i32
  %"legacy_a_wide.25" = zext i32 %".218" to i64
  %"legacy_b_wide.25" = zext i32 -1 to i64
  %"legacy_sum.25" = add i64 %"legacy_a_wide.25", %"legacy_b_wide.25"
  %"legacy_result.25" = trunc i64 %"legacy_sum.25" to i32
  %"isetrp_cmp1.8" = icmp ugt i32 %"legacy_result.24", 253
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P27_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"isetrp_src_trunc.2" = trunc i32 %"P27_to_i32" to i1
  %"isetrp_cmp1.9" = icmp ugt i32 %"legacy_result.25", 253
  %"isetrp_src_to_i32.9" = zext i1 %"isetrp_src_trunc.2" to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = or i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P28_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_02a8_0988"
BB_02a8_0988:
  %"cond_trunc.5" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_02a8_80000988", label %"BB_02a8_0990"
BB_02a8_80000988:
  br label %"BB_02a8_0990"
BB_02a8_0990:
  %"phi.2" = phi  float [             0x0, %"BB_02a8_80000988"], [%"ffma.4", %"BB_02a8_0988"]
  %"legacy_branch_predicate_trunc.2" = trunc i32 %"P28_to_i32" to i1
  %"legacy_branch_predicate_not.2" = xor i1 %"legacy_branch_predicate_trunc.2", -1
  %"legacy_taken_mask.2" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.1", i1 %"legacy_branch_predicate_not.2")
  %".222" = xor i32 %"legacy_taken_mask.2", -1
  %"legacy_fallthrough_mask.2" = and i32 %"legacy_path_mask.1", %".222"
  %"legacy_path_mask.2" = select  i1 %"legacy_branch_predicate_not.2", i32 %"legacy_taken_mask.2", i32 %"legacy_fallthrough_mask.2"
  br label %"BB_02a8_0998"
BB_02a8_0998:
  %"cond_trunc.6" = trunc i32 %"P28_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  %"phi_cast_R195_bitcast" = bitcast float %"phi.2" to i32
  br i1 %"pbra_cond_to_i1.6", label %"BB_02a8_0a98", label %"BB_02a8_09a0"
BB_02a8_09a0:
  %"fcmp_source_bitcast" = bitcast i32 %"mov.4" to float
  %".225" = bitcast float %"fcmp_source_bitcast" to i32
  %".226" = and i32 %".225", 2147483647
  %".227" = and i32 %".226", 2139095040
  %".228" = icmp eq i32 %".227", 0
  %".229" = and i32 %".226", 2147483648
  %".230" = select  i1 %".228", i32 %".229", i32 %".226"
  %".231" = bitcast i32 %".230" to float
  %".232" = bitcast float 0x7ff0000000000000 to i32
  %".233" = and i32 %".232", 2139095040
  %".234" = icmp eq i32 %".233", 0
  %".235" = and i32 %".232", 2147483648
  %".236" = select  i1 %".234", i32 %".235", i32 %".232"
  %".237" = bitcast i32 %".236" to float
  %".238" = fcmp ugt float %".231", %".237"
  %".239" = and i1 %".238", 1
  %".240" = select  i1 %".239", i32 4294967295, i32 0
  %"R196_bitcast" = bitcast i32 %".240" to float
  %"fcmp_source_bitcast.1" = bitcast i32 %"mov.3" to float
  %".241" = bitcast float %"fcmp_source_bitcast.1" to i32
  %".242" = and i32 %".241", 2147483647
  %".243" = and i32 %".242", 2139095040
  %".244" = icmp eq i32 %".243", 0
  %".245" = and i32 %".242", 2147483648
  %".246" = select  i1 %".244", i32 %".245", i32 %".242"
  %".247" = bitcast i32 %".246" to float
  %".248" = bitcast float 0x7ff0000000000000 to i32
  %".249" = and i32 %".248", 2139095040
  %".250" = icmp eq i32 %".249", 0
  %".251" = and i32 %".248", 2147483648
  %".252" = select  i1 %".250", i32 %".251", i32 %".248"
  %".253" = bitcast i32 %".252" to float
  %".254" = fcmp ugt float %".247", %".253"
  %".255" = and i1 %".254", 1
  %".256" = select  i1 %".255", i32 4294967295, i32 0
  %"R361_bitcast" = bitcast i32 %".256" to float
  %"legacy_source_bitcast" = bitcast float %"R196_bitcast" to i32
  %"legacy_source_bitcast.1" = bitcast float %"R361_bitcast" to i32
  %".257" = or i32 %"legacy_source_bitcast", %"legacy_source_bitcast.1"
  %".258" = icmp ne i32 %".257", 0
  %"P29_to_i32" = zext i1 %".258" to i32
  %"legacy_branch_predicate_trunc.3" = trunc i32 %"P29_to_i32" to i1
  %"legacy_taken_mask.3" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.2", i1 %"legacy_branch_predicate_trunc.3")
  %".259" = xor i32 %"legacy_taken_mask.3", -1
  %"legacy_fallthrough_mask.3" = and i32 %"legacy_path_mask.2", %".259"
  %"legacy_path_mask.3" = select  i1 %"legacy_branch_predicate_trunc.3", i32 %"legacy_taken_mask.3", i32 %"legacy_fallthrough_mask.3"
  br label %"BB_02a8_09c0"
BB_02a8_09c0:
  %"cond_trunc.7" = trunc i32 %"P29_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_02a8_0ca0", label %"BB_02a8_09c8"
BB_02a8_09c8:
  %".262" = xor i32 %"mov.6", -1
  %".263" = and i32 %".262", 2147483647
  %".264" = and i32 %".263", %"mov.5"
  %".265" = or i32 0, %".264"
  %".266" = xor i32 %"mov.5", -1
  %".267" = and i32 %"mov.6", 2147483647
  %".268" = and i32 %".267", %".266"
  %".269" = or i32 %".265", %".268"
  %".270" = and i32 %"mov.6", 2147483647
  %".271" = and i32 %".270", %"mov.5"
  %".272" = or i32 %".269", %".271"
  %".273" = icmp ne i32 %".272", 0
  %"P30_to_i32" = zext i1 %".273" to i32
  %"legacy_branch_predicate_trunc.4" = trunc i32 %"P30_to_i32" to i1
  %"legacy_branch_predicate_not.3" = xor i1 %"legacy_branch_predicate_trunc.4", -1
  %"legacy_taken_mask.4" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.3", i1 %"legacy_branch_predicate_not.3")
  %".274" = xor i32 %"legacy_taken_mask.4", -1
  %"legacy_fallthrough_mask.4" = and i32 %"legacy_path_mask.3", %".274"
  %"legacy_path_mask.4" = select  i1 %"legacy_branch_predicate_not.3", i32 %"legacy_taken_mask.4", i32 %"legacy_fallthrough_mask.4"
  br label %"BB_02a8_09e0"
BB_02a8_09e0:
  %"cond_trunc.8" = trunc i32 %"P30_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_02a8_0c88", label %"BB_02a8_09e8"
BB_02a8_09e8:
  %"fcmp_source_bitcast.2" = bitcast i32 %"mov.4" to float
  %".277" = bitcast float %"fcmp_source_bitcast.2" to i32
  %".278" = and i32 %".277", 2147483647
  %".279" = and i32 %".278", 2139095040
  %".280" = icmp eq i32 %".279", 0
  %".281" = and i32 %".278", 2147483648
  %".282" = select  i1 %".280", i32 %".281", i32 %".278"
  %".283" = bitcast i32 %".282" to float
  %".284" = bitcast float 0x7ff0000000000000 to i32
  %".285" = and i32 %".284", 2139095040
  %".286" = icmp eq i32 %".285", 0
  %".287" = and i32 %".284", 2147483648
  %".288" = select  i1 %".286", i32 %".287", i32 %".284"
  %".289" = bitcast i32 %".288" to float
  %".290" = fcmp une float %".283", %".289"
  %".291" = and i1 %".290", 1
  %".292" = select  i1 %".291", i32 4294967295, i32 0
  %"R197_bitcast" = bitcast i32 %".292" to float
  %"fcmp_source_bitcast.3" = bitcast i32 %"mov.3" to float
  %".293" = bitcast float %"fcmp_source_bitcast.3" to i32
  %".294" = and i32 %".293", 2147483647
  %".295" = and i32 %".294", 2139095040
  %".296" = icmp eq i32 %".295", 0
  %".297" = and i32 %".294", 2147483648
  %".298" = select  i1 %".296", i32 %".297", i32 %".294"
  %".299" = bitcast i32 %".298" to float
  %".300" = bitcast float 0x7ff0000000000000 to i32
  %".301" = and i32 %".300", 2139095040
  %".302" = icmp eq i32 %".301", 0
  %".303" = and i32 %".300", 2147483648
  %".304" = select  i1 %".302", i32 %".303", i32 %".300"
  %".305" = bitcast i32 %".304" to float
  %".306" = fcmp une float %".299", %".305"
  %".307" = and i1 %".306", 1
  %".308" = select  i1 %".307", i32 4294967295, i32 0
  %"R201_bitcast" = bitcast i32 %".308" to float
  %"legacy_source_bitcast.2" = bitcast float %"R197_bitcast" to i32
  %"legacy_not" = xor i32 %"legacy_source_bitcast.2", -1
  %"legacy_source_bitcast.3" = bitcast float %"R201_bitcast" to i32
  %"legacy_not.1" = xor i32 %"legacy_source_bitcast.3", -1
  %".309" = and i32 %"legacy_not", %"legacy_not.1"
  %".310" = icmp ne i32 %".309", 0
  %"P31_to_i32" = zext i1 %".310" to i32
  %"legacy_branch_predicate_trunc.5" = trunc i32 %"P31_to_i32" to i1
  %"legacy_taken_mask.5" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.4", i1 %"legacy_branch_predicate_trunc.5")
  %".311" = xor i32 %"legacy_taken_mask.5", -1
  %"legacy_fallthrough_mask.5" = and i32 %"legacy_path_mask.4", %".311"
  %"legacy_path_mask.5" = select  i1 %"legacy_branch_predicate_trunc.5", i32 %"legacy_taken_mask.5", i32 %"legacy_fallthrough_mask.5"
  br label %"BB_02a8_0a08"
BB_02a8_0a08:
  %"cond_trunc.9" = trunc i32 %"P31_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_02a8_0c88", label %"BB_02a8_0a10"
BB_02a8_0a10:
  %"fcmp_source_bitcast.4" = bitcast i32 %"mov.3" to float
  %".314" = bitcast float %"fcmp_source_bitcast.4" to i32
  %".315" = and i32 %".314", 2147483647
  %".316" = and i32 %".315", 2139095040
  %".317" = icmp eq i32 %".316", 0
  %".318" = and i32 %".315", 2147483648
  %".319" = select  i1 %".317", i32 %".318", i32 %".315"
  %".320" = bitcast i32 %".319" to float
  %".321" = bitcast float 0x7ff0000000000000 to i32
  %".322" = and i32 %".321", 2139095040
  %".323" = icmp eq i32 %".322", 0
  %".324" = and i32 %".321", 2147483648
  %".325" = select  i1 %".323", i32 %".324", i32 %".321"
  %".326" = bitcast i32 %".325" to float
  %".327" = fcmp une float %".320", %".326"
  %".328" = and i1 %".327", 1
  %".329" = xor i1 %".327", -1
  %".330" = and i1 %".329", 1
  %"P23_to_i32" = zext i1 %".328" to i32
  %".331" = and i32 %"mov.5", 2147483647
  %".332" = icmp ne i32 %".331", 0
  %"P43_to_i32" = zext i1 %".332" to i32
  %"legacy_source_trunc.2" = trunc i32 %"P23_to_i32" to i1
  %"legacy_pred_to_i32.3" = zext i1 %"legacy_source_trunc.2" to i32
  %"legacy_pred_to_i1.3" = icmp ne i32 %"legacy_pred_to_i32.3", 0
  %"legacy_not.2" = xor i1 %"legacy_pred_to_i1.3", -1
  %"legacy_source_trunc.3" = trunc i32 %"P43_to_i32" to i1
  %"legacy_pred_to_i32.4" = zext i1 %"legacy_source_trunc.3" to i32
  %"legacy_pred_to_i1.4" = icmp ne i32 %"legacy_pred_to_i32.4", 0
  %"legacy_not.3" = xor i1 %"legacy_pred_to_i1.4", -1
  %"legacy_pred_to_i32.5" = zext i1 1 to i32
  %"legacy_pred_to_i1.5" = icmp ne i32 %"legacy_pred_to_i32.5", 0
  %".333" = or i1 %"legacy_not.2", %"legacy_not.3"
  %".334" = and i1 %".333", %"legacy_pred_to_i1.5"
  %".335" = xor i1 %".333", -1
  %".336" = and i1 %".335", %"legacy_pred_to_i1.5"
  %"P8_to_i32" = zext i1 %".334" to i32
  %"legacy_branch_predicate_trunc.6" = trunc i32 %"P8_to_i32" to i1
  %"legacy_taken_mask.6" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.5", i1 %"legacy_branch_predicate_trunc.6")
  %".337" = xor i32 %"legacy_taken_mask.6", -1
  %"legacy_fallthrough_mask.6" = and i32 %"legacy_path_mask.5", %".337"
  %"legacy_path_mask.6" = select  i1 %"legacy_branch_predicate_trunc.6", i32 %"legacy_taken_mask.6", i32 %"legacy_fallthrough_mask.6"
  br label %"BB_02a8_0a30"
BB_02a8_0a30:
  %"cond_trunc.10" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_02a8_0c78", label %"BB_02a8_0a38"
BB_02a8_0a38:
  %"fcmp_source_bitcast.5" = bitcast i32 %"mov.4" to float
  %".340" = bitcast float %"fcmp_source_bitcast.5" to i32
  %".341" = and i32 %".340", 2147483647
  %".342" = and i32 %".341", 2139095040
  %".343" = icmp eq i32 %".342", 0
  %".344" = and i32 %".341", 2147483648
  %".345" = select  i1 %".343", i32 %".344", i32 %".341"
  %".346" = bitcast i32 %".345" to float
  %".347" = bitcast float 0x7ff0000000000000 to i32
  %".348" = and i32 %".347", 2139095040
  %".349" = icmp eq i32 %".348", 0
  %".350" = and i32 %".347", 2147483648
  %".351" = select  i1 %".349", i32 %".350", i32 %".347"
  %".352" = bitcast i32 %".351" to float
  %".353" = fcmp une float %".346", %".352"
  %".354" = and i1 %".353", 1
  %".355" = xor i1 %".353", -1
  %".356" = and i1 %".355", 1
  %"P2_to_i32" = zext i1 %".354" to i32
  %".357" = and i32 %"mov.6", 2147483647
  %".358" = icmp ne i32 %".357", 0
  %"P55_to_i32" = zext i1 %".358" to i32
  %"legacy_source_trunc.4" = trunc i32 %"P2_to_i32" to i1
  %"legacy_pred_to_i32.6" = zext i1 %"legacy_source_trunc.4" to i32
  %"legacy_pred_to_i1.6" = icmp ne i32 %"legacy_pred_to_i32.6", 0
  %"legacy_not.4" = xor i1 %"legacy_pred_to_i1.6", -1
  %"legacy_source_trunc.5" = trunc i32 %"P55_to_i32" to i1
  %"legacy_pred_to_i32.7" = zext i1 %"legacy_source_trunc.5" to i32
  %"legacy_pred_to_i1.7" = icmp ne i32 %"legacy_pred_to_i32.7", 0
  %"legacy_not.5" = xor i1 %"legacy_pred_to_i1.7", -1
  %"legacy_pred_to_i32.8" = zext i1 1 to i32
  %"legacy_pred_to_i1.8" = icmp ne i32 %"legacy_pred_to_i32.8", 0
  %".359" = or i1 %"legacy_not.4", %"legacy_not.5"
  %".360" = and i1 %".359", %"legacy_pred_to_i1.8"
  %".361" = xor i1 %".359", -1
  %".362" = and i1 %".361", %"legacy_pred_to_i1.8"
  %"P6_to_i32" = zext i1 %".360" to i32
  %"legacy_branch_predicate_trunc.7" = trunc i32 %"P6_to_i32" to i1
  %"legacy_taken_mask.7" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.6", i1 %"legacy_branch_predicate_trunc.7")
  %".363" = xor i32 %"legacy_taken_mask.7", -1
  %"legacy_fallthrough_mask.7" = and i32 %"legacy_path_mask.6", %".363"
  %"legacy_path_mask.7" = select  i1 %"legacy_branch_predicate_trunc.7", i32 %"legacy_taken_mask.7", i32 %"legacy_fallthrough_mask.7"
  br label %"BB_02a8_0a58"
BB_02a8_0a58:
  %"cond_trunc.11" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_02a8_0c60", label %"BB_02a8_0a60"
BB_02a8_0a60:
  %"isetrp_cmp1.10" = icmp sge i32 %"legacy_result.25", 0
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  %"isetrp_cmp1.11" = icmp sge i32 %"legacy_result.24", 0
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P61_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_02a8_0a70"
BB_02a8_0a70:
  %"cond_trunc.12" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  %"phi_cast_R197_bitcast" = bitcast float %"R197_bitcast" to i32
  br i1 %"pbra_cond_to_i1.12", label %"BB_02a8_80000a70", label %"BB_02a8_0a78"
BB_02a8_80000a70:
  br label %"BB_02a8_0a78"
BB_02a8_0a78:
  %"phi.3" = phi  i32 [0, %"BB_02a8_80000a70"], [%"phi_cast_R197_bitcast", %"BB_02a8_0a70"]
  %"cond_trunc.13" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_02a8_80000a78", label %"BB_02a8_0a88"
BB_02a8_80000a78:
  %"ffma_lhs_bitcast" = bitcast i32 %"mov.4" to float
  %"ffma.5" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast", float 0x43f0000000000000, float              0x0)
  %"phi_cast_R366_bitcast" = bitcast float %"ffma.5" to i32
  br label %"BB_02a8_0a88"
BB_02a8_0a88:
  %"phi.4" = phi  i32 [4294967232, %"BB_02a8_80000a78"], [%"phi.3", %"BB_02a8_0a78"]
  %"phi.5" = phi  i32 [%"phi_cast_R366_bitcast", %"BB_02a8_80000a78"], [%"mov.5", %"BB_02a8_0a78"]
  %"cond_trunc.14" = trunc i32 %"P61_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_02a8_80000a88", label %"BB_02a8_0a98"
BB_02a8_80000a88:
  %"ffma_lhs_bitcast.1" = bitcast i32 %"mov.3" to float
  %"ffma.6" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.1", float 0x43f0000000000000, float              0x0)
  %"legacy_a_wide.26" = zext i32 %"phi.4" to i64
  %"legacy_b_wide.26" = zext i32 64 to i64
  %"legacy_sum.26" = add i64 %"legacy_a_wide.26", %"legacy_b_wide.26"
  %"legacy_result.26" = trunc i64 %"legacy_sum.26" to i32
  %"phi_cast_R315_bitcast" = bitcast float %"ffma.6" to i32
  br label %"BB_02a8_0a98"
BB_02a8_0c60:
  %".373" = xor i32 %"mov.6", -1
  %".374" = and i32 %".373", 2147483648
  %".375" = and i32 %".374", %"mov.5"
  %".376" = or i32 0, %".375"
  %".377" = xor i32 %"mov.5", -1
  %".378" = and i32 %"mov.6", 2147483648
  %".379" = and i32 %".378", %".377"
  %".380" = or i32 %".376", %".379"
  %".381" = or i32 %".380", 2139095040
  %"phi_cast_R199_bitcast" = bitcast i32 %".381" to float
  br label %"BB_02b0"
BB_02a8_0c78:
  %".383" = xor i32 %"mov.6", -1
  %".384" = and i32 %".383", 2147483648
  %".385" = and i32 %".384", %"mov.5"
  %".386" = or i32 0, %".385"
  %".387" = xor i32 %"mov.5", -1
  %".388" = and i32 %"mov.6", 2147483648
  %".389" = and i32 %".388", %".387"
  %".390" = or i32 %".386", %".389"
  %"phi_cast_R200_bitcast" = bitcast i32 %".390" to float
  br label %"BB_02b0"
BB_02a8_0c88:
  %"mufu_src_bitcast" = bitcast i32 4290772992 to float
  %"mufu_rsq" = call float @"llvm.nvvm.rsqrt.approx.ftz.f"(float %"mufu_src_bitcast")
  br label %"BB_02b0"
BB_02a8_0ca0:
  %"fadd_lhs_bitcast" = bitcast i32 %"mov.4" to float
  %".393" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 368
  %".394" = bitcast i8* %".393" to float*
  %"fadd_rhs" = load float, float* %".394"
  %"fadd" = fadd float %"fadd_lhs_bitcast", %"fadd_rhs"
  br label %"BB_02b0"
BB_02a8_0a98:
  %"phi.6" = phi  i32 [%"phi_cast_R195_bitcast", %"BB_02a8_0998"], [%"legacy_result.26", %"BB_02a8_80000a88"], [%"phi.4", %"BB_02a8_0a88"]
  %"phi.7" = phi  i32 [%"legacy_path_mask.2", %"BB_02a8_0998"], [%"legacy_path_mask.7", %"BB_02a8_80000a88"], [%"legacy_path_mask.7", %"BB_02a8_0a88"]
  %"phi.8" = phi  i32 [%"mov.6", %"BB_02a8_0998"], [%"phi_cast_R315_bitcast", %"BB_02a8_80000a88"], [%"mov.6", %"BB_02a8_0a88"]
  %"phi.9" = phi  i32 [%"mov.5", %"BB_02a8_0998"], [%"phi.5", %"BB_02a8_80000a88"], [%"phi.5", %"BB_02a8_0a88"]
  %"legacy_a_shift.1" = shl i32 %".204", 23
  %"legacy_a_wide.27" = zext i32 %"legacy_a_shift.1" to i64
  %"legacy_b_wide.27" = zext i32 -1065353216 to i64
  %"legacy_sum.27" = add i64 %"legacy_a_wide.27", %"legacy_b_wide.27"
  %"legacy_result.27" = trunc i64 %"legacy_sum.27" to i32
  %"legacy_a_wide.28" = zext i32 %".218" to i64
  %"legacy_b_wide.28" = zext i32 -127 to i64
  %"legacy_sum.28" = add i64 %"legacy_a_wide.28", %"legacy_b_wide.28"
  %"legacy_result.28" = trunc i64 %"legacy_sum.28" to i32
  %"legacy_a_wide.29" = zext i32 %"legacy_result.27" to i64
  %"legacy_a_complement.5" = xor i64 %"legacy_a_wide.29", 4294967295
  %"legacy_a_negate.5" = add i64 %"legacy_a_complement.5", 1
  %"legacy_b_wide.29" = zext i32 %"phi.8" to i64
  %"legacy_sum.29" = add i64 %"legacy_a_negate.5", %"legacy_b_wide.29"
  %"legacy_result.29" = trunc i64 %"legacy_sum.29" to i32
  %"legacy_a_shift.2" = shl i32 %"legacy_result.28", 23
  %"legacy_a_wide.30" = zext i32 %"legacy_a_shift.2" to i64
  %"legacy_a_complement.6" = xor i64 %"legacy_a_wide.30", 4294967295
  %"legacy_a_negate.6" = add i64 %"legacy_a_complement.6", 1
  %"legacy_b_wide.30" = zext i32 %"phi.9" to i64
  %"legacy_sum.30" = add i64 %"legacy_a_negate.6", %"legacy_b_wide.30"
  %"legacy_result.30" = trunc i64 %"legacy_sum.30" to i32
  %"mufu_src_bitcast.1" = bitcast i32 %"legacy_result.29" to float
  %"mufu_rcp.1" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.1")
  %"iadd3_o3_not" = xor i32 %".204", -1
  %"iadd3_o3_neg" = add i32 %"iadd3_o3_not", 1
  %"iadd3_n1" = add i32 %"legacy_result.28", 127
  %"iadd3_n2" = add i32 %"iadd3_n1", %"iadd3_o3_neg"
  %"fadd_lhs_bitcast.1" = bitcast i32 %"legacy_result.29" to float
  %"fadd_lhs_fneg" = fneg float %"fadd_lhs_bitcast.1"
  %"fadd.1" = fadd float %"fadd_lhs_fneg",              0x0
  %"legacy_a_wide.31" = zext i32 %"iadd3_n2" to i64
  %"legacy_b_wide.31" = zext i32 %"phi.6" to i64
  %"legacy_sum.31" = add i64 %"legacy_a_wide.31", %"legacy_b_wide.31"
  %"legacy_result.31" = trunc i64 %"legacy_sum.31" to i32
  %"ffma.7" = call float @"llvm.fma.f32"(float %"mufu_rcp.1", float %"fadd.1", float 0x3ff0000000000000)
  %"ffma.8" = call float @"llvm.fma.f32"(float %"mufu_rcp.1", float %"ffma.7", float %"mufu_rcp.1")
  %"ffma_lhs_bitcast.2" = bitcast i32 %"legacy_result.30" to float
  %"ffma.9" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.2", float %"ffma.8", float              0x0)
  %"ffma_addend_bitcast.1" = bitcast i32 %"legacy_result.30" to float
  %"ffma.10" = call float @"llvm.fma.f32"(float %"fadd.1", float %"ffma.9", float %"ffma_addend_bitcast.1")
  %"ffma.11" = call float @"llvm.fma.f32"(float %"ffma.8", float %"ffma.10", float %"ffma.9")
  %"ffma_addend_bitcast.2" = bitcast i32 %"legacy_result.30" to float
  %"ffma.12" = call float @"llvm.fma.f32"(float %"fadd.1", float %"ffma.11", float %"ffma_addend_bitcast.2")
  %"ffma.13" = call float @"llvm.fma.f32"(float %"ffma.8", float %"ffma.12", float %"ffma.11")
  %"legacy_source_bitcast.4" = bitcast float %"ffma.13" to i32
  %".396" = zext i32 2071 to i64
  %".397" = and i64 %".396", 255
  %".398" = lshr i64 %".396", 8
  %".399" = and i64 %".398", 255
  %".400" = icmp ugt i64 %".399", 32
  %".401" = select  i1 %".400", i64 32, i64 %".399"
  %".402" = zext i32 %"legacy_source_bitcast.4" to i64
  %".403" = icmp ugt i64 %".397", 63
  %".404" = select  i1 %".403", i64 63, i64 %".397"
  %".405" = lshr i64 %".402", %".404"
  %".406" = shl i64 1, %".401"
  %".407" = sub i64 %".406", 1
  %".408" = and i64 %".405", %".407"
  %".409" = trunc i64 %".408" to i32
  %"legacy_a_wide.32" = zext i32 %".409" to i64
  %"legacy_b_wide.32" = zext i32 %"legacy_result.31" to i64
  %"legacy_sum.32" = add i64 %"legacy_a_wide.32", %"legacy_b_wide.32"
  %"legacy_result.32" = trunc i64 %"legacy_sum.32" to i32
  %"legacy_a_wide.33" = zext i32 %"legacy_result.32" to i64
  %"legacy_b_wide.33" = zext i32 -1 to i64
  %"legacy_sum.33" = add i64 %"legacy_a_wide.33", %"legacy_b_wide.33"
  %"legacy_result.33" = trunc i64 %"legacy_sum.33" to i32
  %"isetrp_cmp1.12" = icmp uge i32 %"legacy_result.33", 254
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"legacy_branch_predicate_trunc.8" = trunc i32 %"P9_to_i32" to i1
  %"legacy_branch_predicate_not.4" = xor i1 %"legacy_branch_predicate_trunc.8", -1
  %"legacy_taken_mask.8" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"phi.7", i1 %"legacy_branch_predicate_not.4")
  %".410" = xor i32 %"legacy_taken_mask.8", -1
  %"legacy_fallthrough_mask.8" = and i32 %"phi.7", %".410"
  %"legacy_path_mask.8" = select  i1 %"legacy_branch_predicate_not.4", i32 %"legacy_taken_mask.8", i32 %"legacy_fallthrough_mask.8"
  br label %"BB_02a8_0b38"
BB_02a8_0b38:
  %"cond_trunc.15" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_02a8_0c50", label %"BB_02a8_0b40"
BB_02a8_0b40:
  %"isetrp_cmp1.13" = icmp sgt i32 %"legacy_result.32", 254
  %"isetrp_src_to_i32.13" = zext i1 1 to i32
  %"isetrp_src_to_i1.13" = icmp ne i32 %"isetrp_src_to_i32.13", 0
  %"isetrp_cmp2.13" = and i1 %"isetrp_cmp1.13", %"isetrp_src_to_i1.13"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.13" to i32
  %"legacy_branch_predicate_trunc.9" = trunc i32 %"P10_to_i32" to i1
  %"legacy_taken_mask.9" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.8", i1 %"legacy_branch_predicate_trunc.9")
  %".413" = xor i32 %"legacy_taken_mask.9", -1
  %"legacy_fallthrough_mask.9" = and i32 %"legacy_path_mask.8", %".413"
  %"legacy_path_mask.9" = select  i1 %"legacy_branch_predicate_trunc.9", i32 %"legacy_taken_mask.9", i32 %"legacy_fallthrough_mask.9"
  br label %"BB_02a8_0b50"
BB_02a8_0b50:
  %"cond_trunc.16" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_02a8_0c38", label %"BB_02a8_0b58"
BB_02a8_0b58:
  %"isetrp_cmp1.14" = icmp sge i32 %"legacy_result.32", 1
  %"isetrp_src_to_i32.14" = zext i1 1 to i32
  %"isetrp_src_to_i1.14" = icmp ne i32 %"isetrp_src_to_i32.14", 0
  %"isetrp_cmp2.14" = and i1 %"isetrp_cmp1.14", %"isetrp_src_to_i1.14"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.14" to i32
  %"legacy_branch_predicate_trunc.10" = trunc i32 %"P11_to_i32" to i1
  %"legacy_taken_mask.10" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.9", i1 %"legacy_branch_predicate_trunc.10")
  %".416" = xor i32 %"legacy_taken_mask.10", -1
  %"legacy_fallthrough_mask.10" = and i32 %"legacy_path_mask.9", %".416"
  %"legacy_path_mask.10" = select  i1 %"legacy_branch_predicate_trunc.10", i32 %"legacy_taken_mask.10", i32 %"legacy_fallthrough_mask.10"
  br label %"BB_02a8_0b68"
BB_02a8_0b68:
  %"cond_trunc.17" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_02b0", label %"BB_02a8_0b70"
BB_02a8_0b70:
  %"isetrp_cmp1.15" = icmp sge i32 %"legacy_result.32", -24
  %"isetrp_src_to_i32.15" = zext i1 1 to i32
  %"isetrp_src_to_i1.15" = icmp ne i32 %"isetrp_src_to_i32.15", 0
  %"isetrp_cmp2.15" = and i1 %"isetrp_cmp1.15", %"isetrp_src_to_i1.15"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.15" to i32
  %"legacy_source_bitcast.5" = bitcast float %"ffma.13" to i32
  %".419" = and i32 %"legacy_source_bitcast.5", 2147483648
  %"legacy_branch_predicate_trunc.11" = trunc i32 %"P15_to_i32" to i1
  %"legacy_branch_predicate_not.5" = xor i1 %"legacy_branch_predicate_trunc.11", -1
  %"legacy_taken_mask.11" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.10", i1 %"legacy_branch_predicate_not.5")
  %".420" = xor i32 %"legacy_taken_mask.11", -1
  %"legacy_fallthrough_mask.11" = and i32 %"legacy_path_mask.10", %".420"
  %"legacy_path_mask.11" = select  i1 %"legacy_branch_predicate_not.5", i32 %"legacy_taken_mask.11", i32 %"legacy_fallthrough_mask.11"
  br label %"BB_02a8_0b88"
BB_02a8_0b88:
  %"cond_trunc.18" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  %"phi_cast_R208_bitcast" = bitcast i32 %".419" to float
  br i1 %"pbra_cond_to_i1.18", label %"BB_02b0", label %"BB_02a8_0b90"
BB_02a8_0b90:
  %"ffma_rz" = call float @"llvm.nvvm.fma.rz.f"(float %"ffma.8", float %"ffma.12", float %"ffma.11")
  %"isetrp_cmp1.16" = icmp ne i32 %"legacy_result.32", 0
  %"isetrp_src_to_i32.16" = zext i1 1 to i32
  %"isetrp_src_to_i1.16" = icmp ne i32 %"isetrp_src_to_i32.16", 0
  %"isetrp_cmp2.16" = and i1 %"isetrp_cmp1.16", %"isetrp_src_to_i1.16"
  %"P64_to_i32" = zext i1 %"isetrp_cmp2.16" to i32
  %"legacy_a_wide.34" = zext i32 %"legacy_result.32" to i64
  %"legacy_b_wide.34" = zext i32 32 to i64
  %"legacy_sum.34" = add i64 %"legacy_a_wide.34", %"legacy_b_wide.34"
  %"legacy_result.34" = trunc i64 %"legacy_sum.34" to i32
  %"legacy_source_bitcast.6" = bitcast float %"ffma_rz" to i32
  %".423" = and i32 %"legacy_source_bitcast.6", 8388607
  %".424" = or i32 %".423", 8388608
  %"ffma_rp" = call float @"llvm.nvvm.fma.rp.f"(float %"ffma.8", float %"ffma.12", float %"ffma.11")
  %"ffma_rm" = call float @"llvm.nvvm.fma.rm.f"(float %"ffma.8", float %"ffma.12", float %"ffma.11")
  %"shl.3" = shl i32 %".424", %"legacy_result.34"
  %".425" = bitcast float %"ffma_rp" to i32
  %".426" = and i32 %".425", 2139095040
  %".427" = icmp eq i32 %".426", 0
  %".428" = and i32 %".425", 2147483648
  %".429" = select  i1 %".427", i32 %".428", i32 %".425"
  %".430" = bitcast i32 %".429" to float
  %".431" = bitcast float %"ffma_rm" to i32
  %".432" = and i32 %".431", 2139095040
  %".433" = icmp eq i32 %".432", 0
  %".434" = and i32 %".431", 2147483648
  %".435" = select  i1 %".433", i32 %".434", i32 %".431"
  %".436" = bitcast i32 %".435" to float
  %".437" = fcmp une float %".430", %".436"
  %".438" = and i1 %".437", 1
  %".439" = xor i1 %".437", -1
  %".440" = and i1 %".439", 1
  %"P16_to_i32" = zext i1 %".438" to i32
  %"legacy_a_wide.35" = zext i32 %"legacy_result.32" to i64
  %"legacy_a_complement.7" = xor i64 %"legacy_a_wide.35", 4294967295
  %"legacy_a_negate.7" = add i64 %"legacy_a_complement.7", 1
  %"legacy_b_wide.35" = zext i32 0 to i64
  %"legacy_sum.35" = add i64 %"legacy_a_negate.7", %"legacy_b_wide.35"
  %"legacy_result.35" = trunc i64 %"legacy_sum.35" to i32
  %"isetrp_src_trunc.3" = trunc i32 %"P64_to_i32" to i1
  %"isetrp_cmp1.17" = icmp ne i32 %"shl.3", 0
  %"isetrp_src_to_i32.17" = zext i1 %"isetrp_src_trunc.3" to i32
  %"isetrp_src_to_i1.17" = icmp ne i32 %"isetrp_src_to_i32.17", 0
  %"isetrp_cmp2.17" = and i1 %"isetrp_cmp1.17", %"isetrp_src_to_i1.17"
  %"P65_to_i32" = zext i1 %"isetrp_cmp2.17" to i32
  %".441" = icmp ne i32 %"legacy_result.32", 0
  %".442" = select  i1 %".441", i32 %"legacy_result.35", i32 0
  %"shr_overflow.3" = icmp ugt i32 %".442", 31
  %"shr_clamp.3" = select  i1 %"shr_overflow.3", i32 31, i32 %".442"
  %"shr_result.3" = lshr i32 %".424", %"shr_clamp.3"
  %"shr_zero" = select  i1 %"shr_overflow.3", i32 0, i32 %"shr_result.3"
  %"legacy_source_trunc.6" = trunc i32 %"P16_to_i32" to i1
  %"legacy_pred_to_i32.9" = zext i1 %"legacy_source_trunc.6" to i32
  %"legacy_pred_to_i1.9" = icmp ne i32 %"legacy_pred_to_i32.9", 0
  %"legacy_source_trunc.7" = trunc i32 %"P65_to_i32" to i1
  %"legacy_pred_to_i32.10" = zext i1 %"legacy_source_trunc.7" to i32
  %"legacy_pred_to_i1.10" = icmp ne i32 %"legacy_pred_to_i32.10", 0
  %"legacy_pred_to_i32.11" = zext i1 1 to i32
  %"legacy_pred_to_i1.11" = icmp ne i32 %"legacy_pred_to_i32.11", 0
  %".443" = or i1 %"legacy_pred_to_i1.9", %"legacy_pred_to_i1.10"
  %".444" = and i1 %".443", %"legacy_pred_to_i1.11"
  %".445" = xor i1 %".443", -1
  %".446" = and i1 %".445", %"legacy_pred_to_i1.11"
  %"P17_to_i32" = zext i1 %".444" to i32
  %"shr_overflow.4" = icmp ugt i32 1, 31
  %"shr_clamp.4" = select  i1 %"shr_overflow.4", i32 31, i32 1
  %"shr_result.4" = lshr i32 %"shr_zero", %"shr_clamp.4"
  %"shr_zero.1" = select  i1 %"shr_overflow.4", i32 0, i32 %"shr_result.4"
  %"sel_pred_trunc.2" = trunc i32 %"P17_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc.2", -1
  %"sel_pred_to_i32.2" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1.2" = icmp ne i32 %"sel_pred_to_i32.2", 0
  %"sel.2" = select  i1 %"sel_pred_to_i1.2", i32 0, i32 1
  %".447" = xor i32 %"sel.2", -1
  %".448" = and i32 %".447", 1
  %".449" = and i32 %".448", %"shr_zero.1"
  %".450" = or i32 0, %".449"
  %".451" = xor i32 1, -1
  %".452" = xor i32 %"shr_zero.1", -1
  %".453" = and i32 %"sel.2", %".451"
  %".454" = and i32 %".453", %".452"
  %".455" = or i32 %".450", %".454"
  %".456" = xor i32 1, -1
  %".457" = and i32 %"sel.2", %".456"
  %".458" = and i32 %".457", %"shr_zero.1"
  %".459" = or i32 %".455", %".458"
  %".460" = xor i32 %"shr_zero.1", -1
  %".461" = and i32 %"sel.2", 1
  %".462" = and i32 %".461", %".460"
  %".463" = or i32 %".459", %".462"
  %".464" = and i32 %"sel.2", 1
  %".465" = and i32 %".464", %"shr_zero.1"
  %".466" = or i32 %".463", %".465"
  %".467" = and i32 %".466", %"shr_zero"
  %"legacy_a_wide.36" = zext i32 %"shr_zero.1" to i64
  %"legacy_b_wide.36" = zext i32 %".467" to i64
  %"legacy_sum.36" = add i64 %"legacy_a_wide.36", %"legacy_b_wide.36"
  %"legacy_result.36" = trunc i64 %"legacy_sum.36" to i32
  %".468" = or i32 %"legacy_result.36", %".419"
  %"phi_cast_R209_bitcast" = bitcast i32 %".468" to float
  br label %"BB_02b0"
BB_02a8_0c38:
  %"legacy_source_bitcast.7" = bitcast float %"ffma.13" to i32
  %".470" = and i32 %"legacy_source_bitcast.7", 2147483648
  %".471" = or i32 %".470", 2139095040
  %"phi_cast_R211_bitcast" = bitcast i32 %".471" to float
  br label %"BB_02b0"
BB_02a8_0c50:
  %"legacy_a_shift.3" = shl i32 %"legacy_result.31", 23
  %"legacy_a_wide.37" = zext i32 %"legacy_a_shift.3" to i64
  %"legacy_b_bitcast" = bitcast float %"ffma.13" to i32
  %"legacy_b_wide.37" = zext i32 %"legacy_b_bitcast" to i64
  %"legacy_sum.37" = add i64 %"legacy_a_wide.37", %"legacy_b_wide.37"
  %"legacy_result.37" = trunc i64 %"legacy_sum.37" to i32
  %"phi_cast_R214_bitcast" = bitcast i32 %"legacy_result.37" to float
  br label %"BB_02b0"
BB_02b0:
  %"phi.10" = phi  float [%"phi_cast_R209_bitcast", %"BB_02a8_0b90"], [%"phi_cast_R211_bitcast", %"BB_02a8_0c38"], [%"phi_cast_R214_bitcast", %"BB_02a8_0c50"], [%"phi_cast_R199_bitcast", %"BB_02a8_0c60"], [%"phi_cast_R200_bitcast", %"BB_02a8_0c78"], [%"mufu_rsq", %"BB_02a8_0c88"], [%"fadd", %"BB_02a8_0ca0"], [%"ffma.13", %"BB_02a8_0b68"], [%"phi_cast_R208_bitcast", %"BB_02a8_0b88"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.1")
  %"legacy_join_live_mask" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.1", i1 1)
  br label %"BB_02c0"
BB_02c0:
  %"phi.11" = phi  float [%"phi.10", %"BB_02b0"], [%"ffma.4", %"BB_0298"]
  %"phi.12" = phi  i32 [%"legacy_join_live_mask", %"BB_02b0"], [%"legacy_path_mask.1", %"BB_0298"]
  %".475" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 376
  %".476" = bitcast i8* %".475" to i32*
  %"mov.7" = load i32, i32* %".476"
  %"f2f_ext" = fpext float %"phi.11" to double
  %"R9:R8_bitcast" = bitcast double %"f2f_ext" to i64
  %"R9:R8_r0" = trunc i64 %"R9:R8_bitcast" to i32
  %"R9:R8_r1_shift" = lshr i64 %"R9:R8_bitcast", 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %"imnmx_cmp" = icmp slt i32 %"sel", %"legacy_result.21"
  %"imnmx_max" = select  i1 %"imnmx_cmp", i32 %"sel", i32 %"legacy_result.21"
  %"legacy_a_wide.38" = zext i32 %"mov.7" to i64
  %"legacy_b_wide.38" = zext i32 25165824 to i64
  %"legacy_sum.38" = add i64 %"legacy_a_wide.38", %"legacy_b_wide.38"
  %"legacy_result.38" = trunc i64 %"legacy_sum.38" to i32
  %".477" = and i32 %"legacy_result.38", 2139095040
  %"isetrp_cmp1.18" = icmp ugt i32 %".477", 33554431
  %"isetrp_src_to_i32.18" = zext i1 1 to i32
  %"isetrp_src_to_i1.18" = icmp ne i32 %"isetrp_src_to_i32.18", 0
  %"isetrp_cmp2.18" = and i1 %"isetrp_cmp1.18", %"isetrp_src_to_i1.18"
  %"P18_to_i32" = zext i1 %"isetrp_cmp2.18" to i32
  %"imnmx_cmp.1" = icmp sgt i32 %".175", %"legacy_result.19"
  %"imnmx_max.1" = select  i1 %"imnmx_cmp.1", i32 %".175", i32 %"legacy_result.19"
  %"legacy_a_shift.4" = shl i32 %"imnmx_max", 6
  %"legacy_a_wide.39" = zext i32 %"legacy_a_shift.4" to i64
  %"legacy_b_wide.39" = zext i32 %"shl.2" to i64
  %"legacy_sum.39" = add i64 %"legacy_a_wide.39", %"legacy_b_wide.39"
  %"legacy_result.39" = trunc i64 %"legacy_sum.39" to i32
  %"legacy_a_shift.5" = shl i32 %"imnmx_max.1", 6
  %"legacy_a_wide.40" = zext i32 %"legacy_a_shift.5" to i64
  %"legacy_b_wide.40" = zext i32 %"shl.2" to i64
  %"legacy_sum.40" = add i64 %"legacy_a_wide.40", %"legacy_b_wide.40"
  %"legacy_result.40" = trunc i64 %"legacy_sum.40" to i32
  %"legacy_branch_predicate_trunc.12" = trunc i32 %"P18_to_i32" to i1
  %"legacy_taken_mask.12" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"phi.12", i1 %"legacy_branch_predicate_trunc.12")
  %".478" = xor i32 %"legacy_taken_mask.12", -1
  %"legacy_fallthrough_mask.12" = and i32 %"phi.12", %".478"
  %"legacy_path_mask.12" = select  i1 %"legacy_branch_predicate_trunc.12", i32 %"legacy_taken_mask.12", i32 %"legacy_fallthrough_mask.12"
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.19" = trunc i32 %"P18_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0348", label %"BB_0318"
BB_0318:
  %".481" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 376
  %".482" = bitcast i8* %".481" to i32*
  %"mov.8" = load i32, i32* %".482"
  br label %"BB_0328_07a8"
BB_0328_07a8:
  %"legacy_a_wide.41" = zext i32 %"mov.8" to i64
  %"legacy_b_wide.41" = zext i32 %"mov.8" to i64
  %"legacy_sum.41" = add i64 %"legacy_a_wide.41", %"legacy_b_wide.41"
  %"legacy_result.41" = trunc i64 %"legacy_sum.41" to i32
  %"shr_overflow.5" = icmp ugt i32 24, 31
  %"shr_clamp.5" = select  i1 %"shr_overflow.5", i32 31, i32 24
  %"shr_result.5" = lshr i32 %"legacy_result.41", %"shr_clamp.5"
  %"shr_zero.2" = select  i1 %"shr_overflow.5", i32 0, i32 %"shr_result.5"
  %"isetrp_cmp1.19" = icmp ne i32 %"shr_zero.2", 0
  %"isetrp_src_to_i32.19" = zext i1 1 to i32
  %"isetrp_src_to_i1.19" = icmp ne i32 %"isetrp_src_to_i32.19", 0
  %"isetrp_cmp2.19" = and i1 %"isetrp_cmp1.19", %"isetrp_src_to_i1.19"
  %"P33_to_i32" = zext i1 %"isetrp_cmp2.19" to i32
  %"legacy_branch_predicate_trunc.13" = trunc i32 %"P33_to_i32" to i1
  %"legacy_taken_mask.13" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.12", i1 %"legacy_branch_predicate_trunc.13")
  %".484" = xor i32 %"legacy_taken_mask.13", -1
  %"legacy_fallthrough_mask.13" = and i32 %"legacy_path_mask.12", %".484"
  %"legacy_path_mask.13" = select  i1 %"legacy_branch_predicate_trunc.13", i32 %"legacy_taken_mask.13", i32 %"legacy_fallthrough_mask.13"
  br label %"BB_0328_07c8"
BB_0328_07c8:
  %"cond_trunc.20" = trunc i32 %"P33_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0328_0830", label %"BB_0328_07d0"
BB_0328_07d0:
  %"legacy_a_wide.42" = zext i32 %"mov.8" to i64
  %"legacy_b_wide.42" = zext i32 %"mov.8" to i64
  %"legacy_sum.42" = add i64 %"legacy_a_wide.42", %"legacy_b_wide.42"
  %"legacy_result.42" = trunc i64 %"legacy_sum.42" to i32
  %"isetrp_cmp1.20" = icmp ne i32 %"legacy_result.42", 0
  %"isetrp_src_to_i32.20" = zext i1 1 to i32
  %"isetrp_src_to_i1.20" = icmp ne i32 %"isetrp_src_to_i32.20", 0
  %"isetrp_cmp2.20" = and i1 %"isetrp_cmp1.20", %"isetrp_src_to_i1.20"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.20" to i32
  br label %"BB_0328_07e0"
BB_0328_07e0:
  %"cond_trunc.21" = trunc i32 %"P36_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.21", -1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  %"phi_cast_R274_bitcast" = bitcast i32 %"legacy_result.42" to float
  br i1 %"pbra_cond_to_i1.21", label %"BB_0328_800007e0", label %"BB_0328_07e8"
BB_0328_800007e0:
  %"mufu_src_bitcast.2" = bitcast i32 %"mov.8" to float
  %"mufu_rcp.2" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.2")
  br label %"BB_0328_07e8"
BB_0328_07e8:
  %"phi.13" = phi  float [%"mufu_rcp.2", %"BB_0328_800007e0"], [%"phi_cast_R274_bitcast", %"BB_0328_07e0"]
  %"legacy_branch_predicate_trunc.14" = trunc i32 %"P36_to_i32" to i1
  %"legacy_branch_predicate_not.6" = xor i1 %"legacy_branch_predicate_trunc.14", -1
  %"legacy_taken_mask.14" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.13", i1 %"legacy_branch_predicate_not.6")
  %".490" = xor i32 %"legacy_taken_mask.14", -1
  %"legacy_fallthrough_mask.14" = and i32 %"legacy_path_mask.13", %".490"
  %"legacy_path_mask.14" = select  i1 %"legacy_branch_predicate_not.6", i32 %"legacy_taken_mask.14", i32 %"legacy_fallthrough_mask.14"
  br label %"BB_0328_07f0"
BB_0328_07f0:
  %"cond_trunc.22" = trunc i32 %"P36_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.22", -1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0330", label %"BB_0328_07f8"
BB_0328_07f8:
  %"ffma_lhs_bitcast.3" = bitcast i32 %"mov.8" to float
  %"ffma.14" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.3", float 0x43f0000000000000, float              0x0)
  %"mufu_rcp.3" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"ffma.14")
  %"ffma.15" = call float @"llvm.fma.f32"(float %"ffma.14", float %"mufu_rcp.3", float 0xbff0000000000000)
  %"fadd_lhs_fneg.1" = fneg float %"ffma.15"
  %"fadd.2" = fadd float %"fadd_lhs_fneg.1",              0x0
  %"ffma.16" = call float @"llvm.fma.f32"(float %"mufu_rcp.3", float %"fadd.2", float %"mufu_rcp.3")
  %"ffma.17" = call float @"llvm.fma.f32"(float %"ffma.16", float 0x43f0000000000000, float              0x0)
  br label %"BB_0330"
BB_0328_0830:
  %"legacy_a_wide.43" = zext i32 %"shr_zero.2" to i64
  %"legacy_b_wide.43" = zext i32 -253 to i64
  %"legacy_sum.43" = add i64 %"legacy_a_wide.43", %"legacy_b_wide.43"
  %"legacy_result.43" = trunc i64 %"legacy_sum.43" to i32
  %"isetrp_cmp1.21" = icmp ugt i32 %"legacy_result.43", 1
  %"isetrp_src_to_i32.21" = zext i1 1 to i32
  %"isetrp_src_to_i1.21" = icmp ne i32 %"isetrp_src_to_i32.21", 0
  %"isetrp_cmp2.21" = and i1 %"isetrp_cmp1.21", %"isetrp_src_to_i1.21"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.21" to i32
  %"legacy_branch_predicate_trunc.15" = trunc i32 %"P37_to_i32" to i1
  %"legacy_taken_mask.15" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.13", i1 %"legacy_branch_predicate_trunc.15")
  %".494" = xor i32 %"legacy_taken_mask.15", -1
  %"legacy_fallthrough_mask.15" = and i32 %"legacy_path_mask.13", %".494"
  %"legacy_path_mask.15" = select  i1 %"legacy_branch_predicate_trunc.15", i32 %"legacy_taken_mask.15", i32 %"legacy_fallthrough_mask.15"
  br label %"BB_0328_0848"
BB_0328_0848:
  %"cond_trunc.23" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_0328_0928", label %"BB_0328_0850"
BB_0328_0850:
  %".497" = and i32 %"mov.8", 8388607
  %"legacy_a_wide.44" = zext i32 %"shr_zero.2" to i64
  %"legacy_b_wide.44" = zext i32 -252 to i64
  %"legacy_sum.44" = add i64 %"legacy_a_wide.44", %"legacy_b_wide.44"
  %"legacy_result.44" = trunc i64 %"legacy_sum.44" to i32
  %".498" = or i32 %".497", 1065353216
  %"shl.4" = shl i32 3, %"legacy_result.43"
  %"mufu_src_bitcast.3" = bitcast i32 %".498" to float
  %"mufu_rcp.4" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.3")
  %"ffma_lhs_bitcast.4" = bitcast i32 %".498" to float
  %"ffma.18" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.4", float %"mufu_rcp.4", float 0xbff0000000000000)
  %"fadd_lhs_fneg.2" = fneg float %"ffma.18"
  %"fadd.3" = fadd float %"fadd_lhs_fneg.2",              0x0
  %"ffma_rm.1" = call float @"llvm.nvvm.fma.rm.f"(float %"mufu_rcp.4", float %"fadd.3", float %"mufu_rcp.4")
  %"ffma_rp.1" = call float @"llvm.nvvm.fma.rp.f"(float %"mufu_rcp.4", float %"fadd.3", float %"mufu_rcp.4")
  %"legacy_source_bitcast.8" = bitcast float %"ffma_rm.1" to i32
  %".499" = and i32 %"legacy_source_bitcast.8", 8388607
  %".500" = bitcast float %"ffma_rm.1" to i32
  %".501" = and i32 %".500", 2139095040
  %".502" = icmp eq i32 %".501", 0
  %".503" = and i32 %".500", 2147483648
  %".504" = select  i1 %".502", i32 %".503", i32 %".500"
  %".505" = bitcast i32 %".504" to float
  %".506" = bitcast float %"ffma_rp.1" to i32
  %".507" = and i32 %".506", 2139095040
  %".508" = icmp eq i32 %".507", 0
  %".509" = and i32 %".506", 2147483648
  %".510" = select  i1 %".508", i32 %".509", i32 %".506"
  %".511" = bitcast i32 %".510" to float
  %".512" = fcmp une float %".505", %".511"
  %".513" = and i1 %".512", 1
  %".514" = select  i1 %".513", i32 4294967295, i32 0
  %"R343_bitcast" = bitcast i32 %".514" to float
  %".515" = or i32 %".499", 8388608
  %"legacy_a_bitcast" = bitcast float %"R343_bitcast" to i32
  %"legacy_a_wide.45" = zext i32 %"legacy_a_bitcast" to i64
  %"legacy_a_complement.8" = xor i64 %"legacy_a_wide.45", 4294967295
  %"legacy_a_negate.8" = add i64 %"legacy_a_complement.8", 1
  %"legacy_b_wide.45" = zext i32 0 to i64
  %"legacy_sum.45" = add i64 %"legacy_a_negate.8", %"legacy_b_wide.45"
  %"legacy_result.45" = trunc i64 %"legacy_sum.45" to i32
  %".516" = and i32 %"shl.4", %".515"
  %".517" = xor i32 %"legacy_result.45", -1
  %".518" = and i32 %".517", %"legacy_result.43"
  %".519" = and i32 %".518", %".515"
  %".520" = or i32 0, %".519"
  %".521" = xor i32 %"legacy_result.43", -1
  %".522" = xor i32 %".515", -1
  %".523" = and i32 %"legacy_result.45", %".521"
  %".524" = and i32 %".523", %".522"
  %".525" = or i32 %".520", %".524"
  %".526" = xor i32 %"legacy_result.43", -1
  %".527" = and i32 %"legacy_result.45", %".526"
  %".528" = and i32 %".527", %".515"
  %".529" = or i32 %".525", %".528"
  %".530" = xor i32 %".515", -1
  %".531" = and i32 %"legacy_result.45", %"legacy_result.43"
  %".532" = and i32 %".531", %".530"
  %".533" = or i32 %".529", %".532"
  %".534" = and i32 %"legacy_result.45", %"legacy_result.43"
  %".535" = and i32 %".534", %".515"
  %".536" = or i32 %".533", %".535"
  %".537" = icmp ne i32 %".536", 0
  %"P76_to_i32" = zext i1 %".537" to i32
  %"shr_overflow.6" = icmp ugt i32 %"legacy_result.44", 31
  %"shr_clamp.6" = select  i1 %"shr_overflow.6", i32 31, i32 %"legacy_result.44"
  %"shr_result.6" = lshr i32 %".515", %"shr_clamp.6"
  %"shr_zero.3" = select  i1 %"shr_overflow.6", i32 0, i32 %"shr_result.6"
  %"shr_overflow.7" = icmp ugt i32 %"legacy_result.43", 31
  %"shr_clamp.7" = select  i1 %"shr_overflow.7", i32 31, i32 %"legacy_result.43"
  %"shr_result.7" = lshr i32 %".516", %"shr_clamp.7"
  %"shr_zero.4" = select  i1 %"shr_overflow.7", i32 0, i32 %"shr_result.7"
  %".538" = and i32 %"shr_zero.4", 2
  %".539" = icmp ne i32 %".538", 0
  %"P56_to_i32" = zext i1 %".539" to i32
  %".540" = and i32 %"shr_zero.4", 1
  %".541" = icmp ne i32 %".540", 0
  %"P38_to_i32" = zext i1 %".541" to i32
  %"legacy_source_trunc.8" = trunc i32 %"P76_to_i32" to i1
  %"legacy_pred_to_i32.12" = zext i1 %"legacy_source_trunc.8" to i32
  %"legacy_pred_to_i1.12" = icmp ne i32 %"legacy_pred_to_i32.12", 0
  %"legacy_source_trunc.9" = trunc i32 %"P56_to_i32" to i1
  %"legacy_pred_to_i32.13" = zext i1 %"legacy_source_trunc.9" to i32
  %"legacy_pred_to_i1.13" = icmp ne i32 %"legacy_pred_to_i32.13", 0
  %"legacy_pred_to_i32.14" = zext i1 1 to i32
  %"legacy_pred_to_i1.14" = icmp ne i32 %"legacy_pred_to_i32.14", 0
  %".542" = or i1 %"legacy_pred_to_i1.12", %"legacy_pred_to_i1.13"
  %".543" = and i1 %".542", %"legacy_pred_to_i1.14"
  %".544" = xor i1 %".542", -1
  %".545" = and i1 %".544", %"legacy_pred_to_i1.14"
  %"P12_to_i32" = zext i1 %".543" to i32
  %"isetrp_cmp1.22" = icmp eq i32 %".497", 0
  %"isetrp_src_to_i32.22" = zext i1 1 to i32
  %"isetrp_src_to_i1.22" = icmp ne i32 %"isetrp_src_to_i32.22", 0
  %"isetrp_cmp2.22" = and i1 %"isetrp_cmp1.22", %"isetrp_src_to_i1.22"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2.22" to i32
  %"legacy_source_trunc.10" = trunc i32 %"P38_to_i32" to i1
  %"legacy_pred_to_i32.15" = zext i1 %"legacy_source_trunc.10" to i32
  %"legacy_pred_to_i1.15" = icmp ne i32 %"legacy_pred_to_i32.15", 0
  %"legacy_source_trunc.11" = trunc i32 %"P12_to_i32" to i1
  %"legacy_pred_to_i32.16" = zext i1 %"legacy_source_trunc.11" to i32
  %"legacy_pred_to_i1.16" = icmp ne i32 %"legacy_pred_to_i32.16", 0
  %"legacy_pred_to_i32.17" = zext i1 1 to i32
  %"legacy_pred_to_i1.17" = icmp ne i32 %"legacy_pred_to_i32.17", 0
  %".546" = and i1 %"legacy_pred_to_i1.15", %"legacy_pred_to_i1.16"
  %".547" = and i1 %".546", %"legacy_pred_to_i1.17"
  %".548" = xor i1 %".546", -1
  %".549" = and i1 %".548", %"legacy_pred_to_i1.17"
  %"P39_to_i32" = zext i1 %".547" to i32
  br label %"BB_0328_0908"
BB_0328_0908:
  %"cond_trunc.24" = trunc i32 %"P39_to_i32" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_0328_80000908", label %"BB_0328_0910"
BB_0328_80000908:
  %"legacy_a_wide.46" = zext i32 %"shr_zero.3" to i64
  %"legacy_b_wide.46" = zext i32 1 to i64
  %"legacy_sum.46" = add i64 %"legacy_a_wide.46", %"legacy_b_wide.46"
  %"legacy_result.46" = trunc i64 %"legacy_sum.46" to i32
  br label %"BB_0328_0910"
BB_0328_0910:
  %"phi.14" = phi  i32 [%"legacy_result.46", %"BB_0328_80000908"], [%"shr_zero.3", %"BB_0328_0908"]
  %"cond_trunc.25" = trunc i32 %"P26_to_i32" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_0328_80000910", label %"BB_0328_0918"
BB_0328_80000910:
  %"shl.5" = shl i32 %"phi.14", 1
  br label %"BB_0328_0918"
BB_0328_0918:
  %"phi.15" = phi  i32 [%"shl.5", %"BB_0328_80000910"], [%"phi.14", %"BB_0328_0910"]
  %".555" = xor i32 %"phi.15", -1
  %".556" = and i32 %".555", 2147483648
  %".557" = and i32 %".556", %"mov.8"
  %".558" = or i32 0, %".557"
  %".559" = xor i32 2147483648, -1
  %".560" = xor i32 %"mov.8", -1
  %".561" = and i32 %"phi.15", %".559"
  %".562" = and i32 %".561", %".560"
  %".563" = or i32 %".558", %".562"
  %".564" = xor i32 2147483648, -1
  %".565" = and i32 %"phi.15", %".564"
  %".566" = and i32 %".565", %"mov.8"
  %".567" = or i32 %".563", %".566"
  %".568" = xor i32 %"mov.8", -1
  %".569" = and i32 %"phi.15", 2147483648
  %".570" = and i32 %".569", %".568"
  %".571" = or i32 %".567", %".570"
  %".572" = and i32 %"phi.15", 2147483648
  %".573" = and i32 %".572", %"mov.8"
  %".574" = or i32 %".571", %".573"
  %"phi_cast_R372_bitcast" = bitcast i32 %".574" to float
  br label %"BB_0330"
BB_0328_0928:
  %"mufu_src_bitcast.4" = bitcast i32 %"mov.8" to float
  %"mufu_rcp.5" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.4")
  br label %"BB_0330"
BB_0330:
  %"phi.16" = phi  float [%"ffma.17", %"BB_0328_07f8"], [%"phi_cast_R372_bitcast", %"BB_0328_0918"], [%"mufu_rcp.5", %"BB_0328_0928"], [%"phi.13", %"BB_0328_07f0"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.12")
  %"legacy_join_live_mask.1" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.12", i1 1)
  br label %"BB_0370"
BB_0348:
  %"mufu_src_bitcast.5" = bitcast i32 %"mov.7" to float
  %"mufu_rcp.6" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.5")
  %".578" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 376
  %".579" = bitcast i8* %".578" to float*
  %"ffma_rhs.2" = load float, float* %".579"
  %"ffma_addend_bitcast.3" = bitcast i32 1065353216 to float
  %"ffma_addend_fneg" = fneg float %"ffma_addend_bitcast.3"
  %"ffma.19" = call float @"llvm.fma.f32"(float %"mufu_rcp.6", float %"ffma_rhs.2", float %"ffma_addend_fneg")
  %"fadd_lhs_fneg.3" = fneg float %"ffma.19"
  %"fadd.4" = fadd float %"fadd_lhs_fneg.3",              0x0
  %"ffma.20" = call float @"llvm.fma.f32"(float %"mufu_rcp.6", float %"fadd.4", float %"mufu_rcp.6")
  br label %"BB_0370"
BB_0370:
  %"phi.17" = phi  i32 [%"legacy_join_live_mask.1", %"BB_0330"], [%"legacy_path_mask.12", %"BB_0348"]
  %"phi.18" = phi  float [%"phi.16", %"BB_0330"], [%"ffma.20", %"BB_0348"]
  %".581" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 372
  %".582" = bitcast i8* %".581" to i32*
  %"mov.9" = load i32, i32* %".582"
  %"f2f_ext.1" = fpext float %"phi.18" to double
  %"R11:R10_bitcast" = bitcast double %"f2f_ext.1" to i64
  %"R11:R10_r0" = trunc i64 %"R11:R10_bitcast" to i32
  %"R11:R10_r1_shift" = lshr i64 %"R11:R10_bitcast", 32
  %"R11:R10_r1" = trunc i64 %"R11:R10_r1_shift" to i32
  %"imnmx_cmp.2" = icmp slt i32 %"sel.1", %"legacy_result.23"
  %"imnmx_max.2" = select  i1 %"imnmx_cmp.2", i32 %"sel.1", i32 %"legacy_result.23"
  %"imnmx_cmp.3" = icmp sgt i32 %".172", %"legacy_result.22"
  %"imnmx_max.3" = select  i1 %"imnmx_cmp.3", i32 %".172", i32 %"legacy_result.22"
  %"legacy_a_wide.47" = zext i32 %"mov.9" to i64
  %"legacy_b_wide.47" = zext i32 25165824 to i64
  %"legacy_sum.47" = add i64 %"legacy_a_wide.47", %"legacy_b_wide.47"
  %"legacy_result.47" = trunc i64 %"legacy_sum.47" to i32
  %"legacy_a_shift.6" = shl i32 %"imnmx_max.2", 2
  %"legacy_a_wide.48" = zext i32 %"legacy_a_shift.6" to i64
  %"legacy_b_wide.48" = zext i32 %"shl.1" to i64
  %"legacy_sum.48" = add i64 %"legacy_a_wide.48", %"legacy_b_wide.48"
  %"legacy_result.48" = trunc i64 %"legacy_sum.48" to i32
  %"legacy_a_shift.7" = shl i32 %"imnmx_max.3", 2
  %"legacy_a_wide.49" = zext i32 %"legacy_a_shift.7" to i64
  %"legacy_b_wide.49" = zext i32 %"shl.1" to i64
  %"legacy_sum.49" = add i64 %"legacy_a_wide.49", %"legacy_b_wide.49"
  %"legacy_result.49" = trunc i64 %"legacy_sum.49" to i32
  %".583" = and i32 %"legacy_result.47", 2139095040
  %"isetrp_cmp1.23" = icmp ugt i32 %".583", 33554431
  %"isetrp_src_to_i32.23" = zext i1 1 to i32
  %"isetrp_src_to_i1.23" = icmp ne i32 %"isetrp_src_to_i32.23", 0
  %"isetrp_cmp2.23" = and i1 %"isetrp_cmp1.23", %"isetrp_src_to_i1.23"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.23" to i32
  %"legacy_branch_predicate_trunc.16" = trunc i32 %"P19_to_i32" to i1
  %"legacy_taken_mask.16" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"phi.17", i1 %"legacy_branch_predicate_trunc.16")
  %".584" = xor i32 %"legacy_taken_mask.16", -1
  %"legacy_fallthrough_mask.16" = and i32 %"phi.17", %".584"
  %"legacy_path_mask.16" = select  i1 %"legacy_branch_predicate_trunc.16", i32 %"legacy_taken_mask.16", i32 %"legacy_fallthrough_mask.16"
  br label %"BB_03c0"
BB_03c0:
  %"cond_trunc.26" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_trunc.26" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_03f8", label %"BB_03c8"
BB_03c8:
  %".587" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 372
  %".588" = bitcast i8* %".587" to i32*
  %"mov.10" = load i32, i32* %".588"
  br label %"BB_03d8_07a8"
BB_03d8_07a8:
  %"legacy_a_wide.50" = zext i32 %"mov.10" to i64
  %"legacy_b_wide.50" = zext i32 %"mov.10" to i64
  %"legacy_sum.50" = add i64 %"legacy_a_wide.50", %"legacy_b_wide.50"
  %"legacy_result.50" = trunc i64 %"legacy_sum.50" to i32
  %"shr_overflow.8" = icmp ugt i32 24, 31
  %"shr_clamp.8" = select  i1 %"shr_overflow.8", i32 31, i32 24
  %"shr_result.8" = lshr i32 %"legacy_result.50", %"shr_clamp.8"
  %"shr_zero.5" = select  i1 %"shr_overflow.8", i32 0, i32 %"shr_result.8"
  %"isetrp_cmp1.24" = icmp ne i32 %"shr_zero.5", 0
  %"isetrp_src_to_i32.24" = zext i1 1 to i32
  %"isetrp_src_to_i1.24" = icmp ne i32 %"isetrp_src_to_i32.24", 0
  %"isetrp_cmp2.24" = and i1 %"isetrp_cmp1.24", %"isetrp_src_to_i1.24"
  %"P40_to_i32" = zext i1 %"isetrp_cmp2.24" to i32
  %"legacy_branch_predicate_trunc.17" = trunc i32 %"P40_to_i32" to i1
  %"legacy_taken_mask.17" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.16", i1 %"legacy_branch_predicate_trunc.17")
  %".590" = xor i32 %"legacy_taken_mask.17", -1
  %"legacy_fallthrough_mask.17" = and i32 %"legacy_path_mask.16", %".590"
  %"legacy_path_mask.17" = select  i1 %"legacy_branch_predicate_trunc.17", i32 %"legacy_taken_mask.17", i32 %"legacy_fallthrough_mask.17"
  br label %"BB_03d8_07c8"
BB_03d8_07c8:
  %"cond_trunc.27" = trunc i32 %"P40_to_i32" to i1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_trunc.27" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_03d8_0830", label %"BB_03d8_07d0"
BB_03d8_07d0:
  %"legacy_a_wide.51" = zext i32 %"mov.10" to i64
  %"legacy_b_wide.51" = zext i32 %"mov.10" to i64
  %"legacy_sum.51" = add i64 %"legacy_a_wide.51", %"legacy_b_wide.51"
  %"legacy_result.51" = trunc i64 %"legacy_sum.51" to i32
  %"isetrp_cmp1.25" = icmp ne i32 %"legacy_result.51", 0
  %"isetrp_src_to_i32.25" = zext i1 1 to i32
  %"isetrp_src_to_i1.25" = icmp ne i32 %"isetrp_src_to_i32.25", 0
  %"isetrp_cmp2.25" = and i1 %"isetrp_cmp1.25", %"isetrp_src_to_i1.25"
  %"P41_to_i32" = zext i1 %"isetrp_cmp2.25" to i32
  br label %"BB_03d8_07e0"
BB_03d8_07e0:
  %"cond_trunc.28" = trunc i32 %"P41_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.28", -1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  %"phi_cast_R349_bitcast" = bitcast i32 %"legacy_result.51" to float
  br i1 %"pbra_cond_to_i1.28", label %"BB_03d8_800007e0", label %"BB_03d8_07e8"
BB_03d8_800007e0:
  %"mufu_src_bitcast.6" = bitcast i32 %"mov.10" to float
  %"mufu_rcp.7" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.6")
  br label %"BB_03d8_07e8"
BB_03d8_07e8:
  %"phi.19" = phi  float [%"mufu_rcp.7", %"BB_03d8_800007e0"], [%"phi_cast_R349_bitcast", %"BB_03d8_07e0"]
  %"legacy_branch_predicate_trunc.18" = trunc i32 %"P41_to_i32" to i1
  %"legacy_branch_predicate_not.7" = xor i1 %"legacy_branch_predicate_trunc.18", -1
  %"legacy_taken_mask.18" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.17", i1 %"legacy_branch_predicate_not.7")
  %".596" = xor i32 %"legacy_taken_mask.18", -1
  %"legacy_fallthrough_mask.18" = and i32 %"legacy_path_mask.17", %".596"
  %"legacy_path_mask.18" = select  i1 %"legacy_branch_predicate_not.7", i32 %"legacy_taken_mask.18", i32 %"legacy_fallthrough_mask.18"
  br label %"BB_03d8_07f0"
BB_03d8_07f0:
  %"cond_trunc.29" = trunc i32 %"P41_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.29", -1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_03e0", label %"BB_03d8_07f8"
BB_03d8_07f8:
  %"ffma_lhs_bitcast.5" = bitcast i32 %"mov.10" to float
  %"ffma.21" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.5", float 0x43f0000000000000, float              0x0)
  %"mufu_rcp.8" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"ffma.21")
  %"ffma.22" = call float @"llvm.fma.f32"(float %"ffma.21", float %"mufu_rcp.8", float 0xbff0000000000000)
  %"fadd_lhs_fneg.4" = fneg float %"ffma.22"
  %"fadd.5" = fadd float %"fadd_lhs_fneg.4",              0x0
  %"ffma.23" = call float @"llvm.fma.f32"(float %"mufu_rcp.8", float %"fadd.5", float %"mufu_rcp.8")
  %"ffma.24" = call float @"llvm.fma.f32"(float %"ffma.23", float 0x43f0000000000000, float              0x0)
  br label %"BB_03e0"
BB_03d8_0830:
  %"legacy_a_wide.52" = zext i32 %"shr_zero.5" to i64
  %"legacy_b_wide.52" = zext i32 -253 to i64
  %"legacy_sum.52" = add i64 %"legacy_a_wide.52", %"legacy_b_wide.52"
  %"legacy_result.52" = trunc i64 %"legacy_sum.52" to i32
  %"isetrp_cmp1.26" = icmp ugt i32 %"legacy_result.52", 1
  %"isetrp_src_to_i32.26" = zext i1 1 to i32
  %"isetrp_src_to_i1.26" = icmp ne i32 %"isetrp_src_to_i32.26", 0
  %"isetrp_cmp2.26" = and i1 %"isetrp_cmp1.26", %"isetrp_src_to_i1.26"
  %"P42_to_i32" = zext i1 %"isetrp_cmp2.26" to i32
  %"legacy_branch_predicate_trunc.19" = trunc i32 %"P42_to_i32" to i1
  %"legacy_taken_mask.19" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.17", i1 %"legacy_branch_predicate_trunc.19")
  %".600" = xor i32 %"legacy_taken_mask.19", -1
  %"legacy_fallthrough_mask.19" = and i32 %"legacy_path_mask.17", %".600"
  %"legacy_path_mask.19" = select  i1 %"legacy_branch_predicate_trunc.19", i32 %"legacy_taken_mask.19", i32 %"legacy_fallthrough_mask.19"
  br label %"BB_03d8_0848"
BB_03d8_0848:
  %"cond_trunc.30" = trunc i32 %"P42_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_03d8_0928", label %"BB_03d8_0850"
BB_03d8_0850:
  %".603" = and i32 %"mov.10", 8388607
  %"legacy_a_wide.53" = zext i32 %"shr_zero.5" to i64
  %"legacy_b_wide.53" = zext i32 -252 to i64
  %"legacy_sum.53" = add i64 %"legacy_a_wide.53", %"legacy_b_wide.53"
  %"legacy_result.53" = trunc i64 %"legacy_sum.53" to i32
  %".604" = or i32 %".603", 1065353216
  %"shl.6" = shl i32 3, %"legacy_result.52"
  %"mufu_src_bitcast.7" = bitcast i32 %".604" to float
  %"mufu_rcp.9" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.7")
  %"ffma_lhs_bitcast.6" = bitcast i32 %".604" to float
  %"ffma.25" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.6", float %"mufu_rcp.9", float 0xbff0000000000000)
  %"fadd_lhs_fneg.5" = fneg float %"ffma.25"
  %"fadd.6" = fadd float %"fadd_lhs_fneg.5",              0x0
  %"ffma_rm.2" = call float @"llvm.nvvm.fma.rm.f"(float %"mufu_rcp.9", float %"fadd.6", float %"mufu_rcp.9")
  %"ffma_rp.2" = call float @"llvm.nvvm.fma.rp.f"(float %"mufu_rcp.9", float %"fadd.6", float %"mufu_rcp.9")
  %"legacy_source_bitcast.9" = bitcast float %"ffma_rm.2" to i32
  %".605" = and i32 %"legacy_source_bitcast.9", 8388607
  %".606" = bitcast float %"ffma_rm.2" to i32
  %".607" = and i32 %".606", 2139095040
  %".608" = icmp eq i32 %".607", 0
  %".609" = and i32 %".606", 2147483648
  %".610" = select  i1 %".608", i32 %".609", i32 %".606"
  %".611" = bitcast i32 %".610" to float
  %".612" = bitcast float %"ffma_rp.2" to i32
  %".613" = and i32 %".612", 2139095040
  %".614" = icmp eq i32 %".613", 0
  %".615" = and i32 %".612", 2147483648
  %".616" = select  i1 %".614", i32 %".615", i32 %".612"
  %".617" = bitcast i32 %".616" to float
  %".618" = fcmp une float %".611", %".617"
  %".619" = and i1 %".618", 1
  %".620" = select  i1 %".619", i32 4294967295, i32 0
  %"R321_bitcast" = bitcast i32 %".620" to float
  %".621" = or i32 %".605", 8388608
  %"legacy_a_bitcast.1" = bitcast float %"R321_bitcast" to i32
  %"legacy_a_wide.54" = zext i32 %"legacy_a_bitcast.1" to i64
  %"legacy_a_complement.9" = xor i64 %"legacy_a_wide.54", 4294967295
  %"legacy_a_negate.9" = add i64 %"legacy_a_complement.9", 1
  %"legacy_b_wide.54" = zext i32 0 to i64
  %"legacy_sum.54" = add i64 %"legacy_a_negate.9", %"legacy_b_wide.54"
  %"legacy_result.54" = trunc i64 %"legacy_sum.54" to i32
  %".622" = and i32 %"shl.6", %".621"
  %".623" = xor i32 %"legacy_result.54", -1
  %".624" = and i32 %".623", %"legacy_result.52"
  %".625" = and i32 %".624", %".621"
  %".626" = or i32 0, %".625"
  %".627" = xor i32 %"legacy_result.52", -1
  %".628" = xor i32 %".621", -1
  %".629" = and i32 %"legacy_result.54", %".627"
  %".630" = and i32 %".629", %".628"
  %".631" = or i32 %".626", %".630"
  %".632" = xor i32 %"legacy_result.52", -1
  %".633" = and i32 %"legacy_result.54", %".632"
  %".634" = and i32 %".633", %".621"
  %".635" = or i32 %".631", %".634"
  %".636" = xor i32 %".621", -1
  %".637" = and i32 %"legacy_result.54", %"legacy_result.52"
  %".638" = and i32 %".637", %".636"
  %".639" = or i32 %".635", %".638"
  %".640" = and i32 %"legacy_result.54", %"legacy_result.52"
  %".641" = and i32 %".640", %".621"
  %".642" = or i32 %".639", %".641"
  %".643" = icmp ne i32 %".642", 0
  %"P34_to_i32" = zext i1 %".643" to i32
  %"shr_overflow.9" = icmp ugt i32 %"legacy_result.53", 31
  %"shr_clamp.9" = select  i1 %"shr_overflow.9", i32 31, i32 %"legacy_result.53"
  %"shr_result.9" = lshr i32 %".621", %"shr_clamp.9"
  %"shr_zero.6" = select  i1 %"shr_overflow.9", i32 0, i32 %"shr_result.9"
  %"shr_overflow.10" = icmp ugt i32 %"legacy_result.52", 31
  %"shr_clamp.10" = select  i1 %"shr_overflow.10", i32 31, i32 %"legacy_result.52"
  %"shr_result.10" = lshr i32 %".622", %"shr_clamp.10"
  %"shr_zero.7" = select  i1 %"shr_overflow.10", i32 0, i32 %"shr_result.10"
  %".644" = and i32 %"shr_zero.7", 2
  %".645" = icmp ne i32 %".644", 0
  %"P54_to_i32" = zext i1 %".645" to i32
  %".646" = and i32 %"shr_zero.7", 1
  %".647" = icmp ne i32 %".646", 0
  %"P46_to_i32" = zext i1 %".647" to i32
  %"legacy_source_trunc.12" = trunc i32 %"P34_to_i32" to i1
  %"legacy_pred_to_i32.18" = zext i1 %"legacy_source_trunc.12" to i32
  %"legacy_pred_to_i1.18" = icmp ne i32 %"legacy_pred_to_i32.18", 0
  %"legacy_source_trunc.13" = trunc i32 %"P54_to_i32" to i1
  %"legacy_pred_to_i32.19" = zext i1 %"legacy_source_trunc.13" to i32
  %"legacy_pred_to_i1.19" = icmp ne i32 %"legacy_pred_to_i32.19", 0
  %"legacy_pred_to_i32.20" = zext i1 1 to i32
  %"legacy_pred_to_i1.20" = icmp ne i32 %"legacy_pred_to_i32.20", 0
  %".648" = or i1 %"legacy_pred_to_i1.18", %"legacy_pred_to_i1.19"
  %".649" = and i1 %".648", %"legacy_pred_to_i1.20"
  %".650" = xor i1 %".648", -1
  %".651" = and i1 %".650", %"legacy_pred_to_i1.20"
  %"P45_to_i32" = zext i1 %".649" to i32
  %"isetrp_cmp1.27" = icmp eq i32 %".603", 0
  %"isetrp_src_to_i32.27" = zext i1 1 to i32
  %"isetrp_src_to_i1.27" = icmp ne i32 %"isetrp_src_to_i32.27", 0
  %"isetrp_cmp2.27" = and i1 %"isetrp_cmp1.27", %"isetrp_src_to_i1.27"
  %"P62_to_i32" = zext i1 %"isetrp_cmp2.27" to i32
  %"legacy_source_trunc.14" = trunc i32 %"P46_to_i32" to i1
  %"legacy_pred_to_i32.21" = zext i1 %"legacy_source_trunc.14" to i32
  %"legacy_pred_to_i1.21" = icmp ne i32 %"legacy_pred_to_i32.21", 0
  %"legacy_source_trunc.15" = trunc i32 %"P45_to_i32" to i1
  %"legacy_pred_to_i32.22" = zext i1 %"legacy_source_trunc.15" to i32
  %"legacy_pred_to_i1.22" = icmp ne i32 %"legacy_pred_to_i32.22", 0
  %"legacy_pred_to_i32.23" = zext i1 1 to i32
  %"legacy_pred_to_i1.23" = icmp ne i32 %"legacy_pred_to_i32.23", 0
  %".652" = and i1 %"legacy_pred_to_i1.21", %"legacy_pred_to_i1.22"
  %".653" = and i1 %".652", %"legacy_pred_to_i1.23"
  %".654" = xor i1 %".652", -1
  %".655" = and i1 %".654", %"legacy_pred_to_i1.23"
  %"P47_to_i32" = zext i1 %".653" to i32
  br label %"BB_03d8_0908"
BB_03d8_0908:
  %"cond_trunc.31" = trunc i32 %"P47_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_03d8_80000908", label %"BB_03d8_0910"
BB_03d8_80000908:
  %"legacy_a_wide.55" = zext i32 %"shr_zero.6" to i64
  %"legacy_b_wide.55" = zext i32 1 to i64
  %"legacy_sum.55" = add i64 %"legacy_a_wide.55", %"legacy_b_wide.55"
  %"legacy_result.55" = trunc i64 %"legacy_sum.55" to i32
  br label %"BB_03d8_0910"
BB_03d8_0910:
  %"phi.20" = phi  i32 [%"legacy_result.55", %"BB_03d8_80000908"], [%"shr_zero.6", %"BB_03d8_0908"]
  %"cond_trunc.32" = trunc i32 %"P62_to_i32" to i1
  %"pbra_cond_to_i32.32" = zext i1 %"cond_trunc.32" to i32
  %"pbra_cond_to_i1.32" = icmp ne i32 %"pbra_cond_to_i32.32", 0
  br i1 %"pbra_cond_to_i1.32", label %"BB_03d8_80000910", label %"BB_03d8_0918"
BB_03d8_80000910:
  %"shl.7" = shl i32 %"phi.20", 1
  br label %"BB_03d8_0918"
BB_03d8_0918:
  %"phi.21" = phi  i32 [%"shl.7", %"BB_03d8_80000910"], [%"phi.20", %"BB_03d8_0910"]
  %".661" = xor i32 %"phi.21", -1
  %".662" = and i32 %".661", 2147483648
  %".663" = and i32 %".662", %"mov.10"
  %".664" = or i32 0, %".663"
  %".665" = xor i32 2147483648, -1
  %".666" = xor i32 %"mov.10", -1
  %".667" = and i32 %"phi.21", %".665"
  %".668" = and i32 %".667", %".666"
  %".669" = or i32 %".664", %".668"
  %".670" = xor i32 2147483648, -1
  %".671" = and i32 %"phi.21", %".670"
  %".672" = and i32 %".671", %"mov.10"
  %".673" = or i32 %".669", %".672"
  %".674" = xor i32 %"mov.10", -1
  %".675" = and i32 %"phi.21", 2147483648
  %".676" = and i32 %".675", %".674"
  %".677" = or i32 %".673", %".676"
  %".678" = and i32 %"phi.21", 2147483648
  %".679" = and i32 %".678", %"mov.10"
  %".680" = or i32 %".677", %".679"
  %"phi_cast_R80_bitcast" = bitcast i32 %".680" to float
  br label %"BB_03e0"
BB_03d8_0928:
  %"mufu_src_bitcast.8" = bitcast i32 %"mov.10" to float
  %"mufu_rcp.10" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.8")
  br label %"BB_03e0"
BB_03e0:
  %"phi.22" = phi  float [%"ffma.24", %"BB_03d8_07f8"], [%"phi_cast_R80_bitcast", %"BB_03d8_0918"], [%"mufu_rcp.10", %"BB_03d8_0928"], [%"phi.19", %"BB_03d8_07f0"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.16")
  %"legacy_join_live_mask.2" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.16", i1 1)
  br label %"BB_0420"
BB_03f8:
  %"mufu_src_bitcast.9" = bitcast i32 %"mov.9" to float
  %"mufu_rcp.11" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.9")
  %".684" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 372
  %".685" = bitcast i8* %".684" to float*
  %"ffma_rhs.3" = load float, float* %".685"
  %"ffma_addend_bitcast.4" = bitcast i32 1065353216 to float
  %"ffma_addend_fneg.1" = fneg float %"ffma_addend_bitcast.4"
  %"ffma.26" = call float @"llvm.fma.f32"(float %"mufu_rcp.11", float %"ffma_rhs.3", float %"ffma_addend_fneg.1")
  %"fadd_lhs_fneg.6" = fneg float %"ffma.26"
  %"fadd.7" = fadd float %"fadd_lhs_fneg.6",              0x0
  %"ffma.27" = call float @"llvm.fma.f32"(float %"mufu_rcp.11", float %"fadd.7", float %"mufu_rcp.11")
  br label %"BB_0420"
BB_0420:
  %"phi.23" = phi  i32 [%"legacy_join_live_mask.2", %"BB_03e0"], [%"legacy_path_mask.16", %"BB_03f8"]
  %"phi.24" = phi  float [%"phi.22", %"BB_03e0"], [%"ffma.27", %"BB_03f8"]
  %".687" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 380
  %".688" = bitcast i8* %".687" to i32*
  %"mov.11" = load i32, i32* %".688"
  %"f2f_ext.2" = fpext float %"phi.24" to double
  %"R13:R12_bitcast" = bitcast double %"f2f_ext.2" to i64
  %"R13:R12_r0" = trunc i64 %"R13:R12_bitcast" to i32
  %"R13:R12_r1_shift" = lshr i64 %"R13:R12_bitcast", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"isetrp_cmp1.28" = icmp sge i32 %"tid_y", %".175"
  %"isetrp_src_to_i32.28" = zext i1 1 to i32
  %"isetrp_src_to_i1.28" = icmp ne i32 %"isetrp_src_to_i32.28", 0
  %"isetrp_cmp2.28" = and i1 %"isetrp_cmp1.28", %"isetrp_src_to_i1.28"
  %"P20_to_i32" = zext i1 %"isetrp_cmp2.28" to i32
  %"legacy_a_wide.56" = zext i32 0 to i64
  %".689" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 320
  %".690" = bitcast i8* %".689" to i32*
  %"legacy_b.8" = load i32, i32* %".690"
  %"legacy_b_wide.56" = zext i32 %"legacy_b.8" to i64
  %"legacy_b_complement.2" = xor i64 %"legacy_b_wide.56", 4294967295
  %"legacy_b_negate.2" = add i64 %"legacy_b_complement.2", 1
  %"legacy_sum.56" = add i64 %"legacy_a_wide.56", %"legacy_b_negate.2"
  %"legacy_result.56" = trunc i64 %"legacy_sum.56" to i32
  %"isetrp_src_trunc.4" = trunc i32 %"P35_to_i32" to i1
  %"isetrp_src_not.2" = xor i1 %"isetrp_src_trunc.4", -1
  %"isetrp_cmp1.29" = icmp sgt i32 %"tid_x", %"sel.1"
  %"isetrp_src_to_i32.29" = zext i1 %"isetrp_src_not.2" to i32
  %"isetrp_src_to_i1.29" = icmp ne i32 %"isetrp_src_to_i32.29", 0
  %"isetrp_cmp2.29" = or i1 %"isetrp_cmp1.29", %"isetrp_src_to_i1.29"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.29" to i32
  %"legacy_a_wide.57" = zext i32 %"mov.11" to i64
  %"legacy_b_wide.57" = zext i32 25165824 to i64
  %"legacy_sum.57" = add i64 %"legacy_a_wide.57", %"legacy_b_wide.57"
  %"legacy_result.57" = trunc i64 %"legacy_sum.57" to i32
  %".691" = and i32 %"legacy_result.57", 2139095040
  %"isetrp_src_trunc.5" = trunc i32 %"P20_to_i32" to i1
  %"isetrp_src_not.3" = xor i1 %"isetrp_src_trunc.5", -1
  %"isetrp_cmp1.30" = icmp sgt i32 %"tid_y", %"sel"
  %"isetrp_src_to_i32.30" = zext i1 %"isetrp_src_not.3" to i32
  %"isetrp_src_to_i1.30" = icmp ne i32 %"isetrp_src_to_i32.30", 0
  %"isetrp_cmp2.30" = or i1 %"isetrp_cmp1.30", %"isetrp_src_to_i1.30"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.30" to i32
  %"isetrp_cmp1.31" = icmp ugt i32 %".691", 33554431
  %"isetrp_src_to_i32.31" = zext i1 1 to i32
  %"isetrp_src_to_i1.31" = icmp ne i32 %"isetrp_src_to_i32.31", 0
  %"isetrp_cmp2.31" = and i1 %"isetrp_cmp1.31", %"isetrp_src_to_i1.31"
  %"P48_to_i32" = zext i1 %"isetrp_cmp2.31" to i32
  %"legacy_branch_predicate_trunc.20" = trunc i32 %"P48_to_i32" to i1
  %"legacy_taken_mask.20" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"phi.23", i1 %"legacy_branch_predicate_trunc.20")
  %".692" = xor i32 %"legacy_taken_mask.20", -1
  %"legacy_fallthrough_mask.20" = and i32 %"phi.23", %".692"
  %"legacy_path_mask.20" = select  i1 %"legacy_branch_predicate_trunc.20", i32 %"legacy_taken_mask.20", i32 %"legacy_fallthrough_mask.20"
  br label %"BB_0470"
BB_0470:
  %"cond_trunc.33" = trunc i32 %"P48_to_i32" to i1
  %"pbra_cond_to_i32.33" = zext i1 %"cond_trunc.33" to i32
  %"pbra_cond_to_i1.33" = icmp ne i32 %"pbra_cond_to_i32.33", 0
  br i1 %"pbra_cond_to_i1.33", label %"BB_04a8", label %"BB_0478"
BB_0478:
  %".695" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 380
  %".696" = bitcast i8* %".695" to i32*
  %"mov.12" = load i32, i32* %".696"
  br label %"BB_0488_07a8"
BB_0488_07a8:
  %"legacy_a_wide.58" = zext i32 %"mov.12" to i64
  %"legacy_b_wide.58" = zext i32 %"mov.12" to i64
  %"legacy_sum.58" = add i64 %"legacy_a_wide.58", %"legacy_b_wide.58"
  %"legacy_result.58" = trunc i64 %"legacy_sum.58" to i32
  %"shr_overflow.11" = icmp ugt i32 24, 31
  %"shr_clamp.11" = select  i1 %"shr_overflow.11", i32 31, i32 24
  %"shr_result.11" = lshr i32 %"legacy_result.58", %"shr_clamp.11"
  %"shr_zero.8" = select  i1 %"shr_overflow.11", i32 0, i32 %"shr_result.11"
  %"isetrp_cmp1.32" = icmp ne i32 %"shr_zero.8", 0
  %"isetrp_src_to_i32.32" = zext i1 1 to i32
  %"isetrp_src_to_i1.32" = icmp ne i32 %"isetrp_src_to_i32.32", 0
  %"isetrp_cmp2.32" = and i1 %"isetrp_cmp1.32", %"isetrp_src_to_i1.32"
  %"P49_to_i32" = zext i1 %"isetrp_cmp2.32" to i32
  %"legacy_branch_predicate_trunc.21" = trunc i32 %"P49_to_i32" to i1
  %"legacy_taken_mask.21" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.20", i1 %"legacy_branch_predicate_trunc.21")
  %".698" = xor i32 %"legacy_taken_mask.21", -1
  %"legacy_fallthrough_mask.21" = and i32 %"legacy_path_mask.20", %".698"
  %"legacy_path_mask.21" = select  i1 %"legacy_branch_predicate_trunc.21", i32 %"legacy_taken_mask.21", i32 %"legacy_fallthrough_mask.21"
  br label %"BB_0488_07c8"
BB_0488_07c8:
  %"cond_trunc.34" = trunc i32 %"P49_to_i32" to i1
  %"pbra_cond_to_i32.34" = zext i1 %"cond_trunc.34" to i32
  %"pbra_cond_to_i1.34" = icmp ne i32 %"pbra_cond_to_i32.34", 0
  br i1 %"pbra_cond_to_i1.34", label %"BB_0488_0830", label %"BB_0488_07d0"
BB_0488_07d0:
  %"legacy_a_wide.59" = zext i32 %"mov.12" to i64
  %"legacy_b_wide.59" = zext i32 %"mov.12" to i64
  %"legacy_sum.59" = add i64 %"legacy_a_wide.59", %"legacy_b_wide.59"
  %"legacy_result.59" = trunc i64 %"legacy_sum.59" to i32
  %"isetrp_cmp1.33" = icmp ne i32 %"legacy_result.59", 0
  %"isetrp_src_to_i32.33" = zext i1 1 to i32
  %"isetrp_src_to_i1.33" = icmp ne i32 %"isetrp_src_to_i32.33", 0
  %"isetrp_cmp2.33" = and i1 %"isetrp_cmp1.33", %"isetrp_src_to_i1.33"
  %"P50_to_i32" = zext i1 %"isetrp_cmp2.33" to i32
  br label %"BB_0488_07e0"
BB_0488_07e0:
  %"cond_trunc.35" = trunc i32 %"P50_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.35", -1
  %"pbra_cond_to_i32.35" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.35" = icmp ne i32 %"pbra_cond_to_i32.35", 0
  %"phi_cast_R144_bitcast" = bitcast i32 %"legacy_result.59" to float
  br i1 %"pbra_cond_to_i1.35", label %"BB_0488_800007e0", label %"BB_0488_07e8"
BB_0488_800007e0:
  %"mufu_src_bitcast.10" = bitcast i32 %"mov.12" to float
  %"mufu_rcp.12" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.10")
  br label %"BB_0488_07e8"
BB_0488_07e8:
  %"phi.25" = phi  float [%"mufu_rcp.12", %"BB_0488_800007e0"], [%"phi_cast_R144_bitcast", %"BB_0488_07e0"]
  %"legacy_branch_predicate_trunc.22" = trunc i32 %"P50_to_i32" to i1
  %"legacy_branch_predicate_not.8" = xor i1 %"legacy_branch_predicate_trunc.22", -1
  %"legacy_taken_mask.22" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.21", i1 %"legacy_branch_predicate_not.8")
  %".704" = xor i32 %"legacy_taken_mask.22", -1
  %"legacy_fallthrough_mask.22" = and i32 %"legacy_path_mask.21", %".704"
  %"legacy_path_mask.22" = select  i1 %"legacy_branch_predicate_not.8", i32 %"legacy_taken_mask.22", i32 %"legacy_fallthrough_mask.22"
  br label %"BB_0488_07f0"
BB_0488_07f0:
  %"cond_trunc.36" = trunc i32 %"P50_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.36", -1
  %"pbra_cond_to_i32.36" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.36" = icmp ne i32 %"pbra_cond_to_i32.36", 0
  br i1 %"pbra_cond_to_i1.36", label %"BB_0490", label %"BB_0488_07f8"
BB_0488_07f8:
  %"ffma_lhs_bitcast.7" = bitcast i32 %"mov.12" to float
  %"ffma.28" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.7", float 0x43f0000000000000, float              0x0)
  %"mufu_rcp.13" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"ffma.28")
  %"ffma.29" = call float @"llvm.fma.f32"(float %"ffma.28", float %"mufu_rcp.13", float 0xbff0000000000000)
  %"fadd_lhs_fneg.7" = fneg float %"ffma.29"
  %"fadd.8" = fadd float %"fadd_lhs_fneg.7",              0x0
  %"ffma.30" = call float @"llvm.fma.f32"(float %"mufu_rcp.13", float %"fadd.8", float %"mufu_rcp.13")
  %"ffma.31" = call float @"llvm.fma.f32"(float %"ffma.30", float 0x43f0000000000000, float              0x0)
  %"phi_cast_R252_bitcast" = bitcast float %"ffma.28" to i32
  br label %"BB_0490"
BB_0488_0830:
  %"legacy_a_wide.60" = zext i32 %"shr_zero.8" to i64
  %"legacy_b_wide.60" = zext i32 -253 to i64
  %"legacy_sum.60" = add i64 %"legacy_a_wide.60", %"legacy_b_wide.60"
  %"legacy_result.60" = trunc i64 %"legacy_sum.60" to i32
  %"isetrp_cmp1.34" = icmp ugt i32 %"legacy_result.60", 1
  %"isetrp_src_to_i32.34" = zext i1 1 to i32
  %"isetrp_src_to_i1.34" = icmp ne i32 %"isetrp_src_to_i32.34", 0
  %"isetrp_cmp2.34" = and i1 %"isetrp_cmp1.34", %"isetrp_src_to_i1.34"
  %"P51_to_i32" = zext i1 %"isetrp_cmp2.34" to i32
  %"legacy_branch_predicate_trunc.23" = trunc i32 %"P51_to_i32" to i1
  %"legacy_taken_mask.23" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.21", i1 %"legacy_branch_predicate_trunc.23")
  %".708" = xor i32 %"legacy_taken_mask.23", -1
  %"legacy_fallthrough_mask.23" = and i32 %"legacy_path_mask.21", %".708"
  %"legacy_path_mask.23" = select  i1 %"legacy_branch_predicate_trunc.23", i32 %"legacy_taken_mask.23", i32 %"legacy_fallthrough_mask.23"
  br label %"BB_0488_0848"
BB_0488_0848:
  %"cond_trunc.37" = trunc i32 %"P51_to_i32" to i1
  %"pbra_cond_to_i32.37" = zext i1 %"cond_trunc.37" to i32
  %"pbra_cond_to_i1.37" = icmp ne i32 %"pbra_cond_to_i32.37", 0
  br i1 %"pbra_cond_to_i1.37", label %"BB_0488_0928", label %"BB_0488_0850"
BB_0488_0850:
  %".711" = and i32 %"mov.12", 8388607
  %"legacy_a_wide.61" = zext i32 %"shr_zero.8" to i64
  %"legacy_b_wide.61" = zext i32 -252 to i64
  %"legacy_sum.61" = add i64 %"legacy_a_wide.61", %"legacy_b_wide.61"
  %"legacy_result.61" = trunc i64 %"legacy_sum.61" to i32
  %".712" = or i32 %".711", 1065353216
  %"shl.8" = shl i32 3, %"legacy_result.60"
  %"mufu_src_bitcast.11" = bitcast i32 %".712" to float
  %"mufu_rcp.14" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.11")
  %"ffma_lhs_bitcast.8" = bitcast i32 %".712" to float
  %"ffma.32" = call float @"llvm.fma.f32"(float %"ffma_lhs_bitcast.8", float %"mufu_rcp.14", float 0xbff0000000000000)
  %"fadd_lhs_fneg.8" = fneg float %"ffma.32"
  %"fadd.9" = fadd float %"fadd_lhs_fneg.8",              0x0
  %"ffma_rm.3" = call float @"llvm.nvvm.fma.rm.f"(float %"mufu_rcp.14", float %"fadd.9", float %"mufu_rcp.14")
  %"ffma_rp.3" = call float @"llvm.nvvm.fma.rp.f"(float %"mufu_rcp.14", float %"fadd.9", float %"mufu_rcp.14")
  %"legacy_source_bitcast.10" = bitcast float %"ffma_rm.3" to i32
  %".713" = and i32 %"legacy_source_bitcast.10", 8388607
  %".714" = bitcast float %"ffma_rm.3" to i32
  %".715" = and i32 %".714", 2139095040
  %".716" = icmp eq i32 %".715", 0
  %".717" = and i32 %".714", 2147483648
  %".718" = select  i1 %".716", i32 %".717", i32 %".714"
  %".719" = bitcast i32 %".718" to float
  %".720" = bitcast float %"ffma_rp.3" to i32
  %".721" = and i32 %".720", 2139095040
  %".722" = icmp eq i32 %".721", 0
  %".723" = and i32 %".720", 2147483648
  %".724" = select  i1 %".722", i32 %".723", i32 %".720"
  %".725" = bitcast i32 %".724" to float
  %".726" = fcmp une float %".719", %".725"
  %".727" = and i1 %".726", 1
  %".728" = select  i1 %".727", i32 4294967295, i32 0
  %"R327_bitcast" = bitcast i32 %".728" to float
  %".729" = or i32 %".713", 8388608
  %"legacy_a_bitcast.2" = bitcast float %"R327_bitcast" to i32
  %"legacy_a_wide.62" = zext i32 %"legacy_a_bitcast.2" to i64
  %"legacy_a_complement.10" = xor i64 %"legacy_a_wide.62", 4294967295
  %"legacy_a_negate.10" = add i64 %"legacy_a_complement.10", 1
  %"legacy_b_wide.62" = zext i32 0 to i64
  %"legacy_sum.62" = add i64 %"legacy_a_negate.10", %"legacy_b_wide.62"
  %"legacy_result.62" = trunc i64 %"legacy_sum.62" to i32
  %".730" = and i32 %"shl.8", %".729"
  %".731" = xor i32 %"legacy_result.62", -1
  %".732" = and i32 %".731", %"legacy_result.60"
  %".733" = and i32 %".732", %".729"
  %".734" = or i32 0, %".733"
  %".735" = xor i32 %"legacy_result.60", -1
  %".736" = xor i32 %".729", -1
  %".737" = and i32 %"legacy_result.62", %".735"
  %".738" = and i32 %".737", %".736"
  %".739" = or i32 %".734", %".738"
  %".740" = xor i32 %"legacy_result.60", -1
  %".741" = and i32 %"legacy_result.62", %".740"
  %".742" = and i32 %".741", %".729"
  %".743" = or i32 %".739", %".742"
  %".744" = xor i32 %".729", -1
  %".745" = and i32 %"legacy_result.62", %"legacy_result.60"
  %".746" = and i32 %".745", %".744"
  %".747" = or i32 %".743", %".746"
  %".748" = and i32 %"legacy_result.62", %"legacy_result.60"
  %".749" = and i32 %".748", %".729"
  %".750" = or i32 %".747", %".749"
  %".751" = icmp ne i32 %".750", 0
  %"P68_to_i32" = zext i1 %".751" to i32
  %"shr_overflow.12" = icmp ugt i32 %"legacy_result.61", 31
  %"shr_clamp.12" = select  i1 %"shr_overflow.12", i32 31, i32 %"legacy_result.61"
  %"shr_result.12" = lshr i32 %".729", %"shr_clamp.12"
  %"shr_zero.9" = select  i1 %"shr_overflow.12", i32 0, i32 %"shr_result.12"
  %"shr_overflow.13" = icmp ugt i32 %"legacy_result.60", 31
  %"shr_clamp.13" = select  i1 %"shr_overflow.13", i32 31, i32 %"legacy_result.60"
  %"shr_result.13" = lshr i32 %".730", %"shr_clamp.13"
  %"shr_zero.10" = select  i1 %"shr_overflow.13", i32 0, i32 %"shr_result.13"
  %".752" = and i32 %"shr_zero.10", 2
  %".753" = icmp ne i32 %".752", 0
  %"P67_to_i32" = zext i1 %".753" to i32
  %".754" = and i32 %"shr_zero.10", 1
  %".755" = icmp ne i32 %".754", 0
  %"P52_to_i32" = zext i1 %".755" to i32
  %"legacy_source_trunc.16" = trunc i32 %"P68_to_i32" to i1
  %"legacy_pred_to_i32.24" = zext i1 %"legacy_source_trunc.16" to i32
  %"legacy_pred_to_i1.24" = icmp ne i32 %"legacy_pred_to_i32.24", 0
  %"legacy_source_trunc.17" = trunc i32 %"P67_to_i32" to i1
  %"legacy_pred_to_i32.25" = zext i1 %"legacy_source_trunc.17" to i32
  %"legacy_pred_to_i1.25" = icmp ne i32 %"legacy_pred_to_i32.25", 0
  %"legacy_pred_to_i32.26" = zext i1 1 to i32
  %"legacy_pred_to_i1.26" = icmp ne i32 %"legacy_pred_to_i32.26", 0
  %".756" = or i1 %"legacy_pred_to_i1.24", %"legacy_pred_to_i1.25"
  %".757" = and i1 %".756", %"legacy_pred_to_i1.26"
  %".758" = xor i1 %".756", -1
  %".759" = and i1 %".758", %"legacy_pred_to_i1.26"
  %"P69_to_i32" = zext i1 %".757" to i32
  %"isetrp_cmp1.35" = icmp eq i32 %".711", 0
  %"isetrp_src_to_i32.35" = zext i1 1 to i32
  %"isetrp_src_to_i1.35" = icmp ne i32 %"isetrp_src_to_i32.35", 0
  %"isetrp_cmp2.35" = and i1 %"isetrp_cmp1.35", %"isetrp_src_to_i1.35"
  %"P77_to_i32" = zext i1 %"isetrp_cmp2.35" to i32
  %"legacy_source_trunc.18" = trunc i32 %"P52_to_i32" to i1
  %"legacy_pred_to_i32.27" = zext i1 %"legacy_source_trunc.18" to i32
  %"legacy_pred_to_i1.27" = icmp ne i32 %"legacy_pred_to_i32.27", 0
  %"legacy_source_trunc.19" = trunc i32 %"P69_to_i32" to i1
  %"legacy_pred_to_i32.28" = zext i1 %"legacy_source_trunc.19" to i32
  %"legacy_pred_to_i1.28" = icmp ne i32 %"legacy_pred_to_i32.28", 0
  %"legacy_pred_to_i32.29" = zext i1 1 to i32
  %"legacy_pred_to_i1.29" = icmp ne i32 %"legacy_pred_to_i32.29", 0
  %".760" = and i1 %"legacy_pred_to_i1.27", %"legacy_pred_to_i1.28"
  %".761" = and i1 %".760", %"legacy_pred_to_i1.29"
  %".762" = xor i1 %".760", -1
  %".763" = and i1 %".762", %"legacy_pred_to_i1.29"
  %"P53_to_i32" = zext i1 %".761" to i32
  br label %"BB_0488_0908"
BB_0488_0908:
  %"cond_trunc.38" = trunc i32 %"P53_to_i32" to i1
  %"pbra_cond_to_i32.38" = zext i1 %"cond_trunc.38" to i32
  %"pbra_cond_to_i1.38" = icmp ne i32 %"pbra_cond_to_i32.38", 0
  br i1 %"pbra_cond_to_i1.38", label %"BB_0488_80000908", label %"BB_0488_0910"
BB_0488_80000908:
  %"legacy_a_wide.63" = zext i32 %"shr_zero.9" to i64
  %"legacy_b_wide.63" = zext i32 1 to i64
  %"legacy_sum.63" = add i64 %"legacy_a_wide.63", %"legacy_b_wide.63"
  %"legacy_result.63" = trunc i64 %"legacy_sum.63" to i32
  br label %"BB_0488_0910"
BB_0488_0910:
  %"phi.26" = phi  i32 [%"legacy_result.63", %"BB_0488_80000908"], [%"shr_zero.9", %"BB_0488_0908"]
  %"cond_trunc.39" = trunc i32 %"P77_to_i32" to i1
  %"pbra_cond_to_i32.39" = zext i1 %"cond_trunc.39" to i32
  %"pbra_cond_to_i1.39" = icmp ne i32 %"pbra_cond_to_i32.39", 0
  br i1 %"pbra_cond_to_i1.39", label %"BB_0488_80000910", label %"BB_0488_0918"
BB_0488_80000910:
  %"shl.9" = shl i32 %"phi.26", 1
  br label %"BB_0488_0918"
BB_0488_0918:
  %"phi.27" = phi  i32 [%"shl.9", %"BB_0488_80000910"], [%"phi.26", %"BB_0488_0910"]
  %".769" = xor i32 %"phi.27", -1
  %".770" = and i32 %".769", 2147483648
  %".771" = and i32 %".770", %"mov.12"
  %".772" = or i32 0, %".771"
  %".773" = xor i32 2147483648, -1
  %".774" = xor i32 %"mov.12", -1
  %".775" = and i32 %"phi.27", %".773"
  %".776" = and i32 %".775", %".774"
  %".777" = or i32 %".772", %".776"
  %".778" = xor i32 2147483648, -1
  %".779" = and i32 %"phi.27", %".778"
  %".780" = and i32 %".779", %"mov.12"
  %".781" = or i32 %".777", %".780"
  %".782" = xor i32 %"mov.12", -1
  %".783" = and i32 %"phi.27", 2147483648
  %".784" = and i32 %".783", %".782"
  %".785" = or i32 %".781", %".784"
  %".786" = and i32 %"phi.27", 2147483648
  %".787" = and i32 %".786", %"mov.12"
  %".788" = or i32 %".785", %".787"
  %"phi_cast_R281_bitcast" = bitcast i32 %".788" to float
  br label %"BB_0490"
BB_0488_0928:
  %"mufu_src_bitcast.12" = bitcast i32 %"mov.12" to float
  %"mufu_rcp.15" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.12")
  br label %"BB_0490"
BB_0490:
  %"phi.28" = phi  float [%"ffma.31", %"BB_0488_07f8"], [%"phi_cast_R281_bitcast", %"BB_0488_0918"], [%"mufu_rcp.15", %"BB_0488_0928"], [%"phi.25", %"BB_0488_07f0"]
  %"phi.29" = phi  i32 [%"phi_cast_R252_bitcast", %"BB_0488_07f8"], [%"mov.12", %"BB_0488_0918"], [%"mov.12", %"BB_0488_0928"], [%"mov.12", %"BB_0488_07f0"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.20")
  %"legacy_join_live_mask.3" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.20", i1 1)
  br label %"BB_04d0"
BB_04a8:
  %"mufu_src_bitcast.13" = bitcast i32 %"mov.11" to float
  %"mufu_rcp.16" = call float @"llvm.nvvm.rcp.approx.ftz.f"(float %"mufu_src_bitcast.13")
  %".792" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 380
  %".793" = bitcast i8* %".792" to float*
  %"ffma_rhs.4" = load float, float* %".793"
  %"ffma_addend_bitcast.5" = bitcast i32 1065353216 to float
  %"ffma_addend_fneg.2" = fneg float %"ffma_addend_bitcast.5"
  %"ffma.33" = call float @"llvm.fma.f32"(float %"mufu_rcp.16", float %"ffma_rhs.4", float %"ffma_addend_fneg.2")
  %"fadd_lhs_fneg.9" = fneg float %"ffma.33"
  %"fadd.10" = fadd float %"fadd_lhs_fneg.9",              0x0
  %"ffma.34" = call float @"llvm.fma.f32"(float %"mufu_rcp.16", float %"fadd.10", float %"mufu_rcp.16")
  %"phi_cast_R256_bitcast" = bitcast float %"fadd.10" to i32
  br label %"BB_04d0"
BB_04d0:
  %"phi.30" = phi  i32 [0, %"BB_0490"], [0, %"BB_04a8"], [%"legacy_result.65", %"BB_0720"]
  %"phi.31" = phi  float [%"phi.28", %"BB_0490"], [%"ffma.34", %"BB_04a8"], [%"phi.31", %"BB_0720"]
  %"phi.32" = phi  i32 [%"legacy_result.56", %"BB_0490"], [%"legacy_result.56", %"BB_04a8"], [%"legacy_result.66", %"BB_0720"]
  %"phi.33" = phi  i32 [%"legacy_join_live_mask.3", %"BB_0490"], [%"legacy_path_mask.20", %"BB_04a8"], [%"legacy_path_mask.26", %"BB_0720"]
  %"phi.34" = phi  i32 [%"phi.29", %"BB_0490"], [%"phi_cast_R256_bitcast", %"BB_04a8"], [%"phi.35", %"BB_0720"]
  %"isetrp_cmp1.36" = icmp sgt i32 %"tid_y", %"phi.30"
  %"isetrp_src_to_i32.36" = zext i1 1 to i32
  %"isetrp_src_to_i1.36" = icmp ne i32 %"isetrp_src_to_i32.36", 0
  %"isetrp_cmp2.36" = and i1 %"isetrp_cmp1.36", %"isetrp_src_to_i1.36"
  %"P71_to_i32" = zext i1 %"isetrp_cmp2.36" to i32
  %"legacy_a_wide.64" = zext i32 %"phi.30" to i64
  %"legacy_a_complement.11" = xor i64 %"legacy_a_wide.64", 4294967295
  %"legacy_a_negate.11" = add i64 %"legacy_a_complement.11", 1
  %"legacy_b_wide.64" = zext i32 14 to i64
  %"legacy_sum.64" = add i64 %"legacy_a_negate.11", %"legacy_b_wide.64"
  %"legacy_result.64" = trunc i64 %"legacy_sum.64" to i32
  %"isetrp_cmp1.37" = icmp ne i32 %"phi.32", -1
  %"isetrp_src_to_i32.37" = zext i1 1 to i32
  %"isetrp_src_to_i1.37" = icmp ne i32 %"isetrp_src_to_i32.37", 0
  %"isetrp_cmp2.37" = and i1 %"isetrp_cmp1.37", %"isetrp_src_to_i1.37"
  %"P78_to_i32" = zext i1 %"isetrp_cmp2.37" to i32
  %".795" = lshr i32 %"phi.34", 16
  %".796" = trunc i32 %".795" to i16
  %".797" = zext i16 %".796" to i32
  %".798" = trunc i32 1 to i16
  %".799" = zext i16 %".798" to i32
  %"xmad_product.9" = mul i32 %".797", %".799"
  %"xmad_psl.3" = shl i32 %"xmad_product.9", 16
  %"xmad_clo" = and i32 0, 65535
  %"xmad_sum.9" = add i32 %"xmad_psl.3", %"xmad_clo"
  %"isetrp_cmp1.38" = icmp sgt i32 %"tid_x", %"legacy_result.64"
  %"isetrp_src_to_i32.38" = zext i1 1 to i32
  %"isetrp_src_to_i1.38" = icmp ne i32 %"isetrp_src_to_i32.38", 0
  %"isetrp_cmp2.38" = and i1 %"isetrp_cmp1.38", %"isetrp_src_to_i1.38"
  %"P57_to_i32" = zext i1 %"isetrp_cmp2.38" to i32
  %"isetrp_src_trunc.6" = trunc i32 %"P71_to_i32" to i1
  %"isetrp_src_not.4" = xor i1 %"isetrp_src_trunc.6", -1
  %"isetrp_cmp1.39" = icmp sgt i32 %"tid_y", %"legacy_result.64"
  %"isetrp_src_to_i32.39" = zext i1 %"isetrp_src_not.4" to i32
  %"isetrp_src_to_i1.39" = icmp ne i32 %"isetrp_src_to_i32.39", 0
  %"isetrp_cmp2.39" = or i1 %"isetrp_cmp1.39", %"isetrp_src_to_i1.39"
  %"P72_to_i32" = zext i1 %"isetrp_cmp2.39" to i32
  %"isetrp_src_trunc.7" = trunc i32 %"P57_to_i32" to i1
  %"isetrp_cmp1.40" = icmp sle i32 %"tid_x", %"phi.30"
  %"isetrp_src_to_i32.40" = zext i1 %"isetrp_src_trunc.7" to i32
  %"isetrp_src_to_i1.40" = icmp ne i32 %"isetrp_src_to_i32.40", 0
  %"isetrp_cmp2.40" = or i1 %"isetrp_cmp1.40", %"isetrp_src_to_i1.40"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.40" to i32
  %"legacy_source_trunc.20" = trunc i32 %"P72_to_i32" to i1
  %"legacy_pred_to_i32.30" = zext i1 %"legacy_source_trunc.20" to i32
  %"legacy_pred_to_i1.30" = icmp ne i32 %"legacy_pred_to_i32.30", 0
  %"legacy_source_trunc.21" = trunc i32 %"P44_to_i32" to i1
  %"legacy_pred_to_i32.31" = zext i1 %"legacy_source_trunc.21" to i32
  %"legacy_pred_to_i1.31" = icmp ne i32 %"legacy_pred_to_i32.31", 0
  %"legacy_pred_to_i32.32" = zext i1 1 to i32
  %"legacy_pred_to_i1.32" = icmp ne i32 %"legacy_pred_to_i32.32", 0
  %".800" = or i1 %"legacy_pred_to_i1.30", %"legacy_pred_to_i1.31"
  %".801" = and i1 %".800", %"legacy_pred_to_i1.32"
  %".802" = xor i1 %".800", -1
  %".803" = and i1 %".802", %"legacy_pred_to_i1.32"
  %"P73_to_i32" = zext i1 %".801" to i32
  %"legacy_source_trunc.22" = trunc i32 %"P73_to_i32" to i1
  %"legacy_pred_to_i32.33" = zext i1 %"legacy_source_trunc.22" to i32
  %"legacy_pred_to_i1.33" = icmp ne i32 %"legacy_pred_to_i32.33", 0
  %"legacy_source_trunc.23" = trunc i32 %"P21_to_i32" to i1
  %"legacy_pred_to_i32.34" = zext i1 %"legacy_source_trunc.23" to i32
  %"legacy_pred_to_i1.34" = icmp ne i32 %"legacy_pred_to_i32.34", 0
  %"legacy_pred_to_i32.35" = zext i1 1 to i32
  %"legacy_pred_to_i1.35" = icmp ne i32 %"legacy_pred_to_i32.35", 0
  %".804" = or i1 %"legacy_pred_to_i1.33", %"legacy_pred_to_i1.34"
  %".805" = and i1 %".804", %"legacy_pred_to_i1.35"
  %".806" = xor i1 %".804", -1
  %".807" = and i1 %".806", %"legacy_pred_to_i1.35"
  %"P74_to_i32" = zext i1 %".805" to i32
  %"legacy_source_trunc.24" = trunc i32 %"P58_to_i32" to i1
  %"legacy_pred_to_i32.36" = zext i1 %"legacy_source_trunc.24" to i32
  %"legacy_pred_to_i1.36" = icmp ne i32 %"legacy_pred_to_i32.36", 0
  %"legacy_source_trunc.25" = trunc i32 %"P74_to_i32" to i1
  %"legacy_pred_to_i32.37" = zext i1 %"legacy_source_trunc.25" to i32
  %"legacy_pred_to_i1.37" = icmp ne i32 %"legacy_pred_to_i32.37", 0
  %"legacy_pred_to_i32.38" = zext i1 1 to i32
  %"legacy_pred_to_i1.38" = icmp ne i32 %"legacy_pred_to_i32.38", 0
  %".808" = or i1 %"legacy_pred_to_i1.36", %"legacy_pred_to_i1.37"
  %".809" = and i1 %".808", %"legacy_pred_to_i1.38"
  %".810" = xor i1 %".808", -1
  %".811" = and i1 %".810", %"legacy_pred_to_i1.38"
  %"P59_to_i32" = zext i1 %".809" to i32
  %"legacy_branch_predicate_trunc.24" = trunc i32 %"P59_to_i32" to i1
  %"legacy_taken_mask.24" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"phi.33", i1 %"legacy_branch_predicate_trunc.24")
  %".812" = xor i32 %"legacy_taken_mask.24", -1
  %"legacy_fallthrough_mask.24" = and i32 %"phi.33", %".812"
  %"legacy_path_mask.24" = select  i1 %"legacy_branch_predicate_trunc.24", i32 %"legacy_taken_mask.24", i32 %"legacy_fallthrough_mask.24"
  br label %"BB_0530"
BB_0530:
  %"cond_trunc.40" = trunc i32 %"P59_to_i32" to i1
  %"pbra_cond_to_i32.40" = zext i1 %"cond_trunc.40" to i32
  %"pbra_cond_to_i1.40" = icmp ne i32 %"pbra_cond_to_i32.40", 0
  br i1 %"pbra_cond_to_i1.40", label %"BB_0678", label %"BB_0538"
BB_0538:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"lds_shared_addr_winoff" = and i32 %"legacy_result.40", 16777215
  %".815" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".815" to float addrspace(3)*
  %"lds" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"lds_shared_addr_winoff.1" = and i32 %"legacy_result.39", 16777215
  %".816" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".816" to float addrspace(3)*
  %"lds.1" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.1"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"lds_shared_addr_winoff.2" = and i32 %"legacy_result.9", 16777215
  %".817" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".817" to float addrspace(3)*
  %"lds.2" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.2"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"lds_addr_memaddr_offset_add" = add i32 %"legacy_result.9", 1024
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".818" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".818" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"fadd.11" = fadd float %"lds", %"lds.1"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"lds_shared_addr_winoff.4" = and i32 %"legacy_result.49", 16777215
  %".819" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".819" to float addrspace(3)*
  %"lds.4" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.4"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"lds_shared_addr_winoff.5" = and i32 %"legacy_result.48", 16777215
  %".820" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".820" to float addrspace(3)*
  %"lds.5" = load volatile float, float addrspace(3)* %"lds_shared_addr_cast.5"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"f2f_ext.3" = fpext float %"lds.2" to double
  %"R15:R14_bitcast" = bitcast double %"f2f_ext.3" to i64
  %"R15:R14_r0" = trunc i64 %"R15:R14_bitcast" to i32
  %"R15:R14_r1_shift" = lshr i64 %"R15:R14_bitcast", 32
  %"R15:R14_r1" = trunc i64 %"R15:R14_r1_shift" to i32
  %"fadd_lhs_fneg.10" = fneg float %"lds.2"
  %"fadd.12" = fadd float %"fadd_lhs_fneg.10", 0x4054000000000000
  %"fmul" = fmul float %"phi.31", %"fadd.12"
  %"fadd.13" = fadd float %"lds.4", %"lds.5"
  %"dadd_lhs_r0_bitcast" = bitcast i32 %"R15:R14_r0" to float
  %"dadd_lhs_r0_i32_bitcast" = bitcast float %"dadd_lhs_r0_bitcast" to i32
  %"dadd_lhs_r0_ext" = zext i32 %"dadd_lhs_r0_i32_bitcast" to i64
  %"dadd_lhs_packed_0" = or i64 0, %"dadd_lhs_r0_ext"
  %"dadd_lhs_r1_bitcast" = bitcast i32 %"R15:R14_r1" to float
  %"dadd_lhs_r1_i32_bitcast" = bitcast float %"dadd_lhs_r1_bitcast" to i32
  %"dadd_lhs_r1_ext" = zext i32 %"dadd_lhs_r1_i32_bitcast" to i64
  %"dadd_lhs_r1_shift" = shl i64 %"dadd_lhs_r1_ext", 32
  %"dadd_lhs_packed_1" = or i64 %"dadd_lhs_packed_0", %"dadd_lhs_r1_shift"
  %"dadd_lhs_bitcast" = bitcast i64 %"dadd_lhs_packed_1" to double
  %"dadd_rhs_r0_bitcast" = bitcast i32 %"R15:R14_r0" to float
  %"dadd_rhs_r0_i32_bitcast" = bitcast float %"dadd_rhs_r0_bitcast" to i32
  %"dadd_rhs_r0_ext" = zext i32 %"dadd_rhs_r0_i32_bitcast" to i64
  %"dadd_rhs_packed_0" = or i64 0, %"dadd_rhs_r0_ext"
  %"dadd_rhs_r1_bitcast" = bitcast i32 %"R15:R14_r1" to float
  %"dadd_rhs_r1_i32_bitcast" = bitcast float %"dadd_rhs_r1_bitcast" to i32
  %"dadd_rhs_r1_ext" = zext i32 %"dadd_rhs_r1_i32_bitcast" to i64
  %"dadd_rhs_r1_shift" = shl i64 %"dadd_rhs_r1_ext", 32
  %"dadd_rhs_packed_1" = or i64 %"dadd_rhs_packed_0", %"dadd_rhs_r1_shift"
  %"dadd_rhs_bitcast" = bitcast i64 %"dadd_rhs_packed_1" to double
  %"dadd" = fadd double %"dadd_lhs_bitcast", %"dadd_rhs_bitcast"
  %"R19:R18_bitcast" = bitcast double %"dadd" to i64
  %"R19:R18_r0" = trunc i64 %"R19:R18_bitcast" to i32
  %"R19:R18_r1_shift" = lshr i64 %"R19:R18_bitcast", 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %"f2f_ext.4" = fpext float %"fadd.11" to double
  %"R29:R28_bitcast" = bitcast double %"f2f_ext.4" to i64
  %"R29:R28_r0" = trunc i64 %"R29:R28_bitcast" to i32
  %"R29:R28_r1_shift" = lshr i64 %"R29:R28_bitcast", 32
  %"R29:R28_r1" = trunc i64 %"R29:R28_r1_shift" to i32
  %"dadd_lhs_r0_bitcast.1" = bitcast i32 %"R29:R28_r0" to float
  %"dadd_lhs_r0_i32_bitcast.1" = bitcast float %"dadd_lhs_r0_bitcast.1" to i32
  %"dadd_lhs_r0_ext.1" = zext i32 %"dadd_lhs_r0_i32_bitcast.1" to i64
  %"dadd_lhs_packed_0.1" = or i64 0, %"dadd_lhs_r0_ext.1"
  %"dadd_lhs_r1_bitcast.1" = bitcast i32 %"R29:R28_r1" to float
  %"dadd_lhs_r1_i32_bitcast.1" = bitcast float %"dadd_lhs_r1_bitcast.1" to i32
  %"dadd_lhs_r1_ext.1" = zext i32 %"dadd_lhs_r1_i32_bitcast.1" to i64
  %"dadd_lhs_r1_shift.1" = shl i64 %"dadd_lhs_r1_ext.1", 32
  %"dadd_lhs_packed_1.1" = or i64 %"dadd_lhs_packed_0.1", %"dadd_lhs_r1_shift.1"
  %"dadd_lhs_bitcast.1" = bitcast i64 %"dadd_lhs_packed_1.1" to double
  %"dadd_rhs_r0_bitcast.1" = bitcast i32 %"R19:R18_r0" to float
  %"dadd_rhs_r0_i32_bitcast.1" = bitcast float %"dadd_rhs_r0_bitcast.1" to i32
  %"dadd_rhs_r0_ext.1" = zext i32 %"dadd_rhs_r0_i32_bitcast.1" to i64
  %"dadd_rhs_packed_0.1" = or i64 0, %"dadd_rhs_r0_ext.1"
  %"dadd_rhs_r1_bitcast.1" = bitcast i32 %"R19:R18_r1" to float
  %"dadd_rhs_r1_i32_bitcast.1" = bitcast float %"dadd_rhs_r1_bitcast.1" to i32
  %"dadd_rhs_r1_ext.1" = zext i32 %"dadd_rhs_r1_i32_bitcast.1" to i64
  %"dadd_rhs_r1_shift.1" = shl i64 %"dadd_rhs_r1_ext.1", 32
  %"dadd_rhs_packed_1.1" = or i64 %"dadd_rhs_packed_0.1", %"dadd_rhs_r1_shift.1"
  %"dadd_rhs_bitcast.1" = bitcast i64 %"dadd_rhs_packed_1.1" to double
  %"dadd_rhs_fneg" = fneg double %"dadd_rhs_bitcast.1"
  %"dadd.1" = fadd double %"dadd_lhs_bitcast.1", %"dadd_rhs_fneg"
  %"R29:R28_bitcast.1" = bitcast double %"dadd.1" to i64
  %"R29:R28_r0.1" = trunc i64 %"R29:R28_bitcast.1" to i32
  %"R29:R28_r1_shift.1" = lshr i64 %"R29:R28_bitcast.1", 32
  %"R29:R28_r1.1" = trunc i64 %"R29:R28_r1_shift.1" to i32
  %"f2f_src_bitcast" = bitcast i32 %"lds.3" to float
  %"f2f_ext.5" = fpext float %"f2f_src_bitcast" to double
  %"R21:R20_bitcast" = bitcast double %"f2f_ext.5" to i64
  %"R21:R20_r0" = trunc i64 %"R21:R20_bitcast" to i32
  %"R21:R20_r1_shift" = lshr i64 %"R21:R20_bitcast", 32
  %"R21:R20_r1" = trunc i64 %"R21:R20_r1_shift" to i32
  %"dfma_lhs_r0_bitcast" = bitcast i32 %"R11:R10_r0" to float
  %"dfma_lhs_r0_i32_bitcast" = bitcast float %"dfma_lhs_r0_bitcast" to i32
  %"dfma_lhs_r0_ext" = zext i32 %"dfma_lhs_r0_i32_bitcast" to i64
  %"dfma_lhs_packed_0" = or i64 0, %"dfma_lhs_r0_ext"
  %"dfma_lhs_r1_bitcast" = bitcast i32 %"R11:R10_r1" to float
  %"dfma_lhs_r1_i32_bitcast" = bitcast float %"dfma_lhs_r1_bitcast" to i32
  %"dfma_lhs_r1_ext" = zext i32 %"dfma_lhs_r1_i32_bitcast" to i64
  %"dfma_lhs_r1_shift" = shl i64 %"dfma_lhs_r1_ext", 32
  %"dfma_lhs_packed_1" = or i64 %"dfma_lhs_packed_0", %"dfma_lhs_r1_shift"
  %"dfma_lhs_bitcast" = bitcast i64 %"dfma_lhs_packed_1" to double
  %"dfma_rhs_r0_bitcast" = bitcast i32 %"R29:R28_r0.1" to float
  %"dfma_rhs_r0_i32_bitcast" = bitcast float %"dfma_rhs_r0_bitcast" to i32
  %"dfma_rhs_r0_ext" = zext i32 %"dfma_rhs_r0_i32_bitcast" to i64
  %"dfma_rhs_packed_0" = or i64 0, %"dfma_rhs_r0_ext"
  %"dfma_rhs_r1_bitcast" = bitcast i32 %"R29:R28_r1.1" to float
  %"dfma_rhs_r1_i32_bitcast" = bitcast float %"dfma_rhs_r1_bitcast" to i32
  %"dfma_rhs_r1_ext" = zext i32 %"dfma_rhs_r1_i32_bitcast" to i64
  %"dfma_rhs_r1_shift" = shl i64 %"dfma_rhs_r1_ext", 32
  %"dfma_rhs_packed_1" = or i64 %"dfma_rhs_packed_0", %"dfma_rhs_r1_shift"
  %"dfma_rhs_bitcast" = bitcast i64 %"dfma_rhs_packed_1" to double
  %"dfma_addend_r0_bitcast" = bitcast i32 %"R21:R20_r0" to float
  %"dfma_addend_r0_i32_bitcast" = bitcast float %"dfma_addend_r0_bitcast" to i32
  %"dfma_addend_r0_ext" = zext i32 %"dfma_addend_r0_i32_bitcast" to i64
  %"dfma_addend_packed_0" = or i64 0, %"dfma_addend_r0_ext"
  %"dfma_addend_r1_bitcast" = bitcast i32 %"R21:R20_r1" to float
  %"dfma_addend_r1_i32_bitcast" = bitcast float %"dfma_addend_r1_bitcast" to i32
  %"dfma_addend_r1_ext" = zext i32 %"dfma_addend_r1_i32_bitcast" to i64
  %"dfma_addend_r1_shift" = shl i64 %"dfma_addend_r1_ext", 32
  %"dfma_addend_packed_1" = or i64 %"dfma_addend_packed_0", %"dfma_addend_r1_shift"
  %"dfma_addend_bitcast" = bitcast i64 %"dfma_addend_packed_1" to double
  %"dfma" = call double @"llvm.fma.f64"(double %"dfma_lhs_bitcast", double %"dfma_rhs_bitcast", double %"dfma_addend_bitcast")
  %"R21:R20_bitcast.1" = bitcast double %"dfma" to i64
  %"R21:R20_r0.1" = trunc i64 %"R21:R20_bitcast.1" to i32
  %"R21:R20_r1_shift.1" = lshr i64 %"R21:R20_bitcast.1", 32
  %"R21:R20_r1.1" = trunc i64 %"R21:R20_r1_shift.1" to i32
  %"f2f_ext.6" = fpext float %"fadd.13" to double
  %"R25:R24_bitcast" = bitcast double %"f2f_ext.6" to i64
  %"R25:R24_r0" = trunc i64 %"R25:R24_bitcast" to i32
  %"R25:R24_r1_shift" = lshr i64 %"R25:R24_bitcast", 32
  %"R25:R24_r1" = trunc i64 %"R25:R24_r1_shift" to i32
  %"dadd_lhs_r0_bitcast.2" = bitcast i32 %"R19:R18_r0" to float
  %"dadd_lhs_r0_i32_bitcast.2" = bitcast float %"dadd_lhs_r0_bitcast.2" to i32
  %"dadd_lhs_r0_ext.2" = zext i32 %"dadd_lhs_r0_i32_bitcast.2" to i64
  %"dadd_lhs_packed_0.2" = or i64 0, %"dadd_lhs_r0_ext.2"
  %"dadd_lhs_r1_bitcast.2" = bitcast i32 %"R19:R18_r1" to float
  %"dadd_lhs_r1_i32_bitcast.2" = bitcast float %"dadd_lhs_r1_bitcast.2" to i32
  %"dadd_lhs_r1_ext.2" = zext i32 %"dadd_lhs_r1_i32_bitcast.2" to i64
  %"dadd_lhs_r1_shift.2" = shl i64 %"dadd_lhs_r1_ext.2", 32
  %"dadd_lhs_packed_1.2" = or i64 %"dadd_lhs_packed_0.2", %"dadd_lhs_r1_shift.2"
  %"dadd_lhs_bitcast.2" = bitcast i64 %"dadd_lhs_packed_1.2" to double
  %"dadd_lhs_fneg" = fneg double %"dadd_lhs_bitcast.2"
  %"dadd_rhs_r0_bitcast.2" = bitcast i32 %"R25:R24_r0" to float
  %"dadd_rhs_r0_i32_bitcast.2" = bitcast float %"dadd_rhs_r0_bitcast.2" to i32
  %"dadd_rhs_r0_ext.2" = zext i32 %"dadd_rhs_r0_i32_bitcast.2" to i64
  %"dadd_rhs_packed_0.2" = or i64 0, %"dadd_rhs_r0_ext.2"
  %"dadd_rhs_r1_bitcast.2" = bitcast i32 %"R25:R24_r1" to float
  %"dadd_rhs_r1_i32_bitcast.2" = bitcast float %"dadd_rhs_r1_bitcast.2" to i32
  %"dadd_rhs_r1_ext.2" = zext i32 %"dadd_rhs_r1_i32_bitcast.2" to i64
  %"dadd_rhs_r1_shift.2" = shl i64 %"dadd_rhs_r1_ext.2", 32
  %"dadd_rhs_packed_1.2" = or i64 %"dadd_rhs_packed_0.2", %"dadd_rhs_r1_shift.2"
  %"dadd_rhs_bitcast.2" = bitcast i64 %"dadd_rhs_packed_1.2" to double
  %"dadd.2" = fadd double %"dadd_lhs_fneg", %"dadd_rhs_bitcast.2"
  %"R19:R18_bitcast.1" = bitcast double %"dadd.2" to i64
  %"R19:R18_r0.1" = trunc i64 %"R19:R18_bitcast.1" to i32
  %"R19:R18_r1_shift.1" = lshr i64 %"R19:R18_bitcast.1", 32
  %"R19:R18_r1.1" = trunc i64 %"R19:R18_r1_shift.1" to i32
  %"dfma_lhs_r0_bitcast.1" = bitcast i32 %"R13:R12_r0" to float
  %"dfma_lhs_r0_i32_bitcast.1" = bitcast float %"dfma_lhs_r0_bitcast.1" to i32
  %"dfma_lhs_r0_ext.1" = zext i32 %"dfma_lhs_r0_i32_bitcast.1" to i64
  %"dfma_lhs_packed_0.1" = or i64 0, %"dfma_lhs_r0_ext.1"
  %"dfma_lhs_r1_bitcast.1" = bitcast i32 %"R13:R12_r1" to float
  %"dfma_lhs_r1_i32_bitcast.1" = bitcast float %"dfma_lhs_r1_bitcast.1" to i32
  %"dfma_lhs_r1_ext.1" = zext i32 %"dfma_lhs_r1_i32_bitcast.1" to i64
  %"dfma_lhs_r1_shift.1" = shl i64 %"dfma_lhs_r1_ext.1", 32
  %"dfma_lhs_packed_1.1" = or i64 %"dfma_lhs_packed_0.1", %"dfma_lhs_r1_shift.1"
  %"dfma_lhs_bitcast.1" = bitcast i64 %"dfma_lhs_packed_1.1" to double
  %"dfma_rhs_r0_bitcast.1" = bitcast i32 %"R19:R18_r0.1" to float
  %"dfma_rhs_r0_i32_bitcast.1" = bitcast float %"dfma_rhs_r0_bitcast.1" to i32
  %"dfma_rhs_r0_ext.1" = zext i32 %"dfma_rhs_r0_i32_bitcast.1" to i64
  %"dfma_rhs_packed_0.1" = or i64 0, %"dfma_rhs_r0_ext.1"
  %"dfma_rhs_r1_bitcast.1" = bitcast i32 %"R19:R18_r1.1" to float
  %"dfma_rhs_r1_i32_bitcast.1" = bitcast float %"dfma_rhs_r1_bitcast.1" to i32
  %"dfma_rhs_r1_ext.1" = zext i32 %"dfma_rhs_r1_i32_bitcast.1" to i64
  %"dfma_rhs_r1_shift.1" = shl i64 %"dfma_rhs_r1_ext.1", 32
  %"dfma_rhs_packed_1.1" = or i64 %"dfma_rhs_packed_0.1", %"dfma_rhs_r1_shift.1"
  %"dfma_rhs_bitcast.1" = bitcast i64 %"dfma_rhs_packed_1.1" to double
  %"dfma_addend_r0_bitcast.1" = bitcast i32 %"R21:R20_r0.1" to float
  %"dfma_addend_r0_i32_bitcast.1" = bitcast float %"dfma_addend_r0_bitcast.1" to i32
  %"dfma_addend_r0_ext.1" = zext i32 %"dfma_addend_r0_i32_bitcast.1" to i64
  %"dfma_addend_packed_0.1" = or i64 0, %"dfma_addend_r0_ext.1"
  %"dfma_addend_r1_bitcast.1" = bitcast i32 %"R21:R20_r1.1" to float
  %"dfma_addend_r1_i32_bitcast.1" = bitcast float %"dfma_addend_r1_bitcast.1" to i32
  %"dfma_addend_r1_ext.1" = zext i32 %"dfma_addend_r1_i32_bitcast.1" to i64
  %"dfma_addend_r1_shift.1" = shl i64 %"dfma_addend_r1_ext.1", 32
  %"dfma_addend_packed_1.1" = or i64 %"dfma_addend_packed_0.1", %"dfma_addend_r1_shift.1"
  %"dfma_addend_bitcast.1" = bitcast i64 %"dfma_addend_packed_1.1" to double
  %"dfma.1" = call double @"llvm.fma.f64"(double %"dfma_lhs_bitcast.1", double %"dfma_rhs_bitcast.1", double %"dfma_addend_bitcast.1")
  %"R19:R18_bitcast.2" = bitcast double %"dfma.1" to i64
  %"R19:R18_r0.2" = trunc i64 %"R19:R18_bitcast.2" to i32
  %"R19:R18_r1_shift.2" = lshr i64 %"R19:R18_bitcast.2", 32
  %"R19:R18_r1.2" = trunc i64 %"R19:R18_r1_shift.2" to i32
  %"f2f_ext.7" = fpext float %"fmul" to double
  %"R17:R16_bitcast" = bitcast double %"f2f_ext.7" to i64
  %"R17:R16_r0" = trunc i64 %"R17:R16_bitcast" to i32
  %"R17:R16_r1_shift" = lshr i64 %"R17:R16_bitcast", 32
  %"R17:R16_r1" = trunc i64 %"R17:R16_r1_shift" to i32
  %"dadd_lhs_r0_bitcast.3" = bitcast i32 %"R19:R18_r0.2" to float
  %"dadd_lhs_r0_i32_bitcast.3" = bitcast float %"dadd_lhs_r0_bitcast.3" to i32
  %"dadd_lhs_r0_ext.3" = zext i32 %"dadd_lhs_r0_i32_bitcast.3" to i64
  %"dadd_lhs_packed_0.3" = or i64 0, %"dadd_lhs_r0_ext.3"
  %"dadd_lhs_r1_bitcast.3" = bitcast i32 %"R19:R18_r1.2" to float
  %"dadd_lhs_r1_i32_bitcast.3" = bitcast float %"dadd_lhs_r1_bitcast.3" to i32
  %"dadd_lhs_r1_ext.3" = zext i32 %"dadd_lhs_r1_i32_bitcast.3" to i64
  %"dadd_lhs_r1_shift.3" = shl i64 %"dadd_lhs_r1_ext.3", 32
  %"dadd_lhs_packed_1.3" = or i64 %"dadd_lhs_packed_0.3", %"dadd_lhs_r1_shift.3"
  %"dadd_lhs_bitcast.3" = bitcast i64 %"dadd_lhs_packed_1.3" to double
  %"dadd_rhs_r0_bitcast.3" = bitcast i32 %"R17:R16_r0" to float
  %"dadd_rhs_r0_i32_bitcast.3" = bitcast float %"dadd_rhs_r0_bitcast.3" to i32
  %"dadd_rhs_r0_ext.3" = zext i32 %"dadd_rhs_r0_i32_bitcast.3" to i64
  %"dadd_rhs_packed_0.3" = or i64 0, %"dadd_rhs_r0_ext.3"
  %"dadd_rhs_r1_bitcast.3" = bitcast i32 %"R17:R16_r1" to float
  %"dadd_rhs_r1_i32_bitcast.3" = bitcast float %"dadd_rhs_r1_bitcast.3" to i32
  %"dadd_rhs_r1_ext.3" = zext i32 %"dadd_rhs_r1_i32_bitcast.3" to i64
  %"dadd_rhs_r1_shift.3" = shl i64 %"dadd_rhs_r1_ext.3", 32
  %"dadd_rhs_packed_1.3" = or i64 %"dadd_rhs_packed_0.3", %"dadd_rhs_r1_shift.3"
  %"dadd_rhs_bitcast.3" = bitcast i64 %"dadd_rhs_packed_1.3" to double
  %"dadd.3" = fadd double %"dadd_lhs_bitcast.3", %"dadd_rhs_bitcast.3"
  %"R17:R16_bitcast.1" = bitcast double %"dadd.3" to i64
  %"R17:R16_r0.1" = trunc i64 %"R17:R16_bitcast.1" to i32
  %"R17:R16_r1_shift.1" = lshr i64 %"R17:R16_bitcast.1", 32
  %"R17:R16_r1.1" = trunc i64 %"R17:R16_r1_shift.1" to i32
  %"dfma_lhs_r0_bitcast.2" = bitcast i32 %"R9:R8_r0" to float
  %"dfma_lhs_r0_i32_bitcast.2" = bitcast float %"dfma_lhs_r0_bitcast.2" to i32
  %"dfma_lhs_r0_ext.2" = zext i32 %"dfma_lhs_r0_i32_bitcast.2" to i64
  %"dfma_lhs_packed_0.2" = or i64 0, %"dfma_lhs_r0_ext.2"
  %"dfma_lhs_r1_bitcast.2" = bitcast i32 %"R9:R8_r1" to float
  %"dfma_lhs_r1_i32_bitcast.2" = bitcast float %"dfma_lhs_r1_bitcast.2" to i32
  %"dfma_lhs_r1_ext.2" = zext i32 %"dfma_lhs_r1_i32_bitcast.2" to i64
  %"dfma_lhs_r1_shift.2" = shl i64 %"dfma_lhs_r1_ext.2", 32
  %"dfma_lhs_packed_1.2" = or i64 %"dfma_lhs_packed_0.2", %"dfma_lhs_r1_shift.2"
  %"dfma_lhs_bitcast.2" = bitcast i64 %"dfma_lhs_packed_1.2" to double
  %"dfma_rhs_r0_bitcast.2" = bitcast i32 %"R17:R16_r0.1" to float
  %"dfma_rhs_r0_i32_bitcast.2" = bitcast float %"dfma_rhs_r0_bitcast.2" to i32
  %"dfma_rhs_r0_ext.2" = zext i32 %"dfma_rhs_r0_i32_bitcast.2" to i64
  %"dfma_rhs_packed_0.2" = or i64 0, %"dfma_rhs_r0_ext.2"
  %"dfma_rhs_r1_bitcast.2" = bitcast i32 %"R17:R16_r1.1" to float
  %"dfma_rhs_r1_i32_bitcast.2" = bitcast float %"dfma_rhs_r1_bitcast.2" to i32
  %"dfma_rhs_r1_ext.2" = zext i32 %"dfma_rhs_r1_i32_bitcast.2" to i64
  %"dfma_rhs_r1_shift.2" = shl i64 %"dfma_rhs_r1_ext.2", 32
  %"dfma_rhs_packed_1.2" = or i64 %"dfma_rhs_packed_0.2", %"dfma_rhs_r1_shift.2"
  %"dfma_rhs_bitcast.2" = bitcast i64 %"dfma_rhs_packed_1.2" to double
  %"dfma_addend_r0_bitcast.2" = bitcast i32 %"R15:R14_r0" to float
  %"dfma_addend_r0_i32_bitcast.2" = bitcast float %"dfma_addend_r0_bitcast.2" to i32
  %"dfma_addend_r0_ext.2" = zext i32 %"dfma_addend_r0_i32_bitcast.2" to i64
  %"dfma_addend_packed_0.2" = or i64 0, %"dfma_addend_r0_ext.2"
  %"dfma_addend_r1_bitcast.2" = bitcast i32 %"R15:R14_r1" to float
  %"dfma_addend_r1_i32_bitcast.2" = bitcast float %"dfma_addend_r1_bitcast.2" to i32
  %"dfma_addend_r1_ext.2" = zext i32 %"dfma_addend_r1_i32_bitcast.2" to i64
  %"dfma_addend_r1_shift.2" = shl i64 %"dfma_addend_r1_ext.2", 32
  %"dfma_addend_packed_1.2" = or i64 %"dfma_addend_packed_0.2", %"dfma_addend_r1_shift.2"
  %"dfma_addend_bitcast.2" = bitcast i64 %"dfma_addend_packed_1.2" to double
  %"dfma.2" = call double @"llvm.fma.f64"(double %"dfma_lhs_bitcast.2", double %"dfma_rhs_bitcast.2", double %"dfma_addend_bitcast.2")
  %"R17:R16_bitcast.2" = bitcast double %"dfma.2" to i64
  %"R17:R16_r0.2" = trunc i64 %"R17:R16_bitcast.2" to i32
  %"R17:R16_r1_shift.2" = lshr i64 %"R17:R16_bitcast.2", 32
  %"R17:R16_r1.2" = trunc i64 %"R17:R16_r1_shift.2" to i32
  %"f2f_src_r0_bitcast" = bitcast i32 %"R17:R16_r0.2" to float
  %"f2f_src_r0_i32_bitcast" = bitcast float %"f2f_src_r0_bitcast" to i32
  %"f2f_src_r0_ext" = zext i32 %"f2f_src_r0_i32_bitcast" to i64
  %"f2f_src_packed_0" = or i64 0, %"f2f_src_r0_ext"
  %"f2f_src_r1_bitcast" = bitcast i32 %"R17:R16_r1.2" to float
  %"f2f_src_r1_i32_bitcast" = bitcast float %"f2f_src_r1_bitcast" to i32
  %"f2f_src_r1_ext" = zext i32 %"f2f_src_r1_i32_bitcast" to i64
  %"f2f_src_r1_shift" = shl i64 %"f2f_src_r1_ext", 32
  %"f2f_src_packed_1" = or i64 %"f2f_src_packed_0", %"f2f_src_r1_shift"
  %"f2f_src_bitcast.1" = bitcast i64 %"f2f_src_packed_1" to double
  %"f2f_trunc" = fptrunc double %"f2f_src_bitcast.1" to float
  %"R246_bitcast" = bitcast float %"f2f_trunc" to i32
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  %"sts_addr_memaddr_offset_add.1" = add i32 %"legacy_result.9", 2048
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".821" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".821" to i32 addrspace(3)*
  store volatile i32 %"R246_bitcast", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.24")
  br label %"BB_0678"
BB_0678:
  %"phi.35" = phi  i32 [1, %"BB_0538"], [%"xmad_sum.9", %"BB_0530"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"phi.33")
  %"legacy_join_live_mask.4" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"phi.33", i1 1)
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  %"legacy_branch_predicate_trunc.25" = trunc i32 %"P78_to_i32" to i1
  %"legacy_branch_predicate_not.9" = xor i1 %"legacy_branch_predicate_trunc.25", -1
  %"legacy_taken_mask.25" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_join_live_mask.4", i1 %"legacy_branch_predicate_not.9")
  %".824" = xor i32 %"legacy_taken_mask.25", -1
  %"legacy_fallthrough_mask.25" = and i32 %"legacy_join_live_mask.4", %".824"
  %"legacy_path_mask.25" = select  i1 %"legacy_branch_predicate_not.9", i32 %"legacy_taken_mask.25", i32 %"legacy_fallthrough_mask.25"
  br label %"BB_0698"
BB_0698:
  %"cond_trunc.41" = trunc i32 %"P78_to_i32" to i1
  %"cond_not.15" = xor i1 %"cond_trunc.41", -1
  %"pbra_cond_to_i32.41" = zext i1 %"cond_not.15" to i32
  %"pbra_cond_to_i1.41" = icmp ne i32 %"pbra_cond_to_i32.41", 0
  br i1 %"pbra_cond_to_i1.41", label %"BB_0728", label %"BB_06a0"
BB_06a0:
  %".827" = zext i32 4096 to i64
  %".828" = and i64 %".827", 255
  %".829" = lshr i64 %".827", 8
  %".830" = and i64 %".829", 255
  %".831" = icmp ugt i64 %".830", 32
  %".832" = select  i1 %".831", i64 32, i64 %".830"
  %".833" = sext i32 %"phi.35" to i64
  %".834" = icmp ugt i64 %".828", 63
  %".835" = select  i1 %".834", i64 63, i64 %".828"
  %".836" = ashr i64 %".833", %".835"
  %".837" = shl i64 1, %".832"
  %".838" = sub i64 %".837", 1
  %".839" = and i64 %".836", %".838"
  %".840" = sub i64 64, %".832"
  %".841" = icmp eq i64 %".832", 0
  %".842" = select  i1 %".841", i64 0, i64 %".840"
  %".843" = shl i64 %".839", %".842"
  %".844" = ashr i64 %".843", %".842"
  %".845" = trunc i64 %".844" to i32
  %"legacy_a_wide.65" = zext i32 %"phi.30" to i64
  %"legacy_b_wide.65" = zext i32 1 to i64
  %"legacy_sum.65" = add i64 %"legacy_a_wide.65", %"legacy_b_wide.65"
  %"legacy_result.65" = trunc i64 %"legacy_sum.65" to i32
  %"legacy_a_wide.66" = zext i32 %"phi.32" to i64
  %"legacy_b_wide.66" = zext i32 1 to i64
  %"legacy_sum.66" = add i64 %"legacy_a_wide.66", %"legacy_b_wide.66"
  %"legacy_result.66" = trunc i64 %"legacy_sum.66" to i32
  %"isetrp_cmp1.41" = icmp ne i32 %".845", 0
  %"isetrp_src_to_i32.41" = zext i1 1 to i32
  %"isetrp_src_to_i1.41" = icmp ne i32 %"isetrp_src_to_i32.41", 0
  %"isetrp_cmp2.41" = and i1 %"isetrp_cmp1.41", %"isetrp_src_to_i1.41"
  %"P60_to_i32" = zext i1 %"isetrp_cmp2.41" to i32
  %".846" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 320
  %".847" = bitcast i8* %".846" to i32*
  %"isetrp_rhs.4" = load i32, i32* %".847"
  %"isetrp_cmp1.42" = icmp sge i32 %"legacy_result.65", %"isetrp_rhs.4"
  %"isetrp_src_to_i32.42" = zext i1 1 to i32
  %"isetrp_src_to_i1.42" = icmp ne i32 %"isetrp_src_to_i32.42", 0
  %"isetrp_cmp2.42" = and i1 %"isetrp_cmp1.42", %"isetrp_src_to_i1.42"
  %"P75_to_i32" = zext i1 %"isetrp_cmp2.42" to i32
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.25")
  br label %"BB_06d0"
BB_06d0:
  %"cond_trunc.42" = trunc i32 %"P60_to_i32" to i1
  %"pbra_cond_to_i32.42" = zext i1 %"cond_trunc.42" to i32
  %"pbra_cond_to_i1.42" = icmp ne i32 %"pbra_cond_to_i32.42", 0
  br i1 %"pbra_cond_to_i1.42", label %"BB_800006d0", label %"BB_06d8"
BB_800006d0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %"legacy_result.9", 2048
  %"lds_shared_addr_winoff.6" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".850" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.6"
  %"lds_shared_addr_cast.6" = bitcast i8 addrspace(3)* %".850" to i32 addrspace(3)*
  %"lds.6" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.6"
  br label %"BB_06d8"
BB_06d8:
  %"phi.36" = phi  i32 [%"lds.6", %"BB_800006d0"], [%".845", %"BB_06d0"]
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.25")
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.25")
  br label %"BB_06e8"
BB_06e8:
  %"cond_trunc.43" = trunc i32 %"P60_to_i32" to i1
  %"pbra_cond_to_i32.43" = zext i1 %"cond_trunc.43" to i32
  %"pbra_cond_to_i1.43" = icmp ne i32 %"pbra_cond_to_i32.43", 0
  br i1 %"pbra_cond_to_i1.43", label %"BB_800006e8", label %"BB_06f0"
BB_800006e8:
  %"sts_shared_addr_winoff.3" = and i32 %"legacy_result.9", 16777215
  %".854" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".854" to i32 addrspace(3)*
  store volatile i32 %"phi.36", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_06f0"
BB_06f0:
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.25")
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  %"legacy_branch_predicate_trunc.26" = trunc i32 %"P75_to_i32" to i1
  %"legacy_branch_predicate_not.10" = xor i1 %"legacy_branch_predicate_trunc.26", -1
  %"legacy_taken_mask.26" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"legacy_path_mask.25", i1 %"legacy_branch_predicate_not.10")
  %".857" = xor i32 %"legacy_taken_mask.26", -1
  %"legacy_fallthrough_mask.26" = and i32 %"legacy_path_mask.25", %".857"
  %"legacy_path_mask.26" = select  i1 %"legacy_branch_predicate_not.10", i32 %"legacy_taken_mask.26", i32 %"legacy_fallthrough_mask.26"
  br label %"BB_0720"
BB_0720:
  %"cond_trunc.44" = trunc i32 %"P75_to_i32" to i1
  %"cond_not.16" = xor i1 %"cond_trunc.44", -1
  %"pbra_cond_to_i32.44" = zext i1 %"cond_not.16" to i32
  %"pbra_cond_to_i1.44" = icmp ne i32 %"pbra_cond_to_i32.44", 0
  br i1 %"pbra_cond_to_i1.44", label %"BB_04d0", label %"BB_0728"
BB_0728:
  %"phi.37" = phi  i32 [%"legacy_path_mask", %"BB_0178"], [%"legacy_path_mask.25", %"BB_0698"], [%"legacy_path_mask.26", %"BB_0720"]
  %"phi.38" = phi  i32 [0, %"BB_0178"], [%"phi.35", %"BB_0698"], [%"phi.35", %"BB_0720"]
  %".860" = and i32 %"phi.38", 255
  %".861" = icmp ne i32 %".860", 0
  %"P63_to_i32" = zext i1 %".861" to i32
  %"legacy_branch_predicate_trunc.27" = trunc i32 %"P63_to_i32" to i1
  %"legacy_branch_predicate_not.11" = xor i1 %"legacy_branch_predicate_trunc.27", -1
  %"legacy_taken_mask.27" = call i32 @"llvm.nvvm.vote.ballot.sync"(i32 %"phi.37", i1 %"legacy_branch_predicate_not.11")
  %".862" = xor i32 %"legacy_taken_mask.27", -1
  %"legacy_fallthrough_mask.27" = and i32 %"phi.37", %".862"
  %"legacy_path_mask.27" = select  i1 %"legacy_branch_predicate_not.11", i32 %"legacy_taken_mask.27", i32 %"legacy_fallthrough_mask.27"
  br label %"BB_0750"
BB_0750:
  %"cond_trunc.45" = trunc i32 %"P63_to_i32" to i1
  %"cond_not.17" = xor i1 %"cond_trunc.45", -1
  %"pbra_cond_to_i32.45" = zext i1 %"cond_not.17" to i32
  %"pbra_cond_to_i1.45" = icmp ne i32 %"pbra_cond_to_i32.45", 0
  br i1 %"pbra_cond_to_i1.45", label %"BB_80000750", label %"BB_0758"
BB_0758:
  %"shr_overflow.14" = icmp ugt i32 30, 31
  %"shr_clamp.14" = select  i1 %"shr_overflow.14", i32 31, i32 30
  %"shr_result.14" = ashr i32 %"xmad_sum.8", %"shr_clamp.14"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.27")
  %"lds_addr_memaddr_offset_add.2" = add i32 %"legacy_result.9", 2048
  %"lds_shared_addr_winoff.7" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".865" = getelementptr inbounds [3072 x i8], [3072 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.7"
  %"lds_shared_addr_cast.7" = bitcast i8 addrspace(3)* %".865" to i32 addrspace(3)*
  %"lds.7" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.7"
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"legacy_path_mask.27")
  %"legacy_a_shift.8" = shl i32 %"xmad_sum.8", 2
  %"legacy_a_wide.67" = zext i32 %"legacy_a_shift.8" to i64
  %".866" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 344
  %".867" = bitcast i8* %".866" to i32*
  %"legacy_b.9" = load i32, i32* %".867"
  %"legacy_b_wide.67" = zext i32 %"legacy_b.9" to i64
  %"legacy_sum.67" = add i64 %"legacy_a_wide.67", %"legacy_b_wide.67"
  %"legacy_result.67" = trunc i64 %"legacy_sum.67" to i32
  %".868" = lshr i64 %"legacy_sum.67", 32
  %"legacy_cout.2" = trunc i64 %".868" to i1
  %"P5_to_i32" = zext i1 %"legacy_cout.2" to i32
  %"legacy_a_wide.68" = zext i32 %"shr_result.14" to i64
  %".869" = getelementptr inbounds [400 x i8], [400 x i8]* %"param_local", i64 0, i64 348
  %".870" = bitcast i8* %".869" to i32*
  %"legacy_b.10" = load i32, i32* %".870"
  %"legacy_b_wide.68" = zext i32 %"legacy_b.10" to i64
  %"legacy_sum.68" = add i64 %"legacy_a_wide.68", %"legacy_b_wide.68"
  %"legacy_cin_trunc.2" = trunc i32 %"P5_to_i32" to i1
  %".871" = zext i1 %"legacy_cin_trunc.2" to i64
  %"legacy_sum_cin.2" = add i64 %"legacy_sum.68", %".871"
  %"legacy_result.68" = trunc i64 %"legacy_sum_cin.2" to i32
  %"stg_addr_r0_ext" = zext i32 %"legacy_result.67" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"legacy_result.68" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R127:R114_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %"lds.7", i32 addrspace(1)* %"R127:R114_addr_ptr"
  ret void
BB_80000750:
  ret void
}

@"const_mem" = internal global [5 x [392 x i8]] [[392 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [392 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [392 x i8] [i8 255, i8 255, i8 255, i8 1, i8 0, i8 0, i8 128, i8 191, i8 255, i8 255, i8 255, i8 127, i8 0, i8 0, i8 128, i8 63, i8 0, i8 0, i8 0, i8 128, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [392 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [392 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.vote.ballot.sync"(i32 %".1", i1 %".2") convergent noduplicate

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare void @"llvm.nvvm.bar.warp.sync"(i32 %".1") convergent noduplicate

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare float @"llvm.nvvm.rcp.approx.ftz.f"(float %".1")

declare float @"llvm.fma.f32"(float %".1", float %".2", float %".3")

declare float @"llvm.nvvm.rsqrt.approx.ftz.f"(float %".1")

declare float @"llvm.nvvm.fma.rz.f"(float %".1", float %".2", float %".3")

declare float @"llvm.nvvm.fma.rp.f"(float %".1", float %".2", float %".3")

declare float @"llvm.nvvm.fma.rm.f"(float %".1", float %".2", float %".3")

declare double @"llvm.fma.f64"(double %".1", double %".2", double %".3")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i32, i64, i64, i64, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32)* @"_Z14calculate_tempiPfS_S_iiiiffffff", !"kernel", i32 1 }
