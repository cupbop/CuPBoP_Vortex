; ModuleID = "dynamic_full"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [1040 x i8], align 16
define void @"serial"(i64 %"arg_896", i32 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i32*
  store i32 %"arg_904", i32* %".8", align 8
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  call void asm sideeffect "bar.sync $0, $1;", "r,r,~{memory}"(i32 1, i32 32)
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".11" = bitcast i8* %".10" to i32*
  %"allocation_columns" = load i32, i32* %".11"
  %"allocation_slot_winoff" = and i32 1024, 16777215
  %".12" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".13" = ptrtoint i8 addrspace(3)* %".12" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".13", i32 %"allocation_columns") convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P1_to_i32" = zext i1 %"elect_p" to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".15" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".16" = zext i32 1024 to i64
  %".17" = zext i32 24 to i64
  %".18" = shl i64 %".15", %".17"
  %".19" = and i64 %".18", 4294967295
  %".20" = add i64 %".19", %".16"
  %".21" = trunc i64 %".20" to i32
  br label %"BB_0090"
BB_0090:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0230", label %"BB_00a0"
BB_00a0:
  %".24" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".25" = bitcast i8* %".24" to i32*
  %"ldc_const" = load i32, i32* %".25"
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", -1
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp.1", 1
  %".26" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".27" = zext i32 64 to i64
  %".28" = zext i32 24 to i64
  %".29" = shl i64 %".26", %".28"
  %".30" = and i64 %".29", 4294967295
  %".31" = add i64 %".30", %".27"
  %".32" = trunc i64 %".31" to i32
  %".33" = zext i32 0 to i64
  %".34" = zext i32 %"ldc_const" to i64
  %".35" = shl i64 %".34", 32
  %"shf_concat" = or i64 %".33", %".35"
  %"shf_shift_64" = zext i32 5 to i64
  %".36" = ashr i64 %"shf_concat", %"shf_shift_64"
  %"shf_hi" = lshr i64 %".36", 32
  %"shf_result" = trunc i64 %"shf_hi" to i32
  %".37" = zext i32 %"imad" to i64
  %".38" = zext i32 0 to i64
  %".39" = shl i64 %".38", 32
  %"shf_concat.1" = or i64 %".37", %".39"
  %"shf_shift_64.1" = zext i32 %"shf_result" to i64
  %".40" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".40" to i32
  %".41" = xor i32 0, -1
  %".42" = xor i32 %"shf_result.1", -1
  %".43" = xor i32 0, -1
  %".44" = and i32 %".41", %".42"
  %".45" = and i32 %".44", %".43"
  %".46" = and i32 %".41", %".42"
  %".47" = and i32 %".46", 0
  %".48" = or i32 %".45", %".47"
  %".49" = and i32 0, %".42"
  %".50" = and i32 %".49", %".43"
  %".51" = or i32 %".48", %".50"
  %".52" = and i32 0, %".42"
  %".53" = and i32 %".52", 0
  %".54" = or i32 %".51", %".53"
  %"tmem_alloc_winoff" = and i32 1024, 16777215
  %".55" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".56" = bitcast i8 addrspace(3)* %".55" to i32 addrspace(3)*
  %".57" = load i32, i32 addrspace(3)* %".56"
  %".58" = lshr i32 %".57", 5
  %"P3_to_i32" = zext i1 1 to i32
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.2", %".58"
  %"bra_cond_trunc" = trunc i32 %"P3_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_01d0", label %"BB_0170"
BB_0170:
  %"tmem_alloc_winoff.1" = and i32 1024, 16777215
  %".60" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".61" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  %".62" = load i32, i32 addrspace(3)* %".61"
  %".63" = lshr i32 %".62", 5
  %"P4_to_i32" = zext i1 1 to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.3", %".63"
  %"bra_cond_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0170", label %"BB_01d0"
BB_01d0:
  %"phi" = phi  i32 [%"imad.2", %"BB_00a0"], [%"imad.3", %"BB_0170"]
  %".65" = zext i32 %".54" to i64
  %".66" = zext i32 0 to i64
  %".67" = shl i64 %".66", 32
  %"shf_concat.2" = or i64 %".65", %".67"
  %"shf_shift_64.2" = zext i32 %"phi" to i64
  %".68" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".68" to i32
  %".69" = zext i32 %"imad.1" to i64
  %".70" = zext i32 0 to i64
  %".71" = shl i64 %".70", 32
  %"shf_concat.3" = or i64 %".69", %".71"
  %"shf_shift_64.3" = zext i32 %"phi" to i64
  %".72" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".72" to i32
  %"imad_tmp.4" = mul i32 %"phi", 32
  %"imad.4" = add i32 %"imad_tmp.4", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".32", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".73" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".73" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".32", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".74" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".74" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_shared_addr_winoff" = and i32 %".21", 16777215
  %".75" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".75" to i32 addrspace(3)*
  store volatile i32 %"imad.4", i32 addrspace(3)* %"sts_shared_addr_cast"
  br label %"BB_0230"
BB_0230:
  call void asm sideeffect "bar.sync $0, $1;", "r,r,~{memory}"(i32 1, i32 32)
  %".78" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".79" = bitcast i8* %".78" to i32*
  %"ldc_const.1" = load i32, i32* %".79"
  %".80" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".81" = bitcast i8* %".80" to i64*
  %"ldc_const.2" = load i64, i64* %".81"
  %"UR7:UR6_r0" = trunc i64 %"ldc_const.2" to i32
  %"UR7:UR6_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"UR7:UR6_r1" = trunc i64 %"UR7:UR6_r1_shift" to i32
  %"lds_shared_addr_winoff" = and i32 %".21", 16777215
  %".82" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".82" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".83" = zext i32 %"tid_x" to i64
  %".84" = zext i32 %"UR7:UR6_r0" to i64
  %".85" = zext i32 2 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %".90" = lshr i64 %".88", 32
  %".91" = trunc i64 %".90" to i1
  %"P5_to_i32" = zext i1 %".91" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.5", -1
  %".92" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".93" = zext i32 64 to i64
  %".94" = zext i32 24 to i64
  %".95" = shl i64 %".92", %".94"
  %".96" = and i64 %".95", 4294967295
  %".97" = add i64 %".96", %".93"
  %".98" = trunc i64 %".97" to i32
  %"imad_tmp.6" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.6", %"UR7:UR6_r1"
  %"imad_cin_trunc" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.6", %"imad_cin_ext"
  %"imad_tmp.7" = mul i32 %"lds", 1
  %"imad.7" = add i32 %"imad_tmp.7", %"ldc_const.1"
  %".99" = zext i32 0 to i64
  %".100" = zext i32 %"ldc_const.1" to i64
  %".101" = shl i64 %".100", 32
  %"shf_concat.4" = or i64 %".99", %".101"
  %"shf_shift_64.4" = zext i32 5 to i64
  %".102" = ashr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".102", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".103" = xor i32 %"lds", -1
  %".104" = xor i32 65535, -1
  %".105" = xor i32 0, -1
  %".106" = and i32 %"lds", 65535
  %".107" = and i32 %".106", %".105"
  %".108" = and i32 %"lds", 65535
  %".109" = and i32 %".108", 0
  %".110" = or i32 %".107", %".109"
  %"stg_addr_r0_ext" = zext i32 %".89" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"imad_with_cin" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R5:R54_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %"imad.7", i32 addrspace(1)* %"R5:R54_addr_ptr"
  %"lds_addr_memaddr_offset_add" = add i32 %".98", 20
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".112" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".112" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".113" = zext i32 %"imad.5" to i64
  %".114" = zext i32 0 to i64
  %".115" = shl i64 %".114", 32
  %"shf_concat.5" = or i64 %".113", %".115"
  %"shf_shift_64.5" = zext i32 %"shf_result.4" to i64
  %".116" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".116" to i32
  %".117" = zext i32 0 to i64
  %".118" = zext i32 %".110" to i64
  %".119" = shl i64 %".118", 32
  %"shf_concat.6" = or i64 %".117", %".119"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".120" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".120", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".121" = xor i32 0, -1
  %".122" = xor i32 %"shf_result.5", -1
  %".123" = xor i32 0, -1
  %".124" = and i32 %".121", %".122"
  %".125" = and i32 %".124", %".123"
  %".126" = and i32 %".121", %".122"
  %".127" = and i32 %".126", 0
  %".128" = or i32 %".125", %".127"
  %".129" = and i32 0, %".122"
  %".130" = and i32 %".129", %".123"
  %".131" = or i32 %".128", %".130"
  %".132" = and i32 0, %".122"
  %".133" = and i32 %".132", 0
  %".134" = or i32 %".131", %".133"
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.8", 1
  %".135" = zext i32 %".134" to i64
  %".136" = zext i32 0 to i64
  %".137" = shl i64 %".136", 32
  %"shf_concat.7" = or i64 %".135", %".137"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".138" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".138" to i32
  %".139" = zext i32 %"imad.8" to i64
  %".140" = zext i32 0 to i64
  %".141" = shl i64 %".140", 32
  %"shf_concat.8" = or i64 %".139", %".141"
  %"shf_shift_64.8" = zext i32 %"shf_result.6" to i64
  %".142" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".142" to i32
  %".143" = xor i32 %"lds.1", -1
  %".144" = xor i32 %"shf_result.7", -1
  %".145" = xor i32 0, -1
  %".146" = and i32 %"lds.1", %"shf_result.7"
  %".147" = and i32 %".146", %".145"
  %".148" = and i32 %"lds.1", %"shf_result.7"
  %".149" = and i32 %".148", 0
  %".150" = or i32 %".147", %".149"
  %"isetrp_cmp1" = icmp ne i32 %".150", %"shf_result.7"
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0540_0620", label %"BB_03c0"
BB_03c0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".98", 24
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".153" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".153" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %".154" = xor i32 %"lds.2", -1
  %".155" = xor i32 %"shf_result.8", -1
  %".156" = xor i32 0, -1
  %".157" = and i32 %"lds.2", %"shf_result.8"
  %".158" = and i32 %".157", %".156"
  %".159" = and i32 %"lds.2", %"shf_result.8"
  %".160" = and i32 %".159", 0
  %".161" = or i32 %".158", %".160"
  %"isetrp_cmp1.1" = icmp ne i32 %".161", %"shf_result.8"
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.2" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_trunc.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0510_05f0", label %"BB_0400"
BB_0400:
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".164" = xor i32 0, -1
  %".165" = xor i32 %"shf_result.8", -1
  %".166" = xor i32 0, -1
  %".167" = and i32 %".164", %".165"
  %".168" = and i32 %".167", %".166"
  %".169" = and i32 %".164", %".165"
  %".170" = and i32 %".169", 0
  %".171" = or i32 %".168", %".170"
  %".172" = and i32 0, %".165"
  %".173" = and i32 %".172", %".166"
  %".174" = or i32 %".171", %".173"
  %".175" = and i32 0, %".165"
  %".176" = and i32 %".175", 0
  %".177" = or i32 %".174", %".176"
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".177", i32 %"redux_mask")
  %".178" = xor i32 0, -1
  %".179" = xor i32 %"shf_result.7", -1
  %".180" = xor i32 0, -1
  %".181" = and i32 %".178", %".179"
  %".182" = and i32 %".181", %".180"
  %".183" = and i32 %".178", %".179"
  %".184" = and i32 %".183", 0
  %".185" = or i32 %".182", %".184"
  %".186" = and i32 0, %".179"
  %".187" = and i32 %".186", %".180"
  %".188" = or i32 %".185", %".187"
  %".189" = and i32 0, %".179"
  %".190" = and i32 %".189", 0
  %".191" = or i32 %".188", %".190"
  %"imad_tmp.9" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.9", %".191"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.9", i32 %"redux_mask.1")
  %".192" = xor i32 %".191", -1
  %".193" = call i32 @"llvm.cttz.i32"(i32 %".192", i1 0)
  %".194" = shl i32 %".193", 5
  %".195" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".196" = bitcast i8* %".195" to i32*
  %"release_columns" = load i32, i32* %".196"
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, $1;", "r,r,~{memory}"(i32 %".194", i32 %"release_columns") convergent
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.10" = add i32 %"imad_tmp.10", %"redux_sync_and"
  %"isetrp_cmp1.2" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.11" = add i32 %"imad_tmp.11", %"redux_sync_and.1"
  br label %"BB_04d0"
BB_04d0:
  %"cond_trunc.3" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_trunc.3" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800004d0", label %"BB_0550"
BB_800004d0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".98", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".200" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".200" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.11" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".98", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".201" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".201" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.10" monotonic
  br label %"BB_0550"
BB_0510_05f0:
  call void @"llvm.trap"()
  br label %"BB_0550"
BB_0540_0620:
  call void @"llvm.trap"()
  br label %"BB_0550"
BB_0550:
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P2_to_i32" = zext i1 %"elect_p.1" to i32
  %".205" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".206" = zext i32 64 to i64
  %".207" = zext i32 24 to i64
  %".208" = shl i64 %".205", %".207"
  %".209" = and i64 %".208", 4294967295
  %".210" = add i64 %".209", %".206"
  %".211" = trunc i64 %".210" to i32
  br label %"BB_05a0"
BB_05a0:
  %"cond_trunc.4" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800005a0", label %"BB_05b0"
BB_05b0:
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.12", 1
  %"sts_addr_memaddr_offset_add" = add i32 %".211", 28
  %"sts_trunc" = trunc i32 %"imad.12" to i8
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".214" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  store volatile i8 %"sts_trunc", i8 addrspace(3)* %".214"
  ret void
BB_800005a0:
  ret void
}

@"const_mem" = internal global [5 x [908 x i8]] [[908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [908 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i32)* @"serial", !"kernel", i32 1 }
