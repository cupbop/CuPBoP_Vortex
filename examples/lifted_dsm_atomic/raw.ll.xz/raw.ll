; ModuleID = "dsm_generic_atomic_sm90"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [1040 x i8], align 16
define void @"dsm"(i64 %"arg_528")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [544 x i8], align 16
  %".3" = getelementptr inbounds [544 x i8], [544 x i8]* %"param_local", i64 0, i64 528
  %".4" = bitcast i8* %".3" to i64*
  store i64 %"arg_528", i64* %".4", align 16
  %"ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  %"ldc_const" = call i32 asm  "{ .reg .pred p; mov.pred p, %is_explicit_cluster; selp.u32 $0, 1, 0, p; }", "=r"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"isetrp_cmp1" = icmp eq i32 %"ldc_const", 1
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"iadd3_n1" = add i32 %"ctaid_x", 40
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".6" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".7" = zext i32 1024 to i64
  %".8" = zext i32 24 to i64
  %".9" = shl i64 %".6", %".8"
  %".10" = and i64 %".9", 4294967295
  %".11" = add i64 %".10", %".7"
  %".12" = trunc i64 %".11" to i32
  %"sts_val_r0_ext" = zext i32 %"iadd3_n2" to i64
  %"sts_val_packed_0" = or i64 0, %"sts_val_r0_ext"
  %"sts_val_r1_ext" = zext i32 0 to i64
  %"sts_val_r1_shift" = shl i64 %"sts_val_r1_ext", 32
  %"sts_val_packed_1" = or i64 %"sts_val_packed_0", %"sts_val_r1_shift"
  %"sts_shared_addr_winoff" = and i32 %".12", 16777215
  %".13" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".13" to i64 addrspace(3)*
  store volatile i64 %"sts_val_packed_1", i64 addrspace(3)* %"sts_shared_addr_cast"
  br label %"BB_00b0"
BB_00b0:
  %"cond_trunc" = trunc i32 %"P2_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0120", label %"BB_00c0"
BB_00c0:
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  br label %"BB_0120"
BB_0120:
  %"cond_trunc.1" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0160", label %"BB_0130"
BB_0130:
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_0170"
BB_0160:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0170"
BB_0170:
  %"s2ur_swin_sm_i8" = bitcast [1040 x i8] addrspace(3)* @"shared_mem" to i8 addrspace(3)*
  %"s2ur_swin_gen" = addrspacecast i8 addrspace(3)* %"s2ur_swin_sm_i8" to i8*
  %"s2ur_swin_base" = ptrtoint i8* %"s2ur_swin_gen" to i64
  %"s2ur_swin_hi_shr" = lshr i64 %"s2ur_swin_base", 32
  %"s2ur_swin" = trunc i64 %"s2ur_swin_hi_shr" to i32
  %"s2ur_swin.1" = call i32 @"__culifter_shared_window_hi"(i32 %"s2ur_swin")
  %".23" = xor i32 %"s2ur_cluster_ctarank", -1
  %".24" = xor i32 1, -1
  %".25" = xor i32 0, -1
  %".26" = and i32 %".23", 1
  %".27" = and i32 %".26", %".25"
  %".28" = and i32 %".23", 1
  %".29" = and i32 %".28", 0
  %".30" = or i32 %".27", %".29"
  %".31" = and i32 %"s2ur_cluster_ctarank", %".24"
  %".32" = and i32 %".31", %".25"
  %".33" = or i32 %".30", %".32"
  %".34" = and i32 %"s2ur_cluster_ctarank", %".24"
  %".35" = and i32 %".34", 0
  %".36" = or i32 %".33", %".35"
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"prmt_a64" = zext i32 %".36" to i64
  %"prmt_b64" = zext i32 %".12" to i64
  %"prmt_bsh" = shl i64 %"prmt_b64", 32
  %"prmt_src8" = or i64 %"prmt_a64", %"prmt_bsh"
  %"prmt_nib0_sh" = lshr i32 1620, 0
  %"prmt_idx0" = and i32 %"prmt_nib0_sh", 7
  %"prmt_sign0" = and i32 %"prmt_nib0_sh", 8
  %"prmt_idx0_64" = zext i32 %"prmt_idx0" to i64
  %"prmt_bsh0" = shl i64 %"prmt_idx0_64", 3
  %"prmt_ext0" = lshr i64 %"prmt_src8", %"prmt_bsh0"
  %"prmt_byte0" = trunc i64 %"prmt_ext0" to i8
  %"prmt_hassign0" = icmp ne i32 %"prmt_sign0", 0
  %"prmt_zext0" = zext i8 %"prmt_byte0" to i32
  %"prmt_sfill0" = ashr i8 %"prmt_byte0", 7
  %"prmt_sfill32_0" = zext i8 %"prmt_sfill0" to i32
  %"prmt_smask0" = and i32 %"prmt_sfill32_0", 255
  %"prmt_sel0" = select  i1 %"prmt_hassign0", i32 %"prmt_smask0", i32 %"prmt_zext0"
  %"prmt_place0" = shl i32 %"prmt_sel0", 0
  %"prmt_res0" = or i32 0, %"prmt_place0"
  %"prmt_nib1_sh" = lshr i32 1620, 4
  %"prmt_idx1" = and i32 %"prmt_nib1_sh", 7
  %"prmt_sign1" = and i32 %"prmt_nib1_sh", 8
  %"prmt_idx1_64" = zext i32 %"prmt_idx1" to i64
  %"prmt_bsh1" = shl i64 %"prmt_idx1_64", 3
  %"prmt_ext1" = lshr i64 %"prmt_src8", %"prmt_bsh1"
  %"prmt_byte1" = trunc i64 %"prmt_ext1" to i8
  %"prmt_hassign1" = icmp ne i32 %"prmt_sign1", 0
  %"prmt_zext1" = zext i8 %"prmt_byte1" to i32
  %"prmt_sfill1" = ashr i8 %"prmt_byte1", 7
  %"prmt_sfill32_1" = zext i8 %"prmt_sfill1" to i32
  %"prmt_smask1" = and i32 %"prmt_sfill32_1", 255
  %"prmt_sel1" = select  i1 %"prmt_hassign1", i32 %"prmt_smask1", i32 %"prmt_zext1"
  %"prmt_place1" = shl i32 %"prmt_sel1", 8
  %"prmt_res1" = or i32 %"prmt_res0", %"prmt_place1"
  %"prmt_nib2_sh" = lshr i32 1620, 8
  %"prmt_idx2" = and i32 %"prmt_nib2_sh", 7
  %"prmt_sign2" = and i32 %"prmt_nib2_sh", 8
  %"prmt_idx2_64" = zext i32 %"prmt_idx2" to i64
  %"prmt_bsh2" = shl i64 %"prmt_idx2_64", 3
  %"prmt_ext2" = lshr i64 %"prmt_src8", %"prmt_bsh2"
  %"prmt_byte2" = trunc i64 %"prmt_ext2" to i8
  %"prmt_hassign2" = icmp ne i32 %"prmt_sign2", 0
  %"prmt_zext2" = zext i8 %"prmt_byte2" to i32
  %"prmt_sfill2" = ashr i8 %"prmt_byte2", 7
  %"prmt_sfill32_2" = zext i8 %"prmt_sfill2" to i32
  %"prmt_smask2" = and i32 %"prmt_sfill32_2", 255
  %"prmt_sel2" = select  i1 %"prmt_hassign2", i32 %"prmt_smask2", i32 %"prmt_zext2"
  %"prmt_place2" = shl i32 %"prmt_sel2", 16
  %"prmt_res2" = or i32 %"prmt_res1", %"prmt_place2"
  %"prmt_nib3_sh" = lshr i32 1620, 12
  %"prmt_idx3" = and i32 %"prmt_nib3_sh", 7
  %"prmt_sign3" = and i32 %"prmt_nib3_sh", 8
  %"prmt_idx3_64" = zext i32 %"prmt_idx3" to i64
  %"prmt_bsh3" = shl i64 %"prmt_idx3_64", 3
  %"prmt_ext3" = lshr i64 %"prmt_src8", %"prmt_bsh3"
  %"prmt_byte3" = trunc i64 %"prmt_ext3" to i8
  %"prmt_hassign3" = icmp ne i32 %"prmt_sign3", 0
  %"prmt_zext3" = zext i8 %"prmt_byte3" to i32
  %"prmt_sfill3" = ashr i8 %"prmt_byte3", 7
  %"prmt_sfill32_3" = zext i8 %"prmt_sfill3" to i32
  %"prmt_smask3" = and i32 %"prmt_sfill32_3", 255
  %"prmt_sel3" = select  i1 %"prmt_hassign3", i32 %"prmt_smask3", i32 %"prmt_zext3"
  %"prmt_place3" = shl i32 %"prmt_sel3", 24
  %"prmt_res3" = or i32 %"prmt_res2", %"prmt_place3"
  %"iadd3_o1_64" = zext i32 %"prmt_res3" to i64
  %"iadd3_o2_64" = zext i32 4 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P3_to_i32" = zext i1 %"carry_ge_1" to i32
  %"iadd3_n1.1" = add i32 0, %"s2ur_swin.1"
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_cin1_trunc" = trunc i32 %"P3_to_i32" to i1
  %"iadd3_cin1_narrow_zext" = zext i1 %"iadd3_cin1_trunc" to i32
  %"iadd3_cin1_add" = add i32 %"iadd3_n2.1", %"iadd3_cin1_narrow_zext"
  %"iadd3_cin2_narrow_zext" = zext i1 0 to i32
  %"iadd3_cin2_add" = add i32 %"iadd3_cin1_add", %"iadd3_cin2_narrow_zext"
  %"imad_tmp" = mul i32 0, 0
  %"imad" = add i32 %"imad_tmp", %"iadd3_trunc"
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"sts_addr_memaddr_offset_add" = add i32 %".12", 8
  %"sts_val_r0_ext.1" = zext i32 %"imad" to i64
  %"sts_val_packed_0.1" = or i64 0, %"sts_val_r0_ext.1"
  %"sts_val_r1_ext.1" = zext i32 %"iadd3_cin2_add" to i64
  %"sts_val_r1_shift.1" = shl i64 %"sts_val_r1_ext.1", 32
  %"sts_val_packed_1.1" = or i64 %"sts_val_packed_0.1", %"sts_val_r1_shift.1"
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".37" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".37" to i64 addrspace(3)*
  store volatile i64 %"sts_val_packed_1.1", i64 addrspace(3)* %"sts_shared_addr_cast.1"
  %"popc" = call i32 @"llvm.ctpop.i32"(i32 %"activemask")
  %"lds_addr_memaddr_offset_add" = add i32 %".12", 8
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".39" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i64 addrspace(3)*
  %"lds" = load volatile i64, i64 addrspace(3)* %"lds_shared_addr_cast"
  %"R5:R4_r0" = trunc i64 %"lds" to i32
  %"R5:R4_r1_shift" = lshr i64 %"lds", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"isetrp_cmp1.1" = icmp eq i32 %"flo", %"laneid"
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"imad_tmp.1" = mul i32 %"iadd3_n2", %"popc"
  %"imad.1" = add i32 %"imad_tmp.1", 0
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.2" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_trunc.2" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_80000270", label %"BB_0290"
BB_80000270:
  %"atom_addr_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"atom_addr_packed_0" = or i64 0, %"atom_addr_r0_ext"
  %"atom_addr_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"atom_addr_r1_shift" = shl i64 %"atom_addr_r1_ext", 32
  %"atom_addr_packed_1" = or i64 %"atom_addr_packed_0", %"atom_addr_r1_shift"
  %".42" = bitcast [1040 x i8] addrspace(3)* @"shared_mem" to i8 addrspace(3)*
  %".43" = addrspacecast i8 addrspace(3)* %".42" to i8*
  %"R12:R30_atom_addr" = call i64 @"__culifter_shared_window_resolve"(i64 %"atom_addr_packed_1", i8* %".43", i64 0)
  %"R12:R30_atom_addr.1" = inttoptr i64 %"R12:R30_atom_addr" to i32*
  %"atom_add" = atomicrmw add i32* %"R12:R30_atom_addr.1", i32 %"imad.1" monotonic
  %"atom_addr_r0_ext.1" = zext i32 %"R5:R4_r0" to i64
  %"atom_addr_packed_0.1" = or i64 0, %"atom_addr_r0_ext.1"
  %"atom_addr_r1_ext.1" = zext i32 %"R5:R4_r1" to i64
  %"atom_addr_r1_shift.1" = shl i64 %"atom_addr_r1_ext.1", 32
  %"atom_addr_packed_1.1" = or i64 %"atom_addr_packed_0.1", %"atom_addr_r1_shift.1"
  %".44" = bitcast [1040 x i8] addrspace(3)* @"shared_mem" to i8 addrspace(3)*
  %".45" = addrspacecast i8 addrspace(3)* %".44" to i8*
  %"R12:R30_atom_addr.2" = call i64 @"__culifter_shared_window_resolve"(i64 %"atom_addr_packed_1.1", i8* %".45", i64 0)
  %"R12:R30_atom_addr.3" = inttoptr i64 %"R12:R30_atom_addr.2" to i32*
  %"atom_add.1" = atomicrmw add i32* %"R12:R30_atom_addr.3", i32 %"popc" monotonic
  br label %"BB_0290"
BB_0290:
  %"phi" = phi  i32 [%"atom_add", %"BB_80000270"], [%"imad.1", %"BB_0270"]
  %"iadd_lhs_r0_ext" = zext i32 0 to i64
  %"iadd_lhs_packed_0" = or i64 0, %"iadd_lhs_r0_ext"
  %"iadd_lhs_r1_ext" = zext i32 0 to i64
  %"iadd_lhs_r1_shift" = shl i64 %"iadd_lhs_r1_ext", 32
  %"iadd_lhs_packed_1" = or i64 %"iadd_lhs_packed_0", %"iadd_lhs_r1_shift"
  %"iadd_rhs_r0_ext" = zext i32 %"prmt_res3" to i64
  %"iadd_rhs_packed_0" = or i64 0, %"iadd_rhs_r0_ext"
  %"iadd_rhs_r1_ext" = zext i32 %"s2ur_swin.1" to i64
  %"iadd_rhs_r1_shift" = shl i64 %"iadd_rhs_r1_ext", 32
  %"iadd_rhs_packed_1" = or i64 %"iadd_rhs_packed_0", %"iadd_rhs_r1_shift"
  %"iadd" = add i64 %"iadd_lhs_packed_1", %"iadd_rhs_packed_1"
  %"RZ_idx64h_1:RZ_idx64_1_r0" = trunc i64 %"iadd" to i32
  %"RZ_idx64h_1:RZ_idx64_1_r1_shift" = lshr i64 %"iadd", 32
  %"RZ_idx64h_1:RZ_idx64_1_r1" = trunc i64 %"RZ_idx64h_1:RZ_idx64_1_r1_shift" to i32
  %"ldg_addr_r0_ext" = zext i32 %"RZ_idx64h_1:RZ_idx64_1_r0" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"RZ_idx64h_1:RZ_idx64_1_r1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %".47" = bitcast [1040 x i8] addrspace(3)* @"shared_mem" to i8 addrspace(3)*
  %".48" = addrspacecast i8 addrspace(3)* %".47" to i8*
  %"R6:R5_addr_ptr" = call i64 @"__culifter_shared_window_resolve"(i64 %"ldg_addr_packed_1", i8* %".48", i64 0)
  %"R6:R5_addr_ptr.1" = inttoptr i64 %"R6:R5_addr_ptr" to i32*
  %"ldg" = load i32, i32* %"R6:R5_addr_ptr.1"
  %"lanemask_lt" = call i32 @"llvm.nvvm.read.ptx.sreg.lanemask.lt"()
  %".49" = xor i32 %"lanemask_lt", -1
  %".50" = xor i32 %"activemask", -1
  %".51" = xor i32 0, -1
  %".52" = and i32 %"lanemask_lt", %"activemask"
  %".53" = and i32 %".52", %".51"
  %".54" = and i32 %"lanemask_lt", %"activemask"
  %".55" = and i32 %".54", 0
  %".56" = or i32 %".53", %".55"
  %"popc.1" = call i32 @"llvm.ctpop.i32"(i32 %".56")
  %"shfl_idx" = call i32 @"llvm.nvvm.shfl.sync.idx.i32"(i32 %"activemask", i32 %"phi", i32 %"flo", i32 31)
  %"imad_tmp.2" = mul i32 %"iadd3_n2", %"popc.1"
  %"imad.2" = add i32 %"imad_tmp.2", %"shfl_idx"
  %"imad_tmp.3" = mul i32 %"imad.2", 1
  %"imad.3" = add i32 %"imad_tmp.3", %"ldg"
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_0370", label %"BB_0310"
BB_0310:
  call void @"llvm.nvvm.membar.gl"()
  call void asm sideeffect "barrier.cluster.arrive.aligned;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P2_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_03b0", label %"BB_0380"
BB_0380:
  call void asm sideeffect "barrier.cluster.wait.aligned;", "~{memory}"()
  br label %"BB_03c0"
BB_03b0:
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_03c0"
BB_03c0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".12", 4
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".65" = getelementptr inbounds [1040 x i8], [1040 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".65" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".66" = getelementptr inbounds [544 x i8], [544 x i8]* %"param_local", i64 0, i64 528
  %".67" = bitcast i8* %".66" to i64*
  %"ldc_const.1" = load i64, i64* %".67"
  %"R3:R2_r0" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"ctaid_x" to i64
  %"imad_rhs_64" = zext i32 8 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.4" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad.4" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.4", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.1" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"stg_val_r0_ext" = zext i32 %"imad.3" to i64
  %"stg_val_packed_0" = or i64 0, %"stg_val_r0_ext"
  %"stg_val_r1_ext" = zext i32 %"lds.1" to i64
  %"stg_val_r1_shift" = shl i64 %"stg_val_r1_ext", 32
  %"stg_val_packed_1" = or i64 %"stg_val_packed_0", %"stg_val_r1_shift"
  %"R29:R14_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i64 addrspace(1)*
  store i64 %"stg_val_packed_1", i64 addrspace(1)* %"R29:R14_addr_ptr"
  ret void
}

@"const_mem" = global [5 x [536 x i8]] [[536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [536 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare void @"llvm.nvvm.membar.gl"()

declare void @"llvm.nvvm.barrier0"()

define internal i32 @"__culifter_shared_window_hi"(i32 %".1") noinline !culifter.shared_window !2
{
entry:
  ret i32 %".1"
}

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.nvvm.activemask"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.ctpop.i32"(i32 %".1")

define internal i64 @"__culifter_shared_window_resolve"(i64 %".1", i8* %".2", i64 %".3") noinline !culifter.shared_window !2
{
entry:
  %".5" = ptrtoint i8* %".2" to i64
  %".6" = lshr i64 %".1", 32
  %".7" = lshr i64 %".5", 32
  %".8" = icmp eq i64 %".6", %".7"
  %".9" = and i64 %".5", 16777215
  %".10" = sub i64 %".9", %".3"
  %".11" = add i64 %".1", %".10"
  %".12" = select  i1 %".8", i64 %".11", i64 %".1"
  ret i64 %".12"
}

declare i32 @"llvm.nvvm.read.ptx.sreg.lanemask.lt"()

declare i32 @"llvm.nvvm.shfl.sync.idx.i32"(i32 %".1", i32 %".2", i32 %".3", i32 %".4")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64)* @"dsm", !"kernel", i32 1 }
!2 = !{  }
