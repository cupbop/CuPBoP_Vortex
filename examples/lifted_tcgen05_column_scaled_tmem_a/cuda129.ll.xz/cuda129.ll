; ModuleID = "tcgen05_column_scaled_tmem_a_sm100a_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [2064 x i8], align 16
define void @"_Z13column_scaledIL4Case6EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P13_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P13_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R29:R146_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R29:R146_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P21_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P6_to_i32", %"BB_00a0"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P25_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P39_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P39_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P2_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P28_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_0f90"
BB_0560_0f90:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.10" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.10", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R77:R54_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R77:R54_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R77:R54_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R77:R54_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R77:R54_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R77:R54_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R77:R54_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R77:R54_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R77:R54_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R77:R54_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R77:R54_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R77:R54_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R77:R54_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R77:R54_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R77:R54_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R77:R54_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.15"
  %"ldg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9248
  %"R77:R54_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.16"
  %"ldg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9252
  %"R77:R54_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R77:R54_addr_ptr.17"
  %"R11:R10_r0" = trunc i64 0 to i32
  %"R11:R10_r1_shift" = lshr i64 0, 32
  %"R11:R10_r1" = trunc i64 %"R11:R10_r1_shift" to i32
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.12", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"ldg.17", i32 %"ldg.18", i32 %"R11:R10_r0", i32 %"R11:R10_r1")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a30", label %"BB_08a0"
BB_08a0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".197" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".197" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".198" = zext i32 0 to i64
  %".199" = zext i32 %".185" to i64
  %".200" = shl i64 %".199", 32
  %"shf_concat.4" = or i64 %".198", %".200"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".201" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".201", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".202" = xor i32 %"plop3_a_bit.2", 1
  %".203" = xor i32 %"plop3_b_bit.2", 1
  %".204" = xor i32 %"plop3_c_bit.2", 1
  %".205" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".206" = and i32 %".205", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".206", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".207" = xor i32 %"shf_result.4", -1
  %".208" = xor i32 16376, -1
  %".209" = xor i32 0, -1
  %".210" = and i32 %"shf_result.4", 16376
  %".211" = and i32 %".210", %".209"
  %".212" = and i32 %"shf_result.4", 16376
  %".213" = and i32 %".212", 0
  %".214" = or i32 %".211", %".213"
  %".215" = xor i32 %".214", -1
  %".216" = xor i32 524288, -1
  %".217" = xor i32 0, -1
  %".218" = and i32 %".215", 524288
  %".219" = and i32 %".218", %".217"
  %".220" = and i32 %".215", 524288
  %".221" = and i32 %".220", 0
  %".222" = or i32 %".219", %".221"
  %".223" = and i32 %".214", %".216"
  %".224" = and i32 %".223", %".217"
  %".225" = or i32 %".222", %".224"
  %".226" = and i32 %".214", %".216"
  %".227" = and i32 %".226", 0
  %".228" = or i32 %".225", %".227"
  %".229" = and i32 %".214", 524288
  %".230" = and i32 %".229", %".217"
  %".231" = or i32 %".228", %".230"
  %".232" = and i32 %".214", 524288
  %".233" = and i32 %".232", 0
  %".234" = or i32 %".231", %".233"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"lds.2", 24
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.2", 16
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"lds.2", 20
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_0960"
BB_0960:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_08a0"], [%"P20_to_i32", %"BB_0990"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_08a0"], [%"phi.14", %"BB_0990"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000960", label %"BB_0970"
BB_80000960:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0970"
BB_0970:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000960"], [%"phi.11", %"BB_0960"]
  %"mma_b_r0_ext" = zext i32 %".234" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16416 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".238" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".239" = sub i64 %".238", 0
  %".240" = lshr i64 %".239", 4
  %".241" = add i64 %"mma_b_packed_1", %".240"
  %".242" = and i64 %".241", 16383
  %".243" = and i64 %"mma_b_packed_1", -16384
  %".244" = or i64 %".243", %".242"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.sp.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], [$1], $2, [$5], $3, [$6], [$7], use_d; } }", "r,r,l,r,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".244", i32 134481028, i32 %"mma_arg_zext", i32 %"iadd3_n2.2", i32 %"iadd3_n2.3", i32 %"iadd3_n2.4")
  br label %"BB_0980"
BB_0980:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000980", label %"BB_0990"
BB_80000980:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".248" = xor i32 %"plop3_a_bit.3", 1
  %".249" = xor i32 %"plop3_b_bit.3", 1
  %".250" = xor i32 %"plop3_c_bit.3", 1
  %".251" = and i32 %".248", %"plop3_b_bit.3"
  %".252" = and i32 %".251", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".252", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0990"
BB_0990:
  %"phi.14" = phi  i32 [%"P31_to_i32", %"BB_80000980"], [%"phi.12", %"BB_0980"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".254" = xor i32 %"plop3_a_bit.4", 1
  %".255" = xor i32 %"plop3_b_bit.4", 1
  %".256" = xor i32 %"plop3_c_bit.4", 1
  %".257" = and i32 %".254", %"plop3_b_bit.4"
  %".258" = and i32 %".257", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".258", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0960", label %"BB_09b0"
BB_09b0:
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".260" = xor i32 %"plop3_a_bit.5", 1
  %".261" = xor i32 %"plop3_b_bit.5", 1
  %".262" = xor i32 %"plop3_c_bit.5", 1
  %".263" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".264" = and i32 %".263", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".264", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".265" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".266" = zext i32 %"iadd3_n2.5" to i64
  %".267" = zext i32 24 to i64
  %".268" = shl i64 %".265", %".267"
  %".269" = and i64 %".268", 4294967295
  %".270" = add i64 %".269", %".266"
  %".271" = trunc i64 %".270" to i32
  br label %"BB_09e0"
BB_09e0:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_09b0"], [%"P11_to_i32", %"BB_0a10"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_09b0"], [%"phi.18", %"BB_0a10"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P8_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_800009e0"], [%"phi.15", %"BB_09e0"]
  %"utcbar_local_winoff" = and i32 %".271", 16777215
  %".275" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".276" = ptrtoint i8 addrspace(3)* %".275" to i32
  %".277" = lshr i32 %".271", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".276", i32 %".277")
  br label %"BB_0a00"
BB_0a00:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000a00", label %"BB_0a10"
BB_80000a00:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".281" = xor i32 %"plop3_a_bit.6", 1
  %".282" = xor i32 %"plop3_b_bit.6", 1
  %".283" = xor i32 %"plop3_c_bit.6", 1
  %".284" = and i32 %".281", %"plop3_b_bit.6"
  %".285" = and i32 %".284", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".285", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_0a10"
BB_0a10:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_80000a00"], [%"phi.16", %"BB_0a00"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".287" = xor i32 %"plop3_a_bit.7", 1
  %".288" = xor i32 %"plop3_b_bit.7", 1
  %".289" = xor i32 %"plop3_c_bit.7", 1
  %".290" = and i32 %".287", %"plop3_b_bit.7"
  %".291" = and i32 %".290", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".291", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09e0", label %"BB_0a30"
BB_0a30:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 1024
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %".293" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".294" = zext i32 %"iadd3_n2.6" to i64
  %".295" = zext i32 24 to i64
  %".296" = shl i64 %".293", %".295"
  %".297" = and i64 %".296", 4294967295
  %".298" = add i64 %".297", %".294"
  %".299" = trunc i64 %".298" to i32
  %"mbar_shared_winoff.1" = and i32 %".299", 16777215
  %".300" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".300" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a80"
BB_0a80:
  %"cond_trunc.16" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0f30", label %"BB_0a90"
BB_0f30:
  %"mbar_shared_winoff.2" = and i32 %".299", 16777215
  %".303" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".303" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f40"
BB_0f40:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f30", label %"BB_0a90"
BB_0a90:
  %".306" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".307" = bitcast i8* %".306" to i64*
  %"ldc_const.2" = load i64, i64* %".307"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".314" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".315" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R96:R94_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R96:R94_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R96:R94_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R96:R94_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R96:R94_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R96:R94_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R96:R94_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R96:R94_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R96:R94_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R96:R94_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".321" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R96:R94_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R96:R94_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R96:R94_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".314", i32 addrspace(1)* %"R96:R94_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R96:R94_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".315", i32 addrspace(1)* %"R96:R94_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".328" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".331" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R96:R94_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".321", i32 addrspace(1)* %"R96:R94_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R96:R94_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R96:R94_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R96:R94_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R96:R94_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R96:R94_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R96:R94_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R96:R94_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".328", i32 addrspace(1)* %"R96:R94_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R96:R94_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R96:R94_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R96:R94_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R96:R94_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R96:R94_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".331", i32 addrspace(1)* %"R96:R94_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c90"
BB_0c90:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c90", label %"BB_0ca0"
BB_0ca0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".342" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".342" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 3
  %".343" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".344" = zext i32 80 to i64
  %".345" = zext i32 24 to i64
  %".346" = shl i64 %".343", %".345"
  %".347" = and i64 %".346", 4294967295
  %".348" = add i64 %".347", %".344"
  %".349" = trunc i64 %".348" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.4" = and i32 %".349", 16777215
  %".350" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".350" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".351" = xor i32 %"lds.3", -1
  %".352" = xor i32 65535, -1
  %".353" = xor i32 0, -1
  %".354" = and i32 %"lds.3", 65535
  %".355" = and i32 %".354", %".353"
  %".356" = and i32 %"lds.3", 65535
  %".357" = and i32 %".356", 0
  %".358" = or i32 %".355", %".357"
  %".359" = zext i32 0 to i64
  %".360" = zext i32 %".358" to i64
  %".361" = shl i64 %".360", 32
  %"shf_concat.5" = or i64 %".359", %".361"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".362" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".362", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".363" = zext i32 %"imad.15" to i64
  %".364" = zext i32 0 to i64
  %".365" = shl i64 %".364", 32
  %"shf_concat.6" = or i64 %".363", %".365"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".366" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".366" to i32
  %".367" = zext i32 %"imad.16" to i64
  %".368" = zext i32 0 to i64
  %".369" = shl i64 %".368", 32
  %"shf_concat.7" = or i64 %".367", %".369"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".370" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".370" to i32
  %".371" = xor i32 %"shf_result.7", -1
  %".372" = xor i32 %"shf_result.6", -1
  %".373" = xor i32 0, -1
  %".374" = and i32 %".371", %"shf_result.6"
  %".375" = and i32 %".374", %".373"
  %".376" = and i32 %".371", %"shf_result.6"
  %".377" = and i32 %".376", 0
  %".378" = or i32 %".375", %".377"
  %".379" = and i32 %"shf_result.7", %".372"
  %".380" = and i32 %".379", %".373"
  %".381" = or i32 %".378", %".380"
  %".382" = and i32 %"shf_result.7", %".372"
  %".383" = and i32 %".382", 0
  %".384" = or i32 %".381", %".383"
  %".385" = and i32 %"shf_result.7", %"shf_result.6"
  %".386" = and i32 %".385", %".373"
  %".387" = or i32 %".384", %".386"
  %".388" = and i32 %"shf_result.7", %"shf_result.6"
  %".389" = and i32 %".388", 0
  %".390" = or i32 %".387", %".389"
  %".391" = xor i32 %".390", -1
  %".392" = xor i32 65535, -1
  %".393" = xor i32 0, -1
  %".394" = and i32 %".390", 65535
  %".395" = and i32 %".394", %".393"
  %".396" = and i32 %".390", 65535
  %".397" = and i32 %".396", 0
  %".398" = or i32 %".395", %".397"
  %".399" = xor i32 %".390", -1
  %".400" = xor i32 65535, -1
  %".401" = xor i32 %"lds.4", -1
  %".402" = and i32 %".390", 65535
  %".403" = and i32 %".402", %"lds.4"
  %"isetrp_cmp1.9" = icmp ne i32 %".403", %".398"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0da0"
BB_0da0:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0f00_0fc0", label %"BB_0db0"
BB_0db0:
  %".406" = zext i32 0 to i64
  %".407" = zext i32 %"lds.4" to i64
  %".408" = shl i64 %".407", 32
  %"shf_concat.8" = or i64 %".406", %".408"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".409" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".409", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".410" = zext i32 0 to i64
  %".411" = zext i32 %".390" to i64
  %".412" = shl i64 %".411", 32
  %"shf_concat.9" = or i64 %".410", %".412"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".413" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".413", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".414" = xor i32 %"shf_result.8", -1
  %".415" = xor i32 %"shf_result.9", -1
  %".416" = xor i32 0, -1
  %".417" = and i32 %"shf_result.8", %"shf_result.9"
  %".418" = and i32 %".417", %".416"
  %".419" = and i32 %"shf_result.8", %"shf_result.9"
  %".420" = and i32 %".419", 0
  %".421" = or i32 %".418", %".420"
  %"isetrp_cmp1.10" = icmp ne i32 %".421", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0df0"
BB_0df0:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0ed0_0f60", label %"BB_0e00"
BB_0e00:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".424" = xor i32 0, -1
  %".425" = xor i32 %".390", -1
  %".426" = xor i32 0, -1
  %".427" = and i32 %".424", %".425"
  %".428" = and i32 %".427", %".426"
  %".429" = and i32 %".424", %".425"
  %".430" = and i32 %".429", 0
  %".431" = or i32 %".428", %".430"
  %".432" = and i32 0, %".425"
  %".433" = and i32 %".432", %".426"
  %".434" = or i32 %".431", %".433"
  %".435" = and i32 0, %".425"
  %".436" = and i32 %".435", 0
  %".437" = or i32 %".434", %".436"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".437"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".438" = xor i32 %".437", -1
  %".439" = call i32 @"llvm.cttz.i32"(i32 %".438", i1 0)
  %".440" = shl i32 %".439", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".440") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0ea0"
BB_0ea0:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000ea0", label %"BB_0f10"
BB_80000ea0:
  %"atoms_shared_addr_winoff.1" = and i32 %".349", 16777215
  %".444" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".444" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_0f10"
BB_0ed0_0f60:
  call void @"llvm.trap"()
  br label %"BB_0f10"
BB_0f00_0fc0:
  call void @"llvm.trap"()
  br label %"BB_0f10"
BB_0f10:
  ret void
BB_80000c90:
  ret void
}

define void @"_Z13column_scaledIL4Case5EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P13_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P13_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R21:R131_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R21:R131_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P21_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P6_to_i32", %"BB_00a0"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P25_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P39_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P39_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P2_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P28_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_0f40"
BB_0560_0f40:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.10" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.10", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R67:R33_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R67:R33_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R67:R33_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R67:R33_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R67:R33_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R67:R33_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R67:R33_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R67:R33_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R67:R33_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R67:R33_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R67:R33_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R67:R33_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R67:R33_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R67:R33_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R67:R33_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R67:R33_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0840"
BB_0840:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_09e0", label %"BB_0850"
BB_0850:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".196" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".185" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".201" = xor i32 %"plop3_a_bit.2", 1
  %".202" = xor i32 %"plop3_b_bit.2", 1
  %".203" = xor i32 %"plop3_c_bit.2", 1
  %".204" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".205" = and i32 %".204", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".205", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".206" = xor i32 %"shf_result.4", -1
  %".207" = xor i32 16376, -1
  %".208" = xor i32 0, -1
  %".209" = and i32 %"shf_result.4", 16376
  %".210" = and i32 %".209", %".208"
  %".211" = and i32 %"shf_result.4", 16376
  %".212" = and i32 %".211", 0
  %".213" = or i32 %".210", %".212"
  %".214" = xor i32 %".213", -1
  %".215" = xor i32 524288, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %".214", 524288
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %".214", 524288
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".213", %".215"
  %".223" = and i32 %".222", %".216"
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".213", %".215"
  %".226" = and i32 %".225", 0
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".213", 524288
  %".229" = and i32 %".228", %".216"
  %".230" = or i32 %".227", %".229"
  %".231" = and i32 %".213", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"lds.2", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.2", 20
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0910"
BB_0910:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0850"], [%"P20_to_i32", %"BB_0940"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0850"], [%"phi.14", %"BB_0940"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000910"], [%"phi.11", %"BB_0910"]
  %"mma_b_r0_ext" = zext i32 %".233" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".237" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".238" = sub i64 %".237", 0
  %".239" = lshr i64 %".238", 4
  %".240" = add i64 %"mma_b_packed_1", %".239"
  %".241" = and i64 %".240", 16383
  %".242" = and i64 %"mma_b_packed_1", -16384
  %".243" = or i64 %".242", %".241"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".243", i32 134481024, i32 %"mma_arg_zext", i32 %"iadd3_n2.2", i32 %"iadd3_n2.3")
  br label %"BB_0930"
BB_0930:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000930", label %"BB_0940"
BB_80000930:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".247" = xor i32 %"plop3_a_bit.3", 1
  %".248" = xor i32 %"plop3_b_bit.3", 1
  %".249" = xor i32 %"plop3_c_bit.3", 1
  %".250" = and i32 %".247", %"plop3_b_bit.3"
  %".251" = and i32 %".250", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".251", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.14" = phi  i32 [%"P31_to_i32", %"BB_80000930"], [%"phi.12", %"BB_0930"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".253" = xor i32 %"plop3_a_bit.4", 1
  %".254" = xor i32 %"plop3_b_bit.4", 1
  %".255" = xor i32 %"plop3_c_bit.4", 1
  %".256" = and i32 %".253", %"plop3_b_bit.4"
  %".257" = and i32 %".256", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".257", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0910", label %"BB_0960"
BB_0960:
  %"iadd3_n1.4" = add i32 1024, 1024
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".259" = xor i32 %"plop3_a_bit.5", 1
  %".260" = xor i32 %"plop3_b_bit.5", 1
  %".261" = xor i32 %"plop3_c_bit.5", 1
  %".262" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".263" = and i32 %".262", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".263", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".264" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".265" = zext i32 %"iadd3_n2.4" to i64
  %".266" = zext i32 24 to i64
  %".267" = shl i64 %".264", %".266"
  %".268" = and i64 %".267", 4294967295
  %".269" = add i64 %".268", %".265"
  %".270" = trunc i64 %".269" to i32
  br label %"BB_0990"
BB_0990:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0960"], [%"P11_to_i32", %"BB_09c0"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0960"], [%"phi.18", %"BB_09c0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P8_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_80000990"], [%"phi.15", %"BB_0990"]
  %"utcbar_local_winoff" = and i32 %".270", 16777215
  %".274" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".275" = ptrtoint i8 addrspace(3)* %".274" to i32
  %".276" = lshr i32 %".270", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".275", i32 %".276")
  br label %"BB_09b0"
BB_09b0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".280" = xor i32 %"plop3_a_bit.6", 1
  %".281" = xor i32 %"plop3_b_bit.6", 1
  %".282" = xor i32 %"plop3_c_bit.6", 1
  %".283" = and i32 %".280", %"plop3_b_bit.6"
  %".284" = and i32 %".283", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".284", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_800009b0"], [%"phi.16", %"BB_09b0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".286" = xor i32 %"plop3_a_bit.7", 1
  %".287" = xor i32 %"plop3_b_bit.7", 1
  %".288" = xor i32 %"plop3_c_bit.7", 1
  %".289" = and i32 %".286", %"plop3_b_bit.7"
  %".290" = and i32 %".289", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".290", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0990", label %"BB_09e0"
BB_09e0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".292" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".293" = zext i32 %"iadd3_n2.5" to i64
  %".294" = zext i32 24 to i64
  %".295" = shl i64 %".292", %".294"
  %".296" = and i64 %".295", 4294967295
  %".297" = add i64 %".296", %".293"
  %".298" = trunc i64 %".297" to i32
  %"mbar_shared_winoff.1" = and i32 %".298", 16777215
  %".299" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.16" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0ee0", label %"BB_0a40"
BB_0ee0:
  %"mbar_shared_winoff.2" = and i32 %".298", 16777215
  %".302" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".302" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0ef0"
BB_0ef0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0ee0", label %"BB_0a40"
BB_0a40:
  %".305" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".306" = bitcast i8* %".305" to i64*
  %"ldc_const.2" = load i64, i64* %".306"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".314" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R70:R44_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R70:R44_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R70:R44_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R70:R44_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R70:R44_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R70:R44_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R70:R44_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R70:R44_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R70:R44_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R70:R44_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".321" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R70:R44_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R70:R44_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R70:R44_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R70:R44_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R70:R44_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".314", i32 addrspace(1)* %"R70:R44_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".328" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R70:R44_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R70:R44_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R70:R44_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".321", i32 addrspace(1)* %"R70:R44_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R70:R44_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R70:R44_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R70:R44_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R70:R44_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R70:R44_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R70:R44_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R70:R44_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".328", i32 addrspace(1)* %"R70:R44_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R70:R44_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R70:R44_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R70:R44_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R70:R44_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c40", label %"BB_0c50"
BB_0c50:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".341" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".341" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 3
  %".342" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".343" = zext i32 80 to i64
  %".344" = zext i32 24 to i64
  %".345" = shl i64 %".342", %".344"
  %".346" = and i64 %".345", 4294967295
  %".347" = add i64 %".346", %".343"
  %".348" = trunc i64 %".347" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.4" = and i32 %".348", 16777215
  %".349" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".349" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".350" = xor i32 %"lds.3", -1
  %".351" = xor i32 65535, -1
  %".352" = xor i32 0, -1
  %".353" = and i32 %"lds.3", 65535
  %".354" = and i32 %".353", %".352"
  %".355" = and i32 %"lds.3", 65535
  %".356" = and i32 %".355", 0
  %".357" = or i32 %".354", %".356"
  %".358" = zext i32 0 to i64
  %".359" = zext i32 %".357" to i64
  %".360" = shl i64 %".359", 32
  %"shf_concat.5" = or i64 %".358", %".360"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".361" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".361", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".362" = zext i32 %"imad.15" to i64
  %".363" = zext i32 0 to i64
  %".364" = shl i64 %".363", 32
  %"shf_concat.6" = or i64 %".362", %".364"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".365" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".365" to i32
  %".366" = zext i32 %"imad.16" to i64
  %".367" = zext i32 0 to i64
  %".368" = shl i64 %".367", 32
  %"shf_concat.7" = or i64 %".366", %".368"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".369" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".369" to i32
  %".370" = xor i32 %"shf_result.7", -1
  %".371" = xor i32 %"shf_result.6", -1
  %".372" = xor i32 0, -1
  %".373" = and i32 %".370", %"shf_result.6"
  %".374" = and i32 %".373", %".372"
  %".375" = and i32 %".370", %"shf_result.6"
  %".376" = and i32 %".375", 0
  %".377" = or i32 %".374", %".376"
  %".378" = and i32 %"shf_result.7", %".371"
  %".379" = and i32 %".378", %".372"
  %".380" = or i32 %".377", %".379"
  %".381" = and i32 %"shf_result.7", %".371"
  %".382" = and i32 %".381", 0
  %".383" = or i32 %".380", %".382"
  %".384" = and i32 %"shf_result.7", %"shf_result.6"
  %".385" = and i32 %".384", %".372"
  %".386" = or i32 %".383", %".385"
  %".387" = and i32 %"shf_result.7", %"shf_result.6"
  %".388" = and i32 %".387", 0
  %".389" = or i32 %".386", %".388"
  %".390" = xor i32 %".389", -1
  %".391" = xor i32 65535, -1
  %".392" = xor i32 0, -1
  %".393" = and i32 %".389", 65535
  %".394" = and i32 %".393", %".392"
  %".395" = and i32 %".389", 65535
  %".396" = and i32 %".395", 0
  %".397" = or i32 %".394", %".396"
  %".398" = xor i32 %".389", -1
  %".399" = xor i32 65535, -1
  %".400" = xor i32 %"lds.4", -1
  %".401" = and i32 %".389", 65535
  %".402" = and i32 %".401", %"lds.4"
  %"isetrp_cmp1.9" = icmp ne i32 %".402", %".397"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0eb0_0f70", label %"BB_0d60"
BB_0d60:
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %"lds.4" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.8" = or i64 %".405", %".407"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".408" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".409" = zext i32 0 to i64
  %".410" = zext i32 %".389" to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.9" = or i64 %".409", %".411"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".412" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".412", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".413" = xor i32 %"shf_result.8", -1
  %".414" = xor i32 %"shf_result.9", -1
  %".415" = xor i32 0, -1
  %".416" = and i32 %"shf_result.8", %"shf_result.9"
  %".417" = and i32 %".416", %".415"
  %".418" = and i32 %"shf_result.8", %"shf_result.9"
  %".419" = and i32 %".418", 0
  %".420" = or i32 %".417", %".419"
  %"isetrp_cmp1.10" = icmp ne i32 %".420", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0da0"
BB_0da0:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0e80_0f10", label %"BB_0db0"
BB_0db0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".423" = xor i32 0, -1
  %".424" = xor i32 %".389", -1
  %".425" = xor i32 0, -1
  %".426" = and i32 %".423", %".424"
  %".427" = and i32 %".426", %".425"
  %".428" = and i32 %".423", %".424"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".424"
  %".432" = and i32 %".431", %".425"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 0, %".424"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".436"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".437" = xor i32 %".436", -1
  %".438" = call i32 @"llvm.cttz.i32"(i32 %".437", i1 0)
  %".439" = shl i32 %".438", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".439") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e50", label %"BB_0ec0"
BB_80000e50:
  %"atoms_shared_addr_winoff.1" = and i32 %".348", 16777215
  %".443" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".443" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_0ec0"
BB_0e80_0f10:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0eb0_0f70:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0ec0:
  ret void
BB_80000c40:
  ret void
}

define void @"_Z13column_scaledIL4Case4EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P13_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P13_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R21:R131_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R21:R131_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P21_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P6_to_i32", %"BB_00a0"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P25_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P39_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P39_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P2_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P28_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_0f40"
BB_0560_0f40:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.10" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.10", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R67:R33_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R67:R33_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R67:R33_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R67:R33_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R67:R33_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R67:R33_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R67:R33_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R67:R33_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R67:R33_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R67:R33_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R67:R33_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R67:R33_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R67:R33_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R67:R33_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R67:R33_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R67:R33_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0840"
BB_0840:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_09e0", label %"BB_0850"
BB_0850:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".196" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".185" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".201" = xor i32 %"plop3_a_bit.2", 1
  %".202" = xor i32 %"plop3_b_bit.2", 1
  %".203" = xor i32 %"plop3_c_bit.2", 1
  %".204" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".205" = and i32 %".204", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".205", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".206" = xor i32 %"shf_result.4", -1
  %".207" = xor i32 16376, -1
  %".208" = xor i32 0, -1
  %".209" = and i32 %"shf_result.4", 16376
  %".210" = and i32 %".209", %".208"
  %".211" = and i32 %"shf_result.4", 16376
  %".212" = and i32 %".211", 0
  %".213" = or i32 %".210", %".212"
  %".214" = xor i32 %".213", -1
  %".215" = xor i32 524288, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %".214", 524288
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %".214", 524288
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".213", %".215"
  %".223" = and i32 %".222", %".216"
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".213", %".215"
  %".226" = and i32 %".225", 0
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".213", 524288
  %".229" = and i32 %".228", %".216"
  %".230" = or i32 %".227", %".229"
  %".231" = and i32 %".213", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"lds.2", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.2", 20
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0910"
BB_0910:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0850"], [%"P20_to_i32", %"BB_0940"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0850"], [%"phi.14", %"BB_0940"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000910"], [%"phi.11", %"BB_0910"]
  %"mma_b_r0_ext" = zext i32 %".233" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".237" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".238" = sub i64 %".237", 0
  %".239" = lshr i64 %".238", 4
  %".240" = add i64 %"mma_b_packed_1", %".239"
  %".241" = and i64 %".240", 16383
  %".242" = and i64 %"mma_b_packed_1", -16384
  %".243" = or i64 %".242", %".241"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::2X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".243", i32 1216611456, i32 %"mma_arg_zext", i32 %"iadd3_n2.2", i32 %"iadd3_n2.3")
  br label %"BB_0930"
BB_0930:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000930", label %"BB_0940"
BB_80000930:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".247" = xor i32 %"plop3_a_bit.3", 1
  %".248" = xor i32 %"plop3_b_bit.3", 1
  %".249" = xor i32 %"plop3_c_bit.3", 1
  %".250" = and i32 %".247", %"plop3_b_bit.3"
  %".251" = and i32 %".250", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".251", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.14" = phi  i32 [%"P31_to_i32", %"BB_80000930"], [%"phi.12", %"BB_0930"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".253" = xor i32 %"plop3_a_bit.4", 1
  %".254" = xor i32 %"plop3_b_bit.4", 1
  %".255" = xor i32 %"plop3_c_bit.4", 1
  %".256" = and i32 %".253", %"plop3_b_bit.4"
  %".257" = and i32 %".256", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".257", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0910", label %"BB_0960"
BB_0960:
  %"iadd3_n1.4" = add i32 1024, 1024
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".259" = xor i32 %"plop3_a_bit.5", 1
  %".260" = xor i32 %"plop3_b_bit.5", 1
  %".261" = xor i32 %"plop3_c_bit.5", 1
  %".262" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".263" = and i32 %".262", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".263", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".264" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".265" = zext i32 %"iadd3_n2.4" to i64
  %".266" = zext i32 24 to i64
  %".267" = shl i64 %".264", %".266"
  %".268" = and i64 %".267", 4294967295
  %".269" = add i64 %".268", %".265"
  %".270" = trunc i64 %".269" to i32
  br label %"BB_0990"
BB_0990:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0960"], [%"P11_to_i32", %"BB_09c0"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0960"], [%"phi.18", %"BB_09c0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P8_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_80000990"], [%"phi.15", %"BB_0990"]
  %"utcbar_local_winoff" = and i32 %".270", 16777215
  %".274" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".275" = ptrtoint i8 addrspace(3)* %".274" to i32
  %".276" = lshr i32 %".270", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".275", i32 %".276")
  br label %"BB_09b0"
BB_09b0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".280" = xor i32 %"plop3_a_bit.6", 1
  %".281" = xor i32 %"plop3_b_bit.6", 1
  %".282" = xor i32 %"plop3_c_bit.6", 1
  %".283" = and i32 %".280", %"plop3_b_bit.6"
  %".284" = and i32 %".283", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".284", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_800009b0"], [%"phi.16", %"BB_09b0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".286" = xor i32 %"plop3_a_bit.7", 1
  %".287" = xor i32 %"plop3_b_bit.7", 1
  %".288" = xor i32 %"plop3_c_bit.7", 1
  %".289" = and i32 %".286", %"plop3_b_bit.7"
  %".290" = and i32 %".289", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".290", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0990", label %"BB_09e0"
BB_09e0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".292" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".293" = zext i32 %"iadd3_n2.5" to i64
  %".294" = zext i32 24 to i64
  %".295" = shl i64 %".292", %".294"
  %".296" = and i64 %".295", 4294967295
  %".297" = add i64 %".296", %".293"
  %".298" = trunc i64 %".297" to i32
  %"mbar_shared_winoff.1" = and i32 %".298", 16777215
  %".299" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.16" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0ee0", label %"BB_0a40"
BB_0ee0:
  %"mbar_shared_winoff.2" = and i32 %".298", 16777215
  %".302" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".302" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0ef0"
BB_0ef0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0ee0", label %"BB_0a40"
BB_0a40:
  %".305" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".306" = bitcast i8* %".305" to i64*
  %"ldc_const.2" = load i64, i64* %".306"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".314" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R70:R44_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R70:R44_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R70:R44_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R70:R44_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R70:R44_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R70:R44_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R70:R44_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R70:R44_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R70:R44_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R70:R44_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".321" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R70:R44_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R70:R44_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R70:R44_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R70:R44_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R70:R44_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".314", i32 addrspace(1)* %"R70:R44_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".328" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R70:R44_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R70:R44_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R70:R44_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".321", i32 addrspace(1)* %"R70:R44_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R70:R44_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R70:R44_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R70:R44_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R70:R44_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R70:R44_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R70:R44_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R70:R44_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".328", i32 addrspace(1)* %"R70:R44_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R70:R44_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R70:R44_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R70:R44_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R70:R44_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c40", label %"BB_0c50"
BB_0c50:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".341" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".341" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 3
  %".342" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".343" = zext i32 80 to i64
  %".344" = zext i32 24 to i64
  %".345" = shl i64 %".342", %".344"
  %".346" = and i64 %".345", 4294967295
  %".347" = add i64 %".346", %".343"
  %".348" = trunc i64 %".347" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.4" = and i32 %".348", 16777215
  %".349" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".349" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".350" = xor i32 %"lds.3", -1
  %".351" = xor i32 65535, -1
  %".352" = xor i32 0, -1
  %".353" = and i32 %"lds.3", 65535
  %".354" = and i32 %".353", %".352"
  %".355" = and i32 %"lds.3", 65535
  %".356" = and i32 %".355", 0
  %".357" = or i32 %".354", %".356"
  %".358" = zext i32 0 to i64
  %".359" = zext i32 %".357" to i64
  %".360" = shl i64 %".359", 32
  %"shf_concat.5" = or i64 %".358", %".360"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".361" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".361", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".362" = zext i32 %"imad.15" to i64
  %".363" = zext i32 0 to i64
  %".364" = shl i64 %".363", 32
  %"shf_concat.6" = or i64 %".362", %".364"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".365" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".365" to i32
  %".366" = zext i32 %"imad.16" to i64
  %".367" = zext i32 0 to i64
  %".368" = shl i64 %".367", 32
  %"shf_concat.7" = or i64 %".366", %".368"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".369" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".369" to i32
  %".370" = xor i32 %"shf_result.7", -1
  %".371" = xor i32 %"shf_result.6", -1
  %".372" = xor i32 0, -1
  %".373" = and i32 %".370", %"shf_result.6"
  %".374" = and i32 %".373", %".372"
  %".375" = and i32 %".370", %"shf_result.6"
  %".376" = and i32 %".375", 0
  %".377" = or i32 %".374", %".376"
  %".378" = and i32 %"shf_result.7", %".371"
  %".379" = and i32 %".378", %".372"
  %".380" = or i32 %".377", %".379"
  %".381" = and i32 %"shf_result.7", %".371"
  %".382" = and i32 %".381", 0
  %".383" = or i32 %".380", %".382"
  %".384" = and i32 %"shf_result.7", %"shf_result.6"
  %".385" = and i32 %".384", %".372"
  %".386" = or i32 %".383", %".385"
  %".387" = and i32 %"shf_result.7", %"shf_result.6"
  %".388" = and i32 %".387", 0
  %".389" = or i32 %".386", %".388"
  %".390" = xor i32 %".389", -1
  %".391" = xor i32 65535, -1
  %".392" = xor i32 0, -1
  %".393" = and i32 %".389", 65535
  %".394" = and i32 %".393", %".392"
  %".395" = and i32 %".389", 65535
  %".396" = and i32 %".395", 0
  %".397" = or i32 %".394", %".396"
  %".398" = xor i32 %".389", -1
  %".399" = xor i32 65535, -1
  %".400" = xor i32 %"lds.4", -1
  %".401" = and i32 %".389", 65535
  %".402" = and i32 %".401", %"lds.4"
  %"isetrp_cmp1.9" = icmp ne i32 %".402", %".397"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0eb0_0f70", label %"BB_0d60"
BB_0d60:
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %"lds.4" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.8" = or i64 %".405", %".407"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".408" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".409" = zext i32 0 to i64
  %".410" = zext i32 %".389" to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.9" = or i64 %".409", %".411"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".412" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".412", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".413" = xor i32 %"shf_result.8", -1
  %".414" = xor i32 %"shf_result.9", -1
  %".415" = xor i32 0, -1
  %".416" = and i32 %"shf_result.8", %"shf_result.9"
  %".417" = and i32 %".416", %".415"
  %".418" = and i32 %"shf_result.8", %"shf_result.9"
  %".419" = and i32 %".418", 0
  %".420" = or i32 %".417", %".419"
  %"isetrp_cmp1.10" = icmp ne i32 %".420", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0da0"
BB_0da0:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0e80_0f10", label %"BB_0db0"
BB_0db0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".423" = xor i32 0, -1
  %".424" = xor i32 %".389", -1
  %".425" = xor i32 0, -1
  %".426" = and i32 %".423", %".424"
  %".427" = and i32 %".426", %".425"
  %".428" = and i32 %".423", %".424"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".424"
  %".432" = and i32 %".431", %".425"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 0, %".424"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".436"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".437" = xor i32 %".436", -1
  %".438" = call i32 @"llvm.cttz.i32"(i32 %".437", i1 0)
  %".439" = shl i32 %".438", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".439") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e50", label %"BB_0ec0"
BB_80000e50:
  %"atoms_shared_addr_winoff.1" = and i32 %".348", 16777215
  %".443" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".443" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_0ec0"
BB_0e80_0f10:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0eb0_0f70:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0ec0:
  ret void
BB_80000c40:
  ret void
}

define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P13_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P13_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R21:R131_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R21:R131_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P21_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P6_to_i32", %"BB_00a0"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P25_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P39_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P39_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P2_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P28_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_0f40"
BB_0560_0f40:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.10" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.10", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R67:R33_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R67:R33_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R67:R33_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R67:R33_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R67:R33_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R67:R33_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R67:R33_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R67:R33_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R67:R33_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R67:R33_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R67:R33_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R67:R33_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R67:R33_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R67:R33_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R67:R33_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R67:R33_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0840"
BB_0840:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_09e0", label %"BB_0850"
BB_0850:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".196" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".185" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".201" = xor i32 %"plop3_a_bit.2", 1
  %".202" = xor i32 %"plop3_b_bit.2", 1
  %".203" = xor i32 %"plop3_c_bit.2", 1
  %".204" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".205" = and i32 %".204", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".205", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".206" = xor i32 %"shf_result.4", -1
  %".207" = xor i32 16376, -1
  %".208" = xor i32 0, -1
  %".209" = and i32 %"shf_result.4", 16376
  %".210" = and i32 %".209", %".208"
  %".211" = and i32 %"shf_result.4", 16376
  %".212" = and i32 %".211", 0
  %".213" = or i32 %".210", %".212"
  %".214" = xor i32 %".213", -1
  %".215" = xor i32 524288, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %".214", 524288
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %".214", 524288
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".213", %".215"
  %".223" = and i32 %".222", %".216"
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".213", %".215"
  %".226" = and i32 %".225", 0
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".213", 524288
  %".229" = and i32 %".228", %".216"
  %".230" = or i32 %".227", %".229"
  %".231" = and i32 %".213", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"lds.2", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.2", 20
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0910"
BB_0910:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0850"], [%"P20_to_i32", %"BB_0940"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0850"], [%"phi.14", %"BB_0940"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000910"], [%"phi.11", %"BB_0910"]
  %"mma_b_r0_ext" = zext i32 %".233" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".237" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".238" = sub i64 %".237", 0
  %".239" = lshr i64 %".238", 4
  %".240" = add i64 %"mma_b_packed_1", %".239"
  %".241" = and i64 %".240", 16383
  %".242" = and i64 %"mma_b_packed_1", -16384
  %".243" = or i64 %".242", %".241"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".243", i32 679743664, i32 %"mma_arg_zext", i32 %"iadd3_n2.2", i32 %"iadd3_n2.3")
  br label %"BB_0930"
BB_0930:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000930", label %"BB_0940"
BB_80000930:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".247" = xor i32 %"plop3_a_bit.3", 1
  %".248" = xor i32 %"plop3_b_bit.3", 1
  %".249" = xor i32 %"plop3_c_bit.3", 1
  %".250" = and i32 %".247", %"plop3_b_bit.3"
  %".251" = and i32 %".250", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".251", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.14" = phi  i32 [%"P31_to_i32", %"BB_80000930"], [%"phi.12", %"BB_0930"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".253" = xor i32 %"plop3_a_bit.4", 1
  %".254" = xor i32 %"plop3_b_bit.4", 1
  %".255" = xor i32 %"plop3_c_bit.4", 1
  %".256" = and i32 %".253", %"plop3_b_bit.4"
  %".257" = and i32 %".256", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".257", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0910", label %"BB_0960"
BB_0960:
  %"iadd3_n1.4" = add i32 1024, 1024
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".259" = xor i32 %"plop3_a_bit.5", 1
  %".260" = xor i32 %"plop3_b_bit.5", 1
  %".261" = xor i32 %"plop3_c_bit.5", 1
  %".262" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".263" = and i32 %".262", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".263", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".264" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".265" = zext i32 %"iadd3_n2.4" to i64
  %".266" = zext i32 24 to i64
  %".267" = shl i64 %".264", %".266"
  %".268" = and i64 %".267", 4294967295
  %".269" = add i64 %".268", %".265"
  %".270" = trunc i64 %".269" to i32
  br label %"BB_0990"
BB_0990:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0960"], [%"P11_to_i32", %"BB_09c0"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0960"], [%"phi.18", %"BB_09c0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P8_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_80000990"], [%"phi.15", %"BB_0990"]
  %"utcbar_local_winoff" = and i32 %".270", 16777215
  %".274" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".275" = ptrtoint i8 addrspace(3)* %".274" to i32
  %".276" = lshr i32 %".270", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".275", i32 %".276")
  br label %"BB_09b0"
BB_09b0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".280" = xor i32 %"plop3_a_bit.6", 1
  %".281" = xor i32 %"plop3_b_bit.6", 1
  %".282" = xor i32 %"plop3_c_bit.6", 1
  %".283" = and i32 %".280", %"plop3_b_bit.6"
  %".284" = and i32 %".283", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".284", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_800009b0"], [%"phi.16", %"BB_09b0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".286" = xor i32 %"plop3_a_bit.7", 1
  %".287" = xor i32 %"plop3_b_bit.7", 1
  %".288" = xor i32 %"plop3_c_bit.7", 1
  %".289" = and i32 %".286", %"plop3_b_bit.7"
  %".290" = and i32 %".289", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".290", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0990", label %"BB_09e0"
BB_09e0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".292" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".293" = zext i32 %"iadd3_n2.5" to i64
  %".294" = zext i32 24 to i64
  %".295" = shl i64 %".292", %".294"
  %".296" = and i64 %".295", 4294967295
  %".297" = add i64 %".296", %".293"
  %".298" = trunc i64 %".297" to i32
  %"mbar_shared_winoff.1" = and i32 %".298", 16777215
  %".299" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.16" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0ee0", label %"BB_0a40"
BB_0ee0:
  %"mbar_shared_winoff.2" = and i32 %".298", 16777215
  %".302" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".302" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0ef0"
BB_0ef0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0ee0", label %"BB_0a40"
BB_0a40:
  %".305" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".306" = bitcast i8* %".305" to i64*
  %"ldc_const.2" = load i64, i64* %".306"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".314" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R70:R44_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R70:R44_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R70:R44_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R70:R44_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R70:R44_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R70:R44_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R70:R44_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R70:R44_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R70:R44_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R70:R44_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".321" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R70:R44_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R70:R44_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R70:R44_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R70:R44_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R70:R44_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".314", i32 addrspace(1)* %"R70:R44_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".328" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R70:R44_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R70:R44_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R70:R44_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".321", i32 addrspace(1)* %"R70:R44_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R70:R44_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R70:R44_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R70:R44_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R70:R44_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R70:R44_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R70:R44_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R70:R44_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".328", i32 addrspace(1)* %"R70:R44_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R70:R44_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R70:R44_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R70:R44_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R70:R44_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c40", label %"BB_0c50"
BB_0c50:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".341" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".341" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 3
  %".342" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".343" = zext i32 80 to i64
  %".344" = zext i32 24 to i64
  %".345" = shl i64 %".342", %".344"
  %".346" = and i64 %".345", 4294967295
  %".347" = add i64 %".346", %".343"
  %".348" = trunc i64 %".347" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.4" = and i32 %".348", 16777215
  %".349" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".349" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".350" = xor i32 %"lds.3", -1
  %".351" = xor i32 65535, -1
  %".352" = xor i32 0, -1
  %".353" = and i32 %"lds.3", 65535
  %".354" = and i32 %".353", %".352"
  %".355" = and i32 %"lds.3", 65535
  %".356" = and i32 %".355", 0
  %".357" = or i32 %".354", %".356"
  %".358" = zext i32 0 to i64
  %".359" = zext i32 %".357" to i64
  %".360" = shl i64 %".359", 32
  %"shf_concat.5" = or i64 %".358", %".360"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".361" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".361", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".362" = zext i32 %"imad.15" to i64
  %".363" = zext i32 0 to i64
  %".364" = shl i64 %".363", 32
  %"shf_concat.6" = or i64 %".362", %".364"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".365" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".365" to i32
  %".366" = zext i32 %"imad.16" to i64
  %".367" = zext i32 0 to i64
  %".368" = shl i64 %".367", 32
  %"shf_concat.7" = or i64 %".366", %".368"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".369" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".369" to i32
  %".370" = xor i32 %"shf_result.7", -1
  %".371" = xor i32 %"shf_result.6", -1
  %".372" = xor i32 0, -1
  %".373" = and i32 %".370", %"shf_result.6"
  %".374" = and i32 %".373", %".372"
  %".375" = and i32 %".370", %"shf_result.6"
  %".376" = and i32 %".375", 0
  %".377" = or i32 %".374", %".376"
  %".378" = and i32 %"shf_result.7", %".371"
  %".379" = and i32 %".378", %".372"
  %".380" = or i32 %".377", %".379"
  %".381" = and i32 %"shf_result.7", %".371"
  %".382" = and i32 %".381", 0
  %".383" = or i32 %".380", %".382"
  %".384" = and i32 %"shf_result.7", %"shf_result.6"
  %".385" = and i32 %".384", %".372"
  %".386" = or i32 %".383", %".385"
  %".387" = and i32 %"shf_result.7", %"shf_result.6"
  %".388" = and i32 %".387", 0
  %".389" = or i32 %".386", %".388"
  %".390" = xor i32 %".389", -1
  %".391" = xor i32 65535, -1
  %".392" = xor i32 0, -1
  %".393" = and i32 %".389", 65535
  %".394" = and i32 %".393", %".392"
  %".395" = and i32 %".389", 65535
  %".396" = and i32 %".395", 0
  %".397" = or i32 %".394", %".396"
  %".398" = xor i32 %".389", -1
  %".399" = xor i32 65535, -1
  %".400" = xor i32 %"lds.4", -1
  %".401" = and i32 %".389", 65535
  %".402" = and i32 %".401", %"lds.4"
  %"isetrp_cmp1.9" = icmp ne i32 %".402", %".397"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0eb0_0f70", label %"BB_0d60"
BB_0d60:
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %"lds.4" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.8" = or i64 %".405", %".407"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".408" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".409" = zext i32 0 to i64
  %".410" = zext i32 %".389" to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.9" = or i64 %".409", %".411"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".412" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".412", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".413" = xor i32 %"shf_result.8", -1
  %".414" = xor i32 %"shf_result.9", -1
  %".415" = xor i32 0, -1
  %".416" = and i32 %"shf_result.8", %"shf_result.9"
  %".417" = and i32 %".416", %".415"
  %".418" = and i32 %"shf_result.8", %"shf_result.9"
  %".419" = and i32 %".418", 0
  %".420" = or i32 %".417", %".419"
  %"isetrp_cmp1.10" = icmp ne i32 %".420", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0da0"
BB_0da0:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0e80_0f10", label %"BB_0db0"
BB_0db0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".423" = xor i32 0, -1
  %".424" = xor i32 %".389", -1
  %".425" = xor i32 0, -1
  %".426" = and i32 %".423", %".424"
  %".427" = and i32 %".426", %".425"
  %".428" = and i32 %".423", %".424"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".424"
  %".432" = and i32 %".431", %".425"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 0, %".424"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".436"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".437" = xor i32 %".436", -1
  %".438" = call i32 @"llvm.cttz.i32"(i32 %".437", i1 0)
  %".439" = shl i32 %".438", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".439") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e50", label %"BB_0ec0"
BB_80000e50:
  %"atoms_shared_addr_winoff.1" = and i32 %".348", 16777215
  %".443" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".443" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_0ec0"
BB_0e80_0f10:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0eb0_0f70:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0ec0:
  ret void
BB_80000c40:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P13_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P13_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R21:R131_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R21:R131_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P21_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P6_to_i32", %"BB_00a0"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P25_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P39_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P39_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P2_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P28_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_0f40"
BB_0560_0f40:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.10" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.10", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R67:R33_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R67:R33_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R67:R33_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R67:R33_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R67:R33_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R67:R33_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R67:R33_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R67:R33_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R67:R33_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R67:R33_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R67:R33_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R67:R33_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R67:R33_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R67:R33_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R67:R33_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R67:R33_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R67:R33_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0840"
BB_0840:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_09e0", label %"BB_0850"
BB_0850:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".196" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".185" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".201" = xor i32 %"plop3_a_bit.2", 1
  %".202" = xor i32 %"plop3_b_bit.2", 1
  %".203" = xor i32 %"plop3_c_bit.2", 1
  %".204" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".205" = and i32 %".204", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".205", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".206" = xor i32 %"shf_result.4", -1
  %".207" = xor i32 16376, -1
  %".208" = xor i32 0, -1
  %".209" = and i32 %"shf_result.4", 16376
  %".210" = and i32 %".209", %".208"
  %".211" = and i32 %"shf_result.4", 16376
  %".212" = and i32 %".211", 0
  %".213" = or i32 %".210", %".212"
  %".214" = xor i32 %".213", -1
  %".215" = xor i32 524288, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %".214", 524288
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %".214", 524288
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".213", %".215"
  %".223" = and i32 %".222", %".216"
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".213", %".215"
  %".226" = and i32 %".225", 0
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".213", 524288
  %".229" = and i32 %".228", %".216"
  %".230" = or i32 %".227", %".229"
  %".231" = and i32 %".213", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"lds.2", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.2", 20
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0910"
BB_0910:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0850"], [%"P20_to_i32", %"BB_0940"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_0850"], [%"phi.14", %"BB_0940"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000910"], [%"phi.11", %"BB_0910"]
  %"mma_b_r0_ext" = zext i32 %".233" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".237" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".238" = sub i64 %".237", 0
  %".239" = lshr i64 %".238", 4
  %".240" = add i64 %"mma_b_packed_1", %".239"
  %".241" = and i64 %".240", 16383
  %".242" = and i64 %"mma_b_packed_1", -16384
  %".243" = or i64 %".242", %".241"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".243", i32 679744944, i32 %"mma_arg_zext", i32 %"iadd3_n2.2", i32 %"iadd3_n2.3")
  br label %"BB_0930"
BB_0930:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000930", label %"BB_0940"
BB_80000930:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".247" = xor i32 %"plop3_a_bit.3", 1
  %".248" = xor i32 %"plop3_b_bit.3", 1
  %".249" = xor i32 %"plop3_c_bit.3", 1
  %".250" = and i32 %".247", %"plop3_b_bit.3"
  %".251" = and i32 %".250", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".251", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.14" = phi  i32 [%"P31_to_i32", %"BB_80000930"], [%"phi.12", %"BB_0930"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".253" = xor i32 %"plop3_a_bit.4", 1
  %".254" = xor i32 %"plop3_b_bit.4", 1
  %".255" = xor i32 %"plop3_c_bit.4", 1
  %".256" = and i32 %".253", %"plop3_b_bit.4"
  %".257" = and i32 %".256", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".257", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0910", label %"BB_0960"
BB_0960:
  %"iadd3_n1.4" = add i32 1024, 1024
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".259" = xor i32 %"plop3_a_bit.5", 1
  %".260" = xor i32 %"plop3_b_bit.5", 1
  %".261" = xor i32 %"plop3_c_bit.5", 1
  %".262" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".263" = and i32 %".262", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".263", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".264" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".265" = zext i32 %"iadd3_n2.4" to i64
  %".266" = zext i32 24 to i64
  %".267" = shl i64 %".264", %".266"
  %".268" = and i64 %".267", 4294967295
  %".269" = add i64 %".268", %".265"
  %".270" = trunc i64 %".269" to i32
  br label %"BB_0990"
BB_0990:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0960"], [%"P11_to_i32", %"BB_09c0"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0960"], [%"phi.18", %"BB_09c0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P8_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_80000990"], [%"phi.15", %"BB_0990"]
  %"utcbar_local_winoff" = and i32 %".270", 16777215
  %".274" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".275" = ptrtoint i8 addrspace(3)* %".274" to i32
  %".276" = lshr i32 %".270", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".275", i32 %".276")
  br label %"BB_09b0"
BB_09b0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".280" = xor i32 %"plop3_a_bit.6", 1
  %".281" = xor i32 %"plop3_b_bit.6", 1
  %".282" = xor i32 %"plop3_c_bit.6", 1
  %".283" = and i32 %".280", %"plop3_b_bit.6"
  %".284" = and i32 %".283", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".284", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_800009b0"], [%"phi.16", %"BB_09b0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".286" = xor i32 %"plop3_a_bit.7", 1
  %".287" = xor i32 %"plop3_b_bit.7", 1
  %".288" = xor i32 %"plop3_c_bit.7", 1
  %".289" = and i32 %".286", %"plop3_b_bit.7"
  %".290" = and i32 %".289", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".290", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_0990", label %"BB_09e0"
BB_09e0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %".292" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".293" = zext i32 %"iadd3_n2.5" to i64
  %".294" = zext i32 24 to i64
  %".295" = shl i64 %".292", %".294"
  %".296" = and i64 %".295", 4294967295
  %".297" = add i64 %".296", %".293"
  %".298" = trunc i64 %".297" to i32
  %"mbar_shared_winoff.1" = and i32 %".298", 16777215
  %".299" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.16" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0ee0", label %"BB_0a40"
BB_0ee0:
  %"mbar_shared_winoff.2" = and i32 %".298", 16777215
  %".302" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".302" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0ef0"
BB_0ef0:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0ee0", label %"BB_0a40"
BB_0a40:
  %".305" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".306" = bitcast i8* %".305" to i64*
  %"ldc_const.2" = load i64, i64* %".306"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".312" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".313" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".314" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R70:R44_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R70:R44_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R70:R44_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R70:R44_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R70:R44_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R70:R44_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R70:R44_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R70:R44_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R70:R44_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R70:R44_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".321" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".322" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".323" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R70:R44_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".312", i32 addrspace(1)* %"R70:R44_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R70:R44_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".313", i32 addrspace(1)* %"R70:R44_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R70:R44_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".314", i32 addrspace(1)* %"R70:R44_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".328" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".329" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".330" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R70:R44_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R70:R44_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R70:R44_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".321", i32 addrspace(1)* %"R70:R44_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R70:R44_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".322", i32 addrspace(1)* %"R70:R44_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R70:R44_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".323", i32 addrspace(1)* %"R70:R44_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R70:R44_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R70:R44_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R70:R44_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".328", i32 addrspace(1)* %"R70:R44_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R70:R44_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".329", i32 addrspace(1)* %"R70:R44_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R70:R44_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".330", i32 addrspace(1)* %"R70:R44_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000c40", label %"BB_0c50"
BB_0c50:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".341" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".341" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 3
  %".342" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".343" = zext i32 80 to i64
  %".344" = zext i32 24 to i64
  %".345" = shl i64 %".342", %".344"
  %".346" = and i64 %".345", 4294967295
  %".347" = add i64 %".346", %".343"
  %".348" = trunc i64 %".347" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.4" = and i32 %".348", 16777215
  %".349" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".349" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".350" = xor i32 %"lds.3", -1
  %".351" = xor i32 65535, -1
  %".352" = xor i32 0, -1
  %".353" = and i32 %"lds.3", 65535
  %".354" = and i32 %".353", %".352"
  %".355" = and i32 %"lds.3", 65535
  %".356" = and i32 %".355", 0
  %".357" = or i32 %".354", %".356"
  %".358" = zext i32 0 to i64
  %".359" = zext i32 %".357" to i64
  %".360" = shl i64 %".359", 32
  %"shf_concat.5" = or i64 %".358", %".360"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".361" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".361", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".362" = zext i32 %"imad.15" to i64
  %".363" = zext i32 0 to i64
  %".364" = shl i64 %".363", 32
  %"shf_concat.6" = or i64 %".362", %".364"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".365" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".365" to i32
  %".366" = zext i32 %"imad.16" to i64
  %".367" = zext i32 0 to i64
  %".368" = shl i64 %".367", 32
  %"shf_concat.7" = or i64 %".366", %".368"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".369" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".369" to i32
  %".370" = xor i32 %"shf_result.7", -1
  %".371" = xor i32 %"shf_result.6", -1
  %".372" = xor i32 0, -1
  %".373" = and i32 %".370", %"shf_result.6"
  %".374" = and i32 %".373", %".372"
  %".375" = and i32 %".370", %"shf_result.6"
  %".376" = and i32 %".375", 0
  %".377" = or i32 %".374", %".376"
  %".378" = and i32 %"shf_result.7", %".371"
  %".379" = and i32 %".378", %".372"
  %".380" = or i32 %".377", %".379"
  %".381" = and i32 %"shf_result.7", %".371"
  %".382" = and i32 %".381", 0
  %".383" = or i32 %".380", %".382"
  %".384" = and i32 %"shf_result.7", %"shf_result.6"
  %".385" = and i32 %".384", %".372"
  %".386" = or i32 %".383", %".385"
  %".387" = and i32 %"shf_result.7", %"shf_result.6"
  %".388" = and i32 %".387", 0
  %".389" = or i32 %".386", %".388"
  %".390" = xor i32 %".389", -1
  %".391" = xor i32 65535, -1
  %".392" = xor i32 0, -1
  %".393" = and i32 %".389", 65535
  %".394" = and i32 %".393", %".392"
  %".395" = and i32 %".389", 65535
  %".396" = and i32 %".395", 0
  %".397" = or i32 %".394", %".396"
  %".398" = xor i32 %".389", -1
  %".399" = xor i32 65535, -1
  %".400" = xor i32 %"lds.4", -1
  %".401" = and i32 %".389", 65535
  %".402" = and i32 %".401", %"lds.4"
  %"isetrp_cmp1.9" = icmp ne i32 %".402", %".397"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0d50"
BB_0d50:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0eb0_0f70", label %"BB_0d60"
BB_0d60:
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %"lds.4" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.8" = or i64 %".405", %".407"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".408" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".408", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".409" = zext i32 0 to i64
  %".410" = zext i32 %".389" to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.9" = or i64 %".409", %".411"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".412" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".412", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".413" = xor i32 %"shf_result.8", -1
  %".414" = xor i32 %"shf_result.9", -1
  %".415" = xor i32 0, -1
  %".416" = and i32 %"shf_result.8", %"shf_result.9"
  %".417" = and i32 %".416", %".415"
  %".418" = and i32 %"shf_result.8", %"shf_result.9"
  %".419" = and i32 %".418", 0
  %".420" = or i32 %".417", %".419"
  %"isetrp_cmp1.10" = icmp ne i32 %".420", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0da0"
BB_0da0:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0e80_0f10", label %"BB_0db0"
BB_0db0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".423" = xor i32 0, -1
  %".424" = xor i32 %".389", -1
  %".425" = xor i32 0, -1
  %".426" = and i32 %".423", %".424"
  %".427" = and i32 %".426", %".425"
  %".428" = and i32 %".423", %".424"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".424"
  %".432" = and i32 %".431", %".425"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 0, %".424"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".436"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".437" = xor i32 %".436", -1
  %".438" = call i32 @"llvm.cttz.i32"(i32 %".437", i1 0)
  %".439" = shl i32 %".438", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".439") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0e50"
BB_0e50:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000e50", label %"BB_0ec0"
BB_80000e50:
  %"atoms_shared_addr_winoff.1" = and i32 %".348", 16777215
  %".443" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".443" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_0ec0"
BB_0e80_0f10:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0eb0_0f70:
  call void @"llvm.trap"()
  br label %"BB_0ec0"
BB_0ec0:
  ret void
BB_80000c40:
  ret void
}

define void @"_Z13column_scaledIL4Case1EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P13_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P13_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R143:R100_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R143:R100_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P21_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P6_to_i32", %"BB_00a0"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P25_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P39_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P39_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P2_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P28_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_0e70"
BB_0560_0e70:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R109:R86_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R109:R86_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R109:R86_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R109:R86_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R109:R86_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R109:R86_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R109:R86_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R109:R86_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0790"
BB_0790:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0910", label %"BB_07a0"
BB_07a0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".193" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".193" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".194" = zext i32 0 to i64
  %".195" = zext i32 %".185" to i64
  %".196" = shl i64 %".195", 32
  %"shf_concat.4" = or i64 %".194", %".196"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".197" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".197", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".198" = xor i32 %"plop3_a_bit.2", 1
  %".199" = xor i32 %"plop3_b_bit.2", 1
  %".200" = xor i32 %"plop3_c_bit.2", 1
  %".201" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".202" = and i32 %".201", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".202", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".203" = xor i32 %"shf_result.4", -1
  %".204" = xor i32 16376, -1
  %".205" = xor i32 0, -1
  %".206" = and i32 %"shf_result.4", 16376
  %".207" = and i32 %".206", %".205"
  %".208" = and i32 %"shf_result.4", 16376
  %".209" = and i32 %".208", 0
  %".210" = or i32 %".207", %".209"
  %".211" = xor i32 %".210", -1
  %".212" = xor i32 524288, -1
  %".213" = xor i32 0, -1
  %".214" = and i32 %".211", 524288
  %".215" = and i32 %".214", %".213"
  %".216" = and i32 %".211", 524288
  %".217" = and i32 %".216", 0
  %".218" = or i32 %".215", %".217"
  %".219" = and i32 %".210", %".212"
  %".220" = and i32 %".219", %".213"
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".210", %".212"
  %".223" = and i32 %".222", 0
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".210", 524288
  %".226" = and i32 %".225", %".213"
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".210", 524288
  %".229" = and i32 %".228", 0
  %".230" = or i32 %".227", %".229"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_0840"
BB_0840:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_07a0"], [%"P20_to_i32", %"BB_0870"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_07a0"], [%"phi.14", %"BB_0870"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000840", label %"BB_0850"
BB_80000840:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0850"
BB_0850:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000840"], [%"phi.11", %"BB_0840"]
  %"mma_b_r0_ext" = zext i32 %".230" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".234" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".235" = sub i64 %".234", 0
  %".236" = lshr i64 %".235", 4
  %".237" = add i64 %"mma_b_packed_1", %".236"
  %".238" = and i64 %".237", 16383
  %".239" = and i64 %"mma_b_packed_1", -16384
  %".240" = or i64 %".239", %".238"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".240", i32 134484624, i32 %"mma_arg_zext")
  br label %"BB_0860"
BB_0860:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000860", label %"BB_0870"
BB_80000860:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".244" = xor i32 %"plop3_a_bit.3", 1
  %".245" = xor i32 %"plop3_b_bit.3", 1
  %".246" = xor i32 %"plop3_c_bit.3", 1
  %".247" = and i32 %".244", %"plop3_b_bit.3"
  %".248" = and i32 %".247", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".248", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.14" = phi  i32 [%"P31_to_i32", %"BB_80000860"], [%"phi.12", %"BB_0860"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".250" = xor i32 %"plop3_a_bit.4", 1
  %".251" = xor i32 %"plop3_b_bit.4", 1
  %".252" = xor i32 %"plop3_c_bit.4", 1
  %".253" = and i32 %".250", %"plop3_b_bit.4"
  %".254" = and i32 %".253", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".254", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0840", label %"BB_0890"
BB_0890:
  %"iadd3_n1.2" = add i32 1024, 1024
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".256" = xor i32 %"plop3_a_bit.5", 1
  %".257" = xor i32 %"plop3_b_bit.5", 1
  %".258" = xor i32 %"plop3_c_bit.5", 1
  %".259" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".260" = and i32 %".259", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".260", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".261" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".262" = zext i32 %"iadd3_n2.2" to i64
  %".263" = zext i32 24 to i64
  %".264" = shl i64 %".261", %".263"
  %".265" = and i64 %".264", 4294967295
  %".266" = add i64 %".265", %".262"
  %".267" = trunc i64 %".266" to i32
  br label %"BB_08c0"
BB_08c0:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0890"], [%"P11_to_i32", %"BB_08f0"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0890"], [%"phi.18", %"BB_08f0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800008c0", label %"BB_08d0"
BB_800008c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P8_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_08d0"
BB_08d0:
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_800008c0"], [%"phi.15", %"BB_08c0"]
  %"utcbar_local_winoff" = and i32 %".267", 16777215
  %".271" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".272" = ptrtoint i8 addrspace(3)* %".271" to i32
  %".273" = lshr i32 %".267", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".272", i32 %".273")
  br label %"BB_08e0"
BB_08e0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800008e0", label %"BB_08f0"
BB_800008e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".277" = xor i32 %"plop3_a_bit.6", 1
  %".278" = xor i32 %"plop3_b_bit.6", 1
  %".279" = xor i32 %"plop3_c_bit.6", 1
  %".280" = and i32 %".277", %"plop3_b_bit.6"
  %".281" = and i32 %".280", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".281", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_08f0"
BB_08f0:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_800008e0"], [%"phi.16", %"BB_08e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".283" = xor i32 %"plop3_a_bit.7", 1
  %".284" = xor i32 %"plop3_b_bit.7", 1
  %".285" = xor i32 %"plop3_c_bit.7", 1
  %".286" = and i32 %".283", %"plop3_b_bit.7"
  %".287" = and i32 %".286", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".287", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_08c0", label %"BB_0910"
BB_0910:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".289" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".290" = zext i32 %"iadd3_n2.3" to i64
  %".291" = zext i32 24 to i64
  %".292" = shl i64 %".289", %".291"
  %".293" = and i64 %".292", 4294967295
  %".294" = add i64 %".293", %".290"
  %".295" = trunc i64 %".294" to i32
  %"mbar_shared_winoff.1" = and i32 %".295", 16777215
  %".296" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".296" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.16" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0e10", label %"BB_0970"
BB_0e10:
  %"mbar_shared_winoff.2" = and i32 %".295", 16777215
  %".299" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0e20"
BB_0e20:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0e10", label %"BB_0970"
BB_0970:
  %".302" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".303" = bitcast i8* %".302" to i64*
  %"ldc_const.2" = load i64, i64* %".303"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R111:R91_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R111:R91_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R111:R91_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R111:R91_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R111:R91_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R111:R91_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R111:R91_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R111:R91_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R111:R91_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R111:R91_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".317" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".318" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".319" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R111:R91_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R111:R91_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R111:R91_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R111:R91_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R111:R91_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R111:R91_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R111:R91_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".317", i32 addrspace(1)* %"R111:R91_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R111:R91_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".318", i32 addrspace(1)* %"R111:R91_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R111:R91_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".319", i32 addrspace(1)* %"R111:R91_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R111:R91_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R111:R91_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R111:R91_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R111:R91_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R111:R91_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R111:R91_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R111:R91_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R111:R91_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R111:R91_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R111:R91_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b70"
BB_0b70:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000b70", label %"BB_0b80"
BB_0b80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".338" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".338" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 3
  %".339" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".340" = zext i32 80 to i64
  %".341" = zext i32 24 to i64
  %".342" = shl i64 %".339", %".341"
  %".343" = and i64 %".342", 4294967295
  %".344" = add i64 %".343", %".340"
  %".345" = trunc i64 %".344" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.4" = and i32 %".345", 16777215
  %".346" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".346" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".347" = xor i32 %"lds.3", -1
  %".348" = xor i32 65535, -1
  %".349" = xor i32 0, -1
  %".350" = and i32 %"lds.3", 65535
  %".351" = and i32 %".350", %".349"
  %".352" = and i32 %"lds.3", 65535
  %".353" = and i32 %".352", 0
  %".354" = or i32 %".351", %".353"
  %".355" = zext i32 0 to i64
  %".356" = zext i32 %".354" to i64
  %".357" = shl i64 %".356", 32
  %"shf_concat.5" = or i64 %".355", %".357"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".358" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".358", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".359" = zext i32 %"imad.15" to i64
  %".360" = zext i32 0 to i64
  %".361" = shl i64 %".360", 32
  %"shf_concat.6" = or i64 %".359", %".361"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".362" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".362" to i32
  %".363" = zext i32 %"imad.16" to i64
  %".364" = zext i32 0 to i64
  %".365" = shl i64 %".364", 32
  %"shf_concat.7" = or i64 %".363", %".365"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".366" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".366" to i32
  %".367" = xor i32 %"shf_result.7", -1
  %".368" = xor i32 %"shf_result.6", -1
  %".369" = xor i32 0, -1
  %".370" = and i32 %".367", %"shf_result.6"
  %".371" = and i32 %".370", %".369"
  %".372" = and i32 %".367", %"shf_result.6"
  %".373" = and i32 %".372", 0
  %".374" = or i32 %".371", %".373"
  %".375" = and i32 %"shf_result.7", %".368"
  %".376" = and i32 %".375", %".369"
  %".377" = or i32 %".374", %".376"
  %".378" = and i32 %"shf_result.7", %".368"
  %".379" = and i32 %".378", 0
  %".380" = or i32 %".377", %".379"
  %".381" = and i32 %"shf_result.7", %"shf_result.6"
  %".382" = and i32 %".381", %".369"
  %".383" = or i32 %".380", %".382"
  %".384" = and i32 %"shf_result.7", %"shf_result.6"
  %".385" = and i32 %".384", 0
  %".386" = or i32 %".383", %".385"
  %".387" = xor i32 %".386", -1
  %".388" = xor i32 65535, -1
  %".389" = xor i32 0, -1
  %".390" = and i32 %".386", 65535
  %".391" = and i32 %".390", %".389"
  %".392" = and i32 %".386", 65535
  %".393" = and i32 %".392", 0
  %".394" = or i32 %".391", %".393"
  %".395" = xor i32 %".386", -1
  %".396" = xor i32 65535, -1
  %".397" = xor i32 %"lds.4", -1
  %".398" = and i32 %".386", 65535
  %".399" = and i32 %".398", %"lds.4"
  %"isetrp_cmp1.9" = icmp ne i32 %".399", %".394"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0c80"
BB_0c80:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0de0_0ea0", label %"BB_0c90"
BB_0c90:
  %".402" = zext i32 0 to i64
  %".403" = zext i32 %"lds.4" to i64
  %".404" = shl i64 %".403", 32
  %"shf_concat.8" = or i64 %".402", %".404"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".405" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".405", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".406" = zext i32 0 to i64
  %".407" = zext i32 %".386" to i64
  %".408" = shl i64 %".407", 32
  %"shf_concat.9" = or i64 %".406", %".408"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".409" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".409", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".410" = xor i32 %"shf_result.8", -1
  %".411" = xor i32 %"shf_result.9", -1
  %".412" = xor i32 0, -1
  %".413" = and i32 %"shf_result.8", %"shf_result.9"
  %".414" = and i32 %".413", %".412"
  %".415" = and i32 %"shf_result.8", %"shf_result.9"
  %".416" = and i32 %".415", 0
  %".417" = or i32 %".414", %".416"
  %"isetrp_cmp1.10" = icmp ne i32 %".417", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0cd0"
BB_0cd0:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0db0_0e40", label %"BB_0ce0"
BB_0ce0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".420" = xor i32 0, -1
  %".421" = xor i32 %".386", -1
  %".422" = xor i32 0, -1
  %".423" = and i32 %".420", %".421"
  %".424" = and i32 %".423", %".422"
  %".425" = and i32 %".420", %".421"
  %".426" = and i32 %".425", 0
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 0, %".421"
  %".429" = and i32 %".428", %".422"
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".421"
  %".432" = and i32 %".431", 0
  %".433" = or i32 %".430", %".432"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".433"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".434" = xor i32 %".433", -1
  %".435" = call i32 @"llvm.cttz.i32"(i32 %".434", i1 0)
  %".436" = shl i32 %".435", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".436") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0d80"
BB_0d80:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000d80", label %"BB_0df0"
BB_80000d80:
  %"atoms_shared_addr_winoff.1" = and i32 %".345", 16777215
  %".440" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".440" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_0df0"
BB_0db0_0e40:
  call void @"llvm.trap"()
  br label %"BB_0df0"
BB_0de0_0ea0:
  call void @"llvm.trap"()
  br label %"BB_0df0"
BB_0df0:
  ret void
BB_80000b70:
  ret void
}

define void @"_Z13column_scaledIL4Case0EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P13_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P13_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R143:R100_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R143:R100_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P14_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P21_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P21_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P14_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P6_to_i32", %"BB_00a0"], [%"P14_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P24_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P24_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P25_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P25_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P37_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P37_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P39_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P39_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 3
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P26_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P26_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P2_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P2_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P3_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P3_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P28_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P28_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_0e70"
BB_0560_0e70:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.10" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.10", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R109:R86_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R109:R86_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R109:R86_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R109:R86_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R109:R86_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R109:R86_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R109:R86_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R109:R86_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R109:R86_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0790"
BB_0790:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0910", label %"BB_07a0"
BB_07a0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".193" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".193" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".194" = zext i32 0 to i64
  %".195" = zext i32 %".185" to i64
  %".196" = shl i64 %".195", 32
  %"shf_concat.4" = or i64 %".194", %".196"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".197" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".197", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".198" = xor i32 %"plop3_a_bit.2", 1
  %".199" = xor i32 %"plop3_b_bit.2", 1
  %".200" = xor i32 %"plop3_c_bit.2", 1
  %".201" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".202" = and i32 %".201", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".202", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".203" = xor i32 %"shf_result.4", -1
  %".204" = xor i32 16376, -1
  %".205" = xor i32 0, -1
  %".206" = and i32 %"shf_result.4", 16376
  %".207" = and i32 %".206", %".205"
  %".208" = and i32 %"shf_result.4", 16376
  %".209" = and i32 %".208", 0
  %".210" = or i32 %".207", %".209"
  %".211" = xor i32 %".210", -1
  %".212" = xor i32 524288, -1
  %".213" = xor i32 0, -1
  %".214" = and i32 %".211", 524288
  %".215" = and i32 %".214", %".213"
  %".216" = and i32 %".211", 524288
  %".217" = and i32 %".216", 0
  %".218" = or i32 %".215", %".217"
  %".219" = and i32 %".210", %".212"
  %".220" = and i32 %".219", %".213"
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".210", %".212"
  %".223" = and i32 %".222", 0
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".210", 524288
  %".226" = and i32 %".225", %".213"
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".210", 524288
  %".229" = and i32 %".228", 0
  %".230" = or i32 %".227", %".229"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_0840"
BB_0840:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_07a0"], [%"P20_to_i32", %"BB_0870"]
  %"phi.12" = phi  i32 [%"P29_to_i32", %"BB_07a0"], [%"phi.14", %"BB_0870"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000840", label %"BB_0850"
BB_80000840:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P17_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0850"
BB_0850:
  %"phi.13" = phi  i32 [%"P17_to_i32", %"BB_80000840"], [%"phi.11", %"BB_0840"]
  %"mma_b_r0_ext" = zext i32 %".230" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".234" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".235" = sub i64 %".234", 0
  %".236" = lshr i64 %".235", 4
  %".237" = add i64 %"mma_b_packed_1", %".236"
  %".238" = and i64 %".237", 16383
  %".239" = and i64 %"mma_b_packed_1", -16384
  %".240" = or i64 %".239", %".238"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::f8f6f4 [$0], [$1], $2, $3, use_d; } }", "r,r,l,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".240", i32 134485392, i32 %"mma_arg_zext")
  br label %"BB_0860"
BB_0860:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000860", label %"BB_0870"
BB_80000860:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".244" = xor i32 %"plop3_a_bit.3", 1
  %".245" = xor i32 %"plop3_b_bit.3", 1
  %".246" = xor i32 %"plop3_c_bit.3", 1
  %".247" = and i32 %".244", %"plop3_b_bit.3"
  %".248" = and i32 %".247", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".248", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0870"
BB_0870:
  %"phi.14" = phi  i32 [%"P31_to_i32", %"BB_80000860"], [%"phi.12", %"BB_0860"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".250" = xor i32 %"plop3_a_bit.4", 1
  %".251" = xor i32 %"plop3_b_bit.4", 1
  %".252" = xor i32 %"plop3_c_bit.4", 1
  %".253" = and i32 %".250", %"plop3_b_bit.4"
  %".254" = and i32 %".253", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".254", 0
  %"P20_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0840", label %"BB_0890"
BB_0890:
  %"iadd3_n1.2" = add i32 1024, 1024
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".256" = xor i32 %"plop3_a_bit.5", 1
  %".257" = xor i32 %"plop3_b_bit.5", 1
  %".258" = xor i32 %"plop3_c_bit.5", 1
  %".259" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".260" = and i32 %".259", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".260", 0
  %"P40_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".261" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".262" = zext i32 %"iadd3_n2.2" to i64
  %".263" = zext i32 24 to i64
  %".264" = shl i64 %".261", %".263"
  %".265" = and i64 %".264", 4294967295
  %".266" = add i64 %".265", %".262"
  %".267" = trunc i64 %".266" to i32
  br label %"BB_08c0"
BB_08c0:
  %"phi.15" = phi  i32 [%"P20_to_i32", %"BB_0890"], [%"P11_to_i32", %"BB_08f0"]
  %"phi.16" = phi  i32 [%"P40_to_i32", %"BB_0890"], [%"phi.18", %"BB_08f0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800008c0", label %"BB_08d0"
BB_800008c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P8_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_08d0"
BB_08d0:
  %"phi.17" = phi  i32 [%"P8_to_i32", %"BB_800008c0"], [%"phi.15", %"BB_08c0"]
  %"utcbar_local_winoff" = and i32 %".267", 16777215
  %".271" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".272" = ptrtoint i8 addrspace(3)* %".271" to i32
  %".273" = lshr i32 %".267", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".272", i32 %".273")
  br label %"BB_08e0"
BB_08e0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800008e0", label %"BB_08f0"
BB_800008e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".277" = xor i32 %"plop3_a_bit.6", 1
  %".278" = xor i32 %"plop3_b_bit.6", 1
  %".279" = xor i32 %"plop3_c_bit.6", 1
  %".280" = and i32 %".277", %"plop3_b_bit.6"
  %".281" = and i32 %".280", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".281", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_08f0"
BB_08f0:
  %"phi.18" = phi  i32 [%"P27_to_i32", %"BB_800008e0"], [%"phi.16", %"BB_08e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".283" = xor i32 %"plop3_a_bit.7", 1
  %".284" = xor i32 %"plop3_b_bit.7", 1
  %".285" = xor i32 %"plop3_c_bit.7", 1
  %".286" = and i32 %".283", %"plop3_b_bit.7"
  %".287" = and i32 %".286", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".287", 0
  %"P11_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_08c0", label %"BB_0910"
BB_0910:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.3" = add i32 1024, 1024
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %".289" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".290" = zext i32 %"iadd3_n2.3" to i64
  %".291" = zext i32 24 to i64
  %".292" = shl i64 %".289", %".291"
  %".293" = and i64 %".292", 4294967295
  %".294" = add i64 %".293", %".290"
  %".295" = trunc i64 %".294" to i32
  %"mbar_shared_winoff.1" = and i32 %".295", 16777215
  %".296" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".296" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P35_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0960"
BB_0960:
  %"cond_trunc.16" = trunc i32 %"P35_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_0e10", label %"BB_0970"
BB_0e10:
  %"mbar_shared_winoff.2" = and i32 %".295", 16777215
  %".299" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".299" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P12_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0e20"
BB_0e20:
  %"cond_trunc.17" = trunc i32 %"P12_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0e10", label %"BB_0970"
BB_0970:
  %".302" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".303" = bitcast i8* %".302" to i64*
  %"ldc_const.2" = load i64, i64* %".303"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 16
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".304" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".305" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".306" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".307" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".308" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".309" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".310" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".311" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.14" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.14", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R111:R91_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".304", i32 addrspace(1)* %"R111:R91_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R111:R91_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".305", i32 addrspace(1)* %"R111:R91_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R111:R91_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".306", i32 addrspace(1)* %"R111:R91_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R111:R91_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".307", i32 addrspace(1)* %"R111:R91_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R111:R91_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".308", i32 addrspace(1)* %"R111:R91_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".317" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".318" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".319" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".320" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R111:R91_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".309", i32 addrspace(1)* %"R111:R91_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R111:R91_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".310", i32 addrspace(1)* %"R111:R91_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R111:R91_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".311", i32 addrspace(1)* %"R111:R91_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".324" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".325" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".326" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".327" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R111:R91_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".317", i32 addrspace(1)* %"R111:R91_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R111:R91_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".318", i32 addrspace(1)* %"R111:R91_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R111:R91_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".319", i32 addrspace(1)* %"R111:R91_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R111:R91_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".320", i32 addrspace(1)* %"R111:R91_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R111:R91_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".324", i32 addrspace(1)* %"R111:R91_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R111:R91_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".325", i32 addrspace(1)* %"R111:R91_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R111:R91_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".326", i32 addrspace(1)* %"R111:R91_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R111:R91_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".327", i32 addrspace(1)* %"R111:R91_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0b70"
BB_0b70:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_80000b70", label %"BB_0b80"
BB_0b80:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".338" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".338" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 3
  %".339" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".340" = zext i32 80 to i64
  %".341" = zext i32 24 to i64
  %".342" = shl i64 %".339", %".341"
  %".343" = and i64 %".342", 4294967295
  %".344" = add i64 %".343", %".340"
  %".345" = trunc i64 %".344" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.4" = and i32 %".345", 16777215
  %".346" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".346" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".347" = xor i32 %"lds.3", -1
  %".348" = xor i32 65535, -1
  %".349" = xor i32 0, -1
  %".350" = and i32 %"lds.3", 65535
  %".351" = and i32 %".350", %".349"
  %".352" = and i32 %"lds.3", 65535
  %".353" = and i32 %".352", 0
  %".354" = or i32 %".351", %".353"
  %".355" = zext i32 0 to i64
  %".356" = zext i32 %".354" to i64
  %".357" = shl i64 %".356", 32
  %"shf_concat.5" = or i64 %".355", %".357"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".358" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".358", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".359" = zext i32 %"imad.15" to i64
  %".360" = zext i32 0 to i64
  %".361" = shl i64 %".360", 32
  %"shf_concat.6" = or i64 %".359", %".361"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".362" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".362" to i32
  %".363" = zext i32 %"imad.16" to i64
  %".364" = zext i32 0 to i64
  %".365" = shl i64 %".364", 32
  %"shf_concat.7" = or i64 %".363", %".365"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".366" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".366" to i32
  %".367" = xor i32 %"shf_result.7", -1
  %".368" = xor i32 %"shf_result.6", -1
  %".369" = xor i32 0, -1
  %".370" = and i32 %".367", %"shf_result.6"
  %".371" = and i32 %".370", %".369"
  %".372" = and i32 %".367", %"shf_result.6"
  %".373" = and i32 %".372", 0
  %".374" = or i32 %".371", %".373"
  %".375" = and i32 %"shf_result.7", %".368"
  %".376" = and i32 %".375", %".369"
  %".377" = or i32 %".374", %".376"
  %".378" = and i32 %"shf_result.7", %".368"
  %".379" = and i32 %".378", 0
  %".380" = or i32 %".377", %".379"
  %".381" = and i32 %"shf_result.7", %"shf_result.6"
  %".382" = and i32 %".381", %".369"
  %".383" = or i32 %".380", %".382"
  %".384" = and i32 %"shf_result.7", %"shf_result.6"
  %".385" = and i32 %".384", 0
  %".386" = or i32 %".383", %".385"
  %".387" = xor i32 %".386", -1
  %".388" = xor i32 65535, -1
  %".389" = xor i32 0, -1
  %".390" = and i32 %".386", 65535
  %".391" = and i32 %".390", %".389"
  %".392" = and i32 %".386", 65535
  %".393" = and i32 %".392", 0
  %".394" = or i32 %".391", %".393"
  %".395" = xor i32 %".386", -1
  %".396" = xor i32 65535, -1
  %".397" = xor i32 %"lds.4", -1
  %".398" = and i32 %".386", 65535
  %".399" = and i32 %".398", %"lds.4"
  %"isetrp_cmp1.9" = icmp ne i32 %".399", %".394"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0c80"
BB_0c80:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_0de0_0ea0", label %"BB_0c90"
BB_0c90:
  %".402" = zext i32 0 to i64
  %".403" = zext i32 %"lds.4" to i64
  %".404" = shl i64 %".403", 32
  %"shf_concat.8" = or i64 %".402", %".404"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".405" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".405", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".406" = zext i32 0 to i64
  %".407" = zext i32 %".386" to i64
  %".408" = shl i64 %".407", 32
  %"shf_concat.9" = or i64 %".406", %".408"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".409" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".409", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".410" = xor i32 %"shf_result.8", -1
  %".411" = xor i32 %"shf_result.9", -1
  %".412" = xor i32 0, -1
  %".413" = and i32 %"shf_result.8", %"shf_result.9"
  %".414" = and i32 %".413", %".412"
  %".415" = and i32 %"shf_result.8", %"shf_result.9"
  %".416" = and i32 %".415", 0
  %".417" = or i32 %".414", %".416"
  %"isetrp_cmp1.10" = icmp ne i32 %".417", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P36_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0cd0"
BB_0cd0:
  %"cond_trunc.20" = trunc i32 %"P36_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0db0_0e40", label %"BB_0ce0"
BB_0ce0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".420" = xor i32 0, -1
  %".421" = xor i32 %".386", -1
  %".422" = xor i32 0, -1
  %".423" = and i32 %".420", %".421"
  %".424" = and i32 %".423", %".422"
  %".425" = and i32 %".420", %".421"
  %".426" = and i32 %".425", 0
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 0, %".421"
  %".429" = and i32 %".428", %".422"
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 0, %".421"
  %".432" = and i32 %".431", 0
  %".433" = or i32 %".430", %".432"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".433"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".434" = xor i32 %".433", -1
  %".435" = call i32 @"llvm.cttz.i32"(i32 %".434", i1 0)
  %".436" = shl i32 %".435", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".436") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P38_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0d80"
BB_0d80:
  %"cond_trunc.21" = trunc i32 %"P38_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_80000d80", label %"BB_0df0"
BB_80000d80:
  %"atoms_shared_addr_winoff.1" = and i32 %".345", 16777215
  %".440" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".440" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_0df0"
BB_0db0_0e40:
  call void @"llvm.trap"()
  br label %"BB_0df0"
BB_0de0_0ea0:
  call void @"llvm.trap"()
  br label %"BB_0df0"
BB_0df0:
  ret void
BB_80000b70:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4, !5, !6, !7 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case6EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case5EEvPKjPj", !"kernel", i32 1 }
!3 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case4EEvPKjPj", !"kernel", i32 1 }
!4 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!5 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
!6 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case1EEvPKjPj", !"kernel", i32 1 }
!7 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case0EEvPKjPj", !"kernel", i32 1 }
