; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../p2a/ir/p0/g32.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../p2a/ir/p0/g32.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [8192 x i8], align 16
@const_mem = global [5 x [1088 x i8]] zeroinitializer, align 16

define void @sm80_xmma_gemm_f16f16_f16f32_f32_tn_n_tilesize32x32x64_stage6_warpsize2x2x1_tensor16x8x16_execute_kernel__5x_cublas([736 x i8] %arg_352) #0 {
EntryBB_0000:
  %lo.frag = alloca [32 x float], align 4
  %p2c.q134 = alloca [16 x i64], align 8
  store i64 0, ptr %p2c.q134, align 8
  %0 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 8
  store i64 0, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 16
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 24
  store i64 0, ptr %2, align 8
  %3 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 32
  store i64 0, ptr %3, align 8
  %4 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 40
  store i64 0, ptr %4, align 8
  %5 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 48
  store i64 0, ptr %5, align 8
  %6 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 56
  store i64 0, ptr %6, align 8
  %7 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 64
  store i64 0, ptr %7, align 8
  %8 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 72
  store i64 0, ptr %8, align 8
  %9 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 80
  store i64 0, ptr %9, align 8
  %10 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 88
  store i64 0, ptr %10, align 8
  %11 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 96
  store i64 0, ptr %11, align 8
  %12 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 104
  store i64 0, ptr %12, align 8
  %13 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 112
  store i64 0, ptr %13, align 8
  %14 = getelementptr inbounds nuw i8, ptr %p2c.q134, i64 120
  store i64 0, ptr %14, align 8
  %param_local = alloca [1088 x i8], align 16
  %.3 = getelementptr inbounds nuw i8, ptr %param_local, i64 352
  store [736 x i8] %arg_352, ptr %.3, align 32
  %s2ur_ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %.8 = getelementptr inbounds nuw i8, ptr %param_local, i64 868
  %isetrp_rhs.1 = load i32, ptr %.8, align 4
  %isetrp_cmp1.1.not = icmp eq i32 %isetrp_rhs.1, 0
  %s2ur_ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %.6 = getelementptr inbounds nuw i8, ptr %param_local, i64 848
  %isetrp_rhs = load i32, ptr %.6, align 4
  %isetrp_cmp1.not = icmp eq i32 %isetrp_rhs, 0
  br i1 %isetrp_cmp1.not, label %BB_0320, label %BB_0090

BB_0090:                                          ; preds = %EntryBB_0000
  %.12 = getelementptr inbounds nuw i8, ptr %param_local, i64 988
  %imad_addend = load i32, ptr %.12, align 4
  %.14 = getelementptr inbounds nuw i8, ptr %param_local, i64 860
  %shf_shift = load i32, ptr %.14, align 4
  %shf_shift_64 = zext i32 %shf_shift to i64
  %.19 = shl i64 4294967295, %shf_shift_64
  %shf_result = trunc i64 %.19 to i32
  %.20 = getelementptr inbounds nuw i8, ptr %param_local, i64 984
  %sel_false = load i32, ptr %.20, align 4
  %sel = select i1 %isetrp_cmp1.1.not, i32 %imad_addend, i32 %sel_false
  %.23 = xor i32 %shf_result, -1
  %.38 = or i32 %s2ur_ctaid_y, %.23
  %.47 = shl nuw i64 1, %shf_shift_64
  %shf_result.1 = trunc i64 %.47 to i32
  %.51 = and i32 %s2ur_ctaid_y, %shf_result.1
  %lop3_pred_cmp.not = icmp ne i32 %.51, 0
  %sel.1 = select i1 %isetrp_cmp1.1.not, i32 %sel_false, i32 %imad_addend
  %sel.2 = zext i1 %lop3_pred_cmp.not to i32
  %isetrp_cmp1.2.not = icmp ult i32 %.38, %sel
  br i1 %isetrp_cmp1.2.not, label %BB_0240, label %BB_0180.preheader

BB_0180.preheader:                                ; preds = %BB_0090
  br label %BB_0180

BB_0180:                                          ; preds = %BB_0180.preheader, %BB_01b0
  %phi = phi i32 [ %iadd3_n1, %BB_01b0 ], [ %shf_shift, %BB_0180.preheader ]
  %phi.1 = phi i32 [ %15, %BB_01b0 ], [ %.23, %BB_0180.preheader ]
  %phi.2 = phi i32 [ %phi.4, %BB_01b0 ], [ %sel.2, %BB_0180.preheader ]
  %phi.3 = phi i32 [ %.112, %BB_01b0 ], [ %.38, %BB_0180.preheader ]
  %isetrp_cmp1.4 = icmp ne i32 %phi, 2
  %isetrp_cmp1.3.not = icmp ne i32 %phi.3, %sel
  %brmerge = or i1 %isetrp_cmp1.3.not, %isetrp_cmp1.4
  br i1 %brmerge, label %BB_01b0, label %BB_0290

BB_01b0:                                          ; preds = %BB_0180
  %iadd3_n1 = add i32 %phi, -1
  %15 = lshr i32 %phi.1, 1
  %.112 = or i32 %s2ur_ctaid_y, %15
  %isetrp_cmp1.6.not = icmp ult i32 %.112, %sel
  %shf_shift_64.3 = zext nneg i32 %iadd3_n1 to i64
  %.87 = shl nuw i64 1, %shf_shift_64.3
  %shf_result.3 = trunc i64 %.87 to i32
  %.91 = and i32 %s2ur_ctaid_y, %shf_result.3
  %lop3_pred_cmp.1.not = icmp ne i32 %.91, 0
  %sel.3 = zext i1 %lop3_pred_cmp.1.not to i32
  %phi.4 = xor i32 %phi.2, %sel.3
  br i1 %isetrp_cmp1.6.not, label %BB_0240.loopexit, label %BB_0180

BB_0290:                                          ; preds = %BB_0180
  %.123 = and i32 %phi.1, %s2ur_ctaid_y
  %.129 = xor i32 %phi.1, -1
  %.131 = and i32 %s2ur_ctaid_y, %.129
  %imad_tmp.6 = mul i32 %.123, %sel.1
  %imad.6 = add i32 %imad_tmp.6, %s2ur_ctaid_x
  %imad_lhs_64 = zext i32 %imad.6 to i64
  %imad_tmp_64 = mul nuw nsw i64 %imad_lhs_64, 1431655766
  %"R7:R6_r1_shift" = lshr i64 %imad_tmp_64, 32
  %"R7:R6_r1" = trunc nuw nsw i64 %"R7:R6_r1_shift" to i32
  %iadd3_n1.1 = add i32 %imad.6, %.131
  %imad_tmp.7 = mul i32 %"R7:R6_r1", -3
  %imad.8 = add i32 %imad_tmp.7, %iadd3_n1.1
  br label %BB_02f0

BB_0240.loopexit:                                 ; preds = %BB_01b0
  br label %BB_0240

BB_0240:                                          ; preds = %BB_0240.loopexit, %BB_0090
  %phi.5 = phi i32 [ %shf_shift, %BB_0090 ], [ %iadd3_n1, %BB_0240.loopexit ]
  %phi.6 = phi i32 [ %.23, %BB_0090 ], [ %15, %BB_0240.loopexit ]
  %phi.7 = phi i32 [ %sel.2, %BB_0090 ], [ %phi.4, %BB_0240.loopexit ]
  %.140 = and i32 %phi.6, %s2ur_ctaid_y
  %imad_tmp.8 = mul i32 %.140, %sel.1
  %imad.9 = add i32 %imad_tmp.8, %s2ur_ctaid_x
  %.146 = xor i32 %phi.6, -1
  %.150 = and i32 %s2ur_ctaid_y, %.146
  %16 = and i32 %phi.6, %imad.9
  %.158 = or i32 %16, %.150
  %.160 = zext i32 %imad.9 to i64
  %.161 = shl nuw i64 %.160, 32
  %shf_shift_64.4 = zext nneg i32 %phi.5 to i64
  %.162 = lshr i64 %.161, %shf_shift_64.4
  %shf_hi.1 = lshr i64 %.162, 32
  %shf_result.4 = trunc nuw i64 %shf_hi.1 to i32
  br label %BB_02f0

BB_02f0:                                          ; preds = %BB_0240, %BB_0290
  %phi.8 = phi i32 [ %shf_result.4, %BB_0240 ], [ %"R7:R6_r1", %BB_0290 ]
  %phi.9 = phi i32 [ %phi.7, %BB_0240 ], [ %phi.2, %BB_0290 ]
  %phi.10 = phi i32 [ %.158, %BB_0240 ], [ %imad.8, %BB_0290 ]
  %isetrp_cmp1.7.not = icmp eq i32 %phi.9, 0
  br i1 %isetrp_cmp1.7.not, label %BB_0320, label %BB_80000310

BB_80000310:                                      ; preds = %BB_02f0
  %.165 = xor i32 %phi.8, -1
  %imad.10 = add i32 %sel.1, %.165
  br label %BB_0320

BB_0320:                                          ; preds = %BB_80000310, %BB_02f0, %EntryBB_0000
  %phi.11 = phi i32 [ %s2ur_ctaid_x, %EntryBB_0000 ], [ %imad.10, %BB_80000310 ], [ %phi.8, %BB_02f0 ]
  %phi.12 = phi i32 [ %s2ur_ctaid_y, %EntryBB_0000 ], [ %phi.10, %BB_80000310 ], [ %phi.10, %BB_02f0 ]
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %.181 = getelementptr inbounds nuw i8, ptr %param_local, i64 964
  %ldc_const = load i8, ptr %.181, align 1
  %sel.4 = select i1 %isetrp_cmp1.1.not, i32 %phi.11, i32 %phi.12
  %sel.5 = select i1 %isetrp_cmp1.1.not, i32 %phi.12, i32 %phi.11
  %imad_addend.2 = load i32, ptr %.3, align 4
  %.184 = getelementptr inbounds nuw i8, ptr %param_local, i64 356
  %imad_addend.3 = load i32, ptr %.184, align 4
  %.187 = zext i32 %tid_x to i64
  %.188 = shl nuw i64 %.187, 32
  %.189 = ashr exact i64 %.188, 31
  %isetrp_cmp1.8.not = icmp eq i8 %ldc_const, 0
  %.196 = lshr i64 %.189, 61
  %17 = trunc nuw nsw i64 %.196 to i32
  %.198 = add i32 %tid_x, %17
  %imad_tmp.12 = shl i32 %ctaid_z, 6
  %.202 = and i32 %.198, -8
  %.208 = zext i32 %.198 to i64
  %.209 = shl nuw i64 %.208, 32
  %.210 = ashr exact i64 %.209, 3
  %shf_hi.3 = lshr i64 %.210, 32
  %shf_result.6 = trunc nuw i64 %shf_hi.3 to i32
  %sel.6 = select i1 %isetrp_cmp1.8.not, i32 %imad_tmp.12, i32 0
  %imad.14 = sub i32 %tid_x, %.202
  %.214 = ashr exact i64 %.209, 31
  %imad_tmp.14 = shl i32 %sel.4, 5
  %imad.15 = add i32 %imad_tmp.14, %shf_result.6
  %imad_tmp.15 = shl i32 %imad.14, 3
  %imad.16 = add i32 %imad_tmp.15, %sel.6
  %.220 = lshr i64 %.214, 32
  %.221 = and i64 %.220, 7
  %.222 = add nuw nsw i64 %.221, %shf_hi.3
  %.223 = trunc i64 %.222 to i32
  %iadd3_n1.2 = add i32 %imad.15, 16
  %.224 = getelementptr inbounds nuw i8, ptr %param_local, i64 516
  %isetrp_rhs.2 = load i32, ptr %.224, align 4
  %isetrp_cmp1.9.not = icmp slt i32 %imad.16, %isetrp_rhs.2
  %.229 = and i32 %.223, 268435448
  %.234 = getelementptr inbounds nuw i8, ptr %param_local, i64 508
  %isetrp_rhs.3 = load i32, ptr %.234, align 4
  %isetrp_cmp1.10 = icmp slt i32 %iadd3_n1.2, %isetrp_rhs.3
  %isetrp_cmp2.10 = and i1 %isetrp_cmp1.10, %isetrp_cmp1.9.not
  %.236 = getelementptr inbounds nuw i8, ptr %param_local, i64 972
  %ldc_const.1 = load i8, ptr %.236, align 1
  %imad.17 = sub i32 %shf_result.6, %.229
  %isetrp_cmp1.11 = icmp slt i32 %imad.15, %isetrp_rhs.3
  %isetrp_cmp2.11 = and i1 %isetrp_cmp1.11, %isetrp_cmp1.9.not
  %18 = sext i32 %imad.15 to i64
  %.253 = xor i32 %imad.14, %imad.17
  %19 = sext i32 %imad.16 to i64
  %p2r_p0_i32 = zext i1 %isetrp_cmp2.11 to i32
  %p2r_p1_shl = select i1 %isetrp_cmp2.10, i32 2, i32 0
  %p2r_or_1 = or disjoint i32 %p2r_p1_shl, %p2r_p0_i32
  %20 = shl i32 %shf_result.6, 7
  %21 = shl i32 %.253, 4
  %imad_tmp.18 = add i32 %20, %21
  %22 = zext i32 %imad_addend.2 to i64
  %23 = zext i32 %imad_addend.3 to i64
  %24 = shl nuw i64 %23, 32
  %25 = or disjoint i64 %24, %22
  br i1 %isetrp_cmp1.8.not, label %BB_0670, label %BB_05b0

BB_05b0:                                          ; preds = %BB_0320
  %isetrp_cmp1.12.not = icmp eq i8 %ldc_const.1, 0
  br i1 %isetrp_cmp1.12.not, label %BB_0640, label %BB_800005d0

BB_0640:                                          ; preds = %BB_05b0
  %imad_addend.4 = load i64, ptr %.3, align 8
  %imad_lhs_64.1 = sext i32 %ctaid_z to i64
  %imad_tmp_64.1 = shl nsw i64 %imad_lhs_64.1, 3
  %26 = add i64 %imad_tmp_64.1, %imad_addend.4
  %"R543:R783_addr_ptr" = inttoptr i64 %26 to ptr addrspace(1)
  %ldg_vec3 = load i64, ptr addrspace(1) %"R543:R783_addr_ptr", align 8
  br label %BB_0670

BB_800005d0:                                      ; preds = %BB_05b0
  %27 = sext i32 %ctaid_z to i64
  %.272 = getelementptr inbounds nuw i8, ptr %param_local, i64 576
  %imad_rhs = load i32, ptr %.272, align 4
  %.276 = getelementptr inbounds nuw i8, ptr %param_local, i64 580
  %imad_rhs.2 = load i32, ptr %.276, align 4
  %28 = zext i32 %imad_rhs.2 to i64
  %29 = shl nuw i64 %28, 32
  %30 = zext i32 %imad_rhs to i64
  %31 = or disjoint i64 %29, %30
  %32 = mul i64 %31, %27
  %.296 = shl i64 %32, 1
  %33 = zext i32 %imad_addend.2 to i64
  %34 = zext i32 %imad_addend.3 to i64
  %35 = shl nuw i64 %34, 32
  %36 = add i64 %.296, %33
  %37 = add i64 %36, %35
  br label %BB_0670

BB_0670:                                          ; preds = %BB_800005d0, %BB_0640, %BB_0320
  %38 = phi i64 [ %ldg_vec3, %BB_0640 ], [ %25, %BB_0320 ], [ %37, %BB_800005d0 ]
  %.306 = and i32 %.198, 536870904
  %imad_tmp.21 = shl i32 %sel.5, 5
  %imad.24 = add i32 %imad_tmp.21, %shf_result.6
  %imad.25 = sub i32 %tid_x, %.306
  %iadd3_n1.4 = add i32 %imad.24, 16
  %.311 = getelementptr inbounds nuw i8, ptr %param_local, i64 512
  %isetrp_rhs.5 = load i32, ptr %.311, align 4
  %isetrp_cmp1.13 = icmp slt i32 %imad.24, %isetrp_rhs.5
  %isetrp_cmp2.13 = and i1 %isetrp_cmp1.13, %isetrp_cmp1.9.not
  %imad_tmp.23 = shl i32 %imad.25, 3
  %imad.26 = add i32 %imad_tmp.23, %sel.6
  %isetrp_cmp1.14 = icmp slt i32 %iadd3_n1.4, %isetrp_rhs.5
  %isetrp_cmp2.14 = and i1 %isetrp_cmp1.14, %isetrp_cmp1.9.not
  %.315 = getelementptr inbounds nuw i8, ptr %param_local, i64 360
  %imad_addend.5 = load i32, ptr %.315, align 4
  %39 = sext i32 %imad.24 to i64
  %.321 = getelementptr inbounds nuw i8, ptr %param_local, i64 364
  %imad_addend.6 = load i32, ptr %.321, align 4
  %.323 = getelementptr inbounds nuw i8, ptr %param_local, i64 1072
  %iadd3_o2 = load i32, ptr %.323, align 4
  %iadd3_n1.5 = add i32 %imad.26, %iadd3_o2
  %p2r_p0_i32.1 = zext i1 %isetrp_cmp2.13 to i32
  %p2r_p1_shl.1 = select i1 %isetrp_cmp2.14, i32 2, i32 0
  %p2r_or_1.1 = or disjoint i32 %p2r_p1_shl.1, %p2r_p0_i32.1
  %40 = zext i32 %imad_addend.5 to i64
  %41 = zext i32 %imad_addend.6 to i64
  %42 = shl nuw i64 %41, 32
  %43 = or disjoint i64 %42, %40
  br i1 %isetrp_cmp1.8.not, label %BB_0820, label %BB_0750

BB_0750:                                          ; preds = %BB_0670
  %isetrp_cmp1.15.not = icmp eq i8 %ldc_const.1, 0
  br i1 %isetrp_cmp1.15.not, label %BB_07e0, label %BB_80000750

BB_07e0:                                          ; preds = %BB_0750
  %imad_addend.7 = load i64, ptr %.315, align 8
  %imad_lhs_64.3 = sext i32 %ctaid_z to i64
  %imad_tmp_64.3 = shl nsw i64 %imad_lhs_64.3, 3
  %44 = add i64 %imad_tmp_64.3, %imad_addend.7
  %"R158:R878_addr_ptr" = inttoptr i64 %44 to ptr addrspace(1)
  %ldg_vec.14 = load i64, ptr addrspace(1) %"R158:R878_addr_ptr", align 8
  br label %BB_0820

BB_80000750:                                      ; preds = %BB_0750
  %45 = sext i32 %ctaid_z to i64
  %.336 = getelementptr inbounds nuw i8, ptr %param_local, i64 600
  %imad_rhs.3 = load i32, ptr %.336, align 4
  %.351 = getelementptr inbounds nuw i8, ptr %param_local, i64 604
  %imad_rhs.5 = load i32, ptr %.351, align 4
  %46 = zext i32 %imad_rhs.5 to i64
  %47 = shl nuw i64 %46, 32
  %48 = zext i32 %imad_rhs.3 to i64
  %49 = or disjoint i64 %47, %48
  %50 = mul i64 %49, %45
  %.360 = shl i64 %50, 1
  %51 = zext i32 %imad_addend.5 to i64
  %52 = zext i32 %imad_addend.6 to i64
  %53 = shl nuw i64 %52, 32
  %54 = add i64 %.360, %51
  %55 = add i64 %54, %53
  br label %BB_0820

BB_0820:                                          ; preds = %BB_80000750, %BB_07e0, %BB_0670
  %56 = phi i64 [ %ldg_vec.14, %BB_07e0 ], [ %43, %BB_0670 ], [ %55, %BB_80000750 ]
  %.367 = getelementptr inbounds nuw i8, ptr %param_local, i64 1064
  %isetrp_rhs.7 = load i32, ptr %.367, align 4
  %isetrp_cmp1.16 = icmp slt i32 %isetrp_rhs.7, 0
  br i1 %isetrp_cmp1.16, label %BB_0ce0, label %BB_0840

BB_0840:                                          ; preds = %BB_0820
  %iadd3_tmp = add i32 %imad.15, 16
  %.371 = getelementptr inbounds nuw i8, ptr %param_local, i64 520
  %imad_rhs.6 = load i32, ptr %.371, align 4
  %57 = add nsw i64 %18, 16
  %58 = add nsw i64 %39, 16
  %.375 = getelementptr inbounds nuw i8, ptr %param_local, i64 524
  %imad_rhs.8 = load i32, ptr %.375, align 4
  %59 = zext i32 %imad_rhs.8 to i64
  %60 = shl nuw i64 %59, 32
  %61 = zext i32 %imad_rhs.6 to i64
  %62 = or disjoint i64 %60, %61
  %63 = mul i64 %62, %18
  %64 = add i64 %63, %19
  %.379 = getelementptr inbounds nuw i8, ptr %param_local, i64 528
  %imad_rhs.10 = load i32, ptr %.379, align 4
  %.386 = shl i64 %64, 1
  %imad_tmp_64.6 = mul i32 %iadd3_tmp, %imad_rhs.6
  %imad.41 = add i32 %imad_tmp_64.6, %imad.16
  %.393 = getelementptr inbounds nuw i8, ptr %param_local, i64 532
  %imad_rhs.14 = load i32, ptr %.393, align 4
  %65 = zext i32 %imad_rhs.14 to i64
  %66 = shl nuw i64 %65, 32
  %67 = zext i32 %imad_rhs.10 to i64
  %68 = or disjoint i64 %66, %67
  %69 = mul i64 %57, %62
  %70 = add i64 %69, %19
  %iadd3_n1.10 = add nuw i32 %isetrp_rhs.7, 5
  %iadd3_n1.11 = add nuw i32 %isetrp_rhs.7, 1
  %71 = mul i64 %68, %39
  %72 = add i64 %71, %19
  %.402 = shl i64 %70, 1
  %.408 = shl i64 %72, 1
  %.409 = getelementptr inbounds nuw i8, ptr %param_local, i64 1068
  %iadd3_o2.1 = load i32, ptr %.409, align 4
  %iadd3_n1.13 = sub i32 %iadd3_n1.10, %iadd3_o2.1
  %imad_tmp.39 = shl i32 %imad.41, 1
  %73 = mul i64 %58, %68
  %74 = add i64 %73, %19
  %.418 = shl i64 %74, 1
  %imnmx_max = call i32 @llvm.smin.i32(i32 %iadd3_n1.11, i32 5)
  %75 = and i32 %imad_tmp.18, 16777200
  %p2c.f100 = add nuw nsw i32 %75, 2048
  %p2c.f101 = add nuw nsw i32 %75, 4096
  %p2c.f102 = add nuw nsw i32 %75, 6144
  br label %BB_0a70

BB_0a70:                                          ; preds = %116, %BB_0840
  %p2c.c = phi i32 [ 0, %BB_0840 ], [ %127, %116 ]
  %76 = phi i64 [ %56, %BB_0840 ], [ %121, %116 ]
  %77 = phi i64 [ %38, %BB_0840 ], [ %126, %116 ]
  %phi.17 = phi i32 [ 0, %BB_0840 ], [ %iadd3_n1.19, %116 ]
  %phi.18 = phi i32 [ 0, %BB_0840 ], [ %phi.26, %116 ]
  %phi.19 = phi i32 [ 0, %BB_0840 ], [ %phi.27, %116 ]
  %phi.20 = phi i32 [ %p2r_or_1, %BB_0840 ], [ %sel.7, %116 ]
  %phi.21 = phi i32 [ %p2r_or_1.1, %BB_0840 ], [ %sel.8, %116 ]
  %r2p_p0 = trunc i32 %phi.20 to i1
  %isetrp_cmp1.18 = icmp slt i32 %phi.19, 20480
  %78 = trunc i64 %77 to i32
  %iadd3_trunc.3 = add i32 %imad_tmp.39, %78
  %79 = add i64 %77, %.386
  %80 = add i64 %77, %.402
  %isetrp_cmp1.17 = icmp slt i32 %phi.18, 20480
  %phi.26.v = select i1 %isetrp_cmp1.17, i32 4096, i32 -20480
  %phi.26 = add i32 %phi.18, %phi.26.v
  %warp_reconv_mask = call i32 asm sideeffect "activemask.b32 $0;", "=r"() #9
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  %81 = icmp slt i32 %p2c.c, 1
  br i1 %81, label %82, label %84

82:                                               ; preds = %BB_0a70
  %83 = zext nneg i32 %75 to i64
  %p2c.sm104 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %83
  %p2c.smp105 = ptrtoint ptr addrspace(3) %p2c.sm104 to i64
  %p2c.sz = select i1 %r2p_p0, i32 16, i32 0
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp105, i64 %79, i32 %p2c.sz) #9
  br label %88

84:                                               ; preds = %BB_0a70
  %p2c.q106 = select i1 %r2p_p0, i64 %79, i64 0
  %85 = zext nneg i32 %p2c.c to i64
  %86 = getelementptr i64, ptr %p2c.q134, i64 %85
  %87 = getelementptr i8, ptr %86, i64 -8
  store i64 %p2c.q106, ptr %87, align 8
  br label %88

88:                                               ; preds = %84, %82
  %phi.27.v = select i1 %isetrp_cmp1.18, i32 4096, i32 -20480
  %phi.27 = add i32 %phi.19, %phi.27.v
  %89 = shl i32 %phi.20, 3
  %cpa_srcsz.1 = and i32 %89, 16
  %90 = icmp slt i32 %p2c.c, 1
  br i1 %90, label %91, label %93

91:                                               ; preds = %88
  %92 = zext nneg i32 %p2c.f100 to i64
  %p2c.sm108 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %92
  %p2c.smp109 = ptrtoint ptr addrspace(3) %p2c.sm108 to i64
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp109, i64 %80, i32 %cpa_srcsz.1) #9
  br label %97

93:                                               ; preds = %88
  %.not = icmp eq i32 %cpa_srcsz.1, 0
  %p2c.q111 = select i1 %.not, i64 0, i64 %80
  %94 = add nuw i32 %p2c.c, 3
  %95 = sext i32 %94 to i64
  %96 = getelementptr i64, ptr %p2c.q134, i64 %95
  store i64 %p2c.q111, ptr %96, align 8
  br label %97

97:                                               ; preds = %93, %91
  %r2p_p0.1 = trunc i32 %phi.21 to i1
  %98 = add i64 %76, %.408
  %99 = add i64 %76, %.418
  %isetrp_rhs.8 = load i32, ptr %.224, align 4
  %100 = icmp slt i32 %p2c.c, 1
  br i1 %100, label %101, label %103

101:                                              ; preds = %97
  %102 = zext nneg i32 %p2c.f101 to i64
  %p2c.sm113 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %102
  %p2c.smp114 = ptrtoint ptr addrspace(3) %p2c.sm113 to i64
  %p2c.sz115 = select i1 %r2p_p0.1, i32 16, i32 0
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp114, i64 %98, i32 %p2c.sz115) #9
  br label %107

103:                                              ; preds = %97
  %p2c.q116 = select i1 %r2p_p0.1, i64 %98, i64 0
  %104 = add nuw i32 %p2c.c, 7
  %105 = sext i32 %104 to i64
  %106 = getelementptr i64, ptr %p2c.q134, i64 %105
  store i64 %p2c.q116, ptr %106, align 8
  br label %107

107:                                              ; preds = %103, %101
  %.436 = getelementptr inbounds nuw i8, ptr %param_local, i64 1048
  %iadd3_o2.2 = load i32, ptr %.436, align 4
  %108 = shl i32 %phi.21, 3
  %cpa_srcsz.3 = and i32 %108, 16
  %109 = icmp slt i32 %p2c.c, 1
  br i1 %109, label %110, label %112

110:                                              ; preds = %107
  %111 = zext nneg i32 %p2c.f102 to i64
  %p2c.sm118 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %111
  %p2c.smp119 = ptrtoint ptr addrspace(3) %p2c.sm118 to i64
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp119, i64 %99, i32 %cpa_srcsz.3) #9
  br label %116

112:                                              ; preds = %107
  %.not136 = icmp eq i32 %cpa_srcsz.3, 0
  %p2c.q121 = select i1 %.not136, i64 0, i64 %99
  %113 = add nuw i32 %p2c.c, 11
  %114 = sext i32 %113 to i64
  %115 = getelementptr i64, ptr %p2c.q134, i64 %114
  store i64 %p2c.q121, ptr %115, align 8
  br label %116

116:                                              ; preds = %112, %110
  %isetrp_cmp1.20 = icmp slt i32 %iadd3_n1.5, %isetrp_rhs.8
  %isetrp_cmp1.19.not = icmp sgt i32 %iadd3_n1.13, %phi.17
  %isetrp_cmp2.20 = or i1 %isetrp_cmp1.20, %isetrp_cmp1.19.not
  %sel.8 = select i1 %isetrp_cmp2.20, i32 %phi.21, i32 0
  %117 = zext i32 %iadd3_o2.2 to i64
  %118 = add i64 %76, %117
  %.444 = getelementptr inbounds nuw i8, ptr %param_local, i64 1052
  %iadd3_o2.5 = load i32, ptr %.444, align 4
  %119 = zext i32 %iadd3_o2.5 to i64
  %120 = shl nuw i64 %119, 32
  %121 = add i64 %118, %120
  %.440 = getelementptr inbounds nuw i8, ptr %param_local, i64 1032
  %iadd3_o2.3 = load i32, ptr %.440, align 4
  %122 = zext i32 %iadd3_o2.3 to i64
  %123 = add i64 %77, %122
  %.442 = getelementptr inbounds nuw i8, ptr %param_local, i64 1036
  %iadd3_o2.4 = load i32, ptr %.442, align 4
  %124 = zext i32 %iadd3_o2.4 to i64
  %125 = shl nuw i64 %124, 32
  %126 = add i64 %123, %125
  %sel.7 = select i1 %isetrp_cmp2.20, i32 %phi.20, i32 0
  %iadd3_n1.19 = add i32 %phi.17, 1
  %isetrp_cmp1.21.not = icmp sgt i32 %imnmx_max, %iadd3_n1.19
  %127 = add i32 %p2c.c, 1
  br i1 %isetrp_cmp1.21.not, label %BB_0a70, label %BB_0ce0.loopexit

BB_0ce0.loopexit:                                 ; preds = %116
  br label %BB_0ce0

BB_0ce0:                                          ; preds = %BB_0ce0.loopexit, %BB_0820
  %128 = phi i64 [ %56, %BB_0820 ], [ %121, %BB_0ce0.loopexit ]
  %129 = phi i64 [ %38, %BB_0820 ], [ %126, %BB_0ce0.loopexit ]
  %phi.28 = phi i32 [ 0, %BB_0820 ], [ %phi.26, %BB_0ce0.loopexit ]
  %phi.29 = phi i32 [ 0, %BB_0820 ], [ %phi.27, %BB_0ce0.loopexit ]
  %phi.30 = phi i32 [ %p2r_or_1, %BB_0820 ], [ %sel.7, %BB_0ce0.loopexit ]
  %phi.31 = phi i32 [ %p2r_or_1.1, %BB_0820 ], [ %sel.8, %BB_0ce0.loopexit ]
  %phi.32 = phi i32 [ 0, %BB_0820 ], [ %iadd3_trunc.3, %BB_0ce0.loopexit ]
  %mov.1 = load i32, ptr %.367, align 4
  %isetrp_cmp1.22 = icmp sgt i32 %mov.1, 3
  br i1 %isetrp_cmp1.22, label %BB_0df0, label %BB_0d30.preheader

BB_0d30.preheader:                                ; preds = %BB_0ce0
  br label %BB_0d30

BB_0d30:                                          ; preds = %BB_0d30.preheader, %BB_0d30
  %phi.37 = phi i32 [ %phi.40, %BB_0d30 ], [ %phi.28, %BB_0d30.preheader ]
  %phi.38 = phi i32 [ %phi.41, %BB_0d30 ], [ %phi.29, %BB_0d30.preheader ]
  %phi.39 = phi i32 [ %iadd3_n1.22, %BB_0d30 ], [ %mov.1, %BB_0d30.preheader ]
  %iadd3_n1.22 = add i32 %phi.39, 1
  %isetrp_cmp1.24 = icmp slt i32 %phi.38, 20480
  %isetrp_cmp1.25 = icmp slt i32 %iadd3_n1.22, 4
  %isetrp_cmp1.23 = icmp slt i32 %phi.37, 20480
  %phi.40.v = select i1 %isetrp_cmp1.23, i32 4096, i32 -20480
  %phi.40 = add i32 %phi.37, %phi.40.v
  %phi.41.v = select i1 %isetrp_cmp1.24, i32 4096, i32 -20480
  %phi.41 = add i32 %phi.38, %phi.41.v
  br i1 %isetrp_cmp1.25, label %BB_0d30, label %BB_0df0.loopexit

BB_0df0.loopexit:                                 ; preds = %BB_0d30
  br label %BB_0df0

BB_0df0:                                          ; preds = %BB_0df0.loopexit, %BB_0ce0
  %phi.42 = phi i32 [ %phi.28, %BB_0ce0 ], [ %phi.40, %BB_0df0.loopexit ]
  %phi.43 = phi i32 [ %phi.29, %BB_0ce0 ], [ %phi.41, %BB_0df0.loopexit ]
  %.465 = and i32 %tid_x, 7
  %.473 = and i32 %tid_x, 64
  %.492 = lshr exact i32 %.473, 2
  %.493 = or disjoint i32 %.492, %.465
  %imad_tmp.48 = shl i32 %tid_x, 4
  %.481 = lshr i32 %tid_x, 3
  %130 = and i32 %.481, 1
  %.498 = lshr i32 %tid_x, 1
  %131 = and i32 %.498, 8
  %.5145 = or disjoint i32 %131, %.493
  %.519 = and i32 %tid_x, 32
  %.527 = and i32 %tid_x, 15
  %.542 = xor i32 %tid_x, -1
  %.543 = xor i32 %130, 7
  %.544 = and i32 %.543, %tid_x
  %.552 = and i32 %130, %.542
  %.553 = or disjoint i32 %.544, %.552
  %.560 = lshr exact i32 %.519, 1
  %.561 = or disjoint i32 %.560, %.527
  %.563 = and i32 %imad_tmp.48, 16
  %.566 = xor i32 %.563, 16
  %.567 = and i32 %.566, %tid_x
  %.568 = and i32 %imad_tmp.48, 96
  %.573 = or disjoint i32 %.567, %.568
  %.574 = and i32 %imad_tmp.48, 16
  %.575 = and i32 %.574, %.542
  %imad_tmp.50 = shl nuw nsw i32 %.561, 7
  %132 = or disjoint i32 %.575, %imad_tmp.50
  %imad.59 = or i32 %132, %.573
  call void @llvm.nvvm.barrier0()
  %133 = shl nuw nsw i32 %.5145, 7
  %134 = shl nuw nsw i32 %.553, 4
  %imad_tmp.51 = or disjoint i32 %133, %134
  br i1 %isetrp_cmp1.16, label %BB_1580, label %BB_0f50

BB_0f50:                                          ; preds = %BB_0df0
  %ldsm_shared_winoff = and i32 %imad.59, 16777200
  %.581 = getelementptr inbounds nuw i8, ptr %param_local, i64 520
  %imad_rhs.18 = load i32, ptr %.581, align 4
  %.583 = getelementptr inbounds nuw i8, ptr %param_local, i64 528
  %imad_rhs.19 = load i32, ptr %.583, align 4
  %135 = add nsw i64 %18, 16
  %136 = add nsw i64 %39, 16
  %.603 = getelementptr inbounds nuw i8, ptr %param_local, i64 524
  %imad_rhs.22 = load i32, ptr %.603, align 4
  %137 = zext i32 %imad_rhs.22 to i64
  %138 = shl nuw i64 %137, 32
  %139 = zext i32 %imad_rhs.18 to i64
  %140 = or disjoint i64 %138, %139
  %.605 = getelementptr inbounds nuw i8, ptr %param_local, i64 532
  %imad_rhs.23 = load i32, ptr %.605, align 4
  %141 = zext i32 %imad_rhs.23 to i64
  %142 = shl nuw i64 %141, 32
  %143 = zext i32 %imad_rhs.19 to i64
  %144 = or disjoint i64 %142, %143
  %145 = mul i64 %140, %18
  %146 = add i64 %145, %19
  %.638 = shl i64 %146, 1
  %147 = add i64 %129, %.638
  %mov.3 = load i32, ptr %.367, align 4
  %148 = mul i64 %144, %39
  %149 = add i64 %148, %19
  %150 = mul i64 %135, %140
  %151 = add i64 %150, %19
  %152 = mul i64 %136, %144
  %153 = add i64 %152, %19
  %.668 = xor i32 %imad_tmp.51, -1
  %.671 = and i32 %.668, 32
  %.676 = and i32 %imad_tmp.51, 16777168
  %.678 = or disjoint i32 %.671, %.676
  %.687 = shl i64 %149, 1
  %154 = add i64 %128, %.687
  %.698 = shl i64 %151, 1
  %155 = add i64 %129, %.698
  %.709 = shl i64 %153, 1
  %156 = add i64 %128, %.709
  %.718 = and i32 %.668, 64
  %.723 = and i32 %imad_tmp.51, 16777136
  %.725 = or disjoint i32 %.718, %.723
  %.746 = and i32 %.668, 96
  %.751 = and i32 %imad_tmp.51, 16777104
  %.753 = or disjoint i32 %.746, %.751
  %.585 = and i32 %imad_tmp.48, 32
  %.765 = and i32 %imad.59, 16777168
  %157 = or disjoint i32 %.585, %.765
  %.767 = xor i32 %157, 32
  %.595 = and i32 %imad.59, 16777200
  %158 = xor i32 %.595, 64
  %.739 = and i32 %imad.59, 16777200
  %159 = xor i32 %.739, 96
  %160 = and i32 %imad_tmp.18, 16777200
  %p2c.f87 = add nuw nsw i32 %160, 2048
  %p2c.f89 = add nuw nsw i32 %160, 4096
  %p2c.f91 = add nuw nsw i32 %160, 6144
  br label %BB_1190

BB_1190:                                          ; preds = %BB_1190, %BB_0f50
  %lo.fragoff = phi i32 [ %ldsm_shared_winoff, %BB_0f50 ], [ %imad.59, %BB_1190 ]
  %p2c.qi = phi i32 [ 0, %BB_0f50 ], [ %394, %BB_1190 ]
  %161 = phi i64 [ %156, %BB_0f50 ], [ %391, %BB_1190 ]
  %162 = phi i64 [ %154, %BB_0f50 ], [ %388, %BB_1190 ]
  %163 = phi i64 [ %155, %BB_0f50 ], [ %378, %BB_1190 ]
  %164 = phi i64 [ %147, %BB_0f50 ], [ %381, %BB_1190 ]
  %phi.44 = phi i32 [ 0, %BB_0f50 ], [ %phi.75, %BB_1190 ]
  %phi.45 = phi i32 [ 0, %BB_0f50 ], [ %phi.76, %BB_1190 ]
  %phi.46 = phi i32 [ %phi.42, %BB_0f50 ], [ %phi.77, %BB_1190 ]
  %phi.47 = phi i32 [ %phi.43, %BB_0f50 ], [ %phi.78, %BB_1190 ]
  %phi.48 = phi float [ 0.000000e+00, %BB_0f50 ], [ %365, %BB_1190 ]
  %phi.49 = phi float [ 0.000000e+00, %BB_0f50 ], [ %364, %BB_1190 ]
  %phi.50 = phi float [ 0.000000e+00, %BB_0f50 ], [ %363, %BB_1190 ]
  %phi.51 = phi float [ 0.000000e+00, %BB_0f50 ], [ %362, %BB_1190 ]
  %phi.52 = phi float [ 0.000000e+00, %BB_0f50 ], [ %361, %BB_1190 ]
  %phi.53 = phi i32 [ %mov.3, %BB_0f50 ], [ %iadd3_n1.39, %BB_1190 ]
  %phi.54 = phi i32 [ %phi.30, %BB_0f50 ], [ %sel.11, %BB_1190 ]
  %phi.55 = phi i32 [ %phi.31, %BB_0f50 ], [ %sel.12, %BB_1190 ]
  %phi.60 = phi float [ 0.000000e+00, %BB_0f50 ], [ %360, %BB_1190 ]
  %phi.73 = phi float [ 0.000000e+00, %BB_0f50 ], [ %367, %BB_1190 ]
  %phi.74 = phi float [ 0.000000e+00, %BB_0f50 ], [ %366, %BB_1190 ]
  %lo.fragoff150.in = and i32 %imad_tmp.51, 16752624
  %lo.fragoff150 = add nuw nsw i32 %lo.fragoff150.in, 4096
  %isetrp_cmp1.28 = icmp sgt i32 %phi.53, 4
  %sel.9 = select i1 %isetrp_cmp1.28, i32 %phi.54, i32 0
  %sel.10 = select i1 %isetrp_cmp1.28, i32 %phi.55, i32 0
  %r2p_p0.2 = trunc i32 %sel.9 to i1
  %p2c.q86 = select i1 %r2p_p0.2, i64 %164, i64 0
  %165 = sext i32 %p2c.qi to i64
  %166 = getelementptr i64, ptr %p2c.q134, i64 %165
  %167 = sext i32 %p2c.qi to i64
  %168 = getelementptr i64, ptr %p2c.q134, i64 %167
  %p2c.qo = load i64, ptr %168, align 8
  %169 = add i32 %p2c.qi, 4
  %170 = sext i32 %169 to i64
  %171 = getelementptr i64, ptr %p2c.q134, i64 %170
  %p2c.qo82 = load i64, ptr %171, align 8
  %172 = add i32 %p2c.qi, 8
  %173 = sext i32 %172 to i64
  %174 = getelementptr i64, ptr %p2c.q134, i64 %173
  %p2c.qo83 = load i64, ptr %174, align 8
  %175 = add i32 %p2c.qi, 12
  %176 = sext i32 %175 to i64
  %177 = getelementptr i64, ptr %p2c.q134, i64 %176
  %p2c.qo84 = load i64, ptr %177, align 8
  store i64 %p2c.q86, ptr %166, align 8
  %178 = and i32 %sel.9, 2
  %.not138 = icmp eq i32 %178, 0
  %p2c.q88 = select i1 %.not138, i64 0, i64 %163
  %179 = add i32 %p2c.qi, 4
  %180 = sext i32 %179 to i64
  %181 = getelementptr i64, ptr %p2c.q134, i64 %180
  store i64 %p2c.q88, ptr %181, align 8
  %r2p_p0.3 = trunc i32 %sel.10 to i1
  %p2c.q90 = select i1 %r2p_p0.3, i64 %162, i64 0
  %182 = add i32 %p2c.qi, 8
  %183 = sext i32 %182 to i64
  %184 = getelementptr i64, ptr %p2c.q134, i64 %183
  store i64 %p2c.q90, ptr %184, align 8
  %185 = and i32 %sel.10, 2
  %.not139 = icmp eq i32 %185, 0
  %p2c.q92 = select i1 %.not139, i64 0, i64 %161
  %186 = add i32 %p2c.qi, 12
  %187 = sext i32 %186 to i64
  %188 = getelementptr i64, ptr %p2c.q134, i64 %187
  store i64 %p2c.q92, ptr %188, align 8
  %lo.lane = call i32 @llvm.nvvm.read.ptx.sreg.laneid()
  %lo.g = lshr i32 %lo.lane, 2
  %189 = and i32 %lo.lane, 2
  %lo.th.not = icmp eq i32 %189, 0
  %190 = shl i32 %lo.lane, 3
  %lo.t8 = and i32 %190, 8
  %191 = shl nuw nsw i32 %189, 3
  %192 = or i32 %191, %lo.g
  %lo.shfl152 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff, i32 %192, i32 31) #7
  %193 = add i32 %lo.shfl152, %lo.t8
  %194 = sext i32 %193 to i64
  %195 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %194
  %196 = load volatile float, ptr addrspace(3) %195, align 4
  %197 = add i32 %lo.shfl152, %lo.t8
  %198 = sext i32 %197 to i64
  %199 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %198
  %200 = getelementptr i8, ptr addrspace(3) %199, i64 4
  %201 = load volatile float, ptr addrspace(3) %200, align 4
  %lo.shfl154 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.767, i32 %192, i32 31) #7
  %202 = add i32 %lo.shfl154, %lo.t8
  %203 = sext i32 %202 to i64
  %204 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %203
  %205 = load volatile float, ptr addrspace(3) %204, align 4
  %206 = add i32 %lo.shfl154, %lo.t8
  %207 = sext i32 %206 to i64
  %208 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %207
  %209 = getelementptr i8, ptr addrspace(3) %208, i64 4
  %210 = load volatile float, ptr addrspace(3) %209, align 4
  %211 = select i1 %lo.th.not, i32 8, i32 24
  %212 = or i32 %211, %lo.g
  %lo.shfl153 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff, i32 %212, i32 31) #7
  %lo.shfl155 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.767, i32 %212, i32 31) #7
  %213 = add i32 %lo.shfl153, %lo.t8
  %214 = sext i32 %213 to i64
  %215 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %214
  %216 = load volatile float, ptr addrspace(3) %215, align 4
  %217 = add i32 %lo.shfl153, %lo.t8
  %218 = sext i32 %217 to i64
  %219 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %218
  %220 = getelementptr i8, ptr addrspace(3) %219, i64 4
  %221 = load volatile float, ptr addrspace(3) %220, align 4
  %222 = add i32 %lo.shfl155, %lo.t8
  %223 = sext i32 %222 to i64
  %224 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %223
  %225 = load volatile float, ptr addrspace(3) %224, align 4
  %226 = add i32 %lo.shfl155, %lo.t8
  %227 = sext i32 %226 to i64
  %228 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %227
  %229 = getelementptr i8, ptr addrspace(3) %228, i64 4
  %230 = load volatile float, ptr addrspace(3) %229, align 4
  %231 = shl nuw nsw i32 %189, 2
  %232 = shl nuw nsw i32 %lo.g, 1
  %233 = and i32 %232, 6
  %234 = lshr i32 %lo.lane, 4
  %lo.rho = or i32 %233, %234
  %235 = or i32 %231, %lo.rho
  %lo.shfl = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff150, i32 %235, i32 31) #7
  %236 = add i32 %lo.shfl, %lo.t8
  %237 = sext i32 %236 to i64
  %238 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %237
  %239 = load volatile float, ptr addrspace(3) %238, align 4
  %240 = add i32 %lo.shfl, %lo.t8
  %241 = sext i32 %240 to i64
  %242 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %241
  %243 = getelementptr i8, ptr addrspace(3) %242, i64 4
  %244 = load volatile float, ptr addrspace(3) %243, align 4
  %245 = select i1 %lo.th.not, i32 16, i32 24
  %246 = or i32 %245, %lo.rho
  %lo.shfl151 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %lo.fragoff150, i32 %246, i32 31) #7
  %247 = add i32 %lo.shfl151, %lo.t8
  %248 = sext i32 %247 to i64
  %249 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %248
  %250 = load volatile float, ptr addrspace(3) %249, align 4
  %251 = add i32 %lo.shfl151, %lo.t8
  %252 = sext i32 %251 to i64
  %253 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %252
  %254 = getelementptr i8, ptr addrspace(3) %253, i64 4
  %255 = load volatile float, ptr addrspace(3) %254, align 4
  %lo.shfl156 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.678, i32 %235, i32 31) #7
  %lo.shfl157 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.678, i32 %246, i32 31) #7
  %256 = add i32 %lo.shfl156, %lo.t8
  %257 = sext i32 %256 to i64
  %258 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %257
  %259 = getelementptr i8, ptr addrspace(3) %258, i64 4096
  %260 = load volatile float, ptr addrspace(3) %259, align 4
  %261 = add i32 %lo.shfl156, %lo.t8
  %262 = sext i32 %261 to i64
  %263 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %262
  %264 = getelementptr i8, ptr addrspace(3) %263, i64 4100
  %265 = load volatile float, ptr addrspace(3) %264, align 4
  %266 = add i32 %lo.shfl157, %lo.t8
  %267 = sext i32 %266 to i64
  %268 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %267
  %269 = getelementptr i8, ptr addrspace(3) %268, i64 4096
  %270 = load volatile float, ptr addrspace(3) %269, align 4
  %271 = add i32 %lo.shfl157, %lo.t8
  %272 = sext i32 %271 to i64
  %273 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %272
  %274 = getelementptr i8, ptr addrspace(3) %273, i64 4100
  %275 = load volatile float, ptr addrspace(3) %274, align 4
  %lo.w = call { float, float, float, float, float, float, float, float } @lo.wmma(ptr nonnull %lo.frag, float %196, float %201, float %205, float %210, float %216, float %221, float %225, float %230, float %239, float %250, float %244, float %255, float %260, float %270, float %265, float %275, float %phi.60, float %phi.52, float %phi.49, float %phi.48, float %phi.51, float %phi.50, float %phi.74, float %phi.73) #7
  %276 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 0
  %277 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 1
  %278 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 4
  %279 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 5
  %280 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 2
  %281 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 3
  %282 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 6
  %283 = extractvalue { float, float, float, float, float, float, float, float } %lo.w, 7
  %lo.shfl158 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %158, i32 %192, i32 31) #7
  %284 = add i32 %lo.shfl158, %lo.t8
  %285 = sext i32 %284 to i64
  %286 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %285
  %287 = load volatile float, ptr addrspace(3) %286, align 4
  %288 = add i32 %lo.shfl158, %lo.t8
  %289 = sext i32 %288 to i64
  %290 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %289
  %291 = getelementptr i8, ptr addrspace(3) %290, i64 4
  %292 = load volatile float, ptr addrspace(3) %291, align 4
  %lo.shfl162 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %159, i32 %192, i32 31) #7
  %293 = add i32 %lo.shfl162, %lo.t8
  %294 = sext i32 %293 to i64
  %295 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %294
  %296 = load volatile float, ptr addrspace(3) %295, align 4
  %297 = add i32 %lo.shfl162, %lo.t8
  %298 = sext i32 %297 to i64
  %299 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %298
  %300 = getelementptr i8, ptr addrspace(3) %299, i64 4
  %301 = load volatile float, ptr addrspace(3) %300, align 4
  %lo.shfl159 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %158, i32 %212, i32 31) #7
  %lo.shfl163 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %159, i32 %212, i32 31) #7
  %302 = add i32 %lo.shfl159, %lo.t8
  %303 = sext i32 %302 to i64
  %304 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %303
  %305 = load volatile float, ptr addrspace(3) %304, align 4
  %306 = add i32 %lo.shfl159, %lo.t8
  %307 = sext i32 %306 to i64
  %308 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %307
  %309 = getelementptr i8, ptr addrspace(3) %308, i64 4
  %310 = load volatile float, ptr addrspace(3) %309, align 4
  %311 = add i32 %lo.shfl163, %lo.t8
  %312 = sext i32 %311 to i64
  %313 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %312
  %314 = load volatile float, ptr addrspace(3) %313, align 4
  %315 = add i32 %lo.shfl163, %lo.t8
  %316 = sext i32 %315 to i64
  %317 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %316
  %318 = getelementptr i8, ptr addrspace(3) %317, i64 4
  %319 = load volatile float, ptr addrspace(3) %318, align 4
  %lo.shfl160 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.725, i32 %235, i32 31) #7
  %320 = add i32 %lo.shfl160, %lo.t8
  %321 = sext i32 %320 to i64
  %322 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %321
  %323 = getelementptr i8, ptr addrspace(3) %322, i64 4096
  %324 = load volatile float, ptr addrspace(3) %323, align 4
  %325 = add i32 %lo.shfl160, %lo.t8
  %326 = sext i32 %325 to i64
  %327 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %326
  %328 = getelementptr i8, ptr addrspace(3) %327, i64 4100
  %329 = load volatile float, ptr addrspace(3) %328, align 4
  %lo.shfl161 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.725, i32 %246, i32 31) #7
  %330 = add i32 %lo.shfl161, %lo.t8
  %331 = sext i32 %330 to i64
  %332 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %331
  %333 = getelementptr i8, ptr addrspace(3) %332, i64 4096
  %334 = load volatile float, ptr addrspace(3) %333, align 4
  %335 = add i32 %lo.shfl161, %lo.t8
  %336 = sext i32 %335 to i64
  %337 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %336
  %338 = getelementptr i8, ptr addrspace(3) %337, i64 4100
  %339 = load volatile float, ptr addrspace(3) %338, align 4
  %lo.shfl164 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.753, i32 %235, i32 31) #7
  %lo.shfl165 = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %.753, i32 %246, i32 31) #7
  %340 = add i32 %lo.shfl164, %lo.t8
  %341 = sext i32 %340 to i64
  %342 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %341
  %343 = getelementptr i8, ptr addrspace(3) %342, i64 4096
  %344 = load volatile float, ptr addrspace(3) %343, align 4
  %345 = add i32 %lo.shfl164, %lo.t8
  %346 = sext i32 %345 to i64
  %347 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %346
  %348 = getelementptr i8, ptr addrspace(3) %347, i64 4100
  %349 = load volatile float, ptr addrspace(3) %348, align 4
  %350 = add i32 %lo.shfl165, %lo.t8
  %351 = add i32 %lo.shfl165, %lo.t8
  %352 = sext i32 %351 to i64
  %353 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %352
  %354 = getelementptr i8, ptr addrspace(3) %353, i64 4100
  %355 = load volatile float, ptr addrspace(3) %354, align 4
  %356 = sext i32 %350 to i64
  %357 = getelementptr i8, ptr addrspace(3) @shared_mem, i64 %356
  %358 = getelementptr i8, ptr addrspace(3) %357, i64 4096
  %359 = load volatile float, ptr addrspace(3) %358, align 4
  %lo.w166 = call { float, float, float, float, float, float, float, float } @lo.wmma(ptr nonnull %lo.frag, float %287, float %292, float %296, float %301, float %305, float %310, float %314, float %319, float %324, float %334, float %329, float %339, float %344, float %359, float %349, float %355, float %276, float %277, float %280, float %281, float %278, float %279, float %282, float %283) #7
  %360 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 0
  %361 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 1
  %362 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 4
  %363 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 5
  %364 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 2
  %365 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 3
  %366 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 6
  %367 = extractvalue { float, float, float, float, float, float, float, float } %lo.w166, 7
  call void @llvm.nvvm.barrier0()
  %368 = zext nneg i32 %160 to i64
  %p2c.sm122 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %368
  %p2c.smp123 = ptrtoint ptr addrspace(3) %p2c.sm122 to i64
  %.not140 = icmp eq i64 %p2c.qo, 0
  %p2c.sz124 = select i1 %.not140, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp123, i64 %p2c.qo, i32 %p2c.sz124) #9
  %369 = zext nneg i32 %p2c.f87 to i64
  %p2c.sm125 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %369
  %p2c.smp126 = ptrtoint ptr addrspace(3) %p2c.sm125 to i64
  %.not141 = icmp eq i64 %p2c.qo82, 0
  %p2c.sz127 = select i1 %.not141, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp126, i64 %p2c.qo82, i32 %p2c.sz127) #9
  %370 = zext nneg i32 %p2c.f89 to i64
  %p2c.sm128 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %370
  %p2c.smp129 = ptrtoint ptr addrspace(3) %p2c.sm128 to i64
  %.not142 = icmp eq i64 %p2c.qo83, 0
  %p2c.sz130 = select i1 %.not142, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp129, i64 %p2c.qo83, i32 %p2c.sz130) #9
  %371 = zext nneg i32 %p2c.f91 to i64
  %p2c.sm131 = getelementptr [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %371
  %p2c.smp132 = ptrtoint ptr addrspace(3) %p2c.sm131 to i64
  %.not143 = icmp eq i64 %p2c.qo84, 0
  %p2c.sz133 = select i1 %.not143, i32 0, i32 16
  call void asm sideeffect "cp.async.cg.shared.global [$0], [$1], 16, $2;", "l,l,r,~{memory}"(i64 %p2c.smp132, i64 %p2c.qo84, i32 %p2c.sz133) #9
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.27 = icmp slt i32 %phi.45, 20480
  %phi.76.v = select i1 %isetrp_cmp1.27, i32 4096, i32 -20480
  %phi.76 = add i32 %phi.45, %phi.76.v
  %isetrp_cmp1.26 = icmp slt i32 %phi.44, 20480
  %phi.75.v = select i1 %isetrp_cmp1.26, i32 4096, i32 -20480
  %phi.75 = add i32 %phi.44, %phi.75.v
  %isetrp_cmp1.30 = icmp slt i32 %phi.47, 20480
  %phi.78.v = select i1 %isetrp_cmp1.30, i32 4096, i32 -20480
  %phi.78 = add i32 %phi.47, %phi.78.v
  %isetrp_cmp1.29 = icmp slt i32 %phi.46, 20480
  %phi.77.v = select i1 %isetrp_cmp1.29, i32 4096, i32 -20480
  %phi.77 = add i32 %phi.46, %phi.77.v
  %isetrp_cmp1.31 = icmp sgt i32 %phi.53, 0
  %.791 = getelementptr inbounds nuw i8, ptr %param_local, i64 1068
  %isetrp_rhs.9 = load i32, ptr %.791, align 4
  %isetrp_cmp1.32 = icmp sgt i32 %phi.53, %isetrp_rhs.9
  %iadd3_n1.39 = add i32 %phi.53, -1
  %isetrp_rhs.10 = load i32, ptr %.224, align 4
  %isetrp_cmp1.33 = icmp slt i32 %iadd3_n1.5, %isetrp_rhs.10
  %isetrp_cmp2.33 = or i1 %isetrp_cmp1.33, %isetrp_cmp1.32
  %sel.11 = select i1 %isetrp_cmp2.33, i32 %sel.9, i32 0
  %sel.12 = select i1 %isetrp_cmp2.33, i32 %sel.10, i32 0
  %.799 = getelementptr inbounds nuw i8, ptr %param_local, i64 1032
  %iadd3_o2.6 = load i32, ptr %.799, align 4
  %372 = zext i32 %iadd3_o2.6 to i64
  %373 = add i64 %163, %372
  %374 = zext i32 %iadd3_o2.6 to i64
  %375 = add i64 %164, %374
  %.805 = getelementptr inbounds nuw i8, ptr %param_local, i64 1036
  %iadd3_o2.8 = load i32, ptr %.805, align 4
  %376 = zext i32 %iadd3_o2.8 to i64
  %377 = shl nuw i64 %376, 32
  %378 = add i64 %373, %377
  %379 = zext i32 %iadd3_o2.8 to i64
  %380 = shl nuw i64 %379, 32
  %381 = add i64 %375, %380
  %.809 = getelementptr inbounds nuw i8, ptr %param_local, i64 1048
  %iadd3_o2.10 = load i32, ptr %.809, align 4
  %382 = zext i32 %iadd3_o2.10 to i64
  %383 = add i64 %162, %382
  %384 = zext i32 %iadd3_o2.10 to i64
  %385 = add i64 %161, %384
  %.813 = getelementptr inbounds nuw i8, ptr %param_local, i64 1052
  %iadd3_o2.12 = load i32, ptr %.813, align 4
  %386 = zext i32 %iadd3_o2.12 to i64
  %387 = shl nuw i64 %386, 32
  %388 = add i64 %383, %387
  %389 = zext i32 %iadd3_o2.12 to i64
  %390 = shl nuw i64 %389, 32
  %391 = add i64 %385, %390
  %392 = add i32 %p2c.qi, 1
  %393 = icmp eq i32 %392, 4
  %394 = select i1 %393, i32 0, i32 %392
  br i1 %isetrp_cmp1.31, label %BB_1190, label %BB_1580.loopexit

BB_1580.loopexit:                                 ; preds = %BB_1190
  %395 = trunc i64 %164 to i32
  %iadd3_trunc.10 = add i32 %iadd3_o2.6, %395
  br label %BB_1580

BB_1580:                                          ; preds = %BB_1580.loopexit, %BB_0df0
  %phi.79 = phi float [ 0.000000e+00, %BB_0df0 ], [ %365, %BB_1580.loopexit ]
  %phi.80 = phi float [ 0.000000e+00, %BB_0df0 ], [ %364, %BB_1580.loopexit ]
  %phi.81 = phi float [ 0.000000e+00, %BB_0df0 ], [ %363, %BB_1580.loopexit ]
  %phi.82 = phi float [ 0.000000e+00, %BB_0df0 ], [ %362, %BB_1580.loopexit ]
  %phi.83 = phi float [ 0.000000e+00, %BB_0df0 ], [ %361, %BB_1580.loopexit ]
  %phi.84 = phi float [ 0.000000e+00, %BB_0df0 ], [ %360, %BB_1580.loopexit ]
  %phi.85 = phi i32 [ %phi.32, %BB_0df0 ], [ %iadd3_trunc.10, %BB_1580.loopexit ]
  %phi.88 = phi float [ 0.000000e+00, %BB_0df0 ], [ %367, %BB_1580.loopexit ]
  %phi.89 = phi float [ 0.000000e+00, %BB_0df0 ], [ %366, %BB_1580.loopexit ]
  %ldc_const.2 = load i8, ptr %.181, align 1
  %isetrp_cmp1.34 = icmp ne i8 %ldc_const.2, 0
  %ldc_const.3 = load i8, ptr %.236, align 1
  %.825 = getelementptr inbounds nuw i8, ptr %param_local, i64 400
  %imad_addend.8 = load i32, ptr %.825, align 4
  %.827 = getelementptr inbounds nuw i8, ptr %param_local, i64 404
  %imad_addend.9 = load i32, ptr %.827, align 4
  %.830 = zext i32 %ctaid_z to i64
  %.831 = shl nuw i64 %.830, 32
  %.832 = ashr exact i64 %.831, 31
  %shf_hi.15 = lshr i64 %.832, 32
  %shf_result.19 = trunc nuw i64 %shf_hi.15 to i32
  %396 = sext i32 %ctaid_z to i64
  %397 = zext i32 %imad_addend.8 to i64
  %398 = zext i32 %imad_addend.9 to i64
  %399 = shl nuw i64 %398, 32
  %400 = or disjoint i64 %399, %397
  br i1 %isetrp_cmp1.34, label %BB_1620, label %BB_16c0

BB_1620:                                          ; preds = %BB_1580
  %isetrp_cmp1.35.not = icmp eq i8 %ldc_const.3, 0
  br i1 %isetrp_cmp1.35.not, label %BB_1690, label %BB_80001620

BB_1690:                                          ; preds = %BB_1620
  %.855 = shl nsw i64 %396, 3
  %401 = zext i32 %imad_addend.8 to i64
  %402 = zext i32 %imad_addend.9 to i64
  %403 = shl nuw i64 %402, 32
  %404 = add nsw i64 %.855, %401
  %405 = add i64 %404, %403
  %"R301:R135_addr_ptr" = inttoptr i64 %405 to ptr addrspace(1)
  %ldg_vec.211 = load i64, ptr addrspace(1) %"R301:R135_addr_ptr", align 8
  br label %BB_16c0

BB_80001620:                                      ; preds = %BB_1620
  %.862 = getelementptr inbounds nuw i8, ptr %param_local, i64 648
  %imad_rhs.30 = load i32, ptr %.862, align 4
  %.866 = getelementptr inbounds nuw i8, ptr %param_local, i64 652
  %imad_rhs.32 = load i32, ptr %.866, align 4
  %406 = zext i32 %imad_rhs.32 to i64
  %407 = shl nuw i64 %406, 32
  %408 = zext i32 %imad_rhs.30 to i64
  %409 = or disjoint i64 %407, %408
  %410 = mul i64 %409, %396
  %.886 = shl i64 %410, 1
  %411 = zext i32 %imad_addend.8 to i64
  %412 = zext i32 %imad_addend.9 to i64
  %413 = shl nuw i64 %412, 32
  %414 = add i64 %.886, %411
  %415 = add i64 %414, %413
  br label %BB_16c0

BB_16c0:                                          ; preds = %BB_80001620, %BB_1690, %BB_1580
  %416 = phi i64 [ %ldg_vec.211, %BB_1690 ], [ %400, %BB_1580 ], [ %415, %BB_80001620 ]
  %.893 = getelementptr inbounds nuw i8, ptr %param_local, i64 368
  %mov.4 = load i32, ptr %.893, align 4
  %.895 = getelementptr inbounds nuw i8, ptr %param_local, i64 372
  %mov.5 = load i32, ptr %.895, align 4
  %417 = zext i32 %mov.4 to i64
  %418 = zext i32 %mov.5 to i64
  %419 = shl nuw i64 %418, 32
  %420 = or disjoint i64 %419, %417
  br i1 %isetrp_cmp1.34, label %BB_1700, label %BB_17a0

BB_1700:                                          ; preds = %BB_16c0
  %isetrp_cmp1.36.not = icmp eq i8 %ldc_const.3, 0
  br i1 %isetrp_cmp1.36.not, label %BB_1770, label %BB_80001700

BB_1770:                                          ; preds = %BB_1700
  %.919 = shl nsw i64 %396, 3
  %421 = zext i32 %mov.4 to i64
  %422 = zext i32 %mov.5 to i64
  %423 = shl nuw i64 %422, 32
  %424 = add nsw i64 %.919, %421
  %425 = add i64 %424, %423
  %"R176:R534_addr_ptr" = inttoptr i64 %425 to ptr addrspace(1)
  %ldg_vec.312 = load i64, ptr addrspace(1) %"R176:R534_addr_ptr", align 8
  br label %BB_17a0

BB_80001700:                                      ; preds = %BB_1700
  %.926 = getelementptr inbounds nuw i8, ptr %param_local, i64 624
  %imad_rhs.33 = load i32, ptr %.926, align 4
  %.930 = getelementptr inbounds nuw i8, ptr %param_local, i64 628
  %imad_rhs.35 = load i32, ptr %.930, align 4
  %426 = zext i32 %imad_rhs.35 to i64
  %427 = shl nuw i64 %426, 32
  %428 = zext i32 %imad_rhs.33 to i64
  %429 = or disjoint i64 %427, %428
  %430 = mul i64 %429, %396
  %.950 = shl i64 %430, 1
  %431 = zext i32 %mov.4 to i64
  %432 = zext i32 %mov.5 to i64
  %433 = shl nuw i64 %432, 32
  %434 = add i64 %.950, %431
  %435 = add i64 %434, %433
  br label %BB_17a0

BB_17a0:                                          ; preds = %BB_80001700, %BB_1770, %BB_16c0
  %436 = phi i64 [ %ldg_vec.312, %BB_1770 ], [ %420, %BB_16c0 ], [ %435, %BB_80001700 ]
  %.957 = getelementptr inbounds nuw i8, ptr %param_local, i64 876
  %isetrp_rhs.11 = load i32, ptr %.957, align 4
  %isetrp_cmp1.37.not = icmp eq i32 %isetrp_rhs.11, 0
  br i1 %isetrp_cmp1.37.not, label %BB_1810, label %BB_800017b0

BB_800017b0:                                      ; preds = %BB_17a0
  %.961 = getelementptr inbounds nuw i8, ptr %param_local, i64 384
  %imad_addend.10 = load i32, ptr %.961, align 4
  %.963 = getelementptr inbounds nuw i8, ptr %param_local, i64 392
  %mov.6 = load i32, ptr %.963, align 4
  %.965 = getelementptr inbounds nuw i8, ptr %param_local, i64 388
  %imad_addend.11 = load i32, ptr %.965, align 4
  %.967 = getelementptr inbounds nuw i8, ptr %param_local, i64 396
  %imad_addend.12 = load i32, ptr %.967, align 4
  %ldg_addr_r0_ext.4 = zext i32 %imad_addend.10 to i64
  %ldg_addr_r1_ext.4 = zext i32 %imad_addend.11 to i64
  %ldg_addr_r1_shift.4 = shl nuw i64 %ldg_addr_r1_ext.4, 32
  %ldg_addr_packed_1.4 = or disjoint i64 %ldg_addr_r1_shift.4, %ldg_addr_r0_ext.4
  %"R939:R919_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.4 to ptr addrspace(1)
  %ldg = load i32, ptr addrspace(1) %"R939:R919_addr_ptr", align 4
  %ldg_addr_r0_ext.5 = zext i32 %mov.6 to i64
  %ldg_addr_r1_ext.5 = zext i32 %imad_addend.12 to i64
  %ldg_addr_r1_shift.5 = shl nuw i64 %ldg_addr_r1_ext.5, 32
  %ldg_addr_packed_1.5 = or disjoint i64 %ldg_addr_r1_shift.5, %ldg_addr_r0_ext.5
  %"R784:R759_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.5 to ptr addrspace(1)
  %ldg.1 = load i32, ptr addrspace(1) %"R784:R759_addr_ptr", align 4
  br label %BB_1810

BB_1810:                                          ; preds = %BB_800017b0, %BB_17a0
  %phi.96 = phi i32 [ %ldg.1, %BB_800017b0 ], [ %imad_tmp.51, %BB_17a0 ]
  %phi.97 = phi i32 [ %ldg, %BB_800017b0 ], [ %shf_result.19, %BB_17a0 ]
  %.974 = getelementptr inbounds nuw i8, ptr %param_local, i64 376
  %mov.7 = load i32, ptr %.974, align 4
  %437 = zext i32 %mov.7 to i64
  %.979 = getelementptr inbounds nuw i8, ptr %param_local, i64 380
  %imad_addend.13 = load i32, ptr %.979, align 4
  %438 = zext i32 %imad_addend.13 to i64
  %439 = shl nuw i64 %438, 32
  %440 = or disjoint i64 %439, %437
  br i1 %isetrp_cmp1.34, label %BB_80001870, label %BB_1880

BB_80001870:                                      ; preds = %BB_1810
  %.971 = getelementptr inbounds nuw i8, ptr %param_local, i64 980
  %imad_rhs.36 = load i32, ptr %.971, align 4
  %imad_tmp.77 = mul i32 %ctaid_z, %imad_rhs.36
  %imad_addend.14 = load i64, ptr %.974, align 8
  %imad_lhs_64.15 = sext i32 %imad_tmp.77 to i64
  %imad_tmp_64.15 = shl nsw i64 %imad_lhs_64.15, 1
  %441 = add i64 %imad_tmp_64.15, %imad_addend.14
  br label %BB_1880

BB_1880:                                          ; preds = %BB_80001870, %BB_1810
  %442 = phi i64 [ %441, %BB_80001870 ], [ %440, %BB_1810 ]
  %.986 = getelementptr inbounds nuw i8, ptr %param_local, i64 912
  %isetrp_rhs.12 = load i32, ptr %.986, align 4
  %isetrp_cmp1.38.not = icmp ne i32 %isetrp_rhs.12, 0
  %.995 = shl i32 %tid_x, 3
  %.1051 = and i32 %.995, 8
  %.1001 = lshr i64 %.189, 32
  %443 = trunc nuw i64 %.1001 to i32
  %444 = and i32 %443, 3
  %.1004 = add i32 %444, %tid_x
  %.1016 = and i32 %.1004, -4
  %imad.96 = sub i32 %tid_x, %.1016
  %.1022 = zext i32 %.1004 to i64
  %.1023 = shl nuw i64 %.1022, 32
  %.1024 = ashr exact i64 %.1023, 2
  %shf_hi.17 = lshr i64 %.1024, 32
  %shf_result.22 = trunc nuw i64 %shf_hi.17 to i32
  %imad_tmp.82 = mul i32 %shf_result.22, 10
  %imad.98 = add i32 %imad_tmp.82, %imad.96
  %445 = shl i32 %imad.96, 3
  %.1033 = zext i32 %sel.4 to i64
  %.1036 = shl nuw nsw i64 %.1033, 5
  %.1038 = add nuw nsw i64 %.1036, %shf_hi.17
  %.1039 = trunc i64 %.1038 to i32
  %sext = shl i64 %.1038, 32
  %446 = ashr exact i64 %sext, 32
  %447 = shl i32 %sel.5, 5
  %.1063 = add i32 %447, %445
  %isetrp_cmp1.39.not = icmp slt i32 %.1063, %isetrp_rhs.12
  %or.cond = select i1 %isetrp_cmp1.38.not, i1 %isetrp_cmp1.39.not, i1 false
  %.1043 = lshr i32 %tid_x, 1
  %448 = and i32 %.1043, 15
  %.107113 = or disjoint i32 %448, %.519
  %imad_tmp.85 = mul nuw nsw i32 %.107113, 80
  %.1073 = getelementptr inbounds nuw i8, ptr %param_local, i64 544
  %imad_rhs.37 = load i32, ptr %.1073, align 4
  %449 = zext i32 %imad_rhs.37 to i64
  %450 = lshr exact i32 %.473, 1
  %.108214 = or disjoint i32 %450, %.1051
  %imad.101 = add nuw nsw i32 %imad_tmp.85, %.108214
  %.1084 = getelementptr inbounds nuw i8, ptr %param_local, i64 536
  %imad_rhs.38 = load i32, ptr %.1084, align 4
  %451 = zext i32 %imad_rhs.38 to i64
  %452 = sext i32 %.1063 to i64
  %.1090 = getelementptr inbounds nuw i8, ptr %param_local, i64 548
  %imad_rhs.39 = load i32, ptr %.1090, align 4
  %453 = zext i32 %imad_rhs.39 to i64
  %454 = shl nuw i64 %453, 32
  %455 = or disjoint i64 %454, %449
  %456 = mul i64 %446, %455
  %457 = add i64 %456, %452
  %.1094 = getelementptr inbounds nuw i8, ptr %param_local, i64 540
  %imad_rhs.41 = load i32, ptr %.1094, align 4
  %458 = zext i32 %imad_rhs.41 to i64
  %459 = shl nuw i64 %458, 32
  %460 = or disjoint i64 %459, %451
  %461 = mul i64 %446, %460
  %462 = add i64 %461, %452
  %.1100 = getelementptr inbounds nuw i8, ptr %param_local, i64 880
  %imad_addend.15 = load i32, ptr %.1100, align 4
  %phi.103 = select i1 %isetrp_cmp1.37.not, i32 %imad_addend.15, i32 %phi.97
  %.1102 = getelementptr inbounds nuw i8, ptr %param_local, i64 896
  %mov.8 = load i32, ptr %.1102, align 4
  %phi.102 = select i1 %isetrp_cmp1.37.not, i32 %mov.8, i32 %phi.96
  br i1 %or.cond, label %BB_1ad0, label %BB_1b50

BB_1ad0:                                          ; preds = %BB_1880
  %.1124 = zext i32 %.1063 to i64
  %.1125 = shl nuw i64 %.1124, 32
  %.1145 = ashr exact i64 %.1125, 31
  %463 = add i64 %442, %.1145
  %"R840:R815_addr_ptr" = inttoptr i64 %463 to ptr addrspace(1)
  %ldg_vec.4 = load <4 x i32>, ptr addrspace(1) %"R840:R815_addr_ptr", align 16
  %ldg_lane0.4 = extractelement <4 x i32> %ldg_vec.4, i64 0
  %ldg_lane1.4 = extractelement <4 x i32> %ldg_vec.4, i64 1
  %ldg_lane2 = extractelement <4 x i32> %ldg_vec.4, i64 2
  %ldg_lane3 = extractelement <4 x i32> %ldg_vec.4, i64 3
  br label %BB_1b50

BB_1b50:                                          ; preds = %BB_1880, %BB_1ad0
  %phi.104 = phi i32 [ %ldg_lane3, %BB_1ad0 ], [ 0, %BB_1880 ]
  %phi.105 = phi i32 [ %ldg_lane2, %BB_1ad0 ], [ 0, %BB_1880 ]
  %phi.106 = phi i32 [ %ldg_lane1.4, %BB_1ad0 ], [ 0, %BB_1880 ]
  %phi.107 = phi i32 [ %ldg_lane0.4, %BB_1ad0 ], [ 0, %BB_1880 ]
  %.1153 = getelementptr inbounds nuw i8, ptr %param_local, i64 976
  %isetrp_rhs.14 = load i32, ptr %.1153, align 4
  %isetrp_cmp1.41 = icmp sgt i32 %isetrp_rhs.14, 0
  %isetrp_cmp2.41 = and i1 %isetrp_cmp1.41, %isetrp_cmp1.34
  br i1 %isetrp_cmp2.41, label %BB_1ba0, label %BB_80001b80

BB_1ba0:                                          ; preds = %BB_1b50
  %.1157 = getelementptr inbounds nuw i8, ptr %param_local, i64 873
  %ldc_const.4 = load i8, ptr %.1157, align 1
  %imad_tmp.90 = mul i32 %ctaid_z, %isetrp_rhs.14
  %.1164 = getelementptr inbounds nuw i8, ptr %param_local, i64 384
  %imad_addend.16 = load i64, ptr %.1164, align 8
  %imad_lhs_64.18 = sext i32 %imad_tmp.90 to i64
  %imad_tmp_64.18 = shl nsw i64 %imad_lhs_64.18, 2
  %464 = add i64 %imad_tmp_64.18, %imad_addend.16
  %"R305:R253_addr_ptr" = inttoptr i64 %464 to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R305:R253_addr_ptr", align 4
  %isetrp_cmp1.42.not = icmp eq i8 %ldc_const.4, 0
  br i1 %isetrp_cmp1.42.not, label %BB_1c60, label %BB_80001c20

BB_80001c20:                                      ; preds = %BB_1ba0
  %465 = sext i32 %imad_tmp.90 to i64
  %.1168 = getelementptr inbounds nuw i8, ptr %param_local, i64 392
  %lea_base.12 = load i32, ptr %.1168, align 4
  %.1179 = getelementptr inbounds nuw i8, ptr %param_local, i64 396
  %lea_base.13 = load i32, ptr %.1179, align 4
  %.1186 = shl nsw i64 %465, 2
  %466 = zext i32 %lea_base.12 to i64
  %467 = zext i32 %lea_base.13 to i64
  %468 = shl nuw i64 %467, 32
  %469 = add nsw i64 %.1186, %466
  %470 = add i64 %469, %468
  %"R789:R762_addr_ptr" = inttoptr i64 %470 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R789:R762_addr_ptr", align 4
  br label %BB_1c60

BB_1c60:                                          ; preds = %BB_1ba0, %BB_80001c20
  %phi.108 = phi float [ %ldg.3, %BB_80001c20 ], [ 0.000000e+00, %BB_1ba0 ]
  %prmt_res3 = and i32 %phi.85, -65536
  br i1 %isetrp_cmp1.42.not, label %BB_1c70, label %BB_80001c60

BB_80001c60:                                      ; preds = %BB_1c60
  %prmt_zext0.1 = zext i8 %ldc_const.4 to i32
  %471 = and i32 %phi.85, -65536
  %prmt_res3.1 = or disjoint i32 %471, %prmt_zext0.1
  br label %BB_1c70

BB_80001b80:                                      ; preds = %BB_1b50
  %.1196 = getelementptr inbounds nuw i8, ptr %param_local, i64 873
  %ldc_const.5 = load i8, ptr %.1196, align 1
  %ldc_zext.5 = zext i8 %ldc_const.5 to i32
  %phi_cast_R32_bitcast = bitcast i32 %phi.102 to float
  %phi_cast_R710_bitcast = bitcast i32 %phi.103 to float
  br label %BB_1c70

BB_1c70:                                          ; preds = %BB_80001b80, %BB_80001c60, %BB_1c60
  %phi.109 = phi i32 [ %ldc_zext.5, %BB_80001b80 ], [ %prmt_res3.1, %BB_80001c60 ], [ %prmt_res3, %BB_1c60 ]
  %phi.110 = phi float [ %phi_cast_R32_bitcast, %BB_80001b80 ], [ %phi.108, %BB_80001c60 ], [ %phi.108, %BB_1c60 ]
  %phi.111 = phi float [ %phi_cast_R710_bitcast, %BB_80001b80 ], [ %ldg.2, %BB_80001c60 ], [ %ldg.2, %BB_1c60 ]
  call void @llvm.nvvm.barrier0()
  %.1206 = getelementptr inbounds nuw i8, ptr %param_local, i64 704
  %imad_addend.17 = load i32, ptr %.1206, align 4
  %.1208 = getelementptr inbounds nuw i8, ptr %param_local, i64 996
  %imad_addend.18 = load i32, ptr %.1208, align 4
  %iadd3_n1.51 = add i32 %imad_addend.17, -1
  %.1210 = getelementptr inbounds nuw i8, ptr %param_local, i64 1000
  %imad_rhs.44 = load i32, ptr %.1210, align 4
  %imad_tmp.94 = mul i32 %imad_addend.18, %imad_rhs.44
  %isetrp_cmp1.43 = icmp eq i32 %ctaid_z, %iadd3_n1.51
  %isetrp_cmp2.43 = or i1 %isetrp_cmp1.43, %isetrp_cmp1.34
  %.1237 = shl i64 %457, 1
  %472 = add i64 %416, %.1237
  %imad_tmp.95 = mul i32 %s2ur_ctaid_y, %imad_addend.18
  %imad.114 = add i32 %imad_tmp.95, %s2ur_ctaid_x
  %.1217 = and i32 %phi.109, 255
  %.1202 = fcmp une float %phi.110, 0.000000e+00
  %sel.13 = zext i1 %.1202 to i32
  %.1222 = or i32 %.1217, %sel.13
  %lop3_pred_cmp.2.not = icmp eq i32 %.1222, 0
  br i1 %lop3_pred_cmp.2.not, label %BB_2cb0, label %BB_1dc0

BB_1dc0:                                          ; preds = %BB_1c70
  %isetrp_cmp1.44.not = icmp eq i32 %imad_addend.17, 1
  br i1 %isetrp_cmp1.44.not, label %BB_22d0, label %BB_1dd0

BB_1dd0:                                          ; preds = %BB_1dc0
  %.1249 = getelementptr inbounds nuw i8, ptr %param_local, i64 712
  %imad_addend.19 = load i32, ptr %.1249, align 4
  %.1251 = getelementptr inbounds nuw i8, ptr %param_local, i64 708
  %isetrp_rhs.15 = load i32, ptr %.1251, align 4
  %isetrp_cmp1.45.not = icmp ne i32 %imad_addend.17, %isetrp_rhs.15
  %isetrp_cmp1.46 = icmp ne i32 %imad_addend.19, 2
  %brmerge48 = select i1 %isetrp_cmp1.45.not, i1 true, i1 %isetrp_cmp1.46
  br i1 %brmerge48, label %BB_1e20, label %BB_22d0

BB_1e20:                                          ; preds = %BB_1dd0
  %isetrp_cmp1.47 = icmp eq i32 %imad_addend.19, 1
  %brmerge49.not = select i1 %isetrp_cmp2.43, i1 %isetrp_cmp1.47, i1 false
  br i1 %brmerge49.not, label %BB_2160, label %BB_1e40

BB_1e40:                                          ; preds = %BB_1e20
  %iabs_src = load i32, ptr %.1251, align 4
  %iabs = call i32 @llvm.abs.i32(i32 %iabs_src, i1 false)
  %iabs.1 = call i32 @llvm.abs.i32(i32 %ctaid_z, i1 false)
  %sdiv_div_zero = icmp eq i32 %iabs_src, 0
  %sdiv_safe_div = select i1 %sdiv_div_zero, i32 1, i32 %iabs
  %sdiv = udiv i32 %iabs.1, %sdiv_safe_div
  %473 = mul i32 %sdiv, %iabs
  %imad.117 = sub i32 %iabs.1, %473
  %.1273 = xor i32 %iabs_src, %ctaid_z
  %isetrp_cmp1.49 = icmp slt i32 %.1273, 0
  %isetrp_cmp1.48.not = icmp ule i32 %iabs, %imad.117
  %iadd3_n1.52 = zext i1 %isetrp_cmp1.48.not to i32
  %phi.112 = add i32 %sdiv, %iadd3_n1.52
  %imad.118 = select i1 %isetrp_cmp1.48.not, i32 %iabs, i32 0
  %phi.113 = sub nuw i32 %imad.117, %imad.118
  %isetrp_rhs.16 = load i32, ptr %.1251, align 4
  %isetrp_cmp1.50.not = icmp eq i32 %isetrp_rhs.16, 0
  %isetrp_cmp1.51.not = icmp uge i32 %phi.113, %iabs
  %iadd3_n1.53 = zext i1 %isetrp_cmp1.51.not to i32
  %phi.114 = add i32 %phi.112, %iadd3_n1.53
  %imad_addend_neg.6 = sub i32 0, %phi.114
  %phi.115 = select i1 %isetrp_cmp1.49, i32 %imad_addend_neg.6, i32 %phi.114
  %lop3_b.1 = load i32, ptr %.1251, align 4
  %.1292 = xor i32 %lop3_b.1, -1
  %phi.116 = select i1 %isetrp_cmp1.50.not, i32 %.1292, i32 %phi.115
  %isetrp_cmp1.52.not = icmp eq i32 %phi.116, 0
  %474 = mul i32 %phi.116, %lop3_b.1
  %imad.121 = sub i32 %ctaid_z, %474
  %not.isetrp_cmp1.52.not = xor i1 %isetrp_cmp1.52.not, true
  %sel.14 = zext i1 %not.isetrp_cmp1.52.not to i32
  %imad_tmp.103 = mul i32 %imad_tmp.94, %imad.121
  %imad.122 = add i32 %imad_tmp.103, %imad.114
  %.1308 = getelementptr inbounds nuw i8, ptr %param_local, i64 744
  %imad_addend.20 = load i64, ptr %.1308, align 8
  %imad_lhs_64.19 = sext i32 %imad.122 to i64
  %imad_tmp_64.19 = shl nsw i64 %imad_lhs_64.19, 2
  %imad.123 = add i64 %imad_tmp_64.19, %imad_addend.20
  %475 = add i64 %imad_tmp_64.19, %imad_addend.20
  %.1310 = getelementptr inbounds nuw i8, ptr %param_local, i64 752
  %imad_addend.21 = load i64, ptr %.1310, align 8
  %imad_lhs_64.20 = sext i32 %imad.114 to i64
  %imad_tmp_64.20 = shl nsw i64 %imad_lhs_64.20, 2
  %imad.124 = add i64 %imad_tmp_64.20, %imad_addend.21
  %isetrp_cmp1.54 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.54 = or i1 %isetrp_cmp1.54, %isetrp_cmp1.52.not
  br i1 %isetrp_cmp2.54, label %BB_2110, label %BB_2080.preheader

BB_2080.preheader:                                ; preds = %BB_1e40
  br label %BB_2080

BB_2080:                                          ; preds = %BB_2080.preheader, %BB_2080
  %ld_volatile = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %475) #9
  %isetrp_cmp1.55.not = icmp eq i32 %ld_volatile, %phi.116
  br i1 %isetrp_cmp1.55.not, label %BB_2110.loopexit, label %BB_2080

BB_2110.loopexit:                                 ; preds = %BB_2080
  br label %BB_2110

BB_2110:                                          ; preds = %BB_2110.loopexit, %BB_1e40
  call void @llvm.nvvm.barrier0()
  %phi_cast_R120_zext = and i64 %imad.123, 4294967295
  %phi_cast_R84_zext = and i64 %imad.124, 4294967295
  %476 = inttoptr i64 %phi_cast_R120_zext to ptr addrspace(1)
  br label %BB_22d0

BB_2160:                                          ; preds = %BB_1e20
  %isetrp_cmp1.56.not = icmp eq i32 %iadd3_n1.51, 0
  %imad_addend.22 = load i32, ptr %.1251, align 4
  %isetrp_cmp1.57 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.57 = or i1 %isetrp_cmp1.57, %isetrp_cmp1.56.not
  %.1319 = getelementptr inbounds nuw i8, ptr %param_local, i64 752
  %imad_addend.23 = load i64, ptr %.1319, align 8
  %imad_lhs_64.21 = sext i32 %imad.114 to i64
  %imad_tmp_64.21 = shl nsw i64 %imad_lhs_64.21, 2
  %imad.126 = add i64 %imad_tmp_64.21, %imad_addend.23
  %477 = add i64 %imad_tmp_64.21, %imad_addend.23
  %not.isetrp_cmp1.45.not = xor i1 %isetrp_cmp1.45.not, true
  %iadd3_n1.54 = sext i1 %not.isetrp_cmp1.45.not to i32
  %phi.117 = add i32 %imad_addend.22, %iadd3_n1.54
  br i1 %isetrp_cmp2.57, label %BB_2280, label %BB_21f0.preheader

BB_21f0.preheader:                                ; preds = %BB_2160
  br label %BB_21f0

BB_21f0:                                          ; preds = %BB_21f0.preheader, %BB_21f0
  %ld_volatile.1 = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %477) #9
  %isetrp_cmp1.58.not = icmp eq i32 %ld_volatile.1, %iadd3_n1.51
  br i1 %isetrp_cmp1.58.not, label %BB_2280.loopexit, label %BB_21f0

BB_2280.loopexit:                                 ; preds = %BB_21f0
  br label %BB_2280

BB_2280:                                          ; preds = %BB_2280.loopexit, %BB_2160
  call void @llvm.nvvm.barrier0()
  %phi_cast_R82_zext = and i64 %imad.126, 4294967295
  br label %BB_22d0

BB_22d0:                                          ; preds = %BB_1dd0, %BB_2280, %BB_2110, %BB_1dc0
  %isetrp_cmp1.67.not = phi i1 [ true, %BB_2110 ], [ true, %BB_2280 ], [ false, %BB_1dc0 ], [ false, %BB_1dd0 ]
  %phi.119 = phi i32 [ %imad.121, %BB_2110 ], [ 0, %BB_2280 ], [ 0, %BB_1dc0 ], [ %ctaid_z, %BB_1dd0 ]
  %phi.120 = phi i32 [ %sel.14, %BB_2110 ], [ %phi.117, %BB_2280 ], [ 0, %BB_1dc0 ], [ 0, %BB_1dd0 ]
  %phi.121 = phi ptr addrspace(1) [ %476, %BB_2110 ], [ null, %BB_2280 ], [ null, %BB_1dc0 ], [ null, %BB_1dd0 ]
  %phi.122 = phi i64 [ %phi_cast_R84_zext, %BB_2110 ], [ %phi_cast_R82_zext, %BB_2280 ], [ 0, %BB_1dc0 ], [ 0, %BB_1dd0 ]
  %mov.9 = load i32, ptr %.1206, align 4
  %.1332 = getelementptr inbounds nuw i8, ptr %param_local, i64 712
  %imad_addend.25 = load i32, ptr %.1332, align 4
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.60 = icmp eq i32 %imad_addend.25, 1
  %isetrp_cmp2.60 = and i1 %isetrp_cmp1.60, %isetrp_cmp2.43
  %.1338 = getelementptr inbounds nuw i8, ptr %param_local, i64 720
  %.1340 = getelementptr inbounds nuw i8, ptr %param_local, i64 724
  %isetrp_cmp1.59 = icmp slt i32 %mov.9, 2
  %phi_cast_R417_bitcast.1 = bitcast float %phi.79 to i32
  %phi_cast_R405_bitcast.1 = bitcast float %phi.80 to i32
  %478 = zext i32 %phi_cast_R417_bitcast.1 to i64
  %479 = shl nuw i64 %478, 32
  %480 = zext i32 %phi_cast_R405_bitcast.1 to i64
  %481 = or disjoint i64 %479, %480
  %phi_cast_R347_bitcast.1 = bitcast float %phi.81 to i32
  %phi_cast_R311_bitcast.1 = bitcast float %phi.82 to i32
  %482 = zext i32 %phi_cast_R347_bitcast.1 to i64
  %483 = shl nuw i64 %482, 32
  %484 = zext i32 %phi_cast_R311_bitcast.1 to i64
  %485 = or disjoint i64 %483, %484
  %phi_cast_R276_bitcast.1 = bitcast float %phi.83 to i32
  %phi_cast_R734_bitcast.1 = bitcast float %phi.84 to i32
  %486 = zext i32 %phi_cast_R276_bitcast.1 to i64
  %487 = shl nuw i64 %486, 32
  %488 = zext i32 %phi_cast_R734_bitcast.1 to i64
  %489 = or disjoint i64 %487, %488
  %phi_cast_R194_bitcast.1 = bitcast float %phi.88 to i32
  %phi_cast_R767_bitcast.1 = bitcast float %phi.89 to i32
  %490 = zext i32 %phi_cast_R194_bitcast.1 to i64
  %491 = shl nuw i64 %490, 32
  %492 = zext i32 %phi_cast_R767_bitcast.1 to i64
  %493 = or disjoint i64 %491, %492
  br i1 %isetrp_cmp1.59, label %BB_2650, label %BB_2360

BB_2360:                                          ; preds = %BB_22d0
  %imad_rhs.48 = load i32, ptr %.1340, align 4
  %494 = zext i32 %imad_rhs.48 to i64
  %495 = shl nuw i64 %494, 32
  %imad_rhs.47 = load i32, ptr %.1338, align 4
  %496 = zext i32 %imad_rhs.47 to i64
  %497 = or disjoint i64 %495, %496
  %498 = sext i32 %phi.119 to i64
  %imad_tmp.109 = shl i32 %imad_tmp.94, 7
  %499 = sext i32 %imad_tmp.109 to i64
  %500 = mul i64 %497, %498
  %.1353 = shl i32 %imad.114, 7
  %.1355 = add i32 %.1353, %tid_x
  %isetrp_cmp1.61 = icmp slt i32 %phi.120, 1
  br i1 %isetrp_cmp1.61, label %BB_25c0, label %BB_23e0

BB_23e0:                                          ; preds = %BB_2360
  %imad_tmp.111 = shl i32 %.1355, 4
  %.1368 = getelementptr inbounds nuw i8, ptr %param_local, i64 728
  %iadd3_o2.14 = load i32, ptr %.1368, align 4
  %501 = sext i32 %imad_tmp.111 to i64
  %.1379 = shl nsw i64 %499, 4
  %502 = add i64 %500, %.1379
  %.1387 = getelementptr inbounds nuw i8, ptr %param_local, i64 732
  %iadd3_o2.16 = load i32, ptr %.1387, align 4
  %503 = zext i32 %iadd3_o2.14 to i64
  %504 = zext i32 %iadd3_o2.16 to i64
  %505 = shl nuw i64 %504, 32
  %506 = add i64 %502, %501
  %507 = add i64 %506, %503
  %508 = add i64 %507, %505
  %509 = zext i32 %iadd3_o2.14 to i64
  %510 = zext i32 %iadd3_o2.16 to i64
  %511 = shl nuw i64 %510, 32
  %512 = add i64 %500, %501
  %513 = add i64 %512, %509
  %514 = add i64 %513, %511
  br label %BB_2470

BB_2470:                                          ; preds = %BB_2470, %BB_23e0
  %515 = phi i64 [ %508, %BB_23e0 ], [ %523, %BB_2470 ]
  %516 = phi i64 [ %514, %BB_23e0 ], [ %526, %BB_2470 ]
  %phi.123 = phi i32 [ 0, %BB_23e0 ], [ %iadd3_n1.57, %BB_2470 ]
  %phi.124 = phi float [ %phi.79, %BB_23e0 ], [ %fadd.5, %BB_2470 ]
  %phi.125 = phi float [ %phi.80, %BB_23e0 ], [ %fadd.4, %BB_2470 ]
  %phi.126 = phi float [ %phi.81, %BB_23e0 ], [ %fadd.3, %BB_2470 ]
  %phi.127 = phi float [ %phi.82, %BB_23e0 ], [ %fadd.2, %BB_2470 ]
  %phi.128 = phi float [ %phi.83, %BB_23e0 ], [ %fadd.1, %BB_2470 ]
  %phi.131 = phi float [ %phi.84, %BB_23e0 ], [ %fadd, %BB_2470 ]
  %phi.134 = phi float [ %phi.88, %BB_23e0 ], [ %fadd.7, %BB_2470 ]
  %phi.135 = phi float [ %phi.89, %BB_23e0 ], [ %fadd.6, %BB_2470 ]
  %ldv_volatile = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %516) #9
  %ldstrongv_lane3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 3
  %fadd_lhs_bitcast.3 = bitcast i32 %ldstrongv_lane3 to float
  %ldstrongv_lane2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 2
  %fadd_lhs_bitcast.2 = bitcast i32 %ldstrongv_lane2 to float
  %ldstrongv_lane1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 1
  %fadd_lhs_bitcast.1 = bitcast i32 %ldstrongv_lane1 to float
  %ldstrongv_lane0 = extractvalue { i32, i32, i32, i32 } %ldv_volatile, 0
  %fadd_lhs_bitcast = bitcast i32 %ldstrongv_lane0 to float
  %fadd = fadd float %phi.131, %fadd_lhs_bitcast
  %fadd.1 = fadd float %phi.128, %fadd_lhs_bitcast.1
  %fadd.2 = fadd float %phi.127, %fadd_lhs_bitcast.2
  %fadd.3 = fadd float %phi.126, %fadd_lhs_bitcast.3
  %ldv_volatile.1 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %515) #9
  %ldstrongv_lane3.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 3
  %fadd_lhs_bitcast.7 = bitcast i32 %ldstrongv_lane3.1 to float
  %ldstrongv_lane2.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 2
  %fadd_lhs_bitcast.6 = bitcast i32 %ldstrongv_lane2.1 to float
  %ldstrongv_lane1.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 1
  %fadd_lhs_bitcast.5 = bitcast i32 %ldstrongv_lane1.1 to float
  %ldstrongv_lane0.1 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.1, 0
  %fadd_lhs_bitcast.4 = bitcast i32 %ldstrongv_lane0.1 to float
  %fadd.4 = fadd float %phi.125, %fadd_lhs_bitcast.4
  %fadd.5 = fadd float %phi.124, %fadd_lhs_bitcast.5
  %fadd.6 = fadd float %phi.135, %fadd_lhs_bitcast.6
  %fadd.7 = fadd float %phi.134, %fadd_lhs_bitcast.7
  %iadd3_o2.18 = load i32, ptr %.1338, align 4
  %517 = zext i32 %iadd3_o2.18 to i64
  %518 = add i64 %515, %517
  %519 = zext i32 %iadd3_o2.18 to i64
  %520 = add i64 %516, %519
  %iadd3_o2.20 = load i32, ptr %.1340, align 4
  %521 = zext i32 %iadd3_o2.20 to i64
  %522 = shl nuw i64 %521, 32
  %523 = add i64 %518, %522
  %524 = zext i32 %iadd3_o2.20 to i64
  %525 = shl nuw i64 %524, 32
  %526 = add i64 %520, %525
  %iadd3_n1.57 = add i32 %phi.123, 1
  %isetrp_cmp1.62.not = icmp sgt i32 %phi.120, %iadd3_n1.57
  br i1 %isetrp_cmp1.62.not, label %BB_2470, label %BB_25c0.loopexit

BB_25c0.loopexit:                                 ; preds = %BB_2470
  %phi_cast_R419_bitcast = bitcast float %fadd.5 to i32
  %527 = zext i32 %phi_cast_R419_bitcast to i64
  %528 = shl nuw i64 %527, 32
  %phi_cast_R408_bitcast = bitcast float %fadd.4 to i32
  %529 = zext i32 %phi_cast_R408_bitcast to i64
  %530 = or disjoint i64 %528, %529
  %phi_cast_R209_bitcast = bitcast float %fadd.7 to i32
  %531 = zext i32 %phi_cast_R209_bitcast to i64
  %532 = shl nuw i64 %531, 32
  %phi_cast_R946_bitcast = bitcast float %fadd.6 to i32
  %533 = zext i32 %phi_cast_R946_bitcast to i64
  %534 = or disjoint i64 %532, %533
  %phi_cast_R280_bitcast = bitcast float %fadd.1 to i32
  %535 = zext i32 %phi_cast_R280_bitcast to i64
  %536 = shl nuw i64 %535, 32
  %phi_cast_R923_bitcast = bitcast float %fadd to i32
  %537 = zext i32 %phi_cast_R923_bitcast to i64
  %538 = or disjoint i64 %536, %537
  %phi_cast_R349_bitcast = bitcast float %fadd.3 to i32
  %539 = zext i32 %phi_cast_R349_bitcast to i64
  %540 = shl nuw i64 %539, 32
  %phi_cast_R314_bitcast = bitcast float %fadd.2 to i32
  %541 = zext i32 %phi_cast_R314_bitcast to i64
  %542 = or disjoint i64 %540, %541
  br label %BB_25c0

BB_25c0:                                          ; preds = %BB_25c0.loopexit, %BB_2360
  %543 = phi i64 [ %493, %BB_2360 ], [ %534, %BB_25c0.loopexit ]
  %544 = phi i64 [ %485, %BB_2360 ], [ %542, %BB_25c0.loopexit ]
  %545 = phi i64 [ %481, %BB_2360 ], [ %530, %BB_25c0.loopexit ]
  %546 = phi i64 [ %489, %BB_2360 ], [ %538, %BB_25c0.loopexit ]
  br i1 %isetrp_cmp2.60, label %BB_2650, label %BB_25d0

BB_25d0:                                          ; preds = %BB_25c0
  %547 = lshr i64 %544, 32
  %548 = lshr i64 %543, 32
  %imad_lhs_64.23 = sext i32 %.1355 to i64
  %imad_tmp_64.23 = shl nsw i64 %imad_lhs_64.23, 4
  %imad.135 = add i64 %imad_tmp_64.23, %500
  %549 = add i64 %imad_tmp_64.23, %500
  %.1403 = getelementptr inbounds nuw i8, ptr %param_local, i64 728
  %iadd3_o2.22 = load i32, ptr %.1403, align 4
  %.1405 = getelementptr inbounds nuw i8, ptr %param_local, i64 732
  %iadd3_o2.23 = load i32, ptr %.1405, align 4
  %550 = and i64 %imad.135, 4294967295
  %551 = zext i32 %iadd3_o2.22 to i64
  %552 = add nuw nsw i64 %550, %551
  %553 = zext i32 %iadd3_o2.22 to i64
  %554 = zext i32 %iadd3_o2.23 to i64
  %555 = shl nuw i64 %554, 32
  %556 = add i64 %549, %553
  %557 = add i64 %556, %555
  %stg_val_packed_1 = zext i64 %546 to i128
  %.mask = and i64 %544, 4294967295
  %stg_val_r2_ext = zext nneg i64 %.mask to i128
  %stg_val_r2_shift = shl nuw nsw i128 %stg_val_r2_ext, 64
  %stg_val_packed_2 = or disjoint i128 %stg_val_r2_shift, %stg_val_packed_1
  %stg_val_r3_ext = zext nneg i64 %547 to i128
  %stg_val_r3_shift = shl nuw i128 %stg_val_r3_ext, 96
  %stg_val_packed_3 = or disjoint i128 %stg_val_packed_2, %stg_val_r3_shift
  %"R677:R617_addr_ptr" = inttoptr i64 %557 to ptr addrspace(1)
  store i128 %stg_val_packed_3, ptr addrspace(1) %"R677:R617_addr_ptr", align 8
  %.1422 = shl nsw i64 %499, 4
  %558 = and i64 %imad.135, -4294967296
  %559 = zext i32 %iadd3_o2.23 to i64
  %560 = shl nuw i64 %559, 32
  %561 = add nsw i64 %552, %.1422
  %562 = add i64 %561, %558
  %563 = add i64 %562, %560
  %stg_val_packed_1.1 = zext i64 %545 to i128
  %.mask22 = and i64 %543, 4294967295
  %stg_val_r2_ext.1 = zext nneg i64 %.mask22 to i128
  %stg_val_r2_shift.1 = shl nuw nsw i128 %stg_val_r2_ext.1, 64
  %stg_val_packed_2.1 = or disjoint i128 %stg_val_r2_shift.1, %stg_val_packed_1.1
  %stg_val_r3_ext.1 = zext nneg i64 %548 to i128
  %stg_val_r3_shift.1 = shl nuw i128 %stg_val_r3_ext.1, 96
  %stg_val_packed_3.1 = or disjoint i128 %stg_val_packed_2.1, %stg_val_r3_shift.1
  %"R549:R274_addr_ptr" = inttoptr i64 %563 to ptr addrspace(1)
  store i128 %stg_val_packed_3.1, ptr addrspace(1) %"R549:R274_addr_ptr", align 8
  br label %BB_2650

BB_2650:                                          ; preds = %BB_25d0, %BB_25c0, %BB_22d0
  %564 = phi i64 [ %543, %BB_25d0 ], [ %493, %BB_22d0 ], [ %543, %BB_25c0 ]
  %565 = phi i64 [ %544, %BB_25d0 ], [ %485, %BB_22d0 ], [ %544, %BB_25c0 ]
  %566 = phi i64 [ %545, %BB_25d0 ], [ %481, %BB_22d0 ], [ %545, %BB_25c0 ]
  %567 = phi i64 [ %546, %BB_25d0 ], [ %489, %BB_22d0 ], [ %546, %BB_25c0 ]
  br i1 %isetrp_cmp2.60, label %BB_2660, label %BB_2b10

BB_2660:                                          ; preds = %BB_2650
  %.1434 = shl i32 %sel.5, 5
  %.1436 = add i32 %.1434, 32
  %isetrp_cmp1.63.not = icmp slt i32 %.1063, %.1436
  %isetrp_rhs.17 = load i32, ptr %.311, align 4
  %isetrp_cmp1.64.not = icmp slt i32 %.1063, %isetrp_rhs.17
  %568 = icmp slt i32 %sel.5, 0
  %569 = or i1 %568, %isetrp_cmp1.63.not
  %isetrp_rhs.18 = load i32, ptr %.234, align 4
  %isetrp_cmp1.65 = icmp sgt i32 %isetrp_rhs.18, %.1039
  %isetrp_cmp2.65 = and i1 %isetrp_cmp1.65, %isetrp_cmp1.64.not
  %isetrp_cmp2.66 = and i1 %569, %isetrp_cmp2.65
  br i1 %isetrp_cmp2.66, label %BB_80002730, label %BB_2740

BB_80002730:                                      ; preds = %BB_2660
  %.1480 = shl i64 %462, 1
  %570 = add i64 %436, %.1480
  %"R67:R61_addr_ptr" = inttoptr i64 %570 to ptr addrspace(1)
  %ldg_vec.5 = load <4 x i32>, ptr addrspace(1) %"R67:R61_addr_ptr", align 16
  %ldg_lane0.5 = extractelement <4 x i32> %ldg_vec.5, i64 0
  %ldg_lane1.5 = extractelement <4 x i32> %ldg_vec.5, i64 1
  %ldg_lane2.1 = extractelement <4 x i32> %ldg_vec.5, i64 2
  %ldg_lane3.1 = extractelement <4 x i32> %ldg_vec.5, i64 3
  br label %BB_2740

BB_2740:                                          ; preds = %BB_80002730, %BB_2660
  %phi.152 = phi i32 [ %ldg_lane3.1, %BB_80002730 ], [ 0, %BB_2660 ]
  %phi.153 = phi i32 [ %ldg_lane2.1, %BB_80002730 ], [ 0, %BB_2660 ]
  %phi.154 = phi i32 [ %ldg_lane1.5, %BB_80002730 ], [ 0, %BB_2660 ]
  %phi.155 = phi i32 [ %ldg_lane0.5, %BB_80002730 ], [ 0, %BB_2660 ]
  %571 = zext nneg i32 %imad.101 to i64
  %.1489 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %571
  store volatile i64 %567, ptr addrspace(3) %.1489, align 8
  %sts_addr_memaddr_offset_add = add nuw nsw i32 %imad.101, 16
  %572 = zext nneg i32 %sts_addr_memaddr_offset_add to i64
  %.1491 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %572
  store volatile i64 %566, ptr addrspace(3) %.1491, align 8
  %sts_addr_memaddr_offset_add.1 = add nuw nsw i32 %imad.101, 1280
  %573 = zext nneg i32 %sts_addr_memaddr_offset_add.1 to i64
  %.1493 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %573
  store volatile i64 %565, ptr addrspace(3) %.1493, align 8
  %sts_addr_memaddr_offset_add.2 = add nuw nsw i32 %imad.101, 1296
  %574 = zext nneg i32 %sts_addr_memaddr_offset_add.2 to i64
  %.1495 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %574
  store volatile i64 %564, ptr addrspace(3) %.1495, align 8
  call void @llvm.nvvm.barrier0()
  %lds_shared_addr_winoff.xscale = shl i32 %imad.98, 4
  %lds_shared_addr_winoff = and i32 %lds_shared_addr_winoff.xscale, 16777200
  %575 = zext nneg i32 %lds_shared_addr_winoff to i64
  %.1497 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %575
  %lds = load volatile i128, ptr addrspace(3) %.1497, align 8
  %lds_addr_memaddr_offset_add = add i32 %lds_shared_addr_winoff.xscale, 80
  %lds_shared_addr_winoff.1 = and i32 %lds_addr_memaddr_offset_add, 16777200
  %576 = zext nneg i32 %lds_shared_addr_winoff.1 to i64
  %.1498 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %576
  %lds.1 = load volatile i128, ptr addrspace(3) %.1498, align 8
  br i1 %isetrp_cmp2.66, label %BB_80002af0, label %BB_2b10

BB_80002af0:                                      ; preds = %BB_2740
  %extelt.offset30 = and i32 %phi.152, -65536
  %577 = lshr i32 %phi.152, 3
  %578 = and i32 %577, 268427264
  %579 = icmp samesign ugt i32 %578, 260046847
  %580 = select i1 %579, i32 2139095040, i32 0
  %581 = or i32 %578, %580
  %582 = bitcast i32 %581 to float
  %583 = fmul float %582, 0x46F0000000000000
  %584 = bitcast i32 %extelt.offset30 to float
  %585 = call float @llvm.copysign.f32(float %583, float %584)
  %"R19:R18:R17:R16_r3_shift.3" = lshr i128 %lds.1, 96
  %"R19:R18:R17:R16_r3.3" = trunc nuw i128 %"R19:R18:R17:R16_r3_shift.3" to i32
  %ffma_lhs_bitcast.7 = bitcast i32 %"R19:R18:R17:R16_r3.3" to float
  %extelt.offset26 = and i32 %phi.104, -65536
  %586 = lshr i32 %phi.104, 3
  %587 = and i32 %586, 268427264
  %588 = icmp samesign ugt i32 %587, 260046847
  %589 = select i1 %588, i32 2139095040, i32 0
  %590 = or i32 %587, %589
  %591 = bitcast i32 %590 to float
  %592 = fmul float %591, 0x46F0000000000000
  %593 = bitcast i32 %extelt.offset26 to float
  %594 = call float @llvm.copysign.f32(float %592, float %593)
  %ffma.7 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.7, float %phi.111, float %594)
  %ffma.15 = call float @llvm.fma.f32(float %585, float %phi.110, float %ffma.7)
  %.1499 = getelementptr inbounds nuw i8, ptr %param_local, i64 928
  %fmnmx_rhs = load float, ptr %.1499, align 4
  %fmnmx_max.7 = call float @llvm.maximum.f32(float %ffma.15, float %fmnmx_rhs)
  %.1515 = getelementptr inbounds nuw i8, ptr %param_local, i64 944
  %fmnmx_rhs.8 = load float, ptr %.1515, align 4
  %fmnmx_min.7 = call float @llvm.minimum.f32(float %fmnmx_max.7, float %fmnmx_rhs.8)
  %595 = shl i32 %phi.152, 16
  %596 = lshr exact i32 %595, 3
  %597 = and i32 %596, 268427264
  %598 = icmp samesign ugt i32 %597, 260046847
  %599 = select i1 %598, i32 2139095040, i32 0
  %600 = or i32 %597, %599
  %601 = bitcast i32 %600 to float
  %602 = fmul float %601, 0x46F0000000000000
  %603 = bitcast i32 %595 to float
  %604 = call float @llvm.copysign.f32(float %602, float %603)
  %"R19:R18:R17:R16_r2_shift.3" = lshr i128 %lds.1, 64
  %"R19:R18:R17:R16_r2.3" = trunc i128 %"R19:R18:R17:R16_r2_shift.3" to i32
  %ffma_lhs_bitcast.6 = bitcast i32 %"R19:R18:R17:R16_r2.3" to float
  %605 = shl i32 %phi.104, 16
  %606 = lshr exact i32 %605, 3
  %607 = and i32 %606, 268427264
  %608 = icmp samesign ugt i32 %607, 260046847
  %609 = select i1 %608, i32 2139095040, i32 0
  %610 = or i32 %607, %609
  %611 = bitcast i32 %610 to float
  %612 = fmul float %611, 0x46F0000000000000
  %613 = bitcast i32 %605 to float
  %614 = call float @llvm.copysign.f32(float %612, float %613)
  %ffma.6 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.6, float %phi.111, float %614)
  %ffma.14 = call float @llvm.fma.f32(float %604, float %phi.110, float %ffma.6)
  %fmnmx_max.6 = call float @llvm.maximum.f32(float %ffma.14, float %fmnmx_rhs)
  %fmnmx_min.6 = call float @llvm.minimum.f32(float %fmnmx_max.6, float %fmnmx_rhs.8)
  %extelt.offset29 = and i32 %phi.153, -65536
  %615 = lshr i32 %phi.153, 3
  %616 = and i32 %615, 268427264
  %617 = icmp samesign ugt i32 %616, 260046847
  %618 = select i1 %617, i32 2139095040, i32 0
  %619 = or i32 %616, %618
  %620 = bitcast i32 %619 to float
  %621 = fmul float %620, 0x46F0000000000000
  %622 = bitcast i32 %extelt.offset29 to float
  %623 = call float @llvm.copysign.f32(float %621, float %622)
  %"R19:R18:R17:R16_r1_shift.3" = lshr i128 %lds.1, 32
  %"R19:R18:R17:R16_r1.3" = trunc i128 %"R19:R18:R17:R16_r1_shift.3" to i32
  %ffma_lhs_bitcast.5 = bitcast i32 %"R19:R18:R17:R16_r1.3" to float
  %extelt.offset25 = and i32 %phi.105, -65536
  %624 = lshr i32 %phi.105, 3
  %625 = and i32 %624, 268427264
  %626 = icmp samesign ugt i32 %625, 260046847
  %627 = select i1 %626, i32 2139095040, i32 0
  %628 = or i32 %625, %627
  %629 = bitcast i32 %628 to float
  %630 = fmul float %629, 0x46F0000000000000
  %631 = bitcast i32 %extelt.offset25 to float
  %632 = call float @llvm.copysign.f32(float %630, float %631)
  %ffma.5 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.5, float %phi.111, float %632)
  %ffma.13 = call float @llvm.fma.f32(float %623, float %phi.110, float %ffma.5)
  %fmnmx_max.5 = call float @llvm.maximum.f32(float %ffma.13, float %fmnmx_rhs)
  %fmnmx_min.5 = call float @llvm.minimum.f32(float %fmnmx_max.5, float %fmnmx_rhs.8)
  %633 = shl i32 %phi.153, 16
  %634 = lshr exact i32 %633, 3
  %635 = and i32 %634, 268427264
  %636 = icmp samesign ugt i32 %635, 260046847
  %637 = select i1 %636, i32 2139095040, i32 0
  %638 = or i32 %635, %637
  %639 = bitcast i32 %638 to float
  %640 = fmul float %639, 0x46F0000000000000
  %641 = bitcast i32 %633 to float
  %642 = call float @llvm.copysign.f32(float %640, float %641)
  %"R19:R18:R17:R16_r0.3" = trunc i128 %lds.1 to i32
  %ffma_lhs_bitcast.4 = bitcast i32 %"R19:R18:R17:R16_r0.3" to float
  %643 = shl i32 %phi.105, 16
  %644 = lshr exact i32 %643, 3
  %645 = and i32 %644, 268427264
  %646 = icmp samesign ugt i32 %645, 260046847
  %647 = select i1 %646, i32 2139095040, i32 0
  %648 = or i32 %645, %647
  %649 = bitcast i32 %648 to float
  %650 = fmul float %649, 0x46F0000000000000
  %651 = bitcast i32 %643 to float
  %652 = call float @llvm.copysign.f32(float %650, float %651)
  %ffma.4 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.4, float %phi.111, float %652)
  %ffma.10 = call float @llvm.fma.f32(float %642, float %phi.110, float %ffma.4)
  %fmnmx_max.4 = call float @llvm.maximum.f32(float %ffma.10, float %fmnmx_rhs)
  %fmnmx_min.4 = call float @llvm.minimum.f32(float %fmnmx_max.4, float %fmnmx_rhs.8)
  %653 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min.7, float %fmnmx_min.6, float %fmnmx_min.5, float %fmnmx_min.4)
  %654 = extractvalue { i32, i32, i32, i32 } %653, 0
  %655 = extractvalue { i32, i32, i32, i32 } %653, 1
  %656 = extractvalue { i32, i32, i32, i32 } %653, 2
  %657 = extractvalue { i32, i32, i32, i32 } %653, 3
  %f2fp_a_shift.3 = shl nuw i32 %654, 16
  %f2fp_packed.3 = or disjoint i32 %f2fp_a_shift.3, %655
  %stg_val_r3_ext.2 = zext i32 %f2fp_packed.3 to i128
  %stg_val_r3_shift.2 = shl nuw i128 %stg_val_r3_ext.2, 96
  %f2fp_a_shift.2 = shl nuw i32 %656, 16
  %f2fp_packed.2 = or disjoint i32 %f2fp_a_shift.2, %657
  %stg_val_r2_ext.2 = zext i32 %f2fp_packed.2 to i128
  %stg_val_r2_shift.2 = shl nuw nsw i128 %stg_val_r2_ext.2, 64
  %extelt.offset27 = and i32 %phi.154, -65536
  %658 = lshr i32 %phi.154, 3
  %659 = and i32 %658, 268427264
  %660 = icmp samesign ugt i32 %659, 260046847
  %661 = select i1 %660, i32 2139095040, i32 0
  %662 = or i32 %659, %661
  %663 = bitcast i32 %662 to float
  %664 = fmul float %663, 0x46F0000000000000
  %665 = bitcast i32 %extelt.offset27 to float
  %666 = call float @llvm.copysign.f32(float %664, float %665)
  %"R27:R26:R25:R24_r3_shift.2" = lshr i128 %lds, 96
  %"R27:R26:R25:R24_r3.2" = trunc nuw i128 %"R27:R26:R25:R24_r3_shift.2" to i32
  %ffma_lhs_bitcast = bitcast i32 %"R27:R26:R25:R24_r3.2" to float
  %extelt.offset = and i32 %phi.106, -65536
  %667 = lshr i32 %phi.106, 3
  %668 = and i32 %667, 268427264
  %669 = icmp samesign ugt i32 %668, 260046847
  %670 = select i1 %669, i32 2139095040, i32 0
  %671 = or i32 %668, %670
  %672 = bitcast i32 %671 to float
  %673 = fmul float %672, 0x46F0000000000000
  %674 = bitcast i32 %extelt.offset to float
  %675 = call float @llvm.copysign.f32(float %673, float %674)
  %ffma = call float @llvm.fma.f32(float %ffma_lhs_bitcast, float %phi.111, float %675)
  %ffma.9 = call float @llvm.fma.f32(float %666, float %phi.110, float %ffma)
  %fmnmx_max = call float @llvm.maximum.f32(float %ffma.9, float %fmnmx_rhs)
  %fmnmx_min = call float @llvm.minimum.f32(float %fmnmx_max, float %fmnmx_rhs.8)
  %676 = shl i32 %phi.154, 16
  %677 = lshr exact i32 %676, 3
  %678 = and i32 %677, 268427264
  %679 = icmp samesign ugt i32 %678, 260046847
  %680 = select i1 %679, i32 2139095040, i32 0
  %681 = or i32 %678, %680
  %682 = bitcast i32 %681 to float
  %683 = fmul float %682, 0x46F0000000000000
  %684 = bitcast i32 %676 to float
  %685 = call float @llvm.copysign.f32(float %683, float %684)
  %"R27:R26:R25:R24_r2_shift.2" = lshr i128 %lds, 64
  %"R27:R26:R25:R24_r2.2" = trunc i128 %"R27:R26:R25:R24_r2_shift.2" to i32
  %ffma_lhs_bitcast.3 = bitcast i32 %"R27:R26:R25:R24_r2.2" to float
  %686 = shl i32 %phi.106, 16
  %687 = lshr exact i32 %686, 3
  %688 = and i32 %687, 268427264
  %689 = icmp samesign ugt i32 %688, 260046847
  %690 = select i1 %689, i32 2139095040, i32 0
  %691 = or i32 %688, %690
  %692 = bitcast i32 %691 to float
  %693 = fmul float %692, 0x46F0000000000000
  %694 = bitcast i32 %686 to float
  %695 = call float @llvm.copysign.f32(float %693, float %694)
  %ffma.3 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.3, float %phi.111, float %695)
  %ffma.12 = call float @llvm.fma.f32(float %685, float %phi.110, float %ffma.3)
  %fmnmx_max.3 = call float @llvm.maximum.f32(float %ffma.12, float %fmnmx_rhs)
  %fmnmx_min.3 = call float @llvm.minimum.f32(float %fmnmx_max.3, float %fmnmx_rhs.8)
  %extelt.offset28 = and i32 %phi.155, -65536
  %696 = lshr i32 %phi.155, 3
  %697 = and i32 %696, 268427264
  %698 = icmp samesign ugt i32 %697, 260046847
  %699 = select i1 %698, i32 2139095040, i32 0
  %700 = or i32 %697, %699
  %701 = bitcast i32 %700 to float
  %702 = fmul float %701, 0x46F0000000000000
  %703 = bitcast i32 %extelt.offset28 to float
  %704 = call float @llvm.copysign.f32(float %702, float %703)
  %"R27:R26:R25:R24_r1_shift.2" = lshr i128 %lds, 32
  %"R27:R26:R25:R24_r1.2" = trunc i128 %"R27:R26:R25:R24_r1_shift.2" to i32
  %ffma_lhs_bitcast.2 = bitcast i32 %"R27:R26:R25:R24_r1.2" to float
  %extelt.offset24 = and i32 %phi.107, -65536
  %705 = lshr i32 %phi.107, 3
  %706 = and i32 %705, 268427264
  %707 = icmp samesign ugt i32 %706, 260046847
  %708 = select i1 %707, i32 2139095040, i32 0
  %709 = or i32 %706, %708
  %710 = bitcast i32 %709 to float
  %711 = fmul float %710, 0x46F0000000000000
  %712 = bitcast i32 %extelt.offset24 to float
  %713 = call float @llvm.copysign.f32(float %711, float %712)
  %ffma.2 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.2, float %phi.111, float %713)
  %ffma.11 = call float @llvm.fma.f32(float %704, float %phi.110, float %ffma.2)
  %fmnmx_max.2 = call float @llvm.maximum.f32(float %ffma.11, float %fmnmx_rhs)
  %fmnmx_min.2 = call float @llvm.minimum.f32(float %fmnmx_max.2, float %fmnmx_rhs.8)
  %714 = shl i32 %phi.155, 16
  %715 = lshr exact i32 %714, 3
  %716 = and i32 %715, 268427264
  %717 = icmp samesign ugt i32 %716, 260046847
  %718 = select i1 %717, i32 2139095040, i32 0
  %719 = or i32 %716, %718
  %720 = bitcast i32 %719 to float
  %721 = fmul float %720, 0x46F0000000000000
  %722 = bitcast i32 %714 to float
  %723 = call float @llvm.copysign.f32(float %721, float %722)
  %"R27:R26:R25:R24_r0.2" = trunc i128 %lds to i32
  %ffma_lhs_bitcast.1 = bitcast i32 %"R27:R26:R25:R24_r0.2" to float
  %724 = shl i32 %phi.107, 16
  %725 = lshr exact i32 %724, 3
  %726 = and i32 %725, 268427264
  %727 = icmp samesign ugt i32 %726, 260046847
  %728 = select i1 %727, i32 2139095040, i32 0
  %729 = or i32 %726, %728
  %730 = bitcast i32 %729 to float
  %731 = fmul float %730, 0x46F0000000000000
  %732 = bitcast i32 %724 to float
  %733 = call float @llvm.copysign.f32(float %731, float %732)
  %ffma.1 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.1, float %phi.111, float %733)
  %ffma.8 = call float @llvm.fma.f32(float %723, float %phi.110, float %ffma.1)
  %fmnmx_max.1 = call float @llvm.maximum.f32(float %ffma.8, float %fmnmx_rhs)
  %fmnmx_min.1 = call float @llvm.minimum.f32(float %fmnmx_max.1, float %fmnmx_rhs.8)
  %734 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min, float %fmnmx_min.3, float %fmnmx_min.2, float %fmnmx_min.1)
  %735 = extractvalue { i32, i32, i32, i32 } %734, 0
  %736 = extractvalue { i32, i32, i32, i32 } %734, 1
  %737 = extractvalue { i32, i32, i32, i32 } %734, 2
  %738 = extractvalue { i32, i32, i32, i32 } %734, 3
  %f2fp_a_shift.1 = shl nuw i32 %735, 16
  %f2fp_packed.1 = or disjoint i32 %f2fp_a_shift.1, %736
  %stg_val_r1_ext.2 = zext i32 %f2fp_packed.1 to i128
  %stg_val_r1_shift.2 = shl nuw nsw i128 %stg_val_r1_ext.2, 32
  %f2fp_a_shift = shl nuw i32 %737, 16
  %f2fp_packed = or disjoint i32 %f2fp_a_shift, %738
  %stg_val_r0_ext.2 = zext i32 %f2fp_packed to i128
  %stg_val_packed_1.2 = or disjoint i128 %stg_val_r1_shift.2, %stg_val_r0_ext.2
  %stg_val_packed_2.2 = or disjoint i128 %stg_val_packed_1.2, %stg_val_r2_shift.2
  %stg_val_packed_3.2 = or disjoint i128 %stg_val_packed_2.2, %stg_val_r3_shift.2
  %"R235:R68_addr_ptr_smfix_inwin.unshifted" = xor i64 %472, ptrtoint (ptr addrspacecast (ptr addrspace(3) @shared_mem to ptr) to i64)
  %"R235:R68_addr_ptr_smfix_inwin" = icmp ult i64 %"R235:R68_addr_ptr_smfix_inwin.unshifted", 4294967296
  %"R235:R68_addr_ptr_smfix_w" = and i64 ptrtoint (ptr addrspacecast (ptr addrspace(3) @shared_mem to ptr) to i64), 16777215
  %"R235:R68_addr_ptr_smfix_biased" = select i1 %"R235:R68_addr_ptr_smfix_inwin", i64 %"R235:R68_addr_ptr_smfix_w", i64 0
  %"R235:R68_addr_ptr_smfix" = add i64 %472, %"R235:R68_addr_ptr_smfix_biased"
  %"R235:R68_addr_ptr" = inttoptr i64 %"R235:R68_addr_ptr_smfix" to ptr
  store i128 %stg_val_packed_3.2, ptr %"R235:R68_addr_ptr", align 8
  br label %BB_2b10

BB_2b10:                                          ; preds = %BB_2650, %BB_2740, %BB_80002af0
  %739 = zext i1 %isetrp_cmp1.67.not to i32
  %740 = icmp ne i32 %739, 0
  br i1 %740, label %BB_2b20, label %BB_39b0

BB_2b20:                                          ; preds = %BB_2b10
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.68.not = icmp eq i32 %tid_x, 0
  br i1 %isetrp_cmp1.68.not, label %BB_2bb0, label %BB_39b0

BB_2bb0:                                          ; preds = %BB_2b20
  %warp_reconv_mask.1 = call i32 asm sideeffect "activemask.b32 $0;", "=r"() #9
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  call void @llvm.nvvm.membar.gl()
  br i1 %isetrp_cmp2.43, label %BB_2c10, label %BB_2bf0

BB_2bf0:                                          ; preds = %BB_2bb0
  %red_add = atomicrmw add ptr addrspace(1) %phi.121, i32 1 monotonic, align 4
  br label %BB_2c10

BB_2c10:                                          ; preds = %BB_2bf0, %BB_2bb0
  %red_ptr.1 = inttoptr i64 %phi.122 to ptr addrspace(1)
  %red_add.1 = atomicrmw add ptr addrspace(1) %red_ptr.1, i32 1 monotonic, align 4
  br label %BB_39b0

BB_2cb0:                                          ; preds = %BB_1c70
  %isetrp_cmp1.69.not = icmp eq i32 %imad_addend.17, 1
  br i1 %isetrp_cmp1.69.not, label %BB_31d0, label %BB_2cc0

BB_2cc0:                                          ; preds = %BB_2cb0
  %.1547 = getelementptr inbounds nuw i8, ptr %param_local, i64 712
  %imad_addend.26 = load i32, ptr %.1547, align 4
  %.1549 = getelementptr inbounds nuw i8, ptr %param_local, i64 708
  %isetrp_rhs.19 = load i32, ptr %.1549, align 4
  %isetrp_cmp1.70.not = icmp ne i32 %imad_addend.17, %isetrp_rhs.19
  %isetrp_cmp1.71 = icmp ne i32 %imad_addend.26, 2
  %brmerge50 = select i1 %isetrp_cmp1.70.not, i1 true, i1 %isetrp_cmp1.71
  br i1 %brmerge50, label %BB_2d10, label %BB_31d0

BB_2d10:                                          ; preds = %BB_2cc0
  %isetrp_cmp1.72 = icmp eq i32 %imad_addend.26, 1
  %brmerge52.not = select i1 %isetrp_cmp2.43, i1 %isetrp_cmp1.72, i1 false
  br i1 %brmerge52.not, label %BB_3060, label %BB_2d30

BB_2d30:                                          ; preds = %BB_2d10
  %iabs_src.1 = load i32, ptr %.1549, align 4
  %iabs.2 = call i32 @llvm.abs.i32(i32 %iabs_src.1, i1 false)
  %iabs.3 = call i32 @llvm.abs.i32(i32 %ctaid_z, i1 false)
  %sdiv_div_zero.1 = icmp eq i32 %iabs_src.1, 0
  %sdiv_safe_div.1 = select i1 %sdiv_div_zero.1, i32 1, i32 %iabs.2
  %sdiv.1 = udiv i32 %iabs.3, %sdiv_safe_div.1
  %741 = mul i32 %sdiv.1, %iabs.2
  %imad.138 = sub i32 %iabs.3, %741
  %isetrp_cmp1.73.not = icmp ule i32 %iabs.2, %imad.138
  %iadd3_n1.61 = select i1 %isetrp_cmp1.73.not, i32 %iabs.2, i32 0
  %phi.156 = sub nuw i32 %imad.138, %iadd3_n1.61
  %iadd3_n1.62 = zext i1 %isetrp_cmp1.73.not to i32
  %phi.157 = add i32 %sdiv.1, %iadd3_n1.62
  %lop3_b.2 = load i32, ptr %.1549, align 4
  %.1574 = xor i32 %lop3_b.2, %ctaid_z
  %isetrp_cmp1.75.not = icmp eq i32 %lop3_b.2, 0
  %isetrp_cmp1.76 = icmp slt i32 %.1574, 0
  %isetrp_cmp1.74.not = icmp uge i32 %phi.156, %iabs.2
  %iadd3_n1.63 = zext i1 %isetrp_cmp1.74.not to i32
  %phi.158 = add i32 %phi.157, %iadd3_n1.63
  %imad_addend_neg.9 = sub i32 0, %phi.158
  %phi.159 = select i1 %isetrp_cmp1.76, i32 %imad_addend_neg.9, i32 %phi.158
  %lop3_b.3 = load i32, ptr %.1549, align 4
  %.1590 = xor i32 %lop3_b.3, -1
  %phi.160 = select i1 %isetrp_cmp1.75.not, i32 %.1590, i32 %phi.159
  %isetrp_cmp1.77.not = icmp eq i32 %phi.160, 0
  %742 = mul i32 %phi.160, %lop3_b.3
  %imad.141 = sub i32 %ctaid_z, %742
  %not.isetrp_cmp1.77.not = xor i1 %isetrp_cmp1.77.not, true
  %sel.16 = zext i1 %not.isetrp_cmp1.77.not to i32
  %imad_tmp.118 = mul i32 %imad_tmp.94, %imad.141
  %imad.142 = add i32 %imad_tmp.118, %imad.114
  %.1606 = getelementptr inbounds nuw i8, ptr %param_local, i64 744
  %imad_addend.27 = load i64, ptr %.1606, align 8
  %imad_lhs_64.24 = sext i32 %imad.142 to i64
  %imad_tmp_64.24 = shl nsw i64 %imad_lhs_64.24, 2
  %imad.143 = add i64 %imad_tmp_64.24, %imad_addend.27
  %743 = add i64 %imad_tmp_64.24, %imad_addend.27
  %.1608 = getelementptr inbounds nuw i8, ptr %param_local, i64 752
  %imad_addend.28 = load i64, ptr %.1608, align 8
  %imad_lhs_64.25 = sext i32 %imad.114 to i64
  %imad_tmp_64.25 = shl nsw i64 %imad_lhs_64.25, 2
  %imad.144 = add i64 %imad_tmp_64.25, %imad_addend.28
  %isetrp_cmp1.78 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.78 = or i1 %isetrp_cmp1.78, %isetrp_cmp1.77.not
  br i1 %isetrp_cmp2.78, label %BB_3010, label %BB_2f80.preheader

BB_2f80.preheader:                                ; preds = %BB_2d30
  br label %BB_2f80

BB_2f80:                                          ; preds = %BB_2f80.preheader, %BB_2f80
  %ld_volatile.2 = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %743) #9
  %isetrp_cmp1.80.not = icmp eq i32 %ld_volatile.2, %phi.160
  br i1 %isetrp_cmp1.80.not, label %BB_3010.loopexit, label %BB_2f80

BB_3010.loopexit:                                 ; preds = %BB_2f80
  br label %BB_3010

BB_3010:                                          ; preds = %BB_3010.loopexit, %BB_2d30
  call void @llvm.nvvm.barrier0()
  %phi_cast_R926_zext = and i64 %imad.143, 4294967295
  %phi_cast_R812_zext = and i64 %imad.144, 4294967295
  %744 = inttoptr i64 %phi_cast_R926_zext to ptr addrspace(1)
  br label %BB_31d0

BB_3060:                                          ; preds = %BB_2d10
  %isetrp_cmp1.81.not = icmp eq i32 %iadd3_n1.51, 0
  %imad_addend.29 = load i32, ptr %.1549, align 4
  %isetrp_cmp1.82 = icmp ne i32 %tid_x, 0
  %isetrp_cmp2.82 = or i1 %isetrp_cmp1.82, %isetrp_cmp1.81.not
  %.1617 = getelementptr inbounds nuw i8, ptr %param_local, i64 752
  %imad_addend.30 = load i64, ptr %.1617, align 8
  %imad_lhs_64.26 = sext i32 %imad.114 to i64
  %imad_tmp_64.26 = shl nsw i64 %imad_lhs_64.26, 2
  %imad.146 = add i64 %imad_tmp_64.26, %imad_addend.30
  %745 = add i64 %imad_tmp_64.26, %imad_addend.30
  %not.isetrp_cmp1.70.not = xor i1 %isetrp_cmp1.70.not, true
  %iadd3_n1.65 = sext i1 %not.isetrp_cmp1.70.not to i32
  %phi.161 = add i32 %imad_addend.29, %iadd3_n1.65
  br i1 %isetrp_cmp2.82, label %BB_3180, label %BB_30f0.preheader

BB_30f0.preheader:                                ; preds = %BB_3060
  br label %BB_30f0

BB_30f0:                                          ; preds = %BB_30f0.preheader, %BB_30f0
  %ld_volatile.3 = call i32 asm sideeffect "ld.volatile.global.b32 $0, [$1];", "=r,l,~{memory}"(i64 %745) #9
  %isetrp_cmp1.83.not = icmp eq i32 %ld_volatile.3, %iadd3_n1.51
  br i1 %isetrp_cmp1.83.not, label %BB_3180.loopexit, label %BB_30f0

BB_3180.loopexit:                                 ; preds = %BB_30f0
  br label %BB_3180

BB_3180:                                          ; preds = %BB_3180.loopexit, %BB_3060
  call void @llvm.nvvm.barrier0()
  %phi_cast_R690_zext = and i64 %imad.146, 4294967295
  br label %BB_31d0

BB_31d0:                                          ; preds = %BB_2cc0, %BB_3180, %BB_3010, %BB_2cb0
  %isetrp_cmp1.92.not = phi i1 [ true, %BB_3010 ], [ true, %BB_3180 ], [ false, %BB_2cb0 ], [ false, %BB_2cc0 ]
  %phi.163 = phi i32 [ %imad.141, %BB_3010 ], [ 0, %BB_3180 ], [ 0, %BB_2cb0 ], [ %ctaid_z, %BB_2cc0 ]
  %phi.164 = phi i32 [ %sel.16, %BB_3010 ], [ %phi.161, %BB_3180 ], [ 0, %BB_2cb0 ], [ 0, %BB_2cc0 ]
  %phi.165 = phi ptr addrspace(1) [ %744, %BB_3010 ], [ null, %BB_3180 ], [ null, %BB_2cb0 ], [ null, %BB_2cc0 ]
  %phi.166 = phi i64 [ %phi_cast_R812_zext, %BB_3010 ], [ %phi_cast_R690_zext, %BB_3180 ], [ 0, %BB_2cb0 ], [ 0, %BB_2cc0 ]
  %mov.10 = load i32, ptr %.1206, align 4
  %.1630 = getelementptr inbounds nuw i8, ptr %param_local, i64 712
  %imad_addend.32 = load i32, ptr %.1630, align 4
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.85 = icmp eq i32 %imad_addend.32, 1
  %isetrp_cmp2.85 = and i1 %isetrp_cmp1.85, %isetrp_cmp2.43
  %.1636 = getelementptr inbounds nuw i8, ptr %param_local, i64 720
  %.1638 = getelementptr inbounds nuw i8, ptr %param_local, i64 724
  %isetrp_cmp1.84 = icmp slt i32 %mov.10, 2
  %phi_cast_R417_bitcast.3 = bitcast float %phi.79 to i32
  %phi_cast_R405_bitcast.3 = bitcast float %phi.80 to i32
  %746 = zext i32 %phi_cast_R417_bitcast.3 to i64
  %747 = shl nuw i64 %746, 32
  %748 = zext i32 %phi_cast_R405_bitcast.3 to i64
  %749 = or disjoint i64 %747, %748
  %phi_cast_R347_bitcast.3 = bitcast float %phi.81 to i32
  %phi_cast_R311_bitcast.3 = bitcast float %phi.82 to i32
  %750 = zext i32 %phi_cast_R347_bitcast.3 to i64
  %751 = shl nuw i64 %750, 32
  %752 = zext i32 %phi_cast_R311_bitcast.3 to i64
  %753 = or disjoint i64 %751, %752
  %phi_cast_R276_bitcast.3 = bitcast float %phi.83 to i32
  %phi_cast_R734_bitcast.3 = bitcast float %phi.84 to i32
  %754 = zext i32 %phi_cast_R276_bitcast.3 to i64
  %755 = shl nuw i64 %754, 32
  %756 = zext i32 %phi_cast_R734_bitcast.3 to i64
  %757 = or disjoint i64 %755, %756
  %phi_cast_R194_bitcast.3 = bitcast float %phi.88 to i32
  %phi_cast_R767_bitcast.3 = bitcast float %phi.89 to i32
  %758 = zext i32 %phi_cast_R194_bitcast.3 to i64
  %759 = shl nuw i64 %758, 32
  %760 = zext i32 %phi_cast_R767_bitcast.3 to i64
  %761 = or disjoint i64 %759, %760
  br i1 %isetrp_cmp1.84, label %BB_3510, label %BB_3260

BB_3260:                                          ; preds = %BB_31d0
  %imad_rhs.52 = load i32, ptr %.1638, align 4
  %762 = zext i32 %imad_rhs.52 to i64
  %763 = shl nuw i64 %762, 32
  %imad_rhs.51 = load i32, ptr %.1636, align 4
  %764 = zext i32 %imad_rhs.51 to i64
  %765 = or disjoint i64 %763, %764
  %766 = sext i32 %phi.163 to i64
  %imad_tmp.124 = shl i32 %imad_tmp.94, 7
  %767 = sext i32 %imad_tmp.124 to i64
  %768 = mul i64 %765, %766
  %.1651 = shl i32 %imad.114, 7
  %.1653 = add i32 %.1651, %tid_x
  %isetrp_cmp1.86 = icmp slt i32 %phi.164, 1
  br i1 %isetrp_cmp1.86, label %BB_3480, label %BB_32e0

BB_32e0:                                          ; preds = %BB_3260
  %imad_tmp.126 = shl i32 %.1653, 4
  %.1666 = getelementptr inbounds nuw i8, ptr %param_local, i64 728
  %iadd3_o2.24 = load i32, ptr %.1666, align 4
  %769 = sext i32 %imad_tmp.126 to i64
  %.1677 = shl nsw i64 %767, 4
  %770 = add i64 %768, %.1677
  %.1685 = getelementptr inbounds nuw i8, ptr %param_local, i64 732
  %iadd3_o2.26 = load i32, ptr %.1685, align 4
  %771 = zext i32 %iadd3_o2.24 to i64
  %772 = zext i32 %iadd3_o2.26 to i64
  %773 = shl nuw i64 %772, 32
  %774 = add i64 %770, %769
  %775 = add i64 %774, %771
  %776 = add i64 %775, %773
  %777 = zext i32 %iadd3_o2.24 to i64
  %778 = zext i32 %iadd3_o2.26 to i64
  %779 = shl nuw i64 %778, 32
  %780 = add i64 %768, %769
  %781 = add i64 %780, %777
  %782 = add i64 %781, %779
  br label %BB_3370

BB_3370:                                          ; preds = %BB_3370, %BB_32e0
  %783 = phi i64 [ %776, %BB_32e0 ], [ %791, %BB_3370 ]
  %784 = phi i64 [ %782, %BB_32e0 ], [ %794, %BB_3370 ]
  %phi.167 = phi i32 [ 0, %BB_32e0 ], [ %iadd3_n1.68, %BB_3370 ]
  %phi.168 = phi float [ %phi.79, %BB_32e0 ], [ %fadd.13, %BB_3370 ]
  %phi.169 = phi float [ %phi.80, %BB_32e0 ], [ %fadd.12, %BB_3370 ]
  %phi.170 = phi float [ %phi.81, %BB_32e0 ], [ %fadd.11, %BB_3370 ]
  %phi.171 = phi float [ %phi.82, %BB_32e0 ], [ %fadd.10, %BB_3370 ]
  %phi.172 = phi float [ %phi.83, %BB_32e0 ], [ %fadd.9, %BB_3370 ]
  %phi.173 = phi float [ %phi.84, %BB_32e0 ], [ %fadd.8, %BB_3370 ]
  %phi.178 = phi float [ %phi.88, %BB_32e0 ], [ %fadd.15, %BB_3370 ]
  %phi.179 = phi float [ %phi.89, %BB_32e0 ], [ %fadd.14, %BB_3370 ]
  %ldv_volatile.2 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %784) #9
  %ldstrongv_lane3.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 3
  %fadd_lhs_bitcast.11 = bitcast i32 %ldstrongv_lane3.2 to float
  %ldstrongv_lane2.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 2
  %fadd_lhs_bitcast.10 = bitcast i32 %ldstrongv_lane2.2 to float
  %ldstrongv_lane1.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 1
  %fadd_lhs_bitcast.9 = bitcast i32 %ldstrongv_lane1.2 to float
  %ldstrongv_lane0.2 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.2, 0
  %fadd_lhs_bitcast.8 = bitcast i32 %ldstrongv_lane0.2 to float
  %fadd.8 = fadd float %phi.173, %fadd_lhs_bitcast.8
  %fadd.9 = fadd float %phi.172, %fadd_lhs_bitcast.9
  %fadd.10 = fadd float %phi.171, %fadd_lhs_bitcast.10
  %fadd.11 = fadd float %phi.170, %fadd_lhs_bitcast.11
  %ldv_volatile.3 = call { i32, i32, i32, i32 } asm sideeffect "ld.volatile.global.v4.b32 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,l,~{memory}"(i64 %783) #9
  %ldstrongv_lane3.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 3
  %fadd_lhs_bitcast.15 = bitcast i32 %ldstrongv_lane3.3 to float
  %ldstrongv_lane2.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 2
  %fadd_lhs_bitcast.14 = bitcast i32 %ldstrongv_lane2.3 to float
  %ldstrongv_lane1.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 1
  %fadd_lhs_bitcast.13 = bitcast i32 %ldstrongv_lane1.3 to float
  %ldstrongv_lane0.3 = extractvalue { i32, i32, i32, i32 } %ldv_volatile.3, 0
  %fadd_lhs_bitcast.12 = bitcast i32 %ldstrongv_lane0.3 to float
  %fadd.12 = fadd float %phi.169, %fadd_lhs_bitcast.12
  %fadd.13 = fadd float %phi.168, %fadd_lhs_bitcast.13
  %fadd.14 = fadd float %phi.179, %fadd_lhs_bitcast.14
  %fadd.15 = fadd float %phi.178, %fadd_lhs_bitcast.15
  %iadd3_o2.28 = load i32, ptr %.1636, align 4
  %785 = zext i32 %iadd3_o2.28 to i64
  %786 = add i64 %783, %785
  %787 = zext i32 %iadd3_o2.28 to i64
  %788 = add i64 %784, %787
  %iadd3_o2.30 = load i32, ptr %.1638, align 4
  %789 = zext i32 %iadd3_o2.30 to i64
  %790 = shl nuw i64 %789, 32
  %791 = add i64 %786, %790
  %792 = zext i32 %iadd3_o2.30 to i64
  %793 = shl nuw i64 %792, 32
  %794 = add i64 %788, %793
  %iadd3_n1.68 = add i32 %phi.167, 1
  %isetrp_cmp1.87.not = icmp sgt i32 %phi.164, %iadd3_n1.68
  br i1 %isetrp_cmp1.87.not, label %BB_3370, label %BB_3480.loopexit

BB_3480.loopexit:                                 ; preds = %BB_3370
  %phi_cast_R426_bitcast = bitcast float %fadd.13 to i32
  %795 = zext i32 %phi_cast_R426_bitcast to i64
  %796 = shl nuw i64 %795, 32
  %phi_cast_R393_bitcast = bitcast float %fadd.12 to i32
  %797 = zext i32 %phi_cast_R393_bitcast to i64
  %798 = or disjoint i64 %796, %797
  %phi_cast_R66_bitcast = bitcast float %fadd.15 to i32
  %799 = zext i32 %phi_cast_R66_bitcast to i64
  %800 = shl nuw i64 %799, 32
  %phi_cast_R940_bitcast = bitcast float %fadd.14 to i32
  %801 = zext i32 %phi_cast_R940_bitcast to i64
  %802 = or disjoint i64 %800, %801
  %phi_cast_R292_bitcast = bitcast float %fadd.9 to i32
  %803 = zext i32 %phi_cast_R292_bitcast to i64
  %804 = shl nuw i64 %803, 32
  %phi_cast_R98_bitcast = bitcast float %fadd.8 to i32
  %805 = zext i32 %phi_cast_R98_bitcast to i64
  %806 = or disjoint i64 %804, %805
  %phi_cast_R363_bitcast = bitcast float %fadd.11 to i32
  %807 = zext i32 %phi_cast_R363_bitcast to i64
  %808 = shl nuw i64 %807, 32
  %phi_cast_R325_bitcast = bitcast float %fadd.10 to i32
  %809 = zext i32 %phi_cast_R325_bitcast to i64
  %810 = or disjoint i64 %808, %809
  br label %BB_3480

BB_3480:                                          ; preds = %BB_3480.loopexit, %BB_3260
  %811 = phi i64 [ %761, %BB_3260 ], [ %802, %BB_3480.loopexit ]
  %812 = phi i64 [ %753, %BB_3260 ], [ %810, %BB_3480.loopexit ]
  %813 = phi i64 [ %749, %BB_3260 ], [ %798, %BB_3480.loopexit ]
  %814 = phi i64 [ %757, %BB_3260 ], [ %806, %BB_3480.loopexit ]
  br i1 %isetrp_cmp2.85, label %BB_3510, label %BB_3490

BB_3490:                                          ; preds = %BB_3480
  %815 = lshr i64 %812, 32
  %816 = lshr i64 %811, 32
  %imad_lhs_64.28 = sext i32 %.1653 to i64
  %imad_tmp_64.28 = shl nsw i64 %imad_lhs_64.28, 4
  %imad.155 = add i64 %imad_tmp_64.28, %768
  %817 = add i64 %imad_tmp_64.28, %768
  %.1701 = getelementptr inbounds nuw i8, ptr %param_local, i64 728
  %iadd3_o2.32 = load i32, ptr %.1701, align 4
  %.1703 = getelementptr inbounds nuw i8, ptr %param_local, i64 732
  %iadd3_o2.33 = load i32, ptr %.1703, align 4
  %818 = and i64 %imad.155, 4294967295
  %819 = zext i32 %iadd3_o2.32 to i64
  %820 = add nuw nsw i64 %818, %819
  %821 = zext i32 %iadd3_o2.32 to i64
  %822 = zext i32 %iadd3_o2.33 to i64
  %823 = shl nuw i64 %822, 32
  %824 = add i64 %817, %821
  %825 = add i64 %824, %823
  %stg_val_packed_1.3 = zext i64 %814 to i128
  %.mask34 = and i64 %812, 4294967295
  %stg_val_r2_ext.3 = zext nneg i64 %.mask34 to i128
  %stg_val_r2_shift.3 = shl nuw nsw i128 %stg_val_r2_ext.3, 64
  %stg_val_packed_2.3 = or disjoint i128 %stg_val_r2_shift.3, %stg_val_packed_1.3
  %stg_val_r3_ext.3 = zext nneg i64 %815 to i128
  %stg_val_r3_shift.3 = shl nuw i128 %stg_val_r3_ext.3, 96
  %stg_val_packed_3.3 = or disjoint i128 %stg_val_packed_2.3, %stg_val_r3_shift.3
  %"R687:R637_addr_ptr" = inttoptr i64 %825 to ptr addrspace(1)
  store i128 %stg_val_packed_3.3, ptr addrspace(1) %"R687:R637_addr_ptr", align 8
  %.1720 = shl nsw i64 %767, 4
  %826 = and i64 %imad.155, -4294967296
  %827 = zext i32 %iadd3_o2.33 to i64
  %828 = shl nuw i64 %827, 32
  %829 = add nsw i64 %820, %.1720
  %830 = add i64 %829, %826
  %831 = add i64 %830, %828
  %stg_val_packed_1.4 = zext i64 %813 to i128
  %.mask39 = and i64 %811, 4294967295
  %stg_val_r2_ext.4 = zext nneg i64 %.mask39 to i128
  %stg_val_r2_shift.4 = shl nuw nsw i128 %stg_val_r2_ext.4, 64
  %stg_val_packed_2.4 = or disjoint i128 %stg_val_r2_shift.4, %stg_val_packed_1.4
  %stg_val_r3_ext.4 = zext nneg i64 %816 to i128
  %stg_val_r3_shift.4 = shl nuw i128 %stg_val_r3_ext.4, 96
  %stg_val_packed_3.4 = or disjoint i128 %stg_val_packed_2.4, %stg_val_r3_shift.4
  %"R572:R456_addr_ptr" = inttoptr i64 %831 to ptr addrspace(1)
  store i128 %stg_val_packed_3.4, ptr addrspace(1) %"R572:R456_addr_ptr", align 8
  br label %BB_3510

BB_3510:                                          ; preds = %BB_3490, %BB_3480, %BB_31d0
  %832 = phi i64 [ %811, %BB_3490 ], [ %761, %BB_31d0 ], [ %811, %BB_3480 ]
  %833 = phi i64 [ %812, %BB_3490 ], [ %753, %BB_31d0 ], [ %812, %BB_3480 ]
  %834 = phi i64 [ %813, %BB_3490 ], [ %749, %BB_31d0 ], [ %813, %BB_3480 ]
  %835 = phi i64 [ %814, %BB_3490 ], [ %757, %BB_31d0 ], [ %814, %BB_3480 ]
  br i1 %isetrp_cmp2.85, label %BB_3520, label %BB_3890

BB_3520:                                          ; preds = %BB_3510
  %836 = zext nneg i32 %imad.101 to i64
  %.1729 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %836
  store volatile i64 %835, ptr addrspace(3) %.1729, align 8
  %sts_addr_memaddr_offset_add.3 = add nuw nsw i32 %imad.101, 16
  %837 = zext nneg i32 %sts_addr_memaddr_offset_add.3 to i64
  %.1742 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %837
  store volatile i64 %834, ptr addrspace(3) %.1742, align 8
  %sts_addr_memaddr_offset_add.4 = add nuw nsw i32 %imad.101, 1280
  %838 = zext nneg i32 %sts_addr_memaddr_offset_add.4 to i64
  %.1744 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %838
  store volatile i64 %833, ptr addrspace(3) %.1744, align 8
  %isetrp_rhs.21 = load i32, ptr %.311, align 4
  %sts_addr_memaddr_offset_add.5 = add nuw nsw i32 %imad.101, 1296
  %839 = zext nneg i32 %sts_addr_memaddr_offset_add.5 to i64
  %.1748 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %839
  store volatile i64 %832, ptr addrspace(3) %.1748, align 8
  call void @llvm.nvvm.barrier0()
  %isetrp_rhs.22 = load i32, ptr %.234, align 4
  %lds_shared_addr_winoff.2.xscale = shl i32 %imad.98, 4
  %lds_shared_addr_winoff.2 = and i32 %lds_shared_addr_winoff.2.xscale, 16777200
  %840 = zext nneg i32 %lds_shared_addr_winoff.2 to i64
  %.1772 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %840
  %lds.2 = load volatile i128, ptr addrspace(3) %.1772, align 8
  %lds_addr_memaddr_offset_add.1 = add i32 %lds_shared_addr_winoff.2.xscale, 80
  %lds_shared_addr_winoff.3 = and i32 %lds_addr_memaddr_offset_add.1, 16777200
  %841 = zext nneg i32 %lds_shared_addr_winoff.3 to i64
  %.1773 = getelementptr inbounds nuw [8192 x i8], ptr addrspace(3) @shared_mem, i64 0, i64 %841
  %lds.3 = load volatile i128, ptr addrspace(3) %.1773, align 8
  %842 = icmp slt i32 %sel.5, 0
  %.1734 = shl i32 %sel.5, 5
  %.1736 = add i32 %.1734, 32
  %isetrp_cmp1.88.not = icmp slt i32 %.1063, %.1736
  %.not43.not46 = or i1 %842, %isetrp_cmp1.88.not
  %isetrp_cmp1.90 = icmp sgt i32 %isetrp_rhs.22, %.1039
  %isetrp_cmp1.89 = icmp slt i32 %.1063, %isetrp_rhs.21
  %isetrp_cmp2.90.not47 = and i1 %isetrp_cmp1.90, %isetrp_cmp1.89
  %isetrp_cmp2.91.not = and i1 %.not43.not46, %isetrp_cmp2.90.not47
  br i1 %isetrp_cmp2.91.not, label %BB_80003860, label %BB_3890

BB_80003860:                                      ; preds = %BB_3520
  %"R15:R14:R13:R12_r3_shift.3" = lshr i128 %lds.3, 96
  %"R15:R14:R13:R12_r3.3" = trunc nuw i128 %"R15:R14:R13:R12_r3_shift.3" to i32
  %ffma_lhs_bitcast.23 = bitcast i32 %"R15:R14:R13:R12_r3.3" to float
  %extelt.offset45 = and i32 %phi.104, -65536
  %843 = lshr i32 %phi.104, 3
  %844 = and i32 %843, 268427264
  %845 = icmp samesign ugt i32 %844, 260046847
  %846 = select i1 %845, i32 2139095040, i32 0
  %847 = or i32 %844, %846
  %848 = bitcast i32 %847 to float
  %849 = fmul float %848, 0x46F0000000000000
  %850 = bitcast i32 %extelt.offset45 to float
  %851 = call float @llvm.copysign.f32(float %849, float %850)
  %ffma.23 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.23, float %phi.111, float %851)
  %.1774 = getelementptr inbounds nuw i8, ptr %param_local, i64 928
  %fmnmx_rhs.16 = load float, ptr %.1774, align 4
  %fmnmx_max.15 = call float @llvm.maximum.f32(float %ffma.23, float %fmnmx_rhs.16)
  %.1790 = getelementptr inbounds nuw i8, ptr %param_local, i64 944
  %fmnmx_rhs.24 = load float, ptr %.1790, align 4
  %fmnmx_min.15 = call float @llvm.minimum.f32(float %fmnmx_max.15, float %fmnmx_rhs.24)
  %"R15:R14:R13:R12_r2_shift.3" = lshr i128 %lds.3, 64
  %"R15:R14:R13:R12_r2.3" = trunc i128 %"R15:R14:R13:R12_r2_shift.3" to i32
  %ffma_lhs_bitcast.22 = bitcast i32 %"R15:R14:R13:R12_r2.3" to float
  %852 = shl i32 %phi.104, 16
  %853 = lshr exact i32 %852, 3
  %854 = and i32 %853, 268427264
  %855 = icmp samesign ugt i32 %854, 260046847
  %856 = select i1 %855, i32 2139095040, i32 0
  %857 = or i32 %854, %856
  %858 = bitcast i32 %857 to float
  %859 = fmul float %858, 0x46F0000000000000
  %860 = bitcast i32 %852 to float
  %861 = call float @llvm.copysign.f32(float %859, float %860)
  %ffma.22 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.22, float %phi.111, float %861)
  %fmnmx_max.14 = call float @llvm.maximum.f32(float %ffma.22, float %fmnmx_rhs.16)
  %fmnmx_min.14 = call float @llvm.minimum.f32(float %fmnmx_max.14, float %fmnmx_rhs.24)
  %"R15:R14:R13:R12_r1_shift.3" = lshr i128 %lds.3, 32
  %"R15:R14:R13:R12_r1.3" = trunc i128 %"R15:R14:R13:R12_r1_shift.3" to i32
  %ffma_lhs_bitcast.21 = bitcast i32 %"R15:R14:R13:R12_r1.3" to float
  %extelt.offset42 = and i32 %phi.105, -65536
  %862 = lshr i32 %phi.105, 3
  %863 = and i32 %862, 268427264
  %864 = icmp samesign ugt i32 %863, 260046847
  %865 = select i1 %864, i32 2139095040, i32 0
  %866 = or i32 %863, %865
  %867 = bitcast i32 %866 to float
  %868 = fmul float %867, 0x46F0000000000000
  %869 = bitcast i32 %extelt.offset42 to float
  %870 = call float @llvm.copysign.f32(float %868, float %869)
  %ffma.21 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.21, float %phi.111, float %870)
  %fmnmx_max.13 = call float @llvm.maximum.f32(float %ffma.21, float %fmnmx_rhs.16)
  %fmnmx_min.13 = call float @llvm.minimum.f32(float %fmnmx_max.13, float %fmnmx_rhs.24)
  %"R15:R14:R13:R12_r0.3" = trunc i128 %lds.3 to i32
  %ffma_lhs_bitcast.20 = bitcast i32 %"R15:R14:R13:R12_r0.3" to float
  %871 = shl i32 %phi.105, 16
  %872 = lshr exact i32 %871, 3
  %873 = and i32 %872, 268427264
  %874 = icmp samesign ugt i32 %873, 260046847
  %875 = select i1 %874, i32 2139095040, i32 0
  %876 = or i32 %873, %875
  %877 = bitcast i32 %876 to float
  %878 = fmul float %877, 0x46F0000000000000
  %879 = bitcast i32 %871 to float
  %880 = call float @llvm.copysign.f32(float %878, float %879)
  %ffma.20 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.20, float %phi.111, float %880)
  %fmnmx_max.12 = call float @llvm.maximum.f32(float %ffma.20, float %fmnmx_rhs.16)
  %fmnmx_min.12 = call float @llvm.minimum.f32(float %fmnmx_max.12, float %fmnmx_rhs.24)
  %881 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min.15, float %fmnmx_min.14, float %fmnmx_min.13, float %fmnmx_min.12)
  %882 = extractvalue { i32, i32, i32, i32 } %881, 0
  %883 = extractvalue { i32, i32, i32, i32 } %881, 1
  %884 = extractvalue { i32, i32, i32, i32 } %881, 2
  %885 = extractvalue { i32, i32, i32, i32 } %881, 3
  %f2fp_a_shift.7 = shl nuw i32 %882, 16
  %f2fp_packed.7 = or disjoint i32 %f2fp_a_shift.7, %883
  %stg_val_r3_ext.5 = zext i32 %f2fp_packed.7 to i128
  %stg_val_r3_shift.5 = shl nuw i128 %stg_val_r3_ext.5, 96
  %f2fp_a_shift.6 = shl nuw i32 %884, 16
  %f2fp_packed.6 = or disjoint i32 %f2fp_a_shift.6, %885
  %stg_val_r2_ext.5 = zext i32 %f2fp_packed.6 to i128
  %stg_val_r2_shift.5 = shl nuw nsw i128 %stg_val_r2_ext.5, 64
  %"R19:R18:R17:R16_r3_shift.4" = lshr i128 %lds.2, 96
  %"R19:R18:R17:R16_r3.4" = trunc nuw i128 %"R19:R18:R17:R16_r3_shift.4" to i32
  %ffma_lhs_bitcast.19 = bitcast i32 %"R19:R18:R17:R16_r3.4" to float
  %extelt.offset44 = and i32 %phi.106, -65536
  %886 = lshr i32 %phi.106, 3
  %887 = and i32 %886, 268427264
  %888 = icmp samesign ugt i32 %887, 260046847
  %889 = select i1 %888, i32 2139095040, i32 0
  %890 = or i32 %887, %889
  %891 = bitcast i32 %890 to float
  %892 = fmul float %891, 0x46F0000000000000
  %893 = bitcast i32 %extelt.offset44 to float
  %894 = call float @llvm.copysign.f32(float %892, float %893)
  %ffma.19 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.19, float %phi.111, float %894)
  %fmnmx_max.11 = call float @llvm.maximum.f32(float %ffma.19, float %fmnmx_rhs.16)
  %fmnmx_min.11 = call float @llvm.minimum.f32(float %fmnmx_max.11, float %fmnmx_rhs.24)
  %"R19:R18:R17:R16_r2_shift.4" = lshr i128 %lds.2, 64
  %"R19:R18:R17:R16_r2.4" = trunc i128 %"R19:R18:R17:R16_r2_shift.4" to i32
  %ffma_lhs_bitcast.17 = bitcast i32 %"R19:R18:R17:R16_r2.4" to float
  %895 = shl i32 %phi.106, 16
  %896 = lshr exact i32 %895, 3
  %897 = and i32 %896, 268427264
  %898 = icmp samesign ugt i32 %897, 260046847
  %899 = select i1 %898, i32 2139095040, i32 0
  %900 = or i32 %897, %899
  %901 = bitcast i32 %900 to float
  %902 = fmul float %901, 0x46F0000000000000
  %903 = bitcast i32 %895 to float
  %904 = call float @llvm.copysign.f32(float %902, float %903)
  %ffma.17 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.17, float %phi.111, float %904)
  %fmnmx_max.9 = call float @llvm.maximum.f32(float %ffma.17, float %fmnmx_rhs.16)
  %fmnmx_min.9 = call float @llvm.minimum.f32(float %fmnmx_max.9, float %fmnmx_rhs.24)
  %"R19:R18:R17:R16_r1_shift.4" = lshr i128 %lds.2, 32
  %"R19:R18:R17:R16_r1.4" = trunc i128 %"R19:R18:R17:R16_r1_shift.4" to i32
  %ffma_lhs_bitcast.18 = bitcast i32 %"R19:R18:R17:R16_r1.4" to float
  %extelt.offset41 = and i32 %phi.107, -65536
  %905 = lshr i32 %phi.107, 3
  %906 = and i32 %905, 268427264
  %907 = icmp samesign ugt i32 %906, 260046847
  %908 = select i1 %907, i32 2139095040, i32 0
  %909 = or i32 %906, %908
  %910 = bitcast i32 %909 to float
  %911 = fmul float %910, 0x46F0000000000000
  %912 = bitcast i32 %extelt.offset41 to float
  %913 = call float @llvm.copysign.f32(float %911, float %912)
  %ffma.18 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.18, float %phi.111, float %913)
  %fmnmx_max.10 = call float @llvm.maximum.f32(float %ffma.18, float %fmnmx_rhs.16)
  %fmnmx_min.10 = call float @llvm.minimum.f32(float %fmnmx_max.10, float %fmnmx_rhs.24)
  %"R19:R18:R17:R16_r0.4" = trunc i128 %lds.2 to i32
  %ffma_lhs_bitcast.16 = bitcast i32 %"R19:R18:R17:R16_r0.4" to float
  %914 = shl i32 %phi.107, 16
  %915 = lshr exact i32 %914, 3
  %916 = and i32 %915, 268427264
  %917 = icmp samesign ugt i32 %916, 260046847
  %918 = select i1 %917, i32 2139095040, i32 0
  %919 = or i32 %916, %918
  %920 = bitcast i32 %919 to float
  %921 = fmul float %920, 0x46F0000000000000
  %922 = bitcast i32 %914 to float
  %923 = call float @llvm.copysign.f32(float %921, float %922)
  %ffma.16 = call float @llvm.fma.f32(float %ffma_lhs_bitcast.16, float %phi.111, float %923)
  %fmnmx_max.8 = call float @llvm.maximum.f32(float %ffma.16, float %fmnmx_rhs.16)
  %fmnmx_min.8 = call float @llvm.minimum.f32(float %fmnmx_max.8, float %fmnmx_rhs.24)
  %924 = call { i32, i32, i32, i32 } @lo.cvt.a4(float %fmnmx_min.11, float %fmnmx_min.9, float %fmnmx_min.10, float %fmnmx_min.8)
  %925 = extractvalue { i32, i32, i32, i32 } %924, 0
  %926 = extractvalue { i32, i32, i32, i32 } %924, 1
  %927 = extractvalue { i32, i32, i32, i32 } %924, 2
  %928 = extractvalue { i32, i32, i32, i32 } %924, 3
  %f2fp_a_shift.5 = shl nuw i32 %925, 16
  %f2fp_packed.5 = or disjoint i32 %f2fp_a_shift.5, %926
  %stg_val_r1_ext.5 = zext i32 %f2fp_packed.5 to i128
  %stg_val_r1_shift.5 = shl nuw nsw i128 %stg_val_r1_ext.5, 32
  %f2fp_a_shift.4 = shl nuw i32 %927, 16
  %f2fp_packed.4 = or disjoint i32 %f2fp_a_shift.4, %928
  %stg_val_r0_ext.5 = zext i32 %f2fp_packed.4 to i128
  %stg_val_packed_1.5 = or disjoint i128 %stg_val_r1_shift.5, %stg_val_r0_ext.5
  %stg_val_packed_2.5 = or disjoint i128 %stg_val_packed_1.5, %stg_val_r2_shift.5
  %stg_val_packed_3.5 = or disjoint i128 %stg_val_packed_2.5, %stg_val_r3_shift.5
  %"R235:R68_addr_ptr_smfix_inwin.1.unshifted" = xor i64 %472, ptrtoint (ptr addrspacecast (ptr addrspace(3) @shared_mem to ptr) to i64)
  %"R235:R68_addr_ptr_smfix_inwin.1" = icmp ult i64 %"R235:R68_addr_ptr_smfix_inwin.1.unshifted", 4294967296
  %"R235:R68_addr_ptr_smfix_w.1" = and i64 ptrtoint (ptr addrspacecast (ptr addrspace(3) @shared_mem to ptr) to i64), 16777215
  %"R235:R68_addr_ptr_smfix_biased.1" = select i1 %"R235:R68_addr_ptr_smfix_inwin.1", i64 %"R235:R68_addr_ptr_smfix_w.1", i64 0
  %"R235:R68_addr_ptr_smfix.1" = add i64 %472, %"R235:R68_addr_ptr_smfix_biased.1"
  %"R235:R68_addr_ptr.1" = inttoptr i64 %"R235:R68_addr_ptr_smfix.1" to ptr
  store i128 %stg_val_packed_3.5, ptr %"R235:R68_addr_ptr.1", align 8
  br label %BB_3890

BB_3890:                                          ; preds = %BB_3510, %BB_3520, %BB_80003860
  %929 = zext i1 %isetrp_cmp1.92.not to i32
  %930 = icmp ne i32 %929, 0
  br i1 %930, label %BB_38a0, label %BB_39b0

BB_38a0:                                          ; preds = %BB_3890
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.93.not = icmp eq i32 %tid_x, 0
  br i1 %isetrp_cmp1.93.not, label %BB_3920, label %BB_39b0

BB_3920:                                          ; preds = %BB_38a0
  %warp_reconv_mask.2 = call i32 asm sideeffect "activemask.b32 $0;", "=r"() #9
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.2)
  call void @llvm.nvvm.membar.gl()
  br i1 %isetrp_cmp2.43, label %BB_3980, label %BB_3960

BB_3960:                                          ; preds = %BB_3920
  %red_add.2 = atomicrmw add ptr addrspace(1) %phi.165, i32 1 monotonic, align 4
  br label %BB_3980

BB_3980:                                          ; preds = %BB_3960, %BB_3920
  %red_ptr.3 = inttoptr i64 %phi.166 to ptr addrspace(1)
  %red_add.3 = atomicrmw add ptr addrspace(1) %red_ptr.3, i32 1 monotonic, align 4
  br label %BB_39b0

BB_39b0:                                          ; preds = %BB_3980, %BB_38a0, %BB_3890, %BB_2c10, %BB_2b20, %BB_2b10
  call void @llvm.nvvm.barrier0()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #2

; Function Attrs: nocallback nounwind memory(none)
declare { float, float, float, float } @llvm.nvvm.mma.m16n8k16.row.col.f32.f32(<2 x half>, <2 x half>, <2 x half>, <2 x half>, <2 x half>, <2 x half>, float, float, float, float) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.minimum.f32(float, float) #1

; Function Attrs: nocallback nounwind
declare void @llvm.nvvm.membar.gl() #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.laneid() #1

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.shfl.sync.idx.i32(i32, i32, i32, i32) #5

; Function Attrs: alwaysinline
define internal { i32, i32, i32, i32 } @lo.cvt.a4(float %0, float %1, float %2, float %3) #6 {
entry:
  %4 = call float @llvm.fabs.f32(float %0)
  %5 = bitcast float %4 to i32
  %6 = add nsw i32 %5, -947912704
  %7 = icmp ult i32 %6, 251654144
  %8 = call float @llvm.fabs.f32(float %1)
  %9 = bitcast float %8 to i32
  %10 = add nsw i32 %9, -947912704
  %11 = icmp ult i32 %10, 251654144
  %12 = and i1 %7, %11
  %13 = call float @llvm.fabs.f32(float %2)
  %14 = bitcast float %13 to i32
  %15 = add nsw i32 %14, -947912704
  %16 = icmp ult i32 %15, 251654144
  %17 = and i1 %12, %16
  %18 = call float @llvm.fabs.f32(float %3)
  %19 = bitcast float %18 to i32
  %20 = add nsw i32 %19, -947912704
  %21 = icmp ult i32 %20, 251654144
  %22 = and i1 %17, %21
  br i1 %22, label %fast, label %slow

fast:                                             ; preds = %entry
  %23 = bitcast float %3 to i32
  %24 = bitcast float %2 to i32
  %25 = bitcast float %1 to i32
  %26 = bitcast float %0 to i32
  %27 = lshr i32 %5, 13
  %28 = and i32 %27, 1
  %29 = add nsw i32 %5, -939520001
  %30 = add nsw i32 %29, %28
  %31 = lshr i32 %30, 13
  %32 = lshr i32 %26, 16
  %33 = and i32 %32, 32768
  %34 = or i32 %31, %33
  %35 = lshr i32 %9, 13
  %36 = and i32 %35, 1
  %37 = add nsw i32 %9, -939520001
  %38 = add nsw i32 %37, %36
  %39 = lshr i32 %38, 13
  %40 = lshr i32 %25, 16
  %41 = and i32 %40, 32768
  %42 = or i32 %39, %41
  %43 = lshr i32 %14, 13
  %44 = and i32 %43, 1
  %45 = add nsw i32 %14, -939520001
  %46 = add nsw i32 %45, %44
  %47 = lshr i32 %46, 13
  %48 = lshr i32 %24, 16
  %49 = and i32 %48, 32768
  %50 = or i32 %47, %49
  %51 = lshr i32 %19, 13
  %52 = and i32 %51, 1
  %53 = add nsw i32 %19, -939520001
  %54 = add nsw i32 %53, %52
  %55 = lshr i32 %54, 13
  %56 = lshr i32 %23, 16
  %57 = and i32 %56, 32768
  %58 = or i32 %55, %57
  br label %join

slow:                                             ; preds = %entry
  %59 = fptrunc float %0 to half
  %60 = bitcast half %59 to i16
  %61 = zext i16 %60 to i32
  %62 = fptrunc float %1 to half
  %63 = bitcast half %62 to i16
  %64 = zext i16 %63 to i32
  %65 = fptrunc float %2 to half
  %66 = bitcast half %65 to i16
  %67 = zext i16 %66 to i32
  %68 = fptrunc float %3 to half
  %69 = bitcast half %68 to i16
  %70 = zext i16 %69 to i32
  br label %join

join:                                             ; preds = %slow, %fast
  %71 = phi i32 [ %34, %fast ], [ %61, %slow ]
  %72 = phi i32 [ %42, %fast ], [ %64, %slow ]
  %73 = phi i32 [ %50, %fast ], [ %67, %slow ]
  %74 = phi i32 [ %58, %fast ], [ %70, %slow ]
  %75 = insertvalue { i32, i32, i32, i32 } poison, i32 %71, 0
  %76 = insertvalue { i32, i32, i32, i32 } %75, i32 %72, 1
  %77 = insertvalue { i32, i32, i32, i32 } %76, i32 %73, 2
  %78 = insertvalue { i32, i32, i32, i32 } %77, i32 %74, 3
  ret { i32, i32, i32, i32 } %78
}

; Function Attrs: convergent
declare void @__vx_wmma_mma_m16n16k16_row_row_f16_f16_f32(ptr, ptr, ptr, ptr) #7

; Function Attrs: alwaysinline convergent
define internal { float, float, float, float, float, float, float, float } @lo.wmma(ptr %0, float %1, float %2, float %3, float %4, float %5, float %6, float %7, float %8, float %9, float %10, float %11, float %12, float %13, float %14, float %15, float %16, float %17, float %18, float %19, float %20, float %21, float %22, float %23, float %24) #8 {
entry:
  store float %1, ptr %0, align 4
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store float %9, ptr %25, align 4
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 64
  store float %17, ptr %26, align 4
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 4
  store float %2, ptr %27, align 4
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 36
  store float %10, ptr %28, align 4
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 68
  store float %18, ptr %29, align 4
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store float %3, ptr %30, align 4
  %31 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store float %11, ptr %31, align 4
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 72
  store float %19, ptr %32, align 4
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 12
  store float %4, ptr %33, align 4
  %34 = getelementptr inbounds nuw i8, ptr %0, i64 44
  store float %12, ptr %34, align 4
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 76
  store float %20, ptr %35, align 4
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store float %5, ptr %36, align 4
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 48
  store float %13, ptr %37, align 4
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 80
  store float %21, ptr %38, align 4
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 20
  store float %6, ptr %39, align 4
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 52
  store float %14, ptr %40, align 4
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 84
  store float %22, ptr %41, align 4
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store float %7, ptr %42, align 4
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 56
  store float %15, ptr %43, align 4
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 88
  store float %23, ptr %44, align 4
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 28
  store float %8, ptr %45, align 4
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 60
  store float %16, ptr %46, align 4
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 92
  store float %24, ptr %47, align 4
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 64
  call void @__vx_wmma_mma_m16n16k16_row_row_f16_f16_f32(ptr nonnull %48, ptr %0, ptr nonnull %49, ptr nonnull %50) #7
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %52 = load float, ptr %51, align 4
  %53 = insertvalue { float, float, float, float, float, float, float, float } poison, float %52, 0
  %54 = getelementptr inbounds nuw i8, ptr %0, i64 100
  %55 = load float, ptr %54, align 4
  %56 = insertvalue { float, float, float, float, float, float, float, float } %53, float %55, 1
  %57 = getelementptr inbounds nuw i8, ptr %0, i64 104
  %58 = load float, ptr %57, align 4
  %59 = insertvalue { float, float, float, float, float, float, float, float } %56, float %58, 2
  %60 = getelementptr inbounds nuw i8, ptr %0, i64 108
  %61 = load float, ptr %60, align 4
  %62 = insertvalue { float, float, float, float, float, float, float, float } %59, float %61, 3
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %64 = load float, ptr %63, align 4
  %65 = insertvalue { float, float, float, float, float, float, float, float } %62, float %64, 4
  %66 = getelementptr inbounds nuw i8, ptr %0, i64 116
  %67 = load float, ptr %66, align 4
  %68 = insertvalue { float, float, float, float, float, float, float, float } %65, float %67, 5
  %69 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %70 = load float, ptr %69, align 4
  %71 = insertvalue { float, float, float, float, float, float, float, float } %68, float %70, 6
  %72 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %73 = load float, ptr %72, align 4
  %74 = insertvalue { float, float, float, float, float, float, float, float } %71, float %73, 7
  ret { float, float, float, float, float, float, float, float } %74
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.copysign.f32(float, float) #1

attributes #0 = { "frame-pointer"="all" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { convergent nocallback nounwind }
attributes #3 = { nocallback nounwind memory(none) }
attributes #4 = { nocallback nounwind }
attributes #5 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }
attributes #6 = { alwaysinline }
attributes #7 = { convergent }
attributes #8 = { alwaysinline convergent }
attributes #9 = { nounwind }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1, !2, !3, !4}

!0 = !{i32 2, i32 0}
!1 = !{ptr @sm80_xmma_gemm_f16f16_f16f32_f32_tn_n_tilesize32x32x64_stage6_warpsize2x2x1_tensor16x8x16_execute_kernel__5x_cublas, !"kernel", i32 1}
!2 = !{ptr @sm80_xmma_gemm_f16f16_f16f32_f32_tn_n_tilesize32x32x64_stage6_warpsize2x2x1_tensor16x8x16_execute_kernel__5x_cublas, !"maxntidx", i32 128}
!3 = !{ptr @sm80_xmma_gemm_f16f16_f16f32_f32_tn_n_tilesize32x32x64_stage6_warpsize2x2x1_tensor16x8x16_execute_kernel__5x_cublas, !"maxntidy", i32 1}
!4 = !{ptr @sm80_xmma_gemm_f16f16_f16f32_f32_tn_n_tilesize32x32x64_stage6_warpsize2x2x1_tensor16x8x16_execute_kernel__5x_cublas, !"maxntidz", i32 1}
