; ModuleID = "tcgen05_full_mx_tmem_a_sm100a_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [2064 x i8], align 16
define void @"_Z13column_scaledIL4Case3EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P20_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P20_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R41:R161_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R41:R161_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P30_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P9_to_i32", %"BB_00a0"], [%"P21_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P31_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P31_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P32_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P44_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 512) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P3_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 65535
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P35_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P35_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P4_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P36_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P6_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_10b0"
BB_0560_10b0:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.10" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.10", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R82:R64_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R82:R64_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R82:R64_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R82:R64_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R82:R64_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R82:R64_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R82:R64_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R82:R64_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R82:R64_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R82:R64_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R82:R64_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R82:R64_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R82:R64_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R82:R64_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R82:R64_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R82:R64_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0840"
BB_0840:
  %"cond_trunc.11" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a90", label %"BB_0850"
BB_0850:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".196" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".185" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".201" = xor i32 %"plop3_a_bit.2", 1
  %".202" = xor i32 %"plop3_b_bit.2", 1
  %".203" = xor i32 %"plop3_c_bit.2", 1
  %".204" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".205" = and i32 %".204", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".205", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".206" = xor i32 %"shf_result.4", -1
  %".207" = xor i32 16376, -1
  %".208" = xor i32 0, -1
  %".209" = and i32 %"shf_result.4", 16376
  %".210" = and i32 %".209", %".208"
  %".211" = and i32 %"shf_result.4", 16376
  %".212" = and i32 %".211", 0
  %".213" = or i32 %".210", %".212"
  %".214" = xor i32 %".213", -1
  %".215" = xor i32 524288, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %".214", 524288
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %".214", 524288
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".213", %".215"
  %".223" = and i32 %".222", %".216"
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".213", %".215"
  %".226" = and i32 %".225", 0
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".213", 524288
  %".229" = and i32 %".228", %".216"
  %".230" = or i32 %".227", %".229"
  %".231" = and i32 %".213", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"lds.2", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.2", 20
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0910"
BB_0910:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0850"], [%"P28_to_i32", %"BB_0940"]
  %"phi.12" = phi  i32 [%"P33_to_i32", %"BB_0850"], [%"phi.14", %"BB_0940"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P26_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.13" = phi  i32 [%"P26_to_i32", %"BB_80000910"], [%"phi.11", %"BB_0910"]
  %"mma_b_r0_ext" = zext i32 %".233" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".237" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".238" = sub i64 %".237", 0
  %".239" = lshr i64 %".238", 4
  %".240" = add i64 %"mma_b_packed_1", %".239"
  %".241" = and i64 %".240", 16383
  %".242" = and i64 %"mma_b_packed_1", -16384
  %".243" = or i64 %".242", %".241"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".243", i32 679743664, i32 %"mma_arg_zext", i32 %"iadd3_n2.2", i32 %"iadd3_n2.3")
  br label %"BB_0930"
BB_0930:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000930", label %"BB_0940"
BB_80000930:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".247" = xor i32 %"plop3_a_bit.3", 1
  %".248" = xor i32 %"plop3_b_bit.3", 1
  %".249" = xor i32 %"plop3_c_bit.3", 1
  %".250" = and i32 %".247", %"plop3_b_bit.3"
  %".251" = and i32 %".250", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".251", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.14" = phi  i32 [%"P39_to_i32", %"BB_80000930"], [%"phi.12", %"BB_0930"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".253" = xor i32 %"plop3_a_bit.4", 1
  %".254" = xor i32 %"plop3_b_bit.4", 1
  %".255" = xor i32 %"plop3_c_bit.4", 1
  %".256" = and i32 %".253", %"plop3_b_bit.4"
  %".257" = and i32 %".256", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".257", 0
  %"P28_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0910", label %"BB_0960"
BB_0960:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".259" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".259" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".260" = xor i32 %"plop3_a_bit.5", 1
  %".261" = xor i32 %"plop3_b_bit.5", 1
  %".262" = xor i32 %"plop3_c_bit.5", 1
  %".263" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".264" = and i32 %".263", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".264", 0
  %"P47_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"iadd3_n1.4" = add i32 %"lds.3", 32
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.3", 16
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.3", 20
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  br label %"BB_09c0"
BB_09c0:
  %"phi.15" = phi  i32 [%"P28_to_i32", %"BB_0960"], [%"P14_to_i32", %"BB_09f0"]
  %"phi.16" = phi  i32 [%"P47_to_i32", %"BB_0960"], [%"phi.18", %"BB_09f0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009c0", label %"BB_09d0"
BB_800009c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P11_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09d0"
BB_09d0:
  %"phi.17" = phi  i32 [%"P11_to_i32", %"BB_800009c0"], [%"phi.15", %"BB_09c0"]
  %"mma_b_r0_ext.1" = zext i32 %".233" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".268" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".269" = sub i64 %".268", 0
  %".270" = lshr i64 %".269", 4
  %".271" = add i64 %"mma_b_packed_1.1", %".270"
  %".272" = and i64 %".271", 16383
  %".273" = and i64 %"mma_b_packed_1.1", -16384
  %".274" = or i64 %".273", %".272"
  %"mma_arg_zext.1" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.4", i64 %".274", i32 679743664, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.6")
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".278" = xor i32 %"plop3_a_bit.6", 1
  %".279" = xor i32 %"plop3_b_bit.6", 1
  %".280" = xor i32 %"plop3_c_bit.6", 1
  %".281" = and i32 %".278", %"plop3_b_bit.6"
  %".282" = and i32 %".281", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".282", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.18" = phi  i32 [%"P29_to_i32", %"BB_800009e0"], [%"phi.16", %"BB_09e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".284" = xor i32 %"plop3_a_bit.7", 1
  %".285" = xor i32 %"plop3_b_bit.7", 1
  %".286" = xor i32 %"plop3_c_bit.7", 1
  %".287" = and i32 %".284", %"plop3_b_bit.7"
  %".288" = and i32 %".287", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".288", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09c0", label %"BB_0a10"
BB_0a10:
  %"iadd3_n1.7" = add i32 1024, 1024
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".290" = xor i32 %"plop3_a_bit.8", 1
  %".291" = xor i32 %"plop3_b_bit.8", 1
  %".292" = xor i32 %"plop3_c_bit.8", 1
  %".293" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".294" = and i32 %".293", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".294", 0
  %"P41_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".295" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".296" = zext i32 %"iadd3_n2.7" to i64
  %".297" = zext i32 24 to i64
  %".298" = shl i64 %".295", %".297"
  %".299" = and i64 %".298", 4294967295
  %".300" = add i64 %".299", %".296"
  %".301" = trunc i64 %".300" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.19" = phi  i32 [%"P14_to_i32", %"BB_0a10"], [%"P18_to_i32", %"BB_0a70"]
  %"phi.20" = phi  i32 [%"P41_to_i32", %"BB_0a10"], [%"phi.22", %"BB_0a70"]
  %"cond_trunc.16" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000a40", label %"BB_0a50"
BB_80000a40:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P16_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0a50"
BB_0a50:
  %"phi.21" = phi  i32 [%"P16_to_i32", %"BB_80000a40"], [%"phi.19", %"BB_0a40"]
  %"utcbar_local_winoff" = and i32 %".301", 16777215
  %".305" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".306" = ptrtoint i8 addrspace(3)* %".305" to i32
  %".307" = lshr i32 %".301", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".306", i32 %".307")
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.17" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000a60", label %"BB_0a70"
BB_80000a60:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".311" = xor i32 %"plop3_a_bit.9", 1
  %".312" = xor i32 %"plop3_b_bit.9", 1
  %".313" = xor i32 %"plop3_c_bit.9", 1
  %".314" = and i32 %".311", %"plop3_b_bit.9"
  %".315" = and i32 %".314", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".315", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0a70"
BB_0a70:
  %"phi.22" = phi  i32 [%"P43_to_i32", %"BB_80000a60"], [%"phi.20", %"BB_0a60"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".317" = xor i32 %"plop3_a_bit.10", 1
  %".318" = xor i32 %"plop3_b_bit.10", 1
  %".319" = xor i32 %"plop3_c_bit.10", 1
  %".320" = and i32 %".317", %"plop3_b_bit.10"
  %".321" = and i32 %".320", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".321", 0
  %"P18_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0a40", label %"BB_0a90"
BB_0a90:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.8" = add i32 1024, 1024
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".323" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".324" = zext i32 %"iadd3_n2.8" to i64
  %".325" = zext i32 24 to i64
  %".326" = shl i64 %".323", %".325"
  %".327" = and i64 %".326", 4294967295
  %".328" = add i64 %".327", %".324"
  %".329" = trunc i64 %".328" to i32
  %"mbar_shared_winoff.1" = and i32 %".329", 16777215
  %".330" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".330" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P23_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0ae0"
BB_0ae0:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_1050", label %"BB_0af0"
BB_1050:
  %"mbar_shared_winoff.2" = and i32 %".329", 16777215
  %".333" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".333" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P34_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1060"
BB_1060:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_1050", label %"BB_0af0"
BB_0af0:
  %".336" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".337" = bitcast i8* %".336" to i64*
  %"ldc_const.2" = load i64, i64* %".337"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 24
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".338" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".344" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".345" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R105:R91_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".338", i32 addrspace(1)* %"R105:R91_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R105:R91_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R105:R91_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R105:R91_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R105:R91_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R105:R91_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R105:R91_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R105:R91_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R105:R91_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".353" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R105:R91_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R105:R91_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R105:R91_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".344", i32 addrspace(1)* %"R105:R91_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R105:R91_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".345", i32 addrspace(1)* %"R105:R91_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R105:R91_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R105:R91_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R105:R91_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R105:R91_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R105:R91_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".353", i32 addrspace(1)* %"R105:R91_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R105:R91_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R105:R91_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R105:R91_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R105:R91_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.12", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".367" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".368" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R105:R91_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R105:R91_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R105:R91_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R105:R91_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R105:R91_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R105:R91_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.12", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R105:R91_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".367", i32 addrspace(1)* %"R105:R91_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R105:R91_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".368", i32 addrspace(1)* %"R105:R91_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R105:R91_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R105:R91_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R105:R91_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R105:R91_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R105:R91_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R105:R91_addr_ptr.20"
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R105:R91_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R105:R91_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R105:R91_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R105:R91_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R105:R91_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R105:R91_addr_ptr.23"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0db0"
BB_0db0:
  %"cond_trunc.20" = trunc i32 %"P45_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000db0", label %"BB_0dc0"
BB_0dc0:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".388" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".388" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 65535
  %".389" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".390" = zext i32 80 to i64
  %".391" = zext i32 24 to i64
  %".392" = shl i64 %".389", %".391"
  %".393" = and i64 %".392", 4294967295
  %".394" = add i64 %".393", %".390"
  %".395" = trunc i64 %".394" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.5" = and i32 %".395", 16777215
  %".396" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".397" = xor i32 %"lds.4", -1
  %".398" = xor i32 65535, -1
  %".399" = xor i32 0, -1
  %".400" = and i32 %"lds.4", 65535
  %".401" = and i32 %".400", %".399"
  %".402" = and i32 %"lds.4", 65535
  %".403" = and i32 %".402", 0
  %".404" = or i32 %".401", %".403"
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %".404" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.5" = or i64 %".405", %".407"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".408" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".408", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".409" = zext i32 %"imad.15" to i64
  %".410" = zext i32 0 to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.6" = or i64 %".409", %".411"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".412" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".412" to i32
  %".413" = zext i32 %"imad.16" to i64
  %".414" = zext i32 0 to i64
  %".415" = shl i64 %".414", 32
  %"shf_concat.7" = or i64 %".413", %".415"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".416" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".416" to i32
  %".417" = xor i32 %"shf_result.7", -1
  %".418" = xor i32 %"shf_result.6", -1
  %".419" = xor i32 0, -1
  %".420" = and i32 %".417", %"shf_result.6"
  %".421" = and i32 %".420", %".419"
  %".422" = and i32 %".417", %"shf_result.6"
  %".423" = and i32 %".422", 0
  %".424" = or i32 %".421", %".423"
  %".425" = and i32 %"shf_result.7", %".418"
  %".426" = and i32 %".425", %".419"
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 %"shf_result.7", %".418"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 %"shf_result.7", %"shf_result.6"
  %".432" = and i32 %".431", %".419"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 %"shf_result.7", %"shf_result.6"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %".437" = xor i32 %".436", -1
  %".438" = xor i32 65535, -1
  %".439" = xor i32 0, -1
  %".440" = and i32 %".436", 65535
  %".441" = and i32 %".440", %".439"
  %".442" = and i32 %".436", 65535
  %".443" = and i32 %".442", 0
  %".444" = or i32 %".441", %".443"
  %".445" = xor i32 %".436", -1
  %".446" = xor i32 65535, -1
  %".447" = xor i32 %"lds.5", -1
  %".448" = and i32 %".436", 65535
  %".449" = and i32 %".448", %"lds.5"
  %"isetrp_cmp1.9" = icmp ne i32 %".449", %".444"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P46_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0ec0"
BB_0ec0:
  %"cond_trunc.21" = trunc i32 %"P46_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_1020_10e0", label %"BB_0ed0"
BB_0ed0:
  %".452" = zext i32 0 to i64
  %".453" = zext i32 %"lds.5" to i64
  %".454" = shl i64 %".453", 32
  %"shf_concat.8" = or i64 %".452", %".454"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".455" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".455", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".456" = zext i32 0 to i64
  %".457" = zext i32 %".436" to i64
  %".458" = shl i64 %".457", 32
  %"shf_concat.9" = or i64 %".456", %".458"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".459" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".459", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".460" = xor i32 %"shf_result.8", -1
  %".461" = xor i32 %"shf_result.9", -1
  %".462" = xor i32 0, -1
  %".463" = and i32 %"shf_result.8", %"shf_result.9"
  %".464" = and i32 %".463", %".462"
  %".465" = and i32 %"shf_result.8", %"shf_result.9"
  %".466" = and i32 %".465", 0
  %".467" = or i32 %".464", %".466"
  %"isetrp_cmp1.10" = icmp ne i32 %".467", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P48_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.22" = trunc i32 %"P48_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0ff0_1080", label %"BB_0f20"
BB_0f20:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".470" = xor i32 0, -1
  %".471" = xor i32 %".436", -1
  %".472" = xor i32 0, -1
  %".473" = and i32 %".470", %".471"
  %".474" = and i32 %".473", %".472"
  %".475" = and i32 %".470", %".471"
  %".476" = and i32 %".475", 0
  %".477" = or i32 %".474", %".476"
  %".478" = and i32 0, %".471"
  %".479" = and i32 %".478", %".472"
  %".480" = or i32 %".477", %".479"
  %".481" = and i32 0, %".471"
  %".482" = and i32 %".481", 0
  %".483" = or i32 %".480", %".482"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".483"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".484" = xor i32 %".483", -1
  %".485" = call i32 @"llvm.cttz.i32"(i32 %".484", i1 0)
  %".486" = shl i32 %".485", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 512;", "r,~{memory}"(i32 %".486") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0fc0"
BB_0fc0:
  %"cond_trunc.23" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000fc0", label %"BB_1030"
BB_80000fc0:
  %"atoms_shared_addr_winoff.1" = and i32 %".395", 16777215
  %".490" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_1030"
BB_0ff0_1080:
  call void @"llvm.trap"()
  br label %"BB_1030"
BB_1020_10e0:
  call void @"llvm.trap"()
  br label %"BB_1030"
BB_1030:
  ret void
BB_80000db0:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"isetrp_cmp1" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0060"
BB_0060:
  %"cond_trunc" = trunc i32 %"P1_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_80000060", label %"BB_00a0"
BB_80000060:
  %"cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"viadd" = add i32 1024, 1024
  %".24" = zext i32 %"cluster_ctarank" to i64
  %".25" = zext i32 %"viadd" to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  br label %"BB_00a0"
BB_00a0:
  %"phi" = phi  i32 [%".30", %"BB_80000060"], [0, %"BB_0060"]
  %"cond_trunc.1" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_01d0", label %"BB_00b0"
BB_00b0:
  %".33" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".34" = bitcast i8* %".33" to i64*
  %"ldc_const" = load i64, i64* %".34"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P20_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %".35" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".36" = zext i32 1024 to i64
  %".37" = zext i32 24 to i64
  %".38" = shl i64 %".35", %".37"
  %".39" = and i64 %".38", 4294967295
  %".40" = add i64 %".39", %".36"
  %".41" = trunc i64 %".40" to i32
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P20_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %".42" = zext i32 %"tid_x.1" to i64
  %".43" = zext i32 %".41" to i64
  %".44" = zext i32 2 to i64
  %".45" = shl i64 %".42", %".44"
  %".46" = and i64 %".45", 4294967295
  %".47" = add i64 %".46", %".43"
  %".48" = trunc i64 %".47" to i32
  br label %"BB_0140"
BB_0140:
  %"phi.1" = phi  i32 [%"imad_with_cin", %"BB_00b0"], [%"imad_with_cin.1", %"BB_01c0"]
  %"phi.2" = phi  i32 [%"tid_x.1", %"BB_00b0"], [%"viadd.1", %"BB_01c0"]
  %"phi.3" = phi  i32 [%".48", %"BB_00b0"], [%"viadd.2", %"BB_01c0"]
  %"phi.4" = phi  i32 [%"iadd3_trunc", %"BB_00b0"], [%"iadd3_trunc.1", %"BB_01c0"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.4" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R41:R161_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R41:R161_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd.1" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.4" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P30_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi.1"
  %"imad_cin_trunc.1" = trunc i32 %"P30_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".50" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".50" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.2" = add i32 %"phi.3", 512
  br label %"BB_01c0"
BB_01c0:
  %"cond_trunc.2" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0140", label %"BB_01d0"
BB_01d0:
  %"phi.5" = phi  i32 [0, %"BB_00a0"], [%"s2ur_cluster_ctarank", %"BB_01c0"]
  %"phi.6" = phi  i32 [%"P9_to_i32", %"BB_00a0"], [%"P21_to_i32", %"BB_01c0"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P31_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_0200"
BB_0200:
  %"cond_trunc.3" = trunc i32 %"P1_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000200", label %"BB_0210"
BB_80000200:
  br label %"BB_0210"
BB_0210:
  %"phi.7" = phi  i32 [%"phi", %"BB_80000200"], [0, %"BB_0200"]
  %"cond_trunc.4" = trunc i32 %"P31_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000210", label %"BB_0240"
BB_80000210:
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %".58" = zext i32 %"iadd3_n2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat" = or i64 %".58", %".60"
  %"shf_shift_64" = zext i32 11 to i64
  %".61" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".61" to i32
  %".62" = zext i32 %"iadd3_n2" to i64
  %".63" = zext i32 0 to i64
  %".64" = shl i64 %".63", 32
  %"shf_concat.1" = or i64 %".62", %".64"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".65" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".65" to i32
  br label %"BB_0240"
BB_0240:
  %"phi.8" = phi  i32 [%"shf_result", %"BB_80000210"], [%"phi.5", %"BB_0210"]
  %"phi.9" = phi  i32 [%"shf_result.1", %"BB_80000210"], [1, %"BB_0210"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P32_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0270"
BB_0270:
  %"cond_trunc.5" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000270", label %"BB_0280"
BB_80000270:
  %"mbar_shared_winoff" = and i32 %"phi.7", 16777215
  %".70" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".70" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.9" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.8" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".71" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".71" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0280"
BB_0280:
  %"cond_trunc.6" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0590", label %"BB_0290"
BB_0290:
  %"cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".75" = zext i32 %"cluster_ctarank.1" to i64
  %".76" = zext i32 64 to i64
  %".77" = zext i32 24 to i64
  %".78" = shl i64 %".75", %".77"
  %".79" = and i64 %".78", 4294967295
  %".80" = add i64 %".79", %".76"
  %".81" = trunc i64 %".80" to i32
  %"lds_shared_addr_winoff" = and i32 %".81", 16777215
  %".82" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".82"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.4" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P44_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0310"
BB_0310:
  %"cond_trunc.7" = trunc i32 %"P44_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0520", label %"BB_031f"
BB_031f:
  %"allocation_slot_winoff" = and i32 2056, 16777215
  %".85" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".86" = ptrtoint i8 addrspace(3)* %".85" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".86", i32 512) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P3_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0330"
BB_0330:
  %"cond_trunc.8" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0590", label %"BB_0340"
BB_0340:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 1
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 65535
  %"tmem_alloc_winoff" = and i32 2056, 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P35_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P35_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".94" = xor i32 %"plop3_a_bit", 1
  %".95" = xor i32 %"plop3_b_bit", 1
  %".96" = xor i32 %"plop3_c_bit", 1
  %".97" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".98" = and i32 %".97", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".98", 0
  %"P4_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.5" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P5_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.9" = trunc i32 %"P5_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0470", label %"BB_03e0"
BB_03e0:
  %"tmem_alloc_winoff.1" = and i32 2056, 16777215
  %".101" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".102" = bitcast i8 addrspace(3)* %".101" to i32 addrspace(3)*
  %".103" = load i32, i32 addrspace(3)* %".102"
  %".104" = lshr i32 %".103", 5
  %"P36_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P36_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".105" = xor i32 %"plop3_a_bit.1", 1
  %".106" = xor i32 %"plop3_b_bit.1", 1
  %".107" = xor i32 %"plop3_c_bit.1", 1
  %".108" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".109" = and i32 %".108", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".109", 0
  %"P6_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".104"
  br label %"BB_0460"
BB_0460:
  %"cond_trunc.10" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_03e0", label %"BB_0470"
BB_0470:
  %"phi.10" = phi  i32 [%"imad.5", %"BB_03d0"], [%"imad.6", %"BB_0460"]
  %"viadd.3" = add i32 %"phi.10", 16
  %".112" = zext i32 %"imad.4" to i64
  %".113" = zext i32 0 to i64
  %".114" = shl i64 %".113", 32
  %"shf_concat.2" = or i64 %".112", %".114"
  %"shf_shift_64.2" = zext i32 %"phi.10" to i64
  %".115" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".115" to i32
  %"imad_tmp.6" = mul i32 %"phi.10", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".116" = zext i32 %"imad.3" to i64
  %".117" = zext i32 0 to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.3" = or i64 %".116", %".118"
  %"shf_shift_64.3" = zext i32 %"viadd.3" to i64
  %".119" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".119" to i32
  %".120" = zext i32 %"cluster_ctarank.1" to i64
  %".121" = zext i32 1024 to i64
  %".122" = zext i32 24 to i64
  %".123" = shl i64 %".120", %".122"
  %".124" = and i64 %".123", 4294967295
  %".125" = add i64 %".124", %".121"
  %".126" = trunc i64 %".125" to i32
  %".127" = zext i32 %"cluster_ctarank.1" to i64
  %".128" = zext i32 80 to i64
  %".129" = zext i32 24 to i64
  %".130" = shl i64 %".127", %".129"
  %".131" = and i64 %".130", 4294967295
  %".132" = add i64 %".131", %".128"
  %".133" = trunc i64 %".132" to i32
  %".134" = xor i32 %"shf_result.3", -1
  %".135" = xor i32 %"shf_result.2", -1
  %".136" = xor i32 0, -1
  %".137" = and i32 %".134", %"shf_result.2"
  %".138" = and i32 %".137", %".136"
  %".139" = and i32 %".134", %"shf_result.2"
  %".140" = and i32 %".139", 0
  %".141" = or i32 %".138", %".140"
  %".142" = and i32 %"shf_result.3", %".135"
  %".143" = and i32 %".142", %".136"
  %".144" = or i32 %".141", %".143"
  %".145" = and i32 %"shf_result.3", %".135"
  %".146" = and i32 %".145", 0
  %".147" = or i32 %".144", %".146"
  %".148" = and i32 %"shf_result.3", %"shf_result.2"
  %".149" = and i32 %".148", %".136"
  %".150" = or i32 %".147", %".149"
  %".151" = and i32 %"shf_result.3", %"shf_result.2"
  %".152" = and i32 %".151", 0
  %".153" = or i32 %".150", %".152"
  %"atoms_shared_addr_winoff" = and i32 %".133", 16777215
  %".154" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".154" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".153" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".126", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".155" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".155" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0590"
BB_0520:
  %".158" = zext i32 %"cluster_ctarank.1" to i64
  %".159" = zext i32 1024 to i64
  %".160" = zext i32 24 to i64
  %".161" = shl i64 %".158", %".160"
  %".162" = and i64 %".161", 4294967295
  %".163" = add i64 %".162", %".159"
  %".164" = trunc i64 %".163" to i32
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".164", 1032
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".165" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0560_10b0"
BB_0560_10b0:
  call void @"llvm.trap"()
  br label %"BB_0590"
BB_0590:
  %"isetrp_cmp1.7" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %".169" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".170" = bitcast i8* %".169" to i64*
  %"ldc_const.1" = load i64, i64* %".170"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.8" = mul i32 %"tid_x.1", 18
  %"imad.9" = add i32 %"imad_tmp.8", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.9" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.10" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.10" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.10", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  call void @"llvm.nvvm.barrier0"()
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R82:R64_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R82:R64_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R82:R64_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R82:R64_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R82:R64_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R82:R64_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R82:R64_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R82:R64_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.7"
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"imad_tmp.9" = mul i32 %"tid_x.1", 65536
  %"imad.11" = add i32 %"imad_tmp.9", 0
  %".171" = xor i32 %"imad.11", -1
  %".172" = xor i32 65011712, -1
  %".173" = xor i32 0, -1
  %".174" = and i32 %"imad.11", 65011712
  %".175" = and i32 %".174", %".173"
  %".176" = and i32 %"imad.11", 65011712
  %".177" = and i32 %".176", 0
  %".178" = or i32 %".175", %".177"
  %".179" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".180" = zext i32 1024 to i64
  %".181" = zext i32 24 to i64
  %".182" = shl i64 %".179", %".181"
  %".183" = and i64 %".182", 4294967295
  %".184" = add i64 %".183", %".180"
  %".185" = trunc i64 %".184" to i32
  %"lds_addr_memaddr_offset_add" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".186" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".186" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %"imad_tmp.10" = mul i32 %"lds.1", 1
  %"imad.12" = add i32 %"imad_tmp.10", %".178"
  %"sttm_memaddr_offset_add" = add i32 %"imad.12", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.12", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R82:R64_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R82:R64_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R82:R64_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R82:R64_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R82:R64_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R82:R64_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R82:R64_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R82:R64_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R82:R64_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.12", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.12", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0840"
BB_0840:
  %"cond_trunc.11" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0a90", label %"BB_0850"
BB_0850:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".196" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".197" = zext i32 0 to i64
  %".198" = zext i32 %".185" to i64
  %".199" = shl i64 %".198", 32
  %"shf_concat.4" = or i64 %".197", %".199"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".200" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".200", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".201" = xor i32 %"plop3_a_bit.2", 1
  %".202" = xor i32 %"plop3_b_bit.2", 1
  %".203" = xor i32 %"plop3_c_bit.2", 1
  %".204" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".205" = and i32 %".204", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".205", 0
  %"P33_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".206" = xor i32 %"shf_result.4", -1
  %".207" = xor i32 16376, -1
  %".208" = xor i32 0, -1
  %".209" = and i32 %"shf_result.4", 16376
  %".210" = and i32 %".209", %".208"
  %".211" = and i32 %"shf_result.4", 16376
  %".212" = and i32 %".211", 0
  %".213" = or i32 %".210", %".212"
  %".214" = xor i32 %".213", -1
  %".215" = xor i32 524288, -1
  %".216" = xor i32 0, -1
  %".217" = and i32 %".214", 524288
  %".218" = and i32 %".217", %".216"
  %".219" = and i32 %".214", 524288
  %".220" = and i32 %".219", 0
  %".221" = or i32 %".218", %".220"
  %".222" = and i32 %".213", %".215"
  %".223" = and i32 %".222", %".216"
  %".224" = or i32 %".221", %".223"
  %".225" = and i32 %".213", %".215"
  %".226" = and i32 %".225", 0
  %".227" = or i32 %".224", %".226"
  %".228" = and i32 %".213", 524288
  %".229" = and i32 %".228", %".216"
  %".230" = or i32 %".227", %".229"
  %".231" = and i32 %".213", 524288
  %".232" = and i32 %".231", 0
  %".233" = or i32 %".230", %".232"
  %"iadd3_n1.1" = add i32 %"lds.2", 32
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_n1.2" = add i32 %"lds.2", 16
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.2", 20
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  br label %"BB_0910"
BB_0910:
  %"phi.11" = phi  i32 [%"phi.6", %"BB_0850"], [%"P28_to_i32", %"BB_0940"]
  %"phi.12" = phi  i32 [%"P33_to_i32", %"BB_0850"], [%"phi.14", %"BB_0940"]
  %"cond_trunc.12" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P26_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.13" = phi  i32 [%"P26_to_i32", %"BB_80000910"], [%"phi.11", %"BB_0910"]
  %"mma_b_r0_ext" = zext i32 %".233" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".237" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".238" = sub i64 %".237", 0
  %".239" = lshr i64 %".238", 4
  %".240" = add i64 %"mma_b_packed_1", %".239"
  %".241" = and i64 %".240", 16383
  %".242" = and i64 %"mma_b_packed_1", -16384
  %".243" = or i64 %".242", %".241"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.2", i32 %"iadd3_n2.1", i64 %".243", i32 679744944, i32 %"mma_arg_zext", i32 %"iadd3_n2.2", i32 %"iadd3_n2.3")
  br label %"BB_0930"
BB_0930:
  %"cond_trunc.13" = trunc i32 %"phi.13" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000930", label %"BB_0940"
BB_80000930:
  %"lop3_a_trunc" = trunc i32 %"phi.13" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".247" = xor i32 %"plop3_a_bit.3", 1
  %".248" = xor i32 %"plop3_b_bit.3", 1
  %".249" = xor i32 %"plop3_c_bit.3", 1
  %".250" = and i32 %".247", %"plop3_b_bit.3"
  %".251" = and i32 %".250", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".251", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0940"
BB_0940:
  %"phi.14" = phi  i32 [%"P39_to_i32", %"BB_80000930"], [%"phi.12", %"BB_0930"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".253" = xor i32 %"plop3_a_bit.4", 1
  %".254" = xor i32 %"plop3_b_bit.4", 1
  %".255" = xor i32 %"plop3_c_bit.4", 1
  %".256" = and i32 %".253", %"plop3_b_bit.4"
  %".257" = and i32 %".256", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".257", 0
  %"P28_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.14" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_0910", label %"BB_0960"
BB_0960:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".259" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".259" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".260" = xor i32 %"plop3_a_bit.5", 1
  %".261" = xor i32 %"plop3_b_bit.5", 1
  %".262" = xor i32 %"plop3_c_bit.5", 1
  %".263" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".264" = and i32 %".263", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".264", 0
  %"P47_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"iadd3_n1.4" = add i32 %"lds.3", 32
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.3", 16
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"iadd3_n1.6" = add i32 %"lds.3", 20
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  br label %"BB_09c0"
BB_09c0:
  %"phi.15" = phi  i32 [%"P28_to_i32", %"BB_0960"], [%"P14_to_i32", %"BB_09f0"]
  %"phi.16" = phi  i32 [%"P47_to_i32", %"BB_0960"], [%"phi.18", %"BB_09f0"]
  %"cond_trunc.14" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009c0", label %"BB_09d0"
BB_800009c0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P11_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09d0"
BB_09d0:
  %"phi.17" = phi  i32 [%"P11_to_i32", %"BB_800009c0"], [%"phi.15", %"BB_09c0"]
  %"mma_b_r0_ext.1" = zext i32 %".233" to i64
  %"mma_b_packed_0.1" = or i64 0, %"mma_b_r0_ext.1"
  %"mma_b_r1_ext.1" = zext i32 16400 to i64
  %"mma_b_r1_shift.1" = shl i64 %"mma_b_r1_ext.1", 32
  %"mma_b_packed_1.1" = or i64 %"mma_b_packed_0.1", %"mma_b_r1_shift.1"
  %".268" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".269" = sub i64 %".268", 0
  %".270" = lshr i64 %".269", 4
  %".271" = add i64 %"mma_b_packed_1.1", %".270"
  %".272" = and i64 %".271", 16383
  %".273" = and i64 %"mma_b_packed_1.1", -16384
  %".274" = or i64 %".273", %".272"
  %"mma_arg_zext.1" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.3", i32 %"iadd3_n2.4", i64 %".274", i32 679744944, i32 %"mma_arg_zext.1", i32 %"iadd3_n2.5", i32 %"iadd3_n2.6")
  br label %"BB_09e0"
BB_09e0:
  %"cond_trunc.15" = trunc i32 %"phi.17" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800009e0", label %"BB_09f0"
BB_800009e0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.17" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".278" = xor i32 %"plop3_a_bit.6", 1
  %".279" = xor i32 %"plop3_b_bit.6", 1
  %".280" = xor i32 %"plop3_c_bit.6", 1
  %".281" = and i32 %".278", %"plop3_b_bit.6"
  %".282" = and i32 %".281", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".282", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09f0"
BB_09f0:
  %"phi.18" = phi  i32 [%"P29_to_i32", %"BB_800009e0"], [%"phi.16", %"BB_09e0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".284" = xor i32 %"plop3_a_bit.7", 1
  %".285" = xor i32 %"plop3_b_bit.7", 1
  %".286" = xor i32 %"plop3_c_bit.7", 1
  %".287" = and i32 %".284", %"plop3_b_bit.7"
  %".288" = and i32 %".287", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".288", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.18" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09c0", label %"BB_0a10"
BB_0a10:
  %"iadd3_n1.7" = add i32 1024, 1024
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".290" = xor i32 %"plop3_a_bit.8", 1
  %".291" = xor i32 %"plop3_b_bit.8", 1
  %".292" = xor i32 %"plop3_c_bit.8", 1
  %".293" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".294" = and i32 %".293", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".294", 0
  %"P41_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".295" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".296" = zext i32 %"iadd3_n2.7" to i64
  %".297" = zext i32 24 to i64
  %".298" = shl i64 %".295", %".297"
  %".299" = and i64 %".298", 4294967295
  %".300" = add i64 %".299", %".296"
  %".301" = trunc i64 %".300" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.19" = phi  i32 [%"P14_to_i32", %"BB_0a10"], [%"P18_to_i32", %"BB_0a70"]
  %"phi.20" = phi  i32 [%"P41_to_i32", %"BB_0a10"], [%"phi.22", %"BB_0a70"]
  %"cond_trunc.16" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000a40", label %"BB_0a50"
BB_80000a40:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P16_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0a50"
BB_0a50:
  %"phi.21" = phi  i32 [%"P16_to_i32", %"BB_80000a40"], [%"phi.19", %"BB_0a40"]
  %"utcbar_local_winoff" = and i32 %".301", 16777215
  %".305" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".306" = ptrtoint i8 addrspace(3)* %".305" to i32
  %".307" = lshr i32 %".301", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".306", i32 %".307")
  br label %"BB_0a60"
BB_0a60:
  %"cond_trunc.17" = trunc i32 %"phi.21" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_80000a60", label %"BB_0a70"
BB_80000a60:
  %"lop3_a_trunc.2" = trunc i32 %"phi.21" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".311" = xor i32 %"plop3_a_bit.9", 1
  %".312" = xor i32 %"plop3_b_bit.9", 1
  %".313" = xor i32 %"plop3_c_bit.9", 1
  %".314" = and i32 %".311", %"plop3_b_bit.9"
  %".315" = and i32 %".314", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".315", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0a70"
BB_0a70:
  %"phi.22" = phi  i32 [%"P43_to_i32", %"BB_80000a60"], [%"phi.20", %"BB_0a60"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".317" = xor i32 %"plop3_a_bit.10", 1
  %".318" = xor i32 %"plop3_b_bit.10", 1
  %".319" = xor i32 %"plop3_c_bit.10", 1
  %".320" = and i32 %".317", %"plop3_b_bit.10"
  %".321" = and i32 %".320", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".321", 0
  %"P18_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.22" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0a40", label %"BB_0a90"
BB_0a90:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.8" = add i32 1024, 1024
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".323" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".324" = zext i32 %"iadd3_n2.8" to i64
  %".325" = zext i32 24 to i64
  %".326" = shl i64 %".323", %".325"
  %".327" = and i64 %".326", 4294967295
  %".328" = add i64 %".327", %".324"
  %".329" = trunc i64 %".328" to i32
  %"mbar_shared_winoff.1" = and i32 %".329", 16777215
  %".330" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".330" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P23_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0ae0"
BB_0ae0:
  %"cond_trunc.18" = trunc i32 %"P23_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_1050", label %"BB_0af0"
BB_1050:
  %"mbar_shared_winoff.2" = and i32 %".329", 16777215
  %".333" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".333" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P34_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_1060"
BB_1060:
  %"cond_trunc.19" = trunc i32 %"P34_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.19", -1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_1050", label %"BB_0af0"
BB_0af0:
  %".336" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".337" = bitcast i8* %".336" to i64*
  %"ldc_const.2" = load i64, i64* %".337"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.11" = mul i32 %"tid_x.1", 24
  %"imad.13" = add i32 %"imad_tmp.11", 0
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P45_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.12")
  %".338" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".339" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".340" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".341" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.12", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".342" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".343" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".344" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".345" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.13" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.14" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.14" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.14", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R105:R91_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".338", i32 addrspace(1)* %"R105:R91_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R105:R91_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".339", i32 addrspace(1)* %"R105:R91_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R105:R91_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".340", i32 addrspace(1)* %"R105:R91_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R105:R91_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".341", i32 addrspace(1)* %"R105:R91_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R105:R91_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".342", i32 addrspace(1)* %"R105:R91_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.12", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".351" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".352" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".353" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".354" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R105:R91_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".343", i32 addrspace(1)* %"R105:R91_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R105:R91_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".344", i32 addrspace(1)* %"R105:R91_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R105:R91_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".345", i32 addrspace(1)* %"R105:R91_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.12", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".358" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".359" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".360" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".361" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R105:R91_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".351", i32 addrspace(1)* %"R105:R91_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R105:R91_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".352", i32 addrspace(1)* %"R105:R91_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R105:R91_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".353", i32 addrspace(1)* %"R105:R91_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R105:R91_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".354", i32 addrspace(1)* %"R105:R91_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R105:R91_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".358", i32 addrspace(1)* %"R105:R91_addr_ptr.12"
  %"ldtm_addr_memaddr_offset_add.3" = add i32 %"imad.12", 16
  %"ldtm.4" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.3")
  %".367" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 0
  %".368" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 1
  %".369" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 2
  %".370" = extractvalue {i32, i32, i32, i32} %"ldtm.4", 3
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R105:R91_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".359", i32 addrspace(1)* %"R105:R91_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R105:R91_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".360", i32 addrspace(1)* %"R105:R91_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R105:R91_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".361", i32 addrspace(1)* %"R105:R91_addr_ptr.15"
  %"ldtm_addr_memaddr_offset_add.4" = add i32 %"imad.12", 20
  %"ldtm.5" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.4")
  %".374" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 0
  %".375" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 1
  %".376" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 2
  %".377" = extractvalue {i32, i32, i32, i32} %"ldtm.5", 3
  %"stg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.16" = or i64 0, %"stg_addr_r0_ext.16"
  %"stg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.16" = shl i64 %"stg_addr_r1_ext.16", 32
  %"stg_addr_packed_1.16" = or i64 %"stg_addr_packed_0.16", %"stg_addr_r1_shift.16"
  %"stg_addr_memaddr_offset_add.15" = add i64 %"stg_addr_packed_1.16", 64
  %"R105:R91_addr_ptr.16" = inttoptr i64 %"stg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  store i32 %".367", i32 addrspace(1)* %"R105:R91_addr_ptr.16"
  %"stg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.17" = or i64 0, %"stg_addr_r0_ext.17"
  %"stg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.17" = shl i64 %"stg_addr_r1_ext.17", 32
  %"stg_addr_packed_1.17" = or i64 %"stg_addr_packed_0.17", %"stg_addr_r1_shift.17"
  %"stg_addr_memaddr_offset_add.16" = add i64 %"stg_addr_packed_1.17", 68
  %"R105:R91_addr_ptr.17" = inttoptr i64 %"stg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  store i32 %".368", i32 addrspace(1)* %"R105:R91_addr_ptr.17"
  %"stg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.18" = or i64 0, %"stg_addr_r0_ext.18"
  %"stg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.18" = shl i64 %"stg_addr_r1_ext.18", 32
  %"stg_addr_packed_1.18" = or i64 %"stg_addr_packed_0.18", %"stg_addr_r1_shift.18"
  %"stg_addr_memaddr_offset_add.17" = add i64 %"stg_addr_packed_1.18", 72
  %"R105:R91_addr_ptr.18" = inttoptr i64 %"stg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  store i32 %".369", i32 addrspace(1)* %"R105:R91_addr_ptr.18"
  %"stg_addr_r0_ext.19" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.19" = or i64 0, %"stg_addr_r0_ext.19"
  %"stg_addr_r1_ext.19" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.19" = shl i64 %"stg_addr_r1_ext.19", 32
  %"stg_addr_packed_1.19" = or i64 %"stg_addr_packed_0.19", %"stg_addr_r1_shift.19"
  %"stg_addr_memaddr_offset_add.18" = add i64 %"stg_addr_packed_1.19", 76
  %"R105:R91_addr_ptr.19" = inttoptr i64 %"stg_addr_memaddr_offset_add.18" to i32 addrspace(1)*
  store i32 %".370", i32 addrspace(1)* %"R105:R91_addr_ptr.19"
  %"stg_addr_r0_ext.20" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.20" = or i64 0, %"stg_addr_r0_ext.20"
  %"stg_addr_r1_ext.20" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.20" = shl i64 %"stg_addr_r1_ext.20", 32
  %"stg_addr_packed_1.20" = or i64 %"stg_addr_packed_0.20", %"stg_addr_r1_shift.20"
  %"stg_addr_memaddr_offset_add.19" = add i64 %"stg_addr_packed_1.20", 80
  %"R105:R91_addr_ptr.20" = inttoptr i64 %"stg_addr_memaddr_offset_add.19" to i32 addrspace(1)*
  store i32 %".374", i32 addrspace(1)* %"R105:R91_addr_ptr.20"
  %"stg_addr_r0_ext.21" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.21" = or i64 0, %"stg_addr_r0_ext.21"
  %"stg_addr_r1_ext.21" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.21" = shl i64 %"stg_addr_r1_ext.21", 32
  %"stg_addr_packed_1.21" = or i64 %"stg_addr_packed_0.21", %"stg_addr_r1_shift.21"
  %"stg_addr_memaddr_offset_add.20" = add i64 %"stg_addr_packed_1.21", 84
  %"R105:R91_addr_ptr.21" = inttoptr i64 %"stg_addr_memaddr_offset_add.20" to i32 addrspace(1)*
  store i32 %".375", i32 addrspace(1)* %"R105:R91_addr_ptr.21"
  %"stg_addr_r0_ext.22" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.22" = or i64 0, %"stg_addr_r0_ext.22"
  %"stg_addr_r1_ext.22" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.22" = shl i64 %"stg_addr_r1_ext.22", 32
  %"stg_addr_packed_1.22" = or i64 %"stg_addr_packed_0.22", %"stg_addr_r1_shift.22"
  %"stg_addr_memaddr_offset_add.21" = add i64 %"stg_addr_packed_1.22", 88
  %"R105:R91_addr_ptr.22" = inttoptr i64 %"stg_addr_memaddr_offset_add.21" to i32 addrspace(1)*
  store i32 %".376", i32 addrspace(1)* %"R105:R91_addr_ptr.22"
  %"stg_addr_r0_ext.23" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.23" = or i64 0, %"stg_addr_r0_ext.23"
  %"stg_addr_r1_ext.23" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.23" = shl i64 %"stg_addr_r1_ext.23", 32
  %"stg_addr_packed_1.23" = or i64 %"stg_addr_packed_0.23", %"stg_addr_r1_shift.23"
  %"stg_addr_memaddr_offset_add.22" = add i64 %"stg_addr_packed_1.23", 92
  %"R105:R91_addr_ptr.23" = inttoptr i64 %"stg_addr_memaddr_offset_add.22" to i32 addrspace(1)*
  store i32 %".377", i32 addrspace(1)* %"R105:R91_addr_ptr.23"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0db0"
BB_0db0:
  %"cond_trunc.20" = trunc i32 %"P45_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_80000db0", label %"BB_0dc0"
BB_0dc0:
  %"lds_addr_memaddr_offset_add.3" = add i32 %".185", 1032
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".388" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".388" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 65535
  %".389" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".390" = zext i32 80 to i64
  %".391" = zext i32 24 to i64
  %".392" = shl i64 %".389", %".391"
  %".393" = and i64 %".392", 4294967295
  %".394" = add i64 %".393", %".390"
  %".395" = trunc i64 %".394" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %"lds_shared_addr_winoff.5" = and i32 %".395", 16777215
  %".396" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.5"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".396" to i32 addrspace(3)*
  %"lds.5" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".397" = xor i32 %"lds.4", -1
  %".398" = xor i32 65535, -1
  %".399" = xor i32 0, -1
  %".400" = and i32 %"lds.4", 65535
  %".401" = and i32 %".400", %".399"
  %".402" = and i32 %"lds.4", 65535
  %".403" = and i32 %".402", 0
  %".404" = or i32 %".401", %".403"
  %".405" = zext i32 0 to i64
  %".406" = zext i32 %".404" to i64
  %".407" = shl i64 %".406", 32
  %"shf_concat.5" = or i64 %".405", %".407"
  %"shf_shift_64.5" = zext i32 5 to i64
  %".408" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".408", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %"viadd.4" = add i32 %"shf_result.5", 16
  %".409" = zext i32 %"imad.15" to i64
  %".410" = zext i32 0 to i64
  %".411" = shl i64 %".410", 32
  %"shf_concat.6" = or i64 %".409", %".411"
  %"shf_shift_64.6" = zext i32 %"shf_result.5" to i64
  %".412" = shl i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_result.6" = trunc i64 %".412" to i32
  %".413" = zext i32 %"imad.16" to i64
  %".414" = zext i32 0 to i64
  %".415" = shl i64 %".414", 32
  %"shf_concat.7" = or i64 %".413", %".415"
  %"shf_shift_64.7" = zext i32 %"viadd.4" to i64
  %".416" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".416" to i32
  %".417" = xor i32 %"shf_result.7", -1
  %".418" = xor i32 %"shf_result.6", -1
  %".419" = xor i32 0, -1
  %".420" = and i32 %".417", %"shf_result.6"
  %".421" = and i32 %".420", %".419"
  %".422" = and i32 %".417", %"shf_result.6"
  %".423" = and i32 %".422", 0
  %".424" = or i32 %".421", %".423"
  %".425" = and i32 %"shf_result.7", %".418"
  %".426" = and i32 %".425", %".419"
  %".427" = or i32 %".424", %".426"
  %".428" = and i32 %"shf_result.7", %".418"
  %".429" = and i32 %".428", 0
  %".430" = or i32 %".427", %".429"
  %".431" = and i32 %"shf_result.7", %"shf_result.6"
  %".432" = and i32 %".431", %".419"
  %".433" = or i32 %".430", %".432"
  %".434" = and i32 %"shf_result.7", %"shf_result.6"
  %".435" = and i32 %".434", 0
  %".436" = or i32 %".433", %".435"
  %".437" = xor i32 %".436", -1
  %".438" = xor i32 65535, -1
  %".439" = xor i32 0, -1
  %".440" = and i32 %".436", 65535
  %".441" = and i32 %".440", %".439"
  %".442" = and i32 %".436", 65535
  %".443" = and i32 %".442", 0
  %".444" = or i32 %".441", %".443"
  %".445" = xor i32 %".436", -1
  %".446" = xor i32 65535, -1
  %".447" = xor i32 %"lds.5", -1
  %".448" = and i32 %".436", 65535
  %".449" = and i32 %".448", %"lds.5"
  %"isetrp_cmp1.9" = icmp ne i32 %".449", %".444"
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P46_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0ec0"
BB_0ec0:
  %"cond_trunc.21" = trunc i32 %"P46_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_1020_10e0", label %"BB_0ed0"
BB_0ed0:
  %".452" = zext i32 0 to i64
  %".453" = zext i32 %"lds.5" to i64
  %".454" = shl i64 %".453", 32
  %"shf_concat.8" = or i64 %".452", %".454"
  %"shf_shift_64.8" = zext i32 16 to i64
  %".455" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.2" = lshr i64 %".455", 32
  %"shf_result.8" = trunc i64 %"shf_hi.2" to i32
  %".456" = zext i32 0 to i64
  %".457" = zext i32 %".436" to i64
  %".458" = shl i64 %".457", 32
  %"shf_concat.9" = or i64 %".456", %".458"
  %"shf_shift_64.9" = zext i32 16 to i64
  %".459" = lshr i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_hi.3" = lshr i64 %".459", 32
  %"shf_result.9" = trunc i64 %"shf_hi.3" to i32
  %".460" = xor i32 %"shf_result.8", -1
  %".461" = xor i32 %"shf_result.9", -1
  %".462" = xor i32 0, -1
  %".463" = and i32 %"shf_result.8", %"shf_result.9"
  %".464" = and i32 %".463", %".462"
  %".465" = and i32 %"shf_result.8", %"shf_result.9"
  %".466" = and i32 %".465", 0
  %".467" = or i32 %".464", %".466"
  %"isetrp_cmp1.10" = icmp ne i32 %".467", %"shf_result.9"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P48_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0f10"
BB_0f10:
  %"cond_trunc.22" = trunc i32 %"P48_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_0ff0_1080", label %"BB_0f20"
BB_0f20:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".470" = xor i32 0, -1
  %".471" = xor i32 %".436", -1
  %".472" = xor i32 0, -1
  %".473" = and i32 %".470", %".471"
  %".474" = and i32 %".473", %".472"
  %".475" = and i32 %".470", %".471"
  %".476" = and i32 %".475", 0
  %".477" = or i32 %".474", %".476"
  %".478" = and i32 0, %".471"
  %".479" = and i32 %".478", %".472"
  %".480" = or i32 %".477", %".479"
  %".481" = and i32 0, %".471"
  %".482" = and i32 %".481", 0
  %".483" = or i32 %".480", %".482"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".483"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".484" = xor i32 %".483", -1
  %".485" = call i32 @"llvm.cttz.i32"(i32 %".484", i1 0)
  %".486" = shl i32 %".485", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 512;", "r,~{memory}"(i32 %".486") convergent
  %"isetrp_cmp1.11" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_0fc0"
BB_0fc0:
  %"cond_trunc.23" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000fc0", label %"BB_1030"
BB_80000fc0:
  %"atoms_shared_addr_winoff.1" = and i32 %".395", 16777215
  %".490" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_1030"
BB_0ff0_1080:
  call void @"llvm.trap"()
  br label %"BB_1030"
BB_1020_10e0:
  call void @"llvm.trap"()
  br label %"BB_1030"
BB_1030:
  ret void
BB_80000db0:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case3EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
