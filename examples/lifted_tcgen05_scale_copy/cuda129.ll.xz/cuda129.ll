; ModuleID = "tcgen05_scale_copy_sm100a_cuda12"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [11280 x i8], align 16
define void @"_Z13column_scaledIL4Case5EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"P24_to_i32" = zext i1 0 to i32
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R83:R48_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R83:R48_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P17_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P17_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P26_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P20_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P20_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R71:R11_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R71:R11_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P38_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P38_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"viadd", %"BB_01a0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.10" = phi  i32 [%"ldg", %"BB_01a0"], [%"viadd.2", %"BB_0290"]
  %"phi.11" = phi  i32 [%"iadd3_trunc", %"BB_01a0"], [%"viadd.3", %"BB_0290"]
  %"phi.12" = phi  i32 [%"R3:R2_r1.1", %"BB_01a0"], [%"ldg.1", %"BB_0290"]
  %"phi.13" = phi  i32 [%"R3:R2_r0.1", %"BB_01a0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"phi.14" = phi  i32 [%"P24_to_i32", %"BB_01a0"], [%"P38_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P58_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P48_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 10240
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.15" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.15" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.16" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.15", %"BB_02e0"]
  %"phi.17" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.18" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P58_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P49_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P49_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.16", 16777215
  %".88" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.18" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.17" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 11272, 16777215
  %".103" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P13_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0600", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 11272, 16777215
  %".108" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P50_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P50_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P14_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P14_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P16_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 11272, 16777215
  %".119" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P51_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P51_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.19" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.19", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.19" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.19", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 10248
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0600"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 10248
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_1130"
BB_05f0_1130:
  call void @"llvm.trap"()
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", 0
  br label %"BB_0600"
BB_0600:
  %"phi.20" = phi  i32 [%".140", %"BB_0520"], [%".99", %"BB_03f0"], [%".99", %"BB_05f0_1130"]
  %"phi.21" = phi  i32 [%"imad.4", %"BB_0520"], [%"phi.10", %"BB_03f0"], [%"phi.10", %"BB_05f0_1130"]
  %"phi.22" = phi  i32 [%"shf_result.3", %"BB_0520"], [%"phi.11", %"BB_03f0"], [%"phi.11", %"BB_05f0_1130"]
  %"phi.23" = phi  i32 [%".164", %"BB_0520"], [%"phi.12", %"BB_03f0"], [%"imad.9", %"BB_05f0_1130"]
  %"phi.24" = phi  i32 [%"imad.7", %"BB_0520"], [%"lds_zext", %"BB_03f0"], [1536, %"BB_05f0_1130"]
  br label %"BB_0620"
BB_0620:
  %"phi.25" = phi  i32 [%"phi.20", %"BB_0600"], [%"phi.18", %"BB_0360"]
  %"phi.26" = phi  i32 [%"phi.21", %"BB_0600"], [%"phi.10", %"BB_0360"]
  %"phi.27" = phi  i32 [%"phi.22", %"BB_0600"], [%"phi.11", %"BB_0360"]
  %"phi.28" = phi  i32 [%"phi.23", %"BB_0600"], [%"phi.12", %"BB_0360"]
  %"phi.29" = phi  i32 [%"phi.24", %"BB_0600"], [%"phi.13", %"BB_0360"]
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  br label %"BB_0650"
BB_0650:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000650", label %"BB_0680"
BB_80000650:
  %".176" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".177" = bitcast i8* %".176" to i64*
  %"ldc_const.1" = load i64, i64* %".177"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.9" = mul i32 %"tid_x.1", 10
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.10" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.11" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.11" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.11", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  br label %"BB_0680"
BB_0680:
  %"phi.30" = phi  i32 [%"imad.10", %"BB_80000650"], [%"phi.26", %"BB_0650"]
  %"phi.31" = phi  i32 [%"R3:R2_r1.3", %"BB_80000650"], [%"phi.28", %"BB_0650"]
  %"phi.32" = phi  i32 [%"R3:R2_r0.3", %"BB_80000650"], [%"phi.29", %"BB_0650"]
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0690"
BB_0690:
  %"cond_trunc.12" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000690", label %"BB_0710"
BB_80000690:
  %"ldg_addr_r0_ext.2" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R26:R200_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R26:R200_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R26:R200_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R26:R200_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R26:R200_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R26:R200_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R26:R200_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R26:R200_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.7"
  br label %"BB_0710"
BB_0710:
  %"phi.33" = phi  i32 [%"ldg.3", %"BB_80000690"], [%"imad_with_cin", %"BB_0690"]
  %"phi.34" = phi  i32 [%"ldg.2", %"BB_80000690"], [0, %"BB_0690"]
  %"phi.35" = phi  i32 [%"ldg.9", %"BB_80000690"], [%"phi.9", %"BB_0690"]
  %"phi.36" = phi  i32 [%"ldg.8", %"BB_80000690"], [%"viadd.1", %"BB_0690"]
  %"phi.37" = phi  i32 [%"ldg.7", %"BB_80000690"], [%"phi.30", %"BB_0690"]
  %"phi.38" = phi  i32 [%"ldg.6", %"BB_80000690"], [%"phi.27", %"BB_0690"]
  %"phi.39" = phi  i32 [%"ldg.5", %"BB_80000690"], [0, %"BB_0690"]
  %"phi.40" = phi  i32 [%"ldg.4", %"BB_80000690"], [0, %"BB_0690"]
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"vote_pred_trunc.2" = trunc i32 %"P22_to_i32" to i1
  %"vote_all.2" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.2")
  %"P53_to_i32" = zext i1 %"vote_all.2" to i32
  %"isetrp_cmp1.9" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P52_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0760"
BB_0760:
  %"cond_trunc.13" = trunc i32 %"P53_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000760", label %"BB_0790"
BB_80000760:
  %"iadd3_n1.3" = add i32 1024, 9216
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 1024, 9728
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %".184" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".185" = zext i32 %"iadd3_n2.3" to i64
  %".186" = zext i32 24 to i64
  %".187" = shl i64 %".184", %".186"
  %".188" = and i64 %".187", 4294967295
  %".189" = add i64 %".188", %".185"
  %".190" = trunc i64 %".189" to i32
  br label %"BB_0790"
BB_0790:
  %"phi.41" = phi  i32 [%".190", %"BB_80000760"], [%"phi.17", %"BB_0760"]
  %"phi.42" = phi  i32 [%"iadd3_n2.4", %"BB_80000760"], [%"phi.25", %"BB_0760"]
  %".192" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".193" = zext i32 1024 to i64
  %".194" = zext i32 24 to i64
  %".195" = shl i64 %".192", %".194"
  %".196" = and i64 %".195", 4294967295
  %".197" = add i64 %".196", %".193"
  %".198" = trunc i64 %".197" to i32
  br label %"BB_07a0"
BB_07a0:
  %"cond_trunc.14" = trunc i32 %"P53_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800007a0", label %"BB_07b0"
BB_800007a0:
  %".201" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".202" = zext i32 %"phi.42" to i64
  %".203" = zext i32 24 to i64
  %".204" = shl i64 %".201", %".203"
  %".205" = and i64 %".204", 4294967295
  %".206" = add i64 %".205", %".202"
  %".207" = trunc i64 %".206" to i32
  br label %"BB_07b0"
BB_07b0:
  %"phi.43" = phi  i32 [%".207", %"BB_800007a0"], [%"phi.42", %"BB_07a0"]
  %"cond_trunc.15" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800007b0", label %"BB_07d0"
BB_800007b0:
  %".210" = zext i32 %"tid_x.1" to i64
  %".211" = zext i32 %"phi.41" to i64
  %".212" = zext i32 4 to i64
  %".213" = shl i64 %".210", %".212"
  %".214" = and i64 %".213", 4294967295
  %".215" = add i64 %".214", %".211"
  %".216" = trunc i64 %".215" to i32
  %".217" = zext i32 %"tid_x.1" to i64
  %".218" = zext i32 %"phi.43" to i64
  %".219" = zext i32 4 to i64
  %".220" = shl i64 %".217", %".219"
  %".221" = and i64 %".220", 4294967295
  %".222" = add i64 %".221", %".218"
  %".223" = trunc i64 %".222" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.44" = phi  i32 [%".223", %"BB_800007b0"], [%"phi.32", %"BB_07b0"]
  %"phi.45" = phi  i32 [%".216", %"BB_800007b0"], [0, %"BB_07b0"]
  %"lds_addr_memaddr_offset_add" = add i32 %".198", 10248
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".225" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".225" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  br label %"BB_07e0"
BB_07e0:
  %"cond_trunc.16" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800007e0", label %"BB_0800"
BB_800007e0:
  %"sts_val_r0_ext" = zext i32 %"phi.34" to i128
  %"sts_val_packed_0" = or i128 0, %"sts_val_r0_ext"
  %"sts_val_r1_ext" = zext i32 %"phi.33" to i128
  %"sts_val_r1_shift" = shl i128 %"sts_val_r1_ext", 32
  %"sts_val_packed_1" = or i128 %"sts_val_packed_0", %"sts_val_r1_shift"
  %"sts_val_r2_ext" = zext i32 %"phi.40" to i128
  %"sts_val_r2_shift" = shl i128 %"sts_val_r2_ext", 64
  %"sts_val_packed_2" = or i128 %"sts_val_packed_1", %"sts_val_r2_shift"
  %"sts_val_r3_ext" = zext i32 %"phi.39" to i128
  %"sts_val_r3_shift" = shl i128 %"sts_val_r3_ext", 96
  %"sts_val_packed_3" = or i128 %"sts_val_packed_2", %"sts_val_r3_shift"
  %"sts_shared_addr_winoff.4" = and i32 %"phi.45", 16777215
  %".228" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".228" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3", i128 addrspace(3)* %"sts_shared_addr_cast.4"
  %"sts_val_r0_ext.1" = zext i32 %"phi.38" to i128
  %"sts_val_packed_0.1" = or i128 0, %"sts_val_r0_ext.1"
  %"sts_val_r1_ext.1" = zext i32 %"phi.37" to i128
  %"sts_val_r1_shift.1" = shl i128 %"sts_val_r1_ext.1", 32
  %"sts_val_packed_1.1" = or i128 %"sts_val_packed_0.1", %"sts_val_r1_shift.1"
  %"sts_val_r2_ext.1" = zext i32 %"phi.36" to i128
  %"sts_val_r2_shift.1" = shl i128 %"sts_val_r2_ext.1", 64
  %"sts_val_packed_2.1" = or i128 %"sts_val_packed_1.1", %"sts_val_r2_shift.1"
  %"sts_val_r3_ext.1" = zext i32 %"phi.35" to i128
  %"sts_val_r3_shift.1" = shl i128 %"sts_val_r3_ext.1", 96
  %"sts_val_packed_3.1" = or i128 %"sts_val_packed_2.1", %"sts_val_r3_shift.1"
  %"sts_shared_addr_winoff.5" = and i32 %"phi.44", 16777215
  %".230" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".230" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.1", i128 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_0800"
BB_0800:
  %"warp_reconv_mask" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0850"
BB_0850:
  %"cond_trunc.17" = trunc i32 %"P52_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0bc0", label %"BB_0860"
BB_0860:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".198", 10248
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".237" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".237" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".238" = xor i32 %"plop3_a_bit.2", 1
  %".239" = xor i32 %"plop3_b_bit.2", 1
  %".240" = xor i32 %"plop3_c_bit.2", 1
  %".241" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".242" = and i32 %".241", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".242", 0
  %"P55_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".243" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".244" = zext i32 %"iadd3_n2.5" to i64
  %".245" = zext i32 24 to i64
  %".246" = shl i64 %".243", %".245"
  %".247" = and i64 %".246", 4294967295
  %".248" = add i64 %".247", %".244"
  %".249" = trunc i64 %".248" to i32
  %".250" = zext i32 0 to i64
  %".251" = zext i32 %".249" to i64
  %".252" = shl i64 %".251", 32
  %"shf_concat.4" = or i64 %".250", %".252"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".253" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".253", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".254" = xor i32 %"shf_result.4", -1
  %".255" = xor i32 16376, -1
  %".256" = xor i32 0, -1
  %".257" = and i32 %"shf_result.4", 16376
  %".258" = and i32 %".257", %".256"
  %".259" = and i32 %"shf_result.4", 16376
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = xor i32 %".261", -1
  %".263" = xor i32 524288, -1
  %".264" = xor i32 0, -1
  %".265" = and i32 %".262", 524288
  %".266" = and i32 %".265", %".264"
  %".267" = and i32 %".262", 524288
  %".268" = and i32 %".267", 0
  %".269" = or i32 %".266", %".268"
  %".270" = and i32 %".261", %".263"
  %".271" = and i32 %".270", %".264"
  %".272" = or i32 %".269", %".271"
  %".273" = and i32 %".261", %".263"
  %".274" = and i32 %".273", 0
  %".275" = or i32 %".272", %".274"
  %".276" = and i32 %".261", 524288
  %".277" = and i32 %".276", %".264"
  %".278" = or i32 %".275", %".277"
  %".279" = and i32 %".261", 524288
  %".280" = and i32 %".279", 0
  %".281" = or i32 %".278", %".280"
  br label %"BB_08f0"
BB_08f0:
  %"phi.46" = phi  i32 [%"phi.14", %"BB_0860"], [%"P43_to_i32", %"BB_0920"]
  %"phi.47" = phi  i32 [%"P55_to_i32", %"BB_0860"], [%"phi.49", %"BB_0920"]
  %"cond_trunc.18" = trunc i32 %"phi.47" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P41_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0900"
BB_0900:
  %"phi.48" = phi  i32 [%"P41_to_i32", %"BB_800008f0"], [%"phi.46", %"BB_08f0"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.2", 16
  %"copy_desc_r0_ext" = zext i32 %".281" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16392 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".285" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".286" = sub i64 %".285", 0
  %".287" = lshr i64 %".286", 4
  %".288" = add i64 %"copy_desc_packed_1", %".287"
  %".289" = and i64 %".288", 16383
  %".290" = and i64 %"copy_desc_packed_1", -16384
  %".291" = or i64 %".290", %".289"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".291")
  br label %"BB_0910"
BB_0910:
  %"cond_trunc.19" = trunc i32 %"phi.48" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"lop3_a_trunc" = trunc i32 %"phi.48" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".295" = xor i32 %"plop3_a_bit.3", 1
  %".296" = xor i32 %"plop3_b_bit.3", 1
  %".297" = xor i32 %"plop3_c_bit.3", 1
  %".298" = and i32 %".295", %"plop3_b_bit.3"
  %".299" = and i32 %".298", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".299", 0
  %"P10_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.49" = phi  i32 [%"P10_to_i32", %"BB_80000910"], [%"phi.47", %"BB_0910"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".301" = xor i32 %"plop3_a_bit.4", 1
  %".302" = xor i32 %"plop3_b_bit.4", 1
  %".303" = xor i32 %"plop3_c_bit.4", 1
  %".304" = and i32 %".301", %"plop3_b_bit.4"
  %".305" = and i32 %".304", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".305", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.49" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_08f0", label %"BB_0940"
BB_0940:
  %"iadd3_n1.6" = add i32 1024, 9728
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".307" = xor i32 %"plop3_a_bit.5", 1
  %".308" = xor i32 %"plop3_b_bit.5", 1
  %".309" = xor i32 %"plop3_c_bit.5", 1
  %".310" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".311" = and i32 %".310", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".311", 0
  %"P37_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".312" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".313" = zext i32 %"iadd3_n2.6" to i64
  %".314" = zext i32 24 to i64
  %".315" = shl i64 %".312", %".314"
  %".316" = and i64 %".315", 4294967295
  %".317" = add i64 %".316", %".313"
  %".318" = trunc i64 %".317" to i32
  %".319" = zext i32 0 to i64
  %".320" = zext i32 %".318" to i64
  %".321" = shl i64 %".320", 32
  %"shf_concat.5" = or i64 %".319", %".321"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".322" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".322", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".323" = xor i32 %"shf_result.5", -1
  %".324" = xor i32 16376, -1
  %".325" = xor i32 0, -1
  %".326" = and i32 %"shf_result.5", 16376
  %".327" = and i32 %".326", %".325"
  %".328" = and i32 %"shf_result.5", 16376
  %".329" = and i32 %".328", 0
  %".330" = or i32 %".327", %".329"
  %".331" = xor i32 %".330", -1
  %".332" = xor i32 524288, -1
  %".333" = xor i32 0, -1
  %".334" = and i32 %".331", 524288
  %".335" = and i32 %".334", %".333"
  %".336" = and i32 %".331", 524288
  %".337" = and i32 %".336", 0
  %".338" = or i32 %".335", %".337"
  %".339" = and i32 %".330", %".332"
  %".340" = and i32 %".339", %".333"
  %".341" = or i32 %".338", %".340"
  %".342" = and i32 %".330", %".332"
  %".343" = and i32 %".342", 0
  %".344" = or i32 %".341", %".343"
  %".345" = and i32 %".330", 524288
  %".346" = and i32 %".345", %".333"
  %".347" = or i32 %".344", %".346"
  %".348" = and i32 %".330", 524288
  %".349" = and i32 %".348", 0
  %".350" = or i32 %".347", %".349"
  br label %"BB_09b0"
BB_09b0:
  %"phi.50" = phi  i32 [%"P43_to_i32", %"BB_0940"], [%"P27_to_i32", %"BB_09e0"]
  %"phi.51" = phi  i32 [%"P37_to_i32", %"BB_0940"], [%"phi.53", %"BB_09e0"]
  %"cond_trunc.20" = trunc i32 %"phi.51" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P46_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.52" = phi  i32 [%"P46_to_i32", %"BB_800009b0"], [%"phi.50", %"BB_09b0"]
  %"copy_dst_memaddr_offset_add.1" = add i32 %"lds.2", 20
  %"copy_desc_r0_ext.1" = zext i32 %".350" to i64
  %"copy_desc_packed_0.1" = or i64 0, %"copy_desc_r0_ext.1"
  %"copy_desc_r1_ext.1" = zext i32 16392 to i64
  %"copy_desc_r1_shift.1" = shl i64 %"copy_desc_r1_ext.1", 32
  %"copy_desc_packed_1.1" = or i64 %"copy_desc_packed_0.1", %"copy_desc_r1_shift.1"
  %".354" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".355" = sub i64 %".354", 0
  %".356" = lshr i64 %".355", 4
  %".357" = add i64 %"copy_desc_packed_1.1", %".356"
  %".358" = and i64 %".357", 16383
  %".359" = and i64 %"copy_desc_packed_1.1", -16384
  %".360" = or i64 %".359", %".358"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add.1", i64 %".360")
  br label %"BB_09d0"
BB_09d0:
  %"cond_trunc.21" = trunc i32 %"phi.52" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_800009d0", label %"BB_09e0"
BB_800009d0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.52" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".364" = xor i32 %"plop3_a_bit.6", 1
  %".365" = xor i32 %"plop3_b_bit.6", 1
  %".366" = xor i32 %"plop3_c_bit.6", 1
  %".367" = and i32 %".364", %"plop3_b_bit.6"
  %".368" = and i32 %".367", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".368", 0
  %"P54_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09e0"
BB_09e0:
  %"phi.53" = phi  i32 [%"P54_to_i32", %"BB_800009d0"], [%"phi.51", %"BB_09d0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".370" = xor i32 %"plop3_a_bit.7", 1
  %".371" = xor i32 %"plop3_b_bit.7", 1
  %".372" = xor i32 %"plop3_c_bit.7", 1
  %".373" = and i32 %".370", %"plop3_b_bit.7"
  %".374" = and i32 %".373", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".374", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.53" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09b0", label %"BB_0a00"
BB_0a00:
  %"iadd3_n1.7" = add i32 1024, 8192
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".376" = xor i32 %"plop3_a_bit.8", 1
  %".377" = xor i32 %"plop3_b_bit.8", 1
  %".378" = xor i32 %"plop3_c_bit.8", 1
  %".379" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".380" = and i32 %".379", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".380", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".381" = zext i32 0 to i64
  %".382" = zext i32 %".198" to i64
  %".383" = shl i64 %".382", 32
  %"shf_concat.6" = or i64 %".381", %".383"
  %"shf_shift_64.6" = zext i32 4 to i64
  %".384" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".384", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".385" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".386" = zext i32 %"iadd3_n2.7" to i64
  %".387" = zext i32 24 to i64
  %".388" = shl i64 %".385", %".387"
  %".389" = and i64 %".388", 4294967295
  %".390" = add i64 %".389", %".386"
  %".391" = trunc i64 %".390" to i32
  %".392" = xor i32 %"shf_result.6", -1
  %".393" = xor i32 16376, -1
  %".394" = xor i32 0, -1
  %".395" = and i32 %"shf_result.6", 16376
  %".396" = and i32 %".395", %".394"
  %".397" = and i32 %"shf_result.6", 16376
  %".398" = and i32 %".397", 0
  %".399" = or i32 %".396", %".398"
  %".400" = zext i32 0 to i64
  %".401" = zext i32 %".391" to i64
  %".402" = shl i64 %".401", 32
  %"shf_concat.7" = or i64 %".400", %".402"
  %"shf_shift_64.7" = zext i32 4 to i64
  %".403" = lshr i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_hi.3" = lshr i64 %".403", 32
  %"shf_result.7" = trunc i64 %"shf_hi.3" to i32
  %"iadd3_n1.8" = add i32 %"lds.2", 16
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".404" = xor i32 %"shf_result.7", -1
  %".405" = xor i32 16376, -1
  %".406" = xor i32 0, -1
  %".407" = and i32 %"shf_result.7", 16376
  %".408" = and i32 %".407", %".406"
  %".409" = and i32 %"shf_result.7", 16376
  %".410" = and i32 %".409", 0
  %".411" = or i32 %".408", %".410"
  %"iadd3_n1.9" = add i32 %"lds.2", 20
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %".412" = xor i32 %".411", -1
  %".413" = xor i32 524288, -1
  %".414" = xor i32 0, -1
  %".415" = and i32 %".412", 524288
  %".416" = and i32 %".415", %".414"
  %".417" = and i32 %".412", 524288
  %".418" = and i32 %".417", 0
  %".419" = or i32 %".416", %".418"
  %".420" = and i32 %".411", %".413"
  %".421" = and i32 %".420", %".414"
  %".422" = or i32 %".419", %".421"
  %".423" = and i32 %".411", %".413"
  %".424" = and i32 %".423", 0
  %".425" = or i32 %".422", %".424"
  %".426" = and i32 %".411", 524288
  %".427" = and i32 %".426", %".414"
  %".428" = or i32 %".425", %".427"
  %".429" = and i32 %".411", 524288
  %".430" = and i32 %".429", 0
  %".431" = or i32 %".428", %".430"
  %".432" = xor i32 %".399", -1
  %".433" = xor i32 524288, -1
  %".434" = xor i32 0, -1
  %".435" = and i32 %".432", 524288
  %".436" = and i32 %".435", %".434"
  %".437" = and i32 %".432", 524288
  %".438" = and i32 %".437", 0
  %".439" = or i32 %".436", %".438"
  %".440" = and i32 %".399", %".433"
  %".441" = and i32 %".440", %".434"
  %".442" = or i32 %".439", %".441"
  %".443" = and i32 %".399", %".433"
  %".444" = and i32 %".443", 0
  %".445" = or i32 %".442", %".444"
  %".446" = and i32 %".399", 524288
  %".447" = and i32 %".446", %".434"
  %".448" = or i32 %".445", %".447"
  %".449" = and i32 %".399", 524288
  %".450" = and i32 %".449", 0
  %".451" = or i32 %".448", %".450"
  br label %"BB_0af0"
BB_0af0:
  %"phi.54" = phi  i32 [%"P27_to_i32", %"BB_0a00"], [%"P31_to_i32", %"BB_0b20"]
  %"phi.55" = phi  i32 [%"P1_to_i32", %"BB_0a00"], [%"phi.57", %"BB_0b20"]
  %"cond_trunc.22" = trunc i32 %"phi.55" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000af0", label %"BB_0b00"
BB_80000af0:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P29_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0b00"
BB_0b00:
  %"phi.56" = phi  i32 [%"P29_to_i32", %"BB_80000af0"], [%"phi.54", %"BB_0af0"]
  %"mma_a_r0_ext" = zext i32 %".451" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".455" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".456" = sub i64 %".455", 0
  %".457" = lshr i64 %".456", 4
  %".458" = add i64 %"mma_a_packed_1", %".457"
  %".459" = and i64 %".458", 16383
  %".460" = and i64 %"mma_a_packed_1", -16384
  %".461" = or i64 %".460", %".459"
  %"mma_b_r0_ext" = zext i32 %".431" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".462" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".463" = sub i64 %".462", 0
  %".464" = lshr i64 %".463", 4
  %".465" = add i64 %"mma_b_packed_1", %".464"
  %".466" = and i64 %".465", 16383
  %".467" = and i64 %"mma_b_packed_1", -16384
  %".468" = or i64 %".467", %".466"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".461", i64 %".468", i32 134481024, i32 %"mma_arg_zext", i32 %"iadd3_n2.8", i32 %"iadd3_n2.9")
  br label %"BB_0b10"
BB_0b10:
  %"cond_trunc.23" = trunc i32 %"phi.56" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000b10", label %"BB_0b20"
BB_80000b10:
  %"lop3_a_trunc.2" = trunc i32 %"phi.56" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".472" = xor i32 %"plop3_a_bit.9", 1
  %".473" = xor i32 %"plop3_b_bit.9", 1
  %".474" = xor i32 %"plop3_c_bit.9", 1
  %".475" = and i32 %".472", %"plop3_b_bit.9"
  %".476" = and i32 %".475", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".476", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0b20"
BB_0b20:
  %"phi.57" = phi  i32 [%"P23_to_i32", %"BB_80000b10"], [%"phi.55", %"BB_0b10"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".478" = xor i32 %"plop3_a_bit.10", 1
  %".479" = xor i32 %"plop3_b_bit.10", 1
  %".480" = xor i32 %"plop3_c_bit.10", 1
  %".481" = and i32 %".478", %"plop3_b_bit.10"
  %".482" = and i32 %".481", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".482", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.57" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0af0", label %"BB_0b40"
BB_0b40:
  %"iadd3_n1.10" = add i32 1024, 10240
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".484" = xor i32 %"plop3_a_bit.11", 1
  %".485" = xor i32 %"plop3_b_bit.11", 1
  %".486" = xor i32 %"plop3_c_bit.11", 1
  %".487" = and i32 %"plop3_a_bit.11", %"plop3_b_bit.11"
  %".488" = and i32 %".487", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".488", 0
  %"P45_to_i32" = zext i1 %"plop3_pred.11" to i32
  %".489" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".490" = zext i32 %"iadd3_n2.10" to i64
  %".491" = zext i32 24 to i64
  %".492" = shl i64 %".489", %".491"
  %".493" = and i64 %".492", 4294967295
  %".494" = add i64 %".493", %".490"
  %".495" = trunc i64 %".494" to i32
  br label %"BB_0b70"
BB_0b70:
  %"phi.58" = phi  i32 [%"P31_to_i32", %"BB_0b40"], [%"P36_to_i32", %"BB_0ba0"]
  %"phi.59" = phi  i32 [%"P45_to_i32", %"BB_0b40"], [%"phi.61", %"BB_0ba0"]
  %"cond_trunc.24" = trunc i32 %"phi.59" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80000b70", label %"BB_0b80"
BB_80000b70:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P33_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0b80"
BB_0b80:
  %"phi.60" = phi  i32 [%"P33_to_i32", %"BB_80000b70"], [%"phi.58", %"BB_0b70"]
  %"utcbar_local_winoff" = and i32 %".495", 16777215
  %".499" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".500" = ptrtoint i8 addrspace(3)* %".499" to i32
  %".501" = lshr i32 %".495", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".500", i32 %".501")
  br label %"BB_0b90"
BB_0b90:
  %"cond_trunc.25" = trunc i32 %"phi.60" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"lop3_a_trunc.3" = trunc i32 %"phi.60" to i1
  %"lop3_a_cast_zext.12" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".505" = xor i32 %"plop3_a_bit.12", 1
  %".506" = xor i32 %"plop3_b_bit.12", 1
  %".507" = xor i32 %"plop3_c_bit.12", 1
  %".508" = and i32 %".505", %"plop3_b_bit.12"
  %".509" = and i32 %".508", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".509", 0
  %"P59_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.61" = phi  i32 [%"P59_to_i32", %"BB_80000b90"], [%"phi.59", %"BB_0b90"]
  %"lop3_a_cast_zext.13" = zext i1 1 to i32
  %"lop3_b_cast_zext.13" = zext i1 1 to i32
  %"lop3_c_cast_zext.13" = zext i1 1 to i32
  %"plop3_a_bit.13" = and i32 %"lop3_a_cast_zext.13", 1
  %"plop3_b_bit.13" = and i32 %"lop3_b_cast_zext.13", 1
  %"plop3_c_bit.13" = and i32 %"lop3_c_cast_zext.13", 1
  %".511" = xor i32 %"plop3_a_bit.13", 1
  %".512" = xor i32 %"plop3_b_bit.13", 1
  %".513" = xor i32 %"plop3_c_bit.13", 1
  %".514" = and i32 %".511", %"plop3_b_bit.13"
  %".515" = and i32 %".514", %"plop3_c_bit.13"
  %"plop3_pred.13" = icmp ne i32 %".515", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.13" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.61" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.3", label %"BB_0b70", label %"BB_0bc0"
BB_0bc0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.11" = add i32 1024, 10240
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"imad_tmp.10" = mul i32 %"tid_x.1", 65536
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %".517" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".518" = zext i32 %"iadd3_n2.11" to i64
  %".519" = zext i32 24 to i64
  %".520" = shl i64 %".517", %".519"
  %".521" = and i64 %".520", 4294967295
  %".522" = add i64 %".521", %".518"
  %".523" = trunc i64 %".522" to i32
  %".524" = xor i32 %"imad.12", -1
  %".525" = xor i32 65011712, -1
  %".526" = xor i32 0, -1
  %".527" = and i32 %"imad.12", 65011712
  %".528" = and i32 %".527", %".526"
  %".529" = and i32 %"imad.12", 65011712
  %".530" = and i32 %".529", 0
  %".531" = or i32 %".528", %".530"
  %"imad_tmp.11" = mul i32 %"lds.1", 1
  %"imad.13" = add i32 %"imad_tmp.11", %".531"
  %"mbar_shared_winoff.1" = and i32 %".523", 16777215
  %".532" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".532" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P3_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.26" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.26", -1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_10d0", label %"BB_0c50"
BB_10d0:
  %"mbar_shared_winoff.2" = and i32 %".523", 16777215
  %".535" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".535" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P5_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_10e0"
BB_10e0:
  %"cond_trunc.27" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_10d0", label %"BB_0c50"
BB_0c50:
  %".538" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".539" = bitcast i8* %".538" to i64*
  %"ldc_const.2" = load i64, i64* %".539"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.12" = mul i32 %"tid_x.1", 16
  %"imad.14" = add i32 %"imad_tmp.12", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.13")
  %".540" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".541" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".542" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".543" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.13", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".544" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".545" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".546" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".547" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.14" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.15" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.15" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.15", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R29:R3_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".540", i32 addrspace(1)* %"R29:R3_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R29:R3_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".541", i32 addrspace(1)* %"R29:R3_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R29:R3_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".542", i32 addrspace(1)* %"R29:R3_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R29:R3_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".543", i32 addrspace(1)* %"R29:R3_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R29:R3_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".544", i32 addrspace(1)* %"R29:R3_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.13", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".553" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".554" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".555" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".556" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R29:R3_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".545", i32 addrspace(1)* %"R29:R3_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R29:R3_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".546", i32 addrspace(1)* %"R29:R3_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R29:R3_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".547", i32 addrspace(1)* %"R29:R3_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.13", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".560" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".561" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".562" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".563" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R29:R3_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".553", i32 addrspace(1)* %"R29:R3_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R29:R3_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".554", i32 addrspace(1)* %"R29:R3_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R29:R3_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".555", i32 addrspace(1)* %"R29:R3_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R29:R3_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".556", i32 addrspace(1)* %"R29:R3_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R29:R3_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".560", i32 addrspace(1)* %"R29:R3_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R29:R3_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".561", i32 addrspace(1)* %"R29:R3_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R29:R3_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".562", i32 addrspace(1)* %"R29:R3_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R29:R3_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".563", i32 addrspace(1)* %"R29:R3_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0e40"
BB_0e40:
  %"cond_trunc.28" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_80000e40", label %"BB_0e50"
BB_0e50:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".198", 10248
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".574" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".574" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %".575" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".576" = zext i32 80 to i64
  %".577" = zext i32 24 to i64
  %".578" = shl i64 %".575", %".577"
  %".579" = and i64 %".578", 4294967295
  %".580" = add i64 %".579", %".576"
  %".581" = trunc i64 %".580" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".581", 16777215
  %".582" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".582" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".583" = xor i32 %"lds.3", -1
  %".584" = xor i32 65535, -1
  %".585" = xor i32 0, -1
  %".586" = and i32 %"lds.3", 65535
  %".587" = and i32 %".586", %".585"
  %".588" = and i32 %"lds.3", 65535
  %".589" = and i32 %".588", 0
  %".590" = or i32 %".587", %".589"
  %".591" = zext i32 0 to i64
  %".592" = zext i32 %".590" to i64
  %".593" = shl i64 %".592", 32
  %"shf_concat.8" = or i64 %".591", %".593"
  %"shf_shift_64.8" = zext i32 5 to i64
  %".594" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.4" = lshr i64 %".594", 32
  %"shf_result.8" = trunc i64 %"shf_hi.4" to i32
  %"viadd.5" = add i32 %"shf_result.8", 16
  %".595" = zext i32 %"imad.16" to i64
  %".596" = zext i32 0 to i64
  %".597" = shl i64 %".596", 32
  %"shf_concat.9" = or i64 %".595", %".597"
  %"shf_shift_64.9" = zext i32 %"shf_result.8" to i64
  %".598" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".598" to i32
  %".599" = zext i32 %"imad.16" to i64
  %".600" = zext i32 0 to i64
  %".601" = shl i64 %".600", 32
  %"shf_concat.10" = or i64 %".599", %".601"
  %"shf_shift_64.10" = zext i32 %"viadd.5" to i64
  %".602" = shl i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_result.10" = trunc i64 %".602" to i32
  %".603" = xor i32 %"shf_result.10", -1
  %".604" = xor i32 %"shf_result.9", -1
  %".605" = xor i32 0, -1
  %".606" = and i32 %".603", %"shf_result.9"
  %".607" = and i32 %".606", %".605"
  %".608" = and i32 %".603", %"shf_result.9"
  %".609" = and i32 %".608", 0
  %".610" = or i32 %".607", %".609"
  %".611" = and i32 %"shf_result.10", %".604"
  %".612" = and i32 %".611", %".605"
  %".613" = or i32 %".610", %".612"
  %".614" = and i32 %"shf_result.10", %".604"
  %".615" = and i32 %".614", 0
  %".616" = or i32 %".613", %".615"
  %".617" = and i32 %"shf_result.10", %"shf_result.9"
  %".618" = and i32 %".617", %".605"
  %".619" = or i32 %".616", %".618"
  %".620" = and i32 %"shf_result.10", %"shf_result.9"
  %".621" = and i32 %".620", 0
  %".622" = or i32 %".619", %".621"
  %".623" = xor i32 %".622", -1
  %".624" = xor i32 65535, -1
  %".625" = xor i32 0, -1
  %".626" = and i32 %".622", 65535
  %".627" = and i32 %".626", %".625"
  %".628" = and i32 %".622", 65535
  %".629" = and i32 %".628", 0
  %".630" = or i32 %".627", %".629"
  %".631" = xor i32 %".622", -1
  %".632" = xor i32 65535, -1
  %".633" = xor i32 %"lds.4", -1
  %".634" = and i32 %".622", 65535
  %".635" = and i32 %".634", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".635", %".630"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0f40"
BB_0f40:
  %"cond_trunc.29" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_10a0_1160", label %"BB_0f50"
BB_0f50:
  %".638" = zext i32 0 to i64
  %".639" = zext i32 %"lds.4" to i64
  %".640" = shl i64 %".639", 32
  %"shf_concat.11" = or i64 %".638", %".640"
  %"shf_shift_64.11" = zext i32 16 to i64
  %".641" = lshr i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_hi.5" = lshr i64 %".641", 32
  %"shf_result.11" = trunc i64 %"shf_hi.5" to i32
  %".642" = zext i32 0 to i64
  %".643" = zext i32 %".622" to i64
  %".644" = shl i64 %".643", 32
  %"shf_concat.12" = or i64 %".642", %".644"
  %"shf_shift_64.12" = zext i32 16 to i64
  %".645" = lshr i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_hi.6" = lshr i64 %".645", 32
  %"shf_result.12" = trunc i64 %"shf_hi.6" to i32
  %".646" = xor i32 %"shf_result.11", -1
  %".647" = xor i32 %"shf_result.12", -1
  %".648" = xor i32 0, -1
  %".649" = and i32 %"shf_result.11", %"shf_result.12"
  %".650" = and i32 %".649", %".648"
  %".651" = and i32 %"shf_result.11", %"shf_result.12"
  %".652" = and i32 %".651", 0
  %".653" = or i32 %".650", %".652"
  %"isetrp_cmp1.11" = icmp ne i32 %".653", %"shf_result.12"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0f90"
BB_0f90:
  %"cond_trunc.30" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_1070_1100", label %"BB_0fa0"
BB_0fa0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".656" = xor i32 0, -1
  %".657" = xor i32 %".622", -1
  %".658" = xor i32 0, -1
  %".659" = and i32 %".656", %".657"
  %".660" = and i32 %".659", %".658"
  %".661" = and i32 %".656", %".657"
  %".662" = and i32 %".661", 0
  %".663" = or i32 %".660", %".662"
  %".664" = and i32 0, %".657"
  %".665" = and i32 %".664", %".658"
  %".666" = or i32 %".663", %".665"
  %".667" = and i32 0, %".657"
  %".668" = and i32 %".667", 0
  %".669" = or i32 %".666", %".668"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".669"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".670" = xor i32 %".669", -1
  %".671" = call i32 @"llvm.cttz.i32"(i32 %".670", i1 0)
  %".672" = shl i32 %".671", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".672") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_1040"
BB_1040:
  %"cond_trunc.31" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_80001040", label %"BB_10b0"
BB_80001040:
  %"atoms_shared_addr_winoff.1" = and i32 %".581", 16777215
  %".676" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".676" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_10b0"
BB_1070_1100:
  call void @"llvm.trap"()
  br label %"BB_10b0"
BB_10a0_1160:
  call void @"llvm.trap"()
  br label %"BB_10b0"
BB_10b0:
  ret void
BB_80000e40:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
tmem_entry:
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"tid_z" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()
  %".4" = or i32 %"tid_y", %"tid_z"
  %".5" = or i32 %"tid_x", %".4"
  %".6" = icmp eq i32 %".5", 0
  br i1 %".6", label %"clear_tmem_guard", label %"publish_tmem_guard"
clear_tmem_guard:
  %"phase_winoff" = and i32 64, 16777215
  %".8" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"phase_winoff"
  store i8 0, i8 addrspace(3)* %".8"
  %"mask_winoff" = and i32 80, 16777215
  %".10" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mask_winoff"
  %".11" = bitcast i8 addrspace(3)* %".10" to i32 addrspace(3)*
  store i32 0, i32 addrspace(3)* %".11"
  br label %"publish_tmem_guard"
publish_tmem_guard:
  call void @"llvm.nvvm.barrier0"()
  br label %"EntryBB_0000"
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".16" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".17" = bitcast i8* %".16" to i64*
  store i64 %"arg_896", i64* %".17", align 128
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".20" = bitcast i8* %".19" to i64*
  store i64 %"arg_904", i64* %".20", align 8
  %"P24_to_i32" = zext i1 0 to i32
  %"tid_x.1" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".22" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".24" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".25" = zext i32 1024 to i64
  %".26" = zext i32 24 to i64
  %".27" = shl i64 %".24", %".26"
  %".28" = and i64 %".27", 4294967295
  %".29" = add i64 %".28", %".25"
  %".30" = trunc i64 %".29" to i32
  %".31" = zext i32 %"tid_x.1" to i64
  %".32" = zext i32 %".30" to i64
  %".33" = zext i32 2 to i64
  %".34" = shl i64 %".31", %".33"
  %".35" = and i64 %".34", 4294967295
  %".36" = add i64 %".35", %".32"
  %".37" = trunc i64 %".36" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x.1" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"R3:R2_r1.1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"phi.1" = phi  i32 [%"tid_x.1", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.2" = phi  i32 [%".37", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R3:R2_r0.1", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R83:R48_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R83:R48_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi.1", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P26_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P17_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi"
  %"imad_cin_trunc" = trunc i32 %"P17_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".39" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".39" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P26_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x.1", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P19_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P58_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01a0"
BB_01a0:
  %"cond_trunc.1" = trunc i32 %"P19_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02a0", label %"BB_01b0"
BB_01b0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P20_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".45" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".46" = zext i32 %"iadd3_n2" to i64
  %".47" = zext i32 24 to i64
  %".48" = shl i64 %".45", %".47"
  %".49" = and i64 %".48", 4294967295
  %".50" = add i64 %".49", %".46"
  %".51" = trunc i64 %".50" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R3:R2_r1.1"
  %"imad_cin_trunc.1" = trunc i32 %"P20_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".52" = zext i32 %"tid_x.1" to i64
  %".53" = zext i32 %".51" to i64
  %".54" = zext i32 2 to i64
  %".55" = shl i64 %".52", %".54"
  %".56" = and i64 %".55", 4294967295
  %".57" = add i64 %".56", %".53"
  %".58" = trunc i64 %".57" to i32
  br label %"BB_0210"
BB_0210:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01b0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.5" = phi  i32 [%"tid_x.1", %"BB_01b0"], [%"viadd.2", %"BB_0290"]
  %"phi.6" = phi  i32 [%".58", %"BB_01b0"], [%"viadd.3", %"BB_0290"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01b0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R71:R11_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R71:R11_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P38_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P38_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".60" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".60" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.2" = trunc i32 %"P21_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0210", label %"BB_02a0"
BB_02a0:
  %"phi.8" = phi  i32 [0, %"BB_01a0"], [%".51", %"BB_0290"]
  %"phi.9" = phi  i32 [%"viadd", %"BB_01a0"], [%"imad_with_cin.2", %"BB_0290"]
  %"phi.10" = phi  i32 [%"ldg", %"BB_01a0"], [%"viadd.2", %"BB_0290"]
  %"phi.11" = phi  i32 [%"iadd3_trunc", %"BB_01a0"], [%"viadd.3", %"BB_0290"]
  %"phi.12" = phi  i32 [%"R3:R2_r1.1", %"BB_01a0"], [%"ldg.1", %"BB_0290"]
  %"phi.13" = phi  i32 [%"R3:R2_r0.1", %"BB_01a0"], [%"iadd3_trunc.2", %"BB_0290"]
  %"phi.14" = phi  i32 [%"P24_to_i32", %"BB_01a0"], [%"P38_to_i32", %"BB_0290"]
  %"vote_pred_trunc" = trunc i32 %"P58_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P48_to_i32" = zext i1 %"vote_all" to i32
  br label %"BB_02c0"
BB_02c0:
  %"cond_trunc.3" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_800002c0", label %"BB_02d0"
BB_800002c0:
  %"iadd3_n1.1" = add i32 1024, 10240
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  br label %"BB_02d0"
BB_02d0:
  %"phi.15" = phi  i32 [%"iadd3_n2.1", %"BB_800002c0"], [0, %"BB_02c0"]
  br label %"BB_02e0"
BB_02e0:
  %"cond_trunc.4" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_800002e0", label %"BB_0320"
BB_800002e0:
  %".69" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".70" = zext i32 %"phi.15" to i64
  %".71" = zext i32 24 to i64
  %".72" = shl i64 %".69", %".71"
  %".73" = and i64 %".72", 4294967295
  %".74" = add i64 %".73", %".70"
  %".75" = trunc i64 %".74" to i32
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".76" = zext i32 %"iadd3_n2.2" to i64
  %".77" = zext i32 0 to i64
  %".78" = shl i64 %".77", 32
  %"shf_concat" = or i64 %".76", %".78"
  %"shf_shift_64" = zext i32 11 to i64
  %".79" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".79" to i32
  %".80" = zext i32 %"iadd3_n2.2" to i64
  %".81" = zext i32 0 to i64
  %".82" = shl i64 %".81", 32
  %"shf_concat.1" = or i64 %".80", %".82"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".83" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".83" to i32
  br label %"BB_0320"
BB_0320:
  %"phi.16" = phi  i32 [%".75", %"BB_800002e0"], [%"phi.15", %"BB_02e0"]
  %"phi.17" = phi  i32 [%"shf_result", %"BB_800002e0"], [%"phi.8", %"BB_02e0"]
  %"phi.18" = phi  i32 [%"shf_result.1", %"BB_800002e0"], [1, %"BB_02e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P58_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P49_to_i32" = zext i1 %"vote_all.1" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0350"
BB_0350:
  %"cond_trunc.5" = trunc i32 %"P49_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_80000350", label %"BB_0360"
BB_80000350:
  %"mbar_shared_winoff" = and i32 %"phi.16", 16777215
  %".88" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".88" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.18" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.17" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".89" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".89" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0360"
BB_0360:
  %"cond_trunc.6" = trunc i32 %"P9_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0620", label %"BB_0370"
BB_0370:
  %".93" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".94" = zext i32 64 to i64
  %".95" = zext i32 24 to i64
  %".96" = shl i64 %".93", %".95"
  %".97" = and i64 %".96", 4294967295
  %".98" = add i64 %".97", %".94"
  %".99" = trunc i64 %".98" to i32
  %"lds_shared_addr_winoff" = and i32 %".99", 16777215
  %".100" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds" = load volatile i8, i8 addrspace(3)* %".100"
  %"lds_zext" = zext i8 %"lds" to i32
  %"isetrp_cmp1.5" = icmp ne i32 %"lds_zext", 0
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P11_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_03d0"
BB_03d0:
  %"cond_trunc.7" = trunc i32 %"P11_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_05c0", label %"BB_03df"
BB_03df:
  %"allocation_slot_winoff" = and i32 11272, 16777215
  %".103" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".104" = ptrtoint i8 addrspace(3)* %".103" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".104", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P13_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03f0"
BB_03f0:
  %"cond_trunc.8" = trunc i32 %"P13_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.8", -1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0600", label %"BB_0400"
BB_0400:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_winoff" = and i32 11272, 16777215
  %".108" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".109" = bitcast i8 addrspace(3)* %".108" to i32 addrspace(3)*
  %".110" = load i32, i32 addrspace(3)* %".109"
  %".111" = lshr i32 %".110", 5
  %"P50_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc" = trunc i32 %"P50_to_i32" to i1
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 %"lop3_c_trunc" to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".112" = xor i32 %"plop3_a_bit", 1
  %".113" = xor i32 %"plop3_b_bit", 1
  %".114" = xor i32 %"plop3_c_bit", 1
  %".115" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".116" = and i32 %".115", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".116", 0
  %"P14_to_i32" = zext i1 %"plop3_pred" to i32
  %"sel_pred_trunc" = trunc i32 %"P14_to_i32" to i1
  %"sel_pred_not" = xor i1 %"sel_pred_trunc", -1
  %"sel_pred_to_i32" = zext i1 %"sel_pred_not" to i32
  %"sel_pred_to_i1" = icmp ne i32 %"sel_pred_to_i32", 0
  %"sel" = select  i1 %"sel_pred_to_i1", i32 0, i32 4294967295
  %"isetrp_cmp1.6" = icmp ne i32 %"sel", 0
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P16_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".111"
  br label %"BB_0480"
BB_0480:
  %"cond_trunc.9" = trunc i32 %"P16_to_i32" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_0520", label %"BB_0490"
BB_0490:
  %"tmem_alloc_winoff.1" = and i32 11272, 16777215
  %".119" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".120" = bitcast i8 addrspace(3)* %".119" to i32 addrspace(3)*
  %".121" = load i32, i32 addrspace(3)* %".120"
  %".122" = lshr i32 %".121", 5
  %"P51_to_i32" = zext i1 1 to i32
  %"lop3_c_trunc.1" = trunc i32 %"P51_to_i32" to i1
  %"lop3_a_cast_zext.1" = zext i1 1 to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 %"lop3_c_trunc.1" to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".123" = xor i32 %"plop3_a_bit.1", 1
  %".124" = xor i32 %"plop3_b_bit.1", 1
  %".125" = xor i32 %"plop3_c_bit.1", 1
  %".126" = and i32 %"plop3_a_bit.1", %"plop3_b_bit.1"
  %".127" = and i32 %".126", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".127", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.1" to i32
  %"sel_pred_trunc.1" = trunc i32 %"P4_to_i32" to i1
  %"sel_pred_not.1" = xor i1 %"sel_pred_trunc.1", -1
  %"sel_pred_to_i32.1" = zext i1 %"sel_pred_not.1" to i32
  %"sel_pred_to_i1.1" = icmp ne i32 %"sel_pred_to_i32.1", 0
  %"sel.1" = select  i1 %"sel_pred_to_i1.1", i32 0, i32 4294967295
  %"isetrp_cmp1.7" = icmp ne i32 %"sel.1", 0
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P15_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".122"
  br label %"BB_0510"
BB_0510:
  %"cond_trunc.10" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.10", -1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_0490", label %"BB_0520"
BB_0520:
  %"phi.19" = phi  i32 [%"imad.5", %"BB_0480"], [%"imad.6", %"BB_0510"]
  %"viadd.4" = add i32 %"phi.19", 16
  %".130" = zext i32 %"imad.4" to i64
  %".131" = zext i32 0 to i64
  %".132" = shl i64 %".131", 32
  %"shf_concat.2" = or i64 %".130", %".132"
  %"shf_shift_64.2" = zext i32 %"phi.19" to i64
  %".133" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".133" to i32
  %".134" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".135" = zext i32 80 to i64
  %".136" = zext i32 24 to i64
  %".137" = shl i64 %".134", %".136"
  %".138" = and i64 %".137", 4294967295
  %".139" = add i64 %".138", %".135"
  %".140" = trunc i64 %".139" to i32
  %"imad_tmp.6" = mul i32 %"phi.19", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %".141" = zext i32 %"imad.4" to i64
  %".142" = zext i32 0 to i64
  %".143" = shl i64 %".142", 32
  %"shf_concat.3" = or i64 %".141", %".143"
  %"shf_shift_64.3" = zext i32 %"viadd.4" to i64
  %".144" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".144" to i32
  %".145" = xor i32 %"shf_result.3", -1
  %".146" = xor i32 %"shf_result.2", -1
  %".147" = xor i32 0, -1
  %".148" = and i32 %".145", %"shf_result.2"
  %".149" = and i32 %".148", %".147"
  %".150" = and i32 %".145", %"shf_result.2"
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %"shf_result.3", %".146"
  %".154" = and i32 %".153", %".147"
  %".155" = or i32 %".152", %".154"
  %".156" = and i32 %"shf_result.3", %".146"
  %".157" = and i32 %".156", 0
  %".158" = or i32 %".155", %".157"
  %".159" = and i32 %"shf_result.3", %"shf_result.2"
  %".160" = and i32 %".159", %".147"
  %".161" = or i32 %".158", %".160"
  %".162" = and i32 %"shf_result.3", %"shf_result.2"
  %".163" = and i32 %".162", 0
  %".164" = or i32 %".161", %".163"
  %"atoms_shared_addr_winoff" = and i32 %".140", 16777215
  %".165" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".165" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %".164" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".30", 10248
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".166" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".166" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0600"
BB_05c0:
  %"imad_tmp.7" = mul i32 0, 0
  %"imad.8" = add i32 %"imad_tmp.7", -1
  %"sts_addr_memaddr_offset_add.1" = add i32 %".30", 10248
  %"sts_shared_addr_winoff.3" = and i32 %"sts_addr_memaddr_offset_add.1", 16777215
  %".169" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".169" to i32 addrspace(3)*
  store volatile i32 %"imad.8", i32 addrspace(3)* %"sts_shared_addr_cast.3"
  br label %"BB_05f0_1130"
BB_05f0_1130:
  call void @"llvm.trap"()
  %"imad_tmp.8" = mul i32 0, 0
  %"imad.9" = add i32 %"imad_tmp.8", 0
  br label %"BB_0600"
BB_0600:
  %"phi.20" = phi  i32 [%".140", %"BB_0520"], [%".99", %"BB_03f0"], [%".99", %"BB_05f0_1130"]
  %"phi.21" = phi  i32 [%"imad.4", %"BB_0520"], [%"phi.10", %"BB_03f0"], [%"phi.10", %"BB_05f0_1130"]
  %"phi.22" = phi  i32 [%"shf_result.3", %"BB_0520"], [%"phi.11", %"BB_03f0"], [%"phi.11", %"BB_05f0_1130"]
  %"phi.23" = phi  i32 [%".164", %"BB_0520"], [%"phi.12", %"BB_03f0"], [%"imad.9", %"BB_05f0_1130"]
  %"phi.24" = phi  i32 [%"imad.7", %"BB_0520"], [%"lds_zext", %"BB_03f0"], [1536, %"BB_05f0_1130"]
  br label %"BB_0620"
BB_0620:
  %"phi.25" = phi  i32 [%"phi.20", %"BB_0600"], [%"phi.18", %"BB_0360"]
  %"phi.26" = phi  i32 [%"phi.21", %"BB_0600"], [%"phi.10", %"BB_0360"]
  %"phi.27" = phi  i32 [%"phi.22", %"BB_0600"], [%"phi.11", %"BB_0360"]
  %"phi.28" = phi  i32 [%"phi.23", %"BB_0600"], [%"phi.12", %"BB_0360"]
  %"phi.29" = phi  i32 [%"phi.24", %"BB_0600"], [%"phi.13", %"BB_0360"]
  %"isetrp_cmp1.8" = icmp ugt i32 %"tid_x.1", 31
  %"isetrp_src_to_i32.8" = zext i1 1 to i32
  %"isetrp_src_to_i1.8" = icmp ne i32 %"isetrp_src_to_i32.8", 0
  %"isetrp_cmp2.8" = and i1 %"isetrp_cmp1.8", %"isetrp_src_to_i1.8"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.8" to i32
  br label %"BB_0650"
BB_0650:
  %"cond_trunc.11" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.7" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.7" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000650", label %"BB_0680"
BB_80000650:
  %".176" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".177" = bitcast i8* %".176" to i64*
  %"ldc_const.1" = load i64, i64* %".177"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.9" = mul i32 %"tid_x.1", 10
  %"imad.10" = add i32 %"imad_tmp.9", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.10" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.11" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.3" = trunc i64 %"imad.11" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.11", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  br label %"BB_0680"
BB_0680:
  %"phi.30" = phi  i32 [%"imad.10", %"BB_80000650"], [%"phi.26", %"BB_0650"]
  %"phi.31" = phi  i32 [%"R3:R2_r1.3", %"BB_80000650"], [%"phi.28", %"BB_0650"]
  %"phi.32" = phi  i32 [%"R3:R2_r0.3", %"BB_80000650"], [%"phi.29", %"BB_0650"]
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0690"
BB_0690:
  %"cond_trunc.12" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.8" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.8" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000690", label %"BB_0710"
BB_80000690:
  %"ldg_addr_r0_ext.2" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R26:R200_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R26:R200_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R26:R200_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R26:R200_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R26:R200_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R26:R200_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R26:R200_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"phi.32" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"phi.31" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R26:R200_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R26:R200_addr_ptr.7"
  br label %"BB_0710"
BB_0710:
  %"phi.33" = phi  i32 [%"ldg.3", %"BB_80000690"], [%"imad_with_cin", %"BB_0690"]
  %"phi.34" = phi  i32 [%"ldg.2", %"BB_80000690"], [0, %"BB_0690"]
  %"phi.35" = phi  i32 [%"ldg.9", %"BB_80000690"], [%"phi.9", %"BB_0690"]
  %"phi.36" = phi  i32 [%"ldg.8", %"BB_80000690"], [%"viadd.1", %"BB_0690"]
  %"phi.37" = phi  i32 [%"ldg.7", %"BB_80000690"], [%"phi.30", %"BB_0690"]
  %"phi.38" = phi  i32 [%"ldg.6", %"BB_80000690"], [%"phi.27", %"BB_0690"]
  %"phi.39" = phi  i32 [%"ldg.5", %"BB_80000690"], [0, %"BB_0690"]
  %"phi.40" = phi  i32 [%"ldg.4", %"BB_80000690"], [0, %"BB_0690"]
  %"s2ur_cluster_ctarank.1" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %"vote_pred_trunc.2" = trunc i32 %"P22_to_i32" to i1
  %"vote_all.2" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.2")
  %"P53_to_i32" = zext i1 %"vote_all.2" to i32
  %"isetrp_cmp1.9" = icmp ne i32 %"tid_x.1", 0
  %"isetrp_src_to_i32.9" = zext i1 1 to i32
  %"isetrp_src_to_i1.9" = icmp ne i32 %"isetrp_src_to_i32.9", 0
  %"isetrp_cmp2.9" = and i1 %"isetrp_cmp1.9", %"isetrp_src_to_i1.9"
  %"P52_to_i32" = zext i1 %"isetrp_cmp2.9" to i32
  br label %"BB_0760"
BB_0760:
  %"cond_trunc.13" = trunc i32 %"P53_to_i32" to i1
  %"cond_not.9" = xor i1 %"cond_trunc.13", -1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_not.9" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000760", label %"BB_0790"
BB_80000760:
  %"iadd3_n1.3" = add i32 1024, 9216
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 1024, 9728
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %".184" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".185" = zext i32 %"iadd3_n2.3" to i64
  %".186" = zext i32 24 to i64
  %".187" = shl i64 %".184", %".186"
  %".188" = and i64 %".187", 4294967295
  %".189" = add i64 %".188", %".185"
  %".190" = trunc i64 %".189" to i32
  br label %"BB_0790"
BB_0790:
  %"phi.41" = phi  i32 [%".190", %"BB_80000760"], [%"phi.17", %"BB_0760"]
  %"phi.42" = phi  i32 [%"iadd3_n2.4", %"BB_80000760"], [%"phi.25", %"BB_0760"]
  %".192" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".193" = zext i32 1024 to i64
  %".194" = zext i32 24 to i64
  %".195" = shl i64 %".192", %".194"
  %".196" = and i64 %".195", 4294967295
  %".197" = add i64 %".196", %".193"
  %".198" = trunc i64 %".197" to i32
  br label %"BB_07a0"
BB_07a0:
  %"cond_trunc.14" = trunc i32 %"P53_to_i32" to i1
  %"cond_not.10" = xor i1 %"cond_trunc.14", -1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_not.10" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800007a0", label %"BB_07b0"
BB_800007a0:
  %".201" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".202" = zext i32 %"phi.42" to i64
  %".203" = zext i32 24 to i64
  %".204" = shl i64 %".201", %".203"
  %".205" = and i64 %".204", 4294967295
  %".206" = add i64 %".205", %".202"
  %".207" = trunc i64 %".206" to i32
  br label %"BB_07b0"
BB_07b0:
  %"phi.43" = phi  i32 [%".207", %"BB_800007a0"], [%"phi.42", %"BB_07a0"]
  %"cond_trunc.15" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.11" = xor i1 %"cond_trunc.15", -1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_not.11" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_800007b0", label %"BB_07d0"
BB_800007b0:
  %".210" = zext i32 %"tid_x.1" to i64
  %".211" = zext i32 %"phi.41" to i64
  %".212" = zext i32 4 to i64
  %".213" = shl i64 %".210", %".212"
  %".214" = and i64 %".213", 4294967295
  %".215" = add i64 %".214", %".211"
  %".216" = trunc i64 %".215" to i32
  %".217" = zext i32 %"tid_x.1" to i64
  %".218" = zext i32 %"phi.43" to i64
  %".219" = zext i32 4 to i64
  %".220" = shl i64 %".217", %".219"
  %".221" = and i64 %".220", 4294967295
  %".222" = add i64 %".221", %".218"
  %".223" = trunc i64 %".222" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.44" = phi  i32 [%".223", %"BB_800007b0"], [%"phi.32", %"BB_07b0"]
  %"phi.45" = phi  i32 [%".216", %"BB_800007b0"], [0, %"BB_07b0"]
  %"lds_addr_memaddr_offset_add" = add i32 %".198", 10248
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".225" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".225" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  br label %"BB_07e0"
BB_07e0:
  %"cond_trunc.16" = trunc i32 %"P22_to_i32" to i1
  %"cond_not.12" = xor i1 %"cond_trunc.16", -1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_not.12" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_800007e0", label %"BB_0800"
BB_800007e0:
  %"sts_val_r0_ext" = zext i32 %"phi.34" to i128
  %"sts_val_packed_0" = or i128 0, %"sts_val_r0_ext"
  %"sts_val_r1_ext" = zext i32 %"phi.33" to i128
  %"sts_val_r1_shift" = shl i128 %"sts_val_r1_ext", 32
  %"sts_val_packed_1" = or i128 %"sts_val_packed_0", %"sts_val_r1_shift"
  %"sts_val_r2_ext" = zext i32 %"phi.40" to i128
  %"sts_val_r2_shift" = shl i128 %"sts_val_r2_ext", 64
  %"sts_val_packed_2" = or i128 %"sts_val_packed_1", %"sts_val_r2_shift"
  %"sts_val_r3_ext" = zext i32 %"phi.39" to i128
  %"sts_val_r3_shift" = shl i128 %"sts_val_r3_ext", 96
  %"sts_val_packed_3" = or i128 %"sts_val_packed_2", %"sts_val_r3_shift"
  %"sts_shared_addr_winoff.4" = and i32 %"phi.45", 16777215
  %".228" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".228" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3", i128 addrspace(3)* %"sts_shared_addr_cast.4"
  %"sts_val_r0_ext.1" = zext i32 %"phi.38" to i128
  %"sts_val_packed_0.1" = or i128 0, %"sts_val_r0_ext.1"
  %"sts_val_r1_ext.1" = zext i32 %"phi.37" to i128
  %"sts_val_r1_shift.1" = shl i128 %"sts_val_r1_ext.1", 32
  %"sts_val_packed_1.1" = or i128 %"sts_val_packed_0.1", %"sts_val_r1_shift.1"
  %"sts_val_r2_ext.1" = zext i32 %"phi.36" to i128
  %"sts_val_r2_shift.1" = shl i128 %"sts_val_r2_ext.1", 64
  %"sts_val_packed_2.1" = or i128 %"sts_val_packed_1.1", %"sts_val_r2_shift.1"
  %"sts_val_r3_ext.1" = zext i32 %"phi.35" to i128
  %"sts_val_r3_shift.1" = shl i128 %"sts_val_r3_ext.1", 96
  %"sts_val_packed_3.1" = or i128 %"sts_val_packed_2.1", %"sts_val_r3_shift.1"
  %"sts_shared_addr_winoff.5" = and i32 %"phi.44", 16777215
  %".230" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.5"
  %"sts_shared_addr_cast.5" = bitcast i8 addrspace(3)* %".230" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.1", i128 addrspace(3)* %"sts_shared_addr_cast.5"
  br label %"BB_0800"
BB_0800:
  %"warp_reconv_mask" = call i32 @"llvm.nvvm.activemask"()
  call void @"llvm.nvvm.bar.warp.sync"(i32 %"warp_reconv_mask")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0850"
BB_0850:
  %"cond_trunc.17" = trunc i32 %"P52_to_i32" to i1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_trunc.17" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0bc0", label %"BB_0860"
BB_0860:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".198", 10248
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".237" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".237" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".238" = xor i32 %"plop3_a_bit.2", 1
  %".239" = xor i32 %"plop3_b_bit.2", 1
  %".240" = xor i32 %"plop3_c_bit.2", 1
  %".241" = and i32 %"plop3_a_bit.2", %"plop3_b_bit.2"
  %".242" = and i32 %".241", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".242", 0
  %"P55_to_i32" = zext i1 %"plop3_pred.2" to i32
  %".243" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".244" = zext i32 %"iadd3_n2.5" to i64
  %".245" = zext i32 24 to i64
  %".246" = shl i64 %".243", %".245"
  %".247" = and i64 %".246", 4294967295
  %".248" = add i64 %".247", %".244"
  %".249" = trunc i64 %".248" to i32
  %".250" = zext i32 0 to i64
  %".251" = zext i32 %".249" to i64
  %".252" = shl i64 %".251", 32
  %"shf_concat.4" = or i64 %".250", %".252"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".253" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".253", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %".254" = xor i32 %"shf_result.4", -1
  %".255" = xor i32 16376, -1
  %".256" = xor i32 0, -1
  %".257" = and i32 %"shf_result.4", 16376
  %".258" = and i32 %".257", %".256"
  %".259" = and i32 %"shf_result.4", 16376
  %".260" = and i32 %".259", 0
  %".261" = or i32 %".258", %".260"
  %".262" = xor i32 %".261", -1
  %".263" = xor i32 524288, -1
  %".264" = xor i32 0, -1
  %".265" = and i32 %".262", 524288
  %".266" = and i32 %".265", %".264"
  %".267" = and i32 %".262", 524288
  %".268" = and i32 %".267", 0
  %".269" = or i32 %".266", %".268"
  %".270" = and i32 %".261", %".263"
  %".271" = and i32 %".270", %".264"
  %".272" = or i32 %".269", %".271"
  %".273" = and i32 %".261", %".263"
  %".274" = and i32 %".273", 0
  %".275" = or i32 %".272", %".274"
  %".276" = and i32 %".261", 524288
  %".277" = and i32 %".276", %".264"
  %".278" = or i32 %".275", %".277"
  %".279" = and i32 %".261", 524288
  %".280" = and i32 %".279", 0
  %".281" = or i32 %".278", %".280"
  br label %"BB_08f0"
BB_08f0:
  %"phi.46" = phi  i32 [%"phi.14", %"BB_0860"], [%"P43_to_i32", %"BB_0920"]
  %"phi.47" = phi  i32 [%"P55_to_i32", %"BB_0860"], [%"phi.49", %"BB_0920"]
  %"cond_trunc.18" = trunc i32 %"phi.47" to i1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_trunc.18" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P41_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0900"
BB_0900:
  %"phi.48" = phi  i32 [%"P41_to_i32", %"BB_800008f0"], [%"phi.46", %"BB_08f0"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.2", 16
  %"copy_desc_r0_ext" = zext i32 %".281" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16392 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".285" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".286" = sub i64 %".285", 0
  %".287" = lshr i64 %".286", 4
  %".288" = add i64 %"copy_desc_packed_1", %".287"
  %".289" = and i64 %".288", 16383
  %".290" = and i64 %"copy_desc_packed_1", -16384
  %".291" = or i64 %".290", %".289"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".291")
  br label %"BB_0910"
BB_0910:
  %"cond_trunc.19" = trunc i32 %"phi.48" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000910", label %"BB_0920"
BB_80000910:
  %"lop3_a_trunc" = trunc i32 %"phi.48" to i1
  %"lop3_a_cast_zext.3" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".295" = xor i32 %"plop3_a_bit.3", 1
  %".296" = xor i32 %"plop3_b_bit.3", 1
  %".297" = xor i32 %"plop3_c_bit.3", 1
  %".298" = and i32 %".295", %"plop3_b_bit.3"
  %".299" = and i32 %".298", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".299", 0
  %"P10_to_i32" = zext i1 %"plop3_pred.3" to i32
  br label %"BB_0920"
BB_0920:
  %"phi.49" = phi  i32 [%"P10_to_i32", %"BB_80000910"], [%"phi.47", %"BB_0910"]
  %"lop3_a_cast_zext.4" = zext i1 1 to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".301" = xor i32 %"plop3_a_bit.4", 1
  %".302" = xor i32 %"plop3_b_bit.4", 1
  %".303" = xor i32 %"plop3_c_bit.4", 1
  %".304" = and i32 %".301", %"plop3_b_bit.4"
  %".305" = and i32 %".304", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".305", 0
  %"P43_to_i32" = zext i1 %"plop3_pred.4" to i32
  %"bra_cond_trunc" = trunc i32 %"phi.49" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1")
  br i1 %"branch_any", label %"BB_08f0", label %"BB_0940"
BB_0940:
  %"iadd3_n1.6" = add i32 1024, 9728
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".307" = xor i32 %"plop3_a_bit.5", 1
  %".308" = xor i32 %"plop3_b_bit.5", 1
  %".309" = xor i32 %"plop3_c_bit.5", 1
  %".310" = and i32 %"plop3_a_bit.5", %"plop3_b_bit.5"
  %".311" = and i32 %".310", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".311", 0
  %"P37_to_i32" = zext i1 %"plop3_pred.5" to i32
  %".312" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".313" = zext i32 %"iadd3_n2.6" to i64
  %".314" = zext i32 24 to i64
  %".315" = shl i64 %".312", %".314"
  %".316" = and i64 %".315", 4294967295
  %".317" = add i64 %".316", %".313"
  %".318" = trunc i64 %".317" to i32
  %".319" = zext i32 0 to i64
  %".320" = zext i32 %".318" to i64
  %".321" = shl i64 %".320", 32
  %"shf_concat.5" = or i64 %".319", %".321"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".322" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.1" = lshr i64 %".322", 32
  %"shf_result.5" = trunc i64 %"shf_hi.1" to i32
  %".323" = xor i32 %"shf_result.5", -1
  %".324" = xor i32 16376, -1
  %".325" = xor i32 0, -1
  %".326" = and i32 %"shf_result.5", 16376
  %".327" = and i32 %".326", %".325"
  %".328" = and i32 %"shf_result.5", 16376
  %".329" = and i32 %".328", 0
  %".330" = or i32 %".327", %".329"
  %".331" = xor i32 %".330", -1
  %".332" = xor i32 524288, -1
  %".333" = xor i32 0, -1
  %".334" = and i32 %".331", 524288
  %".335" = and i32 %".334", %".333"
  %".336" = and i32 %".331", 524288
  %".337" = and i32 %".336", 0
  %".338" = or i32 %".335", %".337"
  %".339" = and i32 %".330", %".332"
  %".340" = and i32 %".339", %".333"
  %".341" = or i32 %".338", %".340"
  %".342" = and i32 %".330", %".332"
  %".343" = and i32 %".342", 0
  %".344" = or i32 %".341", %".343"
  %".345" = and i32 %".330", 524288
  %".346" = and i32 %".345", %".333"
  %".347" = or i32 %".344", %".346"
  %".348" = and i32 %".330", 524288
  %".349" = and i32 %".348", 0
  %".350" = or i32 %".347", %".349"
  br label %"BB_09b0"
BB_09b0:
  %"phi.50" = phi  i32 [%"P43_to_i32", %"BB_0940"], [%"P27_to_i32", %"BB_09e0"]
  %"phi.51" = phi  i32 [%"P37_to_i32", %"BB_0940"], [%"phi.53", %"BB_09e0"]
  %"cond_trunc.20" = trunc i32 %"phi.51" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P46_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.52" = phi  i32 [%"P46_to_i32", %"BB_800009b0"], [%"phi.50", %"BB_09b0"]
  %"copy_dst_memaddr_offset_add.1" = add i32 %"lds.2", 20
  %"copy_desc_r0_ext.1" = zext i32 %".350" to i64
  %"copy_desc_packed_0.1" = or i64 0, %"copy_desc_r0_ext.1"
  %"copy_desc_r1_ext.1" = zext i32 16392 to i64
  %"copy_desc_r1_shift.1" = shl i64 %"copy_desc_r1_ext.1", 32
  %"copy_desc_packed_1.1" = or i64 %"copy_desc_packed_0.1", %"copy_desc_r1_shift.1"
  %".354" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".355" = sub i64 %".354", 0
  %".356" = lshr i64 %".355", 4
  %".357" = add i64 %"copy_desc_packed_1.1", %".356"
  %".358" = and i64 %".357", 16383
  %".359" = and i64 %"copy_desc_packed_1.1", -16384
  %".360" = or i64 %".359", %".358"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add.1", i64 %".360")
  br label %"BB_09d0"
BB_09d0:
  %"cond_trunc.21" = trunc i32 %"phi.52" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_800009d0", label %"BB_09e0"
BB_800009d0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.52" to i1
  %"lop3_a_cast_zext.6" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".364" = xor i32 %"plop3_a_bit.6", 1
  %".365" = xor i32 %"plop3_b_bit.6", 1
  %".366" = xor i32 %"plop3_c_bit.6", 1
  %".367" = and i32 %".364", %"plop3_b_bit.6"
  %".368" = and i32 %".367", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".368", 0
  %"P54_to_i32" = zext i1 %"plop3_pred.6" to i32
  br label %"BB_09e0"
BB_09e0:
  %"phi.53" = phi  i32 [%"P54_to_i32", %"BB_800009d0"], [%"phi.51", %"BB_09d0"]
  %"lop3_a_cast_zext.7" = zext i1 1 to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".370" = xor i32 %"plop3_a_bit.7", 1
  %".371" = xor i32 %"plop3_b_bit.7", 1
  %".372" = xor i32 %"plop3_c_bit.7", 1
  %".373" = and i32 %".370", %"plop3_b_bit.7"
  %".374" = and i32 %".373", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".374", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.7" to i32
  %"bra_cond_trunc.1" = trunc i32 %"phi.53" to i1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_trunc.1" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.1")
  br i1 %"branch_any.1", label %"BB_09b0", label %"BB_0a00"
BB_0a00:
  %"iadd3_n1.7" = add i32 1024, 8192
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".376" = xor i32 %"plop3_a_bit.8", 1
  %".377" = xor i32 %"plop3_b_bit.8", 1
  %".378" = xor i32 %"plop3_c_bit.8", 1
  %".379" = and i32 %"plop3_a_bit.8", %"plop3_b_bit.8"
  %".380" = and i32 %".379", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".380", 0
  %"P1_to_i32" = zext i1 %"plop3_pred.8" to i32
  %".381" = zext i32 0 to i64
  %".382" = zext i32 %".198" to i64
  %".383" = shl i64 %".382", 32
  %"shf_concat.6" = or i64 %".381", %".383"
  %"shf_shift_64.6" = zext i32 4 to i64
  %".384" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.2" = lshr i64 %".384", 32
  %"shf_result.6" = trunc i64 %"shf_hi.2" to i32
  %".385" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".386" = zext i32 %"iadd3_n2.7" to i64
  %".387" = zext i32 24 to i64
  %".388" = shl i64 %".385", %".387"
  %".389" = and i64 %".388", 4294967295
  %".390" = add i64 %".389", %".386"
  %".391" = trunc i64 %".390" to i32
  %".392" = xor i32 %"shf_result.6", -1
  %".393" = xor i32 16376, -1
  %".394" = xor i32 0, -1
  %".395" = and i32 %"shf_result.6", 16376
  %".396" = and i32 %".395", %".394"
  %".397" = and i32 %"shf_result.6", 16376
  %".398" = and i32 %".397", 0
  %".399" = or i32 %".396", %".398"
  %".400" = zext i32 0 to i64
  %".401" = zext i32 %".391" to i64
  %".402" = shl i64 %".401", 32
  %"shf_concat.7" = or i64 %".400", %".402"
  %"shf_shift_64.7" = zext i32 4 to i64
  %".403" = lshr i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_hi.3" = lshr i64 %".403", 32
  %"shf_result.7" = trunc i64 %"shf_hi.3" to i32
  %"iadd3_n1.8" = add i32 %"lds.2", 16
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".404" = xor i32 %"shf_result.7", -1
  %".405" = xor i32 16376, -1
  %".406" = xor i32 0, -1
  %".407" = and i32 %"shf_result.7", 16376
  %".408" = and i32 %".407", %".406"
  %".409" = and i32 %"shf_result.7", 16376
  %".410" = and i32 %".409", 0
  %".411" = or i32 %".408", %".410"
  %"iadd3_n1.9" = add i32 %"lds.2", 20
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %".412" = xor i32 %".411", -1
  %".413" = xor i32 524288, -1
  %".414" = xor i32 0, -1
  %".415" = and i32 %".412", 524288
  %".416" = and i32 %".415", %".414"
  %".417" = and i32 %".412", 524288
  %".418" = and i32 %".417", 0
  %".419" = or i32 %".416", %".418"
  %".420" = and i32 %".411", %".413"
  %".421" = and i32 %".420", %".414"
  %".422" = or i32 %".419", %".421"
  %".423" = and i32 %".411", %".413"
  %".424" = and i32 %".423", 0
  %".425" = or i32 %".422", %".424"
  %".426" = and i32 %".411", 524288
  %".427" = and i32 %".426", %".414"
  %".428" = or i32 %".425", %".427"
  %".429" = and i32 %".411", 524288
  %".430" = and i32 %".429", 0
  %".431" = or i32 %".428", %".430"
  %".432" = xor i32 %".399", -1
  %".433" = xor i32 524288, -1
  %".434" = xor i32 0, -1
  %".435" = and i32 %".432", 524288
  %".436" = and i32 %".435", %".434"
  %".437" = and i32 %".432", 524288
  %".438" = and i32 %".437", 0
  %".439" = or i32 %".436", %".438"
  %".440" = and i32 %".399", %".433"
  %".441" = and i32 %".440", %".434"
  %".442" = or i32 %".439", %".441"
  %".443" = and i32 %".399", %".433"
  %".444" = and i32 %".443", 0
  %".445" = or i32 %".442", %".444"
  %".446" = and i32 %".399", 524288
  %".447" = and i32 %".446", %".434"
  %".448" = or i32 %".445", %".447"
  %".449" = and i32 %".399", 524288
  %".450" = and i32 %".449", 0
  %".451" = or i32 %".448", %".450"
  br label %"BB_0af0"
BB_0af0:
  %"phi.54" = phi  i32 [%"P27_to_i32", %"BB_0a00"], [%"P31_to_i32", %"BB_0b20"]
  %"phi.55" = phi  i32 [%"P1_to_i32", %"BB_0a00"], [%"phi.57", %"BB_0b20"]
  %"cond_trunc.22" = trunc i32 %"phi.55" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000af0", label %"BB_0b00"
BB_80000af0:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P29_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_0b00"
BB_0b00:
  %"phi.56" = phi  i32 [%"P29_to_i32", %"BB_80000af0"], [%"phi.54", %"BB_0af0"]
  %"mma_a_r0_ext" = zext i32 %".451" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".455" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".456" = sub i64 %".455", 0
  %".457" = lshr i64 %".456", 4
  %".458" = add i64 %"mma_a_packed_1", %".457"
  %".459" = and i64 %".458", 16383
  %".460" = and i64 %"mma_a_packed_1", -16384
  %".461" = or i64 %".460", %".459"
  %"mma_b_r0_ext" = zext i32 %".431" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".462" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".463" = sub i64 %".462", 0
  %".464" = lshr i64 %".463", 4
  %".465" = add i64 %"mma_b_packed_1", %".464"
  %".466" = and i64 %".465", 16383
  %".467" = and i64 %"mma_b_packed_1", -16384
  %".468" = or i64 %".467", %".466"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.2", i64 %".461", i64 %".468", i32 679744944, i32 %"mma_arg_zext", i32 %"iadd3_n2.8", i32 %"iadd3_n2.9")
  br label %"BB_0b10"
BB_0b10:
  %"cond_trunc.23" = trunc i32 %"phi.56" to i1
  %"pbra_cond_to_i32.23" = zext i1 %"cond_trunc.23" to i32
  %"pbra_cond_to_i1.23" = icmp ne i32 %"pbra_cond_to_i32.23", 0
  br i1 %"pbra_cond_to_i1.23", label %"BB_80000b10", label %"BB_0b20"
BB_80000b10:
  %"lop3_a_trunc.2" = trunc i32 %"phi.56" to i1
  %"lop3_a_cast_zext.9" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".472" = xor i32 %"plop3_a_bit.9", 1
  %".473" = xor i32 %"plop3_b_bit.9", 1
  %".474" = xor i32 %"plop3_c_bit.9", 1
  %".475" = and i32 %".472", %"plop3_b_bit.9"
  %".476" = and i32 %".475", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".476", 0
  %"P23_to_i32" = zext i1 %"plop3_pred.9" to i32
  br label %"BB_0b20"
BB_0b20:
  %"phi.57" = phi  i32 [%"P23_to_i32", %"BB_80000b10"], [%"phi.55", %"BB_0b10"]
  %"lop3_a_cast_zext.10" = zext i1 1 to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".478" = xor i32 %"plop3_a_bit.10", 1
  %".479" = xor i32 %"plop3_b_bit.10", 1
  %".480" = xor i32 %"plop3_c_bit.10", 1
  %".481" = and i32 %".478", %"plop3_b_bit.10"
  %".482" = and i32 %".481", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".482", 0
  %"P31_to_i32" = zext i1 %"plop3_pred.10" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.57" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any.2", label %"BB_0af0", label %"BB_0b40"
BB_0b40:
  %"iadd3_n1.10" = add i32 1024, 10240
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".484" = xor i32 %"plop3_a_bit.11", 1
  %".485" = xor i32 %"plop3_b_bit.11", 1
  %".486" = xor i32 %"plop3_c_bit.11", 1
  %".487" = and i32 %"plop3_a_bit.11", %"plop3_b_bit.11"
  %".488" = and i32 %".487", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".488", 0
  %"P45_to_i32" = zext i1 %"plop3_pred.11" to i32
  %".489" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".490" = zext i32 %"iadd3_n2.10" to i64
  %".491" = zext i32 24 to i64
  %".492" = shl i64 %".489", %".491"
  %".493" = and i64 %".492", 4294967295
  %".494" = add i64 %".493", %".490"
  %".495" = trunc i64 %".494" to i32
  br label %"BB_0b70"
BB_0b70:
  %"phi.58" = phi  i32 [%"P31_to_i32", %"BB_0b40"], [%"P36_to_i32", %"BB_0ba0"]
  %"phi.59" = phi  i32 [%"P45_to_i32", %"BB_0b40"], [%"phi.61", %"BB_0ba0"]
  %"cond_trunc.24" = trunc i32 %"phi.59" to i1
  %"pbra_cond_to_i32.24" = zext i1 %"cond_trunc.24" to i32
  %"pbra_cond_to_i1.24" = icmp ne i32 %"pbra_cond_to_i32.24", 0
  br i1 %"pbra_cond_to_i1.24", label %"BB_80000b70", label %"BB_0b80"
BB_80000b70:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P33_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0b80"
BB_0b80:
  %"phi.60" = phi  i32 [%"P33_to_i32", %"BB_80000b70"], [%"phi.58", %"BB_0b70"]
  %"utcbar_local_winoff" = and i32 %".495", 16777215
  %".499" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".500" = ptrtoint i8 addrspace(3)* %".499" to i32
  %".501" = lshr i32 %".495", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".500", i32 %".501")
  br label %"BB_0b90"
BB_0b90:
  %"cond_trunc.25" = trunc i32 %"phi.60" to i1
  %"pbra_cond_to_i32.25" = zext i1 %"cond_trunc.25" to i32
  %"pbra_cond_to_i1.25" = icmp ne i32 %"pbra_cond_to_i32.25", 0
  br i1 %"pbra_cond_to_i1.25", label %"BB_80000b90", label %"BB_0ba0"
BB_80000b90:
  %"lop3_a_trunc.3" = trunc i32 %"phi.60" to i1
  %"lop3_a_cast_zext.12" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.12" = zext i1 1 to i32
  %"lop3_c_cast_zext.12" = zext i1 1 to i32
  %"plop3_a_bit.12" = and i32 %"lop3_a_cast_zext.12", 1
  %"plop3_b_bit.12" = and i32 %"lop3_b_cast_zext.12", 1
  %"plop3_c_bit.12" = and i32 %"lop3_c_cast_zext.12", 1
  %".505" = xor i32 %"plop3_a_bit.12", 1
  %".506" = xor i32 %"plop3_b_bit.12", 1
  %".507" = xor i32 %"plop3_c_bit.12", 1
  %".508" = and i32 %".505", %"plop3_b_bit.12"
  %".509" = and i32 %".508", %"plop3_c_bit.12"
  %"plop3_pred.12" = icmp ne i32 %".509", 0
  %"P59_to_i32" = zext i1 %"plop3_pred.12" to i32
  br label %"BB_0ba0"
BB_0ba0:
  %"phi.61" = phi  i32 [%"P59_to_i32", %"BB_80000b90"], [%"phi.59", %"BB_0b90"]
  %"lop3_a_cast_zext.13" = zext i1 1 to i32
  %"lop3_b_cast_zext.13" = zext i1 1 to i32
  %"lop3_c_cast_zext.13" = zext i1 1 to i32
  %"plop3_a_bit.13" = and i32 %"lop3_a_cast_zext.13", 1
  %"plop3_b_bit.13" = and i32 %"lop3_b_cast_zext.13", 1
  %"plop3_c_bit.13" = and i32 %"lop3_c_cast_zext.13", 1
  %".511" = xor i32 %"plop3_a_bit.13", 1
  %".512" = xor i32 %"plop3_b_bit.13", 1
  %".513" = xor i32 %"plop3_c_bit.13", 1
  %".514" = and i32 %".511", %"plop3_b_bit.13"
  %".515" = and i32 %".514", %"plop3_c_bit.13"
  %"plop3_pred.13" = icmp ne i32 %".515", 0
  %"P36_to_i32" = zext i1 %"plop3_pred.13" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.61" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.3", label %"BB_0b70", label %"BB_0bc0"
BB_0bc0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.11" = add i32 1024, 10240
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %"imad_tmp.10" = mul i32 %"tid_x.1", 65536
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %".517" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".518" = zext i32 %"iadd3_n2.11" to i64
  %".519" = zext i32 24 to i64
  %".520" = shl i64 %".517", %".519"
  %".521" = and i64 %".520", 4294967295
  %".522" = add i64 %".521", %".518"
  %".523" = trunc i64 %".522" to i32
  %".524" = xor i32 %"imad.12", -1
  %".525" = xor i32 65011712, -1
  %".526" = xor i32 0, -1
  %".527" = and i32 %"imad.12", 65011712
  %".528" = and i32 %".527", %".526"
  %".529" = and i32 %"imad.12", 65011712
  %".530" = and i32 %".529", 0
  %".531" = or i32 %".528", %".530"
  %"imad_tmp.11" = mul i32 %"lds.1", 1
  %"imad.13" = add i32 %"imad_tmp.11", %".531"
  %"mbar_shared_winoff.1" = and i32 %".523", 16777215
  %".532" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".532" to i64
  %"mbar_par_bit" = lshr i32 0, 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P3_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0c40"
BB_0c40:
  %"cond_trunc.26" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.13" = xor i1 %"cond_trunc.26", -1
  %"pbra_cond_to_i32.26" = zext i1 %"cond_not.13" to i32
  %"pbra_cond_to_i1.26" = icmp ne i32 %"pbra_cond_to_i32.26", 0
  br i1 %"pbra_cond_to_i1.26", label %"BB_10d0", label %"BB_0c50"
BB_10d0:
  %"mbar_shared_winoff.2" = and i32 %".523", 16777215
  %".535" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".535" to i64
  %"mbar_par_bit.1" = lshr i32 0, 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P5_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_10e0"
BB_10e0:
  %"cond_trunc.27" = trunc i32 %"P5_to_i32" to i1
  %"cond_not.14" = xor i1 %"cond_trunc.27", -1
  %"pbra_cond_to_i32.27" = zext i1 %"cond_not.14" to i32
  %"pbra_cond_to_i1.27" = icmp ne i32 %"pbra_cond_to_i32.27", 0
  br i1 %"pbra_cond_to_i1.27", label %"BB_10d0", label %"BB_0c50"
BB_0c50:
  %".538" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".539" = bitcast i8* %".538" to i64*
  %"ldc_const.2" = load i64, i64* %".539"
  %"R3:R2_r0.4" = trunc i64 %"ldc_const.2" to i32
  %"R3:R2_r1_shift.4" = lshr i64 %"ldc_const.2", 32
  %"R3:R2_r1.4" = trunc i64 %"R3:R2_r1_shift.4" to i32
  %"imad_tmp.12" = mul i32 %"tid_x.1", 16
  %"imad.14" = add i32 %"imad_tmp.12", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.13")
  %".540" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".541" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".542" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".543" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.13", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".544" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".545" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".546" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".547" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.4" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.4" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.14" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.15" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.5" = trunc i64 %"imad.15" to i32
  %"R3:R2_r1_shift.5" = lshr i64 %"imad.15", 32
  %"R3:R2_r1.5" = trunc i64 %"R3:R2_r1_shift.5" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R29:R3_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".540", i32 addrspace(1)* %"R29:R3_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R29:R3_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".541", i32 addrspace(1)* %"R29:R3_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R29:R3_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".542", i32 addrspace(1)* %"R29:R3_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R29:R3_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".543", i32 addrspace(1)* %"R29:R3_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R29:R3_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".544", i32 addrspace(1)* %"R29:R3_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.13", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".553" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".554" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".555" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".556" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R29:R3_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".545", i32 addrspace(1)* %"R29:R3_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R29:R3_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".546", i32 addrspace(1)* %"R29:R3_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R29:R3_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".547", i32 addrspace(1)* %"R29:R3_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.13", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".560" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".561" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".562" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".563" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R29:R3_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".553", i32 addrspace(1)* %"R29:R3_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R29:R3_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".554", i32 addrspace(1)* %"R29:R3_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R29:R3_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".555", i32 addrspace(1)* %"R29:R3_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R29:R3_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".556", i32 addrspace(1)* %"R29:R3_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R29:R3_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".560", i32 addrspace(1)* %"R29:R3_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R29:R3_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".561", i32 addrspace(1)* %"R29:R3_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R29:R3_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".562", i32 addrspace(1)* %"R29:R3_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.5" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.5" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R29:R3_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".563", i32 addrspace(1)* %"R29:R3_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0e40"
BB_0e40:
  %"cond_trunc.28" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.28" = zext i1 %"cond_trunc.28" to i32
  %"pbra_cond_to_i1.28" = icmp ne i32 %"pbra_cond_to_i32.28", 0
  br i1 %"pbra_cond_to_i1.28", label %"BB_80000e40", label %"BB_0e50"
BB_0e50:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".198", 10248
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".574" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".574" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", 1
  %".575" = zext i32 %"s2ur_cluster_ctarank.1" to i64
  %".576" = zext i32 80 to i64
  %".577" = zext i32 24 to i64
  %".578" = shl i64 %".575", %".577"
  %".579" = and i64 %".578", 4294967295
  %".580" = add i64 %".579", %".576"
  %".581" = trunc i64 %".580" to i32
  %"lds_shared_addr_winoff.4" = and i32 %".581", 16777215
  %".582" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".582" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".583" = xor i32 %"lds.3", -1
  %".584" = xor i32 65535, -1
  %".585" = xor i32 0, -1
  %".586" = and i32 %"lds.3", 65535
  %".587" = and i32 %".586", %".585"
  %".588" = and i32 %"lds.3", 65535
  %".589" = and i32 %".588", 0
  %".590" = or i32 %".587", %".589"
  %".591" = zext i32 0 to i64
  %".592" = zext i32 %".590" to i64
  %".593" = shl i64 %".592", 32
  %"shf_concat.8" = or i64 %".591", %".593"
  %"shf_shift_64.8" = zext i32 5 to i64
  %".594" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.4" = lshr i64 %".594", 32
  %"shf_result.8" = trunc i64 %"shf_hi.4" to i32
  %"viadd.5" = add i32 %"shf_result.8", 16
  %".595" = zext i32 %"imad.16" to i64
  %".596" = zext i32 0 to i64
  %".597" = shl i64 %".596", 32
  %"shf_concat.9" = or i64 %".595", %".597"
  %"shf_shift_64.9" = zext i32 %"shf_result.8" to i64
  %".598" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".598" to i32
  %".599" = zext i32 %"imad.16" to i64
  %".600" = zext i32 0 to i64
  %".601" = shl i64 %".600", 32
  %"shf_concat.10" = or i64 %".599", %".601"
  %"shf_shift_64.10" = zext i32 %"viadd.5" to i64
  %".602" = shl i64 %"shf_concat.10", %"shf_shift_64.10"
  %"shf_result.10" = trunc i64 %".602" to i32
  %".603" = xor i32 %"shf_result.10", -1
  %".604" = xor i32 %"shf_result.9", -1
  %".605" = xor i32 0, -1
  %".606" = and i32 %".603", %"shf_result.9"
  %".607" = and i32 %".606", %".605"
  %".608" = and i32 %".603", %"shf_result.9"
  %".609" = and i32 %".608", 0
  %".610" = or i32 %".607", %".609"
  %".611" = and i32 %"shf_result.10", %".604"
  %".612" = and i32 %".611", %".605"
  %".613" = or i32 %".610", %".612"
  %".614" = and i32 %"shf_result.10", %".604"
  %".615" = and i32 %".614", 0
  %".616" = or i32 %".613", %".615"
  %".617" = and i32 %"shf_result.10", %"shf_result.9"
  %".618" = and i32 %".617", %".605"
  %".619" = or i32 %".616", %".618"
  %".620" = and i32 %"shf_result.10", %"shf_result.9"
  %".621" = and i32 %".620", 0
  %".622" = or i32 %".619", %".621"
  %".623" = xor i32 %".622", -1
  %".624" = xor i32 65535, -1
  %".625" = xor i32 0, -1
  %".626" = and i32 %".622", 65535
  %".627" = and i32 %".626", %".625"
  %".628" = and i32 %".622", 65535
  %".629" = and i32 %".628", 0
  %".630" = or i32 %".627", %".629"
  %".631" = xor i32 %".622", -1
  %".632" = xor i32 65535, -1
  %".633" = xor i32 %"lds.4", -1
  %".634" = and i32 %".622", 65535
  %".635" = and i32 %".634", %"lds.4"
  %"isetrp_cmp1.10" = icmp ne i32 %".635", %".630"
  %"isetrp_src_to_i32.10" = zext i1 1 to i32
  %"isetrp_src_to_i1.10" = icmp ne i32 %"isetrp_src_to_i32.10", 0
  %"isetrp_cmp2.10" = and i1 %"isetrp_cmp1.10", %"isetrp_src_to_i1.10"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.10" to i32
  br label %"BB_0f40"
BB_0f40:
  %"cond_trunc.29" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.29" = zext i1 %"cond_trunc.29" to i32
  %"pbra_cond_to_i1.29" = icmp ne i32 %"pbra_cond_to_i32.29", 0
  br i1 %"pbra_cond_to_i1.29", label %"BB_10a0_1160", label %"BB_0f50"
BB_0f50:
  %".638" = zext i32 0 to i64
  %".639" = zext i32 %"lds.4" to i64
  %".640" = shl i64 %".639", 32
  %"shf_concat.11" = or i64 %".638", %".640"
  %"shf_shift_64.11" = zext i32 16 to i64
  %".641" = lshr i64 %"shf_concat.11", %"shf_shift_64.11"
  %"shf_hi.5" = lshr i64 %".641", 32
  %"shf_result.11" = trunc i64 %"shf_hi.5" to i32
  %".642" = zext i32 0 to i64
  %".643" = zext i32 %".622" to i64
  %".644" = shl i64 %".643", 32
  %"shf_concat.12" = or i64 %".642", %".644"
  %"shf_shift_64.12" = zext i32 16 to i64
  %".645" = lshr i64 %"shf_concat.12", %"shf_shift_64.12"
  %"shf_hi.6" = lshr i64 %".645", 32
  %"shf_result.12" = trunc i64 %"shf_hi.6" to i32
  %".646" = xor i32 %"shf_result.11", -1
  %".647" = xor i32 %"shf_result.12", -1
  %".648" = xor i32 0, -1
  %".649" = and i32 %"shf_result.11", %"shf_result.12"
  %".650" = and i32 %".649", %".648"
  %".651" = and i32 %"shf_result.11", %"shf_result.12"
  %".652" = and i32 %".651", 0
  %".653" = or i32 %".650", %".652"
  %"isetrp_cmp1.11" = icmp ne i32 %".653", %"shf_result.12"
  %"isetrp_src_to_i32.11" = zext i1 1 to i32
  %"isetrp_src_to_i1.11" = icmp ne i32 %"isetrp_src_to_i32.11", 0
  %"isetrp_cmp2.11" = and i1 %"isetrp_cmp1.11", %"isetrp_src_to_i1.11"
  %"P7_to_i32" = zext i1 %"isetrp_cmp2.11" to i32
  br label %"BB_0f90"
BB_0f90:
  %"cond_trunc.30" = trunc i32 %"P7_to_i32" to i1
  %"pbra_cond_to_i32.30" = zext i1 %"cond_trunc.30" to i32
  %"pbra_cond_to_i1.30" = icmp ne i32 %"pbra_cond_to_i32.30", 0
  br i1 %"pbra_cond_to_i1.30", label %"BB_1070_1100", label %"BB_0fa0"
BB_0fa0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".656" = xor i32 0, -1
  %".657" = xor i32 %".622", -1
  %".658" = xor i32 0, -1
  %".659" = and i32 %".656", %".657"
  %".660" = and i32 %".659", %".658"
  %".661" = and i32 %".656", %".657"
  %".662" = and i32 %".661", 0
  %".663" = or i32 %".660", %".662"
  %".664" = and i32 0, %".657"
  %".665" = and i32 %".664", %".658"
  %".666" = or i32 %".663", %".665"
  %".667" = and i32 0, %".657"
  %".668" = and i32 %".667", 0
  %".669" = or i32 %".666", %".668"
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %".669"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.17", i32 %"redux_mask")
  %".670" = xor i32 %".669", -1
  %".671" = call i32 @"llvm.cttz.i32"(i32 %".670", i1 0)
  %".672" = shl i32 %".671", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".672") convergent
  %"isetrp_cmp1.12" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.12" = zext i1 1 to i32
  %"isetrp_src_to_i1.12" = icmp ne i32 %"isetrp_src_to_i32.12", 0
  %"isetrp_cmp2.12" = and i1 %"isetrp_cmp1.12", %"isetrp_src_to_i1.12"
  %"P8_to_i32" = zext i1 %"isetrp_cmp2.12" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and"
  br label %"BB_1040"
BB_1040:
  %"cond_trunc.31" = trunc i32 %"P8_to_i32" to i1
  %"pbra_cond_to_i32.31" = zext i1 %"cond_trunc.31" to i32
  %"pbra_cond_to_i1.31" = icmp ne i32 %"pbra_cond_to_i32.31", 0
  br i1 %"pbra_cond_to_i1.31", label %"BB_80001040", label %"BB_10b0"
BB_80001040:
  %"atoms_shared_addr_winoff.1" = and i32 %".581", 16777215
  %".676" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".676" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.1", i32 %"imad.18" monotonic
  br label %"BB_10b0"
BB_1070_1100:
  call void @"llvm.trap"()
  br label %"BB_10b0"
BB_10a0_1160:
  call void @"llvm.trap"()
  br label %"BB_10b0"
BB_10b0:
  ret void
BB_80000e40:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.z"()

declare void @"llvm.nvvm.barrier0"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.trap"()

declare void @"llvm.nvvm.bar.warp.sync"(i32 %".1")

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case5EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
