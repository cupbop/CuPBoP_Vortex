; ModuleID = "tcgen05_scale_copy_sm100a_cuda13"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [11280 x i8], align 16
define void @"_Z13column_scaledIL4Case5EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P11_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.1" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.2" = phi  i32 [%"R5:R4_r0", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R5:R4_r1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R9:R137_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R9:R137_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi", 128
  %"iadd3_o1_64" = zext i32 %"phi.2" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P5_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi.3"
  %"imad_cin_trunc" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".27" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P30_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P7_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R5:R4_r1"
  %"imad_cin_trunc.1" = trunc i32 %"P7_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R149:R120_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R149:R120_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P27_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P27_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P11_to_i32", %"BB_01b0"], [%"P27_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P40_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P40_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 10240
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P41_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P41_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 10248
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P32_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 10248
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P42_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P42_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 10248
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P43_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P43_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 10248
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P32_to_i32", %"BB_04a0"], [%"P32_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 10248
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  br label %"BB_0540"
BB_0540:
  %"cond_trunc.7" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0670", label %"BB_0550"
BB_0550:
  %"imad_tmp.7" = mul i32 %"tid_x", 10
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R102:R90_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R102:R90_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R102:R90_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R102:R90_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R102:R90_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R102:R90_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R102:R90_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R102:R90_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.7"
  %"iadd3_n1.3" = add i32 1024, 9216
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 1024, 9728
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %".112" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".113" = zext i32 %"iadd3_n2.3" to i64
  %".114" = zext i32 24 to i64
  %".115" = shl i64 %".112", %".114"
  %".116" = and i64 %".115", 4294967295
  %".117" = add i64 %".116", %".113"
  %".118" = trunc i64 %".117" to i32
  %".119" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".120" = zext i32 %"iadd3_n2.4" to i64
  %".121" = zext i32 24 to i64
  %".122" = shl i64 %".119", %".121"
  %".123" = and i64 %".122", 4294967295
  %".124" = add i64 %".123", %".120"
  %".125" = trunc i64 %".124" to i32
  %".126" = zext i32 %"tid_x" to i64
  %".127" = zext i32 %".118" to i64
  %".128" = zext i32 4 to i64
  %".129" = shl i64 %".126", %".128"
  %".130" = and i64 %".129", 4294967295
  %".131" = add i64 %".130", %".127"
  %".132" = trunc i64 %".131" to i32
  %".133" = zext i32 %"tid_x" to i64
  %".134" = zext i32 %".125" to i64
  %".135" = zext i32 4 to i64
  %".136" = shl i64 %".133", %".135"
  %".137" = and i64 %".136", 4294967295
  %".138" = add i64 %".137", %".134"
  %".139" = trunc i64 %".138" to i32
  %"sts_val_r0_ext" = zext i32 %"ldg.2" to i128
  %"sts_val_packed_0" = or i128 0, %"sts_val_r0_ext"
  %"sts_val_r1_ext" = zext i32 %"ldg.3" to i128
  %"sts_val_r1_shift" = shl i128 %"sts_val_r1_ext", 32
  %"sts_val_packed_1" = or i128 %"sts_val_packed_0", %"sts_val_r1_shift"
  %"sts_val_r2_ext" = zext i32 %"ldg.4" to i128
  %"sts_val_r2_shift" = shl i128 %"sts_val_r2_ext", 64
  %"sts_val_packed_2" = or i128 %"sts_val_packed_1", %"sts_val_r2_shift"
  %"sts_val_r3_ext" = zext i32 %"ldg.5" to i128
  %"sts_val_r3_shift" = shl i128 %"sts_val_r3_ext", 96
  %"sts_val_packed_3" = or i128 %"sts_val_packed_2", %"sts_val_r3_shift"
  %"sts_shared_addr_winoff.3" = and i32 %".132", 16777215
  %".140" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".140" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3", i128 addrspace(3)* %"sts_shared_addr_cast.3"
  %"sts_val_r0_ext.1" = zext i32 %"ldg.6" to i128
  %"sts_val_packed_0.1" = or i128 0, %"sts_val_r0_ext.1"
  %"sts_val_r1_ext.1" = zext i32 %"ldg.7" to i128
  %"sts_val_r1_shift.1" = shl i128 %"sts_val_r1_ext.1", 32
  %"sts_val_packed_1.1" = or i128 %"sts_val_packed_0.1", %"sts_val_r1_shift.1"
  %"sts_val_r2_ext.1" = zext i32 %"ldg.8" to i128
  %"sts_val_r2_shift.1" = shl i128 %"sts_val_r2_ext.1", 64
  %"sts_val_packed_2.1" = or i128 %"sts_val_packed_1.1", %"sts_val_r2_shift.1"
  %"sts_val_r3_ext.1" = zext i32 %"ldg.9" to i128
  %"sts_val_r3_shift.1" = shl i128 %"sts_val_r3_ext.1", 96
  %"sts_val_packed_3.1" = or i128 %"sts_val_packed_2.1", %"sts_val_r3_shift.1"
  %"sts_shared_addr_winoff.4" = and i32 %".139", 16777215
  %".142" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".142" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.1", i128 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_0670"
BB_0670:
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.8" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0a60", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 10248
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".149" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".149" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".150" = xor i32 %"plop3_a_bit", 1
  %".151" = xor i32 %"plop3_b_bit", 1
  %".152" = xor i32 %"plop3_c_bit", 1
  %".153" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".154" = and i32 %".153", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".154", 0
  %"P45_to_i32" = zext i1 %"plop3_pred" to i32
  %".155" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".156" = zext i32 %"iadd3_n2.5" to i64
  %".157" = zext i32 24 to i64
  %".158" = shl i64 %".155", %".157"
  %".159" = and i64 %".158", 4294967295
  %".160" = add i64 %".159", %".156"
  %".161" = trunc i64 %".160" to i32
  %".162" = zext i32 0 to i64
  %".163" = zext i32 %".161" to i64
  %".164" = shl i64 %".163", 32
  %"shf_concat.3" = or i64 %".162", %".164"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".165" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".165", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".166" = xor i32 %"shf_result.3", -1
  %".167" = xor i32 16376, -1
  %".168" = xor i32 0, -1
  %".169" = and i32 %"shf_result.3", 16376
  %".170" = and i32 %".169", %".168"
  %".171" = and i32 %"shf_result.3", 16376
  %".172" = and i32 %".171", 0
  %".173" = or i32 %".170", %".172"
  %".174" = xor i32 %".173", -1
  %".175" = xor i32 524288, -1
  %".176" = xor i32 0, -1
  %".177" = and i32 %".174", 524288
  %".178" = and i32 %".177", %".176"
  %".179" = and i32 %".174", 524288
  %".180" = and i32 %".179", 0
  %".181" = or i32 %".178", %".180"
  %".182" = and i32 %".173", %".175"
  %".183" = and i32 %".182", %".176"
  %".184" = or i32 %".181", %".183"
  %".185" = and i32 %".173", %".175"
  %".186" = and i32 %".185", 0
  %".187" = or i32 %".184", %".186"
  %".188" = and i32 %".173", 524288
  %".189" = and i32 %".188", %".176"
  %".190" = or i32 %".187", %".189"
  %".191" = and i32 %".173", 524288
  %".192" = and i32 %".191", 0
  %".193" = or i32 %".190", %".192"
  br label %"BB_0790"
BB_0790:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_0700"], [%"P39_to_i32", %"BB_07c0"]
  %"phi.15" = phi  i32 [%"P45_to_i32", %"BB_0700"], [%"phi.17", %"BB_07c0"]
  %"cond_trunc.9" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000790", label %"BB_07a0"
BB_80000790:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P36_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07a0"
BB_07a0:
  %"phi.16" = phi  i32 [%"P36_to_i32", %"BB_80000790"], [%"phi.14", %"BB_0790"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.1", 16
  %"copy_desc_r0_ext" = zext i32 %".193" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16392 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".197" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".198" = sub i64 %".197", 0
  %".199" = lshr i64 %".198", 4
  %".200" = add i64 %"copy_desc_packed_1", %".199"
  %".201" = and i64 %".200", 16383
  %".202" = and i64 %"copy_desc_packed_1", -16384
  %".203" = or i64 %".202", %".201"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".203")
  br label %"BB_07b0"
BB_07b0:
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_800007b0", label %"BB_07c0"
BB_800007b0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".207" = xor i32 %"plop3_a_bit.1", 1
  %".208" = xor i32 %"plop3_b_bit.1", 1
  %".209" = xor i32 %"plop3_c_bit.1", 1
  %".210" = and i32 %".207", %"plop3_b_bit.1"
  %".211" = and i32 %".210", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".211", 0
  %"P51_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_07c0"
BB_07c0:
  %"phi.17" = phi  i32 [%"P51_to_i32", %"BB_800007b0"], [%"phi.15", %"BB_07b0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".213" = xor i32 %"plop3_a_bit.2", 1
  %".214" = xor i32 %"plop3_b_bit.2", 1
  %".215" = xor i32 %"plop3_c_bit.2", 1
  %".216" = and i32 %".213", %"plop3_b_bit.2"
  %".217" = and i32 %".216", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".217", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0790", label %"BB_07e0"
BB_07e0:
  %"iadd3_n1.6" = add i32 1024, 9728
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".219" = xor i32 %"plop3_a_bit.3", 1
  %".220" = xor i32 %"plop3_b_bit.3", 1
  %".221" = xor i32 %"plop3_c_bit.3", 1
  %".222" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".223" = and i32 %".222", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".223", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".224" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".225" = zext i32 %"iadd3_n2.6" to i64
  %".226" = zext i32 24 to i64
  %".227" = shl i64 %".224", %".226"
  %".228" = and i64 %".227", 4294967295
  %".229" = add i64 %".228", %".225"
  %".230" = trunc i64 %".229" to i32
  %".231" = zext i32 0 to i64
  %".232" = zext i32 %".230" to i64
  %".233" = shl i64 %".232", 32
  %"shf_concat.4" = or i64 %".231", %".233"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".234" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".234", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".235" = xor i32 %"shf_result.4", -1
  %".236" = xor i32 16376, -1
  %".237" = xor i32 0, -1
  %".238" = and i32 %"shf_result.4", 16376
  %".239" = and i32 %".238", %".237"
  %".240" = and i32 %"shf_result.4", 16376
  %".241" = and i32 %".240", 0
  %".242" = or i32 %".239", %".241"
  %".243" = xor i32 %".242", -1
  %".244" = xor i32 524288, -1
  %".245" = xor i32 0, -1
  %".246" = and i32 %".243", 524288
  %".247" = and i32 %".246", %".245"
  %".248" = and i32 %".243", 524288
  %".249" = and i32 %".248", 0
  %".250" = or i32 %".247", %".249"
  %".251" = and i32 %".242", %".244"
  %".252" = and i32 %".251", %".245"
  %".253" = or i32 %".250", %".252"
  %".254" = and i32 %".242", %".244"
  %".255" = and i32 %".254", 0
  %".256" = or i32 %".253", %".255"
  %".257" = and i32 %".242", 524288
  %".258" = and i32 %".257", %".245"
  %".259" = or i32 %".256", %".258"
  %".260" = and i32 %".242", 524288
  %".261" = and i32 %".260", 0
  %".262" = or i32 %".259", %".261"
  br label %"BB_0850"
BB_0850:
  %"phi.18" = phi  i32 [%"P39_to_i32", %"BB_07e0"], [%"P17_to_i32", %"BB_0880"]
  %"phi.19" = phi  i32 [%"P2_to_i32", %"BB_07e0"], [%"phi.21", %"BB_0880"]
  %"cond_trunc.11" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000850", label %"BB_0860"
BB_80000850:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P15_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0860"
BB_0860:
  %"phi.20" = phi  i32 [%"P15_to_i32", %"BB_80000850"], [%"phi.18", %"BB_0850"]
  %"copy_dst_memaddr_offset_add.1" = add i32 %"lds.1", 20
  %"copy_desc_r0_ext.1" = zext i32 %".262" to i64
  %"copy_desc_packed_0.1" = or i64 0, %"copy_desc_r0_ext.1"
  %"copy_desc_r1_ext.1" = zext i32 16392 to i64
  %"copy_desc_r1_shift.1" = shl i64 %"copy_desc_r1_ext.1", 32
  %"copy_desc_packed_1.1" = or i64 %"copy_desc_packed_0.1", %"copy_desc_r1_shift.1"
  %".266" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".267" = sub i64 %".266", 0
  %".268" = lshr i64 %".267", 4
  %".269" = add i64 %"copy_desc_packed_1.1", %".268"
  %".270" = and i64 %".269", 16383
  %".271" = and i64 %"copy_desc_packed_1.1", -16384
  %".272" = or i64 %".271", %".270"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add.1", i64 %".272")
  br label %"BB_0870"
BB_0870:
  %"cond_trunc.12" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000870", label %"BB_0880"
BB_80000870:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".276" = xor i32 %"plop3_a_bit.4", 1
  %".277" = xor i32 %"plop3_b_bit.4", 1
  %".278" = xor i32 %"plop3_c_bit.4", 1
  %".279" = and i32 %".276", %"plop3_b_bit.4"
  %".280" = and i32 %".279", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".280", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0880"
BB_0880:
  %"phi.21" = phi  i32 [%"P4_to_i32", %"BB_80000870"], [%"phi.19", %"BB_0870"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".282" = xor i32 %"plop3_a_bit.5", 1
  %".283" = xor i32 %"plop3_b_bit.5", 1
  %".284" = xor i32 %"plop3_c_bit.5", 1
  %".285" = and i32 %".282", %"plop3_b_bit.5"
  %".286" = and i32 %".285", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".286", 0
  %"P17_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0850", label %"BB_08a0"
BB_08a0:
  %"iadd3_n1.7" = add i32 1024, 8192
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".288" = xor i32 %"plop3_a_bit.6", 1
  %".289" = xor i32 %"plop3_b_bit.6", 1
  %".290" = xor i32 %"plop3_c_bit.6", 1
  %".291" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".292" = and i32 %".291", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".292", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.6" to i32
  %".293" = zext i32 0 to i64
  %".294" = zext i32 %".18" to i64
  %".295" = shl i64 %".294", 32
  %"shf_concat.5" = or i64 %".293", %".295"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".296" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.2" = lshr i64 %".296", 32
  %"shf_result.5" = trunc i64 %"shf_hi.2" to i32
  %".297" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".298" = zext i32 %"iadd3_n2.7" to i64
  %".299" = zext i32 24 to i64
  %".300" = shl i64 %".297", %".299"
  %".301" = and i64 %".300", 4294967295
  %".302" = add i64 %".301", %".298"
  %".303" = trunc i64 %".302" to i32
  %".304" = xor i32 %"shf_result.5", -1
  %".305" = xor i32 16376, -1
  %".306" = xor i32 0, -1
  %".307" = and i32 %"shf_result.5", 16376
  %".308" = and i32 %".307", %".306"
  %".309" = and i32 %"shf_result.5", 16376
  %".310" = and i32 %".309", 0
  %".311" = or i32 %".308", %".310"
  %".312" = zext i32 0 to i64
  %".313" = zext i32 %".303" to i64
  %".314" = shl i64 %".313", 32
  %"shf_concat.6" = or i64 %".312", %".314"
  %"shf_shift_64.6" = zext i32 4 to i64
  %".315" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.3" = lshr i64 %".315", 32
  %"shf_result.6" = trunc i64 %"shf_hi.3" to i32
  %"iadd3_n1.8" = add i32 %"lds.1", 16
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".316" = xor i32 %"shf_result.6", -1
  %".317" = xor i32 16376, -1
  %".318" = xor i32 0, -1
  %".319" = and i32 %"shf_result.6", 16376
  %".320" = and i32 %".319", %".318"
  %".321" = and i32 %"shf_result.6", 16376
  %".322" = and i32 %".321", 0
  %".323" = or i32 %".320", %".322"
  %"iadd3_n1.9" = add i32 %"lds.1", 20
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %".324" = xor i32 %".323", -1
  %".325" = xor i32 524288, -1
  %".326" = xor i32 0, -1
  %".327" = and i32 %".324", 524288
  %".328" = and i32 %".327", %".326"
  %".329" = and i32 %".324", 524288
  %".330" = and i32 %".329", 0
  %".331" = or i32 %".328", %".330"
  %".332" = and i32 %".323", %".325"
  %".333" = and i32 %".332", %".326"
  %".334" = or i32 %".331", %".333"
  %".335" = and i32 %".323", %".325"
  %".336" = and i32 %".335", 0
  %".337" = or i32 %".334", %".336"
  %".338" = and i32 %".323", 524288
  %".339" = and i32 %".338", %".326"
  %".340" = or i32 %".337", %".339"
  %".341" = and i32 %".323", 524288
  %".342" = and i32 %".341", 0
  %".343" = or i32 %".340", %".342"
  %".344" = xor i32 %".311", -1
  %".345" = xor i32 524288, -1
  %".346" = xor i32 0, -1
  %".347" = and i32 %".344", 524288
  %".348" = and i32 %".347", %".346"
  %".349" = and i32 %".344", 524288
  %".350" = and i32 %".349", 0
  %".351" = or i32 %".348", %".350"
  %".352" = and i32 %".311", %".345"
  %".353" = and i32 %".352", %".346"
  %".354" = or i32 %".351", %".353"
  %".355" = and i32 %".311", %".345"
  %".356" = and i32 %".355", 0
  %".357" = or i32 %".354", %".356"
  %".358" = and i32 %".311", 524288
  %".359" = and i32 %".358", %".346"
  %".360" = or i32 %".357", %".359"
  %".361" = and i32 %".311", 524288
  %".362" = and i32 %".361", 0
  %".363" = or i32 %".360", %".362"
  br label %"BB_0990"
BB_0990:
  %"phi.22" = phi  i32 [%"P17_to_i32", %"BB_08a0"], [%"P22_to_i32", %"BB_09c0"]
  %"phi.23" = phi  i32 [%"P25_to_i32", %"BB_08a0"], [%"phi.25", %"BB_09c0"]
  %"cond_trunc.13" = trunc i32 %"phi.23" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P20_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.24" = phi  i32 [%"P20_to_i32", %"BB_80000990"], [%"phi.22", %"BB_0990"]
  %"mma_a_r0_ext" = zext i32 %".363" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".367" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".368" = sub i64 %".367", 0
  %".369" = lshr i64 %".368", 4
  %".370" = add i64 %"mma_a_packed_1", %".369"
  %".371" = and i64 %".370", 16383
  %".372" = and i64 %"mma_a_packed_1", -16384
  %".373" = or i64 %".372", %".371"
  %"mma_b_r0_ext" = zext i32 %".343" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".374" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".375" = sub i64 %".374", 0
  %".376" = lshr i64 %".375", 4
  %".377" = add i64 %"mma_b_packed_1", %".376"
  %".378" = and i64 %".377", 16383
  %".379" = and i64 %"mma_b_packed_1", -16384
  %".380" = or i64 %".379", %".378"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".373", i64 %".380", i32 134481024, i32 %"mma_arg_zext", i32 %"iadd3_n2.8", i32 %"iadd3_n2.9")
  br label %"BB_09b0"
BB_09b0:
  %"cond_trunc.14" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.24" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".384" = xor i32 %"plop3_a_bit.7", 1
  %".385" = xor i32 %"plop3_b_bit.7", 1
  %".386" = xor i32 %"plop3_c_bit.7", 1
  %".387" = and i32 %".384", %"plop3_b_bit.7"
  %".388" = and i32 %".387", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".388", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.25" = phi  i32 [%"P44_to_i32", %"BB_800009b0"], [%"phi.23", %"BB_09b0"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".390" = xor i32 %"plop3_a_bit.8", 1
  %".391" = xor i32 %"plop3_b_bit.8", 1
  %".392" = xor i32 %"plop3_c_bit.8", 1
  %".393" = and i32 %".390", %"plop3_b_bit.8"
  %".394" = and i32 %".393", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".394", 0
  %"P22_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.4" = trunc i32 %"phi.25" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.4")
  br i1 %"branch_any.2", label %"BB_0990", label %"BB_09e0"
BB_09e0:
  %"iadd3_n1.10" = add i32 1024, 10240
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".396" = xor i32 %"plop3_a_bit.9", 1
  %".397" = xor i32 %"plop3_b_bit.9", 1
  %".398" = xor i32 %"plop3_c_bit.9", 1
  %".399" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".400" = and i32 %".399", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".400", 0
  %"P47_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".401" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".402" = zext i32 %"iadd3_n2.10" to i64
  %".403" = zext i32 24 to i64
  %".404" = shl i64 %".401", %".403"
  %".405" = and i64 %".404", 4294967295
  %".406" = add i64 %".405", %".402"
  %".407" = trunc i64 %".406" to i32
  br label %"BB_0a10"
BB_0a10:
  %"phi.26" = phi  i32 [%"P22_to_i32", %"BB_09e0"], [%"P29_to_i32", %"BB_0a40"]
  %"phi.27" = phi  i32 [%"P47_to_i32", %"BB_09e0"], [%"phi.29", %"BB_0a40"]
  %"cond_trunc.15" = trunc i32 %"phi.27" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P26_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.28" = phi  i32 [%"P26_to_i32", %"BB_80000a10"], [%"phi.26", %"BB_0a10"]
  %"utcbar_local_winoff" = and i32 %".407", 16777215
  %".411" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".412" = ptrtoint i8 addrspace(3)* %".411" to i32
  %".413" = lshr i32 %".407", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".412", i32 %".413")
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.16" = trunc i32 %"phi.28" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000a30", label %"BB_0a40"
BB_80000a30:
  %"lop3_a_trunc.3" = trunc i32 %"phi.28" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".417" = xor i32 %"plop3_a_bit.10", 1
  %".418" = xor i32 %"plop3_b_bit.10", 1
  %".419" = xor i32 %"plop3_c_bit.10", 1
  %".420" = and i32 %".417", %"plop3_b_bit.10"
  %".421" = and i32 %".420", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".421", 0
  %"P8_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.29" = phi  i32 [%"P8_to_i32", %"BB_80000a30"], [%"phi.27", %"BB_0a30"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".423" = xor i32 %"plop3_a_bit.11", 1
  %".424" = xor i32 %"plop3_b_bit.11", 1
  %".425" = xor i32 %"plop3_c_bit.11", 1
  %".426" = and i32 %".423", %"plop3_b_bit.11"
  %".427" = and i32 %".426", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".427", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.5" = trunc i32 %"phi.29" to i1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_trunc.5" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.5")
  br i1 %"branch_any.3", label %"BB_0a10", label %"BB_0a60"
BB_0a60:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.11" = add i32 1024, 10240
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %".429" = zext i32 0 to i64
  %".430" = zext i32 0 to i64
  %".431" = shl i64 %".430", 32
  %"shf_concat.7" = or i64 %".429", %".431"
  %"shf_shift_64.7" = zext i32 31 to i64
  %".432" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".432" to i32
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %".433" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".434" = zext i32 %"iadd3_n2.11" to i64
  %".435" = zext i32 24 to i64
  %".436" = shl i64 %".433", %".435"
  %".437" = and i64 %".436", 4294967295
  %".438" = add i64 %".437", %".434"
  %".439" = trunc i64 %".438" to i32
  %".440" = xor i32 %"imad.10", -1
  %".441" = xor i32 65011712, -1
  %".442" = xor i32 0, -1
  %".443" = and i32 %"imad.10", 65011712
  %".444" = and i32 %".443", %".442"
  %".445" = and i32 %"imad.10", 65011712
  %".446" = and i32 %".445", 0
  %".447" = or i32 %".444", %".446"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".447"
  %"mbar_shared_winoff.1" = and i32 %".439", 16777215
  %".448" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".448" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.7", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P48_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.17" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f50", label %"BB_0b10"
BB_0f50:
  %"mbar_shared_winoff.2" = and i32 %".439", 16777215
  %".451" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".451" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.7", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P49_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f60"
BB_0f60:
  %"cond_trunc.18" = trunc i32 %"P49_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0f50", label %"BB_0b10"
BB_0b10:
  %".454" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".455" = bitcast i8* %".454" to i64*
  %"ldc_const.1" = load i64, i64* %".455"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".456" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".457" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".458" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".459" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".460" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".461" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".462" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".463" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.3" = trunc i64 %"imad.13" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R105:R96_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".456", i32 addrspace(1)* %"R105:R96_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R105:R96_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".457", i32 addrspace(1)* %"R105:R96_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R105:R96_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".458", i32 addrspace(1)* %"R105:R96_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R105:R96_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".459", i32 addrspace(1)* %"R105:R96_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R105:R96_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".460", i32 addrspace(1)* %"R105:R96_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".469" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".470" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".471" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".472" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R105:R96_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".461", i32 addrspace(1)* %"R105:R96_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R105:R96_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".462", i32 addrspace(1)* %"R105:R96_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R105:R96_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".463", i32 addrspace(1)* %"R105:R96_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".476" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".477" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".478" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".479" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R105:R96_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".469", i32 addrspace(1)* %"R105:R96_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R105:R96_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".470", i32 addrspace(1)* %"R105:R96_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R105:R96_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".471", i32 addrspace(1)* %"R105:R96_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R105:R96_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".472", i32 addrspace(1)* %"R105:R96_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R105:R96_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".476", i32 addrspace(1)* %"R105:R96_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R105:R96_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".477", i32 addrspace(1)* %"R105:R96_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R105:R96_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".478", i32 addrspace(1)* %"R105:R96_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R105:R96_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".479", i32 addrspace(1)* %"R105:R96_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0d00"
BB_0d00:
  %"cond_trunc.19" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000d00", label %"BB_0d10"
BB_0d10:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 10248
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".490" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 1
  %".491" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".492" = zext i32 64 to i64
  %".493" = zext i32 24 to i64
  %".494" = shl i64 %".491", %".493"
  %".495" = and i64 %".494", 4294967295
  %".496" = add i64 %".495", %".492"
  %".497" = trunc i64 %".496" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".497", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".498" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".498" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".499" = xor i32 %"lds.2", -1
  %".500" = xor i32 65535, -1
  %".501" = xor i32 0, -1
  %".502" = and i32 %"lds.2", 65535
  %".503" = and i32 %".502", %".501"
  %".504" = and i32 %"lds.2", 65535
  %".505" = and i32 %".504", 0
  %".506" = or i32 %".503", %".505"
  %".507" = zext i32 0 to i64
  %".508" = zext i32 %".506" to i64
  %".509" = shl i64 %".508", 32
  %"shf_concat.8" = or i64 %".507", %".509"
  %"shf_shift_64.8" = zext i32 5 to i64
  %".510" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.4" = lshr i64 %".510", 32
  %"shf_result.8" = trunc i64 %"shf_hi.4" to i32
  %".511" = zext i32 %"imad.14" to i64
  %".512" = zext i32 0 to i64
  %".513" = shl i64 %".512", 32
  %"shf_concat.9" = or i64 %".511", %".513"
  %"shf_shift_64.9" = zext i32 %"shf_result.8" to i64
  %".514" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".514" to i32
  %".515" = xor i32 %"lds.3", -1
  %".516" = xor i32 %"shf_result.9", -1
  %".517" = xor i32 0, -1
  %".518" = and i32 %"lds.3", %"shf_result.9"
  %".519" = and i32 %".518", %".517"
  %".520" = and i32 %"lds.3", %"shf_result.9"
  %".521" = and i32 %".520", 0
  %".522" = or i32 %".519", %".521"
  %"isetrp_cmp1.5" = icmp ne i32 %".522", %"shf_result.9"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.20" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0f20_0fb0", label %"BB_0dd0"
BB_0dd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".497", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".525" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".525" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".526" = xor i32 %"lds.4", -1
  %".527" = xor i32 %"shf_result.9", -1
  %".528" = xor i32 0, -1
  %".529" = and i32 %"lds.4", %"shf_result.9"
  %".530" = and i32 %".529", %".528"
  %".531" = and i32 %"lds.4", %"shf_result.9"
  %".532" = and i32 %".531", 0
  %".533" = or i32 %".530", %".532"
  %"isetrp_cmp1.6" = icmp ne i32 %".533", %"shf_result.9"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0e00"
BB_0e00:
  %"cond_trunc.21" = trunc i32 %"P12_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0ef0_0f80", label %"BB_0e10"
BB_0e10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".536" = xor i32 0, -1
  %".537" = xor i32 %"shf_result.9", -1
  %".538" = xor i32 0, -1
  %".539" = and i32 %".536", %".537"
  %".540" = and i32 %".539", %".538"
  %".541" = and i32 %".536", %".537"
  %".542" = and i32 %".541", 0
  %".543" = or i32 %".540", %".542"
  %".544" = and i32 0, %".537"
  %".545" = and i32 %".544", %".538"
  %".546" = or i32 %".543", %".545"
  %".547" = and i32 0, %".537"
  %".548" = and i32 %".547", 0
  %".549" = or i32 %".546", %".548"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %".549"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.15", i32 %"redux_mask")
  %".550" = xor i32 %".549", -1
  %".551" = call i32 @"llvm.cttz.i32"(i32 %".550", i1 0)
  %".552" = shl i32 %".551", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".552") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0eb0"
BB_0eb0:
  %"cond_trunc.22" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000eb0", label %"BB_0f30"
BB_80000eb0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".497", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".556" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".556" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.16" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".497", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".557" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".557" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.16" monotonic
  br label %"BB_0f30"
BB_0ef0_0f80:
  call void @"llvm.trap"()
  br label %"BB_0f30"
BB_0f20_0fb0:
  call void @"llvm.trap"()
  br label %"BB_0f30"
BB_0f30:
  ret void
BB_80000d00:
  ret void
}

define void @"_Z13column_scaledIL4Case2EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P11_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".11" = bitcast i8* %".10" to i64*
  %"ldc_const" = load i64, i64* %".11"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".12" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".13" = zext i32 1024 to i64
  %".14" = zext i32 24 to i64
  %".15" = shl i64 %".12", %".14"
  %".16" = and i64 %".15", 4294967295
  %".17" = add i64 %".16", %".13"
  %".18" = trunc i64 %".17" to i32
  %".19" = zext i32 %"tid_x" to i64
  %".20" = zext i32 %".18" to i64
  %".21" = zext i32 2 to i64
  %".22" = shl i64 %".19", %".21"
  %".23" = and i64 %".22", 4294967295
  %".24" = add i64 %".23", %".20"
  %".25" = trunc i64 %".24" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift" = lshr i64 %"imad", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  br label %"BB_00d0"
BB_00d0:
  %"phi" = phi  i32 [%"tid_x", %"EntryBB_0000"], [%"viadd", %"BB_0150"]
  %"phi.1" = phi  i32 [%".25", %"EntryBB_0000"], [%"viadd.1", %"BB_0150"]
  %"phi.2" = phi  i32 [%"R5:R4_r0", %"EntryBB_0000"], [%"iadd3_trunc", %"BB_0150"]
  %"phi.3" = phi  i32 [%"R5:R4_r1", %"EntryBB_0000"], [%"imad_with_cin", %"BB_0150"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.2" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R9:R137_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R9:R137_addr_ptr"
  %"isetrp_cmp1" = icmp uge i32 %"phi", 1920
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P30_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"viadd" = add i32 %"phi", 128
  %"iadd3_o1_64" = zext i32 %"phi.2" to i64
  %"iadd3_o2_64" = zext i32 512 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P5_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"phi.3"
  %"imad_cin_trunc" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  %"sts_shared_addr_winoff" = and i32 %"phi.1", 16777215
  %".27" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".27" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.1", 512
  br label %"BB_0150"
BB_0150:
  %"cond_trunc" = trunc i32 %"P30_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc", -1
  %"pbra_cond_to_i32" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_00d0", label %"BB_0160"
BB_0160:
  %"isetrp_cmp1.1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P6_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  %"isetrp_cmp1.2" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P34_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  br label %"BB_01b0"
BB_01b0:
  %"cond_trunc.1" = trunc i32 %"P6_to_i32" to i1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_trunc.1" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_02b0", label %"BB_01c0"
BB_01c0:
  %"iadd3_n1" = add i32 1024, 8192
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_64.1" = zext i32 %"R5:R4_r0" to i64
  %"iadd3_o2_64.1" = zext i32 8192 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P7_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %".33" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".34" = zext i32 %"iadd3_n2" to i64
  %".35" = zext i32 24 to i64
  %".36" = shl i64 %".33", %".35"
  %".37" = and i64 %".36", 4294967295
  %".38" = add i64 %".37", %".34"
  %".39" = trunc i64 %".38" to i32
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"R5:R4_r1"
  %"imad_cin_trunc.1" = trunc i32 %"P7_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %".40" = zext i32 %"tid_x" to i64
  %".41" = zext i32 %".39" to i64
  %".42" = zext i32 2 to i64
  %".43" = shl i64 %".40", %".42"
  %".44" = and i64 %".43", 4294967295
  %".45" = add i64 %".44", %".41"
  %".46" = trunc i64 %".45" to i32
  br label %"BB_0220"
BB_0220:
  %"phi.4" = phi  i32 [%"imad_with_cin.1", %"BB_01c0"], [%"imad_with_cin.2", %"BB_02a0"]
  %"phi.5" = phi  i32 [%"tid_x", %"BB_01c0"], [%"viadd.2", %"BB_02a0"]
  %"phi.6" = phi  i32 [%".46", %"BB_01c0"], [%"viadd.3", %"BB_02a0"]
  %"phi.7" = phi  i32 [%"iadd3_trunc.1", %"BB_01c0"], [%"iadd3_trunc.2", %"BB_02a0"]
  %"ldg_addr_r0_ext.1" = zext i32 %"phi.7" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"phi.4" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R149:R120_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R149:R120_addr_ptr"
  %"isetrp_cmp1.3" = icmp uge i32 %"phi.5", 128
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P9_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  %"viadd.2" = add i32 %"phi.5", 128
  %"iadd3_o1_64.2" = zext i32 %"phi.7" to i64
  %"iadd3_o2_64.2" = zext i32 512 to i64
  %"iadd3_o3_64.2" = zext i32 0 to i64
  %"iadd3_tmp.2" = add i64 %"iadd3_o1_64.2", %"iadd3_o2_64.2"
  %"iadd3_tmp2.2" = add i64 %"iadd3_tmp.2", %"iadd3_o3_64.2"
  %"iadd3_trunc.2" = trunc i64 %"iadd3_tmp2.2" to i32
  %"iadd3_carry_val.2" = lshr i64 %"iadd3_tmp2.2", 32
  %"carry_ge_1.2" = icmp uge i64 %"iadd3_carry_val.2", 1
  %"P27_to_i32" = zext i1 %"carry_ge_1.2" to i32
  %"carry_ge_2.2" = icmp uge i64 %"iadd3_carry_val.2", 2
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", %"phi.4"
  %"imad_cin_trunc.2" = trunc i32 %"P27_to_i32" to i1
  %"imad_cin_ext.2" = zext i1 %"imad_cin_trunc.2" to i32
  %"imad_with_cin.2" = add i32 %"imad.3", %"imad_cin_ext.2"
  %"sts_shared_addr_winoff.1" = and i32 %"phi.6", 16777215
  %".48" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".48" to i32 addrspace(3)*
  store volatile i32 %"ldg.1", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  %"viadd.3" = add i32 %"phi.6", 512
  br label %"BB_02a0"
BB_02a0:
  %"cond_trunc.2" = trunc i32 %"P9_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_0220", label %"BB_02b0"
BB_02b0:
  %"phi.8" = phi  i32 [%"P11_to_i32", %"BB_01b0"], [%"P27_to_i32", %"BB_02a0"]
  %"vote_pred_trunc" = trunc i32 %"P34_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P40_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.4" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P10_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  br label %"BB_0300"
BB_0300:
  %"cond_trunc.3" = trunc i32 %"P40_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000300", label %"BB_0350"
BB_80000300:
  %"iadd3_n1.1" = add i32 1024, 10240
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.2" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %".54" = zext i32 %"iadd3_n2.2" to i64
  %".55" = zext i32 0 to i64
  %".56" = shl i64 %".55", 32
  %"shf_concat" = or i64 %".54", %".56"
  %"shf_shift_64" = zext i32 11 to i64
  %".57" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".57" to i32
  %".58" = zext i32 %"iadd3_n2.2" to i64
  %".59" = zext i32 0 to i64
  %".60" = shl i64 %".59", 32
  %"shf_concat.1" = or i64 %".58", %".60"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".61" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".61" to i32
  %".62" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".63" = zext i32 %"iadd3_n2.1" to i64
  %".64" = zext i32 24 to i64
  %".65" = shl i64 %".62", %".64"
  %".66" = and i64 %".65", 4294967295
  %".67" = add i64 %".66", %".63"
  %".68" = trunc i64 %".67" to i32
  br label %"BB_0350"
BB_0350:
  %"phi.9" = phi  i32 [%".68", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.10" = phi  i32 [%"shf_result", %"BB_80000300"], [0, %"BB_0300"]
  %"phi.11" = phi  i32 [%"shf_result.1", %"BB_80000300"], [1, %"BB_0300"]
  %"vote_pred_trunc.1" = trunc i32 %"P34_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P41_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0370"
BB_0370:
  %"cond_trunc.4" = trunc i32 %"P41_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.4", -1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_80000370", label %"BB_0380"
BB_80000370:
  %"mbar_shared_winoff" = and i32 %"phi.9", 16777215
  %".73" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".73" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.11" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.10" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".74" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".74" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0380"
BB_0380:
  %"cond_trunc.5" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_trunc.5" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0500", label %"BB_0390"
BB_0390:
  %"allocation_dst_memaddr_offset_add" = add i32 %".18", 10248
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".78" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".79" = ptrtoint i8 addrspace(3)* %".78" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".79", i32 32) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P32_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_03b0"
BB_03b0:
  %"cond_trunc.6" = trunc i32 %"P32_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.6", -1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0500", label %"BB_03c0"
BB_03c0:
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %".83" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".84" = zext i32 64 to i64
  %".85" = zext i32 24 to i64
  %".86" = shl i64 %".83", %".85"
  %".87" = and i64 %".86", 4294967295
  %".88" = add i64 %".87", %".84"
  %".89" = trunc i64 %".88" to i32
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".18", 10248
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".90" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".91" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %".92" = load i32, i32 addrspace(3)* %".91"
  %".93" = lshr i32 %".92", 5
  %"P42_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".93"
  %"bra_cond_trunc" = trunc i32 %"P42_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_04a0", label %"BB_0440"
BB_0440:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".18", 10248
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".95" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".96" = bitcast i8 addrspace(3)* %".95" to i32 addrspace(3)*
  %".97" = load i32, i32 addrspace(3)* %".96"
  %".98" = lshr i32 %".97", 5
  %"P43_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".98"
  %"bra_cond_trunc.1" = trunc i32 %"P43_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0440", label %"BB_04a0"
BB_04a0:
  %"phi.12" = phi  i32 [%"imad.5", %"BB_03c0"], [%"imad.6", %"BB_0440"]
  %".100" = zext i32 %"imad.4" to i64
  %".101" = zext i32 0 to i64
  %".102" = shl i64 %".101", 32
  %"shf_concat.2" = or i64 %".100", %".102"
  %"shf_shift_64.2" = zext i32 %"phi.12" to i64
  %".103" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".103" to i32
  %"imad_tmp.6" = mul i32 %"phi.12", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".89", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".104" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".104" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".89", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".105" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".105" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.2" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".18", 10248
  %"sts_shared_addr_winoff.2" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".106" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.2"
  %"sts_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".106" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.2"
  br label %"BB_0500"
BB_0500:
  %"phi.13" = phi  i32 [%"P32_to_i32", %"BB_04a0"], [%"P32_to_i32", %"BB_03b0"], [%"phi.8", %"BB_0380"]
  call void @"llvm.nvvm.barrier0"()
  %"lds_addr_memaddr_offset_add" = add i32 %".18", 10248
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".109" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".109" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  br label %"BB_0540"
BB_0540:
  %"cond_trunc.7" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_0670", label %"BB_0550"
BB_0550:
  %"imad_tmp.7" = mul i32 %"tid_x", 10
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R3:R2_r0.1" = trunc i64 %"imad.9" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 9216
  %"R102:R90_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr"
  %"ldg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 9220
  %"R102:R90_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 9224
  %"R102:R90_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 9228
  %"R102:R90_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.3"
  %"ldg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 9232
  %"R102:R90_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.4"
  %"ldg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 9236
  %"R102:R90_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.5"
  %"ldg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 9240
  %"R102:R90_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.6"
  %"ldg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 9244
  %"R102:R90_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R102:R90_addr_ptr.7"
  %"iadd3_n1.3" = add i32 1024, 9216
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 1024, 9728
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %".112" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".113" = zext i32 %"iadd3_n2.3" to i64
  %".114" = zext i32 24 to i64
  %".115" = shl i64 %".112", %".114"
  %".116" = and i64 %".115", 4294967295
  %".117" = add i64 %".116", %".113"
  %".118" = trunc i64 %".117" to i32
  %".119" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".120" = zext i32 %"iadd3_n2.4" to i64
  %".121" = zext i32 24 to i64
  %".122" = shl i64 %".119", %".121"
  %".123" = and i64 %".122", 4294967295
  %".124" = add i64 %".123", %".120"
  %".125" = trunc i64 %".124" to i32
  %".126" = zext i32 %"tid_x" to i64
  %".127" = zext i32 %".118" to i64
  %".128" = zext i32 4 to i64
  %".129" = shl i64 %".126", %".128"
  %".130" = and i64 %".129", 4294967295
  %".131" = add i64 %".130", %".127"
  %".132" = trunc i64 %".131" to i32
  %".133" = zext i32 %"tid_x" to i64
  %".134" = zext i32 %".125" to i64
  %".135" = zext i32 4 to i64
  %".136" = shl i64 %".133", %".135"
  %".137" = and i64 %".136", 4294967295
  %".138" = add i64 %".137", %".134"
  %".139" = trunc i64 %".138" to i32
  %"sts_val_r0_ext" = zext i32 %"ldg.2" to i128
  %"sts_val_packed_0" = or i128 0, %"sts_val_r0_ext"
  %"sts_val_r1_ext" = zext i32 %"ldg.3" to i128
  %"sts_val_r1_shift" = shl i128 %"sts_val_r1_ext", 32
  %"sts_val_packed_1" = or i128 %"sts_val_packed_0", %"sts_val_r1_shift"
  %"sts_val_r2_ext" = zext i32 %"ldg.4" to i128
  %"sts_val_r2_shift" = shl i128 %"sts_val_r2_ext", 64
  %"sts_val_packed_2" = or i128 %"sts_val_packed_1", %"sts_val_r2_shift"
  %"sts_val_r3_ext" = zext i32 %"ldg.5" to i128
  %"sts_val_r3_shift" = shl i128 %"sts_val_r3_ext", 96
  %"sts_val_packed_3" = or i128 %"sts_val_packed_2", %"sts_val_r3_shift"
  %"sts_shared_addr_winoff.3" = and i32 %".132", 16777215
  %".140" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.3"
  %"sts_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".140" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3", i128 addrspace(3)* %"sts_shared_addr_cast.3"
  %"sts_val_r0_ext.1" = zext i32 %"ldg.6" to i128
  %"sts_val_packed_0.1" = or i128 0, %"sts_val_r0_ext.1"
  %"sts_val_r1_ext.1" = zext i32 %"ldg.7" to i128
  %"sts_val_r1_shift.1" = shl i128 %"sts_val_r1_ext.1", 32
  %"sts_val_packed_1.1" = or i128 %"sts_val_packed_0.1", %"sts_val_r1_shift.1"
  %"sts_val_r2_ext.1" = zext i32 %"ldg.8" to i128
  %"sts_val_r2_shift.1" = shl i128 %"sts_val_r2_ext.1", 64
  %"sts_val_packed_2.1" = or i128 %"sts_val_packed_1.1", %"sts_val_r2_shift.1"
  %"sts_val_r3_ext.1" = zext i32 %"ldg.9" to i128
  %"sts_val_r3_shift.1" = shl i128 %"sts_val_r3_ext.1", 96
  %"sts_val_packed_3.1" = or i128 %"sts_val_packed_2.1", %"sts_val_r3_shift.1"
  %"sts_shared_addr_winoff.4" = and i32 %".139", 16777215
  %".142" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.4"
  %"sts_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".142" to i128 addrspace(3)*
  store volatile i128 %"sts_val_packed_3.1", i128 addrspace(3)* %"sts_shared_addr_cast.4"
  br label %"BB_0670"
BB_0670:
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06f0"
BB_06f0:
  %"cond_trunc.8" = trunc i32 %"P34_to_i32" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_0a60", label %"BB_0700"
BB_0700:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".18", 10248
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".149" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".149" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %"iadd3_n1.5" = add i32 1024, 9216
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".150" = xor i32 %"plop3_a_bit", 1
  %".151" = xor i32 %"plop3_b_bit", 1
  %".152" = xor i32 %"plop3_c_bit", 1
  %".153" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".154" = and i32 %".153", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".154", 0
  %"P45_to_i32" = zext i1 %"plop3_pred" to i32
  %".155" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".156" = zext i32 %"iadd3_n2.5" to i64
  %".157" = zext i32 24 to i64
  %".158" = shl i64 %".155", %".157"
  %".159" = and i64 %".158", 4294967295
  %".160" = add i64 %".159", %".156"
  %".161" = trunc i64 %".160" to i32
  %".162" = zext i32 0 to i64
  %".163" = zext i32 %".161" to i64
  %".164" = shl i64 %".163", 32
  %"shf_concat.3" = or i64 %".162", %".164"
  %"shf_shift_64.3" = zext i32 4 to i64
  %".165" = lshr i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_hi" = lshr i64 %".165", 32
  %"shf_result.3" = trunc i64 %"shf_hi" to i32
  %".166" = xor i32 %"shf_result.3", -1
  %".167" = xor i32 16376, -1
  %".168" = xor i32 0, -1
  %".169" = and i32 %"shf_result.3", 16376
  %".170" = and i32 %".169", %".168"
  %".171" = and i32 %"shf_result.3", 16376
  %".172" = and i32 %".171", 0
  %".173" = or i32 %".170", %".172"
  %".174" = xor i32 %".173", -1
  %".175" = xor i32 524288, -1
  %".176" = xor i32 0, -1
  %".177" = and i32 %".174", 524288
  %".178" = and i32 %".177", %".176"
  %".179" = and i32 %".174", 524288
  %".180" = and i32 %".179", 0
  %".181" = or i32 %".178", %".180"
  %".182" = and i32 %".173", %".175"
  %".183" = and i32 %".182", %".176"
  %".184" = or i32 %".181", %".183"
  %".185" = and i32 %".173", %".175"
  %".186" = and i32 %".185", 0
  %".187" = or i32 %".184", %".186"
  %".188" = and i32 %".173", 524288
  %".189" = and i32 %".188", %".176"
  %".190" = or i32 %".187", %".189"
  %".191" = and i32 %".173", 524288
  %".192" = and i32 %".191", 0
  %".193" = or i32 %".190", %".192"
  br label %"BB_0790"
BB_0790:
  %"phi.14" = phi  i32 [%"phi.13", %"BB_0700"], [%"P39_to_i32", %"BB_07c0"]
  %"phi.15" = phi  i32 [%"P45_to_i32", %"BB_0700"], [%"phi.17", %"BB_07c0"]
  %"cond_trunc.9" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000790", label %"BB_07a0"
BB_80000790:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P36_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07a0"
BB_07a0:
  %"phi.16" = phi  i32 [%"P36_to_i32", %"BB_80000790"], [%"phi.14", %"BB_0790"]
  %"copy_dst_memaddr_offset_add" = add i32 %"lds.1", 16
  %"copy_desc_r0_ext" = zext i32 %".193" to i64
  %"copy_desc_packed_0" = or i64 0, %"copy_desc_r0_ext"
  %"copy_desc_r1_ext" = zext i32 16392 to i64
  %"copy_desc_r1_shift" = shl i64 %"copy_desc_r1_ext", 32
  %"copy_desc_packed_1" = or i64 %"copy_desc_packed_0", %"copy_desc_r1_shift"
  %".197" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".198" = sub i64 %".197", 0
  %".199" = lshr i64 %".198", 4
  %".200" = add i64 %"copy_desc_packed_1", %".199"
  %".201" = and i64 %".200", 16383
  %".202" = and i64 %"copy_desc_packed_1", -16384
  %".203" = or i64 %".202", %".201"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add", i64 %".203")
  br label %"BB_07b0"
BB_07b0:
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_800007b0", label %"BB_07c0"
BB_800007b0:
  %"lop3_a_trunc" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".207" = xor i32 %"plop3_a_bit.1", 1
  %".208" = xor i32 %"plop3_b_bit.1", 1
  %".209" = xor i32 %"plop3_c_bit.1", 1
  %".210" = and i32 %".207", %"plop3_b_bit.1"
  %".211" = and i32 %".210", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".211", 0
  %"P51_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_07c0"
BB_07c0:
  %"phi.17" = phi  i32 [%"P51_to_i32", %"BB_800007b0"], [%"phi.15", %"BB_07b0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".213" = xor i32 %"plop3_a_bit.2", 1
  %".214" = xor i32 %"plop3_b_bit.2", 1
  %".215" = xor i32 %"plop3_c_bit.2", 1
  %".216" = and i32 %".213", %"plop3_b_bit.2"
  %".217" = and i32 %".216", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".217", 0
  %"P39_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0790", label %"BB_07e0"
BB_07e0:
  %"iadd3_n1.6" = add i32 1024, 9728
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".219" = xor i32 %"plop3_a_bit.3", 1
  %".220" = xor i32 %"plop3_b_bit.3", 1
  %".221" = xor i32 %"plop3_c_bit.3", 1
  %".222" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".223" = and i32 %".222", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".223", 0
  %"P2_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".224" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".225" = zext i32 %"iadd3_n2.6" to i64
  %".226" = zext i32 24 to i64
  %".227" = shl i64 %".224", %".226"
  %".228" = and i64 %".227", 4294967295
  %".229" = add i64 %".228", %".225"
  %".230" = trunc i64 %".229" to i32
  %".231" = zext i32 0 to i64
  %".232" = zext i32 %".230" to i64
  %".233" = shl i64 %".232", 32
  %"shf_concat.4" = or i64 %".231", %".233"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".234" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi.1" = lshr i64 %".234", 32
  %"shf_result.4" = trunc i64 %"shf_hi.1" to i32
  %".235" = xor i32 %"shf_result.4", -1
  %".236" = xor i32 16376, -1
  %".237" = xor i32 0, -1
  %".238" = and i32 %"shf_result.4", 16376
  %".239" = and i32 %".238", %".237"
  %".240" = and i32 %"shf_result.4", 16376
  %".241" = and i32 %".240", 0
  %".242" = or i32 %".239", %".241"
  %".243" = xor i32 %".242", -1
  %".244" = xor i32 524288, -1
  %".245" = xor i32 0, -1
  %".246" = and i32 %".243", 524288
  %".247" = and i32 %".246", %".245"
  %".248" = and i32 %".243", 524288
  %".249" = and i32 %".248", 0
  %".250" = or i32 %".247", %".249"
  %".251" = and i32 %".242", %".244"
  %".252" = and i32 %".251", %".245"
  %".253" = or i32 %".250", %".252"
  %".254" = and i32 %".242", %".244"
  %".255" = and i32 %".254", 0
  %".256" = or i32 %".253", %".255"
  %".257" = and i32 %".242", 524288
  %".258" = and i32 %".257", %".245"
  %".259" = or i32 %".256", %".258"
  %".260" = and i32 %".242", 524288
  %".261" = and i32 %".260", 0
  %".262" = or i32 %".259", %".261"
  br label %"BB_0850"
BB_0850:
  %"phi.18" = phi  i32 [%"P39_to_i32", %"BB_07e0"], [%"P17_to_i32", %"BB_0880"]
  %"phi.19" = phi  i32 [%"P2_to_i32", %"BB_07e0"], [%"phi.21", %"BB_0880"]
  %"cond_trunc.11" = trunc i32 %"phi.19" to i1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_trunc.11" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_80000850", label %"BB_0860"
BB_80000850:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P15_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0860"
BB_0860:
  %"phi.20" = phi  i32 [%"P15_to_i32", %"BB_80000850"], [%"phi.18", %"BB_0850"]
  %"copy_dst_memaddr_offset_add.1" = add i32 %"lds.1", 20
  %"copy_desc_r0_ext.1" = zext i32 %".262" to i64
  %"copy_desc_packed_0.1" = or i64 0, %"copy_desc_r0_ext.1"
  %"copy_desc_r1_ext.1" = zext i32 16392 to i64
  %"copy_desc_r1_shift.1" = shl i64 %"copy_desc_r1_ext.1", 32
  %"copy_desc_packed_1.1" = or i64 %"copy_desc_packed_0.1", %"copy_desc_r1_shift.1"
  %".266" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".267" = sub i64 %".266", 0
  %".268" = lshr i64 %".267", 4
  %".269" = add i64 %"copy_desc_packed_1.1", %".268"
  %".270" = and i64 %".269", 16383
  %".271" = and i64 %"copy_desc_packed_1.1", -16384
  %".272" = or i64 %".271", %".270"
  call void asm sideeffect "{ { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.cp.cta_group::1.32x128b.warpx4 [$0], $1; } }", "r,l,~{memory}"(i32 %"copy_dst_memaddr_offset_add.1", i64 %".272")
  br label %"BB_0870"
BB_0870:
  %"cond_trunc.12" = trunc i32 %"phi.20" to i1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_trunc.12" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_80000870", label %"BB_0880"
BB_80000870:
  %"lop3_a_trunc.1" = trunc i32 %"phi.20" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".276" = xor i32 %"plop3_a_bit.4", 1
  %".277" = xor i32 %"plop3_b_bit.4", 1
  %".278" = xor i32 %"plop3_c_bit.4", 1
  %".279" = and i32 %".276", %"plop3_b_bit.4"
  %".280" = and i32 %".279", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".280", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0880"
BB_0880:
  %"phi.21" = phi  i32 [%"P4_to_i32", %"BB_80000870"], [%"phi.19", %"BB_0870"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".282" = xor i32 %"plop3_a_bit.5", 1
  %".283" = xor i32 %"plop3_b_bit.5", 1
  %".284" = xor i32 %"plop3_c_bit.5", 1
  %".285" = and i32 %".282", %"plop3_b_bit.5"
  %".286" = and i32 %".285", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".286", 0
  %"P17_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.21" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0850", label %"BB_08a0"
BB_08a0:
  %"iadd3_n1.7" = add i32 1024, 8192
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %"lop3_a_cast_zext.6" = zext i1 1 to i32
  %"lop3_b_cast_zext.6" = zext i1 1 to i32
  %"lop3_c_cast_zext.6" = zext i1 1 to i32
  %"plop3_a_bit.6" = and i32 %"lop3_a_cast_zext.6", 1
  %"plop3_b_bit.6" = and i32 %"lop3_b_cast_zext.6", 1
  %"plop3_c_bit.6" = and i32 %"lop3_c_cast_zext.6", 1
  %".288" = xor i32 %"plop3_a_bit.6", 1
  %".289" = xor i32 %"plop3_b_bit.6", 1
  %".290" = xor i32 %"plop3_c_bit.6", 1
  %".291" = and i32 %"plop3_a_bit.6", %"plop3_b_bit.6"
  %".292" = and i32 %".291", %"plop3_c_bit.6"
  %"plop3_pred.6" = icmp ne i32 %".292", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.6" to i32
  %".293" = zext i32 0 to i64
  %".294" = zext i32 %".18" to i64
  %".295" = shl i64 %".294", 32
  %"shf_concat.5" = or i64 %".293", %".295"
  %"shf_shift_64.5" = zext i32 4 to i64
  %".296" = lshr i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_hi.2" = lshr i64 %".296", 32
  %"shf_result.5" = trunc i64 %"shf_hi.2" to i32
  %".297" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".298" = zext i32 %"iadd3_n2.7" to i64
  %".299" = zext i32 24 to i64
  %".300" = shl i64 %".297", %".299"
  %".301" = and i64 %".300", 4294967295
  %".302" = add i64 %".301", %".298"
  %".303" = trunc i64 %".302" to i32
  %".304" = xor i32 %"shf_result.5", -1
  %".305" = xor i32 16376, -1
  %".306" = xor i32 0, -1
  %".307" = and i32 %"shf_result.5", 16376
  %".308" = and i32 %".307", %".306"
  %".309" = and i32 %"shf_result.5", 16376
  %".310" = and i32 %".309", 0
  %".311" = or i32 %".308", %".310"
  %".312" = zext i32 0 to i64
  %".313" = zext i32 %".303" to i64
  %".314" = shl i64 %".313", 32
  %"shf_concat.6" = or i64 %".312", %".314"
  %"shf_shift_64.6" = zext i32 4 to i64
  %".315" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.3" = lshr i64 %".315", 32
  %"shf_result.6" = trunc i64 %"shf_hi.3" to i32
  %"iadd3_n1.8" = add i32 %"lds.1", 16
  %"iadd3_n2.8" = add i32 %"iadd3_n1.8", 0
  %".316" = xor i32 %"shf_result.6", -1
  %".317" = xor i32 16376, -1
  %".318" = xor i32 0, -1
  %".319" = and i32 %"shf_result.6", 16376
  %".320" = and i32 %".319", %".318"
  %".321" = and i32 %"shf_result.6", 16376
  %".322" = and i32 %".321", 0
  %".323" = or i32 %".320", %".322"
  %"iadd3_n1.9" = add i32 %"lds.1", 20
  %"iadd3_n2.9" = add i32 %"iadd3_n1.9", 0
  %".324" = xor i32 %".323", -1
  %".325" = xor i32 524288, -1
  %".326" = xor i32 0, -1
  %".327" = and i32 %".324", 524288
  %".328" = and i32 %".327", %".326"
  %".329" = and i32 %".324", 524288
  %".330" = and i32 %".329", 0
  %".331" = or i32 %".328", %".330"
  %".332" = and i32 %".323", %".325"
  %".333" = and i32 %".332", %".326"
  %".334" = or i32 %".331", %".333"
  %".335" = and i32 %".323", %".325"
  %".336" = and i32 %".335", 0
  %".337" = or i32 %".334", %".336"
  %".338" = and i32 %".323", 524288
  %".339" = and i32 %".338", %".326"
  %".340" = or i32 %".337", %".339"
  %".341" = and i32 %".323", 524288
  %".342" = and i32 %".341", 0
  %".343" = or i32 %".340", %".342"
  %".344" = xor i32 %".311", -1
  %".345" = xor i32 524288, -1
  %".346" = xor i32 0, -1
  %".347" = and i32 %".344", 524288
  %".348" = and i32 %".347", %".346"
  %".349" = and i32 %".344", 524288
  %".350" = and i32 %".349", 0
  %".351" = or i32 %".348", %".350"
  %".352" = and i32 %".311", %".345"
  %".353" = and i32 %".352", %".346"
  %".354" = or i32 %".351", %".353"
  %".355" = and i32 %".311", %".345"
  %".356" = and i32 %".355", 0
  %".357" = or i32 %".354", %".356"
  %".358" = and i32 %".311", 524288
  %".359" = and i32 %".358", %".346"
  %".360" = or i32 %".357", %".359"
  %".361" = and i32 %".311", 524288
  %".362" = and i32 %".361", 0
  %".363" = or i32 %".360", %".362"
  br label %"BB_0990"
BB_0990:
  %"phi.22" = phi  i32 [%"P17_to_i32", %"BB_08a0"], [%"P22_to_i32", %"BB_09c0"]
  %"phi.23" = phi  i32 [%"P25_to_i32", %"BB_08a0"], [%"phi.25", %"BB_09c0"]
  %"cond_trunc.13" = trunc i32 %"phi.23" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000990", label %"BB_09a0"
BB_80000990:
  %"elect_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"election.3" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.3")
  %"elect_p.3" = extractvalue {i32, i1} %"election.3", 1
  %"P20_to_i32" = zext i1 %"elect_p.3" to i32
  br label %"BB_09a0"
BB_09a0:
  %"phi.24" = phi  i32 [%"P20_to_i32", %"BB_80000990"], [%"phi.22", %"BB_0990"]
  %"mma_a_r0_ext" = zext i32 %".363" to i64
  %"mma_a_packed_0" = or i64 0, %"mma_a_r0_ext"
  %"mma_a_r1_ext" = zext i32 16400 to i64
  %"mma_a_r1_shift" = shl i64 %"mma_a_r1_ext", 32
  %"mma_a_packed_1" = or i64 %"mma_a_packed_0", %"mma_a_r1_shift"
  %".367" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".368" = sub i64 %".367", 0
  %".369" = lshr i64 %".368", 4
  %".370" = add i64 %"mma_a_packed_1", %".369"
  %".371" = and i64 %".370", 16383
  %".372" = and i64 %"mma_a_packed_1", -16384
  %".373" = or i64 %".372", %".371"
  %"mma_b_r0_ext" = zext i32 %".343" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".374" = ptrtoint [11280 x i8] addrspace(3)* @"shared_mem" to i64
  %".375" = sub i64 %".374", 0
  %".376" = lshr i64 %".375", 4
  %".377" = add i64 %"mma_b_packed_1", %".376"
  %".378" = and i64 %".377", 16383
  %".379" = and i64 %"mma_b_packed_1", -16384
  %".380" = or i64 %".379", %".378"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], $1, $2, $3, [$5], [$6], use_d; } }", "r,l,l,r,r,r,r,~{memory}"(i32 %"lds.1", i64 %".373", i64 %".380", i32 679744944, i32 %"mma_arg_zext", i32 %"iadd3_n2.8", i32 %"iadd3_n2.9")
  br label %"BB_09b0"
BB_09b0:
  %"cond_trunc.14" = trunc i32 %"phi.24" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_800009b0", label %"BB_09c0"
BB_800009b0:
  %"lop3_a_trunc.2" = trunc i32 %"phi.24" to i1
  %"lop3_a_cast_zext.7" = zext i1 %"lop3_a_trunc.2" to i32
  %"lop3_b_cast_zext.7" = zext i1 1 to i32
  %"lop3_c_cast_zext.7" = zext i1 1 to i32
  %"plop3_a_bit.7" = and i32 %"lop3_a_cast_zext.7", 1
  %"plop3_b_bit.7" = and i32 %"lop3_b_cast_zext.7", 1
  %"plop3_c_bit.7" = and i32 %"lop3_c_cast_zext.7", 1
  %".384" = xor i32 %"plop3_a_bit.7", 1
  %".385" = xor i32 %"plop3_b_bit.7", 1
  %".386" = xor i32 %"plop3_c_bit.7", 1
  %".387" = and i32 %".384", %"plop3_b_bit.7"
  %".388" = and i32 %".387", %"plop3_c_bit.7"
  %"plop3_pred.7" = icmp ne i32 %".388", 0
  %"P44_to_i32" = zext i1 %"plop3_pred.7" to i32
  br label %"BB_09c0"
BB_09c0:
  %"phi.25" = phi  i32 [%"P44_to_i32", %"BB_800009b0"], [%"phi.23", %"BB_09b0"]
  %"lop3_a_cast_zext.8" = zext i1 1 to i32
  %"lop3_b_cast_zext.8" = zext i1 1 to i32
  %"lop3_c_cast_zext.8" = zext i1 1 to i32
  %"plop3_a_bit.8" = and i32 %"lop3_a_cast_zext.8", 1
  %"plop3_b_bit.8" = and i32 %"lop3_b_cast_zext.8", 1
  %"plop3_c_bit.8" = and i32 %"lop3_c_cast_zext.8", 1
  %".390" = xor i32 %"plop3_a_bit.8", 1
  %".391" = xor i32 %"plop3_b_bit.8", 1
  %".392" = xor i32 %"plop3_c_bit.8", 1
  %".393" = and i32 %".390", %"plop3_b_bit.8"
  %".394" = and i32 %".393", %"plop3_c_bit.8"
  %"plop3_pred.8" = icmp ne i32 %".394", 0
  %"P22_to_i32" = zext i1 %"plop3_pred.8" to i32
  %"bra_cond_trunc.4" = trunc i32 %"phi.25" to i1
  %"bra_cond_to_i32.4" = zext i1 %"bra_cond_trunc.4" to i32
  %"bra_cond_to_i1.4" = icmp ne i32 %"bra_cond_to_i32.4", 0
  %"branch_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.2" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.2", i1 %"bra_cond_to_i1.4")
  br i1 %"branch_any.2", label %"BB_0990", label %"BB_09e0"
BB_09e0:
  %"iadd3_n1.10" = add i32 1024, 10240
  %"iadd3_n2.10" = add i32 %"iadd3_n1.10", 0
  %"lop3_a_cast_zext.9" = zext i1 1 to i32
  %"lop3_b_cast_zext.9" = zext i1 1 to i32
  %"lop3_c_cast_zext.9" = zext i1 1 to i32
  %"plop3_a_bit.9" = and i32 %"lop3_a_cast_zext.9", 1
  %"plop3_b_bit.9" = and i32 %"lop3_b_cast_zext.9", 1
  %"plop3_c_bit.9" = and i32 %"lop3_c_cast_zext.9", 1
  %".396" = xor i32 %"plop3_a_bit.9", 1
  %".397" = xor i32 %"plop3_b_bit.9", 1
  %".398" = xor i32 %"plop3_c_bit.9", 1
  %".399" = and i32 %"plop3_a_bit.9", %"plop3_b_bit.9"
  %".400" = and i32 %".399", %"plop3_c_bit.9"
  %"plop3_pred.9" = icmp ne i32 %".400", 0
  %"P47_to_i32" = zext i1 %"plop3_pred.9" to i32
  %".401" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".402" = zext i32 %"iadd3_n2.10" to i64
  %".403" = zext i32 24 to i64
  %".404" = shl i64 %".401", %".403"
  %".405" = and i64 %".404", 4294967295
  %".406" = add i64 %".405", %".402"
  %".407" = trunc i64 %".406" to i32
  br label %"BB_0a10"
BB_0a10:
  %"phi.26" = phi  i32 [%"P22_to_i32", %"BB_09e0"], [%"P29_to_i32", %"BB_0a40"]
  %"phi.27" = phi  i32 [%"P47_to_i32", %"BB_09e0"], [%"phi.29", %"BB_0a40"]
  %"cond_trunc.15" = trunc i32 %"phi.27" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_80000a10", label %"BB_0a20"
BB_80000a10:
  %"elect_mask.4" = call i32 @"llvm.nvvm.activemask"()
  %"election.4" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.4")
  %"elect_p.4" = extractvalue {i32, i1} %"election.4", 1
  %"P26_to_i32" = zext i1 %"elect_p.4" to i32
  br label %"BB_0a20"
BB_0a20:
  %"phi.28" = phi  i32 [%"P26_to_i32", %"BB_80000a10"], [%"phi.26", %"BB_0a10"]
  %"utcbar_local_winoff" = and i32 %".407", 16777215
  %".411" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".412" = ptrtoint i8 addrspace(3)* %".411" to i32
  %".413" = lshr i32 %".407", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".412", i32 %".413")
  br label %"BB_0a30"
BB_0a30:
  %"cond_trunc.16" = trunc i32 %"phi.28" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000a30", label %"BB_0a40"
BB_80000a30:
  %"lop3_a_trunc.3" = trunc i32 %"phi.28" to i1
  %"lop3_a_cast_zext.10" = zext i1 %"lop3_a_trunc.3" to i32
  %"lop3_b_cast_zext.10" = zext i1 1 to i32
  %"lop3_c_cast_zext.10" = zext i1 1 to i32
  %"plop3_a_bit.10" = and i32 %"lop3_a_cast_zext.10", 1
  %"plop3_b_bit.10" = and i32 %"lop3_b_cast_zext.10", 1
  %"plop3_c_bit.10" = and i32 %"lop3_c_cast_zext.10", 1
  %".417" = xor i32 %"plop3_a_bit.10", 1
  %".418" = xor i32 %"plop3_b_bit.10", 1
  %".419" = xor i32 %"plop3_c_bit.10", 1
  %".420" = and i32 %".417", %"plop3_b_bit.10"
  %".421" = and i32 %".420", %"plop3_c_bit.10"
  %"plop3_pred.10" = icmp ne i32 %".421", 0
  %"P8_to_i32" = zext i1 %"plop3_pred.10" to i32
  br label %"BB_0a40"
BB_0a40:
  %"phi.29" = phi  i32 [%"P8_to_i32", %"BB_80000a30"], [%"phi.27", %"BB_0a30"]
  %"lop3_a_cast_zext.11" = zext i1 1 to i32
  %"lop3_b_cast_zext.11" = zext i1 1 to i32
  %"lop3_c_cast_zext.11" = zext i1 1 to i32
  %"plop3_a_bit.11" = and i32 %"lop3_a_cast_zext.11", 1
  %"plop3_b_bit.11" = and i32 %"lop3_b_cast_zext.11", 1
  %"plop3_c_bit.11" = and i32 %"lop3_c_cast_zext.11", 1
  %".423" = xor i32 %"plop3_a_bit.11", 1
  %".424" = xor i32 %"plop3_b_bit.11", 1
  %".425" = xor i32 %"plop3_c_bit.11", 1
  %".426" = and i32 %".423", %"plop3_b_bit.11"
  %".427" = and i32 %".426", %"plop3_c_bit.11"
  %"plop3_pred.11" = icmp ne i32 %".427", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.11" to i32
  %"bra_cond_trunc.5" = trunc i32 %"phi.29" to i1
  %"bra_cond_to_i32.5" = zext i1 %"bra_cond_trunc.5" to i32
  %"bra_cond_to_i1.5" = icmp ne i32 %"bra_cond_to_i32.5", 0
  %"branch_mask.3" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.3" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.3", i1 %"bra_cond_to_i1.5")
  br i1 %"branch_any.3", label %"BB_0a10", label %"BB_0a60"
BB_0a60:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.11" = add i32 1024, 10240
  %"iadd3_n2.11" = add i32 %"iadd3_n1.11", 0
  %".429" = zext i32 0 to i64
  %".430" = zext i32 0 to i64
  %".431" = shl i64 %".430", 32
  %"shf_concat.7" = or i64 %".429", %".431"
  %"shf_shift_64.7" = zext i32 31 to i64
  %".432" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".432" to i32
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %".433" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".434" = zext i32 %"iadd3_n2.11" to i64
  %".435" = zext i32 24 to i64
  %".436" = shl i64 %".433", %".435"
  %".437" = and i64 %".436", 4294967295
  %".438" = add i64 %".437", %".434"
  %".439" = trunc i64 %".438" to i32
  %".440" = xor i32 %"imad.10", -1
  %".441" = xor i32 65011712, -1
  %".442" = xor i32 0, -1
  %".443" = and i32 %"imad.10", 65011712
  %".444" = and i32 %".443", %".442"
  %".445" = and i32 %"imad.10", 65011712
  %".446" = and i32 %".445", 0
  %".447" = or i32 %".444", %".446"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".447"
  %"mbar_shared_winoff.1" = and i32 %".439", 16777215
  %".448" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".448" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.7", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P48_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0b00"
BB_0b00:
  %"cond_trunc.17" = trunc i32 %"P48_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.17", -1
  %"pbra_cond_to_i32.17" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.17" = icmp ne i32 %"pbra_cond_to_i32.17", 0
  br i1 %"pbra_cond_to_i1.17", label %"BB_0f50", label %"BB_0b10"
BB_0f50:
  %"mbar_shared_winoff.2" = and i32 %".439", 16777215
  %".451" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".451" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.7", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P49_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0f60"
BB_0f60:
  %"cond_trunc.18" = trunc i32 %"P49_to_i32" to i1
  %"cond_not.6" = xor i1 %"cond_trunc.18", -1
  %"pbra_cond_to_i32.18" = zext i1 %"cond_not.6" to i32
  %"pbra_cond_to_i1.18" = icmp ne i32 %"pbra_cond_to_i32.18", 0
  br i1 %"pbra_cond_to_i1.18", label %"BB_0f50", label %"BB_0b10"
BB_0b10:
  %".454" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".455" = bitcast i8* %".454" to i64*
  %"ldc_const.1" = load i64, i64* %".455"
  %"R3:R2_r0.2" = trunc i64 %"ldc_const.1" to i32
  %"R3:R2_r1_shift.2" = lshr i64 %"ldc_const.1", 32
  %"R3:R2_r1.2" = trunc i64 %"R3:R2_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".456" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".457" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".458" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".459" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".460" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".461" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".462" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".463" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R3:R2_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R3:R2_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0.3" = trunc i64 %"imad.13" to i32
  %"R3:R2_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R3:R2_r1.3" = trunc i64 %"R3:R2_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R105:R96_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".456", i32 addrspace(1)* %"R105:R96_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R105:R96_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".457", i32 addrspace(1)* %"R105:R96_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R105:R96_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".458", i32 addrspace(1)* %"R105:R96_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R105:R96_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".459", i32 addrspace(1)* %"R105:R96_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R105:R96_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".460", i32 addrspace(1)* %"R105:R96_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".469" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".470" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".471" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".472" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R105:R96_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".461", i32 addrspace(1)* %"R105:R96_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R105:R96_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".462", i32 addrspace(1)* %"R105:R96_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R105:R96_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".463", i32 addrspace(1)* %"R105:R96_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".476" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".477" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".478" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".479" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R105:R96_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".469", i32 addrspace(1)* %"R105:R96_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R105:R96_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".470", i32 addrspace(1)* %"R105:R96_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R105:R96_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".471", i32 addrspace(1)* %"R105:R96_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R105:R96_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".472", i32 addrspace(1)* %"R105:R96_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R105:R96_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".476", i32 addrspace(1)* %"R105:R96_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R105:R96_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".477", i32 addrspace(1)* %"R105:R96_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R105:R96_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".478", i32 addrspace(1)* %"R105:R96_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R105:R96_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".479", i32 addrspace(1)* %"R105:R96_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0d00"
BB_0d00:
  %"cond_trunc.19" = trunc i32 %"P10_to_i32" to i1
  %"pbra_cond_to_i32.19" = zext i1 %"cond_trunc.19" to i32
  %"pbra_cond_to_i1.19" = icmp ne i32 %"pbra_cond_to_i32.19", 0
  br i1 %"pbra_cond_to_i1.19", label %"BB_80000d00", label %"BB_0d10"
BB_0d10:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".18", 10248
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".490" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".490" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 1
  %".491" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".492" = zext i32 64 to i64
  %".493" = zext i32 24 to i64
  %".494" = shl i64 %".491", %".493"
  %".495" = and i64 %".494", 4294967295
  %".496" = add i64 %".495", %".492"
  %".497" = trunc i64 %".496" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".497", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".498" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".498" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".499" = xor i32 %"lds.2", -1
  %".500" = xor i32 65535, -1
  %".501" = xor i32 0, -1
  %".502" = and i32 %"lds.2", 65535
  %".503" = and i32 %".502", %".501"
  %".504" = and i32 %"lds.2", 65535
  %".505" = and i32 %".504", 0
  %".506" = or i32 %".503", %".505"
  %".507" = zext i32 0 to i64
  %".508" = zext i32 %".506" to i64
  %".509" = shl i64 %".508", 32
  %"shf_concat.8" = or i64 %".507", %".509"
  %"shf_shift_64.8" = zext i32 5 to i64
  %".510" = lshr i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_hi.4" = lshr i64 %".510", 32
  %"shf_result.8" = trunc i64 %"shf_hi.4" to i32
  %".511" = zext i32 %"imad.14" to i64
  %".512" = zext i32 0 to i64
  %".513" = shl i64 %".512", 32
  %"shf_concat.9" = or i64 %".511", %".513"
  %"shf_shift_64.9" = zext i32 %"shf_result.8" to i64
  %".514" = shl i64 %"shf_concat.9", %"shf_shift_64.9"
  %"shf_result.9" = trunc i64 %".514" to i32
  %".515" = xor i32 %"lds.3", -1
  %".516" = xor i32 %"shf_result.9", -1
  %".517" = xor i32 0, -1
  %".518" = and i32 %"lds.3", %"shf_result.9"
  %".519" = and i32 %".518", %".517"
  %".520" = and i32 %"lds.3", %"shf_result.9"
  %".521" = and i32 %".520", 0
  %".522" = or i32 %".519", %".521"
  %"isetrp_cmp1.5" = icmp ne i32 %".522", %"shf_result.9"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0dc0"
BB_0dc0:
  %"cond_trunc.20" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.20" = zext i1 %"cond_trunc.20" to i32
  %"pbra_cond_to_i1.20" = icmp ne i32 %"pbra_cond_to_i32.20", 0
  br i1 %"pbra_cond_to_i1.20", label %"BB_0f20_0fb0", label %"BB_0dd0"
BB_0dd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".497", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".525" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".525" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".526" = xor i32 %"lds.4", -1
  %".527" = xor i32 %"shf_result.9", -1
  %".528" = xor i32 0, -1
  %".529" = and i32 %"lds.4", %"shf_result.9"
  %".530" = and i32 %".529", %".528"
  %".531" = and i32 %"lds.4", %"shf_result.9"
  %".532" = and i32 %".531", 0
  %".533" = or i32 %".530", %".532"
  %"isetrp_cmp1.6" = icmp ne i32 %".533", %"shf_result.9"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P12_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  br label %"BB_0e00"
BB_0e00:
  %"cond_trunc.21" = trunc i32 %"P12_to_i32" to i1
  %"pbra_cond_to_i32.21" = zext i1 %"cond_trunc.21" to i32
  %"pbra_cond_to_i1.21" = icmp ne i32 %"pbra_cond_to_i32.21", 0
  br i1 %"pbra_cond_to_i1.21", label %"BB_0ef0_0f80", label %"BB_0e10"
BB_0e10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %".536" = xor i32 0, -1
  %".537" = xor i32 %"shf_result.9", -1
  %".538" = xor i32 0, -1
  %".539" = and i32 %".536", %".537"
  %".540" = and i32 %".539", %".538"
  %".541" = and i32 %".536", %".537"
  %".542" = and i32 %".541", 0
  %".543" = or i32 %".540", %".542"
  %".544" = and i32 0, %".537"
  %".545" = and i32 %".544", %".538"
  %".546" = or i32 %".543", %".545"
  %".547" = and i32 0, %".537"
  %".548" = and i32 %".547", 0
  %".549" = or i32 %".546", %".548"
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", %".549"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.15", i32 %"redux_mask")
  %".550" = xor i32 %".549", -1
  %".551" = call i32 @"llvm.cttz.i32"(i32 %".550", i1 0)
  %".552" = shl i32 %".551", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 32;", "r,~{memory}"(i32 %".552") convergent
  %"isetrp_cmp1.7" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.7" = zext i1 1 to i32
  %"isetrp_src_to_i1.7" = icmp ne i32 %"isetrp_src_to_i32.7", 0
  %"isetrp_cmp2.7" = and i1 %"isetrp_cmp1.7", %"isetrp_src_to_i1.7"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2.7" to i32
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %"redux_sync_and"
  br label %"BB_0eb0"
BB_0eb0:
  %"cond_trunc.22" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32.22" = zext i1 %"cond_trunc.22" to i32
  %"pbra_cond_to_i1.22" = icmp ne i32 %"pbra_cond_to_i32.22", 0
  br i1 %"pbra_cond_to_i1.22", label %"BB_80000eb0", label %"BB_0f30"
BB_80000eb0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".497", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".556" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".556" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.16" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".497", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".557" = getelementptr inbounds [11280 x i8], [11280 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".557" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.16" monotonic
  br label %"BB_0f30"
BB_0ef0_0f80:
  call void @"llvm.trap"()
  br label %"BB_0f30"
BB_0f20_0fb0:
  call void @"llvm.trap"()
  br label %"BB_0f30"
BB_0f30:
  ret void
BB_80000d00:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case5EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case2EEvPKjPj", !"kernel", i32 1 }
