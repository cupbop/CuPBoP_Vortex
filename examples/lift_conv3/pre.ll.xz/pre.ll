; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../sweep_sb1/lifted/conv3_sm90_lifted.ll'
source_filename = "/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/../sweep_sb1/lifted/conv3_sm90_lifted.ll"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16
@const_mem = global [5 x [560 x i8]] zeroinitializer, align 16

define void @_Z5conv3PfPKfS1_ii(i64 %arg_528, i64 %arg_536, i64 %arg_544, i32 %arg_552, i32 %arg_556) {
EntryBB_0000:
  %param_local = alloca [560 x i8], align 16
  %.7 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 528
  store i64 %arg_528, ptr %.7, align 16
  %.10 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 536
  store i64 %arg_536, ptr %.10, align 8
  %.13 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 544
  store i64 %arg_544, ptr %.13, align 32
  %.16 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 552
  store i32 %arg_552, ptr %.16, align 8
  %.19 = getelementptr inbounds [560 x i8], ptr %param_local, i64 0, i64 556
  store i32 %arg_556, ptr %.19, align 4
  %ctaid_y = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %ntid_x = call i32 @llvm.nvvm.read.ptx.sreg.ntid.x()
  %tid_y = call i32 @llvm.nvvm.read.ptx.sreg.tid.y()
  %ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %ntid_y = call i32 @llvm.nvvm.read.ptx.sreg.ntid.y()
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %ldc_const = load i64, ptr %.16, align 8
  %"R3:R2_r0" = trunc i64 %ldc_const to i32
  %"R3:R2_r1_shift" = lshr i64 %ldc_const, 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %imad_tmp = mul i32 %ctaid_y, %ntid_y
  %imad = add i32 %imad_tmp, %tid_y
  %isetrp_cmp1 = icmp sge i32 %imad, %"R3:R2_r1"
  %imad_tmp.1 = mul i32 %ctaid_x, %ntid_x
  %imad.1 = add i32 %imad_tmp.1, %tid_x
  %isetrp_cmp1.1 = icmp sge i32 %imad.1, %"R3:R2_r0"
  %isetrp_cmp2.1 = or i1 %isetrp_cmp1.1, %isetrp_cmp1
  br label %BB_00c0

BB_00c0:                                          ; preds = %EntryBB_0000
  %0 = zext i1 %isetrp_cmp2.1 to i32
  %1 = icmp ne i32 %0, 0
  br i1 %1, label %BB_800000c0, label %BB_00d0

BB_00d0:                                          ; preds = %BB_00c0
  %ldc_const.1 = load i64, ptr %.10, align 8
  %iadd3_n1 = add i32 %"R3:R2_r0", 2
  %imad_tmp.2 = mul i32 %imad, %iadd3_n1
  %imad.2 = add i32 %imad_tmp.2, %imad.1
  %ldc_const.2 = load i64, ptr %.13, align 8
  %imad_lhs_64 = sext i32 %imad.2 to i64
  %imad_tmp_64 = mul i64 %imad_lhs_64, 4
  %2 = add i64 %imad_tmp_64, %ldc_const.1
  %"R17:R13_addr_ptr" = inttoptr i64 %2 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R17:R13_addr_ptr", align 4
  %"R28:R25_addr_ptr" = inttoptr i64 %ldc_const.2 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R28:R25_addr_ptr", align 4
  %imad_lhs_64.1 = sext i32 %"R3:R2_r0" to i64
  %imad_tmp_64.1 = mul i64 %imad_lhs_64.1, 4
  %3 = add i64 %imad_tmp_64.1, %2
  %ldg_addr_memaddr_offset_add = add i64 %ldc_const.2, 4
  %"R28:R25_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.1", align 4
  %ldg_addr_memaddr_offset_add.1 = add i64 %2, 4
  %"R17:R13_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add.1 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R17:R13_addr_ptr.1", align 4
  %ldg_addr_memaddr_offset_add.2 = add i64 %2, 8
  %"R17:R13_addr_ptr.2" = inttoptr i64 %ldg_addr_memaddr_offset_add.2 to ptr addrspace(1)
  %ldg.4 = load float, ptr addrspace(1) %"R17:R13_addr_ptr.2", align 4
  %ldg_addr_memaddr_offset_add.3 = add i64 %ldc_const.2, 8
  %"R28:R25_addr_ptr.2" = inttoptr i64 %ldg_addr_memaddr_offset_add.3 to ptr addrspace(1)
  %ldg.5 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.2", align 4
  %ldg_addr_memaddr_offset_add.4 = add i64 %ldc_const.2, 12
  %"R28:R25_addr_ptr.3" = inttoptr i64 %ldg_addr_memaddr_offset_add.4 to ptr addrspace(1)
  %ldg.6 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.3", align 4
  %ldg_addr_memaddr_offset_add.5 = add i64 %3, 8
  %"R32:R29_addr_ptr" = inttoptr i64 %ldg_addr_memaddr_offset_add.5 to ptr addrspace(1)
  %ldg.7 = load float, ptr addrspace(1) %"R32:R29_addr_ptr", align 4
  %4 = add i64 %imad_tmp_64.1, %3
  %ldg_addr_memaddr_offset_add.6 = add i64 %ldc_const.2, 16
  %"R28:R25_addr_ptr.4" = inttoptr i64 %ldg_addr_memaddr_offset_add.6 to ptr addrspace(1)
  %ldg.8 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.4", align 4
  %ldg_addr_memaddr_offset_add.7 = add i64 %3, 12
  %"R32:R29_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add.7 to ptr addrspace(1)
  %ldg.9 = load float, ptr addrspace(1) %"R32:R29_addr_ptr.1", align 4
  %ldg_addr_memaddr_offset_add.8 = add i64 %3, 16
  %"R32:R29_addr_ptr.2" = inttoptr i64 %ldg_addr_memaddr_offset_add.8 to ptr addrspace(1)
  %ldg.10 = load float, ptr addrspace(1) %"R32:R29_addr_ptr.2", align 4
  %ldg_addr_memaddr_offset_add.9 = add i64 %ldc_const.2, 20
  %"R28:R25_addr_ptr.5" = inttoptr i64 %ldg_addr_memaddr_offset_add.9 to ptr addrspace(1)
  %ldg.11 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.5", align 4
  %ldg_addr_memaddr_offset_add.10 = add i64 %ldc_const.2, 24
  %"R28:R25_addr_ptr.6" = inttoptr i64 %ldg_addr_memaddr_offset_add.10 to ptr addrspace(1)
  %ldg.12 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.6", align 4
  %ldc_const.3 = load i64, ptr %.7, align 8
  %ldg_addr_memaddr_offset_add.11 = add i64 %4, 16
  %"R38:R37_addr_ptr" = inttoptr i64 %ldg_addr_memaddr_offset_add.11 to ptr addrspace(1)
  %ldg.13 = load float, ptr addrspace(1) %"R38:R37_addr_ptr", align 4
  %ldg_addr_memaddr_offset_add.12 = add i64 %ldc_const.2, 28
  %"R28:R25_addr_ptr.7" = inttoptr i64 %ldg_addr_memaddr_offset_add.12 to ptr addrspace(1)
  %ldg.14 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.7", align 4
  %ldg_addr_memaddr_offset_add.13 = add i64 %4, 20
  %"R38:R37_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add.13 to ptr addrspace(1)
  %ldg.15 = load float, ptr addrspace(1) %"R38:R37_addr_ptr.1", align 4
  %ldg_addr_memaddr_offset_add.14 = add i64 %4, 24
  %"R38:R37_addr_ptr.2" = inttoptr i64 %ldg_addr_memaddr_offset_add.14 to ptr addrspace(1)
  %ldg.16 = load float, ptr addrspace(1) %"R38:R37_addr_ptr.2", align 4
  %ldg_addr_memaddr_offset_add.15 = add i64 %ldc_const.2, 32
  %"R28:R25_addr_ptr.8" = inttoptr i64 %ldg_addr_memaddr_offset_add.15 to ptr addrspace(1)
  %ldg.17 = load float, ptr addrspace(1) %"R28:R25_addr_ptr.8", align 4
  %imad_tmp.3 = mul i32 %imad, %"R3:R2_r0"
  %imad.6 = add i32 %imad_tmp.3, %imad.1
  %imad_lhs_64.3 = sext i32 %imad.6 to i64
  %imad_tmp_64.3 = mul i64 %imad_lhs_64.3, 4
  %5 = add i64 %imad_tmp_64.3, %ldc_const.3
  %ffma = call float @llvm.fma.f32(float %ldg.1, float %ldg, float 0.000000e+00)
  %ffma.1 = call float @llvm.fma.f32(float %ldg.2, float %ldg.3, float %ffma)
  %ffma.2 = call float @llvm.fma.f32(float %ldg.5, float %ldg.4, float %ffma.1)
  %ffma.3 = call float @llvm.fma.f32(float %ldg.6, float %ldg.7, float %ffma.2)
  %ffma.4 = call float @llvm.fma.f32(float %ldg.8, float %ldg.9, float %ffma.3)
  %ffma.5 = call float @llvm.fma.f32(float %ldg.11, float %ldg.10, float %ffma.4)
  %ffma.6 = call float @llvm.fma.f32(float %ldg.12, float %ldg.13, float %ffma.5)
  %ffma.7 = call float @llvm.fma.f32(float %ldg.14, float %ldg.15, float %ffma.6)
  %ffma.8 = call float @llvm.fma.f32(float %ldg.17, float %ldg.16, float %ffma.7)
  %"R36:R31_addr_ptr" = inttoptr i64 %5 to ptr addrspace(1)
  store float %ffma.8, ptr addrspace(1) %"R36:R31_addr_ptr", align 4
  ret void

BB_800000c0:                                      ; preds = %BB_00c0
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.y() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #0

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!nvvmir.version = !{!0}
!nvvm.annotations = !{!1}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z5conv3PfPKfS1_ii, !"kernel", i32 1}
