; ModuleID = "/net/netscratch/cahn45/Vortex_Agent/experiments/sweep_sb1/lifted/conv3_sm90_lifted"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [32768 x i8], align 16
define void @"_Z5conv3PfPKfS1_ii"(i64 %"arg_528", i64 %"arg_536", i64 %"arg_544", i32 %"arg_552", i32 %"arg_556")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [560 x i8], align 16
  %".7" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 528
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_528", i64* %".8", align 16
  %".10" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 536
  %".11" = bitcast i8* %".10" to i64*
  store i64 %"arg_536", i64* %".11", align 8
  %".13" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 544
  %".14" = bitcast i8* %".13" to i64*
  store i64 %"arg_544", i64* %".14", align 32
  %".16" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 552
  %".17" = bitcast i8* %".16" to i32*
  store i32 %"arg_552", i32* %".17", align 8
  %".19" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 556
  %".20" = bitcast i8* %".19" to i32*
  store i32 %"arg_556", i32* %".20", align 4
  %"ctaid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()
  %"ntid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ntid.x"()
  %"tid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()
  %"ctaid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()
  %"ntid_y" = call i32 @"llvm.nvvm.read.ptx.sreg.ntid.y"()
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %".22" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 552
  %".23" = bitcast i8* %".22" to i64*
  %"ldc_const" = load i64, i64* %".23"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"imad_tmp" = mul i32 %"ctaid_y", %"ntid_y"
  %"imad" = add i32 %"imad_tmp", %"tid_y"
  %"isetrp_cmp1" = icmp sge i32 %"imad", %"R3:R2_r1"
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"imad_tmp.1" = mul i32 %"ctaid_x", %"ntid_x"
  %"imad.1" = add i32 %"imad_tmp.1", %"tid_x"
  %"isetrp_src_trunc" = trunc i32 %"P1_to_i32" to i1
  %"isetrp_cmp1.1" = icmp sge i32 %"imad.1", %"R3:R2_r0"
  %"isetrp_src_to_i32.1" = zext i1 %"isetrp_src_trunc" to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = or i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P2_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_00c0"
BB_00c0:
  %"cond_trunc" = trunc i32 %"P2_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_800000c0", label %"BB_00d0"
BB_00d0:
  %".26" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 536
  %".27" = bitcast i8* %".26" to i64*
  %"ldc_const.1" = load i64, i64* %".27"
  %"R27:R26_r0" = trunc i64 %"ldc_const.1" to i32
  %"R27:R26_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R27:R26_r1" = trunc i64 %"R27:R26_r1_shift" to i32
  %"iadd3_n1" = add i32 %"R3:R2_r0", 2
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"imad_tmp.2" = mul i32 %"imad", %"iadd3_n2"
  %"imad.2" = add i32 %"imad_tmp.2", %"imad.1"
  %".28" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 544
  %".29" = bitcast i8* %".28" to i64*
  %"ldc_const.2" = load i64, i64* %".29"
  %"R5:R4_r0" = trunc i64 %"ldc_const.2" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %"imad_addend_r0_ext" = zext i32 %"R27:R26_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R27:R26_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = sext i32 %"imad.2" to i64
  %"imad_rhs_64" = sext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad.3" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R27:R26_r0.1" = trunc i64 %"imad.3" to i32
  %"R27:R26_r1_shift.1" = lshr i64 %"imad.3", 32
  %"R27:R26_r1.1" = trunc i64 %"R27:R26_r1_shift.1" to i32
  %"ldg_addr_r0_ext" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R17:R13_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to float addrspace(1)*
  %"ldg" = load float, float addrspace(1)* %"R17:R13_addr_ptr"
  %"ldg_addr_r0_ext.1" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"R28:R25_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1.1" to float addrspace(1)*
  %"ldg.1" = load float, float addrspace(1)* %"R28:R25_addr_ptr"
  %"imad_addend_r0_ext.1" = zext i32 %"R27:R26_r0.1" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R27:R26_r1.1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = sext i32 %"R3:R2_r0" to i64
  %"imad_rhs_64.1" = sext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.4" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R7:R6_r0" = trunc i64 %"imad.4" to i32
  %"R7:R6_r1_shift" = lshr i64 %"imad.4", 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %"ldg_addr_r0_ext.2" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.2", 4
  %"R28:R25_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to float addrspace(1)*
  %"ldg.2" = load float, float addrspace(1)* %"R28:R25_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.3", 4
  %"R17:R13_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to float addrspace(1)*
  %"ldg.3" = load float, float addrspace(1)* %"R17:R13_addr_ptr.1"
  %"ldg_addr_r0_ext.4" = zext i32 %"R27:R26_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R27:R26_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.4", 8
  %"R17:R13_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to float addrspace(1)*
  %"ldg.4" = load float, float addrspace(1)* %"R17:R13_addr_ptr.2"
  %"ldg_addr_r0_ext.5" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.5", 8
  %"R28:R25_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to float addrspace(1)*
  %"ldg.5" = load float, float addrspace(1)* %"R28:R25_addr_ptr.2"
  %"ldg_addr_r0_ext.6" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.6", 12
  %"R28:R25_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to float addrspace(1)*
  %"ldg.6" = load float, float addrspace(1)* %"R28:R25_addr_ptr.3"
  %"ldg_addr_r0_ext.7" = zext i32 %"R7:R6_r0" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R7:R6_r1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.7", 8
  %"R32:R29_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to float addrspace(1)*
  %"ldg.7" = load float, float addrspace(1)* %"R32:R29_addr_ptr"
  %"imad_addend_r0_ext.2" = zext i32 %"R7:R6_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R7:R6_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = sext i32 %"R3:R2_r0" to i64
  %"imad_rhs_64.2" = sext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.5" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R9:R8_r0" = trunc i64 %"imad.5" to i32
  %"R9:R8_r1_shift" = lshr i64 %"imad.5", 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %"ldg_addr_r0_ext.8" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.8", 16
  %"R28:R25_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to float addrspace(1)*
  %"ldg.8" = load float, float addrspace(1)* %"R28:R25_addr_ptr.4"
  %"ldg_addr_r0_ext.9" = zext i32 %"R7:R6_r0" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R7:R6_r1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.9", 12
  %"R32:R29_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to float addrspace(1)*
  %"ldg.9" = load float, float addrspace(1)* %"R32:R29_addr_ptr.1"
  %"ldg_addr_r0_ext.10" = zext i32 %"R7:R6_r0" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R7:R6_r1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.10", 16
  %"R32:R29_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to float addrspace(1)*
  %"ldg.10" = load float, float addrspace(1)* %"R32:R29_addr_ptr.2"
  %"ldg_addr_r0_ext.11" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.11", 20
  %"R28:R25_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to float addrspace(1)*
  %"ldg.11" = load float, float addrspace(1)* %"R28:R25_addr_ptr.5"
  %"ldg_addr_r0_ext.12" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.12", 24
  %"R28:R25_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to float addrspace(1)*
  %"ldg.12" = load float, float addrspace(1)* %"R28:R25_addr_ptr.6"
  %".30" = getelementptr inbounds [560 x i8], [560 x i8]* %"param_local", i64 0, i64 528
  %".31" = bitcast i8* %".30" to i64*
  %"ldc_const.3" = load i64, i64* %".31"
  %"R7:R6_r0.1" = trunc i64 %"ldc_const.3" to i32
  %"R7:R6_r1_shift.1" = lshr i64 %"ldc_const.3", 32
  %"R7:R6_r1.1" = trunc i64 %"R7:R6_r1_shift.1" to i32
  %"ldg_addr_r0_ext.13" = zext i32 %"R9:R8_r0" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R9:R8_r1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.13", 16
  %"R38:R37_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to float addrspace(1)*
  %"ldg.13" = load float, float addrspace(1)* %"R38:R37_addr_ptr"
  %"ldg_addr_r0_ext.14" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.14", 28
  %"R28:R25_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to float addrspace(1)*
  %"ldg.14" = load float, float addrspace(1)* %"R28:R25_addr_ptr.7"
  %"ldg_addr_r0_ext.15" = zext i32 %"R9:R8_r0" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R9:R8_r1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.15", 20
  %"R38:R37_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to float addrspace(1)*
  %"ldg.15" = load float, float addrspace(1)* %"R38:R37_addr_ptr.1"
  %"ldg_addr_r0_ext.16" = zext i32 %"R9:R8_r0" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R9:R8_r1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.16", 24
  %"R38:R37_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to float addrspace(1)*
  %"ldg.16" = load float, float addrspace(1)* %"R38:R37_addr_ptr.2"
  %"ldg_addr_r0_ext.17" = zext i32 %"R5:R4_r0" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R5:R4_r1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.17", 32
  %"R28:R25_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to float addrspace(1)*
  %"ldg.17" = load float, float addrspace(1)* %"R28:R25_addr_ptr.8"
  %"imad_tmp.3" = mul i32 %"imad", %"R3:R2_r0"
  %"imad.6" = add i32 %"imad_tmp.3", %"imad.1"
  %"imad_addend_r0_ext.3" = zext i32 %"R7:R6_r0.1" to i64
  %"imad_addend_packed_0.3" = or i64 0, %"imad_addend_r0_ext.3"
  %"imad_addend_r1_ext.3" = zext i32 %"R7:R6_r1.1" to i64
  %"imad_addend_r1_shift.3" = shl i64 %"imad_addend_r1_ext.3", 32
  %"imad_addend_packed_1.3" = or i64 %"imad_addend_packed_0.3", %"imad_addend_r1_shift.3"
  %"imad_lhs_64.3" = sext i32 %"imad.6" to i64
  %"imad_rhs_64.3" = sext i32 4 to i64
  %"imad_tmp_64.3" = mul i64 %"imad_lhs_64.3", %"imad_rhs_64.3"
  %"imad.7" = add i64 %"imad_tmp_64.3", %"imad_addend_packed_1.3"
  %"R7:R6_r0.2" = trunc i64 %"imad.7" to i32
  %"R7:R6_r1_shift.2" = lshr i64 %"imad.7", 32
  %"R7:R6_r1.2" = trunc i64 %"R7:R6_r1_shift.2" to i32
  %"ffma" = call float @"llvm.fma.f32"(float %"ldg.1", float %"ldg", float              0x0)
  %"ffma.1" = call float @"llvm.fma.f32"(float %"ldg.2", float %"ldg.3", float %"ffma")
  %"ffma.2" = call float @"llvm.fma.f32"(float %"ldg.5", float %"ldg.4", float %"ffma.1")
  %"ffma.3" = call float @"llvm.fma.f32"(float %"ldg.6", float %"ldg.7", float %"ffma.2")
  %"ffma.4" = call float @"llvm.fma.f32"(float %"ldg.8", float %"ldg.9", float %"ffma.3")
  %"ffma.5" = call float @"llvm.fma.f32"(float %"ldg.11", float %"ldg.10", float %"ffma.4")
  %"ffma.6" = call float @"llvm.fma.f32"(float %"ldg.12", float %"ldg.13", float %"ffma.5")
  %"ffma.7" = call float @"llvm.fma.f32"(float %"ldg.14", float %"ldg.15", float %"ffma.6")
  %"ffma.8" = call float @"llvm.fma.f32"(float %"ldg.17", float %"ldg.16", float %"ffma.7")
  %"stg_addr_r0_ext" = zext i32 %"R7:R6_r0.2" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R7:R6_r1.2" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R36:R31_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to float addrspace(1)*
  store float %"ffma.8", float addrspace(1)* %"R36:R31_addr_ptr"
  ret void
BB_800000c0:
  ret void
}

@"const_mem" = global [5 x [560 x i8]] [[560 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [560 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [560 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [560 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [560 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ntid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ctaid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.ntid.y"()

declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare float @"llvm.fma.f32"(float %".1", float %".2", float %".3")

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64, i64, i32, i32)* @"_Z5conv3PfPKfS1_ii", !"kernel", i32 1 }
