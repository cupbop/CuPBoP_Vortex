; ModuleID = 'llvm-link'
source_filename = "llvm-link"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16

define void @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_([56 x i8] %arg_528) {
EntryBB_0000:
  %local_mem = alloca [32768 x i8], align 16
  %param_local = alloca [592 x i8], align 16
  %.3 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 528
  %.4 = bitcast ptr %.3 to ptr
  store [56 x i8] %arg_528, ptr %.4, align 16
  %.6 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 568
  %.7 = bitcast ptr %.6 to ptr
  %ldc_const = load i64, ptr %.7, align 8
  %"R9:R8_r0" = trunc i64 %ldc_const to i32
  %"R9:R8_r1_shift" = lshr i64 %ldc_const, 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %.8 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 576
  %.9 = bitcast ptr %.8 to ptr
  %ldc_const.1 = load i64, ptr %.9, align 8
  %"UR9:UR8_r0" = trunc i64 %ldc_const.1 to i32
  %"UR9:UR8_r1_shift" = lshr i64 %ldc_const.1, 32
  %"UR9:UR8_r1" = trunc i64 %"UR9:UR8_r1_shift" to i32
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %nctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %R149_zext = zext i32 %nctaid_x to i64
  %R1_trunc = trunc i64 %R149_zext to i32
  %isetrp_cmp1 = icmp ugt i32 %"R9:R8_r0", 0
  %isetrp_src_to_i32 = zext i1 true to i32
  %isetrp_src_to_i1 = icmp ne i32 %isetrp_src_to_i32, 0
  %isetrp_cmp2 = and i1 %isetrp_cmp1, %isetrp_src_to_i1
  %P1_to_i32 = zext i1 %isetrp_cmp2 to i32
  %isetrp_cmp1.1 = icmp eq i32 %"R9:R8_r0", %"UR9:UR8_r0"
  %isetrp_src_to_i32.1 = zext i1 true to i32
  %isetrp_src_to_i1.1 = icmp ne i32 %isetrp_src_to_i32.1, 0
  %isetrp_cmp2.1 = and i1 %isetrp_cmp1.1, %isetrp_src_to_i1.1
  %P8_to_i32 = zext i1 %isetrp_cmp2.1 to i32
  %isetrp_cmp1.2 = icmp sgt i32 %"R9:R8_r1", 0
  %isetrp_ex_lo_trunc = trunc i32 %P1_to_i32 to i1
  %isetrp_ex_lo_to_i32 = zext i1 %isetrp_ex_lo_trunc to i32
  %isetrp_ex_lo_to_i1 = icmp ne i32 %isetrp_ex_lo_to_i32, 0
  %isetrp_hi_eq = icmp eq i32 %"R9:R8_r1", 0
  %isetrp_ex_sel = select i1 %isetrp_hi_eq, i1 %isetrp_ex_lo_to_i1, i1 %isetrp_cmp1.2
  %isetrp_src_to_i32.2 = zext i1 true to i32
  %isetrp_src_to_i1.2 = icmp ne i32 %isetrp_src_to_i32.2, 0
  %isetrp_cmp2.2 = and i1 %isetrp_ex_sel, %isetrp_src_to_i1.2
  %P19_to_i32 = zext i1 %isetrp_cmp2.2 to i32
  %isetrp_cmp1.3 = icmp eq i32 %"R9:R8_r1", %"UR9:UR8_r1"
  %isetrp_ex_lo_trunc.1 = trunc i32 %P8_to_i32 to i1
  %isetrp_ex_lo_to_i32.1 = zext i1 %isetrp_ex_lo_trunc.1 to i32
  %isetrp_ex_lo_to_i1.1 = icmp ne i32 %isetrp_ex_lo_to_i32.1, 0
  %isetrp_hi_eq.1 = icmp eq i32 %"R9:R8_r1", %"UR9:UR8_r1"
  %isetrp_ex_sel.1 = select i1 %isetrp_hi_eq.1, i1 %isetrp_ex_lo_to_i1.1, i1 %isetrp_cmp1.3
  %isetrp_src_to_i32.3 = zext i1 true to i32
  %isetrp_src_to_i1.3 = icmp ne i32 %isetrp_src_to_i32.3, 0
  %isetrp_cmp2.3 = and i1 %isetrp_ex_sel.1, %isetrp_src_to_i1.3
  %P17_to_i32 = zext i1 %isetrp_cmp2.3 to i32
  br label %BB_00c0

BB_00c0:                                          ; preds = %EntryBB_0000
  %cond_trunc = trunc i32 %P19_to_i32 to i1
  %pbra_cond_to_i32 = zext i1 %cond_trunc to i32
  %pbra_cond_to_i1 = icmp ne i32 %pbra_cond_to_i32, 0
  br i1 %pbra_cond_to_i1, label %BB_800000c0, label %BB_00d0

BB_800000c0:                                      ; preds = %BB_00c0
  %bra_cond_trunc = trunc i32 %P17_to_i32 to i1
  %bra_cond_to_i32 = zext i1 %bra_cond_trunc to i32
  %bra_cond_to_i1 = icmp ne i32 %bra_cond_to_i32, 0
  br i1 %bra_cond_to_i1, label %BB_0420, label %BB_00d0

BB_00d0:                                          ; preds = %BB_800000c0, %BB_00c0
  %.13 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  %.14 = bitcast ptr %.13 to ptr
  %ldc_const.2 = load i64, ptr %.14, align 8
  %"R7:R6_r0" = trunc i64 %ldc_const.2 to i32
  %"R7:R6_r1_shift" = lshr i64 %ldc_const.2, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %.15 = zext i32 0 to i64
  %.16 = zext i32 %tid_x to i64
  %.17 = shl i64 %.16, 32
  %shf_concat = or i64 %.15, %.17
  %shf_shift_64 = zext i32 31 to i64
  %.18 = ashr i64 %shf_concat, %shf_shift_64
  %shf_hi = lshr i64 %.18, 32
  %shf_result = trunc i64 %shf_hi to i32
  %.19 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 528
  %.20 = bitcast ptr %.19 to ptr
  %ldc_const.3 = load i64, ptr %.20, align 8
  %"UR11:UR10_r0" = trunc i64 %ldc_const.3 to i32
  %"UR11:UR10_r1_shift" = lshr i64 %ldc_const.3, 32
  %"UR11:UR10_r1" = trunc i64 %"UR11:UR10_r1_shift" to i32
  %.21 = zext i32 %ctaid_x to i64
  %.22 = zext i32 %tid_x to i64
  %.23 = zext i32 7 to i64
  %.24 = shl i64 %.21, %.23
  %.25 = and i64 %.24, 4294967295
  %.26 = add i64 %.25, %.22
  %.27 = trunc i64 %.26 to i32
  %.28 = lshr i64 %.26, 32
  %.29 = trunc i64 %.28 to i1
  %P31_to_i32 = zext i1 %.29 to i32
  %.30 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 536
  %.31 = bitcast ptr %.30 to ptr
  %ldc_const.4 = load i64, ptr %.31, align 8
  %"UR13:UR12_r0" = trunc i64 %ldc_const.4 to i32
  %"UR13:UR12_r1_shift" = lshr i64 %ldc_const.4, 32
  %"UR13:UR12_r1" = trunc i64 %"UR13:UR12_r1_shift" to i32
  %.32 = zext i32 %ctaid_x to i64
  %.33 = zext i32 0 to i64
  %.34 = shl i64 %.33, 32
  %lea_funnel = or i64 %.32, %.34
  %.35 = zext i32 %shf_result to i64
  %.36 = zext i32 7 to i64
  %.37 = shl i64 %lea_funnel, %.36
  %.38 = lshr i64 %.37, 32
  %.39 = add i64 %.38, %.35
  %lea_cin_trunc = trunc i32 %P31_to_i32 to i1
  %.40 = zext i1 %lea_cin_trunc to i64
  %.41 = add i64 %.39, %.40
  %.42 = trunc i64 %.41 to i32
  %isetrp_cmp1.4 = icmp uge i32 %.27, %"R7:R6_r0"
  %isetrp_src_to_i32.4 = zext i1 true to i32
  %isetrp_src_to_i1.4 = icmp ne i32 %isetrp_src_to_i32.4, 0
  %isetrp_cmp2.4 = and i1 %isetrp_cmp1.4, %isetrp_src_to_i1.4
  %P3_to_i32 = zext i1 %isetrp_cmp2.4 to i32
  %isetrp_cmp1.5 = icmp sge i32 %.42, %"R7:R6_r1"
  %isetrp_ex_lo_trunc.2 = trunc i32 %P3_to_i32 to i1
  %isetrp_ex_lo_to_i32.2 = zext i1 %isetrp_ex_lo_trunc.2 to i32
  %isetrp_ex_lo_to_i1.2 = icmp ne i32 %isetrp_ex_lo_to_i32.2, 0
  %isetrp_hi_eq.2 = icmp eq i32 %.42, %"R7:R6_r1"
  %isetrp_ex_sel.2 = select i1 %isetrp_hi_eq.2, i1 %isetrp_ex_lo_to_i1.2, i1 %isetrp_cmp1.5
  %isetrp_src_to_i32.5 = zext i1 true to i32
  %isetrp_src_to_i1.5 = icmp ne i32 %isetrp_src_to_i32.5, 0
  %isetrp_cmp2.5 = and i1 %isetrp_ex_sel.2, %isetrp_src_to_i1.5
  %P10_to_i32 = zext i1 %isetrp_cmp2.5 to i32
  br label %BB_0160

BB_0160:                                          ; preds = %BB_00d0
  %cond_trunc.1 = trunc i32 %P10_to_i32 to i1
  %pbra_cond_to_i32.1 = zext i1 %cond_trunc.1 to i32
  %pbra_cond_to_i1.1 = icmp ne i32 %pbra_cond_to_i32.1, 0
  br i1 %pbra_cond_to_i1.1, label %BB_0940, label %BB_0170

BB_0170:                                          ; preds = %BB_0160
  %iadd3_o1_raw64 = zext i32 %"R7:R6_r0" to i64
  %iadd3_o1_not64 = xor i64 %iadd3_o1_raw64, -1
  %iadd3_o1_not64_masked = and i64 %iadd3_o1_not64, 4294967295
  %iadd3_o1_neg64 = add i64 %iadd3_o1_not64_masked, 1
  %iadd3_o2_64 = zext i32 1 to i64
  %iadd3_o3_64 = zext i32 0 to i64
  %iadd3_tmp = add i64 %iadd3_o1_neg64, %iadd3_o2_64
  %iadd3_tmp2 = add i64 %iadd3_tmp, %iadd3_o3_64
  %iadd3_trunc = trunc i64 %iadd3_tmp2 to i32
  %iadd3_carry_val = lshr i64 %iadd3_tmp2, 32
  %carry_ge_1 = icmp uge i64 %iadd3_carry_val, 1
  %P27_to_i32 = zext i1 %carry_ge_1 to i32
  %.45 = zext i32 0 to i64
  %.46 = zext i32 %"UR9:UR8_r1" to i64
  %.47 = shl i64 %.46, 32
  %shf_concat.1 = or i64 %.45, %.47
  %shf_shift_64.1 = zext i32 31 to i64
  %.48 = ashr i64 %shf_concat.1, %shf_shift_64.1
  %shf_hi.1 = lshr i64 %.48, 32
  %shf_result.1 = trunc i64 %shf_hi.1 to i32
  %.49 = zext i32 0 to i64
  %.50 = zext i32 %"R9:R8_r1" to i64
  %.51 = shl i64 %.50, 32
  %shf_concat.2 = or i64 %.49, %.51
  %shf_shift_64.2 = zext i32 31 to i64
  %.52 = ashr i64 %shf_concat.2, %shf_shift_64.2
  %shf_hi.2 = lshr i64 %.52, 32
  %shf_result.2 = trunc i64 %shf_hi.2 to i32
  %.53 = zext i32 0 to i64
  %.54 = zext i32 %"UR9:UR8_r1" to i64
  %.55 = shl i64 %.54, 32
  %shf_concat.3 = or i64 %.53, %.55
  %shf_shift_64.3 = zext i32 31 to i64
  %.56 = ashr i64 %shf_concat.3, %shf_shift_64.3
  %shf_hi.3 = lshr i64 %.56, 32
  %shf_result.3 = trunc i64 %shf_hi.3 to i32
  %imad_addend_not = xor i32 %"R7:R6_r1", -1
  %imad_tmp = mul i32 0, 0
  %imad = add i32 %imad_tmp, %imad_addend_not
  %imad_cin_trunc = trunc i32 %P27_to_i32 to i1
  %imad_cin_ext = zext i1 %imad_cin_trunc to i32
  %imad_with_cin = add i32 %imad, %imad_cin_ext
  %imad_tmp.1 = mul i32 %imad_with_cin, %"R9:R8_r0"
  %imad.1 = add i32 %imad_tmp.1, 0
  %imad_tmp.2 = mul i32 %imad_with_cin, %"UR9:UR8_r0"
  %imad.2 = add i32 %imad_tmp.2, 0
  %imad_addend_r0_ext = zext i32 0 to i64
  %imad_addend_packed_0 = or i64 0, %imad_addend_r0_ext
  %imad_addend_r1_ext = zext i32 0 to i64
  %imad_addend_r1_shift = shl i64 %imad_addend_r1_ext, 32
  %imad_addend_packed_1 = or i64 %imad_addend_packed_0, %imad_addend_r1_shift
  %imad_lhs_64 = zext i32 %iadd3_trunc to i64
  %imad_rhs_64 = zext i32 %"R9:R8_r0" to i64
  %imad_tmp_64 = mul i64 %imad_lhs_64, %imad_rhs_64
  %imad.3 = add i64 %imad_tmp_64, %imad_addend_packed_1
  %"R11:R10_r0" = trunc i64 %imad.3 to i32
  %"R11:R10_r1_shift" = lshr i64 %imad.3, 32
  %"R11:R10_r1" = trunc i64 %"R11:R10_r1_shift" to i32
  %imad_tmp.3 = mul i32 %iadd3_trunc, %"R9:R8_r1"
  %imad.4 = add i32 %imad_tmp.3, %imad.1
  %.57 = xor i32 %shf_result.2, -1
  %.58 = xor i32 %"R11:R10_r0", -1
  %.59 = xor i32 0, -1
  %.60 = and i32 %shf_result.2, %"R11:R10_r0"
  %.61 = and i32 %.60, %.59
  %.62 = and i32 %shf_result.2, %"R11:R10_r0"
  %.63 = and i32 %.62, 0
  %.64 = or i32 %.61, %.63
  %imad_tmp.4 = mul i32 %iadd3_trunc, %"UR9:UR8_r1"
  %imad.5 = add i32 %imad_tmp.4, %imad.2
  %imad_addend_r0_ext.1 = zext i32 0 to i64
  %imad_addend_packed_0.1 = or i64 0, %imad_addend_r0_ext.1
  %imad_addend_r1_ext.1 = zext i32 0 to i64
  %imad_addend_r1_shift.1 = shl i64 %imad_addend_r1_ext.1, 32
  %imad_addend_packed_1.1 = or i64 %imad_addend_packed_0.1, %imad_addend_r1_shift.1
  %imad_lhs_64.1 = zext i32 %iadd3_trunc to i64
  %imad_rhs_64.1 = zext i32 %"UR9:UR8_r0" to i64
  %imad_tmp_64.1 = mul i64 %imad_lhs_64.1, %imad_rhs_64.1
  %imad.6 = add i64 %imad_tmp_64.1, %imad_addend_packed_1.1
  %"R13:R12_r0" = trunc i64 %imad.6 to i32
  %"R13:R12_r1_shift" = lshr i64 %imad.6, 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %imad_tmp.5 = mul i32 %"R11:R10_r1", 1
  %imad.7 = add i32 %imad_tmp.5, %imad.4
  %.65 = zext i32 0 to i64
  %.66 = zext i32 %"R9:R8_r1" to i64
  %.67 = shl i64 %.66, 32
  %shf_concat.4 = or i64 %.65, %.67
  %shf_shift_64.4 = zext i32 31 to i64
  %.68 = ashr i64 %shf_concat.4, %shf_shift_64.4
  %shf_hi.4 = lshr i64 %.68, 32
  %shf_result.4 = trunc i64 %shf_hi.4 to i32
  %imad_tmp.6 = mul i32 %"R13:R12_r1", 1
  %imad.8 = add i32 %imad_tmp.6, %imad.5
  %.69 = xor i32 %"R13:R12_r0", -1
  %.70 = xor i32 %shf_result.1, -1
  %.71 = xor i32 0, -1
  %.72 = and i32 %"R13:R12_r0", %shf_result.1
  %.73 = and i32 %.72, %.71
  %.74 = and i32 %"R13:R12_r0", %shf_result.1
  %.75 = and i32 %.74, 0
  %.76 = or i32 %.73, %.75
  %.77 = xor i32 %shf_result.4, -1
  %.78 = xor i32 %imad.7, -1
  %.79 = xor i32 0, -1
  %.80 = and i32 %shf_result.4, %imad.7
  %.81 = and i32 %.80, %.79
  %.82 = and i32 %shf_result.4, %imad.7
  %.83 = and i32 %.82, 0
  %.84 = or i32 %.81, %.83
  %.85 = xor i32 %imad.8, -1
  %.86 = xor i32 %shf_result.3, -1
  %.87 = xor i32 0, -1
  %.88 = and i32 %imad.8, %shf_result.3
  %.89 = and i32 %.88, %.87
  %.90 = and i32 %imad.8, %shf_result.3
  %.91 = and i32 %.90, 0
  %.92 = or i32 %.89, %.91
  br label %BB_02b0

BB_02b0:                                          ; preds = %BB_03f0, %BB_0170
  %phi = phi i32 [ %.42, %BB_0170 ], [ %"R25:R24_r1", %BB_03f0 ]
  %phi.1 = phi i32 [ %.27, %BB_0170 ], [ %"R25:R24_r0", %BB_03f0 ]
  %phi.2 = phi float [ 0.000000e+00, %BB_0170 ], [ %ffma, %BB_03f0 ]
  %imad_tmp.7 = mul i32 %phi, %"R9:R8_r0"
  %imad.9 = add i32 %imad_tmp.7, 0
  %imad_tmp.8 = mul i32 %phi, %"UR9:UR8_r0"
  %imad.10 = add i32 %imad_tmp.8, 0
  %imad_addend_r0_ext.2 = zext i32 %.64 to i64
  %imad_addend_packed_0.2 = or i64 0, %imad_addend_r0_ext.2
  %imad_addend_r1_ext.2 = zext i32 %.84 to i64
  %imad_addend_r1_shift.2 = shl i64 %imad_addend_r1_ext.2, 32
  %imad_addend_packed_1.2 = or i64 %imad_addend_packed_0.2, %imad_addend_r1_shift.2
  %imad_lhs_64.2 = zext i32 %phi.1 to i64
  %imad_rhs_64.2 = zext i32 %"R9:R8_r0" to i64
  %imad_tmp_64.2 = mul i64 %imad_lhs_64.2, %imad_rhs_64.2
  %imad.11 = add i64 %imad_tmp_64.2, %imad_addend_packed_1.2
  %"R19:R18_r0" = trunc i64 %imad.11 to i32
  %"R19:R18_r1_shift" = lshr i64 %imad.11, 32
  %"R19:R18_r1" = trunc i64 %"R19:R18_r1_shift" to i32
  %imad_tmp.9 = mul i32 %phi.1, %"R9:R8_r1"
  %imad.12 = add i32 %imad_tmp.9, %imad.9
  %imad_addend_r0_ext.3 = zext i32 %.76 to i64
  %imad_addend_packed_0.3 = or i64 0, %imad_addend_r0_ext.3
  %imad_addend_r1_ext.3 = zext i32 %.92 to i64
  %imad_addend_r1_shift.3 = shl i64 %imad_addend_r1_ext.3, 32
  %imad_addend_packed_1.3 = or i64 %imad_addend_packed_0.3, %imad_addend_r1_shift.3
  %imad_lhs_64.3 = zext i32 %phi.1 to i64
  %imad_rhs_64.3 = zext i32 %"UR9:UR8_r0" to i64
  %imad_tmp_64.3 = mul i64 %imad_lhs_64.3, %imad_rhs_64.3
  %imad.13 = add i64 %imad_tmp_64.3, %imad_addend_packed_1.3
  %"R21:R20_r0" = trunc i64 %imad.13 to i32
  %"R21:R20_r1_shift" = lshr i64 %imad.13, 32
  %"R21:R20_r1" = trunc i64 %"R21:R20_r1_shift" to i32
  %imad_tmp.10 = mul i32 %phi.1, %"UR9:UR8_r1"
  %imad.14 = add i32 %imad_tmp.10, %imad.10
  %.94 = zext i32 %"R19:R18_r0" to i64
  %.95 = zext i32 %"UR11:UR10_r0" to i64
  %.96 = zext i32 2 to i64
  %.97 = shl i64 %.94, %.96
  %.98 = and i64 %.97, 4294967295
  %.99 = add i64 %.98, %.95
  %.100 = trunc i64 %.99 to i32
  %.101 = lshr i64 %.99, 32
  %.102 = trunc i64 %.101 to i1
  %P32_to_i32 = zext i1 %.102 to i32
  %imad_tmp.11 = mul i32 %"R19:R18_r1", 1
  %imad.15 = add i32 %imad_tmp.11, %imad.12
  %.103 = zext i32 %"R21:R20_r0" to i64
  %.104 = zext i32 %"UR13:UR12_r0" to i64
  %.105 = zext i32 2 to i64
  %.106 = shl i64 %.103, %.105
  %.107 = and i64 %.106, 4294967295
  %.108 = add i64 %.107, %.104
  %.109 = trunc i64 %.108 to i32
  %.110 = lshr i64 %.108, 32
  %.111 = trunc i64 %.110 to i1
  %P9_to_i32 = zext i1 %.111 to i32
  %imad_tmp.12 = mul i32 %"R21:R20_r1", 1
  %imad.16 = add i32 %imad_tmp.12, %imad.14
  %.112 = zext i32 %"R19:R18_r0" to i64
  %.113 = zext i32 %imad.15 to i64
  %.114 = shl i64 %.113, 32
  %lea_funnel.1 = or i64 %.112, %.114
  %.115 = zext i32 %"UR11:UR10_r1" to i64
  %.116 = zext i32 2 to i64
  %.117 = shl i64 %lea_funnel.1, %.116
  %.118 = lshr i64 %.117, 32
  %.119 = add i64 %.118, %.115
  %lea_cin_trunc.1 = trunc i32 %P32_to_i32 to i1
  %.120 = zext i1 %lea_cin_trunc.1 to i64
  %.121 = add i64 %.119, %.120
  %.122 = trunc i64 %.121 to i32
  %.123 = zext i32 %"R21:R20_r0" to i64
  %.124 = zext i32 %imad.16 to i64
  %.125 = shl i64 %.124, 32
  %lea_funnel.2 = or i64 %.123, %.125
  %.126 = zext i32 %"UR13:UR12_r1" to i64
  %.127 = zext i32 2 to i64
  %.128 = shl i64 %lea_funnel.2, %.127
  %.129 = lshr i64 %.128, 32
  %.130 = add i64 %.129, %.126
  %lea_cin_trunc.2 = trunc i32 %P9_to_i32 to i1
  %.131 = zext i1 %lea_cin_trunc.2 to i64
  %.132 = add i64 %.130, %.131
  %.133 = trunc i64 %.132 to i32
  %ldg_addr_r0_ext = zext i32 %.100 to i64
  %ldg_addr_packed_0 = or i64 0, %ldg_addr_r0_ext
  %ldg_addr_r1_ext = zext i32 %.122 to i64
  %ldg_addr_r1_shift = shl i64 %ldg_addr_r1_ext, 32
  %ldg_addr_packed_1 = or i64 %ldg_addr_packed_0, %ldg_addr_r1_shift
  %"R67:R63_addr_ptr" = inttoptr i64 %ldg_addr_packed_1 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R67:R63_addr_ptr", align 4
  %ldg_addr_r0_ext.1 = zext i32 %.109 to i64
  %ldg_addr_packed_0.1 = or i64 0, %ldg_addr_r0_ext.1
  %ldg_addr_r1_ext.1 = zext i32 %.133 to i64
  %ldg_addr_r1_shift.1 = shl i64 %ldg_addr_r1_ext.1, 32
  %ldg_addr_packed_1.1 = or i64 %ldg_addr_packed_0.1, %ldg_addr_r1_shift.1
  %"R137:R47_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.1 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R137:R47_addr_ptr", align 4
  %imad_addend_r0_ext.4 = zext i32 %phi.1 to i64
  %imad_addend_packed_0.4 = or i64 0, %imad_addend_r0_ext.4
  %imad_addend_r1_ext.4 = zext i32 %phi to i64
  %imad_addend_r1_shift.4 = shl i64 %imad_addend_r1_ext.4, 32
  %imad_addend_packed_1.4 = or i64 %imad_addend_packed_0.4, %imad_addend_r1_shift.4
  %imad_lhs_64.4 = zext i32 %R1_trunc to i64
  %imad_rhs_64.4 = zext i32 128 to i64
  %imad_tmp_64.4 = mul i64 %imad_lhs_64.4, %imad_rhs_64.4
  %imad.17 = add i64 %imad_tmp_64.4, %imad_addend_packed_1.4
  %"R25:R24_r0" = trunc i64 %imad.17 to i32
  %"R25:R24_r1_shift" = lshr i64 %imad.17, 32
  %"R25:R24_r1" = trunc i64 %"R25:R24_r1_shift" to i32
  %isetrp_cmp1.6 = icmp uge i32 %"R25:R24_r0", %"R7:R6_r0"
  %isetrp_src_to_i32.6 = zext i1 true to i32
  %isetrp_src_to_i1.6 = icmp ne i32 %isetrp_src_to_i32.6, 0
  %isetrp_cmp2.6 = and i1 %isetrp_cmp1.6, %isetrp_src_to_i1.6
  %P33_to_i32 = zext i1 %isetrp_cmp2.6 to i32
  %isetrp_cmp1.7 = icmp sge i32 %"R25:R24_r1", %"R7:R6_r1"
  %isetrp_ex_lo_trunc.3 = trunc i32 %P33_to_i32 to i1
  %isetrp_ex_lo_to_i32.3 = zext i1 %isetrp_ex_lo_trunc.3 to i32
  %isetrp_ex_lo_to_i1.3 = icmp ne i32 %isetrp_ex_lo_to_i32.3, 0
  %isetrp_hi_eq.3 = icmp eq i32 %"R25:R24_r1", %"R7:R6_r1"
  %isetrp_ex_sel.3 = select i1 %isetrp_hi_eq.3, i1 %isetrp_ex_lo_to_i1.3, i1 %isetrp_cmp1.7
  %isetrp_src_to_i32.7 = zext i1 true to i32
  %isetrp_src_to_i1.7 = icmp ne i32 %isetrp_src_to_i32.7, 0
  %isetrp_cmp2.7 = and i1 %isetrp_ex_sel.3, %isetrp_src_to_i1.7
  %P35_to_i32 = zext i1 %isetrp_cmp2.7 to i32
  %ffma = call float @llvm.fma.f32(float %ldg, float %ldg.1, float %phi.2)
  br label %BB_03f0

BB_03f0:                                          ; preds = %BB_02b0
  %cond_trunc.2 = trunc i32 %P35_to_i32 to i1
  %cond_not = xor i1 %cond_trunc.2, true
  %pbra_cond_to_i32.2 = zext i1 %cond_not to i32
  %pbra_cond_to_i1.2 = icmp ne i32 %pbra_cond_to_i32.2, 0
  br i1 %pbra_cond_to_i1.2, label %BB_02b0, label %BB_0940

BB_0420:                                          ; preds = %BB_800000c0
  %isetrp_cmp1.8 = icmp ne i32 %"R9:R8_r0", 1
  %isetrp_src_to_i32.8 = zext i1 true to i32
  %isetrp_src_to_i1.8 = icmp ne i32 %isetrp_src_to_i32.8, 0
  %isetrp_cmp2.8 = and i1 %isetrp_cmp1.8, %isetrp_src_to_i1.8
  %P38_to_i32 = zext i1 %isetrp_cmp2.8 to i32
  %.136 = zext i32 0 to i64
  %.137 = zext i32 %tid_x to i64
  %.138 = shl i64 %.137, 32
  %shf_concat.5 = or i64 %.136, %.138
  %shf_shift_64.5 = zext i32 31 to i64
  %.139 = ashr i64 %shf_concat.5, %shf_shift_64.5
  %shf_hi.5 = lshr i64 %.139, 32
  %shf_result.5 = trunc i64 %shf_hi.5 to i32
  %isetrp_cmp1.9 = icmp ne i32 %"R9:R8_r1", 0
  %isetrp_ex_lo_trunc.4 = trunc i32 %P38_to_i32 to i1
  %isetrp_ex_lo_to_i32.4 = zext i1 %isetrp_ex_lo_trunc.4 to i32
  %isetrp_ex_lo_to_i1.4 = icmp ne i32 %isetrp_ex_lo_to_i32.4, 0
  %isetrp_hi_eq.4 = icmp eq i32 %"R9:R8_r1", 0
  %isetrp_ex_sel.4 = select i1 %isetrp_hi_eq.4, i1 %isetrp_ex_lo_to_i1.4, i1 %isetrp_cmp1.9
  %isetrp_src_to_i32.9 = zext i1 true to i32
  %isetrp_src_to_i1.9 = icmp ne i32 %isetrp_src_to_i32.9, 0
  %isetrp_cmp2.9 = and i1 %isetrp_ex_sel.4, %isetrp_src_to_i1.9
  %P40_to_i32 = zext i1 %isetrp_cmp2.9 to i32
  %imad_addend_r0_ext.5 = zext i32 %tid_x to i64
  %imad_addend_packed_0.5 = or i64 0, %imad_addend_r0_ext.5
  %imad_addend_r1_ext.5 = zext i32 %shf_result.5 to i64
  %imad_addend_r1_shift.5 = shl i64 %imad_addend_r1_ext.5, 32
  %imad_addend_packed_1.5 = or i64 %imad_addend_packed_0.5, %imad_addend_r1_shift.5
  %imad_lhs_64.5 = zext i32 %ctaid_x to i64
  %imad_rhs_64.5 = zext i32 128 to i64
  %imad_tmp_64.5 = mul i64 %imad_lhs_64.5, %imad_rhs_64.5
  %imad.18 = add i64 %imad_tmp_64.5, %imad_addend_packed_1.5
  %"R7:R6_r0.1" = trunc i64 %imad.18 to i32
  %"R7:R6_r1_shift.1" = lshr i64 %imad.18, 32
  %"R7:R6_r1.1" = trunc i64 %"R7:R6_r1_shift.1" to i32
  br label %BB_0480

BB_0480:                                          ; preds = %BB_0420
  %cond_trunc.3 = trunc i32 %P40_to_i32 to i1
  %cond_not.1 = xor i1 %cond_trunc.3, true
  %pbra_cond_to_i32.3 = zext i1 %cond_not.1 to i32
  %pbra_cond_to_i1.3 = icmp ne i32 %pbra_cond_to_i32.3, 0
  br i1 %pbra_cond_to_i1.3, label %BB_0680, label %BB_0490

BB_0490:                                          ; preds = %BB_0480
  %.142 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  %.143 = bitcast ptr %.142 to ptr
  %ldc_const.5 = load i64, ptr %.143, align 8
  %"UR11:UR10_r0.1" = trunc i64 %ldc_const.5 to i32
  %"UR11:UR10_r1_shift.1" = lshr i64 %ldc_const.5, 32
  %"UR11:UR10_r1.1" = trunc i64 %"UR11:UR10_r1_shift.1" to i32
  %.144 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 528
  %.145 = bitcast ptr %.144 to ptr
  %ldc_const.6 = load i64, ptr %.145, align 8
  %"UR13:UR12_r0.1" = trunc i64 %ldc_const.6 to i32
  %"UR13:UR12_r1_shift.1" = lshr i64 %ldc_const.6, 32
  %"UR13:UR12_r1.1" = trunc i64 %"UR13:UR12_r1_shift.1" to i32
  %isetrp_cmp1.10 = icmp uge i32 %"R7:R6_r0.1", %"UR11:UR10_r0.1"
  %isetrp_src_to_i32.10 = zext i1 true to i32
  %isetrp_src_to_i1.10 = icmp ne i32 %isetrp_src_to_i32.10, 0
  %isetrp_cmp2.10 = and i1 %isetrp_cmp1.10, %isetrp_src_to_i1.10
  %P2_to_i32 = zext i1 %isetrp_cmp2.10 to i32
  %.146 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 536
  %.147 = bitcast ptr %.146 to ptr
  %ldc_const.7 = load i64, ptr %.147, align 8
  %"UR15:UR14_r0" = trunc i64 %ldc_const.7 to i32
  %"UR15:UR14_r1_shift" = lshr i64 %ldc_const.7, 32
  %"UR15:UR14_r1" = trunc i64 %"UR15:UR14_r1_shift" to i32
  %isetrp_cmp1.11 = icmp sge i32 %"R7:R6_r1.1", %"UR11:UR10_r1.1"
  %isetrp_ex_lo_trunc.5 = trunc i32 %P2_to_i32 to i1
  %isetrp_ex_lo_to_i32.5 = zext i1 %isetrp_ex_lo_trunc.5 to i32
  %isetrp_ex_lo_to_i1.5 = icmp ne i32 %isetrp_ex_lo_to_i32.5, 0
  %isetrp_hi_eq.5 = icmp eq i32 %"R7:R6_r1.1", %"UR11:UR10_r1.1"
  %isetrp_ex_sel.5 = select i1 %isetrp_hi_eq.5, i1 %isetrp_ex_lo_to_i1.5, i1 %isetrp_cmp1.11
  %isetrp_src_to_i32.11 = zext i1 true to i32
  %isetrp_src_to_i1.11 = icmp ne i32 %isetrp_src_to_i32.11, 0
  %isetrp_cmp2.11 = and i1 %isetrp_ex_sel.5, %isetrp_src_to_i1.11
  %P4_to_i32 = zext i1 %isetrp_cmp2.11 to i32
  br label %BB_04f0

BB_04f0:                                          ; preds = %BB_0490
  %cond_trunc.4 = trunc i32 %P4_to_i32 to i1
  %pbra_cond_to_i32.4 = zext i1 %cond_trunc.4 to i32
  %pbra_cond_to_i1.4 = icmp ne i32 %pbra_cond_to_i32.4, 0
  br i1 %pbra_cond_to_i1.4, label %BB_0940, label %BB_0500

BB_0500:                                          ; preds = %BB_04f0
  br label %BB_0510

BB_0510:                                          ; preds = %BB_0650, %BB_0500
  %phi.3 = phi i32 [ %"R7:R6_r1.1", %BB_0500 ], [ %"R7:R6_r1.3", %BB_0650 ]
  %phi.4 = phi i32 [ %"R7:R6_r0.1", %BB_0500 ], [ %"R7:R6_r0.3", %BB_0650 ]
  %phi.5 = phi float [ 0.000000e+00, %BB_0500 ], [ %ffma.1, %BB_0650 ]
  %imad_tmp.13 = mul i32 %phi.3, %"R9:R8_r0"
  %imad.19 = add i32 %imad_tmp.13, 0
  %imad_addend_r0_ext.6 = zext i32 0 to i64
  %imad_addend_packed_0.6 = or i64 0, %imad_addend_r0_ext.6
  %imad_addend_r1_ext.6 = zext i32 0 to i64
  %imad_addend_r1_shift.6 = shl i64 %imad_addend_r1_ext.6, 32
  %imad_addend_packed_1.6 = or i64 %imad_addend_packed_0.6, %imad_addend_r1_shift.6
  %imad_lhs_64.6 = zext i32 %phi.4 to i64
  %imad_rhs_64.6 = zext i32 %"R9:R8_r0" to i64
  %imad_tmp_64.6 = mul i64 %imad_lhs_64.6, %imad_rhs_64.6
  %imad.20 = add i64 %imad_tmp_64.6, %imad_addend_packed_1.6
  %"R7:R6_r0.2" = trunc i64 %imad.20 to i32
  %"R7:R6_r1_shift.2" = lshr i64 %imad.20, 32
  %"R7:R6_r1.2" = trunc i64 %"R7:R6_r1_shift.2" to i32
  %imad_tmp.14 = mul i32 %phi.4, %"R9:R8_r1"
  %imad.21 = add i32 %imad_tmp.14, %imad.19
  %imad_tmp.15 = mul i32 %"R7:R6_r0.2", 4
  %imad.22 = add i32 %imad_tmp.15, 0
  %iadd3_n1 = add i32 %"R7:R6_r1.2", %imad.21
  %iadd3_n2 = add i32 %iadd3_n1, 0
  %iadd3_o1_64 = zext i32 %imad.22 to i64
  %iadd3_o2_64.1 = zext i32 %"UR13:UR12_r0.1" to i64
  %iadd3_o3_64.1 = zext i32 0 to i64
  %iadd3_tmp.1 = add i64 %iadd3_o1_64, %iadd3_o2_64.1
  %iadd3_tmp2.1 = add i64 %iadd3_tmp.1, %iadd3_o3_64.1
  %iadd3_trunc.1 = trunc i64 %iadd3_tmp2.1 to i32
  %iadd3_carry_val.1 = lshr i64 %iadd3_tmp2.1, 32
  %carry_ge_1.1 = icmp uge i64 %iadd3_carry_val.1, 1
  %P5_to_i32 = zext i1 %carry_ge_1.1 to i32
  %.151 = zext i32 %"R7:R6_r0.2" to i64
  %.152 = zext i32 %iadd3_n2 to i64
  %.153 = shl i64 %.152, 32
  %shf_concat.6 = or i64 %.151, %.153
  %shf_shift_64.6 = zext i32 2 to i64
  %.154 = shl i64 %shf_concat.6, %shf_shift_64.6
  %shf_hi.6 = lshr i64 %.154, 32
  %shf_result.6 = trunc i64 %shf_hi.6 to i32
  %iadd3_o1_64.1 = zext i32 %imad.22 to i64
  %iadd3_o2_64.2 = zext i32 %"UR15:UR14_r0" to i64
  %iadd3_o3_64.2 = zext i32 0 to i64
  %iadd3_tmp.2 = add i64 %iadd3_o1_64.1, %iadd3_o2_64.2
  %iadd3_tmp2.2 = add i64 %iadd3_tmp.2, %iadd3_o3_64.2
  %iadd3_trunc.2 = trunc i64 %iadd3_tmp2.2 to i32
  %iadd3_carry_val.2 = lshr i64 %iadd3_tmp2.2, 32
  %carry_ge_1.2 = icmp uge i64 %iadd3_carry_val.2, 1
  %P18_to_i32 = zext i1 %carry_ge_1.2 to i32
  %iadd3_n1.1 = add i32 %shf_result.6, %"UR13:UR12_r1.1"
  %iadd3_n2.1 = add i32 %iadd3_n1.1, 0
  %iadd3_cin1_trunc = trunc i32 %P5_to_i32 to i1
  %iadd3_cin1_narrow_zext = zext i1 %iadd3_cin1_trunc to i32
  %iadd3_cin1_add = add i32 %iadd3_n2.1, %iadd3_cin1_narrow_zext
  %iadd3_cin2_narrow_zext = zext i1 false to i32
  %iadd3_cin2_add = add i32 %iadd3_cin1_add, %iadd3_cin2_narrow_zext
  %iadd3_n1.2 = add i32 %shf_result.6, %"UR15:UR14_r1"
  %iadd3_n2.2 = add i32 %iadd3_n1.2, 0
  %iadd3_cin1_trunc.1 = trunc i32 %P18_to_i32 to i1
  %iadd3_cin1_narrow_zext.1 = zext i1 %iadd3_cin1_trunc.1 to i32
  %iadd3_cin1_add.1 = add i32 %iadd3_n2.2, %iadd3_cin1_narrow_zext.1
  %iadd3_cin2_narrow_zext.1 = zext i1 false to i32
  %iadd3_cin2_add.1 = add i32 %iadd3_cin1_add.1, %iadd3_cin2_narrow_zext.1
  %ldg_addr_r0_ext.2 = zext i32 %iadd3_trunc.1 to i64
  %ldg_addr_packed_0.2 = or i64 0, %ldg_addr_r0_ext.2
  %ldg_addr_r1_ext.2 = zext i32 %iadd3_cin2_add to i64
  %ldg_addr_r1_shift.2 = shl i64 %ldg_addr_r1_ext.2, 32
  %ldg_addr_packed_1.2 = or i64 %ldg_addr_packed_0.2, %ldg_addr_r1_shift.2
  %"R153:R70_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.2 to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R153:R70_addr_ptr", align 4
  %ldg_addr_r0_ext.3 = zext i32 %iadd3_trunc.2 to i64
  %ldg_addr_packed_0.3 = or i64 0, %ldg_addr_r0_ext.3
  %ldg_addr_r1_ext.3 = zext i32 %iadd3_cin2_add.1 to i64
  %ldg_addr_r1_shift.3 = shl i64 %ldg_addr_r1_ext.3, 32
  %ldg_addr_packed_1.3 = or i64 %ldg_addr_packed_0.3, %ldg_addr_r1_shift.3
  %"R174:R164_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.3 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R174:R164_addr_ptr", align 4
  %imad_addend_r0_ext.7 = zext i32 %phi.4 to i64
  %imad_addend_packed_0.7 = or i64 0, %imad_addend_r0_ext.7
  %imad_addend_r1_ext.7 = zext i32 %phi.3 to i64
  %imad_addend_r1_shift.7 = shl i64 %imad_addend_r1_ext.7, 32
  %imad_addend_packed_1.7 = or i64 %imad_addend_packed_0.7, %imad_addend_r1_shift.7
  %imad_lhs_64.7 = zext i32 %R1_trunc to i64
  %imad_rhs_64.7 = zext i32 128 to i64
  %imad_tmp_64.7 = mul i64 %imad_lhs_64.7, %imad_rhs_64.7
  %imad.23 = add i64 %imad_tmp_64.7, %imad_addend_packed_1.7
  %"R7:R6_r0.3" = trunc i64 %imad.23 to i32
  %"R7:R6_r1_shift.3" = lshr i64 %imad.23, 32
  %"R7:R6_r1.3" = trunc i64 %"R7:R6_r1_shift.3" to i32
  %isetrp_cmp1.12 = icmp uge i32 %"R7:R6_r0.3", %"UR11:UR10_r0.1"
  %isetrp_src_to_i32.12 = zext i1 true to i32
  %isetrp_src_to_i1.12 = icmp ne i32 %isetrp_src_to_i32.12, 0
  %isetrp_cmp2.12 = and i1 %isetrp_cmp1.12, %isetrp_src_to_i1.12
  %P7_to_i32 = zext i1 %isetrp_cmp2.12 to i32
  %isetrp_cmp1.13 = icmp sge i32 %"R7:R6_r1.3", %"UR11:UR10_r1.1"
  %isetrp_ex_lo_trunc.6 = trunc i32 %P7_to_i32 to i1
  %isetrp_ex_lo_to_i32.6 = zext i1 %isetrp_ex_lo_trunc.6 to i32
  %isetrp_ex_lo_to_i1.6 = icmp ne i32 %isetrp_ex_lo_to_i32.6, 0
  %isetrp_hi_eq.6 = icmp eq i32 %"R7:R6_r1.3", %"UR11:UR10_r1.1"
  %isetrp_ex_sel.6 = select i1 %isetrp_hi_eq.6, i1 %isetrp_ex_lo_to_i1.6, i1 %isetrp_cmp1.13
  %isetrp_src_to_i32.13 = zext i1 true to i32
  %isetrp_src_to_i1.13 = icmp ne i32 %isetrp_src_to_i32.13, 0
  %isetrp_cmp2.13 = and i1 %isetrp_ex_sel.6, %isetrp_src_to_i1.13
  %P23_to_i32 = zext i1 %isetrp_cmp2.13 to i32
  %ffma.1 = call float @llvm.fma.f32(float %ldg.2, float %ldg.3, float %phi.5)
  br label %BB_0650

BB_0650:                                          ; preds = %BB_0510
  %cond_trunc.5 = trunc i32 %P23_to_i32 to i1
  %cond_not.2 = xor i1 %cond_trunc.5, true
  %pbra_cond_to_i32.5 = zext i1 %cond_not.2 to i32
  %pbra_cond_to_i1.5 = icmp ne i32 %pbra_cond_to_i32.5, 0
  br i1 %pbra_cond_to_i1.5, label %BB_0510, label %BB_0940

BB_0680:                                          ; preds = %BB_0480
  %imad_tmp.16 = mul i32 %"R7:R6_r0.1", 2
  %imad.24 = add i32 %imad_tmp.16, 0
  %.157 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  %.158 = bitcast ptr %.157 to ptr
  %ldc_const.8 = load i64, ptr %.158, align 8
  %"UR5:UR4_r0" = trunc i64 %ldc_const.8 to i32
  %"UR5:UR4_r1_shift" = lshr i64 %ldc_const.8, 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %.159 = zext i32 %"R7:R6_r0.1" to i64
  %.160 = zext i32 %"R7:R6_r1.1" to i64
  %.161 = shl i64 %.160, 32
  %shf_concat.7 = or i64 %.159, %.161
  %shf_shift_64.7 = zext i32 1 to i64
  %.162 = shl i64 %shf_concat.7, %shf_shift_64.7
  %shf_hi.7 = lshr i64 %.162, 32
  %shf_result.7 = trunc i64 %shf_hi.7 to i32
  %.163 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 536
  %.164 = bitcast ptr %.163 to ptr
  %ldc_const.9 = load i64, ptr %.164, align 8
  %"UR11:UR10_r0.2" = trunc i64 %ldc_const.9 to i32
  %"UR11:UR10_r1_shift.2" = lshr i64 %ldc_const.9, 32
  %"UR11:UR10_r1.2" = trunc i64 %"UR11:UR10_r1_shift.2" to i32
  %isetrp_cmp1.14 = icmp uge i32 %imad.24, %"UR5:UR4_r0"
  %isetrp_src_to_i32.14 = zext i1 true to i32
  %isetrp_src_to_i1.14 = icmp ne i32 %isetrp_src_to_i32.14, 0
  %isetrp_cmp2.14 = and i1 %isetrp_cmp1.14, %isetrp_src_to_i1.14
  %P6_to_i32 = zext i1 %isetrp_cmp2.14 to i32
  %"R15:R14_bitcast" = bitcast double 0.000000e+00 to i64
  %"R15:R14_r0" = trunc i64 %"R15:R14_bitcast" to i32
  %"R15:R14_r1_shift" = lshr i64 %"R15:R14_bitcast", 32
  %"R15:R14_r1" = trunc i64 %"R15:R14_r1_shift" to i32
  %isetrp_cmp1.15 = icmp sge i32 %shf_result.7, %"UR5:UR4_r1"
  %isetrp_ex_lo_trunc.7 = trunc i32 %P6_to_i32 to i1
  %isetrp_ex_lo_to_i32.7 = zext i1 %isetrp_ex_lo_trunc.7 to i32
  %isetrp_ex_lo_to_i1.7 = icmp ne i32 %isetrp_ex_lo_to_i32.7, 0
  %isetrp_hi_eq.7 = icmp eq i32 %shf_result.7, %"UR5:UR4_r1"
  %isetrp_ex_sel.7 = select i1 %isetrp_hi_eq.7, i1 %isetrp_ex_lo_to_i1.7, i1 %isetrp_cmp1.15
  %isetrp_src_to_i32.15 = zext i1 true to i32
  %isetrp_src_to_i1.15 = icmp ne i32 %isetrp_src_to_i32.15, 0
  %isetrp_cmp2.15 = and i1 %isetrp_ex_sel.7, %isetrp_src_to_i1.15
  %P15_to_i32 = zext i1 %isetrp_cmp2.15 to i32
  %.165 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 528
  %.166 = bitcast ptr %.165 to ptr
  %ldc_const.10 = load i64, ptr %.166, align 8
  %"UR5:UR4_r0.1" = trunc i64 %ldc_const.10 to i32
  %"UR5:UR4_r1_shift.1" = lshr i64 %ldc_const.10, 32
  %"UR5:UR4_r1.1" = trunc i64 %"UR5:UR4_r1_shift.1" to i32
  br label %BB_0710

BB_0710:                                          ; preds = %BB_0680
  %cond_trunc.6 = trunc i32 %P15_to_i32 to i1
  %pbra_cond_to_i32.6 = zext i1 %cond_trunc.6 to i32
  %pbra_cond_to_i1.6 = icmp ne i32 %pbra_cond_to_i32.6, 0
  %phi_cast_R28_bitcast.1 = bitcast i32 %"R15:R14_r1" to float
  %phi_cast_R22_bitcast = bitcast i32 %"R15:R14_r0" to float
  br i1 %pbra_cond_to_i1.6, label %BB_0910, label %BB_0720

BB_0720:                                          ; preds = %BB_0710
  %.169 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  %.170 = bitcast ptr %.169 to ptr
  %ldc_const.11 = load i64, ptr %.170, align 8
  %"R7:R6_r0.4" = trunc i64 %ldc_const.11 to i32
  %"R7:R6_r1_shift.4" = lshr i64 %ldc_const.11, 32
  %"R7:R6_r1.4" = trunc i64 %"R7:R6_r1_shift.4" to i32
  %phi_cast_R28_bitcast = bitcast i32 %"R15:R14_r1" to float
  br label %BB_0740

BB_0740:                                          ; preds = %BB_0900, %BB_0720
  %phi.6 = phi float [ 0.000000e+00, %BB_0720 ], [ %phi.14, %BB_0900 ]
  %phi.7 = phi float [ 0.000000e+00, %BB_0720 ], [ %phi.15, %BB_0900 ]
  %phi.8 = phi i32 [ %shf_result.7, %BB_0720 ], [ %"R9:R8_r1.1", %BB_0900 ]
  %phi.9 = phi float [ %phi_cast_R28_bitcast, %BB_0720 ], [ %phi.16, %BB_0900 ]
  %phi.10 = phi float [ 0.000000e+00, %BB_0720 ], [ %phi.17, %BB_0900 ]
  %phi.11 = phi i32 [ %imad.24, %BB_0720 ], [ %"R9:R8_r0.1", %BB_0900 ]
  %isetrp_cmp1.16 = icmp uge i32 %phi.11, %"R7:R6_r0.4"
  %isetrp_src_to_i32.16 = zext i1 true to i32
  %isetrp_src_to_i1.16 = icmp ne i32 %isetrp_src_to_i32.16, 0
  %isetrp_cmp2.16 = and i1 %isetrp_cmp1.16, %isetrp_src_to_i1.16
  %P20_to_i32 = zext i1 %isetrp_cmp2.16 to i32
  %isetrp_cmp1.17 = icmp sge i32 %phi.8, %"R7:R6_r1.4"
  %isetrp_ex_lo_trunc.8 = trunc i32 %P20_to_i32 to i1
  %isetrp_ex_lo_to_i32.8 = zext i1 %isetrp_ex_lo_trunc.8 to i32
  %isetrp_ex_lo_to_i1.8 = icmp ne i32 %isetrp_ex_lo_to_i32.8, 0
  %isetrp_hi_eq.8 = icmp eq i32 %phi.8, %"R7:R6_r1.4"
  %isetrp_ex_sel.8 = select i1 %isetrp_hi_eq.8, i1 %isetrp_ex_lo_to_i1.8, i1 %isetrp_cmp1.17
  %isetrp_src_to_i32.17 = zext i1 true to i32
  %isetrp_src_to_i1.17 = icmp ne i32 %isetrp_src_to_i32.17, 0
  %isetrp_cmp2.17 = and i1 %isetrp_ex_sel.8, %isetrp_src_to_i1.17
  %P21_to_i32 = zext i1 %isetrp_cmp2.17 to i32
  %imad_addend_r0_ext.8 = zext i32 %phi.11 to i64
  %imad_addend_packed_0.8 = or i64 0, %imad_addend_r0_ext.8
  %imad_addend_r1_ext.8 = zext i32 %phi.8 to i64
  %imad_addend_r1_shift.8 = shl i64 %imad_addend_r1_ext.8, 32
  %imad_addend_packed_1.8 = or i64 %imad_addend_packed_0.8, %imad_addend_r1_shift.8
  %imad_lhs_64.8 = zext i32 %R1_trunc to i64
  %imad_rhs_64.8 = zext i32 256 to i64
  %imad_tmp_64.8 = mul i64 %imad_lhs_64.8, %imad_rhs_64.8
  %imad.25 = add i64 %imad_tmp_64.8, %imad_addend_packed_1.8
  %"R9:R8_r0.1" = trunc i64 %imad.25 to i32
  %"R9:R8_r1_shift.1" = lshr i64 %imad.25, 32
  %"R9:R8_r1.1" = trunc i64 %"R9:R8_r1_shift.1" to i32
  %isetrp_cmp1.18 = icmp uge i32 %"R9:R8_r0.1", %"R7:R6_r0.4"
  %isetrp_src_to_i32.18 = zext i1 true to i32
  %isetrp_src_to_i1.18 = icmp ne i32 %isetrp_src_to_i32.18, 0
  %isetrp_cmp2.18 = and i1 %isetrp_cmp1.18, %isetrp_src_to_i1.18
  %P29_to_i32 = zext i1 %isetrp_cmp2.18 to i32
  %isetrp_cmp1.19 = icmp sge i32 %"R9:R8_r1.1", %"R7:R6_r1.4"
  %isetrp_ex_lo_trunc.9 = trunc i32 %P29_to_i32 to i1
  %isetrp_ex_lo_to_i32.9 = zext i1 %isetrp_ex_lo_trunc.9 to i32
  %isetrp_ex_lo_to_i1.9 = icmp ne i32 %isetrp_ex_lo_to_i32.9, 0
  %isetrp_hi_eq.9 = icmp eq i32 %"R9:R8_r1.1", %"R7:R6_r1.4"
  %isetrp_ex_sel.9 = select i1 %isetrp_hi_eq.9, i1 %isetrp_ex_lo_to_i1.9, i1 %isetrp_cmp1.19
  %isetrp_src_to_i32.19 = zext i1 true to i32
  %isetrp_src_to_i1.19 = icmp ne i32 %isetrp_src_to_i32.19, 0
  %isetrp_cmp2.19 = and i1 %isetrp_ex_sel.9, %isetrp_src_to_i1.19
  %P30_to_i32 = zext i1 %isetrp_cmp2.19 to i32
  br label %BB_07c0

BB_07c0:                                          ; preds = %BB_0740
  %cond_trunc.7 = trunc i32 %P21_to_i32 to i1
  %pbra_cond_to_i32.7 = zext i1 %cond_trunc.7 to i32
  %pbra_cond_to_i1.7 = icmp ne i32 %pbra_cond_to_i32.7, 0
  br i1 %pbra_cond_to_i1.7, label %BB_08d0, label %BB_07d0

BB_07d0:                                          ; preds = %BB_07c0
  %iadd3_o1_64.2 = zext i32 %phi.11 to i64
  %iadd3_o2_64.3 = zext i32 1 to i64
  %iadd3_o3_64.3 = zext i32 0 to i64
  %iadd3_tmp.3 = add i64 %iadd3_o1_64.2, %iadd3_o2_64.3
  %iadd3_tmp2.3 = add i64 %iadd3_tmp.3, %iadd3_o3_64.3
  %iadd3_trunc.3 = trunc i64 %iadd3_tmp2.3 to i32
  %iadd3_carry_val.3 = lshr i64 %iadd3_tmp2.3, 32
  %carry_ge_1.3 = icmp uge i64 %iadd3_carry_val.3, 1
  %P25_to_i32 = zext i1 %carry_ge_1.3 to i32
  %imad_tmp.17 = mul i32 %phi.11, 4
  %imad.26 = add i32 %imad_tmp.17, 0
  %.174 = zext i32 %phi.11 to i64
  %.175 = zext i32 %phi.8 to i64
  %.176 = shl i64 %.175, 32
  %shf_concat.8 = or i64 %.174, %.176
  %shf_shift_64.8 = zext i32 2 to i64
  %.177 = shl i64 %shf_concat.8, %shf_shift_64.8
  %shf_hi.8 = lshr i64 %.177, 32
  %shf_result.8 = trunc i64 %shf_hi.8 to i32
  %isetrp_cmp1.20 = icmp uge i32 %iadd3_trunc.3, %"R7:R6_r0.4"
  %isetrp_src_to_i32.20 = zext i1 true to i32
  %isetrp_src_to_i1.20 = icmp ne i32 %isetrp_src_to_i32.20, 0
  %isetrp_cmp2.20 = and i1 %isetrp_cmp1.20, %isetrp_src_to_i1.20
  %P22_to_i32 = zext i1 %isetrp_cmp2.20 to i32
  %imad_tmp.18 = mul i32 0, 0
  %imad.27 = add i32 %imad_tmp.18, %phi.8
  %imad_cin_trunc.1 = trunc i32 %P25_to_i32 to i1
  %imad_cin_ext.1 = zext i1 %imad_cin_trunc.1 to i32
  %imad_with_cin.1 = add i32 %imad.27, %imad_cin_ext.1
  %isetrp_cmp1.21 = icmp sge i32 %imad_with_cin.1, %"R7:R6_r1.4"
  %isetrp_ex_lo_trunc.10 = trunc i32 %P22_to_i32 to i1
  %isetrp_ex_lo_to_i32.10 = zext i1 %isetrp_ex_lo_trunc.10 to i32
  %isetrp_ex_lo_to_i1.10 = icmp ne i32 %isetrp_ex_lo_to_i32.10, 0
  %isetrp_hi_eq.10 = icmp eq i32 %imad_with_cin.1, %"R7:R6_r1.4"
  %isetrp_ex_sel.10 = select i1 %isetrp_hi_eq.10, i1 %isetrp_ex_lo_to_i1.10, i1 %isetrp_cmp1.21
  %isetrp_src_to_i32.21 = zext i1 true to i32
  %isetrp_src_to_i1.21 = icmp ne i32 %isetrp_src_to_i32.21, 0
  %isetrp_cmp2.21 = and i1 %isetrp_ex_sel.10, %isetrp_src_to_i1.21
  %P24_to_i32 = zext i1 %isetrp_cmp2.21 to i32
  %iadd3_o1_64.3 = zext i32 %imad.26 to i64
  %iadd3_o2_64.4 = zext i32 %"UR5:UR4_r0.1" to i64
  %iadd3_o3_64.4 = zext i32 0 to i64
  %iadd3_tmp.4 = add i64 %iadd3_o1_64.3, %iadd3_o2_64.4
  %iadd3_tmp2.4 = add i64 %iadd3_tmp.4, %iadd3_o3_64.4
  %iadd3_trunc.4 = trunc i64 %iadd3_tmp2.4 to i32
  %iadd3_carry_val.4 = lshr i64 %iadd3_tmp2.4, 32
  %carry_ge_1.4 = icmp uge i64 %iadd3_carry_val.4, 1
  %P26_to_i32 = zext i1 %carry_ge_1.4 to i32
  %iadd3_o1_64.4 = zext i32 %imad.26 to i64
  %iadd3_o2_64.5 = zext i32 %"UR11:UR10_r0.2" to i64
  %iadd3_o3_64.5 = zext i32 0 to i64
  %iadd3_tmp.5 = add i64 %iadd3_o1_64.4, %iadd3_o2_64.5
  %iadd3_tmp2.5 = add i64 %iadd3_tmp.5, %iadd3_o3_64.5
  %iadd3_trunc.5 = trunc i64 %iadd3_tmp2.5 to i32
  %iadd3_carry_val.5 = lshr i64 %iadd3_tmp2.5, 32
  %carry_ge_1.5 = icmp uge i64 %iadd3_carry_val.5, 1
  %P28_to_i32 = zext i1 %carry_ge_1.5 to i32
  %iadd3_n1.3 = add i32 %shf_result.8, %"UR5:UR4_r1.1"
  %iadd3_n2.3 = add i32 %iadd3_n1.3, 0
  %iadd3_cin1_trunc.2 = trunc i32 %P26_to_i32 to i1
  %iadd3_cin1_narrow_zext.2 = zext i1 %iadd3_cin1_trunc.2 to i32
  %iadd3_cin1_add.2 = add i32 %iadd3_n2.3, %iadd3_cin1_narrow_zext.2
  %iadd3_cin2_narrow_zext.2 = zext i1 false to i32
  %iadd3_cin2_add.2 = add i32 %iadd3_cin1_add.2, %iadd3_cin2_narrow_zext.2
  %iadd3_n1.4 = add i32 %shf_result.8, %"UR11:UR10_r1.2"
  %iadd3_n2.4 = add i32 %iadd3_n1.4, 0
  %iadd3_cin1_trunc.3 = trunc i32 %P28_to_i32 to i1
  %iadd3_cin1_narrow_zext.3 = zext i1 %iadd3_cin1_trunc.3 to i32
  %iadd3_cin1_add.3 = add i32 %iadd3_n2.4, %iadd3_cin1_narrow_zext.3
  %iadd3_cin2_narrow_zext.3 = zext i1 false to i32
  %iadd3_cin2_add.3 = add i32 %iadd3_cin1_add.3, %iadd3_cin2_narrow_zext.3
  %ldg_addr_r0_ext.4 = zext i32 %iadd3_trunc.4 to i64
  %ldg_addr_packed_0.4 = or i64 0, %ldg_addr_r0_ext.4
  %ldg_addr_r1_ext.4 = zext i32 %iadd3_cin2_add.2 to i64
  %ldg_addr_r1_shift.4 = shl i64 %ldg_addr_r1_ext.4, 32
  %ldg_addr_packed_1.4 = or i64 %ldg_addr_packed_0.4, %ldg_addr_r1_shift.4
  %"R158:R24_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.4 to ptr addrspace(1)
  %ldg.4 = load float, ptr addrspace(1) %"R158:R24_addr_ptr", align 4
  br label %BB_0880

BB_0880:                                          ; preds = %BB_07d0
  %cond_trunc.8 = trunc i32 %P24_to_i32 to i1
  %cond_not.3 = xor i1 %cond_trunc.8, true
  %pbra_cond_to_i32.8 = zext i1 %cond_not.3 to i32
  %pbra_cond_to_i1.8 = icmp ne i32 %pbra_cond_to_i32.8, 0
  br i1 %pbra_cond_to_i1.8, label %BB_80000880, label %BB_0890

BB_80000880:                                      ; preds = %BB_0880
  %ldg_addr_r0_ext.5 = zext i32 %iadd3_trunc.4 to i64
  %ldg_addr_packed_0.5 = or i64 0, %ldg_addr_r0_ext.5
  %ldg_addr_r1_ext.5 = zext i32 %iadd3_cin2_add.2 to i64
  %ldg_addr_r1_shift.5 = shl i64 %ldg_addr_r1_ext.5, 32
  %ldg_addr_packed_1.5 = or i64 %ldg_addr_packed_0.5, %ldg_addr_r1_shift.5
  %ldg_addr_memaddr_offset_add = add i64 %ldg_addr_packed_1.5, 4
  %"R158:R24_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add to ptr addrspace(1)
  %ldg.5 = load float, ptr addrspace(1) %"R158:R24_addr_ptr.1", align 4
  br label %BB_0890

BB_0890:                                          ; preds = %BB_80000880, %BB_0880
  %phi.12 = phi float [ %ldg.5, %BB_80000880 ], [ %phi.6, %BB_0880 ]
  %ldg_addr_r0_ext.6 = zext i32 %iadd3_trunc.5 to i64
  %ldg_addr_packed_0.6 = or i64 0, %ldg_addr_r0_ext.6
  %ldg_addr_r1_ext.6 = zext i32 %iadd3_cin2_add.3 to i64
  %ldg_addr_r1_shift.6 = shl i64 %ldg_addr_r1_ext.6, 32
  %ldg_addr_packed_1.6 = or i64 %ldg_addr_packed_0.6, %ldg_addr_r1_shift.6
  %"R5:R169_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.6 to ptr addrspace(1)
  %ldg.6 = load float, ptr addrspace(1) %"R5:R169_addr_ptr", align 4
  br label %BB_08a0

BB_08a0:                                          ; preds = %BB_0890
  %cond_trunc.9 = trunc i32 %P24_to_i32 to i1
  %cond_not.4 = xor i1 %cond_trunc.9, true
  %pbra_cond_to_i32.9 = zext i1 %cond_not.4 to i32
  %pbra_cond_to_i1.9 = icmp ne i32 %pbra_cond_to_i32.9, 0
  br i1 %pbra_cond_to_i1.9, label %BB_800008a0, label %BB_08b0

BB_800008a0:                                      ; preds = %BB_08a0
  %ldg_addr_r0_ext.7 = zext i32 %iadd3_trunc.5 to i64
  %ldg_addr_packed_0.7 = or i64 0, %ldg_addr_r0_ext.7
  %ldg_addr_r1_ext.7 = zext i32 %iadd3_cin2_add.3 to i64
  %ldg_addr_r1_shift.7 = shl i64 %ldg_addr_r1_ext.7, 32
  %ldg_addr_packed_1.7 = or i64 %ldg_addr_packed_0.7, %ldg_addr_r1_shift.7
  %ldg_addr_memaddr_offset_add.1 = add i64 %ldg_addr_packed_1.7, 4
  %"R5:R169_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add.1 to ptr addrspace(1)
  %ldg.7 = load float, ptr addrspace(1) %"R5:R169_addr_ptr.1", align 4
  br label %BB_08b0

BB_08b0:                                          ; preds = %BB_800008a0, %BB_08a0
  %phi.13 = phi float [ %ldg.7, %BB_800008a0 ], [ %phi.7, %BB_08a0 ]
  %ffma.2 = call float @llvm.fma.f32(float %ldg.4, float %ldg.6, float %phi.9)
  br label %BB_08c0

BB_08c0:                                          ; preds = %BB_08b0
  %cond_trunc.10 = trunc i32 %P24_to_i32 to i1
  %cond_not.5 = xor i1 %cond_trunc.10, true
  %pbra_cond_to_i32.10 = zext i1 %cond_not.5 to i32
  %pbra_cond_to_i1.10 = icmp ne i32 %pbra_cond_to_i32.10, 0
  br i1 %pbra_cond_to_i1.10, label %BB_800008c0, label %BB_08d0

BB_800008c0:                                      ; preds = %BB_08c0
  %ffma.3 = call float @llvm.fma.f32(float %phi.12, float %phi.13, float %phi.10)
  br label %BB_08d0

BB_08d0:                                          ; preds = %BB_800008c0, %BB_08c0, %BB_07c0
  %phi.14 = phi float [ %phi.6, %BB_07c0 ], [ %phi.12, %BB_800008c0 ], [ %phi.12, %BB_08c0 ]
  %phi.15 = phi float [ %phi.7, %BB_07c0 ], [ %phi.13, %BB_800008c0 ], [ %phi.13, %BB_08c0 ]
  %phi.16 = phi float [ %phi.9, %BB_07c0 ], [ %ffma.2, %BB_800008c0 ], [ %ffma.2, %BB_08c0 ]
  %phi.17 = phi float [ %phi.10, %BB_07c0 ], [ %ffma.3, %BB_800008c0 ], [ %phi.10, %BB_08c0 ]
  br label %BB_0900

BB_0900:                                          ; preds = %BB_08d0
  %cond_trunc.11 = trunc i32 %P30_to_i32 to i1
  %cond_not.6 = xor i1 %cond_trunc.11, true
  %pbra_cond_to_i32.11 = zext i1 %cond_not.6 to i32
  %pbra_cond_to_i1.11 = icmp ne i32 %pbra_cond_to_i32.11, 0
  br i1 %pbra_cond_to_i1.11, label %BB_0740, label %BB_0910

BB_0910:                                          ; preds = %BB_0900, %BB_0710
  %phi.18 = phi float [ %phi_cast_R28_bitcast.1, %BB_0710 ], [ %phi.16, %BB_0900 ]
  %phi.19 = phi float [ %phi_cast_R22_bitcast, %BB_0710 ], [ %phi.17, %BB_0900 ]
  %fadd = fadd float 0.000000e+00, %phi.18
  %fadd.1 = fadd float %fadd, %phi.19
  br label %BB_0940

BB_0940:                                          ; preds = %BB_0910, %BB_0650, %BB_04f0, %BB_03f0, %BB_0160
  %phi.20 = phi float [ 0.000000e+00, %BB_0160 ], [ %ffma, %BB_03f0 ], [ 0.000000e+00, %BB_04f0 ], [ %ffma.1, %BB_0650 ], [ %fadd.1, %BB_0910 ]
  %s2ur_cluster_ctarank = call i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank()
  %isetrp_cmp1.22 = icmp sgt i32 %tid_x, 63
  %isetrp_src_to_i32.22 = zext i1 true to i32
  %isetrp_src_to_i1.22 = icmp ne i32 %isetrp_src_to_i32.22, 0
  %isetrp_cmp2.22 = and i1 %isetrp_cmp1.22, %isetrp_src_to_i1.22
  %P12_to_i32 = zext i1 %isetrp_cmp2.22 to i32
  %isetrp_cmp1.23 = icmp sgt i32 %tid_x, 31
  %isetrp_src_to_i32.23 = zext i1 true to i32
  %isetrp_src_to_i1.23 = icmp ne i32 %isetrp_src_to_i32.23, 0
  %isetrp_cmp2.23 = and i1 %isetrp_cmp1.23, %isetrp_src_to_i1.23
  %P11_to_i32 = zext i1 %isetrp_cmp2.23 to i32
  %.190 = zext i32 %s2ur_cluster_ctarank to i64
  %.191 = zext i32 1024 to i64
  %.192 = zext i32 24 to i64
  %.193 = shl i64 %.190, %.192
  %.194 = and i64 %.193, 4294967295
  %.195 = add i64 %.194, %.191
  %.196 = trunc i64 %.195 to i32
  %.197 = zext i32 %tid_x to i64
  %.198 = zext i32 %.196 to i64
  %.199 = zext i32 2 to i64
  %.200 = shl i64 %.197, %.199
  %.201 = and i64 %.200, 4294967295
  %.202 = add i64 %.201, %.198
  %.203 = trunc i64 %.202 to i32
  %.204 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast = bitcast ptr addrspace(3) %.204 to ptr addrspace(3)
  store volatile float %phi.20, ptr addrspace(3) %sts_shared_addr_cast, align 4
  call void @llvm.nvvm.barrier0()
  br label %BB_09c0

BB_09c0:                                          ; preds = %BB_0940
  %cond_trunc.12 = trunc i32 %P12_to_i32 to i1
  %cond_not.7 = xor i1 %cond_trunc.12, true
  %pbra_cond_to_i32.12 = zext i1 %cond_not.7 to i32
  %pbra_cond_to_i1.12 = icmp ne i32 %pbra_cond_to_i32.12, 0
  br i1 %pbra_cond_to_i1.12, label %BB_800009c0, label %BB_0a00

BB_800009c0:                                      ; preds = %BB_09c0
  %.208 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %lds_shared_addr_cast = bitcast ptr addrspace(3) %.208 to ptr addrspace(3)
  %lds = load volatile float, ptr addrspace(3) %lds_shared_addr_cast, align 4
  %lds_addr_memaddr_offset_add = add i32 %.203, 256
  %.209 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add
  %lds_shared_addr_cast.1 = bitcast ptr addrspace(3) %.209 to ptr addrspace(3)
  %lds.1 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.1, align 4
  %fadd.2 = fadd float %lds, %lds.1
  %.210 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast.1 = bitcast ptr addrspace(3) %.210 to ptr addrspace(3)
  store volatile float %fadd.2, ptr addrspace(3) %sts_shared_addr_cast.1, align 4
  br label %BB_0a00

BB_0a00:                                          ; preds = %BB_800009c0, %BB_09c0
  %warp_reconv_mask = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.24 = icmp sgt i32 %tid_x, 15
  %isetrp_src_to_i32.24 = zext i1 true to i32
  %isetrp_src_to_i1.24 = icmp ne i32 %isetrp_src_to_i32.24, 0
  %isetrp_cmp2.24 = and i1 %isetrp_cmp1.24, %isetrp_src_to_i1.24
  %P34_to_i32 = zext i1 %isetrp_cmp2.24 to i32
  br label %BB_0a20

BB_0a20:                                          ; preds = %BB_0a00
  %cond_trunc.13 = trunc i32 %P11_to_i32 to i1
  %cond_not.8 = xor i1 %cond_trunc.13, true
  %pbra_cond_to_i32.13 = zext i1 %cond_not.8 to i32
  %pbra_cond_to_i1.13 = icmp ne i32 %pbra_cond_to_i32.13, 0
  br i1 %pbra_cond_to_i1.13, label %BB_80000a20, label %BB_0a60

BB_80000a20:                                      ; preds = %BB_0a20
  %.215 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %lds_shared_addr_cast.2 = bitcast ptr addrspace(3) %.215 to ptr addrspace(3)
  %lds.2 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.2, align 4
  %lds_addr_memaddr_offset_add.1 = add i32 %.203, 128
  %.216 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.1
  %lds_shared_addr_cast.3 = bitcast ptr addrspace(3) %.216 to ptr addrspace(3)
  %lds.3 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.3, align 4
  %fadd.3 = fadd float %lds.2, %lds.3
  %.217 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast.2 = bitcast ptr addrspace(3) %.217 to ptr addrspace(3)
  store volatile float %fadd.3, ptr addrspace(3) %sts_shared_addr_cast.2, align 4
  br label %BB_0a60

BB_0a60:                                          ; preds = %BB_80000a20, %BB_0a20
  %warp_reconv_mask.1 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.25 = icmp sgt i32 %tid_x, 7
  %isetrp_src_to_i32.25 = zext i1 true to i32
  %isetrp_src_to_i1.25 = icmp ne i32 %isetrp_src_to_i32.25, 0
  %isetrp_cmp2.25 = and i1 %isetrp_cmp1.25, %isetrp_src_to_i1.25
  %P13_to_i32 = zext i1 %isetrp_cmp2.25 to i32
  br label %BB_0a80

BB_0a80:                                          ; preds = %BB_0a60
  %cond_trunc.14 = trunc i32 %P34_to_i32 to i1
  %cond_not.9 = xor i1 %cond_trunc.14, true
  %pbra_cond_to_i32.14 = zext i1 %cond_not.9 to i32
  %pbra_cond_to_i1.14 = icmp ne i32 %pbra_cond_to_i32.14, 0
  br i1 %pbra_cond_to_i1.14, label %BB_80000a80, label %BB_0ac0

BB_80000a80:                                      ; preds = %BB_0a80
  %.222 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %lds_shared_addr_cast.4 = bitcast ptr addrspace(3) %.222 to ptr addrspace(3)
  %lds.4 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.4, align 4
  %lds_addr_memaddr_offset_add.2 = add i32 %.203, 64
  %.223 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.2
  %lds_shared_addr_cast.5 = bitcast ptr addrspace(3) %.223 to ptr addrspace(3)
  %lds.5 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.5, align 4
  %fadd.4 = fadd float %lds.4, %lds.5
  %.224 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast.3 = bitcast ptr addrspace(3) %.224 to ptr addrspace(3)
  store volatile float %fadd.4, ptr addrspace(3) %sts_shared_addr_cast.3, align 4
  br label %BB_0ac0

BB_0ac0:                                          ; preds = %BB_80000a80, %BB_0a80
  %warp_reconv_mask.2 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.2)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.26 = icmp sgt i32 %tid_x, 3
  %isetrp_src_to_i32.26 = zext i1 true to i32
  %isetrp_src_to_i1.26 = icmp ne i32 %isetrp_src_to_i32.26, 0
  %isetrp_cmp2.26 = and i1 %isetrp_cmp1.26, %isetrp_src_to_i1.26
  %P36_to_i32 = zext i1 %isetrp_cmp2.26 to i32
  br label %BB_0ae0

BB_0ae0:                                          ; preds = %BB_0ac0
  %cond_trunc.15 = trunc i32 %P13_to_i32 to i1
  %cond_not.10 = xor i1 %cond_trunc.15, true
  %pbra_cond_to_i32.15 = zext i1 %cond_not.10 to i32
  %pbra_cond_to_i1.15 = icmp ne i32 %pbra_cond_to_i32.15, 0
  br i1 %pbra_cond_to_i1.15, label %BB_80000ae0, label %BB_0b20

BB_80000ae0:                                      ; preds = %BB_0ae0
  %.229 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %lds_shared_addr_cast.6 = bitcast ptr addrspace(3) %.229 to ptr addrspace(3)
  %lds.6 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.6, align 4
  %lds_addr_memaddr_offset_add.3 = add i32 %.203, 32
  %.230 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.3
  %lds_shared_addr_cast.7 = bitcast ptr addrspace(3) %.230 to ptr addrspace(3)
  %lds.7 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.7, align 4
  %fadd.5 = fadd float %lds.6, %lds.7
  %.231 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast.4 = bitcast ptr addrspace(3) %.231 to ptr addrspace(3)
  store volatile float %fadd.5, ptr addrspace(3) %sts_shared_addr_cast.4, align 4
  br label %BB_0b20

BB_0b20:                                          ; preds = %BB_80000ae0, %BB_0ae0
  %warp_reconv_mask.3 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.3)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.27 = icmp sgt i32 %tid_x, 1
  %isetrp_src_to_i32.27 = zext i1 true to i32
  %isetrp_src_to_i1.27 = icmp ne i32 %isetrp_src_to_i32.27, 0
  %isetrp_cmp2.27 = and i1 %isetrp_cmp1.27, %isetrp_src_to_i1.27
  %P14_to_i32 = zext i1 %isetrp_cmp2.27 to i32
  br label %BB_0b40

BB_0b40:                                          ; preds = %BB_0b20
  %cond_trunc.16 = trunc i32 %P36_to_i32 to i1
  %cond_not.11 = xor i1 %cond_trunc.16, true
  %pbra_cond_to_i32.16 = zext i1 %cond_not.11 to i32
  %pbra_cond_to_i1.16 = icmp ne i32 %pbra_cond_to_i32.16, 0
  br i1 %pbra_cond_to_i1.16, label %BB_80000b40, label %BB_0b80

BB_80000b40:                                      ; preds = %BB_0b40
  %.236 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %lds_shared_addr_cast.8 = bitcast ptr addrspace(3) %.236 to ptr addrspace(3)
  %lds.8 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.8, align 4
  %lds_addr_memaddr_offset_add.4 = add i32 %.203, 16
  %.237 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.4
  %lds_shared_addr_cast.9 = bitcast ptr addrspace(3) %.237 to ptr addrspace(3)
  %lds.9 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.9, align 4
  %fadd.6 = fadd float %lds.8, %lds.9
  %.238 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast.5 = bitcast ptr addrspace(3) %.238 to ptr addrspace(3)
  store volatile float %fadd.6, ptr addrspace(3) %sts_shared_addr_cast.5, align 4
  br label %BB_0b80

BB_0b80:                                          ; preds = %BB_80000b40, %BB_0b40
  %warp_reconv_mask.4 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.4)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.28 = icmp sgt i32 %tid_x, 0
  %isetrp_src_to_i32.28 = zext i1 true to i32
  %isetrp_src_to_i1.28 = icmp ne i32 %isetrp_src_to_i32.28, 0
  %isetrp_cmp2.28 = and i1 %isetrp_cmp1.28, %isetrp_src_to_i1.28
  %P37_to_i32 = zext i1 %isetrp_cmp2.28 to i32
  br label %BB_0ba0

BB_0ba0:                                          ; preds = %BB_0b80
  %cond_trunc.17 = trunc i32 %P14_to_i32 to i1
  %cond_not.12 = xor i1 %cond_trunc.17, true
  %pbra_cond_to_i32.17 = zext i1 %cond_not.12 to i32
  %pbra_cond_to_i1.17 = icmp ne i32 %pbra_cond_to_i32.17, 0
  br i1 %pbra_cond_to_i1.17, label %BB_80000ba0, label %BB_0be0

BB_80000ba0:                                      ; preds = %BB_0ba0
  %.243 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %lds_shared_addr_cast.10 = bitcast ptr addrspace(3) %.243 to ptr addrspace(3)
  %lds.10 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.10, align 4
  %lds_addr_memaddr_offset_add.5 = add i32 %.203, 8
  %.244 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.5
  %lds_shared_addr_cast.11 = bitcast ptr addrspace(3) %.244 to ptr addrspace(3)
  %lds.11 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.11, align 4
  %fadd.7 = fadd float %lds.10, %lds.11
  %.245 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast.6 = bitcast ptr addrspace(3) %.245 to ptr addrspace(3)
  store volatile float %fadd.7, ptr addrspace(3) %sts_shared_addr_cast.6, align 4
  br label %BB_0be0

BB_0be0:                                          ; preds = %BB_80000ba0, %BB_0ba0
  %warp_reconv_mask.5 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.5)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.29 = icmp ne i32 %tid_x, 0
  %isetrp_src_to_i32.29 = zext i1 true to i32
  %isetrp_src_to_i1.29 = icmp ne i32 %isetrp_src_to_i32.29, 0
  %isetrp_cmp2.29 = and i1 %isetrp_cmp1.29, %isetrp_src_to_i1.29
  %P16_to_i32 = zext i1 %isetrp_cmp2.29 to i32
  br label %BB_0c00

BB_0c00:                                          ; preds = %BB_0be0
  %cond_trunc.18 = trunc i32 %P37_to_i32 to i1
  %cond_not.13 = xor i1 %cond_trunc.18, true
  %pbra_cond_to_i32.18 = zext i1 %cond_not.13 to i32
  %pbra_cond_to_i1.18 = icmp ne i32 %pbra_cond_to_i32.18, 0
  br i1 %pbra_cond_to_i1.18, label %BB_80000c00, label %BB_0c40

BB_80000c00:                                      ; preds = %BB_0c00
  %.250 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %lds_shared_addr_cast.12 = bitcast ptr addrspace(3) %.250 to ptr addrspace(3)
  %lds.12 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.12, align 4
  %lds_addr_memaddr_offset_add.6 = add i32 %.203, 4
  %.251 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.6
  %lds_shared_addr_cast.13 = bitcast ptr addrspace(3) %.251 to ptr addrspace(3)
  %lds.13 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.13, align 4
  %fadd.8 = fadd float %lds.12, %lds.13
  %.252 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  %sts_shared_addr_cast.7 = bitcast ptr addrspace(3) %.252 to ptr addrspace(3)
  store volatile float %fadd.8, ptr addrspace(3) %sts_shared_addr_cast.7, align 4
  br label %BB_0c40

BB_0c40:                                          ; preds = %BB_80000c00, %BB_0c00
  %warp_reconv_mask.6 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.6)
  %cond_trunc.19 = trunc i32 %P16_to_i32 to i1
  %pbra_cond_to_i32.19 = zext i1 %cond_trunc.19 to i32
  %pbra_cond_to_i1.19 = icmp ne i32 %pbra_cond_to_i32.19, 0
  br i1 %pbra_cond_to_i1.19, label %BB_80000c40, label %BB_0c50

BB_0c50:                                          ; preds = %BB_0c40
  %.256 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.196
  %lds_shared_addr_cast.14 = bitcast ptr addrspace(3) %.256 to ptr addrspace(3)
  %lds.14 = load volatile i32, ptr addrspace(3) %lds_shared_addr_cast.14, align 4
  %s2ur_ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %.257 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 552
  %.258 = bitcast ptr %.257 to ptr
  %ldc_const.12 = load i64, ptr %.258, align 8
  %"R5:R4_r0" = trunc i64 %ldc_const.12 to i32
  %"R5:R4_r1_shift" = lshr i64 %ldc_const.12, 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %.259 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 544
  %.260 = bitcast ptr %.259 to ptr
  %ldc_const.13 = load i64, ptr %.260, align 8
  %"R9:R8_r0.2" = trunc i64 %ldc_const.13 to i32
  %"R9:R8_r1_shift.2" = lshr i64 %ldc_const.13, 32
  %"R9:R8_r1.2" = trunc i64 %"R9:R8_r1_shift.2" to i32
  %imad_addend_r0_ext.9 = zext i32 %ctaid_x to i64
  %imad_addend_packed_0.9 = or i64 0, %imad_addend_r0_ext.9
  %imad_addend_r1_ext.9 = zext i32 0 to i64
  %imad_addend_r1_shift.9 = shl i64 %imad_addend_r1_ext.9, 32
  %imad_addend_packed_1.9 = or i64 %imad_addend_packed_0.9, %imad_addend_r1_shift.9
  %imad_lhs_64.9 = zext i32 %"R5:R4_r0" to i64
  %imad_rhs_64.9 = zext i32 %s2ur_ctaid_z to i64
  %imad_tmp_64.9 = mul i64 %imad_lhs_64.9, %imad_rhs_64.9
  %imad.28 = add i64 %imad_tmp_64.9, %imad_addend_packed_1.9
  %"R3:R2_r0" = trunc i64 %imad.28 to i32
  %"R3:R2_r1_shift" = lshr i64 %imad.28, 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %imad_tmp.19 = mul i32 %"R5:R4_r1", %s2ur_ctaid_z
  %imad.29 = add i32 %imad_tmp.19, %"R3:R2_r1"
  %.261 = zext i32 %"R3:R2_r0" to i64
  %.262 = zext i32 %"R9:R8_r0.2" to i64
  %.263 = zext i32 2 to i64
  %.264 = shl i64 %.261, %.263
  %.265 = and i64 %.264, 4294967295
  %.266 = add i64 %.265, %.262
  %.267 = trunc i64 %.266 to i32
  %.268 = lshr i64 %.266, 32
  %.269 = trunc i64 %.268 to i1
  %P39_to_i32 = zext i1 %.269 to i32
  %.270 = zext i32 %"R3:R2_r0" to i64
  %.271 = zext i32 %imad.29 to i64
  %.272 = shl i64 %.271, 32
  %lea_funnel.3 = or i64 %.270, %.272
  %.273 = zext i32 %"R9:R8_r1.2" to i64
  %.274 = zext i32 2 to i64
  %.275 = shl i64 %lea_funnel.3, %.274
  %.276 = lshr i64 %.275, 32
  %.277 = add i64 %.276, %.273
  %lea_cin_trunc.3 = trunc i32 %P39_to_i32 to i1
  %.278 = zext i1 %lea_cin_trunc.3 to i64
  %.279 = add i64 %.277, %.278
  %.280 = trunc i64 %.279 to i32
  %stg_addr_r0_ext = zext i32 %.267 to i64
  %stg_addr_packed_0 = or i64 0, %stg_addr_r0_ext
  %stg_addr_r1_ext = zext i32 %.280 to i64
  %stg_addr_r1_shift = shl i64 %stg_addr_r1_ext, 32
  %stg_addr_packed_1 = or i64 %stg_addr_packed_0, %stg_addr_r1_shift
  %"R99:R82_addr_ptr" = inttoptr i64 %stg_addr_packed_1 to ptr addrspace(1)
  store i32 %lds.14, ptr addrspace(1) %"R99:R82_addr_ptr", align 4
  ret void

BB_80000c40:                                      ; preds = %BB_0c40
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank() #0

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #1

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.activemask() #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #0

define void @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE(i64 %arg_528, i32 %arg_536, i128 %arg_544, i32 %arg_560, i64 %arg_568, i32 %arg_576, i64 %arg_584, i64 %arg_592, i32 %arg_600, i32 %arg_604, i128 %arg_608) {
EntryBB_0000:
  %local_mem = alloca [32768 x i8], align 16
  %param_local = alloca [624 x i8], align 16
  %.13 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 528
  %.14 = bitcast ptr %.13 to ptr
  store i64 %arg_528, ptr %.14, align 16
  %.16 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 536
  %.17 = bitcast ptr %.16 to ptr
  store i32 %arg_536, ptr %.17, align 8
  %.19 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 544
  %.20 = bitcast ptr %.19 to ptr
  store i128 %arg_544, ptr %.20, align 32
  %.22 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 560
  %.23 = bitcast ptr %.22 to ptr
  store i32 %arg_560, ptr %.23, align 16
  %.25 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 568
  %.26 = bitcast ptr %.25 to ptr
  store i64 %arg_568, ptr %.26, align 8
  %.28 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 576
  %.29 = bitcast ptr %.28 to ptr
  store i32 %arg_576, ptr %.29, align 64
  %.31 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 584
  %.32 = bitcast ptr %.31 to ptr
  store i64 %arg_584, ptr %.32, align 8
  %.34 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 592
  %.35 = bitcast ptr %.34 to ptr
  store i64 %arg_592, ptr %.35, align 16
  %.37 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 600
  %.38 = bitcast ptr %.37 to ptr
  store i32 %arg_600, ptr %.38, align 8
  %.40 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 604
  %.41 = bitcast ptr %.40 to ptr
  store i32 %arg_604, ptr %.41, align 4
  %.43 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 608
  %.44 = bitcast ptr %.43 to ptr
  store i128 %arg_608, ptr %.44, align 32
  %.46 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 600
  %.47 = bitcast ptr %.46 to ptr
  %ldc_const = load i32, ptr %.47, align 4
  %isetrp_cmp1 = icmp ne i32 0, %ldc_const
  %isetrp_src_to_i32 = zext i1 true to i32
  %isetrp_src_to_i1 = icmp ne i32 %isetrp_src_to_i32, 0
  %isetrp_cmp2 = and i1 %isetrp_cmp1, %isetrp_src_to_i1
  %P1_to_i32 = zext i1 %isetrp_cmp2 to i32
  %.48 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 536
  %.49 = bitcast ptr %.48 to ptr
  %ldc_const.1 = load i32, ptr %.49, align 4
  %.50 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 604
  %.51 = bitcast ptr %.50 to ptr
  %ldc_const.2 = load i32, ptr %.51, align 4
  %imad_tmp = mul i32 0, 0
  %imad = add i32 %imad_tmp, %ldc_const.1
  br label %BB_0070

BB_0070:                                          ; preds = %EntryBB_0000
  %cond_trunc = trunc i32 %P1_to_i32 to i1
  %pbra_cond_to_i32 = zext i1 %cond_trunc to i32
  %pbra_cond_to_i1 = icmp ne i32 %pbra_cond_to_i32, 0
  %phi_cast_R1_bitcast = bitcast i32 %imad to float
  br i1 %pbra_cond_to_i1, label %BB_80000070, label %BB_00a0

BB_80000070:                                      ; preds = %BB_0070
  %.54 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 528
  %.55 = bitcast ptr %.54 to ptr
  %ldc_const.3 = load i64, ptr %.55, align 8
  %"R5:R4_r0" = trunc i64 %ldc_const.3 to i32
  %"R5:R4_r1_shift" = lshr i64 %ldc_const.3, 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %.56 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 568
  %.57 = bitcast ptr %.56 to ptr
  %ldc_const.4 = load i64, ptr %.57, align 8
  %"R7:R6_r0" = trunc i64 %ldc_const.4 to i32
  %"R7:R6_r1_shift" = lshr i64 %ldc_const.4, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %ldg_addr_r0_ext = zext i32 %"R5:R4_r0" to i64
  %ldg_addr_packed_0 = or i64 0, %ldg_addr_r0_ext
  %ldg_addr_r1_ext = zext i32 %"R5:R4_r1" to i64
  %ldg_addr_r1_shift = shl i64 %ldg_addr_r1_ext, 32
  %ldg_addr_packed_1 = or i64 %ldg_addr_packed_0, %ldg_addr_r1_shift
  %"R300:R289_addr_ptr" = inttoptr i64 %ldg_addr_packed_1 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R300:R289_addr_ptr", align 4
  br label %BB_00a0

BB_00a0:                                          ; preds = %BB_80000070, %BB_0070
  %phi = phi i32 [ %"R7:R6_r1", %BB_80000070 ], [ 0, %BB_0070 ]
  %phi.1 = phi i32 [ %"R7:R6_r0", %BB_80000070 ], [ 0, %BB_0070 ]
  %phi.2 = phi float [ %ldg, %BB_80000070 ], [ %phi_cast_R1_bitcast, %BB_0070 ]
  %.59 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 576
  %.60 = bitcast ptr %.59 to ptr
  %ldc_const.5 = load i32, ptr %.60, align 4
  %imad_tmp.1 = mul i32 0, 0
  %imad.1 = add i32 %imad_tmp.1, %ldc_const.5
  br label %BB_00c0

BB_00c0:                                          ; preds = %BB_00a0
  %cond_trunc.1 = trunc i32 %P1_to_i32 to i1
  %pbra_cond_to_i32.1 = zext i1 %cond_trunc.1 to i32
  %pbra_cond_to_i1.1 = icmp ne i32 %pbra_cond_to_i32.1, 0
  %phi_cast_R157_bitcast = bitcast i32 %imad.1 to float
  br i1 %pbra_cond_to_i1.1, label %BB_800000c0, label %BB_00d0

BB_800000c0:                                      ; preds = %BB_00c0
  %ldg_addr_r0_ext.1 = zext i32 %phi.1 to i64
  %ldg_addr_packed_0.1 = or i64 0, %ldg_addr_r0_ext.1
  %ldg_addr_r1_ext.1 = zext i32 %phi to i64
  %ldg_addr_r1_shift.1 = shl i64 %ldg_addr_r1_ext.1, 32
  %ldg_addr_packed_1.1 = or i64 %ldg_addr_packed_0.1, %ldg_addr_r1_shift.1
  %"R39:R20_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.1 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R39:R20_addr_ptr", align 4
  br label %BB_00d0

BB_00d0:                                          ; preds = %BB_800000c0, %BB_00c0
  %phi.3 = phi float [ %ldg.1, %BB_800000c0 ], [ %phi_cast_R157_bitcast, %BB_00c0 ]
  %lop3_a_cast_zext = zext i1 true to i32
  %lop3_b_cast_zext = zext i1 true to i32
  %lop3_c_cast_zext = zext i1 true to i32
  %plop3_a_bit = and i32 %lop3_a_cast_zext, 1
  %plop3_b_bit = and i32 %lop3_b_cast_zext, 1
  %plop3_c_bit = and i32 %lop3_c_cast_zext, 1
  %.64 = xor i32 %plop3_a_bit, 1
  %.65 = xor i32 %plop3_b_bit, 1
  %.66 = xor i32 %plop3_c_bit, 1
  %.67 = and i32 %.64, %plop3_b_bit
  %.68 = and i32 %.67, %plop3_c_bit
  %lop3_pred_cmp = icmp ne i32 %.68, 0
  %lop3_q_to_i32 = zext i1 false to i32
  %lop3_q_to_i1 = icmp ne i32 %lop3_q_to_i32, 0
  %lop3_p = or i1 %lop3_pred_cmp, %lop3_q_to_i1
  %P70_to_i32 = zext i1 %lop3_p to i32
  %isetrp_cmp1.1 = icmp eq i32 %ldc_const.2, 1
  %isetrp_src_to_i32.1 = zext i1 true to i32
  %isetrp_src_to_i1.1 = icmp ne i32 %isetrp_src_to_i32.1, 0
  %isetrp_cmp2.1 = and i1 %isetrp_cmp1.1, %isetrp_src_to_i1.1
  %P67_to_i32 = zext i1 %isetrp_cmp2.1 to i32
  %fsetrp_cmp1 = fcmp une float %phi.2, 0.000000e+00
  %fsetrp_cmp2 = and i1 %fsetrp_cmp1, true
  %P42_to_i32 = zext i1 %fsetrp_cmp2 to i32
  br label %BB_0100

BB_0100:                                          ; preds = %BB_00d0
  %cond_trunc.2 = trunc i32 %P42_to_i32 to i1
  %cond_not = xor i1 %cond_trunc.2, true
  %pbra_cond_to_i32.2 = zext i1 %cond_not to i32
  %pbra_cond_to_i1.2 = icmp ne i32 %pbra_cond_to_i32.2, 0
  br i1 %pbra_cond_to_i1.2, label %BB_80000100, label %BB_0150

BB_80000100:                                      ; preds = %BB_0100
  %.71 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 584
  %.72 = bitcast ptr %.71 to ptr
  %ldc_const.6 = load i64, ptr %.72, align 8
  %"R9:R8_r0" = trunc i64 %ldc_const.6 to i32
  %"R9:R8_r1_shift" = lshr i64 %ldc_const.6, 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %fsetrp_cmp1.1 = fcmp une float %phi.3, 1.000000e+00
  %fsetrp_cmp2.1 = and i1 %fsetrp_cmp1.1, true
  %P65_to_i32 = zext i1 %fsetrp_cmp2.1 to i32
  %.73 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 592
  %.74 = bitcast ptr %.73 to ptr
  %ldc_const.7 = load i64, ptr %.74, align 8
  %"R11:R10_r0" = trunc i64 %ldc_const.7 to i32
  %"R11:R10_r1_shift" = lshr i64 %ldc_const.7, 32
  %"R11:R10_r1" = trunc i64 %"R11:R10_r1_shift" to i32
  %isetrp_cmp1.2 = icmp eq i32 %"R9:R8_r0", %"R11:R10_r0"
  %isetrp_src_to_i32.2 = zext i1 true to i32
  %isetrp_src_to_i1.2 = icmp ne i32 %isetrp_src_to_i32.2, 0
  %isetrp_cmp2.2 = and i1 %isetrp_cmp1.2, %isetrp_src_to_i1.2
  %P35_to_i32 = zext i1 %isetrp_cmp2.2 to i32
  %isetrp_src_trunc = trunc i32 %P65_to_i32 to i1
  %isetrp_src_not = xor i1 %isetrp_src_trunc, true
  %isetrp_cmp1.3 = icmp eq i32 %"R9:R8_r1", %"R11:R10_r1"
  %isetrp_ex_lo_trunc = trunc i32 %P35_to_i32 to i1
  %isetrp_ex_lo_to_i32 = zext i1 %isetrp_ex_lo_trunc to i32
  %isetrp_ex_lo_to_i1 = icmp ne i32 %isetrp_ex_lo_to_i32, 0
  %isetrp_hi_eq = icmp eq i32 %"R9:R8_r1", %"R11:R10_r1"
  %isetrp_ex_sel = select i1 %isetrp_hi_eq, i1 %isetrp_ex_lo_to_i1, i1 %isetrp_cmp1.3
  %isetrp_src_to_i32.3 = zext i1 %isetrp_src_not to i32
  %isetrp_src_to_i1.3 = icmp ne i32 %isetrp_src_to_i32.3, 0
  %isetrp_cmp2.3 = and i1 %isetrp_ex_sel, %isetrp_src_to_i1.3
  %P13_to_i32 = zext i1 %isetrp_cmp2.3 to i32
  br label %BB_0150

BB_0150:                                          ; preds = %BB_80000100, %BB_0100
  %phi.4 = phi i32 [ %"R9:R8_r1", %BB_80000100 ], [ 0, %BB_0100 ]
  %phi.5 = phi i32 [ %"R9:R8_r0", %BB_80000100 ], [ 0, %BB_0100 ]
  %phi.6 = phi i32 [ %P13_to_i32, %BB_80000100 ], [ %P70_to_i32, %BB_0100 ]
  %cond_trunc.3 = trunc i32 %phi.6 to i1
  %pbra_cond_to_i32.3 = zext i1 %cond_trunc.3 to i32
  %pbra_cond_to_i1.3 = icmp ne i32 %pbra_cond_to_i32.3, 0
  br i1 %pbra_cond_to_i1.3, label %BB_80000150, label %BB_0160

BB_80000150:                                      ; preds = %BB_0150
  %exit_guard_trunc = trunc i32 %P67_to_i32 to i1
  %exit_guard_to_i32 = zext i1 %exit_guard_trunc to i32
  %exit_guard_to_i1 = icmp ne i32 %exit_guard_to_i32, 0
  br i1 %exit_guard_to_i1, label %exit_0150, label %BB_0160

BB_0160:                                          ; preds = %BB_80000150, %BB_0150
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %ntid_x = call i32 @llvm.nvvm.read.ptx.sreg.ntid.x()
  %R203_zext = zext i32 %ntid_x to i64
  %R3_trunc = trunc i64 %R203_zext to i32
  %.79 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 560
  %.80 = bitcast ptr %.79 to ptr
  %ldc_const.8 = load i32, ptr %.80, align 4
  %isetrp_cmp1.4 = icmp uge i32 %R3_trunc, %ldc_const.8
  %isetrp_src_to_i32.4 = zext i1 true to i32
  %isetrp_src_to_i1.4 = icmp ne i32 %isetrp_src_to_i32.4, 0
  %isetrp_cmp2.4 = and i1 %isetrp_cmp1.4, %isetrp_src_to_i1.4
  %P23_to_i32 = zext i1 %isetrp_cmp2.4 to i32
  %isetrp_src_trunc.1 = trunc i32 %P42_to_i32 to i1
  %isetrp_src_not.1 = xor i1 %isetrp_src_trunc.1, true
  %isetrp_cmp1.5 = icmp sge i32 %tid_x, %ldc_const.8
  %isetrp_src_to_i32.5 = zext i1 %isetrp_src_not.1 to i32
  %isetrp_src_to_i1.5 = icmp ne i32 %isetrp_src_to_i32.5, 0
  %isetrp_cmp2.5 = or i1 %isetrp_cmp1.5, %isetrp_src_to_i1.5
  %P33_to_i32 = zext i1 %isetrp_cmp2.5 to i32
  br label %BB_01d0

BB_01d0:                                          ; preds = %BB_0160
  %cond_trunc.4 = trunc i32 %P33_to_i32 to i1
  %pbra_cond_to_i32.4 = zext i1 %cond_trunc.4 to i32
  %pbra_cond_to_i1.4 = icmp ne i32 %pbra_cond_to_i32.4, 0
  br i1 %pbra_cond_to_i1.4, label %BB_0290, label %BB_01e0

BB_01e0:                                          ; preds = %BB_01d0
  %s2ur_ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %.83 = zext i32 0 to i64
  %.84 = zext i32 %tid_x to i64
  %.85 = shl i64 %.84, 32
  %shf_concat = or i64 %.83, %.85
  %shf_shift_64 = zext i32 31 to i64
  %.86 = ashr i64 %shf_concat, %shf_shift_64
  %shf_hi = lshr i64 %.86, 32
  %shf_result = trunc i64 %shf_hi to i32
  %.87 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 544
  %.88 = bitcast ptr %.87 to ptr
  %ldc_const.9 = load i64, ptr %.88, align 8
  %"UR7:UR6_r0" = trunc i64 %ldc_const.9 to i32
  %"UR7:UR6_r1_shift" = lshr i64 %ldc_const.9, 32
  %"UR7:UR6_r1" = trunc i64 %"UR7:UR6_r1_shift" to i32
  %.89 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 552
  %.90 = bitcast ptr %.89 to ptr
  %ldc_const.10 = load i64, ptr %.90, align 8
  %"R9:R8_r0.1" = trunc i64 %ldc_const.10 to i32
  %"R9:R8_r1_shift.1" = lshr i64 %ldc_const.10, 32
  %"R9:R8_r1.1" = trunc i64 %"R9:R8_r1_shift.1" to i32
  %imad_addend_r0_ext = zext i32 %tid_x to i64
  %imad_addend_packed_0 = or i64 0, %imad_addend_r0_ext
  %imad_addend_r1_ext = zext i32 %shf_result to i64
  %imad_addend_r1_shift = shl i64 %imad_addend_r1_ext, 32
  %imad_addend_packed_1 = or i64 %imad_addend_packed_0, %imad_addend_r1_shift
  %imad_lhs_64 = zext i32 %"R9:R8_r0.1" to i64
  %imad_rhs_64 = zext i32 %s2ur_ctaid_z to i64
  %imad_tmp_64 = mul i64 %imad_lhs_64, %imad_rhs_64
  %imad.2 = add i64 %imad_tmp_64, %imad_addend_packed_1
  %"R7:R6_r0.1" = trunc i64 %imad.2 to i32
  %"R7:R6_r1_shift.1" = lshr i64 %imad.2, 32
  %"R7:R6_r1.1" = trunc i64 %"R7:R6_r1_shift.1" to i32
  %imad_tmp.2 = mul i32 %"R9:R8_r1.1", %s2ur_ctaid_z
  %imad.3 = add i32 %imad_tmp.2, %"R7:R6_r1.1"
  %.91 = zext i32 %"R7:R6_r0.1" to i64
  %.92 = zext i32 %"UR7:UR6_r0" to i64
  %.93 = zext i32 2 to i64
  %.94 = shl i64 %.91, %.93
  %.95 = and i64 %.94, 4294967295
  %.96 = add i64 %.95, %.92
  %.97 = trunc i64 %.96 to i32
  %.98 = lshr i64 %.96, 32
  %.99 = trunc i64 %.98 to i1
  %P39_to_i32 = zext i1 %.99 to i32
  %.100 = zext i32 %"R7:R6_r0.1" to i64
  %.101 = zext i32 %imad.3 to i64
  %.102 = shl i64 %.101, 32
  %lea_funnel = or i64 %.100, %.102
  %.103 = zext i32 %"UR7:UR6_r1" to i64
  %.104 = zext i32 2 to i64
  %.105 = shl i64 %lea_funnel, %.104
  %.106 = lshr i64 %.105, 32
  %.107 = add i64 %.106, %.103
  %lea_cin_trunc = trunc i32 %P39_to_i32 to i1
  %.108 = zext i1 %lea_cin_trunc to i64
  %.109 = add i64 %.107, %.108
  %.110 = trunc i64 %.109 to i32
  %ldg_addr_r0_ext.2 = zext i32 %.97 to i64
  %ldg_addr_packed_0.2 = or i64 0, %ldg_addr_r0_ext.2
  %ldg_addr_r1_ext.2 = zext i32 %.110 to i64
  %ldg_addr_r1_shift.2 = shl i64 %ldg_addr_r1_ext.2, 32
  %ldg_addr_packed_1.2 = or i64 %ldg_addr_packed_0.2, %ldg_addr_r1_shift.2
  %"R161:R92_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.2 to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R161:R92_addr_ptr", align 4
  br label %BB_0290

BB_0290:                                          ; preds = %BB_01e0, %BB_01d0
  %phi.7 = phi i32 [ %.110, %BB_01e0 ], [ %phi.4, %BB_01d0 ]
  %phi.8 = phi i32 [ %.97, %BB_01e0 ], [ %phi.5, %BB_01d0 ]
  %phi.9 = phi float [ %ldg.2, %BB_01e0 ], [ 0.000000e+00, %BB_01d0 ]
  %cond_trunc.5 = trunc i32 %P23_to_i32 to i1
  %pbra_cond_to_i32.5 = zext i1 %cond_trunc.5 to i32
  %pbra_cond_to_i1.5 = icmp ne i32 %pbra_cond_to_i32.5, 0
  br i1 %pbra_cond_to_i1.5, label %BB_0900, label %BB_02a0

BB_02a0:                                          ; preds = %BB_0290
  %imad_tmp.3 = mul i32 %tid_x, 1
  %imad.4 = add i32 %imad_tmp.3, %R3_trunc
  %.113 = zext i32 0 to i64
  %.114 = zext i32 %ldc_const.8 to i64
  %.115 = shl i64 %.114, 32
  %shf_concat.1 = or i64 %.113, %.115
  %shf_shift_64.1 = zext i32 31 to i64
  %.116 = ashr i64 %shf_concat.1, %shf_shift_64.1
  %shf_hi.1 = lshr i64 %.116, 32
  %shf_result.1 = trunc i64 %shf_hi.1 to i32
  %isetrp_cmp1.6 = icmp uge i32 %imad.4, %ldc_const.8
  %isetrp_src_to_i32.6 = zext i1 true to i32
  %isetrp_src_to_i1.6 = icmp ne i32 %isetrp_src_to_i32.6, 0
  %isetrp_cmp2.6 = and i1 %isetrp_cmp1.6, %isetrp_src_to_i1.6
  %P40_to_i32 = zext i1 %isetrp_cmp2.6 to i32
  %isetrp_cmp1.7 = icmp sge i32 0, %shf_result.1
  %isetrp_ex_lo_trunc.1 = trunc i32 %P40_to_i32 to i1
  %isetrp_ex_lo_to_i32.1 = zext i1 %isetrp_ex_lo_trunc.1 to i32
  %isetrp_ex_lo_to_i1.1 = icmp ne i32 %isetrp_ex_lo_to_i32.1, 0
  %isetrp_hi_eq.1 = icmp eq i32 0, %shf_result.1
  %isetrp_ex_sel.1 = select i1 %isetrp_hi_eq.1, i1 %isetrp_ex_lo_to_i1.1, i1 %isetrp_cmp1.7
  %isetrp_src_to_i32.7 = zext i1 true to i32
  %isetrp_src_to_i1.7 = icmp ne i32 %isetrp_src_to_i32.7, 0
  %isetrp_cmp2.7 = and i1 %isetrp_ex_sel.1, %isetrp_src_to_i1.7
  %P41_to_i32 = zext i1 %isetrp_cmp2.7 to i32
  br label %BB_02f0

BB_02f0:                                          ; preds = %BB_02a0
  %cond_trunc.6 = trunc i32 %P41_to_i32 to i1
  %pbra_cond_to_i32.6 = zext i1 %cond_trunc.6 to i32
  %pbra_cond_to_i1.6 = icmp ne i32 %pbra_cond_to_i32.6, 0
  br i1 %pbra_cond_to_i1.6, label %BB_0900, label %BB_0300

BB_0300:                                          ; preds = %BB_02f0
  %cond_trunc.7 = trunc i32 %P42_to_i32 to i1
  %cond_not.1 = xor i1 %cond_trunc.7, true
  %pbra_cond_to_i32.7 = zext i1 %cond_not.1 to i32
  %pbra_cond_to_i1.7 = icmp ne i32 %pbra_cond_to_i32.7, 0
  br i1 %pbra_cond_to_i1.7, label %BB_0900, label %BB_0310

BB_0310:                                          ; preds = %BB_0300
  %.120 = xor i32 0, -1
  %.121 = xor i32 %imad.4, -1
  %.122 = xor i32 0, -1
  %.123 = and i32 %.120, %.121
  %.124 = and i32 %.123, %.122
  %.125 = and i32 %.120, %.121
  %.126 = and i32 %.125, 0
  %.127 = or i32 %.124, %.126
  %.128 = and i32 0, %.121
  %.129 = and i32 %.128, %.122
  %.130 = or i32 %.127, %.129
  %.131 = and i32 0, %.121
  %.132 = and i32 %.131, 0
  %.133 = or i32 %.130, %.132
  %ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %.134 = xor i32 0, -1
  %.135 = xor i32 0, -1
  %.136 = xor i32 0, -1
  %.137 = and i32 %.134, %.135
  %.138 = and i32 %.137, %.136
  %.139 = and i32 %.134, %.135
  %.140 = and i32 %.139, 0
  %.141 = or i32 %.138, %.140
  %.142 = and i32 0, %.135
  %.143 = and i32 %.142, %.136
  %.144 = or i32 %.141, %.143
  %.145 = and i32 0, %.135
  %.146 = and i32 %.145, 0
  %.147 = or i32 %.144, %.146
  %iadd3_o1_64 = zext i32 %.133 to i64
  %iadd3_o2_64 = zext i32 %ldc_const.8 to i64
  %iadd3_o3_64 = zext i32 0 to i64
  %iadd3_tmp = add i64 %iadd3_o1_64, %iadd3_o2_64
  %iadd3_tmp2 = add i64 %iadd3_tmp, %iadd3_o3_64
  %iadd3_trunc = trunc i64 %iadd3_tmp2 to i32
  %iadd3_carry_val = lshr i64 %iadd3_tmp2, 32
  %carry_ge_1 = icmp uge i64 %iadd3_carry_val, 1
  %P9_to_i32 = zext i1 %carry_ge_1 to i32
  %iadd3_n1 = add i32 %.147, %shf_result.1
  %iadd3_n2 = add i32 %iadd3_n1, 0
  %iadd3_cin1_trunc = trunc i32 %P9_to_i32 to i1
  %iadd3_cin1_narrow_zext = zext i1 %iadd3_cin1_trunc to i32
  %iadd3_cin1_add = add i32 %iadd3_n2, %iadd3_cin1_narrow_zext
  %iadd3_cin2_narrow_zext = zext i1 false to i32
  %iadd3_cin2_add = add i32 %iadd3_cin1_add, %iadd3_cin2_narrow_zext
  %isetrp_cmp1.8 = icmp ne i32 %iadd3_cin2_add, 0
  %isetrp_src_to_i32.8 = zext i1 true to i32
  %isetrp_src_to_i1.8 = icmp ne i32 %isetrp_src_to_i32.8, 0
  %isetrp_cmp2.8 = and i1 %isetrp_cmp1.8, %isetrp_src_to_i1.8
  %P20_to_i32 = zext i1 %isetrp_cmp2.8 to i32
  br label %BB_0390

BB_0390:                                          ; preds = %BB_0310
  %cond_trunc.8 = trunc i32 %P20_to_i32 to i1
  %cond_not.2 = xor i1 %cond_trunc.8, true
  %pbra_cond_to_i32.8 = zext i1 %cond_not.2 to i32
  %pbra_cond_to_i1.8 = icmp ne i32 %pbra_cond_to_i32.8, 0
  br i1 %pbra_cond_to_i1.8, label %BB_03d0, label %BB_03b0_1360

BB_03b0_1360:                                     ; preds = %BB_0390
  %udiv64_dividend_lo_64 = zext i32 %iadd3_trunc to i64
  %udiv64_dividend_hi_64 = zext i32 %iadd3_cin2_add to i64
  %udiv64_divisor_lo_64 = zext i32 %R3_trunc to i64
  %udiv64_divisor_hi_64 = zext i32 0 to i64
  %udiv64_dividend_hi_shl = shl i64 %udiv64_dividend_hi_64, 32
  %udiv64_dividend = or i64 %udiv64_dividend_lo_64, %udiv64_dividend_hi_shl
  %udiv64_divisor_hi_shl = shl i64 %udiv64_divisor_hi_64, 32
  %udiv64_divisor = or i64 %udiv64_divisor_lo_64, %udiv64_divisor_hi_shl
  %udiv64_div_zero = icmp eq i64 %udiv64_divisor, 0
  %udiv64_safe_div = select i1 %udiv64_div_zero, i64 1, i64 %udiv64_divisor
  %udiv64 = udiv i64 %udiv64_dividend, %udiv64_safe_div
  %udiv64_word = trunc i64 %udiv64 to i32
  %udiv64_dividend_lo_64.1 = zext i32 %iadd3_trunc to i64
  %udiv64_dividend_hi_64.1 = zext i32 %iadd3_cin2_add to i64
  %udiv64_divisor_lo_64.1 = zext i32 %R3_trunc to i64
  %udiv64_divisor_hi_64.1 = zext i32 0 to i64
  %udiv64_dividend_hi_shl.1 = shl i64 %udiv64_dividend_hi_64.1, 32
  %udiv64_dividend.1 = or i64 %udiv64_dividend_lo_64.1, %udiv64_dividend_hi_shl.1
  %udiv64_divisor_hi_shl.1 = shl i64 %udiv64_divisor_hi_64.1, 32
  %udiv64_divisor.1 = or i64 %udiv64_divisor_lo_64.1, %udiv64_divisor_hi_shl.1
  %udiv64_div_zero.1 = icmp eq i64 %udiv64_divisor.1, 0
  %udiv64_safe_div.1 = select i1 %udiv64_div_zero.1, i64 1, i64 %udiv64_divisor.1
  %udiv64.1 = udiv i64 %udiv64_dividend.1, %udiv64_safe_div.1
  %udiv64_hi = lshr i64 %udiv64.1, 32
  %udiv64_word.1 = trunc i64 %udiv64_hi to i32
  %urem64_dividend_lo_64 = zext i32 %iadd3_trunc to i64
  %urem64_dividend_hi_64 = zext i32 %iadd3_cin2_add to i64
  %urem64_divisor_lo_64 = zext i32 %R3_trunc to i64
  %urem64_divisor_hi_64 = zext i32 0 to i64
  %urem64_dividend_hi_shl = shl i64 %urem64_dividend_hi_64, 32
  %urem64_dividend = or i64 %urem64_dividend_lo_64, %urem64_dividend_hi_shl
  %urem64_divisor_hi_shl = shl i64 %urem64_divisor_hi_64, 32
  %urem64_divisor = or i64 %urem64_divisor_lo_64, %urem64_divisor_hi_shl
  %urem64_div_zero = icmp eq i64 %urem64_divisor, 0
  %urem64_safe_div = select i1 %urem64_div_zero, i64 1, i64 %urem64_divisor
  %urem64 = urem i64 %urem64_dividend, %urem64_safe_div
  %urem64_word = trunc i64 %urem64 to i32
  %iadd3_o1_raw64 = zext i32 %R3_trunc to i64
  %iadd3_o1_not64 = xor i64 %iadd3_o1_raw64, -1
  %iadd3_o1_not64_masked = and i64 %iadd3_o1_not64, 4294967295
  %iadd3_o1_neg64 = add i64 %iadd3_o1_not64_masked, 1
  %iadd3_o2_64.1 = zext i32 %urem64_word to i64
  %iadd3_o3_64.1 = zext i32 0 to i64
  %iadd3_tmp.1 = add i64 %iadd3_o1_neg64, %iadd3_o2_64.1
  %iadd3_tmp2.1 = add i64 %iadd3_tmp.1, %iadd3_o3_64.1
  %iadd3_trunc.1 = trunc i64 %iadd3_tmp2.1 to i32
  %iadd3_carry_val.1 = lshr i64 %iadd3_tmp2.1, 32
  %carry_ge_1.1 = icmp uge i64 %iadd3_carry_val.1, 1
  %P61_to_i32 = zext i1 %carry_ge_1.1 to i32
  %urem64_dividend_lo_64.1 = zext i32 %iadd3_trunc to i64
  %urem64_dividend_hi_64.1 = zext i32 %iadd3_cin2_add to i64
  %urem64_divisor_lo_64.1 = zext i32 %R3_trunc to i64
  %urem64_divisor_hi_64.1 = zext i32 0 to i64
  %urem64_dividend_hi_shl.1 = shl i64 %urem64_dividend_hi_64.1, 32
  %urem64_dividend.1 = or i64 %urem64_dividend_lo_64.1, %urem64_dividend_hi_shl.1
  %urem64_divisor_hi_shl.1 = shl i64 %urem64_divisor_hi_64.1, 32
  %urem64_divisor.1 = or i64 %urem64_divisor_lo_64.1, %urem64_divisor_hi_shl.1
  %urem64_div_zero.1 = icmp eq i64 %urem64_divisor.1, 0
  %urem64_safe_div.1 = select i1 %urem64_div_zero.1, i64 1, i64 %urem64_divisor.1
  %urem64.1 = urem i64 %urem64_dividend.1, %urem64_safe_div.1
  %urem64_hi = lshr i64 %urem64.1, 32
  %urem64_word.1 = trunc i64 %urem64_hi to i32
  %isetrp_cmp1.9 = icmp uge i32 %urem64_word, %R3_trunc
  %isetrp_src_to_i32.9 = zext i1 true to i32
  %isetrp_src_to_i1.9 = icmp ne i32 %isetrp_src_to_i32.9, 0
  %isetrp_cmp2.9 = and i1 %isetrp_cmp1.9, %isetrp_src_to_i1.9
  %P68_to_i32 = zext i1 %isetrp_cmp2.9 to i32
  %iadd3_o1_64.1 = zext i32 %udiv64_word to i64
  %iadd3_o2_64.2 = zext i32 1 to i64
  %iadd3_o3_64.2 = zext i32 0 to i64
  %iadd3_tmp.2 = add i64 %iadd3_o1_64.1, %iadd3_o2_64.2
  %iadd3_tmp2.2 = add i64 %iadd3_tmp.2, %iadd3_o3_64.2
  %iadd3_trunc.2 = trunc i64 %iadd3_tmp2.2 to i32
  %iadd3_carry_val.2 = lshr i64 %iadd3_tmp2.2, 32
  %carry_ge_1.2 = icmp uge i64 %iadd3_carry_val.2, 1
  %P34_to_i32 = zext i1 %carry_ge_1.2 to i32
  %isetrp_cmp1.10 = icmp uge i32 %urem64_word.1, 0
  %isetrp_ex_lo_trunc.2 = trunc i32 %P68_to_i32 to i1
  %isetrp_ex_lo_to_i32.2 = zext i1 %isetrp_ex_lo_trunc.2 to i32
  %isetrp_ex_lo_to_i1.2 = icmp ne i32 %isetrp_ex_lo_to_i32.2, 0
  %isetrp_hi_eq.2 = icmp eq i32 %urem64_word.1, 0
  %isetrp_ex_sel.2 = select i1 %isetrp_hi_eq.2, i1 %isetrp_ex_lo_to_i1.2, i1 %isetrp_cmp1.10
  %isetrp_src_to_i32.10 = zext i1 true to i32
  %isetrp_src_to_i1.10 = icmp ne i32 %isetrp_src_to_i32.10, 0
  %isetrp_cmp2.10 = and i1 %isetrp_ex_sel.2, %isetrp_src_to_i1.10
  %P7_to_i32 = zext i1 %isetrp_cmp2.10 to i32
  %iadd3_n1.1 = add i32 %urem64_word.1, -1
  %iadd3_n2.1 = add i32 %iadd3_n1.1, 0
  %iadd3_cin1_trunc.1 = trunc i32 %P61_to_i32 to i1
  %iadd3_cin1_narrow_zext.1 = zext i1 %iadd3_cin1_trunc.1 to i32
  %iadd3_cin1_add.1 = add i32 %iadd3_n2.1, %iadd3_cin1_narrow_zext.1
  %iadd3_cin2_narrow_zext.1 = zext i1 false to i32
  %iadd3_cin2_add.1 = add i32 %iadd3_cin1_add.1, %iadd3_cin2_narrow_zext.1
  %imad_tmp.4 = mul i32 0, 0
  %imad.5 = add i32 %imad_tmp.4, %udiv64_word.1
  %imad_cin_trunc = trunc i32 %P34_to_i32 to i1
  %imad_cin_ext = zext i1 %imad_cin_trunc to i32
  %imad_with_cin = add i32 %imad.5, %imad_cin_ext
  %sel_pred_trunc = trunc i32 %P7_to_i32 to i1
  %sel_pred_to_i32 = zext i1 %sel_pred_trunc to i32
  %sel_pred_to_i1 = icmp ne i32 %sel_pred_to_i32, 0
  %sel = select i1 %sel_pred_to_i1, i32 %iadd3_trunc.1, i32 %urem64_word
  %sel_pred_trunc.1 = trunc i32 %P7_to_i32 to i1
  %sel_pred_to_i32.1 = zext i1 %sel_pred_trunc.1 to i32
  %sel_pred_to_i1.1 = icmp ne i32 %sel_pred_to_i32.1, 0
  %sel.1 = select i1 %sel_pred_to_i1.1, i32 %iadd3_trunc.2, i32 %udiv64_word
  %sel_pred_trunc.2 = trunc i32 %P7_to_i32 to i1
  %sel_pred_to_i32.2 = zext i1 %sel_pred_trunc.2 to i32
  %sel_pred_to_i1.2 = icmp ne i32 %sel_pred_to_i32.2, 0
  %sel.2 = select i1 %sel_pred_to_i1.2, i32 %iadd3_cin2_add.1, i32 %urem64_word.1
  %sel_pred_trunc.3 = trunc i32 %P7_to_i32 to i1
  %sel_pred_to_i32.3 = zext i1 %sel_pred_trunc.3 to i32
  %sel_pred_to_i1.3 = icmp ne i32 %sel_pred_to_i32.3, 0
  %sel.3 = select i1 %sel_pred_to_i1.3, i32 %imad_with_cin, i32 %udiv64_word.1
  %isetrp_cmp1.11 = icmp uge i32 %sel, %R3_trunc
  %isetrp_src_to_i32.11 = zext i1 true to i32
  %isetrp_src_to_i1.11 = icmp ne i32 %isetrp_src_to_i32.11, 0
  %isetrp_cmp2.11 = and i1 %isetrp_cmp1.11, %isetrp_src_to_i1.11
  %P2_to_i32 = zext i1 %isetrp_cmp2.11 to i32
  %iadd3_o1_64.2 = zext i32 %sel.1 to i64
  %iadd3_o2_64.3 = zext i32 1 to i64
  %iadd3_o3_64.3 = zext i32 0 to i64
  %iadd3_tmp.3 = add i64 %iadd3_o1_64.2, %iadd3_o2_64.3
  %iadd3_tmp2.3 = add i64 %iadd3_tmp.3, %iadd3_o3_64.3
  %iadd3_trunc.3 = trunc i64 %iadd3_tmp2.3 to i32
  %iadd3_carry_val.3 = lshr i64 %iadd3_tmp2.3, 32
  %carry_ge_1.3 = icmp uge i64 %iadd3_carry_val.3, 1
  %P45_to_i32 = zext i1 %carry_ge_1.3 to i32
  %isetrp_cmp1.12 = icmp uge i32 %sel.2, 0
  %isetrp_ex_lo_trunc.3 = trunc i32 %P2_to_i32 to i1
  %isetrp_ex_lo_to_i32.3 = zext i1 %isetrp_ex_lo_trunc.3 to i32
  %isetrp_ex_lo_to_i1.3 = icmp ne i32 %isetrp_ex_lo_to_i32.3, 0
  %isetrp_hi_eq.3 = icmp eq i32 %sel.2, 0
  %isetrp_ex_sel.3 = select i1 %isetrp_hi_eq.3, i1 %isetrp_ex_lo_to_i1.3, i1 %isetrp_cmp1.12
  %isetrp_src_to_i32.12 = zext i1 true to i32
  %isetrp_src_to_i1.12 = icmp ne i32 %isetrp_src_to_i32.12, 0
  %isetrp_cmp2.12 = and i1 %isetrp_ex_sel.3, %isetrp_src_to_i1.12
  %P3_to_i32 = zext i1 %isetrp_cmp2.12 to i32
  %isetrp_cmp1.13 = icmp ne i32 %R3_trunc, 0
  %isetrp_src_to_i32.13 = zext i1 true to i32
  %isetrp_src_to_i1.13 = icmp ne i32 %isetrp_src_to_i32.13, 0
  %isetrp_cmp2.13 = and i1 %isetrp_cmp1.13, %isetrp_src_to_i1.13
  %P62_to_i32 = zext i1 %isetrp_cmp2.13 to i32
  %iadd3_n1.2 = add i32 0, %sel.3
  %iadd3_n2.2 = add i32 %iadd3_n1.2, 0
  %iadd3_cin1_trunc.2 = trunc i32 %P45_to_i32 to i1
  %iadd3_cin1_narrow_zext.2 = zext i1 %iadd3_cin1_trunc.2 to i32
  %iadd3_cin1_add.2 = add i32 %iadd3_n2.2, %iadd3_cin1_narrow_zext.2
  %iadd3_cin2_narrow_zext.2 = zext i1 false to i32
  %iadd3_cin2_add.2 = add i32 %iadd3_cin1_add.2, %iadd3_cin2_narrow_zext.2
  %isetrp_cmp1.14 = icmp ne i32 0, 0
  %isetrp_ex_lo_trunc.4 = trunc i32 %P62_to_i32 to i1
  %isetrp_ex_lo_to_i32.4 = zext i1 %isetrp_ex_lo_trunc.4 to i32
  %isetrp_ex_lo_to_i1.4 = icmp ne i32 %isetrp_ex_lo_to_i32.4, 0
  %isetrp_hi_eq.4 = icmp eq i32 0, 0
  %isetrp_ex_sel.4 = select i1 %isetrp_hi_eq.4, i1 %isetrp_ex_lo_to_i1.4, i1 %isetrp_cmp1.14
  %isetrp_src_to_i32.14 = zext i1 true to i32
  %isetrp_src_to_i1.14 = icmp ne i32 %isetrp_src_to_i32.14, 0
  %isetrp_cmp2.14 = and i1 %isetrp_ex_sel.4, %isetrp_src_to_i1.14
  %P63_to_i32 = zext i1 %isetrp_cmp2.14 to i32
  %sel_pred_trunc.4 = trunc i32 %P3_to_i32 to i1
  %sel_pred_to_i32.4 = zext i1 %sel_pred_trunc.4 to i32
  %sel_pred_to_i1.4 = icmp ne i32 %sel_pred_to_i32.4, 0
  %sel.4 = select i1 %sel_pred_to_i1.4, i32 %iadd3_trunc.3, i32 %sel.1
  %sel_pred_trunc.5 = trunc i32 %P3_to_i32 to i1
  %sel_pred_to_i32.5 = zext i1 %sel_pred_trunc.5 to i32
  %sel_pred_to_i1.5 = icmp ne i32 %sel_pred_to_i32.5, 0
  %sel.5 = select i1 %sel_pred_to_i1.5, i32 %iadd3_cin2_add.2, i32 %sel.3
  %sel_pred_trunc.6 = trunc i32 %P63_to_i32 to i1
  %sel_pred_to_i32.6 = zext i1 %sel_pred_trunc.6 to i32
  %sel_pred_to_i1.6 = icmp ne i32 %sel_pred_to_i32.6, 0
  %sel.6 = select i1 %sel_pred_to_i1.6, i32 %sel.4, i32 -1
  %sel_pred_trunc.7 = trunc i32 %P63_to_i32 to i1
  %sel_pred_to_i32.7 = zext i1 %sel_pred_trunc.7 to i32
  %sel_pred_to_i1.7 = icmp ne i32 %sel_pred_to_i32.7, 0
  %sel.7 = select i1 %sel_pred_to_i1.7, i32 %sel.5, i32 -1
  br label %BB_0500

BB_03d0:                                          ; preds = %BB_0390
  %isetrp_cmp1.15 = icmp ne i32 %R3_trunc, 0
  %isetrp_src_to_i32.15 = zext i1 true to i32
  %isetrp_src_to_i1.15 = icmp ne i32 %isetrp_src_to_i32.15, 0
  %isetrp_cmp2.15 = and i1 %isetrp_cmp1.15, %isetrp_src_to_i1.15
  %P56_to_i32 = zext i1 %isetrp_cmp2.15 to i32
  %sdiv_div_zero = icmp eq i32 %R3_trunc, 0
  %sdiv_safe_div = select i1 %sdiv_div_zero, i32 1, i32 %R3_trunc
  %sdiv = udiv i32 %iadd3_trunc, %sdiv_safe_div
  %imad_addend_neg = sub i32 0, %sdiv
  %imad_tmp.5 = mul i32 0, 0
  %imad.6 = add i32 %imad_tmp.5, %imad_addend_neg
  %imad_tmp.6 = mul i32 %R3_trunc, %imad.6
  %imad.7 = add i32 %imad_tmp.6, %iadd3_trunc
  %isetrp_cmp1.16 = icmp uge i32 %imad.7, %R3_trunc
  %isetrp_src_to_i32.16 = zext i1 true to i32
  %isetrp_src_to_i1.16 = icmp ne i32 %isetrp_src_to_i32.16, 0
  %isetrp_cmp2.16 = and i1 %isetrp_cmp1.16, %isetrp_src_to_i1.16
  %P4_to_i32 = zext i1 %isetrp_cmp2.16 to i32
  br label %BB_04b0

BB_04b0:                                          ; preds = %BB_03d0
  %cond_trunc.9 = trunc i32 %P4_to_i32 to i1
  %pbra_cond_to_i32.9 = zext i1 %cond_trunc.9 to i32
  %pbra_cond_to_i1.9 = icmp ne i32 %pbra_cond_to_i32.9, 0
  br i1 %pbra_cond_to_i1.9, label %BB_800004b0, label %BB_04d0

BB_800004b0:                                      ; preds = %BB_04b0
  %imad_addend_neg.1 = sub i32 0, %R3_trunc
  %imad_tmp.7 = mul i32 %imad.7, 1
  %imad.8 = add i32 %imad_tmp.7, %imad_addend_neg.1
  %iadd3_n1.3 = add i32 %sdiv, 1
  %iadd3_n2.3 = add i32 %iadd3_n1.3, 0
  br label %BB_04d0

BB_04d0:                                          ; preds = %BB_800004b0, %BB_04b0
  %phi.10 = phi i32 [ %iadd3_n2.3, %BB_800004b0 ], [ %sdiv, %BB_04b0 ]
  %phi.11 = phi i32 [ %imad.8, %BB_800004b0 ], [ %imad.7, %BB_04b0 ]
  %isetrp_cmp1.17 = icmp uge i32 %phi.11, %R3_trunc
  %isetrp_src_to_i32.17 = zext i1 true to i32
  %isetrp_src_to_i1.17 = icmp ne i32 %isetrp_src_to_i32.17, 0
  %isetrp_cmp2.17 = and i1 %isetrp_cmp1.17, %isetrp_src_to_i1.17
  %P64_to_i32 = zext i1 %isetrp_cmp2.17 to i32
  br label %BB_04e0

BB_04e0:                                          ; preds = %BB_04d0
  %cond_trunc.10 = trunc i32 %P64_to_i32 to i1
  %pbra_cond_to_i32.10 = zext i1 %cond_trunc.10 to i32
  %pbra_cond_to_i1.10 = icmp ne i32 %pbra_cond_to_i32.10, 0
  br i1 %pbra_cond_to_i1.10, label %BB_800004e0, label %BB_04f0

BB_800004e0:                                      ; preds = %BB_04e0
  %viadd = add i32 %phi.10, 1
  br label %BB_04f0

BB_04f0:                                          ; preds = %BB_800004e0, %BB_04e0
  %phi.12 = phi i32 [ %viadd, %BB_800004e0 ], [ %phi.10, %BB_04e0 ]
  %cond_trunc.11 = trunc i32 %P56_to_i32 to i1
  %cond_not.3 = xor i1 %cond_trunc.11, true
  %pbra_cond_to_i32.11 = zext i1 %cond_not.3 to i32
  %pbra_cond_to_i1.11 = icmp ne i32 %pbra_cond_to_i32.11, 0
  br i1 %pbra_cond_to_i1.11, label %BB_800004f0, label %BB_0500

BB_800004f0:                                      ; preds = %BB_04f0
  %.158 = xor i32 0, -1
  %.159 = xor i32 %R3_trunc, -1
  %.160 = xor i32 0, -1
  %.161 = and i32 %.158, %.159
  %.162 = and i32 %.161, %.160
  %.163 = and i32 %.158, %.159
  %.164 = and i32 %.163, 0
  %.165 = or i32 %.162, %.164
  %.166 = and i32 0, %.159
  %.167 = and i32 %.166, %.160
  %.168 = or i32 %.165, %.167
  %.169 = and i32 0, %.159
  %.170 = and i32 %.169, 0
  %.171 = or i32 %.168, %.170
  br label %BB_0500

BB_0500:                                          ; preds = %BB_800004f0, %BB_04f0, %BB_03b0_1360
  %phi.13 = phi i32 [ %sel.7, %BB_03b0_1360 ], [ 0, %BB_800004f0 ], [ 0, %BB_04f0 ]
  %phi.14 = phi i32 [ %sel.6, %BB_03b0_1360 ], [ %.171, %BB_800004f0 ], [ %phi.12, %BB_04f0 ]
  %viadd.1 = add i32 %phi.14, 1
  %isetrp_cmp1.18 = icmp uge i32 %phi.14, 3
  %isetrp_src_to_i32.18 = zext i1 true to i32
  %isetrp_src_to_i1.18 = icmp ne i32 %isetrp_src_to_i32.18, 0
  %isetrp_cmp2.18 = and i1 %isetrp_cmp1.18, %isetrp_src_to_i1.18
  %P5_to_i32 = zext i1 %isetrp_cmp2.18 to i32
  %.173 = xor i32 %viadd.1, -1
  %.174 = xor i32 3, -1
  %.175 = xor i32 0, -1
  %.176 = and i32 %viadd.1, 3
  %.177 = and i32 %.176, %.175
  %.178 = and i32 %viadd.1, 3
  %.179 = and i32 %.178, 0
  %.180 = or i32 %.177, %.179
  %isetrp_cmp1.19 = icmp uge i32 %phi.13, 0
  %isetrp_ex_lo_trunc.5 = trunc i32 %P5_to_i32 to i1
  %isetrp_ex_lo_to_i32.5 = zext i1 %isetrp_ex_lo_trunc.5 to i32
  %isetrp_ex_lo_to_i1.5 = icmp ne i32 %isetrp_ex_lo_to_i32.5, 0
  %isetrp_hi_eq.5 = icmp eq i32 %phi.13, 0
  %isetrp_ex_sel.5 = select i1 %isetrp_hi_eq.5, i1 %isetrp_ex_lo_to_i1.5, i1 %isetrp_cmp1.19
  %isetrp_src_to_i32.19 = zext i1 true to i32
  %isetrp_src_to_i1.19 = icmp ne i32 %isetrp_src_to_i32.19, 0
  %isetrp_cmp2.19 = and i1 %isetrp_ex_sel.5, %isetrp_src_to_i1.19
  %P6_to_i32 = zext i1 %isetrp_cmp2.19 to i32
  %isetrp_cmp1.20 = icmp ne i32 %.180, 0
  %isetrp_src_to_i32.20 = zext i1 true to i32
  %isetrp_src_to_i1.20 = icmp ne i32 %isetrp_src_to_i32.20, 0
  %isetrp_cmp2.20 = and i1 %isetrp_cmp1.20, %isetrp_src_to_i1.20
  %P43_to_i32 = zext i1 %isetrp_cmp2.20 to i32
  %isetrp_cmp1.21 = icmp ne i32 0, 0
  %isetrp_ex_lo_trunc.6 = trunc i32 %P43_to_i32 to i1
  %isetrp_ex_lo_to_i32.6 = zext i1 %isetrp_ex_lo_trunc.6 to i32
  %isetrp_ex_lo_to_i1.6 = icmp ne i32 %isetrp_ex_lo_to_i32.6, 0
  %isetrp_hi_eq.6 = icmp eq i32 0, 0
  %isetrp_ex_sel.6 = select i1 %isetrp_hi_eq.6, i1 %isetrp_ex_lo_to_i1.6, i1 %isetrp_cmp1.21
  %isetrp_src_to_i32.21 = zext i1 true to i32
  %isetrp_src_to_i1.21 = icmp ne i32 %isetrp_src_to_i32.21, 0
  %isetrp_cmp2.21 = and i1 %isetrp_ex_sel.6, %isetrp_src_to_i1.21
  %P44_to_i32 = zext i1 %isetrp_cmp2.21 to i32
  br label %BB_0580

BB_0580:                                          ; preds = %BB_0500
  %cond_trunc.12 = trunc i32 %P44_to_i32 to i1
  %cond_not.4 = xor i1 %cond_trunc.12, true
  %pbra_cond_to_i32.12 = zext i1 %cond_not.4 to i32
  %pbra_cond_to_i1.12 = icmp ne i32 %pbra_cond_to_i32.12, 0
  br i1 %pbra_cond_to_i1.12, label %BB_06e0, label %BB_0590

BB_0590:                                          ; preds = %BB_0580
  %.183 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 552
  %.184 = bitcast ptr %.183 to ptr
  %ldc_const.11 = load i64, ptr %.184, align 8
  %"UR7:UR6_r0.1" = trunc i64 %ldc_const.11 to i32
  %"UR7:UR6_r1_shift.1" = lshr i64 %ldc_const.11, 32
  %"UR7:UR6_r1.1" = trunc i64 %"UR7:UR6_r1_shift.1" to i32
  %.185 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 544
  %.186 = bitcast ptr %.185 to ptr
  %ldc_const.12 = load i64, ptr %.186, align 8
  %"UR9:UR8_r0" = trunc i64 %ldc_const.12 to i32
  %"UR9:UR8_r1_shift" = lshr i64 %ldc_const.12, 32
  %"UR9:UR8_r1" = trunc i64 %"UR9:UR8_r1_shift" to i32
  %imad_addend_r0_ext.1 = zext i32 %imad.4 to i64
  %imad_addend_packed_0.1 = or i64 0, %imad_addend_r0_ext.1
  %imad_addend_r1_ext.1 = zext i32 0 to i64
  %imad_addend_r1_shift.1 = shl i64 %imad_addend_r1_ext.1, 32
  %imad_addend_packed_1.1 = or i64 %imad_addend_packed_0.1, %imad_addend_r1_shift.1
  %imad_lhs_64.1 = zext i32 %ctaid_z to i64
  %imad_rhs_64.1 = zext i32 %"UR7:UR6_r0.1" to i64
  %imad_tmp_64.1 = mul i64 %imad_lhs_64.1, %imad_rhs_64.1
  %imad.9 = add i64 %imad_tmp_64.1, %imad_addend_packed_1.1
  %"R9:R8_r0.2" = trunc i64 %imad.9 to i32
  %"R9:R8_r1_shift.2" = lshr i64 %imad.9, 32
  %"R9:R8_r1.2" = trunc i64 %"R9:R8_r1_shift.2" to i32
  %imad_tmp.8 = mul i32 %ctaid_z, %"UR7:UR6_r1.1"
  %imad.10 = add i32 %imad_tmp.8, %"R9:R8_r1.2"
  %.187 = zext i32 %"R9:R8_r0.2" to i64
  %.188 = zext i32 %"UR9:UR8_r0" to i64
  %.189 = zext i32 2 to i64
  %.190 = shl i64 %.187, %.189
  %.191 = and i64 %.190, 4294967295
  %.192 = add i64 %.191, %.188
  %.193 = trunc i64 %.192 to i32
  %.194 = lshr i64 %.192, 32
  %.195 = trunc i64 %.194 to i1
  %P46_to_i32 = zext i1 %.195 to i32
  %.196 = zext i32 %"R9:R8_r0.2" to i64
  %.197 = zext i32 %imad.10 to i64
  %.198 = shl i64 %.197, 32
  %lea_funnel.1 = or i64 %.196, %.198
  %.199 = zext i32 %"UR9:UR8_r1" to i64
  %.200 = zext i32 2 to i64
  %.201 = shl i64 %lea_funnel.1, %.200
  %.202 = lshr i64 %.201, 32
  %.203 = add i64 %.202, %.199
  %lea_cin_trunc.1 = trunc i32 %P46_to_i32 to i1
  %.204 = zext i1 %lea_cin_trunc.1 to i64
  %.205 = add i64 %.203, %.204
  %.206 = trunc i64 %.205 to i32
  br label %BB_0600

BB_0600:                                          ; preds = %BB_06c0, %BB_0590
  %phi.15 = phi i32 [ 0, %BB_0590 ], [ %imad_with_cin.1, %BB_06c0 ]
  %phi.16 = phi i32 [ %imad.4, %BB_0590 ], [ %iadd3_trunc.5, %BB_06c0 ]
  %phi.17 = phi float [ %phi.9, %BB_0590 ], [ %fadd, %BB_06c0 ]
  %phi.18 = phi i32 [ 0, %BB_0590 ], [ %iadd3_cin2_add.3, %BB_06c0 ]
  %phi.19 = phi i32 [ %.206, %BB_0590 ], [ %.227, %BB_06c0 ]
  %phi.20 = phi i32 [ %.193, %BB_0590 ], [ %.214, %BB_06c0 ]
  %phi.21 = phi i32 [ %.180, %BB_0590 ], [ %iadd3_trunc.4, %BB_06c0 ]
  %ldg_addr_r0_ext.3 = zext i32 %phi.20 to i64
  %ldg_addr_packed_0.3 = or i64 0, %ldg_addr_r0_ext.3
  %ldg_addr_r1_ext.3 = zext i32 %phi.19 to i64
  %ldg_addr_r1_shift.3 = shl i64 %ldg_addr_r1_ext.3, 32
  %ldg_addr_packed_1.3 = or i64 %ldg_addr_packed_0.3, %ldg_addr_r1_shift.3
  %"R229:R222_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.3 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R229:R222_addr_ptr", align 4
  %iadd3_o1_64.3 = zext i32 %phi.21 to i64
  %iadd3_o2_64.4 = zext i32 -1 to i64
  %iadd3_o3_64.4 = zext i32 0 to i64
  %iadd3_tmp.4 = add i64 %iadd3_o1_64.3, %iadd3_o2_64.4
  %iadd3_tmp2.4 = add i64 %iadd3_tmp.4, %iadd3_o3_64.4
  %iadd3_trunc.4 = trunc i64 %iadd3_tmp2.4 to i32
  %iadd3_carry_val.4 = lshr i64 %iadd3_tmp2.4, 32
  %carry_ge_1.4 = icmp uge i64 %iadd3_carry_val.4, 1
  %P47_to_i32 = zext i1 %carry_ge_1.4 to i32
  %iadd3_o1_64.4 = zext i32 %R3_trunc to i64
  %iadd3_o2_64.5 = zext i32 %phi.16 to i64
  %iadd3_o3_64.5 = zext i32 0 to i64
  %iadd3_tmp.5 = add i64 %iadd3_o1_64.4, %iadd3_o2_64.5
  %iadd3_tmp2.5 = add i64 %iadd3_tmp.5, %iadd3_o3_64.5
  %iadd3_trunc.5 = trunc i64 %iadd3_tmp2.5 to i32
  %iadd3_carry_val.5 = lshr i64 %iadd3_tmp2.5, 32
  %carry_ge_1.5 = icmp uge i64 %iadd3_carry_val.5, 1
  %P66_to_i32 = zext i1 %carry_ge_1.5 to i32
  %iadd3_n1.4 = add i32 %phi.18, -1
  %iadd3_n2.4 = add i32 %iadd3_n1.4, 0
  %iadd3_cin1_trunc.3 = trunc i32 %P47_to_i32 to i1
  %iadd3_cin1_narrow_zext.3 = zext i1 %iadd3_cin1_trunc.3 to i32
  %iadd3_cin1_add.3 = add i32 %iadd3_n2.4, %iadd3_cin1_narrow_zext.3
  %iadd3_cin2_narrow_zext.3 = zext i1 false to i32
  %iadd3_cin2_add.3 = add i32 %iadd3_cin1_add.3, %iadd3_cin2_narrow_zext.3
  %isetrp_cmp1.22 = icmp ne i32 %iadd3_trunc.4, 0
  %isetrp_src_to_i32.22 = zext i1 true to i32
  %isetrp_src_to_i1.22 = icmp ne i32 %isetrp_src_to_i32.22, 0
  %isetrp_cmp2.22 = and i1 %isetrp_cmp1.22, %isetrp_src_to_i1.22
  %P48_to_i32 = zext i1 %isetrp_cmp2.22 to i32
  %imad_tmp.9 = mul i32 0, 0
  %imad.11 = add i32 %imad_tmp.9, %phi.15
  %imad_cin_trunc.1 = trunc i32 %P66_to_i32 to i1
  %imad_cin_ext.1 = zext i1 %imad_cin_trunc.1 to i32
  %imad_with_cin.1 = add i32 %imad.11, %imad_cin_ext.1
  %.208 = zext i32 %R3_trunc to i64
  %.209 = zext i32 %phi.20 to i64
  %.210 = zext i32 2 to i64
  %.211 = shl i64 %.208, %.210
  %.212 = and i64 %.211, 4294967295
  %.213 = add i64 %.212, %.209
  %.214 = trunc i64 %.213 to i32
  %.215 = lshr i64 %.213, 32
  %.216 = trunc i64 %.215 to i1
  %P55_to_i32 = zext i1 %.216 to i32
  %isetrp_cmp1.23 = icmp ne i32 %iadd3_cin2_add.3, 0
  %isetrp_ex_lo_trunc.7 = trunc i32 %P48_to_i32 to i1
  %isetrp_ex_lo_to_i32.7 = zext i1 %isetrp_ex_lo_trunc.7 to i32
  %isetrp_ex_lo_to_i1.7 = icmp ne i32 %isetrp_ex_lo_to_i32.7, 0
  %isetrp_hi_eq.7 = icmp eq i32 %iadd3_cin2_add.3, 0
  %isetrp_ex_sel.7 = select i1 %isetrp_hi_eq.7, i1 %isetrp_ex_lo_to_i1.7, i1 %isetrp_cmp1.23
  %isetrp_src_to_i32.23 = zext i1 true to i32
  %isetrp_src_to_i1.23 = icmp ne i32 %isetrp_src_to_i32.23, 0
  %isetrp_cmp2.23 = and i1 %isetrp_ex_sel.7, %isetrp_src_to_i1.23
  %P49_to_i32 = zext i1 %isetrp_cmp2.23 to i32
  %.217 = zext i32 %R3_trunc to i64
  %.218 = zext i32 0 to i64
  %.219 = shl i64 %.218, 32
  %lea_funnel.2 = or i64 %.217, %.219
  %.220 = zext i32 %phi.19 to i64
  %.221 = zext i32 2 to i64
  %.222 = shl i64 %lea_funnel.2, %.221
  %.223 = lshr i64 %.222, 32
  %.224 = add i64 %.223, %.220
  %lea_cin_trunc.2 = trunc i32 %P55_to_i32 to i1
  %.225 = zext i1 %lea_cin_trunc.2 to i64
  %.226 = add i64 %.224, %.225
  %.227 = trunc i64 %.226 to i32
  %fadd = fadd float %ldg.3, %phi.17
  br label %BB_06c0

BB_06c0:                                          ; preds = %BB_0600
  %cond_trunc.13 = trunc i32 %P49_to_i32 to i1
  %pbra_cond_to_i32.13 = zext i1 %cond_trunc.13 to i32
  %pbra_cond_to_i1.13 = icmp ne i32 %pbra_cond_to_i32.13, 0
  %phi_cast_R86_bitcast = bitcast float %ldg.3 to i32
  br i1 %pbra_cond_to_i1.13, label %BB_0600, label %BB_06e0

BB_06e0:                                          ; preds = %BB_06c0, %BB_0580
  %phi.22 = phi i32 [ %phi.13, %BB_0580 ], [ %phi.19, %BB_06c0 ]
  %phi.23 = phi i32 [ %phi.14, %BB_0580 ], [ %phi_cast_R86_bitcast, %BB_06c0 ]
  %phi.24 = phi i32 [ 0, %BB_0580 ], [ %imad_with_cin.1, %BB_06c0 ]
  %phi.25 = phi i32 [ %imad.4, %BB_0580 ], [ %iadd3_trunc.5, %BB_06c0 ]
  %phi.26 = phi float [ %phi.9, %BB_0580 ], [ %fadd, %BB_06c0 ]
  %cond_trunc.14 = trunc i32 %P6_to_i32 to i1
  %cond_not.5 = xor i1 %cond_trunc.14, true
  %pbra_cond_to_i32.14 = zext i1 %cond_not.5 to i32
  %pbra_cond_to_i1.14 = icmp ne i32 %pbra_cond_to_i32.14, 0
  br i1 %pbra_cond_to_i1.14, label %BB_0900, label %BB_06f0

BB_06f0:                                          ; preds = %BB_06e0
  %.231 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 552
  %.232 = bitcast ptr %.231 to ptr
  %ldc_const.13 = load i64, ptr %.232, align 8
  %"UR7:UR6_r0.2" = trunc i64 %ldc_const.13 to i32
  %"UR7:UR6_r1_shift.2" = lshr i64 %ldc_const.13, 32
  %"UR7:UR6_r1.2" = trunc i64 %"UR7:UR6_r1_shift.2" to i32
  %.233 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 544
  %.234 = bitcast ptr %.233 to ptr
  %ldc_const.14 = load i64, ptr %.234, align 8
  %"UR9:UR8_r0.1" = trunc i64 %ldc_const.14 to i32
  %"UR9:UR8_r1_shift.1" = lshr i64 %ldc_const.14, 32
  %"UR9:UR8_r1.1" = trunc i64 %"UR9:UR8_r1_shift.1" to i32
  %imad_addend_r0_ext.2 = zext i32 %phi.25 to i64
  %imad_addend_packed_0.2 = or i64 0, %imad_addend_r0_ext.2
  %imad_addend_r1_ext.2 = zext i32 %phi.24 to i64
  %imad_addend_r1_shift.2 = shl i64 %imad_addend_r1_ext.2, 32
  %imad_addend_packed_1.2 = or i64 %imad_addend_packed_0.2, %imad_addend_r1_shift.2
  %imad_lhs_64.2 = zext i32 %ctaid_z to i64
  %imad_rhs_64.2 = zext i32 %"UR7:UR6_r0.2" to i64
  %imad_tmp_64.2 = mul i64 %imad_lhs_64.2, %imad_rhs_64.2
  %imad.12 = add i64 %imad_tmp_64.2, %imad_addend_packed_1.2
  %"R9:R8_r0.3" = trunc i64 %imad.12 to i32
  %"R9:R8_r1_shift.3" = lshr i64 %imad.12, 32
  %"R9:R8_r1.3" = trunc i64 %"R9:R8_r1_shift.3" to i32
  %.235 = zext i32 %R3_trunc to i64
  %.236 = zext i32 0 to i64
  %.237 = shl i64 %.236, 32
  %shf_concat.2 = or i64 %.235, %.237
  %shf_shift_64.2 = zext i32 2 to i64
  %.238 = shl i64 %shf_concat.2, %shf_shift_64.2
  %shf_result.2 = trunc i64 %.238 to i32
  %.239 = zext i32 0 to i64
  %.240 = zext i32 %R3_trunc to i64
  %.241 = shl i64 %.240, 32
  %shf_concat.3 = or i64 %.239, %.241
  %shf_shift_64.3 = zext i32 30 to i64
  %.242 = lshr i64 %shf_concat.3, %shf_shift_64.3
  %shf_hi.2 = lshr i64 %.242, 32
  %shf_result.3 = trunc i64 %shf_hi.2 to i32
  %imad_tmp.10 = mul i32 %ctaid_z, %"UR7:UR6_r1.2"
  %imad.13 = add i32 %imad_tmp.10, %"R9:R8_r1.3"
  %.243 = zext i32 %"R9:R8_r0.3" to i64
  %.244 = zext i32 %"UR9:UR8_r0.1" to i64
  %.245 = zext i32 2 to i64
  %.246 = shl i64 %.243, %.245
  %.247 = and i64 %.246, 4294967295
  %.248 = add i64 %.247, %.244
  %.249 = trunc i64 %.248 to i32
  %.250 = lshr i64 %.248, 32
  %.251 = trunc i64 %.250 to i1
  %P8_to_i32 = zext i1 %.251 to i32
  %.252 = zext i32 %"R9:R8_r0.3" to i64
  %.253 = zext i32 %imad.13 to i64
  %.254 = shl i64 %.253, 32
  %lea_funnel.3 = or i64 %.252, %.254
  %.255 = zext i32 %"UR9:UR8_r1.1" to i64
  %.256 = zext i32 2 to i64
  %.257 = shl i64 %lea_funnel.3, %.256
  %.258 = lshr i64 %.257, 32
  %.259 = add i64 %.258, %.255
  %lea_cin_trunc.3 = trunc i32 %P8_to_i32 to i1
  %.260 = zext i1 %lea_cin_trunc.3 to i64
  %.261 = add i64 %.259, %.260
  %.262 = trunc i64 %.261 to i32
  br label %BB_0770

BB_0770:                                          ; preds = %BB_08e0, %BB_06f0
  %phi.27 = phi i32 [ %phi.24, %BB_06f0 ], [ %iadd3_cin2_add.5, %BB_08e0 ]
  %phi.28 = phi i32 [ %phi.25, %BB_06f0 ], [ %iadd3_trunc.10, %BB_08e0 ]
  %phi.29 = phi float [ %phi.26, %BB_06f0 ], [ %fadd.4, %BB_08e0 ]
  %phi.30 = phi i32 [ %.262, %BB_06f0 ], [ %iadd3_cin2_add.6, %BB_08e0 ]
  %phi.31 = phi i32 [ %.249, %BB_06f0 ], [ %iadd3_trunc.11, %BB_08e0 ]
  %iadd3_o1_64.5 = zext i32 %shf_result.2 to i64
  %iadd3_o2_64.6 = zext i32 %phi.31 to i64
  %iadd3_o3_64.6 = zext i32 0 to i64
  %iadd3_tmp.6 = add i64 %iadd3_o1_64.5, %iadd3_o2_64.6
  %iadd3_tmp2.6 = add i64 %iadd3_tmp.6, %iadd3_o3_64.6
  %iadd3_trunc.6 = trunc i64 %iadd3_tmp2.6 to i32
  %iadd3_carry_val.6 = lshr i64 %iadd3_tmp2.6, 32
  %carry_ge_1.6 = icmp uge i64 %iadd3_carry_val.6, 1
  %P10_to_i32 = zext i1 %carry_ge_1.6 to i32
  %.264 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 560
  %.265 = bitcast ptr %.264 to ptr
  %ldc_const.15 = load i32, ptr %.265, align 4
  %ldg_addr_r0_ext.4 = zext i32 %phi.31 to i64
  %ldg_addr_packed_0.4 = or i64 0, %ldg_addr_r0_ext.4
  %ldg_addr_r1_ext.4 = zext i32 %phi.30 to i64
  %ldg_addr_r1_shift.4 = shl i64 %ldg_addr_r1_ext.4, 32
  %ldg_addr_packed_1.4 = or i64 %ldg_addr_packed_0.4, %ldg_addr_r1_shift.4
  %"R46:R252_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.4 to ptr addrspace(1)
  %ldg.4 = load float, ptr addrspace(1) %"R46:R252_addr_ptr", align 4
  %imad_tmp.11 = mul i32 %shf_result.3, 1
  %imad.14 = add i32 %imad_tmp.11, %phi.30
  %imad_cin_trunc.2 = trunc i32 %P10_to_i32 to i1
  %imad_cin_ext.2 = zext i1 %imad_cin_trunc.2 to i32
  %imad_with_cin.2 = add i32 %imad.14, %imad_cin_ext.2
  %iadd3_o1_64.6 = zext i32 %shf_result.2 to i64
  %iadd3_o2_64.7 = zext i32 %iadd3_trunc.6 to i64
  %iadd3_o3_64.7 = zext i32 0 to i64
  %iadd3_tmp.7 = add i64 %iadd3_o1_64.6, %iadd3_o2_64.7
  %iadd3_tmp2.7 = add i64 %iadd3_tmp.7, %iadd3_o3_64.7
  %iadd3_trunc.7 = trunc i64 %iadd3_tmp2.7 to i32
  %iadd3_carry_val.7 = lshr i64 %iadd3_tmp2.7, 32
  %carry_ge_1.7 = icmp uge i64 %iadd3_carry_val.7, 1
  %P11_to_i32 = zext i1 %carry_ge_1.7 to i32
  %ldg_addr_r0_ext.5 = zext i32 %iadd3_trunc.6 to i64
  %ldg_addr_packed_0.5 = or i64 0, %ldg_addr_r0_ext.5
  %ldg_addr_r1_ext.5 = zext i32 %imad_with_cin.2 to i64
  %ldg_addr_r1_shift.5 = shl i64 %ldg_addr_r1_ext.5, 32
  %ldg_addr_packed_1.5 = or i64 %ldg_addr_packed_0.5, %ldg_addr_r1_shift.5
  %"R231:R226_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.5 to ptr addrspace(1)
  %ldg.5 = load float, ptr addrspace(1) %"R231:R226_addr_ptr", align 4
  %imad_tmp.12 = mul i32 %shf_result.3, 1
  %imad.15 = add i32 %imad_tmp.12, %imad_with_cin.2
  %imad_cin_trunc.3 = trunc i32 %P11_to_i32 to i1
  %imad_cin_ext.3 = zext i1 %imad_cin_trunc.3 to i32
  %imad_with_cin.3 = add i32 %imad.15, %imad_cin_ext.3
  %iadd3_o1_64.7 = zext i32 %shf_result.2 to i64
  %iadd3_o2_64.8 = zext i32 %iadd3_trunc.7 to i64
  %iadd3_o3_64.8 = zext i32 0 to i64
  %iadd3_tmp.8 = add i64 %iadd3_o1_64.7, %iadd3_o2_64.8
  %iadd3_tmp2.8 = add i64 %iadd3_tmp.8, %iadd3_o3_64.8
  %iadd3_trunc.8 = trunc i64 %iadd3_tmp2.8 to i32
  %iadd3_carry_val.8 = lshr i64 %iadd3_tmp2.8, 32
  %carry_ge_1.8 = icmp uge i64 %iadd3_carry_val.8, 1
  %P14_to_i32 = zext i1 %carry_ge_1.8 to i32
  %ldg_addr_r0_ext.6 = zext i32 %iadd3_trunc.7 to i64
  %ldg_addr_packed_0.6 = or i64 0, %ldg_addr_r0_ext.6
  %ldg_addr_r1_ext.6 = zext i32 %imad_with_cin.3 to i64
  %ldg_addr_r1_shift.6 = shl i64 %ldg_addr_r1_ext.6, 32
  %ldg_addr_packed_1.6 = or i64 %ldg_addr_packed_0.6, %ldg_addr_r1_shift.6
  %"R38:R68_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.6 to ptr addrspace(1)
  %ldg.6 = load float, ptr addrspace(1) %"R38:R68_addr_ptr", align 4
  %imad_tmp.13 = mul i32 %shf_result.3, 1
  %imad.16 = add i32 %imad_tmp.13, %imad_with_cin.3
  %imad_cin_trunc.4 = trunc i32 %P14_to_i32 to i1
  %imad_cin_ext.4 = zext i1 %imad_cin_trunc.4 to i32
  %imad_with_cin.4 = add i32 %imad.16, %imad_cin_ext.4
  %ldg_addr_r0_ext.7 = zext i32 %iadd3_trunc.8 to i64
  %ldg_addr_packed_0.7 = or i64 0, %ldg_addr_r0_ext.7
  %ldg_addr_r1_ext.7 = zext i32 %imad_with_cin.4 to i64
  %ldg_addr_r1_shift.7 = shl i64 %ldg_addr_r1_ext.7, 32
  %ldg_addr_packed_1.7 = or i64 %ldg_addr_packed_0.7, %ldg_addr_r1_shift.7
  %"R144:R89_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.7 to ptr addrspace(1)
  %ldg.7 = load float, ptr addrspace(1) %"R144:R89_addr_ptr", align 4
  %iadd3_o1_64.8 = zext i32 %R3_trunc to i64
  %iadd3_o2_64.9 = zext i32 %phi.28 to i64
  %iadd3_o3_64.9 = zext i32 %R3_trunc to i64
  %iadd3_tmp.9 = add i64 %iadd3_o1_64.8, %iadd3_o2_64.9
  %iadd3_tmp2.9 = add i64 %iadd3_tmp.9, %iadd3_o3_64.9
  %iadd3_trunc.9 = trunc i64 %iadd3_tmp2.9 to i32
  %iadd3_carry_val.9 = lshr i64 %iadd3_tmp2.9, 32
  %carry_ge_1.9 = icmp uge i64 %iadd3_carry_val.9, 1
  %P15_to_i32 = zext i1 %carry_ge_1.9 to i32
  %carry_ge_2 = icmp uge i64 %iadd3_carry_val.9, 2
  %P50_to_i32 = zext i1 %carry_ge_2 to i32
  %iadd3_n1.5 = add i32 0, %phi.27
  %iadd3_n2.5 = add i32 %iadd3_n1.5, 0
  %iadd3_cin1_trunc.4 = trunc i32 %P15_to_i32 to i1
  %iadd3_cin1_narrow_zext.4 = zext i1 %iadd3_cin1_trunc.4 to i32
  %iadd3_cin1_add.4 = add i32 %iadd3_n2.5, %iadd3_cin1_narrow_zext.4
  %iadd3_cin2_trunc = trunc i32 %P50_to_i32 to i1
  %iadd3_cin2_narrow_zext.4 = zext i1 %iadd3_cin2_trunc to i32
  %iadd3_cin2_add.4 = add i32 %iadd3_cin1_add.4, %iadd3_cin2_narrow_zext.4
  %iadd3_o1_64.9 = zext i32 %R3_trunc to i64
  %iadd3_o2_64.10 = zext i32 %iadd3_trunc.9 to i64
  %iadd3_o3_64.10 = zext i32 %R3_trunc to i64
  %iadd3_tmp.10 = add i64 %iadd3_o1_64.9, %iadd3_o2_64.10
  %iadd3_tmp2.10 = add i64 %iadd3_tmp.10, %iadd3_o3_64.10
  %iadd3_trunc.10 = trunc i64 %iadd3_tmp2.10 to i32
  %iadd3_carry_val.10 = lshr i64 %iadd3_tmp2.10, 32
  %carry_ge_1.10 = icmp uge i64 %iadd3_carry_val.10, 1
  %P16_to_i32 = zext i1 %carry_ge_1.10 to i32
  %carry_ge_2.1 = icmp uge i64 %iadd3_carry_val.10, 2
  %P51_to_i32 = zext i1 %carry_ge_2.1 to i32
  %iadd3_n1.6 = add i32 0, %iadd3_cin2_add.4
  %iadd3_n2.6 = add i32 %iadd3_n1.6, 0
  %iadd3_cin1_trunc.5 = trunc i32 %P16_to_i32 to i1
  %iadd3_cin1_narrow_zext.5 = zext i1 %iadd3_cin1_trunc.5 to i32
  %iadd3_cin1_add.5 = add i32 %iadd3_n2.6, %iadd3_cin1_narrow_zext.5
  %iadd3_cin2_trunc.1 = trunc i32 %P51_to_i32 to i1
  %iadd3_cin2_narrow_zext.5 = zext i1 %iadd3_cin2_trunc.1 to i32
  %iadd3_cin2_add.5 = add i32 %iadd3_cin1_add.5, %iadd3_cin2_narrow_zext.5
  %isetrp_cmp1.24 = icmp uge i32 %iadd3_trunc.10, %ldc_const.15
  %isetrp_src_to_i32.24 = zext i1 true to i32
  %isetrp_src_to_i1.24 = icmp ne i32 %isetrp_src_to_i32.24, 0
  %isetrp_cmp2.24 = and i1 %isetrp_cmp1.24, %isetrp_src_to_i1.24
  %P17_to_i32 = zext i1 %isetrp_cmp2.24 to i32
  %isetrp_cmp1.25 = icmp sge i32 %iadd3_cin2_add.5, %shf_result.1
  %isetrp_ex_lo_trunc.8 = trunc i32 %P17_to_i32 to i1
  %isetrp_ex_lo_to_i32.8 = zext i1 %isetrp_ex_lo_trunc.8 to i32
  %isetrp_ex_lo_to_i1.8 = icmp ne i32 %isetrp_ex_lo_to_i32.8, 0
  %isetrp_hi_eq.8 = icmp eq i32 %iadd3_cin2_add.5, %shf_result.1
  %isetrp_ex_sel.8 = select i1 %isetrp_hi_eq.8, i1 %isetrp_ex_lo_to_i1.8, i1 %isetrp_cmp1.25
  %isetrp_src_to_i32.25 = zext i1 true to i32
  %isetrp_src_to_i1.25 = icmp ne i32 %isetrp_src_to_i32.25, 0
  %isetrp_cmp2.25 = and i1 %isetrp_ex_sel.8, %isetrp_src_to_i1.25
  %P18_to_i32 = zext i1 %isetrp_cmp2.25 to i32
  %fadd.1 = fadd float %ldg.4, %phi.29
  %iadd3_o1_64.10 = zext i32 %shf_result.2 to i64
  %iadd3_o2_64.11 = zext i32 %iadd3_trunc.8 to i64
  %iadd3_o3_64.11 = zext i32 0 to i64
  %iadd3_tmp.11 = add i64 %iadd3_o1_64.10, %iadd3_o2_64.11
  %iadd3_tmp2.11 = add i64 %iadd3_tmp.11, %iadd3_o3_64.11
  %iadd3_trunc.11 = trunc i64 %iadd3_tmp2.11 to i32
  %iadd3_carry_val.11 = lshr i64 %iadd3_tmp2.11, 32
  %carry_ge_1.11 = icmp uge i64 %iadd3_carry_val.11, 1
  %P52_to_i32 = zext i1 %carry_ge_1.11 to i32
  %fadd.2 = fadd float %fadd.1, %ldg.5
  %iadd3_n1.7 = add i32 %shf_result.3, %imad_with_cin.4
  %iadd3_n2.7 = add i32 %iadd3_n1.7, 0
  %iadd3_cin1_trunc.6 = trunc i32 %P52_to_i32 to i1
  %iadd3_cin1_narrow_zext.6 = zext i1 %iadd3_cin1_trunc.6 to i32
  %iadd3_cin1_add.6 = add i32 %iadd3_n2.7, %iadd3_cin1_narrow_zext.6
  %iadd3_cin2_narrow_zext.6 = zext i1 false to i32
  %iadd3_cin2_add.6 = add i32 %iadd3_cin1_add.6, %iadd3_cin2_narrow_zext.6
  %fadd.3 = fadd float %fadd.2, %ldg.6
  %fadd.4 = fadd float %fadd.3, %ldg.7
  br label %BB_08e0

BB_08e0:                                          ; preds = %BB_0770
  %cond_trunc.15 = trunc i32 %P18_to_i32 to i1
  %cond_not.6 = xor i1 %cond_trunc.15, true
  %pbra_cond_to_i32.15 = zext i1 %cond_not.6 to i32
  %pbra_cond_to_i1.15 = icmp ne i32 %pbra_cond_to_i32.15, 0
  br i1 %pbra_cond_to_i1.15, label %BB_0770, label %BB_0900

BB_0900:                                          ; preds = %BB_08e0, %BB_06e0, %BB_0300, %BB_02f0, %BB_0290
  %phi.32 = phi i32 [ %phi.7, %BB_02f0 ], [ %phi.7, %BB_0300 ], [ %phi.22, %BB_06e0 ], [ %imad_with_cin.4, %BB_08e0 ], [ %phi.7, %BB_0290 ]
  %phi.33 = phi i32 [ %phi.8, %BB_02f0 ], [ %phi.8, %BB_0300 ], [ %phi.23, %BB_06e0 ], [ %iadd3_trunc.8, %BB_08e0 ], [ %phi.8, %BB_0290 ]
  %phi.34 = phi float [ %phi.9, %BB_02f0 ], [ %phi.9, %BB_0300 ], [ %phi.26, %BB_06e0 ], [ %fadd.4, %BB_08e0 ], [ %phi.9, %BB_0290 ]
  %s2ur_cluster_ctarank = call i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank()
  %.268 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 560
  %.269 = bitcast ptr %.268 to ptr
  %ldc_const.16 = load i32, ptr %.269, align 4
  %.270 = zext i32 %s2ur_cluster_ctarank to i64
  %.271 = zext i32 1024 to i64
  %.272 = zext i32 24 to i64
  %.273 = shl i64 %.270, %.272
  %.274 = and i64 %.273, 4294967295
  %.275 = add i64 %.274, %.271
  %.276 = trunc i64 %.275 to i32
  %.277 = zext i32 %tid_x to i64
  %.278 = zext i32 %.276 to i64
  %.279 = zext i32 2 to i64
  %.280 = shl i64 %.277, %.279
  %.281 = and i64 %.280, 4294967295
  %.282 = add i64 %.281, %.278
  %.283 = trunc i64 %.282 to i32
  %isetrp_cmp1.26 = icmp sge i32 %ldc_const.16, 33
  %isetrp_src_to_i32.26 = zext i1 true to i32
  %isetrp_src_to_i1.26 = icmp ne i32 %isetrp_src_to_i32.26, 0
  %isetrp_cmp2.26 = and i1 %isetrp_cmp1.26, %isetrp_src_to_i1.26
  %P19_to_i32 = zext i1 %isetrp_cmp2.26 to i32
  %.284 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.283
  %sts_shared_addr_cast = bitcast ptr addrspace(3) %.284 to ptr addrspace(3)
  store volatile float %phi.34, ptr addrspace(3) %sts_shared_addr_cast, align 4
  br label %BB_0970

BB_0970:                                          ; preds = %BB_0900
  %cond_trunc.16 = trunc i32 %P19_to_i32 to i1
  %cond_not.7 = xor i1 %cond_trunc.16, true
  %pbra_cond_to_i32.16 = zext i1 %cond_not.7 to i32
  %pbra_cond_to_i1.16 = icmp ne i32 %pbra_cond_to_i32.16, 0
  br i1 %pbra_cond_to_i1.16, label %BB_0a80, label %BB_0980

BB_0980:                                          ; preds = %BB_0970
  %.288 = zext i32 0 to i64
  %.289 = zext i32 %R3_trunc to i64
  %.290 = shl i64 %.289, 32
  %shf_concat.4 = or i64 %.288, %.290
  %shf_shift_64.4 = zext i32 1 to i64
  %.291 = lshr i64 %shf_concat.4, %shf_shift_64.4
  %shf_hi.3 = lshr i64 %.291, 32
  %shf_result.4 = trunc i64 %shf_hi.3 to i32
  %.292 = zext i32 0 to i64
  %.293 = zext i32 %R3_trunc to i64
  %.294 = shl i64 %.293, 32
  %shf_concat.5 = or i64 %.292, %.294
  %shf_shift_64.5 = zext i32 2 to i64
  %.295 = lshr i64 %shf_concat.5, %shf_shift_64.5
  %shf_hi.4 = lshr i64 %.295, 32
  %shf_result.5 = trunc i64 %shf_hi.4 to i32
  %isetrp_cmp1.27 = icmp sge i32 %shf_result.4, %ldc_const.16
  %isetrp_src_to_i32.27 = zext i1 true to i32
  %isetrp_src_to_i1.27 = icmp ne i32 %isetrp_src_to_i32.27, 0
  %isetrp_cmp2.27 = and i1 %isetrp_cmp1.27, %isetrp_src_to_i1.27
  %P21_to_i32 = zext i1 %isetrp_cmp2.27 to i32
  br label %BB_09b0

BB_09b0:                                          ; preds = %BB_0980
  %cond_trunc.17 = trunc i32 %P21_to_i32 to i1
  %cond_not.8 = xor i1 %cond_trunc.17, true
  %pbra_cond_to_i32.17 = zext i1 %cond_not.8 to i32
  %pbra_cond_to_i1.17 = icmp ne i32 %pbra_cond_to_i32.17, 0
  br i1 %pbra_cond_to_i1.17, label %BB_800009b0, label %BB_09d0

BB_800009b0:                                      ; preds = %BB_09b0
  call void @llvm.nvvm.barrier0()
  %imad_tmp.14 = mul i32 %shf_result.4, 4
  %imad.17 = add i32 %imad_tmp.14, %.283
  br label %BB_09d0

BB_09d0:                                          ; preds = %BB_800009b0, %BB_09b0
  %phi.35 = phi i32 [ %imad.17, %BB_800009b0 ], [ %shf_result.4, %BB_09b0 ]
  %isetrp_cmp1.28 = icmp sge i32 %shf_result.5, %ldc_const.16
  %isetrp_src_to_i32.28 = zext i1 true to i32
  %isetrp_src_to_i1.28 = icmp ne i32 %isetrp_src_to_i32.28, 0
  %isetrp_cmp2.28 = and i1 %isetrp_cmp1.28, %isetrp_src_to_i1.28
  %P53_to_i32 = zext i1 %isetrp_cmp2.28 to i32
  br label %BB_09e0

BB_09e0:                                          ; preds = %BB_09d0
  %cond_trunc.18 = trunc i32 %P53_to_i32 to i1
  %cond_not.9 = xor i1 %cond_trunc.18, true
  %pbra_cond_to_i32.18 = zext i1 %cond_not.9 to i32
  %pbra_cond_to_i1.18 = icmp ne i32 %pbra_cond_to_i32.18, 0
  br i1 %pbra_cond_to_i1.18, label %BB_800009e0, label %BB_09f0

BB_800009e0:                                      ; preds = %BB_09e0
  %imad_tmp.15 = mul i32 %shf_result.5, 4
  %imad.18 = add i32 %imad_tmp.15, %.283
  br label %BB_09f0

BB_09f0:                                          ; preds = %BB_800009e0, %BB_09e0
  %phi.36 = phi i32 [ %imad.18, %BB_800009e0 ], [ %shf_result.5, %BB_09e0 ]
  %cond_trunc.19 = trunc i32 %P21_to_i32 to i1
  %cond_not.10 = xor i1 %cond_trunc.19, true
  %pbra_cond_to_i32.19 = zext i1 %cond_not.10 to i32
  %pbra_cond_to_i1.19 = icmp ne i32 %pbra_cond_to_i32.19, 0
  br i1 %pbra_cond_to_i1.19, label %BB_800009f0, label %BB_0a30

BB_800009f0:                                      ; preds = %BB_09f0
  %.303 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.35
  %lds_shared_addr_cast = bitcast ptr addrspace(3) %.303 to ptr addrspace(3)
  %lds = load volatile float, ptr addrspace(3) %lds_shared_addr_cast, align 4
  %fadd.5 = fadd float %phi.34, %lds
  call void @llvm.nvvm.barrier0()
  %.304 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.283
  %sts_shared_addr_cast.1 = bitcast ptr addrspace(3) %.304 to ptr addrspace(3)
  store volatile float %fadd.5, ptr addrspace(3) %sts_shared_addr_cast.1, align 4
  %phi_cast_R95_bitcast = bitcast float %lds to i32
  br label %BB_0a30

BB_0a30:                                          ; preds = %BB_800009f0, %BB_09f0
  %phi.37 = phi i32 [ %phi_cast_R95_bitcast, %BB_800009f0 ], [ %phi.33, %BB_09f0 ]
  %phi.38 = phi float [ %fadd.5, %BB_800009f0 ], [ %phi.34, %BB_09f0 ]
  %warp_reconv_mask = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  %cond_trunc.20 = trunc i32 %P53_to_i32 to i1
  %cond_not.11 = xor i1 %cond_trunc.20, true
  %pbra_cond_to_i32.20 = zext i1 %cond_not.11 to i32
  %pbra_cond_to_i1.20 = icmp ne i32 %pbra_cond_to_i32.20, 0
  br i1 %pbra_cond_to_i1.20, label %BB_80000a30, label %BB_0a80

BB_80000a30:                                      ; preds = %BB_0a30
  call void @llvm.nvvm.barrier0()
  %.308 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.36
  %lds_shared_addr_cast.1 = bitcast ptr addrspace(3) %.308 to ptr addrspace(3)
  %lds.1 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.1, align 4
  %fadd.6 = fadd float %lds.1, %phi.38
  call void @llvm.nvvm.barrier0()
  %.309 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.283
  %sts_shared_addr_cast.2 = bitcast ptr addrspace(3) %.309 to ptr addrspace(3)
  store volatile float %fadd.6, ptr addrspace(3) %sts_shared_addr_cast.2, align 4
  %phi_cast_R147_bitcast = bitcast float %fadd.6 to i32
  %phi_cast_R97_bitcast = bitcast float %lds.1 to i32
  br label %BB_0a80

BB_0a80:                                          ; preds = %BB_80000a30, %BB_0a30, %BB_0970
  %phi.39 = phi i32 [ %phi.32, %BB_0970 ], [ %phi_cast_R147_bitcast, %BB_80000a30 ], [ %phi.32, %BB_0a30 ]
  %phi.40 = phi i32 [ %phi.33, %BB_0970 ], [ %phi_cast_R97_bitcast, %BB_80000a30 ], [ %phi.37, %BB_0a30 ]
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.29 = icmp sgt i32 %tid_x, 3
  %isetrp_src_to_i32.29 = zext i1 true to i32
  %isetrp_src_to_i1.29 = icmp ne i32 %isetrp_src_to_i32.29, 0
  %isetrp_cmp2.29 = and i1 %isetrp_cmp1.29, %isetrp_src_to_i1.29
  %P22_to_i32 = zext i1 %isetrp_cmp2.29 to i32
  br label %BB_0ab0

BB_0ab0:                                          ; preds = %BB_0a80
  %cond_trunc.21 = trunc i32 %P22_to_i32 to i1
  %pbra_cond_to_i32.21 = zext i1 %cond_trunc.21 to i32
  %pbra_cond_to_i1.21 = icmp ne i32 %pbra_cond_to_i32.21, 0
  br i1 %pbra_cond_to_i1.21, label %BB_1130, label %BB_0ac0

BB_0ac0:                                          ; preds = %BB_0ab0
  %iadd3_o1_not = xor i32 %tid_x, -1
  %iadd3_o1_neg = add i32 %iadd3_o1_not, 1
  %iadd3_n1.8 = add i32 %iadd3_o1_neg, 31
  %iadd3_n2.8 = add i32 %iadd3_n1.8, 0
  %.314 = zext i32 %iadd3_n2.8 to i64
  %.315 = zext i32 0 to i64
  %.316 = shl i64 %.315, 32
  %lea_funnel.4 = or i64 %.314, %.316
  %.317 = zext i32 1 to i64
  %.318 = zext i32 30 to i64
  %.319 = shl i64 %lea_funnel.4, %.318
  %.320 = lshr i64 %.319, 32
  %.321 = add i64 %.320, %.317
  %.322 = trunc i64 %.321 to i32
  %isetrp_cmp1.30 = icmp uge i32 %iadd3_n2.8, 12
  %isetrp_src_to_i32.30 = zext i1 true to i32
  %isetrp_src_to_i1.30 = icmp ne i32 %isetrp_src_to_i32.30, 0
  %isetrp_cmp2.30 = and i1 %isetrp_cmp1.30, %isetrp_src_to_i1.30
  %P54_to_i32 = zext i1 %isetrp_cmp2.30 to i32
  %.323 = xor i32 %.322, -1
  %.324 = xor i32 3, -1
  %.325 = xor i32 0, -1
  %.326 = and i32 %.322, 3
  %.327 = and i32 %.326, %.325
  %.328 = and i32 %.322, 3
  %.329 = and i32 %.328, 0
  %.330 = or i32 %.327, %.329
  %lop3_pred_cmp.1 = icmp ne i32 %.330, 0
  %lop3_q_to_i32.1 = zext i1 false to i32
  %lop3_q_to_i1.1 = icmp ne i32 %lop3_q_to_i32.1, 0
  %lop3_p.1 = or i1 %lop3_pred_cmp.1, %lop3_q_to_i1.1
  %P25_to_i32 = zext i1 %lop3_p.1 to i32
  br label %BB_0b30

BB_0b30:                                          ; preds = %BB_0ac0
  %cond_trunc.22 = trunc i32 %P25_to_i32 to i1
  %cond_not.12 = xor i1 %cond_trunc.22, true
  %pbra_cond_to_i32.22 = zext i1 %cond_not.12 to i32
  %pbra_cond_to_i1.22 = icmp ne i32 %pbra_cond_to_i32.22, 0
  br i1 %pbra_cond_to_i1.22, label %BB_0c10, label %BB_0b40

BB_0b40:                                          ; preds = %BB_0b30
  %tid_x.1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  br label %BB_0b80

BB_0b80:                                          ; preds = %BB_0be0, %BB_0b40
  %phi.41 = phi i32 [ %tid_x, %BB_0b40 ], [ %viadd.2, %BB_0be0 ]
  %phi.42 = phi i32 [ %.283, %BB_0b40 ], [ %viadd.3, %BB_0be0 ]
  %phi.43 = phi i32 [ %.330, %BB_0b40 ], [ %iadd3_n2.9, %BB_0be0 ]
  %phi.44 = phi float [ 0.000000e+00, %BB_0b40 ], [ %fadd.7, %BB_0be0 ]
  %.334 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.42
  %lds_shared_addr_cast.2 = bitcast ptr addrspace(3) %.334 to ptr addrspace(3)
  %lds.2 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.2, align 4
  %iadd3_n1.9 = add i32 %phi.43, -1
  %iadd3_n2.9 = add i32 %iadd3_n1.9, 0
  %viadd.2 = add i32 %phi.41, 4
  %isetrp_cmp1.31 = icmp ne i32 %iadd3_n2.9, 0
  %isetrp_src_to_i32.31 = zext i1 true to i32
  %isetrp_src_to_i1.31 = icmp ne i32 %isetrp_src_to_i32.31, 0
  %isetrp_cmp2.31 = and i1 %isetrp_cmp1.31, %isetrp_src_to_i1.31
  %P26_to_i32 = zext i1 %isetrp_cmp2.31 to i32
  %viadd.3 = add i32 %phi.42, 16
  %fadd.7 = fadd float %lds.2, %phi.44
  br label %BB_0be0

BB_0be0:                                          ; preds = %BB_0b80
  %cond_trunc.23 = trunc i32 %P26_to_i32 to i1
  %pbra_cond_to_i32.23 = zext i1 %cond_trunc.23 to i32
  %pbra_cond_to_i1.23 = icmp ne i32 %pbra_cond_to_i32.23, 0
  br i1 %pbra_cond_to_i1.23, label %BB_0b80, label %BB_0c10

BB_0c10:                                          ; preds = %BB_0be0, %BB_0b30
  %phi.45 = phi i32 [ %tid_x, %BB_0b30 ], [ %viadd.2, %BB_0be0 ]
  %phi.46 = phi i32 [ %tid_x, %BB_0b30 ], [ %tid_x.1, %BB_0be0 ]
  %phi.47 = phi float [ 0.000000e+00, %BB_0b30 ], [ %fadd.7, %BB_0be0 ]
  %cond_trunc.24 = trunc i32 %P54_to_i32 to i1
  %cond_not.13 = xor i1 %cond_trunc.24, true
  %pbra_cond_to_i32.24 = zext i1 %cond_not.13 to i32
  %pbra_cond_to_i1.24 = icmp ne i32 %pbra_cond_to_i32.24, 0
  br i1 %pbra_cond_to_i1.24, label %BB_1110, label %BB_0c20

BB_0c20:                                          ; preds = %BB_0c10
  %viadd.4 = add i32 %phi.45, -16
  %lop3_a_cast_zext.1 = zext i1 true to i32
  %lop3_b_cast_zext.1 = zext i1 true to i32
  %lop3_c_cast_zext.1 = zext i1 true to i32
  %plop3_a_bit.1 = and i32 %lop3_a_cast_zext.1, 1
  %plop3_b_bit.1 = and i32 %lop3_b_cast_zext.1, 1
  %plop3_c_bit.1 = and i32 %lop3_c_cast_zext.1, 1
  %.338 = xor i32 %plop3_a_bit.1, 1
  %.339 = xor i32 %plop3_b_bit.1, 1
  %.340 = xor i32 %plop3_c_bit.1, 1
  %.341 = and i32 %plop3_a_bit.1, %plop3_b_bit.1
  %.342 = and i32 %.341, %plop3_c_bit.1
  %lop3_pred_cmp.2 = icmp ne i32 %.342, 0
  %lop3_q_to_i32.2 = zext i1 false to i32
  %lop3_q_to_i1.2 = icmp ne i32 %lop3_q_to_i32.2, 0
  %lop3_p.2 = or i1 %lop3_pred_cmp.2, %lop3_q_to_i1.2
  %P27_to_i32 = zext i1 %lop3_p.2 to i32
  %iadd3_o1_not.1 = xor i32 %viadd.4, -1
  %iadd3_o1_neg.1 = add i32 %iadd3_o1_not.1, 1
  %iadd3_n1.10 = add i32 %iadd3_o1_neg.1, 16
  %iadd3_n2.10 = add i32 %iadd3_n1.10, 0
  %isetrp_cmp1.32 = icmp sgt i32 %iadd3_n2.10, 48
  %isetrp_src_to_i32.32 = zext i1 true to i32
  %isetrp_src_to_i1.32 = icmp ne i32 %isetrp_src_to_i32.32, 0
  %isetrp_cmp2.32 = and i1 %isetrp_cmp1.32, %isetrp_src_to_i1.32
  %P57_to_i32 = zext i1 %isetrp_cmp2.32 to i32
  %.343 = zext i32 %phi.45 to i64
  %.344 = zext i32 %.276 to i64
  %.345 = zext i32 2 to i64
  %.346 = shl i64 %.343, %.345
  %.347 = and i64 %.346, 4294967295
  %.348 = add i64 %.347, %.344
  %.349 = trunc i64 %.348 to i32
  %iadd3_n1.11 = add i32 %.349, 32
  %iadd3_n2.11 = add i32 %iadd3_n1.11, 0
  br label %BB_0c90

BB_0c90:                                          ; preds = %BB_0c20
  %cond_trunc.25 = trunc i32 %P57_to_i32 to i1
  %cond_not.14 = xor i1 %cond_trunc.25, true
  %pbra_cond_to_i32.25 = zext i1 %cond_not.14 to i32
  %pbra_cond_to_i1.25 = icmp ne i32 %pbra_cond_to_i32.25, 0
  br i1 %pbra_cond_to_i1.25, label %BB_0ef0, label %BB_0ca0

BB_0ca0:                                          ; preds = %BB_0c90
  %lop3_a_cast_zext.2 = zext i1 true to i32
  %lop3_b_cast_zext.2 = zext i1 true to i32
  %lop3_c_cast_zext.2 = zext i1 true to i32
  %plop3_a_bit.2 = and i32 %lop3_a_cast_zext.2, 1
  %plop3_b_bit.2 = and i32 %lop3_b_cast_zext.2, 1
  %plop3_c_bit.2 = and i32 %lop3_c_cast_zext.2, 1
  %.352 = xor i32 %plop3_a_bit.2, 1
  %.353 = xor i32 %plop3_b_bit.2, 1
  %.354 = xor i32 %plop3_c_bit.2, 1
  %.355 = and i32 %.352, %plop3_b_bit.2
  %.356 = and i32 %.355, %plop3_c_bit.2
  %lop3_pred_cmp.3 = icmp ne i32 %.356, 0
  %lop3_q_to_i32.3 = zext i1 false to i32
  %lop3_q_to_i1.3 = icmp ne i32 %lop3_q_to_i32.3, 0
  %lop3_p.3 = or i1 %lop3_pred_cmp.3, %lop3_q_to_i1.3
  %P28_to_i32 = zext i1 %lop3_p.3 to i32
  br label %BB_0cb0

BB_0cb0:                                          ; preds = %BB_0ee0, %BB_0ca0
  %phi.48 = phi i32 [ %viadd.4, %BB_0ca0 ], [ %viadd.5, %BB_0ee0 ]
  %phi.49 = phi i32 [ %iadd3_n2.11, %BB_0ca0 ], [ %viadd.6, %BB_0ee0 ]
  %phi.50 = phi float [ %phi.47, %BB_0ca0 ], [ %fadd.23, %BB_0ee0 ]
  %lds_addr_memaddr_offset_add = add i32 %phi.49, -32
  %.358 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add
  %lds_shared_addr_cast.3 = bitcast ptr addrspace(3) %.358 to ptr addrspace(3)
  %lds.3 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.3, align 4
  %viadd.5 = add i32 %phi.48, 64
  %lds_addr_memaddr_offset_add.1 = add i32 %phi.49, -16
  %.359 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.1
  %lds_shared_addr_cast.4 = bitcast ptr addrspace(3) %.359 to ptr addrspace(3)
  %lds.4 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.4, align 4
  %isetrp_cmp1.33 = icmp sge i32 %viadd.5, -32
  %isetrp_src_to_i32.33 = zext i1 true to i32
  %isetrp_src_to_i1.33 = icmp ne i32 %isetrp_src_to_i32.33, 0
  %isetrp_cmp2.33 = and i1 %isetrp_cmp1.33, %isetrp_src_to_i1.33
  %P58_to_i32 = zext i1 %isetrp_cmp2.33 to i32
  %.360 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.49
  %lds_shared_addr_cast.5 = bitcast ptr addrspace(3) %.360 to ptr addrspace(3)
  %lds.5 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.5, align 4
  %lds_addr_memaddr_offset_add.2 = add i32 %phi.49, 16
  %.361 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.2
  %lds_shared_addr_cast.6 = bitcast ptr addrspace(3) %.361 to ptr addrspace(3)
  %lds.6 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.6, align 4
  %lds_addr_memaddr_offset_add.3 = add i32 %phi.49, 32
  %.362 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.3
  %lds_shared_addr_cast.7 = bitcast ptr addrspace(3) %.362 to ptr addrspace(3)
  %lds.7 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.7, align 4
  %lds_addr_memaddr_offset_add.4 = add i32 %phi.49, 48
  %.363 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.4
  %lds_shared_addr_cast.8 = bitcast ptr addrspace(3) %.363 to ptr addrspace(3)
  %lds.8 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.8, align 4
  %lds_addr_memaddr_offset_add.5 = add i32 %phi.49, 64
  %.364 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.5
  %lds_shared_addr_cast.9 = bitcast ptr addrspace(3) %.364 to ptr addrspace(3)
  %lds.9 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.9, align 4
  %lds_addr_memaddr_offset_add.6 = add i32 %phi.49, 80
  %.365 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.6
  %lds_shared_addr_cast.10 = bitcast ptr addrspace(3) %.365 to ptr addrspace(3)
  %lds.10 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.10, align 4
  %lds_addr_memaddr_offset_add.7 = add i32 %phi.49, 96
  %.366 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.7
  %lds_shared_addr_cast.11 = bitcast ptr addrspace(3) %.366 to ptr addrspace(3)
  %lds.11 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.11, align 4
  %lds_addr_memaddr_offset_add.8 = add i32 %phi.49, 112
  %.367 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.8
  %lds_shared_addr_cast.12 = bitcast ptr addrspace(3) %.367 to ptr addrspace(3)
  %lds.12 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.12, align 4
  %fadd.8 = fadd float %lds.3, %phi.50
  %lds_addr_memaddr_offset_add.9 = add i32 %phi.49, 160
  %.368 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.9
  %lds_shared_addr_cast.13 = bitcast ptr addrspace(3) %.368 to ptr addrspace(3)
  %lds.13 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.13, align 4
  %fadd.9 = fadd float %fadd.8, %lds.4
  %lds_addr_memaddr_offset_add.10 = add i32 %phi.49, 128
  %.369 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.10
  %lds_shared_addr_cast.14 = bitcast ptr addrspace(3) %.369 to ptr addrspace(3)
  %lds.14 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.14, align 4
  %fadd.10 = fadd float %fadd.9, %lds.5
  %lds_addr_memaddr_offset_add.11 = add i32 %phi.49, 144
  %.370 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.11
  %lds_shared_addr_cast.15 = bitcast ptr addrspace(3) %.370 to ptr addrspace(3)
  %lds.15 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.15, align 4
  %fadd.11 = fadd float %fadd.10, %lds.6
  %lds_addr_memaddr_offset_add.12 = add i32 %phi.49, 176
  %.371 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.12
  %lds_shared_addr_cast.16 = bitcast ptr addrspace(3) %.371 to ptr addrspace(3)
  %lds.16 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.16, align 4
  %fadd.12 = fadd float %fadd.11, %lds.7
  %lds_addr_memaddr_offset_add.13 = add i32 %phi.49, 192
  %.372 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.13
  %lds_shared_addr_cast.17 = bitcast ptr addrspace(3) %.372 to ptr addrspace(3)
  %lds.17 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.17, align 4
  %fadd.13 = fadd float %fadd.12, %lds.8
  %lds_addr_memaddr_offset_add.14 = add i32 %phi.49, 208
  %.373 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.14
  %lds_shared_addr_cast.18 = bitcast ptr addrspace(3) %.373 to ptr addrspace(3)
  %lds.18 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.18, align 4
  %fadd.14 = fadd float %fadd.13, %lds.9
  %fadd.15 = fadd float %fadd.14, %lds.10
  %viadd.6 = add i32 %phi.49, 256
  %fadd.16 = fadd float %fadd.15, %lds.11
  %fadd.17 = fadd float %fadd.16, %lds.12
  %fadd.18 = fadd float %fadd.17, %lds.14
  %fadd.19 = fadd float %fadd.18, %lds.15
  %fadd.20 = fadd float %fadd.19, %lds.13
  %fadd.21 = fadd float %fadd.20, %lds.16
  %fadd.22 = fadd float %fadd.21, %lds.17
  %fadd.23 = fadd float %fadd.22, %lds.18
  br label %BB_0ee0

BB_0ee0:                                          ; preds = %BB_0cb0
  %cond_trunc.26 = trunc i32 %P58_to_i32 to i1
  %cond_not.15 = xor i1 %cond_trunc.26, true
  %pbra_cond_to_i32.26 = zext i1 %cond_not.15 to i32
  %pbra_cond_to_i1.26 = icmp ne i32 %pbra_cond_to_i32.26, 0
  %phi_cast_R153_bitcast = bitcast float %fadd.16 to i32
  br i1 %pbra_cond_to_i1.26, label %BB_0cb0, label %BB_0ef0

BB_0ef0:                                          ; preds = %BB_0ee0, %BB_0c90
  %phi.51 = phi i32 [ %phi.39, %BB_0c90 ], [ %phi_cast_R153_bitcast, %BB_0ee0 ]
  %phi.52 = phi i32 [ %viadd.4, %BB_0c90 ], [ %viadd.5, %BB_0ee0 ]
  %phi.53 = phi i32 [ %iadd3_n2.11, %BB_0c90 ], [ %viadd.6, %BB_0ee0 ]
  %phi.54 = phi float [ %phi.47, %BB_0c90 ], [ %fadd.23, %BB_0ee0 ]
  %phi.55 = phi i32 [ %P27_to_i32, %BB_0c90 ], [ %P28_to_i32, %BB_0ee0 ]
  %iadd3_o1_not.2 = xor i32 %phi.52, -1
  %iadd3_o1_neg.2 = add i32 %iadd3_o1_not.2, 1
  %iadd3_n1.12 = add i32 %iadd3_o1_neg.2, 16
  %iadd3_n2.12 = add i32 %iadd3_n1.12, 0
  %isetrp_cmp1.34 = icmp sgt i32 %iadd3_n2.12, 16
  %isetrp_src_to_i32.34 = zext i1 true to i32
  %isetrp_src_to_i1.34 = icmp ne i32 %isetrp_src_to_i32.34, 0
  %isetrp_cmp2.34 = and i1 %isetrp_cmp1.34, %isetrp_src_to_i1.34
  %P59_to_i32 = zext i1 %isetrp_cmp2.34 to i32
  br label %BB_0f30

BB_0f30:                                          ; preds = %BB_0ef0
  %cond_trunc.27 = trunc i32 %P59_to_i32 to i1
  %cond_not.16 = xor i1 %cond_trunc.27, true
  %pbra_cond_to_i32.27 = zext i1 %cond_not.16 to i32
  %pbra_cond_to_i1.27 = icmp ne i32 %pbra_cond_to_i32.27, 0
  br i1 %pbra_cond_to_i1.27, label %BB_1070, label %BB_0f40

BB_0f40:                                          ; preds = %BB_0f30
  %lds_addr_memaddr_offset_add.15 = add i32 %phi.53, -32
  %.378 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.15
  %lds_shared_addr_cast.19 = bitcast ptr addrspace(3) %.378 to ptr addrspace(3)
  %lds.19 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.19, align 4
  %lop3_a_cast_zext.3 = zext i1 true to i32
  %lop3_b_cast_zext.3 = zext i1 true to i32
  %lop3_c_cast_zext.3 = zext i1 true to i32
  %plop3_a_bit.3 = and i32 %lop3_a_cast_zext.3, 1
  %plop3_b_bit.3 = and i32 %lop3_b_cast_zext.3, 1
  %plop3_c_bit.3 = and i32 %lop3_c_cast_zext.3, 1
  %.379 = xor i32 %plop3_a_bit.3, 1
  %.380 = xor i32 %plop3_b_bit.3, 1
  %.381 = xor i32 %plop3_c_bit.3, 1
  %.382 = and i32 %.379, %plop3_b_bit.3
  %.383 = and i32 %.382, %plop3_c_bit.3
  %lop3_pred_cmp.4 = icmp ne i32 %.383, 0
  %lop3_q_to_i32.4 = zext i1 false to i32
  %lop3_q_to_i1.4 = icmp ne i32 %lop3_q_to_i32.4, 0
  %lop3_p.4 = or i1 %lop3_pred_cmp.4, %lop3_q_to_i1.4
  %P30_to_i32 = zext i1 %lop3_p.4 to i32
  %viadd.7 = add i32 %phi.52, 32
  %lds_addr_memaddr_offset_add.16 = add i32 %phi.53, -16
  %.384 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.16
  %lds_shared_addr_cast.20 = bitcast ptr addrspace(3) %.384 to ptr addrspace(3)
  %lds.20 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.20, align 4
  %.385 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.53
  %lds_shared_addr_cast.21 = bitcast ptr addrspace(3) %.385 to ptr addrspace(3)
  %lds.21 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.21, align 4
  %lds_addr_memaddr_offset_add.17 = add i32 %phi.53, 16
  %.386 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.17
  %lds_shared_addr_cast.22 = bitcast ptr addrspace(3) %.386 to ptr addrspace(3)
  %lds.22 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.22, align 4
  %lds_addr_memaddr_offset_add.18 = add i32 %phi.53, 32
  %.387 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.18
  %lds_shared_addr_cast.23 = bitcast ptr addrspace(3) %.387 to ptr addrspace(3)
  %lds.23 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.23, align 4
  %lds_addr_memaddr_offset_add.19 = add i32 %phi.53, 48
  %.388 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.19
  %lds_shared_addr_cast.24 = bitcast ptr addrspace(3) %.388 to ptr addrspace(3)
  %lds.24 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.24, align 4
  %lds_addr_memaddr_offset_add.20 = add i32 %phi.53, 64
  %.389 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.20
  %lds_shared_addr_cast.25 = bitcast ptr addrspace(3) %.389 to ptr addrspace(3)
  %lds.25 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.25, align 4
  %lds_addr_memaddr_offset_add.21 = add i32 %phi.53, 80
  %.390 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.21
  %lds_shared_addr_cast.26 = bitcast ptr addrspace(3) %.390 to ptr addrspace(3)
  %lds.26 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.26, align 4
  %iadd3_n1.13 = add i32 %phi.53, 128
  %iadd3_n2.13 = add i32 %iadd3_n1.13, 0
  %fadd.24 = fadd float %phi.54, %lds.19
  %fadd.25 = fadd float %fadd.24, %lds.20
  %fadd.26 = fadd float %fadd.25, %lds.21
  %fadd.27 = fadd float %fadd.26, %lds.22
  %fadd.28 = fadd float %fadd.27, %lds.23
  %fadd.29 = fadd float %fadd.28, %lds.24
  %fadd.30 = fadd float %fadd.29, %lds.25
  %fadd.31 = fadd float %fadd.30, %lds.26
  %phi_cast_R155_bitcast = bitcast float %lds.20 to i32
  %phi_cast_R117_bitcast = bitcast float %fadd.30 to i32
  br label %BB_1070

BB_1070:                                          ; preds = %BB_0f40, %BB_0f30
  %phi.56 = phi i32 [ %phi_cast_R155_bitcast, %BB_0f40 ], [ %phi.51, %BB_0f30 ]
  %phi.57 = phi i32 [ %phi_cast_R117_bitcast, %BB_0f40 ], [ %iadd3_n2.12, %BB_0f30 ]
  %phi.58 = phi i32 [ %viadd.7, %BB_0f40 ], [ %phi.52, %BB_0f30 ]
  %phi.59 = phi i32 [ %iadd3_n2.13, %BB_0f40 ], [ %phi.53, %BB_0f30 ]
  %phi.60 = phi float [ %fadd.31, %BB_0f40 ], [ %phi.54, %BB_0f30 ]
  %phi.61 = phi i32 [ %P30_to_i32, %BB_0f40 ], [ %phi.55, %BB_0f30 ]
  %isetrp_src_trunc.2 = trunc i32 %phi.61 to i1
  %isetrp_cmp1.35 = icmp slt i32 %phi.58, 16
  %isetrp_src_to_i32.35 = zext i1 %isetrp_src_trunc.2 to i32
  %isetrp_src_to_i1.35 = icmp ne i32 %isetrp_src_to_i32.35, 0
  %isetrp_cmp2.35 = or i1 %isetrp_cmp1.35, %isetrp_src_to_i1.35
  %P32_to_i32 = zext i1 %isetrp_cmp2.35 to i32
  br label %BB_1090

BB_1090:                                          ; preds = %BB_1070
  %cond_trunc.28 = trunc i32 %P32_to_i32 to i1
  %pbra_cond_to_i32.28 = zext i1 %cond_trunc.28 to i32
  %pbra_cond_to_i1.28 = icmp ne i32 %pbra_cond_to_i32.28, 0
  br i1 %pbra_cond_to_i1.28, label %BB_80001090, label %BB_1110

BB_80001090:                                      ; preds = %BB_1090
  %lds_addr_memaddr_offset_add.22 = add i32 %phi.59, -32
  %.394 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.22
  %lds_shared_addr_cast.27 = bitcast ptr addrspace(3) %.394 to ptr addrspace(3)
  %lds.27 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.27, align 4
  %lds_addr_memaddr_offset_add.23 = add i32 %phi.59, -16
  %.395 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.23
  %lds_shared_addr_cast.28 = bitcast ptr addrspace(3) %.395 to ptr addrspace(3)
  %lds.28 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.28, align 4
  %.396 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.59
  %lds_shared_addr_cast.29 = bitcast ptr addrspace(3) %.396 to ptr addrspace(3)
  %lds.29 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.29, align 4
  %lds_addr_memaddr_offset_add.24 = add i32 %phi.59, 16
  %.397 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.24
  %lds_shared_addr_cast.30 = bitcast ptr addrspace(3) %.397 to ptr addrspace(3)
  %lds.30 = load volatile float, ptr addrspace(3) %lds_shared_addr_cast.30, align 4
  %fadd.32 = fadd float %phi.60, %lds.27
  %fadd.33 = fadd float %fadd.32, %lds.28
  %fadd.34 = fadd float %fadd.33, %lds.29
  %fadd.35 = fadd float %fadd.34, %lds.30
  %phi_cast_R120_bitcast = bitcast float %fadd.32 to i32
  br label %BB_1110

BB_1110:                                          ; preds = %BB_80001090, %BB_1090, %BB_0c10
  %phi.62 = phi i32 [ %phi.39, %BB_0c10 ], [ %phi.56, %BB_80001090 ], [ %phi.56, %BB_1090 ]
  %phi.63 = phi i32 [ %phi.45, %BB_0c10 ], [ %phi_cast_R120_bitcast, %BB_80001090 ], [ %phi.57, %BB_1090 ]
  %phi.64 = phi float [ %phi.47, %BB_0c10 ], [ %fadd.35, %BB_80001090 ], [ %phi.60, %BB_1090 ]
  %warp_reconv_mask.1 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  %.399 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.283
  %sts_shared_addr_cast.3 = bitcast ptr addrspace(3) %.399 to ptr addrspace(3)
  store volatile float %phi.64, ptr addrspace(3) %sts_shared_addr_cast.3, align 4
  br label %BB_1130

BB_1130:                                          ; preds = %BB_1110, %BB_0ab0
  %phi.65 = phi i32 [ %phi.62, %BB_1110 ], [ %phi.39, %BB_0ab0 ]
  %phi.66 = phi i32 [ %phi.63, %BB_1110 ], [ %phi.40, %BB_0ab0 ]
  %phi.67 = phi i32 [ %phi.46, %BB_1110 ], [ %tid_x, %BB_0ab0 ]
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.36 = icmp ne i32 %phi.67, 0
  %isetrp_src_to_i32.36 = zext i1 true to i32
  %isetrp_src_to_i1.36 = icmp ne i32 %isetrp_src_to_i32.36, 0
  %isetrp_cmp2.36 = and i1 %isetrp_cmp1.36, %isetrp_src_to_i1.36
  %P36_to_i32 = zext i1 %isetrp_cmp2.36 to i32
  br label %BB_1160

BB_1160:                                          ; preds = %BB_1130
  %cond_trunc.29 = trunc i32 %P36_to_i32 to i1
  %pbra_cond_to_i32.29 = zext i1 %cond_trunc.29 to i32
  %pbra_cond_to_i1.29 = icmp ne i32 %pbra_cond_to_i32.29, 0
  br i1 %pbra_cond_to_i1.29, label %BB_80001160, label %BB_1170

BB_1170:                                          ; preds = %BB_1160
  %s2ur_ctaid_z.1 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %fsetrp_cmp1.2 = fcmp une float %phi.3, 0.000000e+00
  %fsetrp_cmp2.2 = and i1 %fsetrp_cmp1.2, true
  %P37_to_i32 = zext i1 %fsetrp_cmp2.2 to i32
  %.404 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 616
  %.405 = bitcast ptr %.404 to ptr
  %ldc_const.17 = load i64, ptr %.405, align 8
  %"UR9:UR8_r0.2" = trunc i64 %ldc_const.17 to i32
  %"UR9:UR8_r1_shift.2" = lshr i64 %ldc_const.17, 32
  %"UR9:UR8_r1.2" = trunc i64 %"UR9:UR8_r1_shift.2" to i32
  %.406 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.276
  %lds_shared_addr_cast.31 = bitcast ptr addrspace(3) %.406 to ptr addrspace(3)
  %lds.31 = load volatile i128, ptr addrspace(3) %lds_shared_addr_cast.31, align 8
  %"R7:R6:R5:R4_r0" = trunc i128 %lds.31 to i32
  %"R7:R6:R5:R4_r1_shift" = lshr i128 %lds.31, 32
  %"R7:R6:R5:R4_r1" = trunc i128 %"R7:R6:R5:R4_r1_shift" to i32
  %"R7:R6:R5:R4_r2_shift" = lshr i128 %lds.31, 64
  %"R7:R6:R5:R4_r2" = trunc i128 %"R7:R6:R5:R4_r2_shift" to i32
  %"R7:R6:R5:R4_r3_shift" = lshr i128 %lds.31, 96
  %"R7:R6:R5:R4_r3" = trunc i128 %"R7:R6:R5:R4_r3_shift" to i32
  %.407 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 604
  %.408 = bitcast ptr %.407 to ptr
  %ldc_const.18 = load i32, ptr %.408, align 4
  br label %BB_11c0

BB_11c0:                                          ; preds = %BB_1170
  %cond_trunc.30 = trunc i32 %P37_to_i32 to i1
  %pbra_cond_to_i32.30 = zext i1 %cond_trunc.30 to i32
  %pbra_cond_to_i1.30 = icmp ne i32 %pbra_cond_to_i32.30, 0
  br i1 %pbra_cond_to_i1.30, label %BB_800011c0, label %BB_11d0

BB_800011c0:                                      ; preds = %BB_11c0
  %.411 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 584
  %.412 = bitcast ptr %.411 to ptr
  %ldc_const.19 = load i64, ptr %.412, align 8
  %"R9:R8_r0.4" = trunc i64 %ldc_const.19 to i32
  %"R9:R8_r1_shift.4" = lshr i64 %ldc_const.19, 32
  %"R9:R8_r1.4" = trunc i64 %"R9:R8_r1_shift.4" to i32
  br label %BB_11d0

BB_11d0:                                          ; preds = %BB_800011c0, %BB_11c0
  %phi.68 = phi i32 [ %"R9:R8_r1.4", %BB_800011c0 ], [ %phi.65, %BB_11c0 ]
  %phi.69 = phi i32 [ %"R9:R8_r0.4", %BB_800011c0 ], [ %phi.66, %BB_11c0 ]
  %imad_addend_r0_ext.3 = zext i32 0 to i64
  %imad_addend_packed_0.3 = or i64 0, %imad_addend_r0_ext.3
  %imad_addend_r1_ext.3 = zext i32 0 to i64
  %imad_addend_r1_shift.3 = shl i64 %imad_addend_r1_ext.3, 32
  %imad_addend_packed_1.3 = or i64 %imad_addend_packed_0.3, %imad_addend_r1_shift.3
  %imad_lhs_64.3 = zext i32 %s2ur_ctaid_z.1 to i64
  %imad_rhs_64.3 = zext i32 %"UR9:UR8_r0.2" to i64
  %imad_tmp_64.3 = mul i64 %imad_lhs_64.3, %imad_rhs_64.3
  %imad.19 = add i64 %imad_tmp_64.3, %imad_addend_packed_1.3
  %"UR5:UR4_r0" = trunc i64 %imad.19 to i32
  %"UR5:UR4_r1_shift" = lshr i64 %imad.19, 32
  %"UR5:UR4_r1" = trunc i64 %"UR5:UR4_r1_shift" to i32
  %imad_tmp.16 = mul i32 %s2ur_ctaid_z.1, %"UR9:UR8_r1.2"
  %imad.20 = add i32 %imad_tmp.16, %"UR5:UR4_r1"
  %.414 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 608
  %.415 = bitcast ptr %.414 to ptr
  %ldc_const.20 = load i64, ptr %.415, align 8
  %"UR9:UR8_r0.3" = trunc i64 %ldc_const.20 to i32
  %"UR9:UR8_r1_shift.3" = lshr i64 %ldc_const.20, 32
  %"UR9:UR8_r1.3" = trunc i64 %"UR9:UR8_r1_shift.3" to i32
  %r2p_shr_1 = lshr i32 %ldc_const.18, 1
  %r2p_p1 = trunc i32 %r2p_shr_1 to i1
  %P60_to_i32 = zext i1 %r2p_p1 to i32
  %r2p_shr_2 = lshr i32 %ldc_const.18, 2
  %r2p_p2 = trunc i32 %r2p_shr_2 to i1
  %P12_to_i32 = zext i1 %r2p_p2 to i32
  %.416 = zext i32 %"UR5:UR4_r0" to i64
  %.417 = zext i32 %"UR9:UR8_r0.3" to i64
  %.418 = zext i32 2 to i64
  %.419 = shl i64 %.416, %.418
  %.420 = and i64 %.419, 4294967295
  %.421 = add i64 %.420, %.417
  %.422 = trunc i64 %.421 to i32
  %.423 = lshr i64 %.421, 32
  %.424 = trunc i64 %.423 to i1
  %P69_to_i32 = zext i1 %.424 to i32
  %.425 = zext i32 %"UR5:UR4_r0" to i64
  %.426 = zext i32 %imad.20 to i64
  %.427 = shl i64 %.426, 32
  %lea_funnel.5 = or i64 %.425, %.427
  %.428 = zext i32 %"UR9:UR8_r1.3" to i64
  %.429 = zext i32 2 to i64
  %.430 = shl i64 %lea_funnel.5, %.429
  %.431 = lshr i64 %.430, 32
  %.432 = add i64 %.431, %.428
  %lea_cin_trunc.4 = trunc i32 %P69_to_i32 to i1
  %.433 = zext i1 %lea_cin_trunc.4 to i64
  %.434 = add i64 %.432, %.433
  %.435 = trunc i64 %.434 to i32
  br label %BB_1240

BB_1240:                                          ; preds = %BB_11d0
  %cond_trunc.31 = trunc i32 %P37_to_i32 to i1
  %pbra_cond_to_i32.31 = zext i1 %cond_trunc.31 to i32
  %pbra_cond_to_i1.31 = icmp ne i32 %pbra_cond_to_i32.31, 0
  %phi_cast_R162_bitcast = bitcast i32 %phi.68 to float
  br i1 %pbra_cond_to_i1.31, label %BB_80001240, label %BB_1250

BB_80001240:                                      ; preds = %BB_1240
  %ldg_addr_r0_ext.8 = zext i32 %phi.69 to i64
  %ldg_addr_packed_0.8 = or i64 0, %ldg_addr_r0_ext.8
  %ldg_addr_r1_ext.8 = zext i32 %phi.68 to i64
  %ldg_addr_r1_shift.8 = shl i64 %ldg_addr_r1_ext.8, 32
  %ldg_addr_packed_1.8 = or i64 %ldg_addr_packed_0.8, %ldg_addr_r1_shift.8
  %"R162:R125_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.8 to ptr addrspace(1)
  %ldg.8 = load float, ptr addrspace(1) %"R162:R125_addr_ptr", align 4
  br label %BB_1250

BB_1250:                                          ; preds = %BB_80001240, %BB_1240
  %phi.70 = phi float [ %ldg.8, %BB_80001240 ], [ %phi_cast_R162_bitcast, %BB_1240 ]
  %imad_tmp.17 = mul i32 0, 0
  %imad.21 = add i32 %imad_tmp.17, %.422
  %imad_tmp.18 = mul i32 0, 0
  %imad.22 = add i32 %imad_tmp.18, %.435
  br label %BB_1270

BB_1270:                                          ; preds = %BB_1250
  %cond_trunc.32 = trunc i32 %P12_to_i32 to i1
  %pbra_cond_to_i32.32 = zext i1 %cond_trunc.32 to i32
  %pbra_cond_to_i1.32 = icmp ne i32 %pbra_cond_to_i32.32, 0
  br i1 %pbra_cond_to_i1.32, label %BB_80001270, label %BB_1280

BB_80001270:                                      ; preds = %BB_1270
  %ldg_addr_r0_ext.9 = zext i32 %imad.21 to i64
  %ldg_addr_packed_0.9 = or i64 0, %ldg_addr_r0_ext.9
  %ldg_addr_r1_ext.9 = zext i32 %imad.22 to i64
  %ldg_addr_r1_shift.9 = shl i64 %ldg_addr_r1_ext.9, 32
  %ldg_addr_packed_1.9 = or i64 %ldg_addr_packed_0.9, %ldg_addr_r1_shift.9
  %"R131:R241_addr_ptr" = inttoptr i64 %ldg_addr_packed_1.9 to ptr addrspace(1)
  %ldg.9 = load float, ptr addrspace(1) %"R131:R241_addr_ptr", align 4
  br label %BB_1280

BB_1280:                                          ; preds = %BB_80001270, %BB_1270
  %phi.71 = phi float [ %ldg.9, %BB_80001270 ], [ 0.000000e+00, %BB_1270 ]
  %fadd_rhs_bitcast = bitcast i32 %"R7:R6:R5:R4_r0" to float
  %fadd.36 = fadd float 0.000000e+00, %fadd_rhs_bitcast
  %fadd_rhs_bitcast.1 = bitcast i32 %"R7:R6:R5:R4_r1" to float
  %fadd.37 = fadd float %fadd.36, %fadd_rhs_bitcast.1
  %fadd_rhs_bitcast.2 = bitcast i32 %"R7:R6:R5:R4_r2" to float
  %fadd.38 = fadd float %fadd.37, %fadd_rhs_bitcast.2
  %.442 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 592
  %.443 = bitcast ptr %.442 to ptr
  %ldc_const.21 = load i64, ptr %.443, align 8
  %"R5:R4_r0.1" = trunc i64 %ldc_const.21 to i32
  %"R5:R4_r1_shift.1" = lshr i64 %ldc_const.21, 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %fadd_rhs_bitcast.3 = bitcast i32 %"R7:R6:R5:R4_r3" to float
  %fadd.39 = fadd float %fadd.38, %fadd_rhs_bitcast.3
  br label %BB_12e0

BB_12e0:                                          ; preds = %BB_1280
  %cond_trunc.33 = trunc i32 %P37_to_i32 to i1
  %pbra_cond_to_i32.33 = zext i1 %cond_trunc.33 to i32
  %pbra_cond_to_i1.33 = icmp ne i32 %pbra_cond_to_i32.33, 0
  %phi_cast_R215_bitcast = bitcast i32 0 to float
  br i1 %pbra_cond_to_i1.33, label %BB_800012e0, label %BB_12f0

BB_800012e0:                                      ; preds = %BB_12e0
  %fmul = fmul float %phi.70, %phi.3
  br label %BB_12f0

BB_12f0:                                          ; preds = %BB_800012e0, %BB_12e0
  %phi.72 = phi float [ %fmul, %BB_800012e0 ], [ %phi_cast_R215_bitcast, %BB_12e0 ]
  %ffma = call float @llvm.fma.f32(float %fadd.39, float %phi.2, float %phi.72)
  %sel_false = bitcast i32 2143289344 to float
  %sel_pred_trunc.8 = trunc i32 %P60_to_i32 to i1
  %sel_pred_to_i32.8 = zext i1 %sel_pred_trunc.8 to i32
  %sel_pred_to_i1.8 = icmp ne i32 %sel_pred_to_i32.8, 0
  %sel.8 = select i1 %sel_pred_to_i1.8, float 0.000000e+00, float %sel_false
  %fadd.40 = fadd float %ffma, %phi.71
  %fsetrp_cmp1.3 = fcmp uge float %fadd.40, %sel.8
  %fsetrp_cmp2.3 = and i1 %fsetrp_cmp1.3, true
  %P38_to_i32 = zext i1 %fsetrp_cmp2.3 to i32
  %sel_pred_trunc.9 = trunc i32 %P38_to_i32 to i1
  %sel_pred_not = xor i1 %sel_pred_trunc.9, true
  %sel_pred_to_i32.9 = zext i1 %sel_pred_not to i32
  %sel_pred_to_i1.9 = icmp ne i32 %sel_pred_to_i32.9, 0
  %sel.9 = select i1 %sel_pred_to_i1.9, float %sel.8, float %fadd.40
  %stg_addr_r0_ext = zext i32 %"R5:R4_r0.1" to i64
  %stg_addr_packed_0 = or i64 0, %stg_addr_r0_ext
  %stg_addr_r1_ext = zext i32 %"R5:R4_r1.1" to i64
  %stg_addr_r1_shift = shl i64 %stg_addr_r1_ext, 32
  %stg_addr_packed_1 = or i64 %stg_addr_packed_0, %stg_addr_r1_shift
  %"R317:R299_addr_ptr" = inttoptr i64 %stg_addr_packed_1 to ptr addrspace(1)
  store float %sel.9, ptr addrspace(1) %"R317:R299_addr_ptr", align 4
  ret void

BB_80001160:                                      ; preds = %BB_1160
  ret void

exit_0150:                                        ; preds = %BB_80000150
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #0

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { convergent nocallback nounwind }
attributes #2 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }

!nvvmir.version = !{!0, !0}
!nvvm.annotations = !{!1, !2, !3, !4, !5, !6, !7, !8}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"kernel", i32 1}
!2 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"maxntidx", i32 128}
!3 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"maxntidy", i32 1}
!4 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"maxntidz", i32 1}
!5 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"kernel", i32 1}
!6 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"maxntidx", i32 128}
!7 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"maxntidy", i32 1}
!8 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"maxntidz", i32 1}
