; ModuleID = '/net/netscratch/cahn45/Vortex_Agent/experiments/integ_lit/ir/sdot.raw.ll'
source_filename = "llvm-link"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@shared_mem = external addrspace(3) global [32768 x i8], align 16

define void @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_([56 x i8] %arg_528) {
EntryBB_0000:
  %param_local = alloca [592 x i8], align 16
  %.3 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 528
  store [56 x i8] %arg_528, ptr %.3, align 16
  %.6 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 568
  %ldc_const = load i64, ptr %.6, align 8
  %"R9:R8_r1_shift" = lshr i64 %ldc_const, 32
  %"R9:R8_r1" = trunc i64 %"R9:R8_r1_shift" to i32
  %.8 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 576
  %ldc_const.1 = load i64, ptr %.8, align 8
  %"UR9:UR8_r1_shift" = lshr i64 %ldc_const.1, 32
  %"UR9:UR8_r1" = trunc i64 %"UR9:UR8_r1_shift" to i32
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %ctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %nctaid_x = call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x()
  %0 = icmp sgt i64 %ldc_const, 0
  %1 = icmp eq i64 %ldc_const, %ldc_const.1
  br label %BB_00c0

BB_00c0:                                          ; preds = %EntryBB_0000
  %2 = zext i1 %0 to i32
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %BB_800000c0, label %BB_00d0

BB_800000c0:                                      ; preds = %BB_00c0
  %4 = zext i1 %1 to i32
  %5 = icmp ne i32 %4, 0
  br i1 %5, label %BB_0420, label %BB_00d0

BB_00d0:                                          ; preds = %BB_800000c0, %BB_00c0
  %.13 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  %ldc_const.2 = load i64, ptr %.13, align 8
  %"R7:R6_r0" = trunc i64 %ldc_const.2 to i32
  %"R7:R6_r1_shift" = lshr i64 %ldc_const.2, 32
  %"R7:R6_r1" = trunc i64 %"R7:R6_r1_shift" to i32
  %6 = sext i32 %tid_x to i64
  %ldc_const.3 = load i64, ptr %.3, align 8
  %.21 = zext i32 %ctaid_x to i64
  %.24 = shl i64 %.21, 7
  %.30 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 536
  %ldc_const.4 = load i64, ptr %.30, align 8
  %7 = add i64 %6, %.24
  %8 = icmp sge i64 %7, %ldc_const.2
  br label %BB_0160

BB_0160:                                          ; preds = %BB_00d0
  %9 = zext i1 %8 to i32
  %10 = icmp ne i32 %9, 0
  br i1 %10, label %BB_0940, label %BB_0170

BB_0170:                                          ; preds = %BB_0160
  %iadd3_o1_raw64 = zext i32 %"R7:R6_r0" to i64
  %iadd3_o1_not64 = xor i64 %iadd3_o1_raw64, -1
  %.46 = zext i32 %"UR9:UR8_r1" to i64
  %.47 = shl i64 %.46, 32
  %.48 = ashr i64 %.47, 31
  %shf_hi.1 = lshr i64 %.48, 32
  %shf_result.1 = trunc i64 %shf_hi.1 to i32
  %11 = sext i32 %shf_result.1 to i64
  %.50 = zext i32 %"R9:R8_r1" to i64
  %.51 = shl i64 %.50, 32
  %.52 = ashr i64 %.51, 31
  %shf_hi.2 = lshr i64 %.52, 32
  %shf_result.2 = trunc i64 %shf_hi.2 to i32
  %12 = sext i32 %shf_result.2 to i64
  %imad_addend_not = xor i32 %"R7:R6_r1", -1
  %13 = and i64 %iadd3_o1_not64, 4294967295
  %14 = zext i32 %imad_addend_not to i64
  %15 = shl i64 %14, 32
  %16 = add i64 %13, 1
  %17 = add i64 %16, 1
  %18 = add i64 %17, %15
  %19 = mul i64 %18, %ldc_const
  %20 = mul i64 %18, %ldc_const.1
  %21 = and i64 %12, %19
  %22 = and i64 %20, %11
  br label %BB_02b0

BB_02b0:                                          ; preds = %BB_03f0, %BB_0170
  %23 = phi i64 [ %7, %BB_0170 ], [ %30, %BB_03f0 ]
  %phi.2 = phi float [ 0.000000e+00, %BB_0170 ], [ %ffma, %BB_03f0 ]
  %24 = mul i64 %23, %ldc_const
  %25 = add i64 %24, %21
  %26 = mul i64 %23, %ldc_const.1
  %27 = add i64 %26, %22
  %.117 = shl i64 %25, 2
  %28 = add i64 %ldc_const.3, %.117
  %.128 = shl i64 %27, 2
  %29 = add i64 %ldc_const.4, %.128
  %"R67:R63_addr_ptr" = inttoptr i64 %28 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R67:R63_addr_ptr", align 4
  %"R137:R47_addr_ptr" = inttoptr i64 %29 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R137:R47_addr_ptr", align 4
  %imad_lhs_64.4 = zext i32 %nctaid_x to i64
  %imad_tmp_64.4 = mul i64 %imad_lhs_64.4, 128
  %30 = add i64 %imad_tmp_64.4, %23
  %31 = icmp sge i64 %30, %ldc_const.2
  %ffma = call float @llvm.fma.f32(float %ldg, float %ldg.1, float %phi.2)
  br label %BB_03f0

BB_03f0:                                          ; preds = %BB_02b0
  %cond_not = xor i1 %31, true
  br i1 %cond_not, label %BB_02b0, label %BB_0940

BB_0420:                                          ; preds = %BB_800000c0
  %32 = sext i32 %tid_x to i64
  %33 = icmp ne i64 %ldc_const, 1
  %imad_lhs_64.5 = zext i32 %ctaid_x to i64
  %imad_tmp_64.5 = mul i64 %imad_lhs_64.5, 128
  %34 = add i64 %imad_tmp_64.5, %32
  br label %BB_0480

BB_0480:                                          ; preds = %BB_0420
  %cond_not.1 = xor i1 %33, true
  br i1 %cond_not.1, label %BB_0680, label %BB_0490

BB_0490:                                          ; preds = %BB_0480
  %.142 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  %ldc_const.5 = load i64, ptr %.142, align 8
  %ldc_const.6 = load i64, ptr %.3, align 8
  %.146 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 536
  %ldc_const.7 = load i64, ptr %.146, align 8
  %35 = icmp sge i64 %34, %ldc_const.5
  br label %BB_04f0

BB_04f0:                                          ; preds = %BB_0490
  %36 = zext i1 %35 to i32
  %37 = icmp ne i32 %36, 0
  br i1 %37, label %BB_0940, label %BB_0500

BB_0500:                                          ; preds = %BB_04f0
  br label %BB_0510

BB_0510:                                          ; preds = %BB_0650, %BB_0500
  %38 = phi i64 [ %34, %BB_0500 ], [ %42, %BB_0650 ]
  %phi.5 = phi float [ 0.000000e+00, %BB_0500 ], [ %ffma.1, %BB_0650 ]
  %39 = mul i64 %38, %ldc_const
  %.154 = shl i64 %39, 2
  %40 = add i64 %.154, %ldc_const.6
  %41 = add i64 %.154, %ldc_const.7
  %"R153:R70_addr_ptr" = inttoptr i64 %40 to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R153:R70_addr_ptr", align 4
  %"R174:R164_addr_ptr" = inttoptr i64 %41 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R174:R164_addr_ptr", align 4
  %imad_lhs_64.7 = zext i32 %nctaid_x to i64
  %imad_tmp_64.7 = mul i64 %imad_lhs_64.7, 128
  %42 = add i64 %imad_tmp_64.7, %38
  %43 = icmp sge i64 %42, %ldc_const.5
  %ffma.1 = call float @llvm.fma.f32(float %ldg.2, float %ldg.3, float %phi.5)
  br label %BB_0650

BB_0650:                                          ; preds = %BB_0510
  %cond_not.2 = xor i1 %43, true
  br i1 %cond_not.2, label %BB_0510, label %BB_0940

BB_0680:                                          ; preds = %BB_0480
  %.157 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 560
  %ldc_const.8 = load i64, ptr %.157, align 8
  %.162 = shl i64 %34, 1
  %.163 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 536
  %ldc_const.9 = load i64, ptr %.163, align 8
  %44 = icmp sge i64 %.162, %ldc_const.8
  %ldc_const.10 = load i64, ptr %.3, align 8
  br label %BB_0710

BB_0710:                                          ; preds = %BB_0680
  %45 = zext i1 %44 to i32
  %46 = icmp ne i32 %45, 0
  br i1 %46, label %BB_0910, label %BB_0720

BB_0720:                                          ; preds = %BB_0710
  br label %BB_0740

BB_0740:                                          ; preds = %BB_0900, %BB_0720
  %47 = phi i64 [ %.162, %BB_0720 ], [ %49, %BB_0900 ]
  %phi.6 = phi float [ 0.000000e+00, %BB_0720 ], [ %phi.14, %BB_0900 ]
  %phi.7 = phi float [ 0.000000e+00, %BB_0720 ], [ %phi.15, %BB_0900 ]
  %phi.9 = phi float [ 0.000000e+00, %BB_0720 ], [ %phi.16, %BB_0900 ]
  %phi.10 = phi float [ 0.000000e+00, %BB_0720 ], [ %phi.17, %BB_0900 ]
  %48 = icmp sge i64 %47, %ldc_const.8
  %imad_lhs_64.8 = zext i32 %nctaid_x to i64
  %imad_tmp_64.8 = mul i64 %imad_lhs_64.8, 256
  %49 = add i64 %imad_tmp_64.8, %47
  %50 = icmp sge i64 %49, %ldc_const.8
  br label %BB_07c0

BB_07c0:                                          ; preds = %BB_0740
  %51 = zext i1 %48 to i32
  %52 = icmp ne i32 %51, 0
  br i1 %52, label %BB_08d0, label %BB_07d0

BB_07d0:                                          ; preds = %BB_07c0
  %.177 = shl i64 %47, 2
  %53 = add i64 %47, 1
  %54 = icmp sge i64 %53, %ldc_const.8
  %55 = add i64 %.177, %ldc_const.10
  %56 = add i64 %.177, %ldc_const.9
  %"R158:R24_addr_ptr" = inttoptr i64 %55 to ptr addrspace(1)
  %ldg.4 = load float, ptr addrspace(1) %"R158:R24_addr_ptr", align 4
  br label %BB_0880

BB_0880:                                          ; preds = %BB_07d0
  %cond_not.3 = xor i1 %54, true
  br i1 %cond_not.3, label %BB_80000880, label %BB_0890

BB_80000880:                                      ; preds = %BB_0880
  %ldg_addr_memaddr_offset_add = add i64 %55, 4
  %"R158:R24_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add to ptr addrspace(1)
  %ldg.5 = load float, ptr addrspace(1) %"R158:R24_addr_ptr.1", align 4
  br label %BB_0890

BB_0890:                                          ; preds = %BB_80000880, %BB_0880
  %phi.12 = phi float [ %ldg.5, %BB_80000880 ], [ %phi.6, %BB_0880 ]
  %"R5:R169_addr_ptr" = inttoptr i64 %56 to ptr addrspace(1)
  %ldg.6 = load float, ptr addrspace(1) %"R5:R169_addr_ptr", align 4
  br label %BB_08a0

BB_08a0:                                          ; preds = %BB_0890
  %57 = zext i1 %cond_not.3 to i32
  %58 = icmp ne i32 %57, 0
  br i1 %58, label %BB_800008a0, label %BB_08b0

BB_800008a0:                                      ; preds = %BB_08a0
  %ldg_addr_memaddr_offset_add.1 = add i64 %56, 4
  %"R5:R169_addr_ptr.1" = inttoptr i64 %ldg_addr_memaddr_offset_add.1 to ptr addrspace(1)
  %ldg.7 = load float, ptr addrspace(1) %"R5:R169_addr_ptr.1", align 4
  br label %BB_08b0

BB_08b0:                                          ; preds = %BB_800008a0, %BB_08a0
  %phi.13 = phi float [ %ldg.7, %BB_800008a0 ], [ %phi.7, %BB_08a0 ]
  %ffma.2 = call float @llvm.fma.f32(float %ldg.4, float %ldg.6, float %phi.9)
  br label %BB_08c0

BB_08c0:                                          ; preds = %BB_08b0
  %59 = zext i1 %cond_not.3 to i32
  %60 = icmp ne i32 %59, 0
  br i1 %60, label %BB_800008c0, label %BB_08d0

BB_800008c0:                                      ; preds = %BB_08c0
  %ffma.3 = call float @llvm.fma.f32(float %phi.12, float %phi.13, float %phi.10)
  br label %BB_08d0

BB_08d0:                                          ; preds = %BB_800008c0, %BB_08c0, %BB_07c0
  %phi.14 = phi float [ %phi.6, %BB_07c0 ], [ %phi.12, %BB_800008c0 ], [ %phi.12, %BB_08c0 ]
  %phi.15 = phi float [ %phi.7, %BB_07c0 ], [ %phi.13, %BB_800008c0 ], [ %phi.13, %BB_08c0 ]
  %phi.16 = phi float [ %phi.9, %BB_07c0 ], [ %ffma.2, %BB_800008c0 ], [ %ffma.2, %BB_08c0 ]
  %phi.17 = phi float [ %phi.10, %BB_07c0 ], [ %ffma.3, %BB_800008c0 ], [ %phi.10, %BB_08c0 ]
  br label %BB_0900

BB_0900:                                          ; preds = %BB_08d0
  %cond_not.6 = xor i1 %50, true
  br i1 %cond_not.6, label %BB_0740, label %BB_0910

BB_0910:                                          ; preds = %BB_0900, %BB_0710
  %phi.18 = phi float [ 0.000000e+00, %BB_0710 ], [ %phi.16, %BB_0900 ]
  %phi.19 = phi float [ 0.000000e+00, %BB_0710 ], [ %phi.17, %BB_0900 ]
  %fadd = fadd float 0.000000e+00, %phi.18
  %fadd.1 = fadd float %fadd, %phi.19
  br label %BB_0940

BB_0940:                                          ; preds = %BB_0910, %BB_0650, %BB_04f0, %BB_03f0, %BB_0160
  %phi.20 = phi float [ 0.000000e+00, %BB_0160 ], [ %ffma, %BB_03f0 ], [ 0.000000e+00, %BB_04f0 ], [ %ffma.1, %BB_0650 ], [ %fadd.1, %BB_0910 ]
  %s2ur_cluster_ctarank = call i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank()
  %isetrp_cmp1.22 = icmp sgt i32 %tid_x, 63
  %isetrp_cmp1.23 = icmp sgt i32 %tid_x, 31
  %.190 = zext i32 %s2ur_cluster_ctarank to i64
  %.193 = shl i64 %.190, 24
  %.194 = and i64 %.193, 4294967295
  %.195 = add i64 %.194, 1024
  %.196 = trunc i64 %.195 to i32
  %.197 = zext i32 %tid_x to i64
  %.198 = zext i32 %.196 to i64
  %.200 = shl i64 %.197, 2
  %.201 = and i64 %.200, 4294967295
  %.202 = add i64 %.201, %.198
  %.203 = trunc i64 %.202 to i32
  %.204 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.203
  store volatile float %phi.20, ptr addrspace(3) %.204, align 4
  call void @llvm.nvvm.barrier0()
  br label %BB_09c0

BB_09c0:                                          ; preds = %BB_0940
  %cond_not.7 = xor i1 %isetrp_cmp1.22, true
  br i1 %cond_not.7, label %BB_800009c0, label %BB_0a00

BB_800009c0:                                      ; preds = %BB_09c0
  %lds = load volatile float, ptr addrspace(3) %.204, align 4
  %lds_addr_memaddr_offset_add = add i32 %.203, 256
  %.209 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add
  %lds.1 = load volatile float, ptr addrspace(3) %.209, align 4
  %fadd.2 = fadd float %lds, %lds.1
  store volatile float %fadd.2, ptr addrspace(3) %.204, align 4
  br label %BB_0a00

BB_0a00:                                          ; preds = %BB_800009c0, %BB_09c0
  %warp_reconv_mask = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.24 = icmp sgt i32 %tid_x, 15
  br label %BB_0a20

BB_0a20:                                          ; preds = %BB_0a00
  %cond_not.8 = xor i1 %isetrp_cmp1.23, true
  br i1 %cond_not.8, label %BB_80000a20, label %BB_0a60

BB_80000a20:                                      ; preds = %BB_0a20
  %lds.2 = load volatile float, ptr addrspace(3) %.204, align 4
  %lds_addr_memaddr_offset_add.1 = add i32 %.203, 128
  %.216 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.1
  %lds.3 = load volatile float, ptr addrspace(3) %.216, align 4
  %fadd.3 = fadd float %lds.2, %lds.3
  store volatile float %fadd.3, ptr addrspace(3) %.204, align 4
  br label %BB_0a60

BB_0a60:                                          ; preds = %BB_80000a20, %BB_0a20
  %warp_reconv_mask.1 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.25 = icmp sgt i32 %tid_x, 7
  br label %BB_0a80

BB_0a80:                                          ; preds = %BB_0a60
  %cond_not.9 = xor i1 %isetrp_cmp1.24, true
  br i1 %cond_not.9, label %BB_80000a80, label %BB_0ac0

BB_80000a80:                                      ; preds = %BB_0a80
  %lds.4 = load volatile float, ptr addrspace(3) %.204, align 4
  %lds_addr_memaddr_offset_add.2 = add i32 %.203, 64
  %.223 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.2
  %lds.5 = load volatile float, ptr addrspace(3) %.223, align 4
  %fadd.4 = fadd float %lds.4, %lds.5
  store volatile float %fadd.4, ptr addrspace(3) %.204, align 4
  br label %BB_0ac0

BB_0ac0:                                          ; preds = %BB_80000a80, %BB_0a80
  %warp_reconv_mask.2 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.2)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.26 = icmp sgt i32 %tid_x, 3
  br label %BB_0ae0

BB_0ae0:                                          ; preds = %BB_0ac0
  %cond_not.10 = xor i1 %isetrp_cmp1.25, true
  br i1 %cond_not.10, label %BB_80000ae0, label %BB_0b20

BB_80000ae0:                                      ; preds = %BB_0ae0
  %lds.6 = load volatile float, ptr addrspace(3) %.204, align 4
  %lds_addr_memaddr_offset_add.3 = add i32 %.203, 32
  %.230 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.3
  %lds.7 = load volatile float, ptr addrspace(3) %.230, align 4
  %fadd.5 = fadd float %lds.6, %lds.7
  store volatile float %fadd.5, ptr addrspace(3) %.204, align 4
  br label %BB_0b20

BB_0b20:                                          ; preds = %BB_80000ae0, %BB_0ae0
  %warp_reconv_mask.3 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.3)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.27 = icmp sgt i32 %tid_x, 1
  br label %BB_0b40

BB_0b40:                                          ; preds = %BB_0b20
  %cond_not.11 = xor i1 %isetrp_cmp1.26, true
  br i1 %cond_not.11, label %BB_80000b40, label %BB_0b80

BB_80000b40:                                      ; preds = %BB_0b40
  %lds.8 = load volatile float, ptr addrspace(3) %.204, align 4
  %lds_addr_memaddr_offset_add.4 = add i32 %.203, 16
  %.237 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.4
  %lds.9 = load volatile float, ptr addrspace(3) %.237, align 4
  %fadd.6 = fadd float %lds.8, %lds.9
  store volatile float %fadd.6, ptr addrspace(3) %.204, align 4
  br label %BB_0b80

BB_0b80:                                          ; preds = %BB_80000b40, %BB_0b40
  %warp_reconv_mask.4 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.4)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.28 = icmp sgt i32 %tid_x, 0
  br label %BB_0ba0

BB_0ba0:                                          ; preds = %BB_0b80
  %cond_not.12 = xor i1 %isetrp_cmp1.27, true
  br i1 %cond_not.12, label %BB_80000ba0, label %BB_0be0

BB_80000ba0:                                      ; preds = %BB_0ba0
  %lds.10 = load volatile float, ptr addrspace(3) %.204, align 4
  %lds_addr_memaddr_offset_add.5 = add i32 %.203, 8
  %.244 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.5
  %lds.11 = load volatile float, ptr addrspace(3) %.244, align 4
  %fadd.7 = fadd float %lds.10, %lds.11
  store volatile float %fadd.7, ptr addrspace(3) %.204, align 4
  br label %BB_0be0

BB_0be0:                                          ; preds = %BB_80000ba0, %BB_0ba0
  %warp_reconv_mask.5 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.5)
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.29 = icmp ne i32 %tid_x, 0
  br label %BB_0c00

BB_0c00:                                          ; preds = %BB_0be0
  %cond_not.13 = xor i1 %isetrp_cmp1.28, true
  br i1 %cond_not.13, label %BB_80000c00, label %BB_0c40

BB_80000c00:                                      ; preds = %BB_0c00
  %lds.12 = load volatile float, ptr addrspace(3) %.204, align 4
  %lds_addr_memaddr_offset_add.6 = add i32 %.203, 4
  %.251 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.6
  %lds.13 = load volatile float, ptr addrspace(3) %.251, align 4
  %fadd.8 = fadd float %lds.12, %lds.13
  store volatile float %fadd.8, ptr addrspace(3) %.204, align 4
  br label %BB_0c40

BB_0c40:                                          ; preds = %BB_80000c00, %BB_0c00
  %warp_reconv_mask.6 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.6)
  br i1 %isetrp_cmp1.29, label %BB_80000c40, label %BB_0c50

BB_0c50:                                          ; preds = %BB_0c40
  %.256 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.196
  %lds.14 = load volatile i32, ptr addrspace(3) %.256, align 4
  %s2ur_ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %61 = zext i32 %s2ur_ctaid_z to i64
  %.257 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 552
  %ldc_const.12 = load i64, ptr %.257, align 8
  %.259 = getelementptr inbounds [592 x i8], ptr %param_local, i64 0, i64 544
  %ldc_const.13 = load i64, ptr %.259, align 8
  %62 = mul i64 %ldc_const.12, %61
  %63 = zext i32 %ctaid_x to i64
  %64 = add i64 %62, %63
  %.275 = shl i64 %64, 2
  %65 = add i64 %ldc_const.13, %.275
  %"R99:R82_addr_ptr" = inttoptr i64 %65 to ptr addrspace(1)
  store i32 %lds.14, ptr addrspace(1) %"R99:R82_addr_ptr", align 4
  ret void

BB_80000c40:                                      ; preds = %BB_0c40
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank() #0

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier0() #1

; Function Attrs: convergent nocallback nounwind memory(inaccessiblemem: readwrite)
declare i32 @llvm.nvvm.activemask() #2

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.bar.warp.sync(i32) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ctaid.z() #0

define void @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE(i64 %arg_528, i32 %arg_536, i128 %arg_544, i32 %arg_560, i64 %arg_568, i32 %arg_576, i64 %arg_584, i64 %arg_592, i32 %arg_600, i32 %arg_604, i128 %arg_608) {
EntryBB_0000:
  %param_local = alloca [624 x i8], align 16
  %.13 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 528
  store i64 %arg_528, ptr %.13, align 16
  %.16 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 536
  store i32 %arg_536, ptr %.16, align 8
  %.19 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 544
  store i128 %arg_544, ptr %.19, align 32
  %.22 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 560
  store i32 %arg_560, ptr %.22, align 16
  %.25 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 568
  store i64 %arg_568, ptr %.25, align 8
  %.28 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 576
  store i32 %arg_576, ptr %.28, align 64
  %.31 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 584
  store i64 %arg_584, ptr %.31, align 8
  %.34 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 592
  store i64 %arg_592, ptr %.34, align 16
  %.37 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 600
  store i32 %arg_600, ptr %.37, align 8
  %.40 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 604
  store i32 %arg_604, ptr %.40, align 4
  %.43 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 608
  store i128 %arg_608, ptr %.43, align 32
  %ldc_const = load i32, ptr %.37, align 4
  %isetrp_cmp1 = icmp ne i32 0, %ldc_const
  %ldc_const.1 = load i32, ptr %.16, align 4
  %ldc_const.2 = load i32, ptr %.40, align 4
  br label %BB_0070

BB_0070:                                          ; preds = %EntryBB_0000
  %phi_cast_R1_bitcast = bitcast i32 %ldc_const.1 to float
  br i1 %isetrp_cmp1, label %BB_80000070, label %BB_00a0

BB_80000070:                                      ; preds = %BB_0070
  %ldc_const.3 = load i64, ptr %.13, align 8
  %ldc_const.4 = load i64, ptr %.25, align 8
  %"R300:R289_addr_ptr" = inttoptr i64 %ldc_const.3 to ptr addrspace(1)
  %ldg = load float, ptr addrspace(1) %"R300:R289_addr_ptr", align 4
  br label %BB_00a0

BB_00a0:                                          ; preds = %BB_80000070, %BB_0070
  %0 = phi i64 [ %ldc_const.4, %BB_80000070 ], [ 0, %BB_0070 ]
  %phi.2 = phi float [ %ldg, %BB_80000070 ], [ %phi_cast_R1_bitcast, %BB_0070 ]
  %ldc_const.5 = load i32, ptr %.28, align 4
  br label %BB_00c0

BB_00c0:                                          ; preds = %BB_00a0
  %phi_cast_R157_bitcast = bitcast i32 %ldc_const.5 to float
  br i1 %isetrp_cmp1, label %BB_800000c0, label %BB_00d0

BB_800000c0:                                      ; preds = %BB_00c0
  %"R39:R20_addr_ptr" = inttoptr i64 %0 to ptr addrspace(1)
  %ldg.1 = load float, ptr addrspace(1) %"R39:R20_addr_ptr", align 4
  br label %BB_00d0

BB_00d0:                                          ; preds = %BB_800000c0, %BB_00c0
  %phi.3 = phi float [ %ldg.1, %BB_800000c0 ], [ %phi_cast_R157_bitcast, %BB_00c0 ]
  %isetrp_cmp1.1 = icmp eq i32 %ldc_const.2, 1
  %fsetrp_cmp1 = fcmp une float %phi.2, 0.000000e+00
  br label %BB_0100

BB_0100:                                          ; preds = %BB_00d0
  %cond_not = xor i1 %fsetrp_cmp1, true
  br i1 %cond_not, label %BB_80000100, label %BB_0150

BB_80000100:                                      ; preds = %BB_0100
  %ldc_const.6 = load i64, ptr %.31, align 8
  %fsetrp_cmp1.1 = fcmp une float %phi.3, 1.000000e+00
  %ldc_const.7 = load i64, ptr %.34, align 8
  %isetrp_src_not = xor i1 %fsetrp_cmp1.1, true
  %1 = icmp eq i64 %ldc_const.6, %ldc_const.7
  %isetrp_cmp2.3 = and i1 %1, %isetrp_src_not
  %P13_to_i32 = zext i1 %isetrp_cmp2.3 to i32
  br label %BB_0150

BB_0150:                                          ; preds = %BB_80000100, %BB_0100
  %2 = phi i64 [ %ldc_const.6, %BB_80000100 ], [ 0, %BB_0100 ]
  %phi.6 = phi i32 [ %P13_to_i32, %BB_80000100 ], [ 0, %BB_0100 ]
  %cond_trunc.3 = trunc i32 %phi.6 to i1
  br i1 %cond_trunc.3, label %BB_80000150, label %BB_0160

BB_80000150:                                      ; preds = %BB_0150
  %3 = zext i1 %isetrp_cmp1.1 to i32
  %4 = icmp ne i32 %3, 0
  br i1 %4, label %exit_0150, label %BB_0160

BB_0160:                                          ; preds = %BB_80000150, %BB_0150
  %tid_x = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %ntid_x = call i32 @llvm.nvvm.read.ptx.sreg.ntid.x()
  %ldc_const.8 = load i32, ptr %.22, align 4
  %isetrp_cmp1.4 = icmp uge i32 %ntid_x, %ldc_const.8
  %isetrp_cmp1.5 = icmp sge i32 %tid_x, %ldc_const.8
  %isetrp_cmp2.5 = or i1 %isetrp_cmp1.5, %cond_not
  br label %BB_01d0

BB_01d0:                                          ; preds = %BB_0160
  %5 = zext i1 %isetrp_cmp2.5 to i32
  %6 = icmp ne i32 %5, 0
  br i1 %6, label %BB_0290, label %BB_01e0

BB_01e0:                                          ; preds = %BB_01d0
  %s2ur_ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %7 = zext i32 %s2ur_ctaid_z to i64
  %8 = sext i32 %tid_x to i64
  %ldc_const.9 = load i64, ptr %.19, align 8
  %.89 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 552
  %ldc_const.10 = load i64, ptr %.89, align 8
  %9 = mul i64 %ldc_const.10, %7
  %10 = add i64 %9, %8
  %.105 = shl i64 %10, 2
  %11 = add i64 %ldc_const.9, %.105
  %"R161:R92_addr_ptr" = inttoptr i64 %11 to ptr addrspace(1)
  %ldg.2 = load float, ptr addrspace(1) %"R161:R92_addr_ptr", align 4
  br label %BB_0290

BB_0290:                                          ; preds = %BB_01e0, %BB_01d0
  %12 = phi i64 [ %11, %BB_01e0 ], [ %2, %BB_01d0 ]
  %phi.9 = phi float [ %ldg.2, %BB_01e0 ], [ 0.000000e+00, %BB_01d0 ]
  br i1 %isetrp_cmp1.4, label %BB_0900, label %BB_02a0

BB_02a0:                                          ; preds = %BB_0290
  %imad.4 = add i32 %tid_x, %ntid_x
  %13 = zext i32 %imad.4 to i64
  %.114 = zext i32 %ldc_const.8 to i64
  %.115 = shl i64 %.114, 32
  %.116 = ashr i64 %.115, 31
  %shf_hi.1 = lshr i64 %.116, 32
  %shf_result.1 = trunc i64 %shf_hi.1 to i32
  %14 = sext i32 %ldc_const.8 to i64
  %15 = icmp sge i64 %13, %14
  br label %BB_02f0

BB_02f0:                                          ; preds = %BB_02a0
  %16 = zext i1 %15 to i32
  %17 = icmp ne i32 %16, 0
  br i1 %17, label %BB_0900, label %BB_0300

BB_0300:                                          ; preds = %BB_02f0
  %18 = zext i1 %cond_not to i32
  %19 = icmp ne i32 %18, 0
  br i1 %19, label %BB_0900, label %BB_0310

BB_0310:                                          ; preds = %BB_0300
  %.121 = xor i32 %imad.4, -1
  %ctaid_z = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %20 = zext i32 %ctaid_z to i64
  %iadd3_o1_64 = zext i32 %.121 to i64
  %iadd3_tmp = add i64 %iadd3_o1_64, %.114
  %iadd3_trunc = trunc i64 %iadd3_tmp to i32
  %iadd3_carry_val = lshr i64 %iadd3_tmp, 32
  %carry_ge_1 = icmp uge i64 %iadd3_carry_val, 1
  %iadd3_n1 = add i32 -1, %shf_result.1
  %iadd3_cin1_narrow_zext = zext i1 %carry_ge_1 to i32
  %iadd3_cin1_add = add i32 %iadd3_n1, %iadd3_cin1_narrow_zext
  %21 = zext i32 %.121 to i64
  %22 = add i64 %14, %21
  %23 = add i64 %22, -4294967296
  %isetrp_cmp1.8 = icmp ne i32 %iadd3_cin1_add, 0
  br label %BB_0390

BB_0390:                                          ; preds = %BB_0310
  %cond_not.2 = xor i1 %isetrp_cmp1.8, true
  br i1 %cond_not.2, label %BB_03d0, label %BB_03b0_1360

BB_03b0_1360:                                     ; preds = %BB_0390
  %udiv64_divisor_lo_64 = zext i32 %ntid_x to i64
  %udiv64_div_zero = icmp eq i64 %udiv64_divisor_lo_64, 0
  %udiv64_safe_div = select i1 %udiv64_div_zero, i64 1, i64 %udiv64_divisor_lo_64
  %udiv64 = udiv i64 %23, %udiv64_safe_div
  %urem64 = urem i64 %23, %udiv64_safe_div
  %urem64_word = trunc i64 %urem64 to i32
  %iadd3_o1_not64 = xor i64 %udiv64_divisor_lo_64, -1
  %iadd3_o1_not64_masked = and i64 %iadd3_o1_not64, 4294967295
  %iadd3_o1_neg64 = add i64 %iadd3_o1_not64_masked, 1
  %iadd3_o2_64.1 = zext i32 %urem64_word to i64
  %iadd3_tmp.1 = add i64 %iadd3_o1_neg64, %iadd3_o2_64.1
  %iadd3_trunc.1 = trunc i64 %iadd3_tmp.1 to i32
  %iadd3_carry_val.1 = lshr i64 %iadd3_tmp.1, 32
  %carry_ge_1.1 = icmp uge i64 %iadd3_carry_val.1, 1
  %urem64_hi = lshr i64 %urem64, 32
  %urem64_word.1 = trunc i64 %urem64_hi to i32
  %isetrp_cmp1.9 = icmp uge i32 %urem64_word, %ntid_x
  %isetrp_hi_eq.2 = icmp eq i32 %urem64_word.1, 0
  %isetrp_ex_sel.2 = select i1 %isetrp_hi_eq.2, i1 %isetrp_cmp1.9, i1 true
  %iadd3_n1.1 = add i32 %urem64_word.1, -1
  %iadd3_cin1_narrow_zext.1 = zext i1 %carry_ge_1.1 to i32
  %iadd3_cin1_add.1 = add i32 %iadd3_n1.1, %iadd3_cin1_narrow_zext.1
  %24 = add i64 %udiv64, 1
  %sel = select i1 %isetrp_ex_sel.2, i32 %iadd3_trunc.1, i32 %urem64_word
  %sel.2 = select i1 %isetrp_ex_sel.2, i32 %iadd3_cin1_add.1, i32 %urem64_word.1
  %25 = select i1 %isetrp_ex_sel.2, i64 %24, i64 %udiv64
  %isetrp_cmp1.11 = icmp uge i32 %sel, %ntid_x
  %isetrp_hi_eq.3 = icmp eq i32 %sel.2, 0
  %isetrp_ex_sel.3 = select i1 %isetrp_hi_eq.3, i1 %isetrp_cmp1.11, i1 true
  %isetrp_cmp1.13 = icmp ne i32 %ntid_x, 0
  %26 = add i64 %25, 1
  %27 = select i1 %isetrp_ex_sel.3, i64 %26, i64 %25
  %28 = select i1 %isetrp_cmp1.13, i64 %27, i64 -1
  br label %BB_0500

BB_03d0:                                          ; preds = %BB_0390
  %isetrp_cmp1.15 = icmp ne i32 %ntid_x, 0
  %sdiv_div_zero = icmp eq i32 %ntid_x, 0
  %sdiv_safe_div = select i1 %sdiv_div_zero, i32 1, i32 %ntid_x
  %sdiv = udiv i32 %iadd3_trunc, %sdiv_safe_div
  %imad_addend_neg = sub i32 0, %sdiv
  %imad_tmp.6 = mul i32 %ntid_x, %imad_addend_neg
  %imad.7 = add i32 %imad_tmp.6, %iadd3_trunc
  %isetrp_cmp1.16 = icmp uge i32 %imad.7, %ntid_x
  br label %BB_04b0

BB_04b0:                                          ; preds = %BB_03d0
  %29 = zext i1 %isetrp_cmp1.16 to i32
  %30 = icmp ne i32 %29, 0
  br i1 %30, label %BB_800004b0, label %BB_04d0

BB_800004b0:                                      ; preds = %BB_04b0
  %imad_addend_neg.1 = sub i32 0, %ntid_x
  %imad.8 = add i32 %imad.7, %imad_addend_neg.1
  %iadd3_n1.3 = add i32 %sdiv, 1
  br label %BB_04d0

BB_04d0:                                          ; preds = %BB_800004b0, %BB_04b0
  %phi.10 = phi i32 [ %iadd3_n1.3, %BB_800004b0 ], [ %sdiv, %BB_04b0 ]
  %phi.11 = phi i32 [ %imad.8, %BB_800004b0 ], [ %imad.7, %BB_04b0 ]
  %isetrp_cmp1.17 = icmp uge i32 %phi.11, %ntid_x
  br label %BB_04e0

BB_04e0:                                          ; preds = %BB_04d0
  %31 = zext i1 %isetrp_cmp1.17 to i32
  %32 = icmp ne i32 %31, 0
  br i1 %32, label %BB_800004e0, label %BB_04f0

BB_800004e0:                                      ; preds = %BB_04e0
  %viadd = add i32 %phi.10, 1
  br label %BB_04f0

BB_04f0:                                          ; preds = %BB_800004e0, %BB_04e0
  %phi.12 = phi i32 [ %viadd, %BB_800004e0 ], [ %phi.10, %BB_04e0 ]
  %33 = zext i32 %phi.12 to i64
  %cond_not.3 = xor i1 %isetrp_cmp1.15, true
  br i1 %cond_not.3, label %BB_800004f0, label %BB_0500

BB_800004f0:                                      ; preds = %BB_04f0
  %.159 = xor i32 %ntid_x, -1
  %34 = zext i32 %.159 to i64
  br label %BB_0500

BB_0500:                                          ; preds = %BB_800004f0, %BB_04f0, %BB_03b0_1360
  %35 = phi i64 [ %28, %BB_03b0_1360 ], [ %34, %BB_800004f0 ], [ %33, %BB_04f0 ]
  %36 = trunc i64 %35 to i32
  %37 = lshr i64 %35, 32
  %38 = trunc i64 %37 to i32
  %viadd.1 = add i32 %36, 1
  %isetrp_cmp1.18 = icmp uge i32 %36, 3
  %.176 = and i32 %viadd.1, 3
  %39 = zext i32 %.176 to i64
  %isetrp_hi_eq.5 = icmp eq i32 %38, 0
  %isetrp_ex_sel.5 = select i1 %isetrp_hi_eq.5, i1 %isetrp_cmp1.18, i1 true
  %isetrp_cmp1.20 = icmp ne i32 %.176, 0
  br label %BB_0580

BB_0580:                                          ; preds = %BB_0500
  %cond_not.4 = xor i1 %isetrp_cmp1.20, true
  br i1 %cond_not.4, label %BB_06e0, label %BB_0590

BB_0590:                                          ; preds = %BB_0580
  %.183 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 552
  %ldc_const.11 = load i64, ptr %.183, align 8
  %ldc_const.12 = load i64, ptr %.19, align 8
  %40 = mul i64 %20, %ldc_const.11
  %41 = zext i32 %imad.4 to i64
  %42 = add i64 %40, %41
  %.201 = shl i64 %42, 2
  %43 = add i64 %ldc_const.12, %.201
  br label %BB_0600

BB_0600:                                          ; preds = %BB_06c0, %BB_0590
  %44 = phi i64 [ %39, %BB_0590 ], [ %50, %BB_06c0 ]
  %45 = phi i64 [ %13, %BB_0590 ], [ %54, %BB_06c0 ]
  %46 = phi i64 [ %43, %BB_0590 ], [ %58, %BB_06c0 ]
  %phi.17 = phi float [ %phi.9, %BB_0590 ], [ %fadd, %BB_06c0 ]
  %47 = lshr i64 %46, 32
  %48 = trunc i64 %47 to i32
  %"R229:R222_addr_ptr" = inttoptr i64 %46 to ptr addrspace(1)
  %ldg.3 = load float, ptr addrspace(1) %"R229:R222_addr_ptr", align 4
  %iadd3_o1_64.4 = zext i32 %ntid_x to i64
  %49 = add i64 %44, 4294967295
  %50 = add i64 %49, -4294967296
  %51 = add i64 %44, 4294967295
  %52 = add i64 %51, -4294967296
  %53 = zext i32 %ntid_x to i64
  %54 = add i64 %45, %53
  %55 = zext i32 %ntid_x to i64
  %56 = add i64 %45, %55
  %.211 = shl i64 %iadd3_o1_64.4, 2
  %57 = icmp ne i64 %52, 0
  %58 = add i64 %46, %.211
  %fadd = fadd float %ldg.3, %phi.17
  br label %BB_06c0

BB_06c0:                                          ; preds = %BB_0600
  %phi_cast_R86_bitcast = bitcast float %ldg.3 to i32
  %59 = zext i32 %48 to i64
  %60 = shl i64 %59, 32
  %61 = zext i32 %phi_cast_R86_bitcast to i64
  %62 = or i64 %61, %60
  br i1 %57, label %BB_0600, label %BB_06e0

BB_06e0:                                          ; preds = %BB_06c0, %BB_0580
  %63 = phi i64 [ %35, %BB_0580 ], [ %62, %BB_06c0 ]
  %64 = phi i64 [ %13, %BB_0580 ], [ %56, %BB_06c0 ]
  %phi.26 = phi float [ %phi.9, %BB_0580 ], [ %fadd, %BB_06c0 ]
  %cond_not.5 = xor i1 %isetrp_ex_sel.5, true
  br i1 %cond_not.5, label %BB_0900, label %BB_06f0

BB_06f0:                                          ; preds = %BB_06e0
  %.231 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 552
  %ldc_const.13 = load i64, ptr %.231, align 8
  %ldc_const.14 = load i64, ptr %.19, align 8
  %.235 = zext i32 %ntid_x to i64
  %.238 = shl i64 %.235, 2
  %shf_result.2 = trunc i64 %.238 to i32
  %.241 = shl i64 %.235, 32
  %.242 = lshr i64 %.241, 30
  %65 = mul i64 %20, %ldc_const.13
  %66 = add i64 %65, %64
  %.257 = shl i64 %66, 2
  %67 = add i64 %ldc_const.14, %.257
  br label %BB_0770

BB_0770:                                          ; preds = %BB_08e0, %BB_06f0
  %68 = phi i64 [ %64, %BB_06f0 ], [ %124, %BB_08e0 ]
  %69 = phi i64 [ %67, %BB_06f0 ], [ %148, %BB_08e0 ]
  %phi.29 = phi float [ %phi.26, %BB_06f0 ], [ %fadd.4, %BB_08e0 ]
  %70 = trunc i64 %69 to i32
  %71 = lshr i64 %69, 32
  %72 = trunc i64 %71 to i32
  %iadd3_o1_64.5 = zext i32 %shf_result.2 to i64
  %iadd3_o2_64.6 = zext i32 %70 to i64
  %iadd3_tmp.6 = add i64 %iadd3_o1_64.5, %iadd3_o2_64.6
  %iadd3_trunc.6 = trunc i64 %iadd3_tmp.6 to i32
  %iadd3_carry_val.6 = lshr i64 %iadd3_tmp.6, 32
  %carry_ge_1.6 = icmp uge i64 %iadd3_carry_val.6, 1
  %ldc_const.15 = load i32, ptr %.22, align 4
  %73 = zext i32 %shf_result.1 to i64
  %74 = shl i64 %73, 32
  %75 = zext i32 %ldc_const.15 to i64
  %76 = or i64 %75, %74
  %"R46:R252_addr_ptr" = inttoptr i64 %69 to ptr addrspace(1)
  %ldg.4 = load float, ptr addrspace(1) %"R46:R252_addr_ptr", align 4
  %77 = zext i32 %shf_result.2 to i64
  %78 = zext i32 %70 to i64
  %79 = add i64 %77, %78
  %80 = zext i32 %shf_result.2 to i64
  %81 = and i64 %.242, -4294967296
  %82 = add i64 %69, %80
  %83 = add i64 %82, %81
  %iadd3_o2_64.7 = zext i32 %iadd3_trunc.6 to i64
  %iadd3_tmp.7 = add i64 %iadd3_o1_64.5, %iadd3_o2_64.7
  %iadd3_trunc.7 = trunc i64 %iadd3_tmp.7 to i32
  %iadd3_carry_val.7 = lshr i64 %iadd3_tmp.7, 32
  %carry_ge_1.7 = icmp uge i64 %iadd3_carry_val.7, 1
  %"R231:R226_addr_ptr" = inttoptr i64 %83 to ptr addrspace(1)
  %ldg.5 = load float, ptr addrspace(1) %"R231:R226_addr_ptr", align 4
  %84 = zext i32 %shf_result.2 to i64
  %85 = zext i32 %iadd3_trunc.6 to i64
  %86 = add i64 %84, %85
  %87 = zext i32 %shf_result.2 to i64
  %88 = and i64 %.242, -4294967296
  %89 = and i64 %.242, -4294967296
  %90 = zext i32 %72 to i64
  %91 = shl i64 %90, 32
  %92 = add i64 %79, %87
  %93 = add i64 %92, %88
  %94 = add i64 %93, %89
  %95 = add i64 %94, %91
  %"R38:R68_addr_ptr" = inttoptr i64 %95 to ptr addrspace(1)
  %ldg.6 = load float, ptr addrspace(1) %"R38:R68_addr_ptr", align 4
  %96 = zext i32 %shf_result.2 to i64
  %97 = zext i32 %iadd3_trunc.7 to i64
  %98 = add i64 %96, %97
  %99 = zext i32 %shf_result.2 to i64
  %100 = and i64 %.242, -4294967296
  %101 = and i64 %.242, -4294967296
  %102 = and i64 %.242, -4294967296
  %103 = zext i32 %72 to i64
  %104 = shl i64 %103, 32
  %105 = zext i1 %carry_ge_1.6 to i64
  %106 = shl i64 %105, 32
  %107 = add i64 %86, %99
  %108 = add i64 %107, %100
  %109 = add i64 %108, %101
  %110 = add i64 %109, %102
  %111 = add i64 %110, %104
  %112 = add i64 %111, %106
  %"R144:R89_addr_ptr" = inttoptr i64 %112 to ptr addrspace(1)
  %ldg.7 = load float, ptr addrspace(1) %"R144:R89_addr_ptr", align 4
  %113 = zext i32 %ntid_x to i64
  %114 = zext i32 %ntid_x to i64
  %115 = add i64 %68, %113
  %116 = add i64 %115, %114
  %117 = zext i32 %ntid_x to i64
  %118 = zext i32 %ntid_x to i64
  %119 = add i64 %68, %117
  %120 = add i64 %119, %118
  %121 = zext i32 %ntid_x to i64
  %122 = zext i32 %ntid_x to i64
  %123 = add i64 %116, %121
  %124 = add i64 %123, %122
  %125 = zext i32 %ntid_x to i64
  %126 = zext i32 %ntid_x to i64
  %127 = add i64 %120, %125
  %128 = add i64 %127, %126
  %129 = icmp sge i64 %128, %76
  %fadd.1 = fadd float %ldg.4, %phi.29
  %fadd.2 = fadd float %fadd.1, %ldg.5
  %130 = zext i32 %shf_result.2 to i64
  %131 = and i64 %.242, -4294967296
  %132 = and i64 %.242, -4294967296
  %133 = and i64 %.242, -4294967296
  %134 = and i64 %.242, -4294967296
  %135 = zext i32 %72 to i64
  %136 = shl i64 %135, 32
  %137 = zext i1 %carry_ge_1.6 to i64
  %138 = shl i64 %137, 32
  %139 = zext i1 %carry_ge_1.7 to i64
  %140 = shl i64 %139, 32
  %141 = add i64 %98, %130
  %142 = add i64 %141, %131
  %143 = add i64 %142, %132
  %144 = add i64 %143, %133
  %145 = add i64 %144, %134
  %146 = add i64 %145, %136
  %147 = add i64 %146, %138
  %148 = add i64 %147, %140
  %fadd.3 = fadd float %fadd.2, %ldg.6
  %fadd.4 = fadd float %fadd.3, %ldg.7
  br label %BB_08e0

BB_08e0:                                          ; preds = %BB_0770
  %cond_not.6 = xor i1 %129, true
  br i1 %cond_not.6, label %BB_0770, label %BB_0900

BB_0900:                                          ; preds = %BB_08e0, %BB_06e0, %BB_0300, %BB_02f0, %BB_0290
  %149 = phi i64 [ %12, %BB_02f0 ], [ %12, %BB_0300 ], [ %63, %BB_06e0 ], [ %112, %BB_08e0 ], [ %12, %BB_0290 ]
  %phi.34 = phi float [ %phi.9, %BB_02f0 ], [ %phi.9, %BB_0300 ], [ %phi.26, %BB_06e0 ], [ %fadd.4, %BB_08e0 ], [ %phi.9, %BB_0290 ]
  %150 = trunc i64 %149 to i32
  %151 = lshr i64 %149, 32
  %152 = trunc i64 %151 to i32
  %s2ur_cluster_ctarank = call i32 @llvm.nvvm.read.ptx.sreg.cluster.ctarank()
  %ldc_const.16 = load i32, ptr %.22, align 4
  %.270 = zext i32 %s2ur_cluster_ctarank to i64
  %.273 = shl i64 %.270, 24
  %.274 = and i64 %.273, 4294967295
  %.275 = add i64 %.274, 1024
  %.276 = trunc i64 %.275 to i32
  %.277 = zext i32 %tid_x to i64
  %.278 = zext i32 %.276 to i64
  %.280 = shl i64 %.277, 2
  %.281 = and i64 %.280, 4294967295
  %.282 = add i64 %.281, %.278
  %.283 = trunc i64 %.282 to i32
  %isetrp_cmp1.26 = icmp sge i32 %ldc_const.16, 33
  %.284 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.283
  store volatile float %phi.34, ptr addrspace(3) %.284, align 4
  br label %BB_0970

BB_0970:                                          ; preds = %BB_0900
  %cond_not.7 = xor i1 %isetrp_cmp1.26, true
  br i1 %cond_not.7, label %BB_0a80, label %BB_0980

BB_0980:                                          ; preds = %BB_0970
  %.289 = zext i32 %ntid_x to i64
  %.290 = shl i64 %.289, 32
  %.291 = lshr i64 %.290, 1
  %shf_hi.3 = lshr i64 %.291, 32
  %shf_result.4 = trunc i64 %shf_hi.3 to i32
  %.295 = lshr i64 %.290, 2
  %shf_hi.4 = lshr i64 %.295, 32
  %shf_result.5 = trunc i64 %shf_hi.4 to i32
  %isetrp_cmp1.27 = icmp sge i32 %shf_result.4, %ldc_const.16
  br label %BB_09b0

BB_09b0:                                          ; preds = %BB_0980
  %cond_not.8 = xor i1 %isetrp_cmp1.27, true
  br i1 %cond_not.8, label %BB_800009b0, label %BB_09d0

BB_800009b0:                                      ; preds = %BB_09b0
  call void @llvm.nvvm.barrier0()
  %imad_tmp.14 = mul i32 %shf_result.4, 4
  %imad.17 = add i32 %imad_tmp.14, %.283
  br label %BB_09d0

BB_09d0:                                          ; preds = %BB_800009b0, %BB_09b0
  %phi.35 = phi i32 [ %imad.17, %BB_800009b0 ], [ %shf_result.4, %BB_09b0 ]
  %isetrp_cmp1.28 = icmp sge i32 %shf_result.5, %ldc_const.16
  br label %BB_09e0

BB_09e0:                                          ; preds = %BB_09d0
  %cond_not.9 = xor i1 %isetrp_cmp1.28, true
  br i1 %cond_not.9, label %BB_800009e0, label %BB_09f0

BB_800009e0:                                      ; preds = %BB_09e0
  %imad_tmp.15 = mul i32 %shf_result.5, 4
  %imad.18 = add i32 %imad_tmp.15, %.283
  br label %BB_09f0

BB_09f0:                                          ; preds = %BB_800009e0, %BB_09e0
  %phi.36 = phi i32 [ %imad.18, %BB_800009e0 ], [ %shf_result.5, %BB_09e0 ]
  br i1 %cond_not.8, label %BB_800009f0, label %BB_0a30

BB_800009f0:                                      ; preds = %BB_09f0
  %.303 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.35
  %lds = load volatile float, ptr addrspace(3) %.303, align 4
  %fadd.5 = fadd float %phi.34, %lds
  call void @llvm.nvvm.barrier0()
  store volatile float %fadd.5, ptr addrspace(3) %.284, align 4
  %phi_cast_R95_bitcast = bitcast float %lds to i32
  br label %BB_0a30

BB_0a30:                                          ; preds = %BB_800009f0, %BB_09f0
  %phi.37 = phi i32 [ %phi_cast_R95_bitcast, %BB_800009f0 ], [ %150, %BB_09f0 ]
  %phi.38 = phi float [ %fadd.5, %BB_800009f0 ], [ %phi.34, %BB_09f0 ]
  %153 = zext i32 %152 to i64
  %154 = shl i64 %153, 32
  %155 = zext i32 %phi.37 to i64
  %156 = or i64 %155, %154
  %warp_reconv_mask = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask)
  br i1 %cond_not.9, label %BB_80000a30, label %BB_0a80

BB_80000a30:                                      ; preds = %BB_0a30
  call void @llvm.nvvm.barrier0()
  %.308 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.36
  %lds.1 = load volatile float, ptr addrspace(3) %.308, align 4
  %fadd.6 = fadd float %lds.1, %phi.38
  call void @llvm.nvvm.barrier0()
  store volatile float %fadd.6, ptr addrspace(3) %.284, align 4
  %phi_cast_R147_bitcast = bitcast float %fadd.6 to i32
  %phi_cast_R97_bitcast = bitcast float %lds.1 to i32
  %157 = zext i32 %phi_cast_R147_bitcast to i64
  %158 = shl i64 %157, 32
  %159 = zext i32 %phi_cast_R97_bitcast to i64
  %160 = or i64 %159, %158
  br label %BB_0a80

BB_0a80:                                          ; preds = %BB_80000a30, %BB_0a30, %BB_0970
  %161 = phi i64 [ %149, %BB_0970 ], [ %160, %BB_80000a30 ], [ %156, %BB_0a30 ]
  %162 = lshr i64 %161, 32
  %163 = trunc i64 %162 to i32
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.29 = icmp sgt i32 %tid_x, 3
  br label %BB_0ab0

BB_0ab0:                                          ; preds = %BB_0a80
  %164 = zext i1 %isetrp_cmp1.29 to i32
  %165 = icmp ne i32 %164, 0
  br i1 %165, label %BB_1130, label %BB_0ac0

BB_0ac0:                                          ; preds = %BB_0ab0
  %iadd3_o1_not = xor i32 %tid_x, -1
  %iadd3_o1_neg = add i32 %iadd3_o1_not, 1
  %iadd3_n1.8 = add i32 %iadd3_o1_neg, 31
  %.314 = zext i32 %iadd3_n1.8 to i64
  %.319 = shl i64 %.314, 30
  %.320 = lshr i64 %.319, 32
  %.321 = add i64 %.320, 1
  %.322 = trunc i64 %.321 to i32
  %isetrp_cmp1.30 = icmp uge i32 %iadd3_n1.8, 12
  %.326 = and i32 %.322, 3
  %lop3_pred_cmp.1 = icmp ne i32 %.326, 0
  br label %BB_0b30

BB_0b30:                                          ; preds = %BB_0ac0
  %cond_not.12 = xor i1 %lop3_pred_cmp.1, true
  br i1 %cond_not.12, label %BB_0c10, label %BB_0b40

BB_0b40:                                          ; preds = %BB_0b30
  br label %BB_0b80

BB_0b80:                                          ; preds = %BB_0be0, %BB_0b40
  %phi.41 = phi i32 [ %tid_x, %BB_0b40 ], [ %viadd.2, %BB_0be0 ]
  %phi.42 = phi i32 [ %.283, %BB_0b40 ], [ %viadd.3, %BB_0be0 ]
  %phi.43 = phi i32 [ %.326, %BB_0b40 ], [ %iadd3_n1.9, %BB_0be0 ]
  %phi.44 = phi float [ 0.000000e+00, %BB_0b40 ], [ %fadd.7, %BB_0be0 ]
  %.334 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.42
  %lds.2 = load volatile float, ptr addrspace(3) %.334, align 4
  %iadd3_n1.9 = add i32 %phi.43, -1
  %viadd.2 = add i32 %phi.41, 4
  %isetrp_cmp1.31 = icmp ne i32 %iadd3_n1.9, 0
  %viadd.3 = add i32 %phi.42, 16
  %fadd.7 = fadd float %lds.2, %phi.44
  br label %BB_0be0

BB_0be0:                                          ; preds = %BB_0b80
  %166 = zext i1 %isetrp_cmp1.31 to i32
  %167 = icmp ne i32 %166, 0
  br i1 %167, label %BB_0b80, label %BB_0c10

BB_0c10:                                          ; preds = %BB_0be0, %BB_0b30
  %phi.45 = phi i32 [ %tid_x, %BB_0b30 ], [ %viadd.2, %BB_0be0 ]
  %phi.46 = phi i32 [ %tid_x, %BB_0b30 ], [ %tid_x, %BB_0be0 ]
  %phi.47 = phi float [ 0.000000e+00, %BB_0b30 ], [ %fadd.7, %BB_0be0 ]
  %168 = zext i32 %163 to i64
  %169 = shl i64 %168, 32
  %170 = zext i32 %phi.45 to i64
  %171 = or i64 %170, %169
  %cond_not.13 = xor i1 %isetrp_cmp1.30, true
  br i1 %cond_not.13, label %BB_1110, label %BB_0c20

BB_0c20:                                          ; preds = %BB_0c10
  %viadd.4 = add i32 %phi.45, -16
  %iadd3_o1_not.1 = xor i32 %viadd.4, -1
  %iadd3_o1_neg.1 = add i32 %iadd3_o1_not.1, 1
  %iadd3_n1.10 = add i32 %iadd3_o1_neg.1, 16
  %isetrp_cmp1.32 = icmp sgt i32 %iadd3_n1.10, 48
  %.343 = zext i32 %phi.45 to i64
  %.346 = shl i64 %.343, 2
  %.347 = and i64 %.346, 4294967295
  %.348 = add i64 %.347, %.278
  %.349 = trunc i64 %.348 to i32
  %iadd3_n1.11 = add i32 %.349, 32
  br label %BB_0c90

BB_0c90:                                          ; preds = %BB_0c20
  %cond_not.14 = xor i1 %isetrp_cmp1.32, true
  br i1 %cond_not.14, label %BB_0ef0, label %BB_0ca0

BB_0ca0:                                          ; preds = %BB_0c90
  br label %BB_0cb0

BB_0cb0:                                          ; preds = %BB_0ee0, %BB_0ca0
  %phi.48 = phi i32 [ %viadd.4, %BB_0ca0 ], [ %viadd.5, %BB_0ee0 ]
  %phi.49 = phi i32 [ %iadd3_n1.11, %BB_0ca0 ], [ %viadd.6, %BB_0ee0 ]
  %phi.50 = phi float [ %phi.47, %BB_0ca0 ], [ %fadd.23, %BB_0ee0 ]
  %lds_addr_memaddr_offset_add = add i32 %phi.49, -32
  %.358 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add
  %lds.3 = load volatile float, ptr addrspace(3) %.358, align 4
  %viadd.5 = add i32 %phi.48, 64
  %lds_addr_memaddr_offset_add.1 = add i32 %phi.49, -16
  %.359 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.1
  %lds.4 = load volatile float, ptr addrspace(3) %.359, align 4
  %isetrp_cmp1.33 = icmp sge i32 %viadd.5, -32
  %.360 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.49
  %lds.5 = load volatile float, ptr addrspace(3) %.360, align 4
  %lds_addr_memaddr_offset_add.2 = add i32 %phi.49, 16
  %.361 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.2
  %lds.6 = load volatile float, ptr addrspace(3) %.361, align 4
  %lds_addr_memaddr_offset_add.3 = add i32 %phi.49, 32
  %.362 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.3
  %lds.7 = load volatile float, ptr addrspace(3) %.362, align 4
  %lds_addr_memaddr_offset_add.4 = add i32 %phi.49, 48
  %.363 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.4
  %lds.8 = load volatile float, ptr addrspace(3) %.363, align 4
  %lds_addr_memaddr_offset_add.5 = add i32 %phi.49, 64
  %.364 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.5
  %lds.9 = load volatile float, ptr addrspace(3) %.364, align 4
  %lds_addr_memaddr_offset_add.6 = add i32 %phi.49, 80
  %.365 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.6
  %lds.10 = load volatile float, ptr addrspace(3) %.365, align 4
  %lds_addr_memaddr_offset_add.7 = add i32 %phi.49, 96
  %.366 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.7
  %lds.11 = load volatile float, ptr addrspace(3) %.366, align 4
  %lds_addr_memaddr_offset_add.8 = add i32 %phi.49, 112
  %.367 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.8
  %lds.12 = load volatile float, ptr addrspace(3) %.367, align 4
  %fadd.8 = fadd float %lds.3, %phi.50
  %lds_addr_memaddr_offset_add.9 = add i32 %phi.49, 160
  %.368 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.9
  %lds.13 = load volatile float, ptr addrspace(3) %.368, align 4
  %fadd.9 = fadd float %fadd.8, %lds.4
  %lds_addr_memaddr_offset_add.10 = add i32 %phi.49, 128
  %.369 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.10
  %lds.14 = load volatile float, ptr addrspace(3) %.369, align 4
  %fadd.10 = fadd float %fadd.9, %lds.5
  %lds_addr_memaddr_offset_add.11 = add i32 %phi.49, 144
  %.370 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.11
  %lds.15 = load volatile float, ptr addrspace(3) %.370, align 4
  %fadd.11 = fadd float %fadd.10, %lds.6
  %lds_addr_memaddr_offset_add.12 = add i32 %phi.49, 176
  %.371 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.12
  %lds.16 = load volatile float, ptr addrspace(3) %.371, align 4
  %fadd.12 = fadd float %fadd.11, %lds.7
  %lds_addr_memaddr_offset_add.13 = add i32 %phi.49, 192
  %.372 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.13
  %lds.17 = load volatile float, ptr addrspace(3) %.372, align 4
  %fadd.13 = fadd float %fadd.12, %lds.8
  %lds_addr_memaddr_offset_add.14 = add i32 %phi.49, 208
  %.373 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.14
  %lds.18 = load volatile float, ptr addrspace(3) %.373, align 4
  %fadd.14 = fadd float %fadd.13, %lds.9
  %fadd.15 = fadd float %fadd.14, %lds.10
  %viadd.6 = add i32 %phi.49, 256
  %fadd.16 = fadd float %fadd.15, %lds.11
  %fadd.17 = fadd float %fadd.16, %lds.12
  %fadd.18 = fadd float %fadd.17, %lds.14
  %fadd.19 = fadd float %fadd.18, %lds.15
  %fadd.20 = fadd float %fadd.19, %lds.13
  %fadd.21 = fadd float %fadd.20, %lds.16
  %fadd.22 = fadd float %fadd.21, %lds.17
  %fadd.23 = fadd float %fadd.22, %lds.18
  br label %BB_0ee0

BB_0ee0:                                          ; preds = %BB_0cb0
  %cond_not.15 = xor i1 %isetrp_cmp1.33, true
  %phi_cast_R153_bitcast = bitcast float %fadd.16 to i32
  br i1 %cond_not.15, label %BB_0cb0, label %BB_0ef0

BB_0ef0:                                          ; preds = %BB_0ee0, %BB_0c90
  %phi.51 = phi i32 [ %163, %BB_0c90 ], [ %phi_cast_R153_bitcast, %BB_0ee0 ]
  %phi.52 = phi i32 [ %viadd.4, %BB_0c90 ], [ %viadd.5, %BB_0ee0 ]
  %phi.53 = phi i32 [ %iadd3_n1.11, %BB_0c90 ], [ %viadd.6, %BB_0ee0 ]
  %phi.54 = phi float [ %phi.47, %BB_0c90 ], [ %fadd.23, %BB_0ee0 ]
  %phi.55 = phi i32 [ 1, %BB_0c90 ], [ 0, %BB_0ee0 ]
  %iadd3_o1_not.2 = xor i32 %phi.52, -1
  %iadd3_o1_neg.2 = add i32 %iadd3_o1_not.2, 1
  %iadd3_n1.12 = add i32 %iadd3_o1_neg.2, 16
  %172 = zext i32 %phi.51 to i64
  %173 = shl i64 %172, 32
  %174 = zext i32 %iadd3_n1.12 to i64
  %175 = or i64 %174, %173
  %isetrp_cmp1.34 = icmp sgt i32 %iadd3_n1.12, 16
  br label %BB_0f30

BB_0f30:                                          ; preds = %BB_0ef0
  %cond_not.16 = xor i1 %isetrp_cmp1.34, true
  br i1 %cond_not.16, label %BB_1070, label %BB_0f40

BB_0f40:                                          ; preds = %BB_0f30
  %lds_addr_memaddr_offset_add.15 = add i32 %phi.53, -32
  %.378 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.15
  %lds.19 = load volatile float, ptr addrspace(3) %.378, align 4
  %viadd.7 = add i32 %phi.52, 32
  %lds_addr_memaddr_offset_add.16 = add i32 %phi.53, -16
  %.384 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.16
  %lds.20 = load volatile float, ptr addrspace(3) %.384, align 4
  %.385 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.53
  %lds.21 = load volatile float, ptr addrspace(3) %.385, align 4
  %lds_addr_memaddr_offset_add.17 = add i32 %phi.53, 16
  %.386 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.17
  %lds.22 = load volatile float, ptr addrspace(3) %.386, align 4
  %lds_addr_memaddr_offset_add.18 = add i32 %phi.53, 32
  %.387 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.18
  %lds.23 = load volatile float, ptr addrspace(3) %.387, align 4
  %lds_addr_memaddr_offset_add.19 = add i32 %phi.53, 48
  %.388 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.19
  %lds.24 = load volatile float, ptr addrspace(3) %.388, align 4
  %lds_addr_memaddr_offset_add.20 = add i32 %phi.53, 64
  %.389 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.20
  %lds.25 = load volatile float, ptr addrspace(3) %.389, align 4
  %lds_addr_memaddr_offset_add.21 = add i32 %phi.53, 80
  %.390 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.21
  %lds.26 = load volatile float, ptr addrspace(3) %.390, align 4
  %iadd3_n1.13 = add i32 %phi.53, 128
  %fadd.24 = fadd float %phi.54, %lds.19
  %fadd.25 = fadd float %fadd.24, %lds.20
  %fadd.26 = fadd float %fadd.25, %lds.21
  %fadd.27 = fadd float %fadd.26, %lds.22
  %fadd.28 = fadd float %fadd.27, %lds.23
  %fadd.29 = fadd float %fadd.28, %lds.24
  %fadd.30 = fadd float %fadd.29, %lds.25
  %fadd.31 = fadd float %fadd.30, %lds.26
  %phi_cast_R155_bitcast = bitcast float %lds.20 to i32
  %phi_cast_R117_bitcast = bitcast float %fadd.30 to i32
  %176 = zext i32 %phi_cast_R155_bitcast to i64
  %177 = shl i64 %176, 32
  %178 = zext i32 %phi_cast_R117_bitcast to i64
  %179 = or i64 %178, %177
  br label %BB_1070

BB_1070:                                          ; preds = %BB_0f40, %BB_0f30
  %180 = phi i64 [ %179, %BB_0f40 ], [ %175, %BB_0f30 ]
  %phi.58 = phi i32 [ %viadd.7, %BB_0f40 ], [ %phi.52, %BB_0f30 ]
  %phi.59 = phi i32 [ %iadd3_n1.13, %BB_0f40 ], [ %phi.53, %BB_0f30 ]
  %phi.60 = phi float [ %fadd.31, %BB_0f40 ], [ %phi.54, %BB_0f30 ]
  %phi.61 = phi i32 [ 0, %BB_0f40 ], [ %phi.55, %BB_0f30 ]
  %181 = lshr i64 %180, 32
  %182 = trunc i64 %181 to i32
  %isetrp_src_trunc.2 = trunc i32 %phi.61 to i1
  %isetrp_cmp1.35 = icmp slt i32 %phi.58, 16
  %isetrp_cmp2.35 = or i1 %isetrp_cmp1.35, %isetrp_src_trunc.2
  br label %BB_1090

BB_1090:                                          ; preds = %BB_1070
  %183 = zext i1 %isetrp_cmp2.35 to i32
  %184 = icmp ne i32 %183, 0
  br i1 %184, label %BB_80001090, label %BB_1110

BB_80001090:                                      ; preds = %BB_1090
  %lds_addr_memaddr_offset_add.22 = add i32 %phi.59, -32
  %.394 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.22
  %lds.27 = load volatile float, ptr addrspace(3) %.394, align 4
  %lds_addr_memaddr_offset_add.23 = add i32 %phi.59, -16
  %.395 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.23
  %lds.28 = load volatile float, ptr addrspace(3) %.395, align 4
  %.396 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %phi.59
  %lds.29 = load volatile float, ptr addrspace(3) %.396, align 4
  %lds_addr_memaddr_offset_add.24 = add i32 %phi.59, 16
  %.397 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %lds_addr_memaddr_offset_add.24
  %lds.30 = load volatile float, ptr addrspace(3) %.397, align 4
  %fadd.32 = fadd float %phi.60, %lds.27
  %fadd.33 = fadd float %fadd.32, %lds.28
  %fadd.34 = fadd float %fadd.33, %lds.29
  %fadd.35 = fadd float %fadd.34, %lds.30
  %phi_cast_R120_bitcast = bitcast float %fadd.32 to i32
  %185 = zext i32 %182 to i64
  %186 = shl i64 %185, 32
  %187 = zext i32 %phi_cast_R120_bitcast to i64
  %188 = or i64 %187, %186
  br label %BB_1110

BB_1110:                                          ; preds = %BB_80001090, %BB_1090, %BB_0c10
  %189 = phi i64 [ %171, %BB_0c10 ], [ %188, %BB_80001090 ], [ %180, %BB_1090 ]
  %phi.64 = phi float [ %phi.47, %BB_0c10 ], [ %fadd.35, %BB_80001090 ], [ %phi.60, %BB_1090 ]
  %warp_reconv_mask.1 = call i32 @llvm.nvvm.activemask()
  call void @llvm.nvvm.bar.warp.sync(i32 %warp_reconv_mask.1)
  store volatile float %phi.64, ptr addrspace(3) %.284, align 4
  br label %BB_1130

BB_1130:                                          ; preds = %BB_1110, %BB_0ab0
  %190 = phi i64 [ %189, %BB_1110 ], [ %161, %BB_0ab0 ]
  %phi.67 = phi i32 [ %phi.46, %BB_1110 ], [ %tid_x, %BB_0ab0 ]
  call void @llvm.nvvm.barrier0()
  %isetrp_cmp1.36 = icmp ne i32 %phi.67, 0
  br label %BB_1160

BB_1160:                                          ; preds = %BB_1130
  %191 = zext i1 %isetrp_cmp1.36 to i32
  %192 = icmp ne i32 %191, 0
  br i1 %192, label %BB_80001160, label %BB_1170

BB_1170:                                          ; preds = %BB_1160
  %s2ur_ctaid_z.1 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.z()
  %193 = zext i32 %s2ur_ctaid_z.1 to i64
  %fsetrp_cmp1.2 = fcmp une float %phi.3, 0.000000e+00
  %.404 = getelementptr inbounds [624 x i8], ptr %param_local, i64 0, i64 616
  %ldc_const.17 = load i64, ptr %.404, align 8
  %.406 = getelementptr inbounds [32768 x i8], ptr addrspace(3) @shared_mem, i32 0, i32 %.276
  %lds.31 = load volatile i128, ptr addrspace(3) %.406, align 8
  %"R7:R6:R5:R4_r0" = trunc i128 %lds.31 to i32
  %"R7:R6:R5:R4_r1_shift" = lshr i128 %lds.31, 32
  %"R7:R6:R5:R4_r1" = trunc i128 %"R7:R6:R5:R4_r1_shift" to i32
  %"R7:R6:R5:R4_r2_shift" = lshr i128 %lds.31, 64
  %"R7:R6:R5:R4_r2" = trunc i128 %"R7:R6:R5:R4_r2_shift" to i32
  %"R7:R6:R5:R4_r3_shift" = lshr i128 %lds.31, 96
  %"R7:R6:R5:R4_r3" = trunc i128 %"R7:R6:R5:R4_r3_shift" to i32
  %ldc_const.18 = load i32, ptr %.40, align 4
  br label %BB_11c0

BB_11c0:                                          ; preds = %BB_1170
  %194 = zext i1 %fsetrp_cmp1.2 to i32
  %195 = icmp ne i32 %194, 0
  br i1 %195, label %BB_800011c0, label %BB_11d0

BB_800011c0:                                      ; preds = %BB_11c0
  %ldc_const.19 = load i64, ptr %.31, align 8
  br label %BB_11d0

BB_11d0:                                          ; preds = %BB_800011c0, %BB_11c0
  %196 = phi i64 [ %ldc_const.19, %BB_800011c0 ], [ %190, %BB_11c0 ]
  %197 = lshr i64 %196, 32
  %198 = trunc i64 %197 to i32
  %199 = mul i64 %193, %ldc_const.17
  %ldc_const.20 = load i64, ptr %.43, align 8
  %r2p_shr_1 = lshr i32 %ldc_const.18, 1
  %r2p_p1 = trunc i32 %r2p_shr_1 to i1
  %r2p_shr_2 = lshr i32 %ldc_const.18, 2
  %r2p_p2 = trunc i32 %r2p_shr_2 to i1
  %.430 = shl i64 %199, 2
  %200 = add i64 %ldc_const.20, %.430
  br label %BB_1240

BB_1240:                                          ; preds = %BB_11d0
  %phi_cast_R162_bitcast = bitcast i32 %198 to float
  br i1 %fsetrp_cmp1.2, label %BB_80001240, label %BB_1250

BB_80001240:                                      ; preds = %BB_1240
  %"R162:R125_addr_ptr" = inttoptr i64 %196 to ptr addrspace(1)
  %ldg.8 = load float, ptr addrspace(1) %"R162:R125_addr_ptr", align 4
  br label %BB_1250

BB_1250:                                          ; preds = %BB_80001240, %BB_1240
  %phi.70 = phi float [ %ldg.8, %BB_80001240 ], [ %phi_cast_R162_bitcast, %BB_1240 ]
  br label %BB_1270

BB_1270:                                          ; preds = %BB_1250
  %201 = zext i1 %r2p_p2 to i32
  %202 = icmp ne i32 %201, 0
  br i1 %202, label %BB_80001270, label %BB_1280

BB_80001270:                                      ; preds = %BB_1270
  %"R131:R241_addr_ptr" = inttoptr i64 %200 to ptr addrspace(1)
  %ldg.9 = load float, ptr addrspace(1) %"R131:R241_addr_ptr", align 4
  br label %BB_1280

BB_1280:                                          ; preds = %BB_80001270, %BB_1270
  %phi.71 = phi float [ %ldg.9, %BB_80001270 ], [ 0.000000e+00, %BB_1270 ]
  %fadd_rhs_bitcast = bitcast i32 %"R7:R6:R5:R4_r0" to float
  %fadd.36 = fadd float 0.000000e+00, %fadd_rhs_bitcast
  %fadd_rhs_bitcast.1 = bitcast i32 %"R7:R6:R5:R4_r1" to float
  %fadd.37 = fadd float %fadd.36, %fadd_rhs_bitcast.1
  %fadd_rhs_bitcast.2 = bitcast i32 %"R7:R6:R5:R4_r2" to float
  %fadd.38 = fadd float %fadd.37, %fadd_rhs_bitcast.2
  %ldc_const.21 = load i64, ptr %.34, align 8
  %fadd_rhs_bitcast.3 = bitcast i32 %"R7:R6:R5:R4_r3" to float
  %fadd.39 = fadd float %fadd.38, %fadd_rhs_bitcast.3
  br label %BB_12e0

BB_12e0:                                          ; preds = %BB_1280
  %203 = zext i1 %fsetrp_cmp1.2 to i32
  %204 = icmp ne i32 %203, 0
  br i1 %204, label %BB_800012e0, label %BB_12f0

BB_800012e0:                                      ; preds = %BB_12e0
  %fmul = fmul float %phi.70, %phi.3
  br label %BB_12f0

BB_12f0:                                          ; preds = %BB_800012e0, %BB_12e0
  %phi.72 = phi float [ %fmul, %BB_800012e0 ], [ 0.000000e+00, %BB_12e0 ]
  %ffma = call float @llvm.fma.f32(float %fadd.39, float %phi.2, float %phi.72)
  %sel.8 = select i1 %r2p_p1, float 0.000000e+00, float 0x7FF8000000000000
  %fadd.40 = fadd float %ffma, %phi.71
  %fsetrp_cmp1.3 = fcmp uge float %fadd.40, %sel.8
  %sel_pred_not = xor i1 %fsetrp_cmp1.3, true
  %sel.9 = select i1 %sel_pred_not, float %sel.8, float %fadd.40
  %"R317:R299_addr_ptr" = inttoptr i64 %ldc_const.21 to ptr addrspace(1)
  store float %sel.9, ptr addrspace(1) %"R317:R299_addr_ptr", align 4
  ret void

BB_80001160:                                      ; preds = %BB_1160
  ret void

exit_0150:                                        ; preds = %BB_80000150
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #0

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { convergent nocallback nounwind }
attributes #2 = { convergent nocallback nounwind memory(inaccessiblemem: readwrite) }

!nvvmir.version = !{!0, !0}
!nvvm.annotations = !{!1, !2, !3, !4, !5, !6, !7, !8}

!0 = !{i32 2, i32 0}
!1 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"kernel", i32 1}
!2 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"maxntidx", i32 128}
!3 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"maxntidy", i32 1}
!4 = !{ptr @_Z10dot_kernelIfLi128ELi0E15cublasDotParamsI16cublasGemvTensorIKfE30cublasGemvTensorStridedBatchedIfEEEvT2_, !"maxntidz", i32 1}
!5 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"kernel", i32 1}
!6 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"maxntidx", i32 128}
!7 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"maxntidy", i32 1}
!8 = !{ptr @_Z20reduce_1Block_kernelIfLi128ELi7E30cublasGemvTensorStridedBatchedIfE16cublasGemvTensorIfES3_EvPKT_S4_T2_iS6_S4_T3_T4_19cublasPointerMode_t18cublasLtEpilogue_tS0_IKN8biasTypeINS9_10value_typeES4_E4typeEE, !"maxntidz", i32 1}
