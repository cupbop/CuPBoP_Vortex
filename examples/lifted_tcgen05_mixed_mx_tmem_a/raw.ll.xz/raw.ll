; ModuleID = "tcgen05_cubin"
target triple = "nvptx64-nvidia-cuda"
target datalayout = "e-i64:64-v16:16-v32:32-n16:32:64"

@"shared_mem" = external addrspace(3) global [2064 x i8], align 16
define void @"_Z13column_scaledIL4Case11EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P33_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0090"
BB_0090:
  %"cond_trunc" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0190", label %"BB_00a0"
BB_00a0:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".21" = zext i32 %"tid_x" to i64
  %".22" = zext i32 %".16" to i64
  %".23" = zext i32 2 to i64
  %".24" = shl i64 %".21", %".23"
  %".25" = and i64 %".24", 4294967295
  %".26" = add i64 %".25", %".22"
  %".27" = trunc i64 %".26" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P30_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P30_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"imad_with_cin", %"BB_00a0"], [%"imad_with_cin.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"tid_x", %"BB_00a0"], [%"viadd", %"BB_0180"]
  %"phi.2" = phi  i32 [%".27", %"BB_00a0"], [%"viadd.1", %"BB_0180"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"BB_00a0"], [%"iadd3_trunc.1", %"BB_0180"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R83:R80_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R83:R80_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.1", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P5_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi"
  %"imad_cin_trunc.1" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".29" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".29" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P31_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0100", label %"BB_0190"
BB_0190:
  %"phi.4" = phi  i32 [%"P33_to_i32", %"BB_0090"], [%"P5_to_i32", %"BB_0180"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P15_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  br label %"BB_01e0"
BB_01e0:
  %"cond_trunc.2" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_800001e0", label %"BB_0230"
BB_800001e0:
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %".35" = zext i32 %"iadd3_n2.1" to i64
  %".36" = zext i32 0 to i64
  %".37" = shl i64 %".36", 32
  %"shf_concat" = or i64 %".35", %".37"
  %"shf_shift_64" = zext i32 11 to i64
  %".38" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".38" to i32
  %".39" = zext i32 %"iadd3_n2.1" to i64
  %".40" = zext i32 0 to i64
  %".41" = shl i64 %".40", 32
  %"shf_concat.1" = or i64 %".39", %".41"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".42" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".42" to i32
  %".43" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".44" = zext i32 %"iadd3_n2" to i64
  %".45" = zext i32 24 to i64
  %".46" = shl i64 %".43", %".45"
  %".47" = and i64 %".46", 4294967295
  %".48" = add i64 %".47", %".44"
  %".49" = trunc i64 %".48" to i32
  br label %"BB_0230"
BB_0230:
  %"phi.5" = phi  i32 [%".49", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.6" = phi  i32 [%"shf_result", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.7" = phi  i32 [%"shf_result.1", %"BB_800001e0"], [1, %"BB_01e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P16_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0250"
BB_0250:
  %"cond_trunc.3" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000250", label %"BB_0260"
BB_80000250:
  %"mbar_shared_winoff" = and i32 %"phi.5", 16777215
  %".54" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".54" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.7" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.6" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".55" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".55" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0260"
BB_0260:
  %"cond_trunc.4" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0400", label %"BB_0270"
BB_0270:
  %"allocation_dst_memaddr_offset_add" = add i32 %".16", 1032
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".59" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".60" = ptrtoint i8 addrspace(3)* %".59" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".60", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P7_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.5" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0400", label %"BB_02a0"
BB_02a0:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 3
  %".64" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".65" = zext i32 64 to i64
  %".66" = zext i32 24 to i64
  %".67" = shl i64 %".64", %".66"
  %".68" = and i64 %".67", 4294967295
  %".69" = add i64 %".68", %".65"
  %".70" = trunc i64 %".69" to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".16", 1032
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".71" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".72" = bitcast i8 addrspace(3)* %".71" to i32 addrspace(3)*
  %".73" = load i32, i32 addrspace(3)* %".72"
  %".74" = lshr i32 %".73", 5
  %"P17_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".74"
  %"bra_cond_trunc" = trunc i32 %"P17_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_0390", label %"BB_0330"
BB_0330:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".16", 1032
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".76" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".77" = bitcast i8 addrspace(3)* %".76" to i32 addrspace(3)*
  %".78" = load i32, i32 addrspace(3)* %".77"
  %".79" = lshr i32 %".78", 5
  %"P18_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".79"
  %"bra_cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0330", label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%"imad.5", %"BB_02a0"], [%"imad.6", %"BB_0330"]
  %".81" = zext i32 %"imad.3" to i64
  %".82" = zext i32 0 to i64
  %".83" = shl i64 %".82", 32
  %"shf_concat.2" = or i64 %".81", %".83"
  %"shf_shift_64.2" = zext i32 %"phi.8" to i64
  %".84" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".84" to i32
  %".85" = zext i32 %"imad.4" to i64
  %".86" = zext i32 0 to i64
  %".87" = shl i64 %".86", 32
  %"shf_concat.3" = or i64 %".85", %".87"
  %"shf_shift_64.3" = zext i32 %"phi.8" to i64
  %".88" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".88" to i32
  %"imad_tmp.6" = mul i32 %"phi.8", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".70", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".89" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".89" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".70", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".91" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0400"
BB_0400:
  %"phi.9" = phi  i32 [%"P7_to_i32", %"BB_0390"], [%"P7_to_i32", %"BB_0290"], [%"phi.4", %"BB_0260"]
  %".94" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".95" = bitcast i8* %".94" to i64*
  %"ldc_const.1" = load i64, i64* %".95"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 18
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.9" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R75:R8_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R75:R8_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R75:R8_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R75:R8_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R75:R8_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R75:R8_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R75:R8_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R75:R8_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".96" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".96" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".97" = xor i32 %"imad.10", -1
  %".98" = xor i32 65011712, -1
  %".99" = xor i32 0, -1
  %".100" = and i32 %"imad.10", 65011712
  %".101" = and i32 %".100", %".99"
  %".102" = and i32 %"imad.10", 65011712
  %".103" = and i32 %".102", 0
  %".104" = or i32 %".101", %".103"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".104"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R75:R8_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R75:R8_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R75:R8_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R75:R8_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R75:R8_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R75:R8_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R75:R8_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R75:R8_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.15"
  %"ldg_addr_r0_ext.17" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.17" = or i64 0, %"ldg_addr_r0_ext.17"
  %"ldg_addr_r1_ext.17" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.17" = shl i64 %"ldg_addr_r1_ext.17", 32
  %"ldg_addr_packed_1.17" = or i64 %"ldg_addr_packed_0.17", %"ldg_addr_r1_shift.17"
  %"ldg_addr_memaddr_offset_add.16" = add i64 %"ldg_addr_packed_1.17", 9248
  %"R75:R8_addr_ptr.16" = inttoptr i64 %"ldg_addr_memaddr_offset_add.16" to i32 addrspace(1)*
  %"ldg.17" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.16"
  %"ldg_addr_r0_ext.18" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.18" = or i64 0, %"ldg_addr_r0_ext.18"
  %"ldg_addr_r1_ext.18" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.18" = shl i64 %"ldg_addr_r1_ext.18", 32
  %"ldg_addr_packed_1.18" = or i64 %"ldg_addr_packed_0.18", %"ldg_addr_r1_shift.18"
  %"ldg_addr_memaddr_offset_add.17" = add i64 %"ldg_addr_packed_1.18", 9252
  %"R75:R8_addr_ptr.17" = inttoptr i64 %"ldg_addr_memaddr_offset_add.17" to i32 addrspace(1)*
  %"ldg.18" = load i32, i32 addrspace(1)* %"R75:R8_addr_ptr.17"
  %"R11:R10_r0" = trunc i64 0 to i32
  %"R11:R10_r1_shift" = lshr i64 0, 32
  %"R11:R10_r1" = trunc i64 %"R11:R10_r1_shift" to i32
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.11", 24
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"ldg.17", i32 %"ldg.18", i32 %"R11:R10_r0", i32 %"R11:R10_r1")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_06d0"
BB_06d0:
  %"cond_trunc.6" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0870", label %"BB_06e0"
BB_06e0:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".115" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".115" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".116" = zext i32 0 to i64
  %".117" = zext i32 %".16" to i64
  %".118" = shl i64 %".117", 32
  %"shf_concat.4" = or i64 %".116", %".118"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".119" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".119", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".120" = xor i32 %"plop3_a_bit", 1
  %".121" = xor i32 %"plop3_b_bit", 1
  %".122" = xor i32 %"plop3_c_bit", 1
  %".123" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".124" = and i32 %".123", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".124", 0
  %"P9_to_i32" = zext i1 %"plop3_pred" to i32
  %".125" = xor i32 %"shf_result.4", -1
  %".126" = xor i32 16376, -1
  %".127" = xor i32 0, -1
  %".128" = and i32 %"shf_result.4", 16376
  %".129" = and i32 %".128", %".127"
  %".130" = and i32 %"shf_result.4", 16376
  %".131" = and i32 %".130", 0
  %".132" = or i32 %".129", %".131"
  %".133" = xor i32 %".132", -1
  %".134" = xor i32 524288, -1
  %".135" = xor i32 0, -1
  %".136" = and i32 %".133", 524288
  %".137" = and i32 %".136", %".135"
  %".138" = and i32 %".133", 524288
  %".139" = and i32 %".138", 0
  %".140" = or i32 %".137", %".139"
  %".141" = and i32 %".132", %".134"
  %".142" = and i32 %".141", %".135"
  %".143" = or i32 %".140", %".142"
  %".144" = and i32 %".132", %".134"
  %".145" = and i32 %".144", 0
  %".146" = or i32 %".143", %".145"
  %".147" = and i32 %".132", 524288
  %".148" = and i32 %".147", %".135"
  %".149" = or i32 %".146", %".148"
  %".150" = and i32 %".132", 524288
  %".151" = and i32 %".150", 0
  %".152" = or i32 %".149", %".151"
  %"iadd3_n1.2" = add i32 %"lds.1", 32
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.1", 24
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"lds.1", 16
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  %"iadd3_n1.5" = add i32 %"lds.1", 20
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  br label %"BB_07a0"
BB_07a0:
  %"phi.10" = phi  i32 [%"phi.9", %"BB_06e0"], [%"P14_to_i32", %"BB_07d0"]
  %"phi.11" = phi  i32 [%"P9_to_i32", %"BB_06e0"], [%"phi.13", %"BB_07d0"]
  %"cond_trunc.7" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_800007a0", label %"BB_07b0"
BB_800007a0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P11_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_07b0"
BB_07b0:
  %"phi.12" = phi  i32 [%"P11_to_i32", %"BB_800007a0"], [%"phi.10", %"BB_07a0"]
  %"mma_b_r0_ext" = zext i32 %".152" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16416 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".156" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".157" = sub i64 %".156", 0
  %".158" = lshr i64 %".157", 4
  %".159" = add i64 %"mma_b_packed_1", %".158"
  %".160" = and i64 %".159", 16383
  %".161" = and i64 %"mma_b_packed_1", -16384
  %".162" = or i64 %".161", %".160"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.sp.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, [$5], $3, [$6], [$7], use_d; } }", "r,r,l,r,r,r,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.2", i64 %".162", i32 679739572, i32 %"mma_arg_zext", i32 %"iadd3_n2.3", i32 %"iadd3_n2.4", i32 %"iadd3_n2.5")
  br label %"BB_07c0"
BB_07c0:
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_800007c0", label %"BB_07d0"
BB_800007c0:
  %"lop3_a_trunc" = trunc i32 %"phi.12" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".166" = xor i32 %"plop3_a_bit.1", 1
  %".167" = xor i32 %"plop3_b_bit.1", 1
  %".168" = xor i32 %"plop3_c_bit.1", 1
  %".169" = and i32 %".166", %"plop3_b_bit.1"
  %".170" = and i32 %".169", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".170", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.13" = phi  i32 [%"P25_to_i32", %"BB_800007c0"], [%"phi.11", %"BB_07c0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".172" = xor i32 %"plop3_a_bit.2", 1
  %".173" = xor i32 %"plop3_b_bit.2", 1
  %".174" = xor i32 %"plop3_c_bit.2", 1
  %".175" = and i32 %".172", %"plop3_b_bit.2"
  %".176" = and i32 %".175", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".176", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.13" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_07a0", label %"BB_07f0"
BB_07f0:
  %"iadd3_n1.6" = add i32 1024, 1024
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".178" = xor i32 %"plop3_a_bit.3", 1
  %".179" = xor i32 %"plop3_b_bit.3", 1
  %".180" = xor i32 %"plop3_c_bit.3", 1
  %".181" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".182" = and i32 %".181", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".182", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".183" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".184" = zext i32 %"iadd3_n2.6" to i64
  %".185" = zext i32 24 to i64
  %".186" = shl i64 %".183", %".185"
  %".187" = and i64 %".186", 4294967295
  %".188" = add i64 %".187", %".184"
  %".189" = trunc i64 %".188" to i32
  br label %"BB_0820"
BB_0820:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_07f0"], [%"P4_to_i32", %"BB_0850"]
  %"phi.15" = phi  i32 [%"P27_to_i32", %"BB_07f0"], [%"phi.17", %"BB_0850"]
  %"cond_trunc.9" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000820", label %"BB_0830"
BB_80000820:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P35_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0830"
BB_0830:
  %"phi.16" = phi  i32 [%"P35_to_i32", %"BB_80000820"], [%"phi.14", %"BB_0820"]
  %"utcbar_local_winoff" = and i32 %".189", 16777215
  %".193" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".194" = ptrtoint i8 addrspace(3)* %".193" to i32
  %".195" = lshr i32 %".189", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".194", i32 %".195")
  br label %"BB_0840"
BB_0840:
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000840", label %"BB_0850"
BB_80000840:
  %"lop3_a_trunc.1" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".199" = xor i32 %"plop3_a_bit.4", 1
  %".200" = xor i32 %"plop3_b_bit.4", 1
  %".201" = xor i32 %"plop3_c_bit.4", 1
  %".202" = and i32 %".199", %"plop3_b_bit.4"
  %".203" = and i32 %".202", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".203", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0850"
BB_0850:
  %"phi.17" = phi  i32 [%"P29_to_i32", %"BB_80000840"], [%"phi.15", %"BB_0840"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".205" = xor i32 %"plop3_a_bit.5", 1
  %".206" = xor i32 %"plop3_b_bit.5", 1
  %".207" = xor i32 %"plop3_c_bit.5", 1
  %".208" = and i32 %".205", %"plop3_b_bit.5"
  %".209" = and i32 %".208", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".209", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0820", label %"BB_0870"
BB_0870:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.7" = add i32 1024, 1024
  %"iadd3_n2.7" = add i32 %"iadd3_n1.7", 0
  %".211" = zext i32 0 to i64
  %".212" = zext i32 0 to i64
  %".213" = shl i64 %".212", 32
  %"shf_concat.5" = or i64 %".211", %".213"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".214" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".214" to i32
  %".215" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".216" = zext i32 %"iadd3_n2.7" to i64
  %".217" = zext i32 24 to i64
  %".218" = shl i64 %".215", %".217"
  %".219" = and i64 %".218", 4294967295
  %".220" = add i64 %".219", %".216"
  %".221" = trunc i64 %".220" to i32
  %"mbar_shared_winoff.1" = and i32 %".221", 16777215
  %".222" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".222" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P3_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_08e0"
BB_08e0:
  %"cond_trunc.11" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0d80", label %"BB_08f0"
BB_0d80:
  %"mbar_shared_winoff.2" = and i32 %".221", 16777215
  %".225" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".225" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P20_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0d90"
BB_0d90:
  %"cond_trunc.12" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0d80", label %"BB_08f0"
BB_08f0:
  %".228" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".229" = bitcast i8* %".228" to i64*
  %"ldc_const.2" = load i64, i64* %".229"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".230" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".231" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".232" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".233" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".234" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".235" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".236" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".237" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.13" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R13:R29_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".230", i32 addrspace(1)* %"R13:R29_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R13:R29_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".231", i32 addrspace(1)* %"R13:R29_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R13:R29_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".232", i32 addrspace(1)* %"R13:R29_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R13:R29_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".233", i32 addrspace(1)* %"R13:R29_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R13:R29_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".234", i32 addrspace(1)* %"R13:R29_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".243" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".244" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".245" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".246" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R13:R29_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".235", i32 addrspace(1)* %"R13:R29_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R13:R29_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".236", i32 addrspace(1)* %"R13:R29_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R13:R29_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".237", i32 addrspace(1)* %"R13:R29_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".250" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".251" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".252" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".253" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R13:R29_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".243", i32 addrspace(1)* %"R13:R29_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R13:R29_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".244", i32 addrspace(1)* %"R13:R29_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R13:R29_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".245", i32 addrspace(1)* %"R13:R29_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R13:R29_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".246", i32 addrspace(1)* %"R13:R29_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R13:R29_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".250", i32 addrspace(1)* %"R13:R29_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R13:R29_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".251", i32 addrspace(1)* %"R13:R29_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R13:R29_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".252", i32 addrspace(1)* %"R13:R29_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R13:R29_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".253", i32 addrspace(1)* %"R13:R29_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0ae0"
BB_0ae0:
  %"cond_trunc.13" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000ae0", label %"BB_0af0"
BB_0af0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".264" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".264" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 3
  %".265" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".266" = zext i32 64 to i64
  %".267" = zext i32 24 to i64
  %".268" = shl i64 %".265", %".267"
  %".269" = and i64 %".268", 4294967295
  %".270" = add i64 %".269", %".266"
  %".271" = trunc i64 %".270" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".271", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".272" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".272" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".273" = xor i32 %"lds.2", -1
  %".274" = xor i32 65535, -1
  %".275" = xor i32 0, -1
  %".276" = and i32 %"lds.2", 65535
  %".277" = and i32 %".276", %".275"
  %".278" = and i32 %"lds.2", 65535
  %".279" = and i32 %".278", 0
  %".280" = or i32 %".277", %".279"
  %".281" = zext i32 0 to i64
  %".282" = zext i32 %".280" to i64
  %".283" = shl i64 %".282", 32
  %"shf_concat.6" = or i64 %".281", %".283"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".284" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.1" = lshr i64 %".284", 32
  %"shf_result.6" = trunc i64 %"shf_hi.1" to i32
  %".285" = zext i32 %"imad.14" to i64
  %".286" = zext i32 0 to i64
  %".287" = shl i64 %".286", 32
  %"shf_concat.7" = or i64 %".285", %".287"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".288" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".288" to i32
  %".289" = xor i32 %"lds.3", -1
  %".290" = xor i32 %"shf_result.7", -1
  %".291" = xor i32 0, -1
  %".292" = and i32 %"lds.3", %"shf_result.7"
  %".293" = and i32 %".292", %".291"
  %".294" = and i32 %"lds.3", %"shf_result.7"
  %".295" = and i32 %".294", 0
  %".296" = or i32 %".293", %".295"
  %"isetrp_cmp1.4" = icmp ne i32 %".296", %"shf_result.7"
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".297" = zext i32 %"imad.15" to i64
  %".298" = zext i32 0 to i64
  %".299" = shl i64 %".298", 32
  %"shf_concat.8" = or i64 %".297", %".299"
  %"shf_shift_64.8" = zext i32 %"shf_result.6" to i64
  %".300" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".300" to i32
  br label %"BB_0bc0"
BB_0bc0:
  %"cond_trunc.14" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0d50_0de0", label %"BB_0bd0"
BB_0bd0:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".271", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".303" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".303" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".304" = xor i32 %"lds.4", -1
  %".305" = xor i32 %"shf_result.8", -1
  %".306" = xor i32 0, -1
  %".307" = and i32 %"lds.4", %"shf_result.8"
  %".308" = and i32 %".307", %".306"
  %".309" = and i32 %"lds.4", %"shf_result.8"
  %".310" = and i32 %".309", 0
  %".311" = or i32 %".308", %".310"
  %"isetrp_cmp1.5" = icmp ne i32 %".311", %"shf_result.8"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0c00"
BB_0c00:
  %"cond_trunc.15" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0d20_0db0", label %"BB_0c10"
BB_0c10:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".314" = xor i32 0, -1
  %".315" = xor i32 %"shf_result.8", -1
  %".316" = xor i32 0, -1
  %".317" = and i32 %".314", %".315"
  %".318" = and i32 %".317", %".316"
  %".319" = and i32 %".314", %".315"
  %".320" = and i32 %".319", 0
  %".321" = or i32 %".318", %".320"
  %".322" = and i32 0, %".315"
  %".323" = and i32 %".322", %".316"
  %".324" = or i32 %".321", %".323"
  %".325" = and i32 0, %".315"
  %".326" = and i32 %".325", 0
  %".327" = or i32 %".324", %".326"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".327", i32 %"redux_mask")
  %".328" = xor i32 0, -1
  %".329" = xor i32 %"shf_result.7", -1
  %".330" = xor i32 0, -1
  %".331" = and i32 %".328", %".329"
  %".332" = and i32 %".331", %".330"
  %".333" = and i32 %".328", %".329"
  %".334" = and i32 %".333", 0
  %".335" = or i32 %".332", %".334"
  %".336" = and i32 0, %".329"
  %".337" = and i32 %".336", %".330"
  %".338" = or i32 %".335", %".337"
  %".339" = and i32 0, %".329"
  %".340" = and i32 %".339", 0
  %".341" = or i32 %".338", %".340"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".341"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask.1")
  %".342" = xor i32 %".341", -1
  %".343" = call i32 @"llvm.cttz.i32"(i32 %".342", i1 0)
  %".344" = shl i32 %".343", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".344") convergent
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  %"isetrp_cmp1.6" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and.1"
  br label %"BB_0ce0"
BB_0ce0:
  %"cond_trunc.16" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000ce0", label %"BB_0d60"
BB_80000ce0:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".271", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".348" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".348" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.18" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".271", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".349" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".349" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.17" monotonic
  br label %"BB_0d60"
BB_0d20_0db0:
  call void @"llvm.trap"()
  br label %"BB_0d60"
BB_0d50_0de0:
  call void @"llvm.trap"()
  br label %"BB_0d60"
BB_0d60:
  ret void
BB_80000ae0:
  ret void
}

define void @"_Z13column_scaledIL4Case10EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P33_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0090"
BB_0090:
  %"cond_trunc" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0190", label %"BB_00a0"
BB_00a0:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"R5:R4_r0" = trunc i64 %"ldc_const" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %".21" = zext i32 %"tid_x" to i64
  %".22" = zext i32 %".16" to i64
  %".23" = zext i32 2 to i64
  %".24" = shl i64 %".21", %".23"
  %".25" = and i64 %".24", 4294967295
  %".26" = add i64 %".25", %".22"
  %".27" = trunc i64 %".26" to i32
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P30_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R5:R4_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P30_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"imad_with_cin", %"BB_00a0"], [%"imad_with_cin.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"iadd3_trunc", %"BB_00a0"], [%"iadd3_trunc.1", %"BB_0180"]
  %"phi.2" = phi  i32 [%"tid_x", %"BB_00a0"], [%"viadd", %"BB_0180"]
  %"phi.3" = phi  i32 [%".27", %"BB_00a0"], [%"viadd.1", %"BB_0180"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R7:R28_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R7:R28_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.1" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P5_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi"
  %"imad_cin_trunc.1" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".29" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".29" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.3", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P31_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0100", label %"BB_0190"
BB_0190:
  %"phi.4" = phi  i32 [%"P33_to_i32", %"BB_0090"], [%"P5_to_i32", %"BB_0180"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P15_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  br label %"BB_01e0"
BB_01e0:
  %"cond_trunc.2" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_800001e0", label %"BB_0230"
BB_800001e0:
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %".35" = zext i32 %"iadd3_n2.1" to i64
  %".36" = zext i32 0 to i64
  %".37" = shl i64 %".36", 32
  %"shf_concat" = or i64 %".35", %".37"
  %"shf_shift_64" = zext i32 11 to i64
  %".38" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".38" to i32
  %".39" = zext i32 %"iadd3_n2.1" to i64
  %".40" = zext i32 0 to i64
  %".41" = shl i64 %".40", 32
  %"shf_concat.1" = or i64 %".39", %".41"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".42" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".42" to i32
  %".43" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".44" = zext i32 %"iadd3_n2" to i64
  %".45" = zext i32 24 to i64
  %".46" = shl i64 %".43", %".45"
  %".47" = and i64 %".46", 4294967295
  %".48" = add i64 %".47", %".44"
  %".49" = trunc i64 %".48" to i32
  br label %"BB_0230"
BB_0230:
  %"phi.5" = phi  i32 [%".49", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.6" = phi  i32 [%"shf_result", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.7" = phi  i32 [%"shf_result.1", %"BB_800001e0"], [1, %"BB_01e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P16_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0250"
BB_0250:
  %"cond_trunc.3" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000250", label %"BB_0260"
BB_80000250:
  %"mbar_shared_winoff" = and i32 %"phi.5", 16777215
  %".54" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".54" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.7" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.6" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".55" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".55" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0260"
BB_0260:
  %"cond_trunc.4" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0400", label %"BB_0270"
BB_0270:
  %"allocation_dst_memaddr_offset_add" = add i32 %".16", 1032
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".59" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".60" = ptrtoint i8 addrspace(3)* %".59" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".60", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P7_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.5" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0400", label %"BB_02a0"
BB_02a0:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 3
  %".64" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".65" = zext i32 64 to i64
  %".66" = zext i32 24 to i64
  %".67" = shl i64 %".64", %".66"
  %".68" = and i64 %".67", 4294967295
  %".69" = add i64 %".68", %".65"
  %".70" = trunc i64 %".69" to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".16", 1032
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".71" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".72" = bitcast i8 addrspace(3)* %".71" to i32 addrspace(3)*
  %".73" = load i32, i32 addrspace(3)* %".72"
  %".74" = lshr i32 %".73", 5
  %"P17_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".74"
  %"bra_cond_trunc" = trunc i32 %"P17_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_0390", label %"BB_0330"
BB_0330:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".16", 1032
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".76" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".77" = bitcast i8 addrspace(3)* %".76" to i32 addrspace(3)*
  %".78" = load i32, i32 addrspace(3)* %".77"
  %".79" = lshr i32 %".78", 5
  %"P18_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".79"
  %"bra_cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0330", label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%"imad.5", %"BB_02a0"], [%"imad.6", %"BB_0330"]
  %".81" = zext i32 %"imad.3" to i64
  %".82" = zext i32 0 to i64
  %".83" = shl i64 %".82", 32
  %"shf_concat.2" = or i64 %".81", %".83"
  %"shf_shift_64.2" = zext i32 %"phi.8" to i64
  %".84" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".84" to i32
  %".85" = zext i32 %"imad.4" to i64
  %".86" = zext i32 0 to i64
  %".87" = shl i64 %".86", 32
  %"shf_concat.3" = or i64 %".85", %".87"
  %"shf_shift_64.3" = zext i32 %"phi.8" to i64
  %".88" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".88" to i32
  %"imad_tmp.6" = mul i32 %"phi.8", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".70", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".89" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".89" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".70", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".91" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0400"
BB_0400:
  %"phi.9" = phi  i32 [%"P7_to_i32", %"BB_0390"], [%"P7_to_i32", %"BB_0290"], [%"phi.4", %"BB_0260"]
  %".94" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".95" = bitcast i8* %".94" to i64*
  %"ldc_const.1" = load i64, i64* %".95"
  %"R21:R20_r0" = trunc i64 %"ldc_const.1" to i32
  %"R21:R20_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R21:R20_r1" = trunc i64 %"R21:R20_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 18
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R21:R20_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R21:R20_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R21:R20_r0.1" = trunc i64 %"imad.9" to i32
  %"R21:R20_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R21:R20_r1.1" = trunc i64 %"R21:R20_r1_shift.1" to i32
  %"ldg_addr_r0_ext.1" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R110:R106_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R110:R106_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R110:R106_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R110:R106_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R110:R106_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R110:R106_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R110:R106_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R110:R106_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".96" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".96" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".97" = xor i32 %"imad.10", -1
  %".98" = xor i32 65011712, -1
  %".99" = xor i32 0, -1
  %".100" = and i32 %"imad.10", 65011712
  %".101" = and i32 %".100", %".99"
  %".102" = and i32 %"imad.10", 65011712
  %".103" = and i32 %".102", 0
  %".104" = or i32 %".101", %".103"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".104"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R110:R106_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R110:R106_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R110:R106_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R110:R106_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R110:R106_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R110:R106_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R110:R106_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R110:R106_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.15"
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.10", 1082130432
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 1082130432
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", 1082130432
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.13", 1082130432
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.14", 1082130432
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.15", 1082130432
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.11", i32 %"imad.12", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15")
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.16", 1082130432
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.17", 1082130432
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.18", 1082130432
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.19", 1082130432
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.20", 1082130432
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.21", 1082130432
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.22", 1082130432
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.11", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"imad.16", i32 %"imad.17", i32 %"imad.18", i32 %"imad.19")
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.23", 1082130432
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.11", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"imad.20", i32 %"imad.21", i32 %"imad.22", i32 %"imad.23")
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.24", 1082130432
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.25", 1082130432
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.11", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"imad.24", i32 %"imad.25", i32 %"imad.26", i32 %"imad.27")
  %"sttm_memaddr_offset_add.5" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.5", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.6" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.6", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0800"
BB_0800:
  %"cond_trunc.6" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_09a0", label %"BB_0810"
BB_0810:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".118" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".118" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".119" = zext i32 0 to i64
  %".120" = zext i32 %".16" to i64
  %".121" = shl i64 %".120", 32
  %"shf_concat.4" = or i64 %".119", %".121"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".122" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".122", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".123" = xor i32 %"plop3_a_bit", 1
  %".124" = xor i32 %"plop3_b_bit", 1
  %".125" = xor i32 %"plop3_c_bit", 1
  %".126" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".127" = and i32 %".126", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".127", 0
  %"P9_to_i32" = zext i1 %"plop3_pred" to i32
  %".128" = xor i32 %"shf_result.4", -1
  %".129" = xor i32 16376, -1
  %".130" = xor i32 0, -1
  %".131" = and i32 %"shf_result.4", 16376
  %".132" = and i32 %".131", %".130"
  %".133" = and i32 %"shf_result.4", 16376
  %".134" = and i32 %".133", 0
  %".135" = or i32 %".132", %".134"
  %".136" = xor i32 %".135", -1
  %".137" = xor i32 524288, -1
  %".138" = xor i32 0, -1
  %".139" = and i32 %".136", 524288
  %".140" = and i32 %".139", %".138"
  %".141" = and i32 %".136", 524288
  %".142" = and i32 %".141", 0
  %".143" = or i32 %".140", %".142"
  %".144" = and i32 %".135", %".137"
  %".145" = and i32 %".144", %".138"
  %".146" = or i32 %".143", %".145"
  %".147" = and i32 %".135", %".137"
  %".148" = and i32 %".147", 0
  %".149" = or i32 %".146", %".148"
  %".150" = and i32 %".135", 524288
  %".151" = and i32 %".150", %".138"
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %".135", 524288
  %".154" = and i32 %".153", 0
  %".155" = or i32 %".152", %".154"
  %"iadd3_n1.2" = add i32 %"lds.1", 32
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.1", 16
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"lds.1", 20
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_08d0"
BB_08d0:
  %"phi.10" = phi  i32 [%"phi.9", %"BB_0810"], [%"P14_to_i32", %"BB_0900"]
  %"phi.11" = phi  i32 [%"P9_to_i32", %"BB_0810"], [%"phi.13", %"BB_0900"]
  %"cond_trunc.7" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_800008d0", label %"BB_08e0"
BB_800008d0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P11_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_08e0"
BB_08e0:
  %"phi.12" = phi  i32 [%"P11_to_i32", %"BB_800008d0"], [%"phi.10", %"BB_08d0"]
  %"mma_b_r0_ext" = zext i32 %".155" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".159" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".160" = sub i64 %".159", 0
  %".161" = lshr i64 %".160", 4
  %".162" = add i64 %"mma_b_packed_1", %".161"
  %".163" = and i64 %".162", 16383
  %".164" = and i64 %"mma_b_packed_1", -16384
  %".165" = or i64 %".164", %".163"
  %"mma_arg_zext" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.2", i64 %".165", i32 679740848, i32 %"mma_arg_zext", i32 %"iadd3_n2.3", i32 %"iadd3_n2.4")
  br label %"BB_08f0"
BB_08f0:
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"lop3_a_trunc" = trunc i32 %"phi.12" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".169" = xor i32 %"plop3_a_bit.1", 1
  %".170" = xor i32 %"plop3_b_bit.1", 1
  %".171" = xor i32 %"plop3_c_bit.1", 1
  %".172" = and i32 %".169", %"plop3_b_bit.1"
  %".173" = and i32 %".172", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".173", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0900"
BB_0900:
  %"phi.13" = phi  i32 [%"P25_to_i32", %"BB_800008f0"], [%"phi.11", %"BB_08f0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".175" = xor i32 %"plop3_a_bit.2", 1
  %".176" = xor i32 %"plop3_b_bit.2", 1
  %".177" = xor i32 %"plop3_c_bit.2", 1
  %".178" = and i32 %".175", %"plop3_b_bit.2"
  %".179" = and i32 %".178", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".179", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.13" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_08d0", label %"BB_0920"
BB_0920:
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".181" = xor i32 %"plop3_a_bit.3", 1
  %".182" = xor i32 %"plop3_b_bit.3", 1
  %".183" = xor i32 %"plop3_c_bit.3", 1
  %".184" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".185" = and i32 %".184", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".185", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".186" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".187" = zext i32 %"iadd3_n2.5" to i64
  %".188" = zext i32 24 to i64
  %".189" = shl i64 %".186", %".188"
  %".190" = and i64 %".189", 4294967295
  %".191" = add i64 %".190", %".187"
  %".192" = trunc i64 %".191" to i32
  br label %"BB_0950"
BB_0950:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_0920"], [%"P4_to_i32", %"BB_0980"]
  %"phi.15" = phi  i32 [%"P27_to_i32", %"BB_0920"], [%"phi.17", %"BB_0980"]
  %"cond_trunc.9" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000950", label %"BB_0960"
BB_80000950:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P35_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0960"
BB_0960:
  %"phi.16" = phi  i32 [%"P35_to_i32", %"BB_80000950"], [%"phi.14", %"BB_0950"]
  %"utcbar_local_winoff" = and i32 %".192", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".197" = ptrtoint i8 addrspace(3)* %".196" to i32
  %".198" = lshr i32 %".192", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".197", i32 %".198")
  br label %"BB_0970"
BB_0970:
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000970", label %"BB_0980"
BB_80000970:
  %"lop3_a_trunc.1" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".202" = xor i32 %"plop3_a_bit.4", 1
  %".203" = xor i32 %"plop3_b_bit.4", 1
  %".204" = xor i32 %"plop3_c_bit.4", 1
  %".205" = and i32 %".202", %"plop3_b_bit.4"
  %".206" = and i32 %".205", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".206", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0980"
BB_0980:
  %"phi.17" = phi  i32 [%"P29_to_i32", %"BB_80000970"], [%"phi.15", %"BB_0970"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".208" = xor i32 %"plop3_a_bit.5", 1
  %".209" = xor i32 %"plop3_b_bit.5", 1
  %".210" = xor i32 %"plop3_c_bit.5", 1
  %".211" = and i32 %".208", %"plop3_b_bit.5"
  %".212" = and i32 %".211", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".212", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0950", label %"BB_09a0"
BB_09a0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 1024
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %".214" = zext i32 0 to i64
  %".215" = zext i32 0 to i64
  %".216" = shl i64 %".215", 32
  %"shf_concat.5" = or i64 %".214", %".216"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".217" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".217" to i32
  %".218" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".219" = zext i32 %"iadd3_n2.6" to i64
  %".220" = zext i32 24 to i64
  %".221" = shl i64 %".218", %".220"
  %".222" = and i64 %".221", 4294967295
  %".223" = add i64 %".222", %".219"
  %".224" = trunc i64 %".223" to i32
  %"mbar_shared_winoff.1" = and i32 %".224", 16777215
  %".225" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".225" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P3_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a10"
BB_0a10:
  %"cond_trunc.11" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0eb0", label %"BB_0a20"
BB_0eb0:
  %"mbar_shared_winoff.2" = and i32 %".224", 16777215
  %".228" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".228" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P20_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0ec0"
BB_0ec0:
  %"cond_trunc.12" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0eb0", label %"BB_0a20"
BB_0a20:
  %".231" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".232" = bitcast i8* %".231" to i64*
  %"ldc_const.2" = load i64, i64* %".232"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.26" = mul i32 %"tid_x", 16
  %"imad.28" = add i32 %"imad_tmp.26", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".233" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".234" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".235" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".236" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".237" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".238" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".239" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".240" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.28" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.29" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0" = trunc i64 %"imad.29" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.29", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R132:R122_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".233", i32 addrspace(1)* %"R132:R122_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R132:R122_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".234", i32 addrspace(1)* %"R132:R122_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R132:R122_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".235", i32 addrspace(1)* %"R132:R122_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R132:R122_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".236", i32 addrspace(1)* %"R132:R122_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R132:R122_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".237", i32 addrspace(1)* %"R132:R122_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".246" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".247" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".248" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".249" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R132:R122_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".238", i32 addrspace(1)* %"R132:R122_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R132:R122_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".239", i32 addrspace(1)* %"R132:R122_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R132:R122_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".240", i32 addrspace(1)* %"R132:R122_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".253" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".254" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".255" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".256" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R132:R122_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".246", i32 addrspace(1)* %"R132:R122_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R132:R122_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".247", i32 addrspace(1)* %"R132:R122_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R132:R122_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".248", i32 addrspace(1)* %"R132:R122_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R132:R122_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".249", i32 addrspace(1)* %"R132:R122_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R132:R122_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".253", i32 addrspace(1)* %"R132:R122_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R132:R122_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".254", i32 addrspace(1)* %"R132:R122_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R132:R122_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".255", i32 addrspace(1)* %"R132:R122_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R132:R122_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".256", i32 addrspace(1)* %"R132:R122_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c10"
BB_0c10:
  %"cond_trunc.13" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000c10", label %"BB_0c20"
BB_0c20:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".267" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".267" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.27", 3
  %".268" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".269" = zext i32 64 to i64
  %".270" = zext i32 24 to i64
  %".271" = shl i64 %".268", %".270"
  %".272" = and i64 %".271", 4294967295
  %".273" = add i64 %".272", %".269"
  %".274" = trunc i64 %".273" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".274", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".275" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".275" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".276" = xor i32 %"lds.2", -1
  %".277" = xor i32 65535, -1
  %".278" = xor i32 0, -1
  %".279" = and i32 %"lds.2", 65535
  %".280" = and i32 %".279", %".278"
  %".281" = and i32 %"lds.2", 65535
  %".282" = and i32 %".281", 0
  %".283" = or i32 %".280", %".282"
  %".284" = zext i32 0 to i64
  %".285" = zext i32 %".283" to i64
  %".286" = shl i64 %".285", 32
  %"shf_concat.6" = or i64 %".284", %".286"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".287" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.1" = lshr i64 %".287", 32
  %"shf_result.6" = trunc i64 %"shf_hi.1" to i32
  %".288" = zext i32 %"imad.30" to i64
  %".289" = zext i32 0 to i64
  %".290" = shl i64 %".289", 32
  %"shf_concat.7" = or i64 %".288", %".290"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".291" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".291" to i32
  %".292" = xor i32 %"lds.3", -1
  %".293" = xor i32 %"shf_result.7", -1
  %".294" = xor i32 0, -1
  %".295" = and i32 %"lds.3", %"shf_result.7"
  %".296" = and i32 %".295", %".294"
  %".297" = and i32 %"lds.3", %"shf_result.7"
  %".298" = and i32 %".297", 0
  %".299" = or i32 %".296", %".298"
  %"isetrp_cmp1.4" = icmp ne i32 %".299", %"shf_result.7"
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"imad_tmp.28" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.28", 1
  %".300" = zext i32 %"imad.31" to i64
  %".301" = zext i32 0 to i64
  %".302" = shl i64 %".301", 32
  %"shf_concat.8" = or i64 %".300", %".302"
  %"shf_shift_64.8" = zext i32 %"shf_result.6" to i64
  %".303" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".303" to i32
  br label %"BB_0cf0"
BB_0cf0:
  %"cond_trunc.14" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0e80_0f10", label %"BB_0d00"
BB_0d00:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".274", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".306" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".306" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".307" = xor i32 %"lds.4", -1
  %".308" = xor i32 %"shf_result.8", -1
  %".309" = xor i32 0, -1
  %".310" = and i32 %"lds.4", %"shf_result.8"
  %".311" = and i32 %".310", %".309"
  %".312" = and i32 %"lds.4", %"shf_result.8"
  %".313" = and i32 %".312", 0
  %".314" = or i32 %".311", %".313"
  %"isetrp_cmp1.5" = icmp ne i32 %".314", %"shf_result.8"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0d30"
BB_0d30:
  %"cond_trunc.15" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0e50_0ee0", label %"BB_0d40"
BB_0d40:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".317" = xor i32 0, -1
  %".318" = xor i32 %"shf_result.8", -1
  %".319" = xor i32 0, -1
  %".320" = and i32 %".317", %".318"
  %".321" = and i32 %".320", %".319"
  %".322" = and i32 %".317", %".318"
  %".323" = and i32 %".322", 0
  %".324" = or i32 %".321", %".323"
  %".325" = and i32 0, %".318"
  %".326" = and i32 %".325", %".319"
  %".327" = or i32 %".324", %".326"
  %".328" = and i32 0, %".318"
  %".329" = and i32 %".328", 0
  %".330" = or i32 %".327", %".329"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".330", i32 %"redux_mask")
  %".331" = xor i32 0, -1
  %".332" = xor i32 %"shf_result.7", -1
  %".333" = xor i32 0, -1
  %".334" = and i32 %".331", %".332"
  %".335" = and i32 %".334", %".333"
  %".336" = and i32 %".331", %".332"
  %".337" = and i32 %".336", 0
  %".338" = or i32 %".335", %".337"
  %".339" = and i32 0, %".332"
  %".340" = and i32 %".339", %".333"
  %".341" = or i32 %".338", %".340"
  %".342" = and i32 0, %".332"
  %".343" = and i32 %".342", 0
  %".344" = or i32 %".341", %".343"
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.29", %".344"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.32", i32 %"redux_mask.1")
  %".345" = xor i32 %".344", -1
  %".346" = call i32 @"llvm.cttz.i32"(i32 %".345", i1 0)
  %".347" = shl i32 %".346", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".347") convergent
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.33" = add i32 %"imad_tmp.30", %"redux_sync_and"
  %"isetrp_cmp1.6" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.34" = add i32 %"imad_tmp.31", %"redux_sync_and.1"
  br label %"BB_0e10"
BB_0e10:
  %"cond_trunc.16" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000e10", label %"BB_0e90"
BB_80000e10:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".274", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".351" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".351" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.34" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".274", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".352" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".352" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.33" monotonic
  br label %"BB_0e90"
BB_0e50_0ee0:
  call void @"llvm.trap"()
  br label %"BB_0e90"
BB_0e80_0f10:
  call void @"llvm.trap"()
  br label %"BB_0e90"
BB_0e90:
  ret void
BB_80000c10:
  ret void
}

define void @"_Z13column_scaledIL4Case9EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P33_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0090"
BB_0090:
  %"cond_trunc" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0190", label %"BB_00a0"
BB_00a0:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"R5:R4_r0" = trunc i64 %"ldc_const" to i32
  %"R5:R4_r1_shift" = lshr i64 %"ldc_const", 32
  %"R5:R4_r1" = trunc i64 %"R5:R4_r1_shift" to i32
  %".21" = zext i32 %"tid_x" to i64
  %".22" = zext i32 %".16" to i64
  %".23" = zext i32 2 to i64
  %".24" = shl i64 %".21", %".23"
  %".25" = and i64 %".24", 4294967295
  %".26" = add i64 %".25", %".22"
  %".27" = trunc i64 %".26" to i32
  %"imad_addend_r0_ext" = zext i32 %"R5:R4_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R5:R4_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R5:R4_r0.1" = trunc i64 %"imad" to i32
  %"R5:R4_r1_shift.1" = lshr i64 %"imad", 32
  %"R5:R4_r1.1" = trunc i64 %"R5:R4_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R5:R4_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P30_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R5:R4_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P30_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"imad_with_cin", %"BB_00a0"], [%"imad_with_cin.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"iadd3_trunc", %"BB_00a0"], [%"iadd3_trunc.1", %"BB_0180"]
  %"phi.2" = phi  i32 [%"tid_x", %"BB_00a0"], [%"viadd", %"BB_0180"]
  %"phi.3" = phi  i32 [%".27", %"BB_00a0"], [%"viadd.1", %"BB_0180"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.1" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R7:R28_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R7:R28_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.2", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd" = add i32 %"phi.2", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.1" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P5_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi"
  %"imad_cin_trunc.1" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.3", 16777215
  %".29" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".29" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.3", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P31_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0100", label %"BB_0190"
BB_0190:
  %"phi.4" = phi  i32 [%"P33_to_i32", %"BB_0090"], [%"P5_to_i32", %"BB_0180"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P15_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  br label %"BB_01e0"
BB_01e0:
  %"cond_trunc.2" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_800001e0", label %"BB_0230"
BB_800001e0:
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %".35" = zext i32 %"iadd3_n2.1" to i64
  %".36" = zext i32 0 to i64
  %".37" = shl i64 %".36", 32
  %"shf_concat" = or i64 %".35", %".37"
  %"shf_shift_64" = zext i32 11 to i64
  %".38" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".38" to i32
  %".39" = zext i32 %"iadd3_n2.1" to i64
  %".40" = zext i32 0 to i64
  %".41" = shl i64 %".40", 32
  %"shf_concat.1" = or i64 %".39", %".41"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".42" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".42" to i32
  %".43" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".44" = zext i32 %"iadd3_n2" to i64
  %".45" = zext i32 24 to i64
  %".46" = shl i64 %".43", %".45"
  %".47" = and i64 %".46", 4294967295
  %".48" = add i64 %".47", %".44"
  %".49" = trunc i64 %".48" to i32
  br label %"BB_0230"
BB_0230:
  %"phi.5" = phi  i32 [%".49", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.6" = phi  i32 [%"shf_result", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.7" = phi  i32 [%"shf_result.1", %"BB_800001e0"], [1, %"BB_01e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P16_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0250"
BB_0250:
  %"cond_trunc.3" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000250", label %"BB_0260"
BB_80000250:
  %"mbar_shared_winoff" = and i32 %"phi.5", 16777215
  %".54" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".54" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.7" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.6" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".55" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".55" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0260"
BB_0260:
  %"cond_trunc.4" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0400", label %"BB_0270"
BB_0270:
  %"allocation_dst_memaddr_offset_add" = add i32 %".16", 1032
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".59" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".60" = ptrtoint i8 addrspace(3)* %".59" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".60", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P7_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.5" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0400", label %"BB_02a0"
BB_02a0:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 3
  %".64" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".65" = zext i32 64 to i64
  %".66" = zext i32 24 to i64
  %".67" = shl i64 %".64", %".66"
  %".68" = and i64 %".67", 4294967295
  %".69" = add i64 %".68", %".65"
  %".70" = trunc i64 %".69" to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".16", 1032
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".71" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".72" = bitcast i8 addrspace(3)* %".71" to i32 addrspace(3)*
  %".73" = load i32, i32 addrspace(3)* %".72"
  %".74" = lshr i32 %".73", 5
  %"P17_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".74"
  %"bra_cond_trunc" = trunc i32 %"P17_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_0390", label %"BB_0330"
BB_0330:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".16", 1032
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".76" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".77" = bitcast i8 addrspace(3)* %".76" to i32 addrspace(3)*
  %".78" = load i32, i32 addrspace(3)* %".77"
  %".79" = lshr i32 %".78", 5
  %"P18_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".79"
  %"bra_cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0330", label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%"imad.5", %"BB_02a0"], [%"imad.6", %"BB_0330"]
  %".81" = zext i32 %"imad.3" to i64
  %".82" = zext i32 0 to i64
  %".83" = shl i64 %".82", 32
  %"shf_concat.2" = or i64 %".81", %".83"
  %"shf_shift_64.2" = zext i32 %"phi.8" to i64
  %".84" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".84" to i32
  %".85" = zext i32 %"imad.4" to i64
  %".86" = zext i32 0 to i64
  %".87" = shl i64 %".86", 32
  %"shf_concat.3" = or i64 %".85", %".87"
  %"shf_shift_64.3" = zext i32 %"phi.8" to i64
  %".88" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".88" to i32
  %"imad_tmp.6" = mul i32 %"phi.8", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".70", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".89" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".89" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".70", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".91" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0400"
BB_0400:
  %"phi.9" = phi  i32 [%"P7_to_i32", %"BB_0390"], [%"P7_to_i32", %"BB_0290"], [%"phi.4", %"BB_0260"]
  %".94" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".95" = bitcast i8* %".94" to i64*
  %"ldc_const.1" = load i64, i64* %".95"
  %"R21:R20_r0" = trunc i64 %"ldc_const.1" to i32
  %"R21:R20_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R21:R20_r1" = trunc i64 %"R21:R20_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 18
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R21:R20_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R21:R20_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R21:R20_r0.1" = trunc i64 %"imad.9" to i32
  %"R21:R20_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R21:R20_r1.1" = trunc i64 %"R21:R20_r1_shift.1" to i32
  %"ldg_addr_r0_ext.1" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R110:R106_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R110:R106_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R110:R106_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R110:R106_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R110:R106_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R110:R106_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R110:R106_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R110:R106_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".96" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".96" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".97" = xor i32 %"imad.10", -1
  %".98" = xor i32 65011712, -1
  %".99" = xor i32 0, -1
  %".100" = and i32 %"imad.10", 65011712
  %".101" = and i32 %".100", %".99"
  %".102" = and i32 %"imad.10", 65011712
  %".103" = and i32 %".102", 0
  %".104" = or i32 %".101", %".103"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".104"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R110:R106_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R110:R106_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R110:R106_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R110:R106_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R110:R106_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R110:R106_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R110:R106_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R21:R20_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R21:R20_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R110:R106_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R110:R106_addr_ptr.15"
  %"imad_tmp.10" = mul i32 0, 0
  %"imad.12" = add i32 %"imad_tmp.10", 1082130432
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.13" = add i32 %"imad_tmp.11", 1082130432
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.12", 1082130432
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.13", 1082130432
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.14", 1082130432
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.15", 1082130432
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"imad.11", i32 %"imad.12", i32 %"imad.13", i32 %"imad.14", i32 %"imad.15")
  %"imad_tmp.16" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.16", 1082130432
  %"imad_tmp.17" = mul i32 0, 0
  %"imad.19" = add i32 %"imad_tmp.17", 1082130432
  %"imad_tmp.18" = mul i32 0, 0
  %"imad.20" = add i32 %"imad_tmp.18", 1082130432
  %"imad_tmp.19" = mul i32 0, 0
  %"imad.21" = add i32 %"imad_tmp.19", 1082130432
  %"imad_tmp.20" = mul i32 0, 0
  %"imad.22" = add i32 %"imad_tmp.20", 1082130432
  %"imad_tmp.21" = mul i32 0, 0
  %"imad.23" = add i32 %"imad_tmp.21", 1082130432
  %"imad_tmp.22" = mul i32 0, 0
  %"imad.24" = add i32 %"imad_tmp.22", 1082130432
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.11", 4
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"imad.16", i32 %"imad.17", i32 %"imad.18", i32 %"imad.19")
  %"imad_tmp.23" = mul i32 0, 0
  %"imad.25" = add i32 %"imad_tmp.23", 1082130432
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.11", 8
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"imad.20", i32 %"imad.21", i32 %"imad.22", i32 %"imad.23")
  %"imad_tmp.24" = mul i32 0, 0
  %"imad.26" = add i32 %"imad_tmp.24", 1082130432
  %"imad_tmp.25" = mul i32 0, 0
  %"imad.27" = add i32 %"imad_tmp.25", 1082130432
  %"sttm_memaddr_offset_add.4" = add i32 %"imad.11", 12
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.4", i32 %"imad.24", i32 %"imad.25", i32 %"imad.26", i32 %"imad.27")
  %"sttm_memaddr_offset_add.5" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.5", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.6" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.6", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0800"
BB_0800:
  %"cond_trunc.6" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_09a0", label %"BB_0810"
BB_0810:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".118" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".118" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".119" = zext i32 0 to i64
  %".120" = zext i32 %".16" to i64
  %".121" = shl i64 %".120", 32
  %"shf_concat.4" = or i64 %".119", %".121"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".122" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".122", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".123" = xor i32 %"plop3_a_bit", 1
  %".124" = xor i32 %"plop3_b_bit", 1
  %".125" = xor i32 %"plop3_c_bit", 1
  %".126" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".127" = and i32 %".126", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".127", 0
  %"P9_to_i32" = zext i1 %"plop3_pred" to i32
  %".128" = xor i32 %"shf_result.4", -1
  %".129" = xor i32 16376, -1
  %".130" = xor i32 0, -1
  %".131" = and i32 %"shf_result.4", 16376
  %".132" = and i32 %".131", %".130"
  %".133" = and i32 %"shf_result.4", 16376
  %".134" = and i32 %".133", 0
  %".135" = or i32 %".132", %".134"
  %".136" = xor i32 %".135", -1
  %".137" = xor i32 524288, -1
  %".138" = xor i32 0, -1
  %".139" = and i32 %".136", 524288
  %".140" = and i32 %".139", %".138"
  %".141" = and i32 %".136", 524288
  %".142" = and i32 %".141", 0
  %".143" = or i32 %".140", %".142"
  %".144" = and i32 %".135", %".137"
  %".145" = and i32 %".144", %".138"
  %".146" = or i32 %".143", %".145"
  %".147" = and i32 %".135", %".137"
  %".148" = and i32 %".147", 0
  %".149" = or i32 %".146", %".148"
  %".150" = and i32 %".135", 524288
  %".151" = and i32 %".150", %".138"
  %".152" = or i32 %".149", %".151"
  %".153" = and i32 %".135", 524288
  %".154" = and i32 %".153", 0
  %".155" = or i32 %".152", %".154"
  %"iadd3_n1.2" = add i32 %"lds.1", 32
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.1", 16
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"lds.1", 20
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_08d0"
BB_08d0:
  %"phi.10" = phi  i32 [%"phi.9", %"BB_0810"], [%"P14_to_i32", %"BB_0900"]
  %"phi.11" = phi  i32 [%"P9_to_i32", %"BB_0810"], [%"phi.13", %"BB_0900"]
  %"cond_trunc.7" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_800008d0", label %"BB_08e0"
BB_800008d0:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P11_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_08e0"
BB_08e0:
  %"phi.12" = phi  i32 [%"P11_to_i32", %"BB_800008d0"], [%"phi.10", %"BB_08d0"]
  %"mma_b_r0_ext" = zext i32 %".155" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".159" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".160" = sub i64 %".159", 0
  %".161" = lshr i64 %".160", 4
  %".162" = add i64 %"mma_b_packed_1", %".161"
  %".163" = and i64 %".162", 16383
  %".164" = and i64 %"mma_b_packed_1", -16384
  %".165" = or i64 %".164", %".163"
  %"mma_arg_zext" = zext i1 1 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.2", i64 %".165", i32 679742640, i32 %"mma_arg_zext", i32 %"iadd3_n2.3", i32 %"iadd3_n2.4")
  br label %"BB_08f0"
BB_08f0:
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_800008f0", label %"BB_0900"
BB_800008f0:
  %"lop3_a_trunc" = trunc i32 %"phi.12" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".169" = xor i32 %"plop3_a_bit.1", 1
  %".170" = xor i32 %"plop3_b_bit.1", 1
  %".171" = xor i32 %"plop3_c_bit.1", 1
  %".172" = and i32 %".169", %"plop3_b_bit.1"
  %".173" = and i32 %".172", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".173", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0900"
BB_0900:
  %"phi.13" = phi  i32 [%"P25_to_i32", %"BB_800008f0"], [%"phi.11", %"BB_08f0"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".175" = xor i32 %"plop3_a_bit.2", 1
  %".176" = xor i32 %"plop3_b_bit.2", 1
  %".177" = xor i32 %"plop3_c_bit.2", 1
  %".178" = and i32 %".175", %"plop3_b_bit.2"
  %".179" = and i32 %".178", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".179", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.13" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_08d0", label %"BB_0920"
BB_0920:
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".181" = xor i32 %"plop3_a_bit.3", 1
  %".182" = xor i32 %"plop3_b_bit.3", 1
  %".183" = xor i32 %"plop3_c_bit.3", 1
  %".184" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".185" = and i32 %".184", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".185", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".186" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".187" = zext i32 %"iadd3_n2.5" to i64
  %".188" = zext i32 24 to i64
  %".189" = shl i64 %".186", %".188"
  %".190" = and i64 %".189", 4294967295
  %".191" = add i64 %".190", %".187"
  %".192" = trunc i64 %".191" to i32
  br label %"BB_0950"
BB_0950:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_0920"], [%"P4_to_i32", %"BB_0980"]
  %"phi.15" = phi  i32 [%"P27_to_i32", %"BB_0920"], [%"phi.17", %"BB_0980"]
  %"cond_trunc.9" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_80000950", label %"BB_0960"
BB_80000950:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P35_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_0960"
BB_0960:
  %"phi.16" = phi  i32 [%"P35_to_i32", %"BB_80000950"], [%"phi.14", %"BB_0950"]
  %"utcbar_local_winoff" = and i32 %".192", 16777215
  %".196" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".197" = ptrtoint i8 addrspace(3)* %".196" to i32
  %".198" = lshr i32 %".192", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".197", i32 %".198")
  br label %"BB_0970"
BB_0970:
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_80000970", label %"BB_0980"
BB_80000970:
  %"lop3_a_trunc.1" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".202" = xor i32 %"plop3_a_bit.4", 1
  %".203" = xor i32 %"plop3_b_bit.4", 1
  %".204" = xor i32 %"plop3_c_bit.4", 1
  %".205" = and i32 %".202", %"plop3_b_bit.4"
  %".206" = and i32 %".205", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".206", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0980"
BB_0980:
  %"phi.17" = phi  i32 [%"P29_to_i32", %"BB_80000970"], [%"phi.15", %"BB_0970"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".208" = xor i32 %"plop3_a_bit.5", 1
  %".209" = xor i32 %"plop3_b_bit.5", 1
  %".210" = xor i32 %"plop3_c_bit.5", 1
  %".211" = and i32 %".208", %"plop3_b_bit.5"
  %".212" = and i32 %".211", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".212", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_0950", label %"BB_09a0"
BB_09a0:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 1024
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %".214" = zext i32 0 to i64
  %".215" = zext i32 0 to i64
  %".216" = shl i64 %".215", 32
  %"shf_concat.5" = or i64 %".214", %".216"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".217" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".217" to i32
  %".218" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".219" = zext i32 %"iadd3_n2.6" to i64
  %".220" = zext i32 24 to i64
  %".221" = shl i64 %".218", %".220"
  %".222" = and i64 %".221", 4294967295
  %".223" = add i64 %".222", %".219"
  %".224" = trunc i64 %".223" to i32
  %"mbar_shared_winoff.1" = and i32 %".224", 16777215
  %".225" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".225" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P3_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0a10"
BB_0a10:
  %"cond_trunc.11" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0eb0", label %"BB_0a20"
BB_0eb0:
  %"mbar_shared_winoff.2" = and i32 %".224", 16777215
  %".228" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".228" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P20_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0ec0"
BB_0ec0:
  %"cond_trunc.12" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0eb0", label %"BB_0a20"
BB_0a20:
  %".231" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".232" = bitcast i8* %".231" to i64*
  %"ldc_const.2" = load i64, i64* %".232"
  %"R13:R12_r0" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  %"imad_tmp.26" = mul i32 %"tid_x", 16
  %"imad.28" = add i32 %"imad_tmp.26", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".233" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".234" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".235" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".236" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".237" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".238" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".239" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".240" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.28" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.29" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R3:R2_r0" = trunc i64 %"imad.29" to i32
  %"R3:R2_r1_shift" = lshr i64 %"imad.29", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %"stg_addr_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R132:R122_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".233", i32 addrspace(1)* %"R132:R122_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R132:R122_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".234", i32 addrspace(1)* %"R132:R122_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R132:R122_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".235", i32 addrspace(1)* %"R132:R122_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R132:R122_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".236", i32 addrspace(1)* %"R132:R122_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R132:R122_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".237", i32 addrspace(1)* %"R132:R122_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".246" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".247" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".248" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".249" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R132:R122_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".238", i32 addrspace(1)* %"R132:R122_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R132:R122_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".239", i32 addrspace(1)* %"R132:R122_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R132:R122_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".240", i32 addrspace(1)* %"R132:R122_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".253" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".254" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".255" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".256" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R132:R122_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".246", i32 addrspace(1)* %"R132:R122_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R132:R122_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".247", i32 addrspace(1)* %"R132:R122_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R132:R122_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".248", i32 addrspace(1)* %"R132:R122_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R132:R122_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".249", i32 addrspace(1)* %"R132:R122_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R132:R122_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".253", i32 addrspace(1)* %"R132:R122_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R132:R122_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".254", i32 addrspace(1)* %"R132:R122_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R132:R122_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".255", i32 addrspace(1)* %"R132:R122_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R3:R2_r0" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R3:R2_r1" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R132:R122_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".256", i32 addrspace(1)* %"R132:R122_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0c10"
BB_0c10:
  %"cond_trunc.13" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000c10", label %"BB_0c20"
BB_0c20:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".267" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".267" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.27" = mul i32 0, 0
  %"imad.30" = add i32 %"imad_tmp.27", 3
  %".268" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".269" = zext i32 64 to i64
  %".270" = zext i32 24 to i64
  %".271" = shl i64 %".268", %".270"
  %".272" = and i64 %".271", 4294967295
  %".273" = add i64 %".272", %".269"
  %".274" = trunc i64 %".273" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".274", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".275" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".275" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".276" = xor i32 %"lds.2", -1
  %".277" = xor i32 65535, -1
  %".278" = xor i32 0, -1
  %".279" = and i32 %"lds.2", 65535
  %".280" = and i32 %".279", %".278"
  %".281" = and i32 %"lds.2", 65535
  %".282" = and i32 %".281", 0
  %".283" = or i32 %".280", %".282"
  %".284" = zext i32 0 to i64
  %".285" = zext i32 %".283" to i64
  %".286" = shl i64 %".285", 32
  %"shf_concat.6" = or i64 %".284", %".286"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".287" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.1" = lshr i64 %".287", 32
  %"shf_result.6" = trunc i64 %"shf_hi.1" to i32
  %".288" = zext i32 %"imad.30" to i64
  %".289" = zext i32 0 to i64
  %".290" = shl i64 %".289", 32
  %"shf_concat.7" = or i64 %".288", %".290"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".291" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".291" to i32
  %".292" = xor i32 %"lds.3", -1
  %".293" = xor i32 %"shf_result.7", -1
  %".294" = xor i32 0, -1
  %".295" = and i32 %"lds.3", %"shf_result.7"
  %".296" = and i32 %".295", %".294"
  %".297" = and i32 %"lds.3", %"shf_result.7"
  %".298" = and i32 %".297", 0
  %".299" = or i32 %".296", %".298"
  %"isetrp_cmp1.4" = icmp ne i32 %".299", %"shf_result.7"
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"imad_tmp.28" = mul i32 0, 0
  %"imad.31" = add i32 %"imad_tmp.28", 1
  %".300" = zext i32 %"imad.31" to i64
  %".301" = zext i32 0 to i64
  %".302" = shl i64 %".301", 32
  %"shf_concat.8" = or i64 %".300", %".302"
  %"shf_shift_64.8" = zext i32 %"shf_result.6" to i64
  %".303" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".303" to i32
  br label %"BB_0cf0"
BB_0cf0:
  %"cond_trunc.14" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0e80_0f10", label %"BB_0d00"
BB_0d00:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".274", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".306" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".306" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".307" = xor i32 %"lds.4", -1
  %".308" = xor i32 %"shf_result.8", -1
  %".309" = xor i32 0, -1
  %".310" = and i32 %"lds.4", %"shf_result.8"
  %".311" = and i32 %".310", %".309"
  %".312" = and i32 %"lds.4", %"shf_result.8"
  %".313" = and i32 %".312", 0
  %".314" = or i32 %".311", %".313"
  %"isetrp_cmp1.5" = icmp ne i32 %".314", %"shf_result.8"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0d30"
BB_0d30:
  %"cond_trunc.15" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0e50_0ee0", label %"BB_0d40"
BB_0d40:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".317" = xor i32 0, -1
  %".318" = xor i32 %"shf_result.8", -1
  %".319" = xor i32 0, -1
  %".320" = and i32 %".317", %".318"
  %".321" = and i32 %".320", %".319"
  %".322" = and i32 %".317", %".318"
  %".323" = and i32 %".322", 0
  %".324" = or i32 %".321", %".323"
  %".325" = and i32 0, %".318"
  %".326" = and i32 %".325", %".319"
  %".327" = or i32 %".324", %".326"
  %".328" = and i32 0, %".318"
  %".329" = and i32 %".328", 0
  %".330" = or i32 %".327", %".329"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".330", i32 %"redux_mask")
  %".331" = xor i32 0, -1
  %".332" = xor i32 %"shf_result.7", -1
  %".333" = xor i32 0, -1
  %".334" = and i32 %".331", %".332"
  %".335" = and i32 %".334", %".333"
  %".336" = and i32 %".331", %".332"
  %".337" = and i32 %".336", 0
  %".338" = or i32 %".335", %".337"
  %".339" = and i32 0, %".332"
  %".340" = and i32 %".339", %".333"
  %".341" = or i32 %".338", %".340"
  %".342" = and i32 0, %".332"
  %".343" = and i32 %".342", 0
  %".344" = or i32 %".341", %".343"
  %"imad_tmp.29" = mul i32 0, 0
  %"imad.32" = add i32 %"imad_tmp.29", %".344"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.32", i32 %"redux_mask.1")
  %".345" = xor i32 %".344", -1
  %".346" = call i32 @"llvm.cttz.i32"(i32 %".345", i1 0)
  %".347" = shl i32 %".346", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".347") convergent
  %"imad_tmp.30" = mul i32 0, 0
  %"imad.33" = add i32 %"imad_tmp.30", %"redux_sync_and"
  %"isetrp_cmp1.6" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.31" = mul i32 0, 0
  %"imad.34" = add i32 %"imad_tmp.31", %"redux_sync_and.1"
  br label %"BB_0e10"
BB_0e10:
  %"cond_trunc.16" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000e10", label %"BB_0e90"
BB_80000e10:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".274", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".351" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".351" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.34" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".274", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".352" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".352" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.33" monotonic
  br label %"BB_0e90"
BB_0e50_0ee0:
  call void @"llvm.trap"()
  br label %"BB_0e90"
BB_0e80_0f10:
  call void @"llvm.trap"()
  br label %"BB_0e90"
BB_0e90:
  ret void
BB_80000c10:
  ret void
}

define void @"_Z13column_scaledIL4Case8EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P33_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0090"
BB_0090:
  %"cond_trunc" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0190", label %"BB_00a0"
BB_00a0:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".21" = zext i32 %"tid_x" to i64
  %".22" = zext i32 %".16" to i64
  %".23" = zext i32 2 to i64
  %".24" = shl i64 %".21", %".23"
  %".25" = and i64 %".24", 4294967295
  %".26" = add i64 %".25", %".22"
  %".27" = trunc i64 %".26" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P30_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P30_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"imad_with_cin", %"BB_00a0"], [%"imad_with_cin.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"tid_x", %"BB_00a0"], [%"viadd", %"BB_0180"]
  %"phi.2" = phi  i32 [%".27", %"BB_00a0"], [%"viadd.1", %"BB_0180"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"BB_00a0"], [%"iadd3_trunc.1", %"BB_0180"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R51:R67_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R51:R67_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.1", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P5_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi"
  %"imad_cin_trunc.1" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".29" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".29" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P31_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0100", label %"BB_0190"
BB_0190:
  %"phi.4" = phi  i32 [%"P33_to_i32", %"BB_0090"], [%"P5_to_i32", %"BB_0180"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P15_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  br label %"BB_01e0"
BB_01e0:
  %"cond_trunc.2" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_800001e0", label %"BB_0230"
BB_800001e0:
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %".35" = zext i32 %"iadd3_n2.1" to i64
  %".36" = zext i32 0 to i64
  %".37" = shl i64 %".36", 32
  %"shf_concat" = or i64 %".35", %".37"
  %"shf_shift_64" = zext i32 11 to i64
  %".38" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".38" to i32
  %".39" = zext i32 %"iadd3_n2.1" to i64
  %".40" = zext i32 0 to i64
  %".41" = shl i64 %".40", 32
  %"shf_concat.1" = or i64 %".39", %".41"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".42" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".42" to i32
  %".43" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".44" = zext i32 %"iadd3_n2" to i64
  %".45" = zext i32 24 to i64
  %".46" = shl i64 %".43", %".45"
  %".47" = and i64 %".46", 4294967295
  %".48" = add i64 %".47", %".44"
  %".49" = trunc i64 %".48" to i32
  br label %"BB_0230"
BB_0230:
  %"phi.5" = phi  i32 [%".49", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.6" = phi  i32 [%"shf_result", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.7" = phi  i32 [%"shf_result.1", %"BB_800001e0"], [1, %"BB_01e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P16_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0250"
BB_0250:
  %"cond_trunc.3" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000250", label %"BB_0260"
BB_80000250:
  %"mbar_shared_winoff" = and i32 %"phi.5", 16777215
  %".54" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".54" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.7" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.6" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".55" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".55" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0260"
BB_0260:
  %"cond_trunc.4" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0400", label %"BB_0270"
BB_0270:
  %"allocation_dst_memaddr_offset_add" = add i32 %".16", 1032
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".59" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".60" = ptrtoint i8 addrspace(3)* %".59" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".60", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P7_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.5" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0400", label %"BB_02a0"
BB_02a0:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 3
  %".64" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".65" = zext i32 64 to i64
  %".66" = zext i32 24 to i64
  %".67" = shl i64 %".64", %".66"
  %".68" = and i64 %".67", 4294967295
  %".69" = add i64 %".68", %".65"
  %".70" = trunc i64 %".69" to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".16", 1032
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".71" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".72" = bitcast i8 addrspace(3)* %".71" to i32 addrspace(3)*
  %".73" = load i32, i32 addrspace(3)* %".72"
  %".74" = lshr i32 %".73", 5
  %"P17_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".74"
  %"bra_cond_trunc" = trunc i32 %"P17_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_0390", label %"BB_0330"
BB_0330:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".16", 1032
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".76" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".77" = bitcast i8 addrspace(3)* %".76" to i32 addrspace(3)*
  %".78" = load i32, i32 addrspace(3)* %".77"
  %".79" = lshr i32 %".78", 5
  %"P18_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".79"
  %"bra_cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0330", label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%"imad.5", %"BB_02a0"], [%"imad.6", %"BB_0330"]
  %".81" = zext i32 %"imad.3" to i64
  %".82" = zext i32 0 to i64
  %".83" = shl i64 %".82", 32
  %"shf_concat.2" = or i64 %".81", %".83"
  %"shf_shift_64.2" = zext i32 %"phi.8" to i64
  %".84" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".84" to i32
  %".85" = zext i32 %"imad.4" to i64
  %".86" = zext i32 0 to i64
  %".87" = shl i64 %".86", 32
  %"shf_concat.3" = or i64 %".85", %".87"
  %"shf_shift_64.3" = zext i32 %"phi.8" to i64
  %".88" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".88" to i32
  %"imad_tmp.6" = mul i32 %"phi.8", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".70", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".89" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".89" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".70", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".91" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0400"
BB_0400:
  %"phi.9" = phi  i32 [%"P7_to_i32", %"BB_0390"], [%"P7_to_i32", %"BB_0290"], [%"phi.4", %"BB_0260"]
  %".94" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".95" = bitcast i8* %".94" to i64*
  %"ldc_const.1" = load i64, i64* %".95"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 18
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.9" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R23:R118_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R23:R118_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R23:R118_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R23:R118_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R23:R118_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R23:R118_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R23:R118_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R23:R118_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".96" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".96" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".97" = xor i32 %"imad.10", -1
  %".98" = xor i32 65011712, -1
  %".99" = xor i32 0, -1
  %".100" = and i32 %"imad.10", 65011712
  %".101" = and i32 %".100", %".99"
  %".102" = and i32 %"imad.10", 65011712
  %".103" = and i32 %".102", 0
  %".104" = or i32 %".101", %".103"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".104"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R23:R118_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R23:R118_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R23:R118_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R23:R118_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R23:R118_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R23:R118_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R23:R118_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R23:R118_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0680"
BB_0680:
  %"cond_trunc.6" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0820", label %"BB_0690"
BB_0690:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".114" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".114" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".115" = zext i32 0 to i64
  %".116" = zext i32 %".16" to i64
  %".117" = shl i64 %".116", 32
  %"shf_concat.4" = or i64 %".115", %".117"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".118" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".118", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".119" = xor i32 %"plop3_a_bit", 1
  %".120" = xor i32 %"plop3_b_bit", 1
  %".121" = xor i32 %"plop3_c_bit", 1
  %".122" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".123" = and i32 %".122", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".123", 0
  %"P9_to_i32" = zext i1 %"plop3_pred" to i32
  %".124" = xor i32 %"shf_result.4", -1
  %".125" = xor i32 16376, -1
  %".126" = xor i32 0, -1
  %".127" = and i32 %"shf_result.4", 16376
  %".128" = and i32 %".127", %".126"
  %".129" = and i32 %"shf_result.4", 16376
  %".130" = and i32 %".129", 0
  %".131" = or i32 %".128", %".130"
  %".132" = xor i32 %".131", -1
  %".133" = xor i32 524288, -1
  %".134" = xor i32 0, -1
  %".135" = and i32 %".132", 524288
  %".136" = and i32 %".135", %".134"
  %".137" = and i32 %".132", 524288
  %".138" = and i32 %".137", 0
  %".139" = or i32 %".136", %".138"
  %".140" = and i32 %".131", %".133"
  %".141" = and i32 %".140", %".134"
  %".142" = or i32 %".139", %".141"
  %".143" = and i32 %".131", %".133"
  %".144" = and i32 %".143", 0
  %".145" = or i32 %".142", %".144"
  %".146" = and i32 %".131", 524288
  %".147" = and i32 %".146", %".134"
  %".148" = or i32 %".145", %".147"
  %".149" = and i32 %".131", 524288
  %".150" = and i32 %".149", 0
  %".151" = or i32 %".148", %".150"
  %"iadd3_n1.2" = add i32 %"lds.1", 32
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.1", 16
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"lds.1", 20
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_0750"
BB_0750:
  %"phi.10" = phi  i32 [%"phi.9", %"BB_0690"], [%"P14_to_i32", %"BB_0780"]
  %"phi.11" = phi  i32 [%"P9_to_i32", %"BB_0690"], [%"phi.13", %"BB_0780"]
  %"cond_trunc.7" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_80000750", label %"BB_0760"
BB_80000750:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P11_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0760"
BB_0760:
  %"phi.12" = phi  i32 [%"P11_to_i32", %"BB_80000750"], [%"phi.10", %"BB_0750"]
  %"mma_b_r0_ext" = zext i32 %".151" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".155" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".156" = sub i64 %".155", 0
  %".157" = lshr i64 %".156", 4
  %".158" = add i64 %"mma_b_packed_1", %".157"
  %".159" = and i64 %".158", 16383
  %".160" = and i64 %"mma_b_packed_1", -16384
  %".161" = or i64 %".160", %".159"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.2", i64 %".161", i32 679740464, i32 %"mma_arg_zext", i32 %"iadd3_n2.3", i32 %"iadd3_n2.4")
  br label %"BB_0770"
BB_0770:
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000770", label %"BB_0780"
BB_80000770:
  %"lop3_a_trunc" = trunc i32 %"phi.12" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".165" = xor i32 %"plop3_a_bit.1", 1
  %".166" = xor i32 %"plop3_b_bit.1", 1
  %".167" = xor i32 %"plop3_c_bit.1", 1
  %".168" = and i32 %".165", %"plop3_b_bit.1"
  %".169" = and i32 %".168", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".169", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0780"
BB_0780:
  %"phi.13" = phi  i32 [%"P25_to_i32", %"BB_80000770"], [%"phi.11", %"BB_0770"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".171" = xor i32 %"plop3_a_bit.2", 1
  %".172" = xor i32 %"plop3_b_bit.2", 1
  %".173" = xor i32 %"plop3_c_bit.2", 1
  %".174" = and i32 %".171", %"plop3_b_bit.2"
  %".175" = and i32 %".174", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".175", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.13" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0750", label %"BB_07a0"
BB_07a0:
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".177" = xor i32 %"plop3_a_bit.3", 1
  %".178" = xor i32 %"plop3_b_bit.3", 1
  %".179" = xor i32 %"plop3_c_bit.3", 1
  %".180" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".181" = and i32 %".180", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".181", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".182" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".183" = zext i32 %"iadd3_n2.5" to i64
  %".184" = zext i32 24 to i64
  %".185" = shl i64 %".182", %".184"
  %".186" = and i64 %".185", 4294967295
  %".187" = add i64 %".186", %".183"
  %".188" = trunc i64 %".187" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_07a0"], [%"P4_to_i32", %"BB_0800"]
  %"phi.15" = phi  i32 [%"P27_to_i32", %"BB_07a0"], [%"phi.17", %"BB_0800"]
  %"cond_trunc.9" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800007d0", label %"BB_07e0"
BB_800007d0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P35_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_07e0"
BB_07e0:
  %"phi.16" = phi  i32 [%"P35_to_i32", %"BB_800007d0"], [%"phi.14", %"BB_07d0"]
  %"utcbar_local_winoff" = and i32 %".188", 16777215
  %".192" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".193" = ptrtoint i8 addrspace(3)* %".192" to i32
  %".194" = lshr i32 %".188", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".193", i32 %".194")
  br label %"BB_07f0"
BB_07f0:
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_800007f0", label %"BB_0800"
BB_800007f0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".198" = xor i32 %"plop3_a_bit.4", 1
  %".199" = xor i32 %"plop3_b_bit.4", 1
  %".200" = xor i32 %"plop3_c_bit.4", 1
  %".201" = and i32 %".198", %"plop3_b_bit.4"
  %".202" = and i32 %".201", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".202", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0800"
BB_0800:
  %"phi.17" = phi  i32 [%"P29_to_i32", %"BB_800007f0"], [%"phi.15", %"BB_07f0"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".204" = xor i32 %"plop3_a_bit.5", 1
  %".205" = xor i32 %"plop3_b_bit.5", 1
  %".206" = xor i32 %"plop3_c_bit.5", 1
  %".207" = and i32 %".204", %"plop3_b_bit.5"
  %".208" = and i32 %".207", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".208", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_07d0", label %"BB_0820"
BB_0820:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 1024
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %".210" = zext i32 0 to i64
  %".211" = zext i32 0 to i64
  %".212" = shl i64 %".211", 32
  %"shf_concat.5" = or i64 %".210", %".212"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".213" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".213" to i32
  %".214" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".215" = zext i32 %"iadd3_n2.6" to i64
  %".216" = zext i32 24 to i64
  %".217" = shl i64 %".214", %".216"
  %".218" = and i64 %".217", 4294967295
  %".219" = add i64 %".218", %".215"
  %".220" = trunc i64 %".219" to i32
  %"mbar_shared_winoff.1" = and i32 %".220", 16777215
  %".221" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".221" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P3_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.11" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0d30", label %"BB_08a0"
BB_0d30:
  %"mbar_shared_winoff.2" = and i32 %".220", 16777215
  %".224" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".224" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P20_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0d40"
BB_0d40:
  %"cond_trunc.12" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0d30", label %"BB_08a0"
BB_08a0:
  %".227" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".228" = bitcast i8* %".227" to i64*
  %"ldc_const.2" = load i64, i64* %".228"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".229" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".230" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".231" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".232" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".233" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".234" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".235" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".236" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.13" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R59:R3_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".229", i32 addrspace(1)* %"R59:R3_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R59:R3_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".230", i32 addrspace(1)* %"R59:R3_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R59:R3_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".231", i32 addrspace(1)* %"R59:R3_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R59:R3_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".232", i32 addrspace(1)* %"R59:R3_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R59:R3_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".233", i32 addrspace(1)* %"R59:R3_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".242" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".243" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".244" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".245" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R59:R3_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".234", i32 addrspace(1)* %"R59:R3_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R59:R3_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".235", i32 addrspace(1)* %"R59:R3_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R59:R3_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".236", i32 addrspace(1)* %"R59:R3_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".249" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".250" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".251" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".252" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R59:R3_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".242", i32 addrspace(1)* %"R59:R3_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R59:R3_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".243", i32 addrspace(1)* %"R59:R3_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R59:R3_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".244", i32 addrspace(1)* %"R59:R3_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R59:R3_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".245", i32 addrspace(1)* %"R59:R3_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R59:R3_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".249", i32 addrspace(1)* %"R59:R3_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R59:R3_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".250", i32 addrspace(1)* %"R59:R3_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R59:R3_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".251", i32 addrspace(1)* %"R59:R3_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R59:R3_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".252", i32 addrspace(1)* %"R59:R3_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0a90"
BB_0a90:
  %"cond_trunc.13" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000a90", label %"BB_0aa0"
BB_0aa0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".263" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".263" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 3
  %".264" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".265" = zext i32 64 to i64
  %".266" = zext i32 24 to i64
  %".267" = shl i64 %".264", %".266"
  %".268" = and i64 %".267", 4294967295
  %".269" = add i64 %".268", %".265"
  %".270" = trunc i64 %".269" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".270", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".271" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".271" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".272" = xor i32 %"lds.2", -1
  %".273" = xor i32 65535, -1
  %".274" = xor i32 0, -1
  %".275" = and i32 %"lds.2", 65535
  %".276" = and i32 %".275", %".274"
  %".277" = and i32 %"lds.2", 65535
  %".278" = and i32 %".277", 0
  %".279" = or i32 %".276", %".278"
  %".280" = zext i32 0 to i64
  %".281" = zext i32 %".279" to i64
  %".282" = shl i64 %".281", 32
  %"shf_concat.6" = or i64 %".280", %".282"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".283" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.1" = lshr i64 %".283", 32
  %"shf_result.6" = trunc i64 %"shf_hi.1" to i32
  %".284" = zext i32 %"imad.14" to i64
  %".285" = zext i32 0 to i64
  %".286" = shl i64 %".285", 32
  %"shf_concat.7" = or i64 %".284", %".286"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".287" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".287" to i32
  %".288" = xor i32 %"lds.3", -1
  %".289" = xor i32 %"shf_result.7", -1
  %".290" = xor i32 0, -1
  %".291" = and i32 %"lds.3", %"shf_result.7"
  %".292" = and i32 %".291", %".290"
  %".293" = and i32 %"lds.3", %"shf_result.7"
  %".294" = and i32 %".293", 0
  %".295" = or i32 %".292", %".294"
  %"isetrp_cmp1.4" = icmp ne i32 %".295", %"shf_result.7"
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".296" = zext i32 %"imad.15" to i64
  %".297" = zext i32 0 to i64
  %".298" = shl i64 %".297", 32
  %"shf_concat.8" = or i64 %".296", %".298"
  %"shf_shift_64.8" = zext i32 %"shf_result.6" to i64
  %".299" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".299" to i32
  br label %"BB_0b70"
BB_0b70:
  %"cond_trunc.14" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0d00_0d90", label %"BB_0b80"
BB_0b80:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".270", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".302" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".302" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".303" = xor i32 %"lds.4", -1
  %".304" = xor i32 %"shf_result.8", -1
  %".305" = xor i32 0, -1
  %".306" = and i32 %"lds.4", %"shf_result.8"
  %".307" = and i32 %".306", %".305"
  %".308" = and i32 %"lds.4", %"shf_result.8"
  %".309" = and i32 %".308", 0
  %".310" = or i32 %".307", %".309"
  %"isetrp_cmp1.5" = icmp ne i32 %".310", %"shf_result.8"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0bb0"
BB_0bb0:
  %"cond_trunc.15" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0cd0_0d60", label %"BB_0bc0"
BB_0bc0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".313" = xor i32 0, -1
  %".314" = xor i32 %"shf_result.8", -1
  %".315" = xor i32 0, -1
  %".316" = and i32 %".313", %".314"
  %".317" = and i32 %".316", %".315"
  %".318" = and i32 %".313", %".314"
  %".319" = and i32 %".318", 0
  %".320" = or i32 %".317", %".319"
  %".321" = and i32 0, %".314"
  %".322" = and i32 %".321", %".315"
  %".323" = or i32 %".320", %".322"
  %".324" = and i32 0, %".314"
  %".325" = and i32 %".324", 0
  %".326" = or i32 %".323", %".325"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".326", i32 %"redux_mask")
  %".327" = xor i32 0, -1
  %".328" = xor i32 %"shf_result.7", -1
  %".329" = xor i32 0, -1
  %".330" = and i32 %".327", %".328"
  %".331" = and i32 %".330", %".329"
  %".332" = and i32 %".327", %".328"
  %".333" = and i32 %".332", 0
  %".334" = or i32 %".331", %".333"
  %".335" = and i32 0, %".328"
  %".336" = and i32 %".335", %".329"
  %".337" = or i32 %".334", %".336"
  %".338" = and i32 0, %".328"
  %".339" = and i32 %".338", 0
  %".340" = or i32 %".337", %".339"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".340"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask.1")
  %".341" = xor i32 %".340", -1
  %".342" = call i32 @"llvm.cttz.i32"(i32 %".341", i1 0)
  %".343" = shl i32 %".342", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".343") convergent
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  %"isetrp_cmp1.6" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and.1"
  br label %"BB_0c90"
BB_0c90:
  %"cond_trunc.16" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000c90", label %"BB_0d10"
BB_80000c90:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".270", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".347" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".347" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.18" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".270", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".348" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".348" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.17" monotonic
  br label %"BB_0d10"
BB_0cd0_0d60:
  call void @"llvm.trap"()
  br label %"BB_0d10"
BB_0d00_0d90:
  call void @"llvm.trap"()
  br label %"BB_0d10"
BB_0d10:
  ret void
BB_80000a90:
  ret void
}

define void @"_Z13column_scaledIL4Case7EEvPKjPj"(i64 %"arg_896", i64 %"arg_904")
{
EntryBB_0000:
  %"local_mem" = alloca [32768 x i8], align 16
  %"param_local" = alloca [912 x i8], align 16
  %".4" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".5" = bitcast i8* %".4" to i64*
  store i64 %"arg_896", i64* %".5", align 128
  %".7" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".8" = bitcast i8* %".7" to i64*
  store i64 %"arg_904", i64* %".8", align 8
  %"P33_to_i32" = zext i1 0 to i32
  %"tid_x" = call i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()
  %"s2ur_cluster_ctarank" = call i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()
  %".10" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".11" = zext i32 1024 to i64
  %".12" = zext i32 24 to i64
  %".13" = shl i64 %".10", %".12"
  %".14" = and i64 %".13", 4294967295
  %".15" = add i64 %".14", %".11"
  %".16" = trunc i64 %".15" to i32
  %"isetrp_cmp1" = icmp ugt i32 %"tid_x", 255
  %"isetrp_src_to_i32" = zext i1 1 to i32
  %"isetrp_src_to_i1" = icmp ne i32 %"isetrp_src_to_i32", 0
  %"isetrp_cmp2" = and i1 %"isetrp_cmp1", %"isetrp_src_to_i1"
  %"P23_to_i32" = zext i1 %"isetrp_cmp2" to i32
  %"isetrp_cmp1.1" = icmp ne i32 %"tid_x", 0
  %"isetrp_src_to_i32.1" = zext i1 1 to i32
  %"isetrp_src_to_i1.1" = icmp ne i32 %"isetrp_src_to_i32.1", 0
  %"isetrp_cmp2.1" = and i1 %"isetrp_cmp1.1", %"isetrp_src_to_i1.1"
  %"P1_to_i32" = zext i1 %"isetrp_cmp2.1" to i32
  br label %"BB_0090"
BB_0090:
  %"cond_trunc" = trunc i32 %"P23_to_i32" to i1
  %"pbra_cond_to_i32" = zext i1 %"cond_trunc" to i32
  %"pbra_cond_to_i1" = icmp ne i32 %"pbra_cond_to_i32", 0
  br i1 %"pbra_cond_to_i1", label %"BB_0190", label %"BB_00a0"
BB_00a0:
  %".19" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".20" = bitcast i8* %".19" to i64*
  %"ldc_const" = load i64, i64* %".20"
  %"R3:R2_r0" = trunc i64 %"ldc_const" to i32
  %"R3:R2_r1_shift" = lshr i64 %"ldc_const", 32
  %"R3:R2_r1" = trunc i64 %"R3:R2_r1_shift" to i32
  %".21" = zext i32 %"tid_x" to i64
  %".22" = zext i32 %".16" to i64
  %".23" = zext i32 2 to i64
  %".24" = shl i64 %".21", %".23"
  %".25" = and i64 %".24", 4294967295
  %".26" = add i64 %".25", %".22"
  %".27" = trunc i64 %".26" to i32
  %"imad_addend_r0_ext" = zext i32 %"R3:R2_r0" to i64
  %"imad_addend_packed_0" = or i64 0, %"imad_addend_r0_ext"
  %"imad_addend_r1_ext" = zext i32 %"R3:R2_r1" to i64
  %"imad_addend_r1_shift" = shl i64 %"imad_addend_r1_ext", 32
  %"imad_addend_packed_1" = or i64 %"imad_addend_packed_0", %"imad_addend_r1_shift"
  %"imad_lhs_64" = zext i32 %"tid_x" to i64
  %"imad_rhs_64" = zext i32 4 to i64
  %"imad_tmp_64" = mul i64 %"imad_lhs_64", %"imad_rhs_64"
  %"imad" = add i64 %"imad_tmp_64", %"imad_addend_packed_1"
  %"R3:R2_r0.1" = trunc i64 %"imad" to i32
  %"R3:R2_r1_shift.1" = lshr i64 %"imad", 32
  %"R3:R2_r1.1" = trunc i64 %"R3:R2_r1_shift.1" to i32
  %"iadd3_o1_64" = zext i32 %"R3:R2_r0.1" to i64
  %"iadd3_o2_64" = zext i32 8192 to i64
  %"iadd3_o3_64" = zext i32 0 to i64
  %"iadd3_tmp" = add i64 %"iadd3_o1_64", %"iadd3_o2_64"
  %"iadd3_tmp2" = add i64 %"iadd3_tmp", %"iadd3_o3_64"
  %"iadd3_trunc" = trunc i64 %"iadd3_tmp2" to i32
  %"iadd3_carry_val" = lshr i64 %"iadd3_tmp2", 32
  %"carry_ge_1" = icmp uge i64 %"iadd3_carry_val", 1
  %"P30_to_i32" = zext i1 %"carry_ge_1" to i32
  %"carry_ge_2" = icmp uge i64 %"iadd3_carry_val", 2
  %"imad_tmp" = mul i32 0, 0
  %"imad.1" = add i32 %"imad_tmp", %"R3:R2_r1.1"
  %"imad_cin_trunc" = trunc i32 %"P30_to_i32" to i1
  %"imad_cin_ext" = zext i1 %"imad_cin_trunc" to i32
  %"imad_with_cin" = add i32 %"imad.1", %"imad_cin_ext"
  br label %"BB_0100"
BB_0100:
  %"phi" = phi  i32 [%"imad_with_cin", %"BB_00a0"], [%"imad_with_cin.1", %"BB_0180"]
  %"phi.1" = phi  i32 [%"tid_x", %"BB_00a0"], [%"viadd", %"BB_0180"]
  %"phi.2" = phi  i32 [%".27", %"BB_00a0"], [%"viadd.1", %"BB_0180"]
  %"phi.3" = phi  i32 [%"iadd3_trunc", %"BB_00a0"], [%"iadd3_trunc.1", %"BB_0180"]
  %"ldg_addr_r0_ext" = zext i32 %"phi.3" to i64
  %"ldg_addr_packed_0" = or i64 0, %"ldg_addr_r0_ext"
  %"ldg_addr_r1_ext" = zext i32 %"phi" to i64
  %"ldg_addr_r1_shift" = shl i64 %"ldg_addr_r1_ext", 32
  %"ldg_addr_packed_1" = or i64 %"ldg_addr_packed_0", %"ldg_addr_r1_shift"
  %"R51:R67_addr_ptr" = inttoptr i64 %"ldg_addr_packed_1" to i32 addrspace(1)*
  %"ldg" = load i32, i32 addrspace(1)* %"R51:R67_addr_ptr"
  %"isetrp_cmp1.2" = icmp uge i32 %"phi.1", 128
  %"isetrp_src_to_i32.2" = zext i1 1 to i32
  %"isetrp_src_to_i1.2" = icmp ne i32 %"isetrp_src_to_i32.2", 0
  %"isetrp_cmp2.2" = and i1 %"isetrp_cmp1.2", %"isetrp_src_to_i1.2"
  %"P31_to_i32" = zext i1 %"isetrp_cmp2.2" to i32
  %"viadd" = add i32 %"phi.1", 128
  %"iadd3_o1_64.1" = zext i32 %"phi.3" to i64
  %"iadd3_o2_64.1" = zext i32 512 to i64
  %"iadd3_o3_64.1" = zext i32 0 to i64
  %"iadd3_tmp.1" = add i64 %"iadd3_o1_64.1", %"iadd3_o2_64.1"
  %"iadd3_tmp2.1" = add i64 %"iadd3_tmp.1", %"iadd3_o3_64.1"
  %"iadd3_trunc.1" = trunc i64 %"iadd3_tmp2.1" to i32
  %"iadd3_carry_val.1" = lshr i64 %"iadd3_tmp2.1", 32
  %"carry_ge_1.1" = icmp uge i64 %"iadd3_carry_val.1", 1
  %"P5_to_i32" = zext i1 %"carry_ge_1.1" to i32
  %"carry_ge_2.1" = icmp uge i64 %"iadd3_carry_val.1", 2
  %"imad_tmp.1" = mul i32 0, 0
  %"imad.2" = add i32 %"imad_tmp.1", %"phi"
  %"imad_cin_trunc.1" = trunc i32 %"P5_to_i32" to i1
  %"imad_cin_ext.1" = zext i1 %"imad_cin_trunc.1" to i32
  %"imad_with_cin.1" = add i32 %"imad.2", %"imad_cin_ext.1"
  %"sts_shared_addr_winoff" = and i32 %"phi.2", 16777215
  %".29" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff"
  %"sts_shared_addr_cast" = bitcast i8 addrspace(3)* %".29" to i32 addrspace(3)*
  store volatile i32 %"ldg", i32 addrspace(3)* %"sts_shared_addr_cast"
  %"viadd.1" = add i32 %"phi.2", 512
  br label %"BB_0180"
BB_0180:
  %"cond_trunc.1" = trunc i32 %"P31_to_i32" to i1
  %"cond_not" = xor i1 %"cond_trunc.1", -1
  %"pbra_cond_to_i32.1" = zext i1 %"cond_not" to i32
  %"pbra_cond_to_i1.1" = icmp ne i32 %"pbra_cond_to_i32.1", 0
  br i1 %"pbra_cond_to_i1.1", label %"BB_0100", label %"BB_0190"
BB_0190:
  %"phi.4" = phi  i32 [%"P33_to_i32", %"BB_0090"], [%"P5_to_i32", %"BB_0180"]
  %"vote_pred_trunc" = trunc i32 %"P1_to_i32" to i1
  %"vote_all" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc")
  %"P15_to_i32" = zext i1 %"vote_all" to i32
  %"isetrp_cmp1.3" = icmp ugt i32 %"tid_x", 31
  %"isetrp_src_to_i32.3" = zext i1 1 to i32
  %"isetrp_src_to_i1.3" = icmp ne i32 %"isetrp_src_to_i32.3", 0
  %"isetrp_cmp2.3" = and i1 %"isetrp_cmp1.3", %"isetrp_src_to_i1.3"
  %"P32_to_i32" = zext i1 %"isetrp_cmp2.3" to i32
  br label %"BB_01e0"
BB_01e0:
  %"cond_trunc.2" = trunc i32 %"P15_to_i32" to i1
  %"cond_not.1" = xor i1 %"cond_trunc.2", -1
  %"pbra_cond_to_i32.2" = zext i1 %"cond_not.1" to i32
  %"pbra_cond_to_i1.2" = icmp ne i32 %"pbra_cond_to_i32.2", 0
  br i1 %"pbra_cond_to_i1.2", label %"BB_800001e0", label %"BB_0230"
BB_800001e0:
  %"iadd3_n1" = add i32 1024, 1024
  %"iadd3_n2" = add i32 %"iadd3_n1", 0
  %"iadd3_o1_not" = xor i32 1, -1
  %"iadd3_o1_neg" = add i32 %"iadd3_o1_not", 1
  %"iadd3_n1.1" = add i32 %"iadd3_o1_neg", 1048576
  %"iadd3_n2.1" = add i32 %"iadd3_n1.1", 0
  %".35" = zext i32 %"iadd3_n2.1" to i64
  %".36" = zext i32 0 to i64
  %".37" = shl i64 %".36", 32
  %"shf_concat" = or i64 %".35", %".37"
  %"shf_shift_64" = zext i32 11 to i64
  %".38" = shl i64 %"shf_concat", %"shf_shift_64"
  %"shf_result" = trunc i64 %".38" to i32
  %".39" = zext i32 %"iadd3_n2.1" to i64
  %".40" = zext i32 0 to i64
  %".41" = shl i64 %".40", 32
  %"shf_concat.1" = or i64 %".39", %".41"
  %"shf_shift_64.1" = zext i32 1 to i64
  %".42" = shl i64 %"shf_concat.1", %"shf_shift_64.1"
  %"shf_result.1" = trunc i64 %".42" to i32
  %".43" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".44" = zext i32 %"iadd3_n2" to i64
  %".45" = zext i32 24 to i64
  %".46" = shl i64 %".43", %".45"
  %".47" = and i64 %".46", 4294967295
  %".48" = add i64 %".47", %".44"
  %".49" = trunc i64 %".48" to i32
  br label %"BB_0230"
BB_0230:
  %"phi.5" = phi  i32 [%".49", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.6" = phi  i32 [%"shf_result", %"BB_800001e0"], [0, %"BB_01e0"]
  %"phi.7" = phi  i32 [%"shf_result.1", %"BB_800001e0"], [1, %"BB_01e0"]
  %"vote_pred_trunc.1" = trunc i32 %"P1_to_i32" to i1
  %"vote_all.1" = call i1 @"llvm.nvvm.vote.all.sync"(i32 -1, i1 %"vote_pred_trunc.1")
  %"P16_to_i32" = zext i1 %"vote_all.1" to i32
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0250"
BB_0250:
  %"cond_trunc.3" = trunc i32 %"P16_to_i32" to i1
  %"cond_not.2" = xor i1 %"cond_trunc.3", -1
  %"pbra_cond_to_i32.3" = zext i1 %"cond_not.2" to i32
  %"pbra_cond_to_i1.3" = icmp ne i32 %"pbra_cond_to_i32.3", 0
  br i1 %"pbra_cond_to_i1.3", label %"BB_80000250", label %"BB_0260"
BB_80000250:
  %"mbar_shared_winoff" = and i32 %"phi.5", 16777215
  %".54" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff"
  %"mbar_ptr" = ptrtoint i8 addrspace(3)* %".54" to i64
  %"mbar_init_state_r0_ext" = zext i32 %"phi.7" to i64
  %"mbar_init_state_packed_0" = or i64 0, %"mbar_init_state_r0_ext"
  %"mbar_init_state_r1_ext" = zext i32 %"phi.6" to i64
  %"mbar_init_state_r1_shift" = shl i64 %"mbar_init_state_r1_ext", 32
  %"mbar_init_state_packed_1" = or i64 %"mbar_init_state_packed_0", %"mbar_init_state_r1_shift"
  %"mbar_init_low" = trunc i64 %"mbar_init_state_packed_1" to i32
  %"mbar_cd" = lshr i32 %"mbar_init_low", 1
  %"mbar_count_raw" = sub i32 1048576, %"mbar_cd"
  %"mbar_count" = and i32 %"mbar_count_raw", 1048575
  %".55" = lshr i64 %"mbar_init_state_packed_1", 63
  %"mbar_init_phase" = trunc i64 %".55" to i32
  call void asm sideeffect "{ .reg .pred advance; .reg .b32 mask, enabled; .reg .pred leader; activemask.b32 mask; elect.sync _|leader, mask; @leader mbarrier.init.shared::cta.b64 [$0], $1; selp.u32 enabled, $2, 0, leader; setp.ne.u32 advance, enabled, 0; @advance mbarrier.arrive.shared::cta.b64 _, [$0], $1; }", "l,r,r,~{memory}"(i64 %"mbar_ptr", i32 %"mbar_count", i32 %"mbar_init_phase")
  br label %"BB_0260"
BB_0260:
  %"cond_trunc.4" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.4" = zext i1 %"cond_trunc.4" to i32
  %"pbra_cond_to_i1.4" = icmp ne i32 %"pbra_cond_to_i32.4", 0
  br i1 %"pbra_cond_to_i1.4", label %"BB_0400", label %"BB_0270"
BB_0270:
  %"allocation_dst_memaddr_offset_add" = add i32 %".16", 1032
  %"allocation_slot_winoff" = and i32 %"allocation_dst_memaddr_offset_add", 16777215
  %".59" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"allocation_slot_winoff"
  %".60" = ptrtoint i8 addrspace(3)* %".59" to i32
  call void asm sideeffect "bar.warp.sync 0xffffffff; tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [$0], $1; bar.warp.sync 0xffffffff;", "r,r,~{memory}"(i32 %".60", i32 64) convergent
  %"elect_mask" = call i32 @"llvm.nvvm.activemask"()
  %"election" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask")
  %"elect_p" = extractvalue {i32, i1} %"election", 1
  %"P7_to_i32" = zext i1 %"elect_p" to i32
  br label %"BB_0290"
BB_0290:
  %"cond_trunc.5" = trunc i32 %"P7_to_i32" to i1
  %"cond_not.3" = xor i1 %"cond_trunc.5", -1
  %"pbra_cond_to_i32.5" = zext i1 %"cond_not.3" to i32
  %"pbra_cond_to_i1.5" = icmp ne i32 %"pbra_cond_to_i32.5", 0
  br i1 %"pbra_cond_to_i1.5", label %"BB_0400", label %"BB_02a0"
BB_02a0:
  %"imad_tmp.2" = mul i32 0, 0
  %"imad.3" = add i32 %"imad_tmp.2", 3
  %".64" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".65" = zext i32 64 to i64
  %".66" = zext i32 24 to i64
  %".67" = shl i64 %".64", %".66"
  %".68" = and i64 %".67", 4294967295
  %".69" = add i64 %".68", %".65"
  %".70" = trunc i64 %".69" to i32
  %"imad_tmp.3" = mul i32 0, 0
  %"imad.4" = add i32 %"imad_tmp.3", 1
  %"tmem_alloc_slot_memaddr_offset_add" = add i32 %".16", 1032
  %"tmem_alloc_winoff" = and i32 %"tmem_alloc_slot_memaddr_offset_add", 16777215
  %".71" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff"
  %".72" = bitcast i8 addrspace(3)* %".71" to i32 addrspace(3)*
  %".73" = load i32, i32 addrspace(3)* %".72"
  %".74" = lshr i32 %".73", 5
  %"P17_to_i32" = zext i1 1 to i32
  %"imad_tmp.4" = mul i32 0, 0
  %"imad.5" = add i32 %"imad_tmp.4", %".74"
  %"bra_cond_trunc" = trunc i32 %"P17_to_i32" to i1
  %"bra_cond_to_i32" = zext i1 %"bra_cond_trunc" to i32
  %"bra_cond_to_i1" = icmp ne i32 %"bra_cond_to_i32", 0
  br i1 %"bra_cond_to_i1", label %"BB_0390", label %"BB_0330"
BB_0330:
  %"tmem_alloc_slot_memaddr_offset_add.1" = add i32 %".16", 1032
  %"tmem_alloc_winoff.1" = and i32 %"tmem_alloc_slot_memaddr_offset_add.1", 16777215
  %".76" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"tmem_alloc_winoff.1"
  %".77" = bitcast i8 addrspace(3)* %".76" to i32 addrspace(3)*
  %".78" = load i32, i32 addrspace(3)* %".77"
  %".79" = lshr i32 %".78", 5
  %"P18_to_i32" = zext i1 1 to i32
  %"imad_tmp.5" = mul i32 0, 0
  %"imad.6" = add i32 %"imad_tmp.5", %".79"
  %"bra_cond_trunc.1" = trunc i32 %"P18_to_i32" to i1
  %"bra_cond_not" = xor i1 %"bra_cond_trunc.1", -1
  %"bra_cond_to_i32.1" = zext i1 %"bra_cond_not" to i32
  %"bra_cond_to_i1.1" = icmp ne i32 %"bra_cond_to_i32.1", 0
  br i1 %"bra_cond_to_i1.1", label %"BB_0330", label %"BB_0390"
BB_0390:
  %"phi.8" = phi  i32 [%"imad.5", %"BB_02a0"], [%"imad.6", %"BB_0330"]
  %".81" = zext i32 %"imad.3" to i64
  %".82" = zext i32 0 to i64
  %".83" = shl i64 %".82", 32
  %"shf_concat.2" = or i64 %".81", %".83"
  %"shf_shift_64.2" = zext i32 %"phi.8" to i64
  %".84" = shl i64 %"shf_concat.2", %"shf_shift_64.2"
  %"shf_result.2" = trunc i64 %".84" to i32
  %".85" = zext i32 %"imad.4" to i64
  %".86" = zext i32 0 to i64
  %".87" = shl i64 %".86", 32
  %"shf_concat.3" = or i64 %".85", %".87"
  %"shf_shift_64.3" = zext i32 %"phi.8" to i64
  %".88" = shl i64 %"shf_concat.3", %"shf_shift_64.3"
  %"shf_result.3" = trunc i64 %".88" to i32
  %"imad_tmp.6" = mul i32 %"phi.8", 32
  %"imad.7" = add i32 %"imad_tmp.6", 0
  %"atoms_addr_memaddr_offset_add" = add i32 %".70", 20
  %"atoms_shared_addr_winoff" = and i32 %"atoms_addr_memaddr_offset_add", 16777215
  %".89" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff"
  %"atoms_ptr" = bitcast i8 addrspace(3)* %".89" to i32 addrspace(3)*
  %"atoms_or" = atomicrmw or i32 addrspace(3)* %"atoms_ptr", i32 %"shf_result.2" monotonic
  %"atoms_addr_memaddr_offset_add.1" = add i32 %".70", 24
  %"atoms_shared_addr_winoff.1" = and i32 %"atoms_addr_memaddr_offset_add.1", 16777215
  %".90" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.1"
  %"atoms_ptr.1" = bitcast i8 addrspace(3)* %".90" to i32 addrspace(3)*
  %"atoms_or.1" = atomicrmw or i32 addrspace(3)* %"atoms_ptr.1", i32 %"shf_result.3" monotonic
  %"sts_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"sts_shared_addr_winoff.1" = and i32 %"sts_addr_memaddr_offset_add", 16777215
  %".91" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"sts_shared_addr_winoff.1"
  %"sts_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".91" to i32 addrspace(3)*
  store volatile i32 %"imad.7", i32 addrspace(3)* %"sts_shared_addr_cast.1"
  br label %"BB_0400"
BB_0400:
  %"phi.9" = phi  i32 [%"P7_to_i32", %"BB_0390"], [%"P7_to_i32", %"BB_0290"], [%"phi.4", %"BB_0260"]
  %".94" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 896
  %".95" = bitcast i8* %".94" to i64*
  %"ldc_const.1" = load i64, i64* %".95"
  %"R13:R12_r0" = trunc i64 %"ldc_const.1" to i32
  %"R13:R12_r1_shift" = lshr i64 %"ldc_const.1", 32
  %"R13:R12_r1" = trunc i64 %"R13:R12_r1_shift" to i32
  call void @"llvm.nvvm.barrier0"()
  %"imad_tmp.7" = mul i32 %"tid_x", 18
  %"imad.8" = add i32 %"imad_tmp.7", 0
  %"imad_addend_r0_ext.1" = zext i32 %"R13:R12_r0" to i64
  %"imad_addend_packed_0.1" = or i64 0, %"imad_addend_r0_ext.1"
  %"imad_addend_r1_ext.1" = zext i32 %"R13:R12_r1" to i64
  %"imad_addend_r1_shift.1" = shl i64 %"imad_addend_r1_ext.1", 32
  %"imad_addend_packed_1.1" = or i64 %"imad_addend_packed_0.1", %"imad_addend_r1_shift.1"
  %"imad_lhs_64.1" = zext i32 %"imad.8" to i64
  %"imad_rhs_64.1" = zext i32 4 to i64
  %"imad_tmp_64.1" = mul i64 %"imad_lhs_64.1", %"imad_rhs_64.1"
  %"imad.9" = add i64 %"imad_tmp_64.1", %"imad_addend_packed_1.1"
  %"R13:R12_r0.1" = trunc i64 %"imad.9" to i32
  %"R13:R12_r1_shift.1" = lshr i64 %"imad.9", 32
  %"R13:R12_r1.1" = trunc i64 %"R13:R12_r1_shift.1" to i32
  %"ldg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.1" = or i64 0, %"ldg_addr_r0_ext.1"
  %"ldg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.1" = shl i64 %"ldg_addr_r1_ext.1", 32
  %"ldg_addr_packed_1.1" = or i64 %"ldg_addr_packed_0.1", %"ldg_addr_r1_shift.1"
  %"ldg_addr_memaddr_offset_add" = add i64 %"ldg_addr_packed_1.1", 9256
  %"R23:R118_addr_ptr" = inttoptr i64 %"ldg_addr_memaddr_offset_add" to i32 addrspace(1)*
  %"ldg.1" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr"
  %"ldg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.2" = or i64 0, %"ldg_addr_r0_ext.2"
  %"ldg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.2" = shl i64 %"ldg_addr_r1_ext.2", 32
  %"ldg_addr_packed_1.2" = or i64 %"ldg_addr_packed_0.2", %"ldg_addr_r1_shift.2"
  %"ldg_addr_memaddr_offset_add.1" = add i64 %"ldg_addr_packed_1.2", 9260
  %"R23:R118_addr_ptr.1" = inttoptr i64 %"ldg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  %"ldg.2" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.1"
  %"ldg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.3" = or i64 0, %"ldg_addr_r0_ext.3"
  %"ldg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.3" = shl i64 %"ldg_addr_r1_ext.3", 32
  %"ldg_addr_packed_1.3" = or i64 %"ldg_addr_packed_0.3", %"ldg_addr_r1_shift.3"
  %"ldg_addr_memaddr_offset_add.2" = add i64 %"ldg_addr_packed_1.3", 9264
  %"R23:R118_addr_ptr.2" = inttoptr i64 %"ldg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  %"ldg.3" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.2"
  %"ldg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.4" = or i64 0, %"ldg_addr_r0_ext.4"
  %"ldg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.4" = shl i64 %"ldg_addr_r1_ext.4", 32
  %"ldg_addr_packed_1.4" = or i64 %"ldg_addr_packed_0.4", %"ldg_addr_r1_shift.4"
  %"ldg_addr_memaddr_offset_add.3" = add i64 %"ldg_addr_packed_1.4", 9268
  %"R23:R118_addr_ptr.3" = inttoptr i64 %"ldg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  %"ldg.4" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.3"
  %"ldg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.5" = or i64 0, %"ldg_addr_r0_ext.5"
  %"ldg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.5" = shl i64 %"ldg_addr_r1_ext.5", 32
  %"ldg_addr_packed_1.5" = or i64 %"ldg_addr_packed_0.5", %"ldg_addr_r1_shift.5"
  %"ldg_addr_memaddr_offset_add.4" = add i64 %"ldg_addr_packed_1.5", 9272
  %"R23:R118_addr_ptr.4" = inttoptr i64 %"ldg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  %"ldg.5" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.4"
  %"ldg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.6" = or i64 0, %"ldg_addr_r0_ext.6"
  %"ldg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.6" = shl i64 %"ldg_addr_r1_ext.6", 32
  %"ldg_addr_packed_1.6" = or i64 %"ldg_addr_packed_0.6", %"ldg_addr_r1_shift.6"
  %"ldg_addr_memaddr_offset_add.5" = add i64 %"ldg_addr_packed_1.6", 9276
  %"R23:R118_addr_ptr.5" = inttoptr i64 %"ldg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  %"ldg.6" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.5"
  %"ldg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.7" = or i64 0, %"ldg_addr_r0_ext.7"
  %"ldg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.7" = shl i64 %"ldg_addr_r1_ext.7", 32
  %"ldg_addr_packed_1.7" = or i64 %"ldg_addr_packed_0.7", %"ldg_addr_r1_shift.7"
  %"ldg_addr_memaddr_offset_add.6" = add i64 %"ldg_addr_packed_1.7", 9280
  %"R23:R118_addr_ptr.6" = inttoptr i64 %"ldg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  %"ldg.7" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.6"
  %"ldg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.8" = or i64 0, %"ldg_addr_r0_ext.8"
  %"ldg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.8" = shl i64 %"ldg_addr_r1_ext.8", 32
  %"ldg_addr_packed_1.8" = or i64 %"ldg_addr_packed_0.8", %"ldg_addr_r1_shift.8"
  %"ldg_addr_memaddr_offset_add.7" = add i64 %"ldg_addr_packed_1.8", 9284
  %"R23:R118_addr_ptr.7" = inttoptr i64 %"ldg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  %"ldg.8" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.7"
  %"imad_tmp.8" = mul i32 %"tid_x", 65536
  %"imad.10" = add i32 %"imad_tmp.8", 0
  %"lds_addr_memaddr_offset_add" = add i32 %".16", 1032
  %"lds_shared_addr_winoff" = and i32 %"lds_addr_memaddr_offset_add", 16777215
  %".96" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff"
  %"lds_shared_addr_cast" = bitcast i8 addrspace(3)* %".96" to i32 addrspace(3)*
  %"lds" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast"
  %".97" = xor i32 %"imad.10", -1
  %".98" = xor i32 65011712, -1
  %".99" = xor i32 0, -1
  %".100" = and i32 %"imad.10", 65011712
  %".101" = and i32 %".100", %".99"
  %".102" = and i32 %"imad.10", 65011712
  %".103" = and i32 %".102", 0
  %".104" = or i32 %".101", %".103"
  %"imad_tmp.9" = mul i32 %"lds", 1
  %"imad.11" = add i32 %"imad_tmp.9", %".104"
  %"sttm_memaddr_offset_add" = add i32 %"imad.11", 32
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add", i32 %"ldg.1", i32 %"ldg.2", i32 %"ldg.3", i32 %"ldg.4")
  %"sttm_memaddr_offset_add.1" = add i32 %"imad.11", 36
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.1", i32 %"ldg.5", i32 %"ldg.6", i32 %"ldg.7", i32 %"ldg.8")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  %"ldg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.9" = or i64 0, %"ldg_addr_r0_ext.9"
  %"ldg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.9" = shl i64 %"ldg_addr_r1_ext.9", 32
  %"ldg_addr_packed_1.9" = or i64 %"ldg_addr_packed_0.9", %"ldg_addr_r1_shift.9"
  %"ldg_addr_memaddr_offset_add.8" = add i64 %"ldg_addr_packed_1.9", 9216
  %"R23:R118_addr_ptr.8" = inttoptr i64 %"ldg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  %"ldg.9" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.8"
  %"ldg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.10" = or i64 0, %"ldg_addr_r0_ext.10"
  %"ldg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.10" = shl i64 %"ldg_addr_r1_ext.10", 32
  %"ldg_addr_packed_1.10" = or i64 %"ldg_addr_packed_0.10", %"ldg_addr_r1_shift.10"
  %"ldg_addr_memaddr_offset_add.9" = add i64 %"ldg_addr_packed_1.10", 9220
  %"R23:R118_addr_ptr.9" = inttoptr i64 %"ldg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  %"ldg.10" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.9"
  %"ldg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.11" = or i64 0, %"ldg_addr_r0_ext.11"
  %"ldg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.11" = shl i64 %"ldg_addr_r1_ext.11", 32
  %"ldg_addr_packed_1.11" = or i64 %"ldg_addr_packed_0.11", %"ldg_addr_r1_shift.11"
  %"ldg_addr_memaddr_offset_add.10" = add i64 %"ldg_addr_packed_1.11", 9224
  %"R23:R118_addr_ptr.10" = inttoptr i64 %"ldg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  %"ldg.11" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.10"
  %"ldg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.12" = or i64 0, %"ldg_addr_r0_ext.12"
  %"ldg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.12" = shl i64 %"ldg_addr_r1_ext.12", 32
  %"ldg_addr_packed_1.12" = or i64 %"ldg_addr_packed_0.12", %"ldg_addr_r1_shift.12"
  %"ldg_addr_memaddr_offset_add.11" = add i64 %"ldg_addr_packed_1.12", 9228
  %"R23:R118_addr_ptr.11" = inttoptr i64 %"ldg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  %"ldg.12" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.11"
  %"ldg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.13" = or i64 0, %"ldg_addr_r0_ext.13"
  %"ldg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.13" = shl i64 %"ldg_addr_r1_ext.13", 32
  %"ldg_addr_packed_1.13" = or i64 %"ldg_addr_packed_0.13", %"ldg_addr_r1_shift.13"
  %"ldg_addr_memaddr_offset_add.12" = add i64 %"ldg_addr_packed_1.13", 9232
  %"R23:R118_addr_ptr.12" = inttoptr i64 %"ldg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  %"ldg.13" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.12"
  %"ldg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.14" = or i64 0, %"ldg_addr_r0_ext.14"
  %"ldg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.14" = shl i64 %"ldg_addr_r1_ext.14", 32
  %"ldg_addr_packed_1.14" = or i64 %"ldg_addr_packed_0.14", %"ldg_addr_r1_shift.14"
  %"ldg_addr_memaddr_offset_add.13" = add i64 %"ldg_addr_packed_1.14", 9236
  %"R23:R118_addr_ptr.13" = inttoptr i64 %"ldg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  %"ldg.14" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.13"
  %"ldg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.15" = or i64 0, %"ldg_addr_r0_ext.15"
  %"ldg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.15" = shl i64 %"ldg_addr_r1_ext.15", 32
  %"ldg_addr_packed_1.15" = or i64 %"ldg_addr_packed_0.15", %"ldg_addr_r1_shift.15"
  %"ldg_addr_memaddr_offset_add.14" = add i64 %"ldg_addr_packed_1.15", 9240
  %"R23:R118_addr_ptr.14" = inttoptr i64 %"ldg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  %"ldg.15" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.14"
  %"ldg_addr_r0_ext.16" = zext i32 %"R13:R12_r0.1" to i64
  %"ldg_addr_packed_0.16" = or i64 0, %"ldg_addr_r0_ext.16"
  %"ldg_addr_r1_ext.16" = zext i32 %"R13:R12_r1.1" to i64
  %"ldg_addr_r1_shift.16" = shl i64 %"ldg_addr_r1_ext.16", 32
  %"ldg_addr_packed_1.16" = or i64 %"ldg_addr_packed_0.16", %"ldg_addr_r1_shift.16"
  %"ldg_addr_memaddr_offset_add.15" = add i64 %"ldg_addr_packed_1.16", 9244
  %"R23:R118_addr_ptr.15" = inttoptr i64 %"ldg_addr_memaddr_offset_add.15" to i32 addrspace(1)*
  %"ldg.16" = load i32, i32 addrspace(1)* %"R23:R118_addr_ptr.15"
  %"sttm_memaddr_offset_add.2" = add i32 %"imad.11", 16
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.2", i32 %"ldg.9", i32 %"ldg.10", i32 %"ldg.11", i32 %"ldg.12")
  %"sttm_memaddr_offset_add.3" = add i32 %"imad.11", 20
  call void asm sideeffect "tcgen05.st.sync.aligned.32x32b.x4.b32 [$0], {$1,$2,$3,$4}; tcgen05.wait::st.sync.aligned;", "r,r,r,r,r,~{memory}"(i32 %"sttm_memaddr_offset_add.3", i32 %"ldg.13", i32 %"ldg.14", i32 %"ldg.15", i32 %"ldg.16")
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  call void @"llvm.nvvm.barrier0"()
  call void @"llvm.nvvm.membar.cta"()
  call void asm sideeffect "fence.proxy.async.shared::cta;", "~{memory}"()
  br label %"BB_0680"
BB_0680:
  %"cond_trunc.6" = trunc i32 %"P1_to_i32" to i1
  %"pbra_cond_to_i32.6" = zext i1 %"cond_trunc.6" to i32
  %"pbra_cond_to_i1.6" = icmp ne i32 %"pbra_cond_to_i32.6", 0
  br i1 %"pbra_cond_to_i1.6", label %"BB_0820", label %"BB_0690"
BB_0690:
  %"lds_addr_memaddr_offset_add.1" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.1" = and i32 %"lds_addr_memaddr_offset_add.1", 16777215
  %".114" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.1"
  %"lds_shared_addr_cast.1" = bitcast i8 addrspace(3)* %".114" to i32 addrspace(3)*
  %"lds.1" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.1"
  %".115" = zext i32 0 to i64
  %".116" = zext i32 %".16" to i64
  %".117" = shl i64 %".116", 32
  %"shf_concat.4" = or i64 %".115", %".117"
  %"shf_shift_64.4" = zext i32 4 to i64
  %".118" = lshr i64 %"shf_concat.4", %"shf_shift_64.4"
  %"shf_hi" = lshr i64 %".118", 32
  %"shf_result.4" = trunc i64 %"shf_hi" to i32
  %"lop3_a_cast_zext" = zext i1 1 to i32
  %"lop3_b_cast_zext" = zext i1 1 to i32
  %"lop3_c_cast_zext" = zext i1 1 to i32
  %"plop3_a_bit" = and i32 %"lop3_a_cast_zext", 1
  %"plop3_b_bit" = and i32 %"lop3_b_cast_zext", 1
  %"plop3_c_bit" = and i32 %"lop3_c_cast_zext", 1
  %".119" = xor i32 %"plop3_a_bit", 1
  %".120" = xor i32 %"plop3_b_bit", 1
  %".121" = xor i32 %"plop3_c_bit", 1
  %".122" = and i32 %"plop3_a_bit", %"plop3_b_bit"
  %".123" = and i32 %".122", %"plop3_c_bit"
  %"plop3_pred" = icmp ne i32 %".123", 0
  %"P9_to_i32" = zext i1 %"plop3_pred" to i32
  %".124" = xor i32 %"shf_result.4", -1
  %".125" = xor i32 16376, -1
  %".126" = xor i32 0, -1
  %".127" = and i32 %"shf_result.4", 16376
  %".128" = and i32 %".127", %".126"
  %".129" = and i32 %"shf_result.4", 16376
  %".130" = and i32 %".129", 0
  %".131" = or i32 %".128", %".130"
  %".132" = xor i32 %".131", -1
  %".133" = xor i32 524288, -1
  %".134" = xor i32 0, -1
  %".135" = and i32 %".132", 524288
  %".136" = and i32 %".135", %".134"
  %".137" = and i32 %".132", 524288
  %".138" = and i32 %".137", 0
  %".139" = or i32 %".136", %".138"
  %".140" = and i32 %".131", %".133"
  %".141" = and i32 %".140", %".134"
  %".142" = or i32 %".139", %".141"
  %".143" = and i32 %".131", %".133"
  %".144" = and i32 %".143", 0
  %".145" = or i32 %".142", %".144"
  %".146" = and i32 %".131", 524288
  %".147" = and i32 %".146", %".134"
  %".148" = or i32 %".145", %".147"
  %".149" = and i32 %".131", 524288
  %".150" = and i32 %".149", 0
  %".151" = or i32 %".148", %".150"
  %"iadd3_n1.2" = add i32 %"lds.1", 32
  %"iadd3_n2.2" = add i32 %"iadd3_n1.2", 0
  %"iadd3_n1.3" = add i32 %"lds.1", 16
  %"iadd3_n2.3" = add i32 %"iadd3_n1.3", 0
  %"iadd3_n1.4" = add i32 %"lds.1", 20
  %"iadd3_n2.4" = add i32 %"iadd3_n1.4", 0
  br label %"BB_0750"
BB_0750:
  %"phi.10" = phi  i32 [%"phi.9", %"BB_0690"], [%"P14_to_i32", %"BB_0780"]
  %"phi.11" = phi  i32 [%"P9_to_i32", %"BB_0690"], [%"phi.13", %"BB_0780"]
  %"cond_trunc.7" = trunc i32 %"phi.11" to i1
  %"pbra_cond_to_i32.7" = zext i1 %"cond_trunc.7" to i32
  %"pbra_cond_to_i1.7" = icmp ne i32 %"pbra_cond_to_i32.7", 0
  br i1 %"pbra_cond_to_i1.7", label %"BB_80000750", label %"BB_0760"
BB_80000750:
  %"elect_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"election.1" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.1")
  %"elect_p.1" = extractvalue {i32, i1} %"election.1", 1
  %"P11_to_i32" = zext i1 %"elect_p.1" to i32
  br label %"BB_0760"
BB_0760:
  %"phi.12" = phi  i32 [%"P11_to_i32", %"BB_80000750"], [%"phi.10", %"BB_0750"]
  %"mma_b_r0_ext" = zext i32 %".151" to i64
  %"mma_b_packed_0" = or i64 0, %"mma_b_r0_ext"
  %"mma_b_r1_ext" = zext i32 16400 to i64
  %"mma_b_r1_shift" = shl i64 %"mma_b_r1_ext", 32
  %"mma_b_packed_1" = or i64 %"mma_b_packed_0", %"mma_b_r1_shift"
  %".155" = ptrtoint [2064 x i8] addrspace(3)* @"shared_mem" to i64
  %".156" = sub i64 %".155", 0
  %".157" = lshr i64 %".156", 4
  %".158" = add i64 %"mma_b_packed_1", %".157"
  %".159" = and i64 %".158", 16383
  %".160" = and i64 %"mma_b_packed_1", -16384
  %".161" = or i64 %".160", %".159"
  %"mma_arg_zext" = zext i1 0 to i32
  call void asm sideeffect "{ .reg .pred use_d; setp.ne.u32 use_d, $4, 0; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [$0], [$1], $2, $3, [$5], [$6], use_d; } }", "r,r,l,r,r,r,r,~{memory}"(i32 %"lds.1", i32 %"iadd3_n2.2", i64 %".161", i32 679739568, i32 %"mma_arg_zext", i32 %"iadd3_n2.3", i32 %"iadd3_n2.4")
  br label %"BB_0770"
BB_0770:
  %"cond_trunc.8" = trunc i32 %"phi.12" to i1
  %"pbra_cond_to_i32.8" = zext i1 %"cond_trunc.8" to i32
  %"pbra_cond_to_i1.8" = icmp ne i32 %"pbra_cond_to_i32.8", 0
  br i1 %"pbra_cond_to_i1.8", label %"BB_80000770", label %"BB_0780"
BB_80000770:
  %"lop3_a_trunc" = trunc i32 %"phi.12" to i1
  %"lop3_a_cast_zext.1" = zext i1 %"lop3_a_trunc" to i32
  %"lop3_b_cast_zext.1" = zext i1 1 to i32
  %"lop3_c_cast_zext.1" = zext i1 1 to i32
  %"plop3_a_bit.1" = and i32 %"lop3_a_cast_zext.1", 1
  %"plop3_b_bit.1" = and i32 %"lop3_b_cast_zext.1", 1
  %"plop3_c_bit.1" = and i32 %"lop3_c_cast_zext.1", 1
  %".165" = xor i32 %"plop3_a_bit.1", 1
  %".166" = xor i32 %"plop3_b_bit.1", 1
  %".167" = xor i32 %"plop3_c_bit.1", 1
  %".168" = and i32 %".165", %"plop3_b_bit.1"
  %".169" = and i32 %".168", %"plop3_c_bit.1"
  %"plop3_pred.1" = icmp ne i32 %".169", 0
  %"P25_to_i32" = zext i1 %"plop3_pred.1" to i32
  br label %"BB_0780"
BB_0780:
  %"phi.13" = phi  i32 [%"P25_to_i32", %"BB_80000770"], [%"phi.11", %"BB_0770"]
  %"lop3_a_cast_zext.2" = zext i1 1 to i32
  %"lop3_b_cast_zext.2" = zext i1 1 to i32
  %"lop3_c_cast_zext.2" = zext i1 1 to i32
  %"plop3_a_bit.2" = and i32 %"lop3_a_cast_zext.2", 1
  %"plop3_b_bit.2" = and i32 %"lop3_b_cast_zext.2", 1
  %"plop3_c_bit.2" = and i32 %"lop3_c_cast_zext.2", 1
  %".171" = xor i32 %"plop3_a_bit.2", 1
  %".172" = xor i32 %"plop3_b_bit.2", 1
  %".173" = xor i32 %"plop3_c_bit.2", 1
  %".174" = and i32 %".171", %"plop3_b_bit.2"
  %".175" = and i32 %".174", %"plop3_c_bit.2"
  %"plop3_pred.2" = icmp ne i32 %".175", 0
  %"P14_to_i32" = zext i1 %"plop3_pred.2" to i32
  %"bra_cond_trunc.2" = trunc i32 %"phi.13" to i1
  %"bra_cond_to_i32.2" = zext i1 %"bra_cond_trunc.2" to i32
  %"bra_cond_to_i1.2" = icmp ne i32 %"bra_cond_to_i32.2", 0
  %"branch_mask" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask", i1 %"bra_cond_to_i1.2")
  br i1 %"branch_any", label %"BB_0750", label %"BB_07a0"
BB_07a0:
  %"iadd3_n1.5" = add i32 1024, 1024
  %"iadd3_n2.5" = add i32 %"iadd3_n1.5", 0
  %"lop3_a_cast_zext.3" = zext i1 1 to i32
  %"lop3_b_cast_zext.3" = zext i1 1 to i32
  %"lop3_c_cast_zext.3" = zext i1 1 to i32
  %"plop3_a_bit.3" = and i32 %"lop3_a_cast_zext.3", 1
  %"plop3_b_bit.3" = and i32 %"lop3_b_cast_zext.3", 1
  %"plop3_c_bit.3" = and i32 %"lop3_c_cast_zext.3", 1
  %".177" = xor i32 %"plop3_a_bit.3", 1
  %".178" = xor i32 %"plop3_b_bit.3", 1
  %".179" = xor i32 %"plop3_c_bit.3", 1
  %".180" = and i32 %"plop3_a_bit.3", %"plop3_b_bit.3"
  %".181" = and i32 %".180", %"plop3_c_bit.3"
  %"plop3_pred.3" = icmp ne i32 %".181", 0
  %"P27_to_i32" = zext i1 %"plop3_pred.3" to i32
  %".182" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".183" = zext i32 %"iadd3_n2.5" to i64
  %".184" = zext i32 24 to i64
  %".185" = shl i64 %".182", %".184"
  %".186" = and i64 %".185", 4294967295
  %".187" = add i64 %".186", %".183"
  %".188" = trunc i64 %".187" to i32
  br label %"BB_07d0"
BB_07d0:
  %"phi.14" = phi  i32 [%"P14_to_i32", %"BB_07a0"], [%"P4_to_i32", %"BB_0800"]
  %"phi.15" = phi  i32 [%"P27_to_i32", %"BB_07a0"], [%"phi.17", %"BB_0800"]
  %"cond_trunc.9" = trunc i32 %"phi.15" to i1
  %"pbra_cond_to_i32.9" = zext i1 %"cond_trunc.9" to i32
  %"pbra_cond_to_i1.9" = icmp ne i32 %"pbra_cond_to_i32.9", 0
  br i1 %"pbra_cond_to_i1.9", label %"BB_800007d0", label %"BB_07e0"
BB_800007d0:
  %"elect_mask.2" = call i32 @"llvm.nvvm.activemask"()
  %"election.2" = call {i32, i1} @"llvm.nvvm.elect.sync"(i32 %"elect_mask.2")
  %"elect_p.2" = extractvalue {i32, i1} %"election.2", 1
  %"P35_to_i32" = zext i1 %"elect_p.2" to i32
  br label %"BB_07e0"
BB_07e0:
  %"phi.16" = phi  i32 [%"P35_to_i32", %"BB_800007d0"], [%"phi.14", %"BB_07d0"]
  %"utcbar_local_winoff" = and i32 %".188", 16777215
  %".192" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"utcbar_local_winoff"
  %".193" = ptrtoint i8 addrspace(3)* %".192" to i32
  %".194" = lshr i32 %".188", 24
  call void asm sideeffect "{ .reg .u32 bar; mapa.shared::cluster.u32 bar, $0, $1; { .reg .pred pe; .reg .b32 me; activemask.b32 me; elect.sync _|pe, me; @pe tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [bar]; } }", "r,r,~{memory}"(i32 %".193", i32 %".194")
  br label %"BB_07f0"
BB_07f0:
  %"cond_trunc.10" = trunc i32 %"phi.16" to i1
  %"pbra_cond_to_i32.10" = zext i1 %"cond_trunc.10" to i32
  %"pbra_cond_to_i1.10" = icmp ne i32 %"pbra_cond_to_i32.10", 0
  br i1 %"pbra_cond_to_i1.10", label %"BB_800007f0", label %"BB_0800"
BB_800007f0:
  %"lop3_a_trunc.1" = trunc i32 %"phi.16" to i1
  %"lop3_a_cast_zext.4" = zext i1 %"lop3_a_trunc.1" to i32
  %"lop3_b_cast_zext.4" = zext i1 1 to i32
  %"lop3_c_cast_zext.4" = zext i1 1 to i32
  %"plop3_a_bit.4" = and i32 %"lop3_a_cast_zext.4", 1
  %"plop3_b_bit.4" = and i32 %"lop3_b_cast_zext.4", 1
  %"plop3_c_bit.4" = and i32 %"lop3_c_cast_zext.4", 1
  %".198" = xor i32 %"plop3_a_bit.4", 1
  %".199" = xor i32 %"plop3_b_bit.4", 1
  %".200" = xor i32 %"plop3_c_bit.4", 1
  %".201" = and i32 %".198", %"plop3_b_bit.4"
  %".202" = and i32 %".201", %"plop3_c_bit.4"
  %"plop3_pred.4" = icmp ne i32 %".202", 0
  %"P29_to_i32" = zext i1 %"plop3_pred.4" to i32
  br label %"BB_0800"
BB_0800:
  %"phi.17" = phi  i32 [%"P29_to_i32", %"BB_800007f0"], [%"phi.15", %"BB_07f0"]
  %"lop3_a_cast_zext.5" = zext i1 1 to i32
  %"lop3_b_cast_zext.5" = zext i1 1 to i32
  %"lop3_c_cast_zext.5" = zext i1 1 to i32
  %"plop3_a_bit.5" = and i32 %"lop3_a_cast_zext.5", 1
  %"plop3_b_bit.5" = and i32 %"lop3_b_cast_zext.5", 1
  %"plop3_c_bit.5" = and i32 %"lop3_c_cast_zext.5", 1
  %".204" = xor i32 %"plop3_a_bit.5", 1
  %".205" = xor i32 %"plop3_b_bit.5", 1
  %".206" = xor i32 %"plop3_c_bit.5", 1
  %".207" = and i32 %".204", %"plop3_b_bit.5"
  %".208" = and i32 %".207", %"plop3_c_bit.5"
  %"plop3_pred.5" = icmp ne i32 %".208", 0
  %"P4_to_i32" = zext i1 %"plop3_pred.5" to i32
  %"bra_cond_trunc.3" = trunc i32 %"phi.17" to i1
  %"bra_cond_to_i32.3" = zext i1 %"bra_cond_trunc.3" to i32
  %"bra_cond_to_i1.3" = icmp ne i32 %"bra_cond_to_i32.3", 0
  %"branch_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"branch_any.1" = call i1 @"llvm.nvvm.vote.any.sync"(i32 %"branch_mask.1", i1 %"bra_cond_to_i1.3")
  br i1 %"branch_any.1", label %"BB_07d0", label %"BB_0820"
BB_0820:
  call void @"llvm.nvvm.barrier0"()
  %"iadd3_n1.6" = add i32 1024, 1024
  %"iadd3_n2.6" = add i32 %"iadd3_n1.6", 0
  %".210" = zext i32 0 to i64
  %".211" = zext i32 0 to i64
  %".212" = shl i64 %".211", 32
  %"shf_concat.5" = or i64 %".210", %".212"
  %"shf_shift_64.5" = zext i32 31 to i64
  %".213" = shl i64 %"shf_concat.5", %"shf_shift_64.5"
  %"shf_result.5" = trunc i64 %".213" to i32
  %".214" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".215" = zext i32 %"iadd3_n2.6" to i64
  %".216" = zext i32 24 to i64
  %".217" = shl i64 %".214", %".216"
  %".218" = and i64 %".217", 4294967295
  %".219" = add i64 %".218", %".215"
  %".220" = trunc i64 %".219" to i32
  %"mbar_shared_winoff.1" = and i32 %".220", 16777215
  %".221" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.1"
  %"mbar_ptr.1" = ptrtoint i8 addrspace(3)* %".221" to i64
  %"mbar_par_bit" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.1", i32 %"mbar_par_bit")
  %"mbar_ready" = icmp ne i32 %"mbar_phasechk", 0
  %"P3_to_i32" = zext i1 %"mbar_ready" to i32
  br label %"BB_0890"
BB_0890:
  %"cond_trunc.11" = trunc i32 %"P3_to_i32" to i1
  %"cond_not.4" = xor i1 %"cond_trunc.11", -1
  %"pbra_cond_to_i32.11" = zext i1 %"cond_not.4" to i32
  %"pbra_cond_to_i1.11" = icmp ne i32 %"pbra_cond_to_i32.11", 0
  br i1 %"pbra_cond_to_i1.11", label %"BB_0d30", label %"BB_08a0"
BB_0d30:
  %"mbar_shared_winoff.2" = and i32 %".220", 16777215
  %".224" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"mbar_shared_winoff.2"
  %"mbar_ptr.2" = ptrtoint i8 addrspace(3)* %".224" to i64
  %"mbar_par_bit.1" = lshr i32 %"shf_result.5", 31
  %"mbar_phasechk.1" = call i32 asm sideeffect "{.reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [$1], $2; selp.u32 $0, 1, 0, p;}", "=r,l,r,~{memory}"(i64 %"mbar_ptr.2", i32 %"mbar_par_bit.1")
  %"mbar_ready.1" = icmp ne i32 %"mbar_phasechk.1", 0
  %"P20_to_i32" = zext i1 %"mbar_ready.1" to i32
  br label %"BB_0d40"
BB_0d40:
  %"cond_trunc.12" = trunc i32 %"P20_to_i32" to i1
  %"cond_not.5" = xor i1 %"cond_trunc.12", -1
  %"pbra_cond_to_i32.12" = zext i1 %"cond_not.5" to i32
  %"pbra_cond_to_i1.12" = icmp ne i32 %"pbra_cond_to_i32.12", 0
  br i1 %"pbra_cond_to_i1.12", label %"BB_0d30", label %"BB_08a0"
BB_08a0:
  %".227" = getelementptr inbounds [912 x i8], [912 x i8]* %"param_local", i64 0, i64 904
  %".228" = bitcast i8* %".227" to i64*
  %"ldc_const.2" = load i64, i64* %".228"
  %"R13:R12_r0.2" = trunc i64 %"ldc_const.2" to i32
  %"R13:R12_r1_shift.2" = lshr i64 %"ldc_const.2", 32
  %"R13:R12_r1.2" = trunc i64 %"R13:R12_r1_shift.2" to i32
  %"imad_tmp.10" = mul i32 %"tid_x", 16
  %"imad.12" = add i32 %"imad_tmp.10", 0
  %"ldtm" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"imad.11")
  %".229" = extractvalue {i32, i32, i32, i32} %"ldtm", 0
  %".230" = extractvalue {i32, i32, i32, i32} %"ldtm", 1
  %".231" = extractvalue {i32, i32, i32, i32} %"ldtm", 2
  %".232" = extractvalue {i32, i32, i32, i32} %"ldtm", 3
  %"ldtm_addr_memaddr_offset_add" = add i32 %"imad.11", 4
  %"ldtm.1" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add")
  %".233" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 0
  %".234" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 1
  %".235" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 2
  %".236" = extractvalue {i32, i32, i32, i32} %"ldtm.1", 3
  %"imad_addend_r0_ext.2" = zext i32 %"R13:R12_r0.2" to i64
  %"imad_addend_packed_0.2" = or i64 0, %"imad_addend_r0_ext.2"
  %"imad_addend_r1_ext.2" = zext i32 %"R13:R12_r1.2" to i64
  %"imad_addend_r1_shift.2" = shl i64 %"imad_addend_r1_ext.2", 32
  %"imad_addend_packed_1.2" = or i64 %"imad_addend_packed_0.2", %"imad_addend_r1_shift.2"
  %"imad_lhs_64.2" = zext i32 %"imad.12" to i64
  %"imad_rhs_64.2" = zext i32 4 to i64
  %"imad_tmp_64.2" = mul i64 %"imad_lhs_64.2", %"imad_rhs_64.2"
  %"imad.13" = add i64 %"imad_tmp_64.2", %"imad_addend_packed_1.2"
  %"R13:R12_r0.3" = trunc i64 %"imad.13" to i32
  %"R13:R12_r1_shift.3" = lshr i64 %"imad.13", 32
  %"R13:R12_r1.3" = trunc i64 %"R13:R12_r1_shift.3" to i32
  %"stg_addr_r0_ext" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0" = or i64 0, %"stg_addr_r0_ext"
  %"stg_addr_r1_ext" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift" = shl i64 %"stg_addr_r1_ext", 32
  %"stg_addr_packed_1" = or i64 %"stg_addr_packed_0", %"stg_addr_r1_shift"
  %"R59:R3_addr_ptr" = inttoptr i64 %"stg_addr_packed_1" to i32 addrspace(1)*
  store i32 %".229", i32 addrspace(1)* %"R59:R3_addr_ptr"
  %"stg_addr_r0_ext.1" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.1" = or i64 0, %"stg_addr_r0_ext.1"
  %"stg_addr_r1_ext.1" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.1" = shl i64 %"stg_addr_r1_ext.1", 32
  %"stg_addr_packed_1.1" = or i64 %"stg_addr_packed_0.1", %"stg_addr_r1_shift.1"
  %"stg_addr_memaddr_offset_add" = add i64 %"stg_addr_packed_1.1", 4
  %"R59:R3_addr_ptr.1" = inttoptr i64 %"stg_addr_memaddr_offset_add" to i32 addrspace(1)*
  store i32 %".230", i32 addrspace(1)* %"R59:R3_addr_ptr.1"
  %"stg_addr_r0_ext.2" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.2" = or i64 0, %"stg_addr_r0_ext.2"
  %"stg_addr_r1_ext.2" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.2" = shl i64 %"stg_addr_r1_ext.2", 32
  %"stg_addr_packed_1.2" = or i64 %"stg_addr_packed_0.2", %"stg_addr_r1_shift.2"
  %"stg_addr_memaddr_offset_add.1" = add i64 %"stg_addr_packed_1.2", 8
  %"R59:R3_addr_ptr.2" = inttoptr i64 %"stg_addr_memaddr_offset_add.1" to i32 addrspace(1)*
  store i32 %".231", i32 addrspace(1)* %"R59:R3_addr_ptr.2"
  %"stg_addr_r0_ext.3" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.3" = or i64 0, %"stg_addr_r0_ext.3"
  %"stg_addr_r1_ext.3" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.3" = shl i64 %"stg_addr_r1_ext.3", 32
  %"stg_addr_packed_1.3" = or i64 %"stg_addr_packed_0.3", %"stg_addr_r1_shift.3"
  %"stg_addr_memaddr_offset_add.2" = add i64 %"stg_addr_packed_1.3", 12
  %"R59:R3_addr_ptr.3" = inttoptr i64 %"stg_addr_memaddr_offset_add.2" to i32 addrspace(1)*
  store i32 %".232", i32 addrspace(1)* %"R59:R3_addr_ptr.3"
  %"stg_addr_r0_ext.4" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.4" = or i64 0, %"stg_addr_r0_ext.4"
  %"stg_addr_r1_ext.4" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.4" = shl i64 %"stg_addr_r1_ext.4", 32
  %"stg_addr_packed_1.4" = or i64 %"stg_addr_packed_0.4", %"stg_addr_r1_shift.4"
  %"stg_addr_memaddr_offset_add.3" = add i64 %"stg_addr_packed_1.4", 16
  %"R59:R3_addr_ptr.4" = inttoptr i64 %"stg_addr_memaddr_offset_add.3" to i32 addrspace(1)*
  store i32 %".233", i32 addrspace(1)* %"R59:R3_addr_ptr.4"
  %"ldtm_addr_memaddr_offset_add.1" = add i32 %"imad.11", 8
  %"ldtm.2" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.1")
  %".242" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 0
  %".243" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 1
  %".244" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 2
  %".245" = extractvalue {i32, i32, i32, i32} %"ldtm.2", 3
  %"stg_addr_r0_ext.5" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.5" = or i64 0, %"stg_addr_r0_ext.5"
  %"stg_addr_r1_ext.5" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.5" = shl i64 %"stg_addr_r1_ext.5", 32
  %"stg_addr_packed_1.5" = or i64 %"stg_addr_packed_0.5", %"stg_addr_r1_shift.5"
  %"stg_addr_memaddr_offset_add.4" = add i64 %"stg_addr_packed_1.5", 20
  %"R59:R3_addr_ptr.5" = inttoptr i64 %"stg_addr_memaddr_offset_add.4" to i32 addrspace(1)*
  store i32 %".234", i32 addrspace(1)* %"R59:R3_addr_ptr.5"
  %"stg_addr_r0_ext.6" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.6" = or i64 0, %"stg_addr_r0_ext.6"
  %"stg_addr_r1_ext.6" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.6" = shl i64 %"stg_addr_r1_ext.6", 32
  %"stg_addr_packed_1.6" = or i64 %"stg_addr_packed_0.6", %"stg_addr_r1_shift.6"
  %"stg_addr_memaddr_offset_add.5" = add i64 %"stg_addr_packed_1.6", 24
  %"R59:R3_addr_ptr.6" = inttoptr i64 %"stg_addr_memaddr_offset_add.5" to i32 addrspace(1)*
  store i32 %".235", i32 addrspace(1)* %"R59:R3_addr_ptr.6"
  %"stg_addr_r0_ext.7" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.7" = or i64 0, %"stg_addr_r0_ext.7"
  %"stg_addr_r1_ext.7" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.7" = shl i64 %"stg_addr_r1_ext.7", 32
  %"stg_addr_packed_1.7" = or i64 %"stg_addr_packed_0.7", %"stg_addr_r1_shift.7"
  %"stg_addr_memaddr_offset_add.6" = add i64 %"stg_addr_packed_1.7", 28
  %"R59:R3_addr_ptr.7" = inttoptr i64 %"stg_addr_memaddr_offset_add.6" to i32 addrspace(1)*
  store i32 %".236", i32 addrspace(1)* %"R59:R3_addr_ptr.7"
  %"ldtm_addr_memaddr_offset_add.2" = add i32 %"imad.11", 12
  %"ldtm.3" = call {i32, i32, i32, i32} asm sideeffect "tcgen05.ld.sync.aligned.32x32b.x4.b32 {$0, $1, $2, $3}, [$4];
	tcgen05.wait::ld.sync.aligned;", "=r,=r,=r,=r,r,~{memory}"(i32 %"ldtm_addr_memaddr_offset_add.2")
  %".249" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 0
  %".250" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 1
  %".251" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 2
  %".252" = extractvalue {i32, i32, i32, i32} %"ldtm.3", 3
  %"stg_addr_r0_ext.8" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.8" = or i64 0, %"stg_addr_r0_ext.8"
  %"stg_addr_r1_ext.8" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.8" = shl i64 %"stg_addr_r1_ext.8", 32
  %"stg_addr_packed_1.8" = or i64 %"stg_addr_packed_0.8", %"stg_addr_r1_shift.8"
  %"stg_addr_memaddr_offset_add.7" = add i64 %"stg_addr_packed_1.8", 32
  %"R59:R3_addr_ptr.8" = inttoptr i64 %"stg_addr_memaddr_offset_add.7" to i32 addrspace(1)*
  store i32 %".242", i32 addrspace(1)* %"R59:R3_addr_ptr.8"
  %"stg_addr_r0_ext.9" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.9" = or i64 0, %"stg_addr_r0_ext.9"
  %"stg_addr_r1_ext.9" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.9" = shl i64 %"stg_addr_r1_ext.9", 32
  %"stg_addr_packed_1.9" = or i64 %"stg_addr_packed_0.9", %"stg_addr_r1_shift.9"
  %"stg_addr_memaddr_offset_add.8" = add i64 %"stg_addr_packed_1.9", 36
  %"R59:R3_addr_ptr.9" = inttoptr i64 %"stg_addr_memaddr_offset_add.8" to i32 addrspace(1)*
  store i32 %".243", i32 addrspace(1)* %"R59:R3_addr_ptr.9"
  %"stg_addr_r0_ext.10" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.10" = or i64 0, %"stg_addr_r0_ext.10"
  %"stg_addr_r1_ext.10" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.10" = shl i64 %"stg_addr_r1_ext.10", 32
  %"stg_addr_packed_1.10" = or i64 %"stg_addr_packed_0.10", %"stg_addr_r1_shift.10"
  %"stg_addr_memaddr_offset_add.9" = add i64 %"stg_addr_packed_1.10", 40
  %"R59:R3_addr_ptr.10" = inttoptr i64 %"stg_addr_memaddr_offset_add.9" to i32 addrspace(1)*
  store i32 %".244", i32 addrspace(1)* %"R59:R3_addr_ptr.10"
  %"stg_addr_r0_ext.11" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.11" = or i64 0, %"stg_addr_r0_ext.11"
  %"stg_addr_r1_ext.11" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.11" = shl i64 %"stg_addr_r1_ext.11", 32
  %"stg_addr_packed_1.11" = or i64 %"stg_addr_packed_0.11", %"stg_addr_r1_shift.11"
  %"stg_addr_memaddr_offset_add.10" = add i64 %"stg_addr_packed_1.11", 44
  %"R59:R3_addr_ptr.11" = inttoptr i64 %"stg_addr_memaddr_offset_add.10" to i32 addrspace(1)*
  store i32 %".245", i32 addrspace(1)* %"R59:R3_addr_ptr.11"
  %"stg_addr_r0_ext.12" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.12" = or i64 0, %"stg_addr_r0_ext.12"
  %"stg_addr_r1_ext.12" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.12" = shl i64 %"stg_addr_r1_ext.12", 32
  %"stg_addr_packed_1.12" = or i64 %"stg_addr_packed_0.12", %"stg_addr_r1_shift.12"
  %"stg_addr_memaddr_offset_add.11" = add i64 %"stg_addr_packed_1.12", 48
  %"R59:R3_addr_ptr.12" = inttoptr i64 %"stg_addr_memaddr_offset_add.11" to i32 addrspace(1)*
  store i32 %".249", i32 addrspace(1)* %"R59:R3_addr_ptr.12"
  %"stg_addr_r0_ext.13" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.13" = or i64 0, %"stg_addr_r0_ext.13"
  %"stg_addr_r1_ext.13" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.13" = shl i64 %"stg_addr_r1_ext.13", 32
  %"stg_addr_packed_1.13" = or i64 %"stg_addr_packed_0.13", %"stg_addr_r1_shift.13"
  %"stg_addr_memaddr_offset_add.12" = add i64 %"stg_addr_packed_1.13", 52
  %"R59:R3_addr_ptr.13" = inttoptr i64 %"stg_addr_memaddr_offset_add.12" to i32 addrspace(1)*
  store i32 %".250", i32 addrspace(1)* %"R59:R3_addr_ptr.13"
  %"stg_addr_r0_ext.14" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.14" = or i64 0, %"stg_addr_r0_ext.14"
  %"stg_addr_r1_ext.14" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.14" = shl i64 %"stg_addr_r1_ext.14", 32
  %"stg_addr_packed_1.14" = or i64 %"stg_addr_packed_0.14", %"stg_addr_r1_shift.14"
  %"stg_addr_memaddr_offset_add.13" = add i64 %"stg_addr_packed_1.14", 56
  %"R59:R3_addr_ptr.14" = inttoptr i64 %"stg_addr_memaddr_offset_add.13" to i32 addrspace(1)*
  store i32 %".251", i32 addrspace(1)* %"R59:R3_addr_ptr.14"
  %"stg_addr_r0_ext.15" = zext i32 %"R13:R12_r0.3" to i64
  %"stg_addr_packed_0.15" = or i64 0, %"stg_addr_r0_ext.15"
  %"stg_addr_r1_ext.15" = zext i32 %"R13:R12_r1.3" to i64
  %"stg_addr_r1_shift.15" = shl i64 %"stg_addr_r1_ext.15", 32
  %"stg_addr_packed_1.15" = or i64 %"stg_addr_packed_0.15", %"stg_addr_r1_shift.15"
  %"stg_addr_memaddr_offset_add.14" = add i64 %"stg_addr_packed_1.15", 60
  %"R59:R3_addr_ptr.15" = inttoptr i64 %"stg_addr_memaddr_offset_add.14" to i32 addrspace(1)*
  store i32 %".252", i32 addrspace(1)* %"R59:R3_addr_ptr.15"
  call void @"llvm.nvvm.barrier0"()
  br label %"BB_0a90"
BB_0a90:
  %"cond_trunc.13" = trunc i32 %"P32_to_i32" to i1
  %"pbra_cond_to_i32.13" = zext i1 %"cond_trunc.13" to i32
  %"pbra_cond_to_i1.13" = icmp ne i32 %"pbra_cond_to_i32.13", 0
  br i1 %"pbra_cond_to_i1.13", label %"BB_80000a90", label %"BB_0aa0"
BB_0aa0:
  %"lds_addr_memaddr_offset_add.2" = add i32 %".16", 1032
  %"lds_shared_addr_winoff.2" = and i32 %"lds_addr_memaddr_offset_add.2", 16777215
  %".263" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.2"
  %"lds_shared_addr_cast.2" = bitcast i8 addrspace(3)* %".263" to i32 addrspace(3)*
  %"lds.2" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.2"
  %"imad_tmp.11" = mul i32 0, 0
  %"imad.14" = add i32 %"imad_tmp.11", 3
  %".264" = zext i32 %"s2ur_cluster_ctarank" to i64
  %".265" = zext i32 64 to i64
  %".266" = zext i32 24 to i64
  %".267" = shl i64 %".264", %".266"
  %".268" = and i64 %".267", 4294967295
  %".269" = add i64 %".268", %".265"
  %".270" = trunc i64 %".269" to i32
  %"lds_addr_memaddr_offset_add.3" = add i32 %".270", 20
  %"lds_shared_addr_winoff.3" = and i32 %"lds_addr_memaddr_offset_add.3", 16777215
  %".271" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.3"
  %"lds_shared_addr_cast.3" = bitcast i8 addrspace(3)* %".271" to i32 addrspace(3)*
  %"lds.3" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.3"
  %".272" = xor i32 %"lds.2", -1
  %".273" = xor i32 65535, -1
  %".274" = xor i32 0, -1
  %".275" = and i32 %"lds.2", 65535
  %".276" = and i32 %".275", %".274"
  %".277" = and i32 %"lds.2", 65535
  %".278" = and i32 %".277", 0
  %".279" = or i32 %".276", %".278"
  %".280" = zext i32 0 to i64
  %".281" = zext i32 %".279" to i64
  %".282" = shl i64 %".281", 32
  %"shf_concat.6" = or i64 %".280", %".282"
  %"shf_shift_64.6" = zext i32 5 to i64
  %".283" = lshr i64 %"shf_concat.6", %"shf_shift_64.6"
  %"shf_hi.1" = lshr i64 %".283", 32
  %"shf_result.6" = trunc i64 %"shf_hi.1" to i32
  %".284" = zext i32 %"imad.14" to i64
  %".285" = zext i32 0 to i64
  %".286" = shl i64 %".285", 32
  %"shf_concat.7" = or i64 %".284", %".286"
  %"shf_shift_64.7" = zext i32 %"shf_result.6" to i64
  %".287" = shl i64 %"shf_concat.7", %"shf_shift_64.7"
  %"shf_result.7" = trunc i64 %".287" to i32
  %".288" = xor i32 %"lds.3", -1
  %".289" = xor i32 %"shf_result.7", -1
  %".290" = xor i32 0, -1
  %".291" = and i32 %"lds.3", %"shf_result.7"
  %".292" = and i32 %".291", %".290"
  %".293" = and i32 %"lds.3", %"shf_result.7"
  %".294" = and i32 %".293", 0
  %".295" = or i32 %".292", %".294"
  %"isetrp_cmp1.4" = icmp ne i32 %".295", %"shf_result.7"
  %"isetrp_src_to_i32.4" = zext i1 1 to i32
  %"isetrp_src_to_i1.4" = icmp ne i32 %"isetrp_src_to_i32.4", 0
  %"isetrp_cmp2.4" = and i1 %"isetrp_cmp1.4", %"isetrp_src_to_i1.4"
  %"P21_to_i32" = zext i1 %"isetrp_cmp2.4" to i32
  %"imad_tmp.12" = mul i32 0, 0
  %"imad.15" = add i32 %"imad_tmp.12", 1
  %".296" = zext i32 %"imad.15" to i64
  %".297" = zext i32 0 to i64
  %".298" = shl i64 %".297", 32
  %"shf_concat.8" = or i64 %".296", %".298"
  %"shf_shift_64.8" = zext i32 %"shf_result.6" to i64
  %".299" = shl i64 %"shf_concat.8", %"shf_shift_64.8"
  %"shf_result.8" = trunc i64 %".299" to i32
  br label %"BB_0b70"
BB_0b70:
  %"cond_trunc.14" = trunc i32 %"P21_to_i32" to i1
  %"pbra_cond_to_i32.14" = zext i1 %"cond_trunc.14" to i32
  %"pbra_cond_to_i1.14" = icmp ne i32 %"pbra_cond_to_i32.14", 0
  br i1 %"pbra_cond_to_i1.14", label %"BB_0d00_0d90", label %"BB_0b80"
BB_0b80:
  %"lds_addr_memaddr_offset_add.4" = add i32 %".270", 24
  %"lds_shared_addr_winoff.4" = and i32 %"lds_addr_memaddr_offset_add.4", 16777215
  %".302" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"lds_shared_addr_winoff.4"
  %"lds_shared_addr_cast.4" = bitcast i8 addrspace(3)* %".302" to i32 addrspace(3)*
  %"lds.4" = load volatile i32, i32 addrspace(3)* %"lds_shared_addr_cast.4"
  %".303" = xor i32 %"lds.4", -1
  %".304" = xor i32 %"shf_result.8", -1
  %".305" = xor i32 0, -1
  %".306" = and i32 %"lds.4", %"shf_result.8"
  %".307" = and i32 %".306", %".305"
  %".308" = and i32 %"lds.4", %"shf_result.8"
  %".309" = and i32 %".308", 0
  %".310" = or i32 %".307", %".309"
  %"isetrp_cmp1.5" = icmp ne i32 %".310", %"shf_result.8"
  %"isetrp_src_to_i32.5" = zext i1 1 to i32
  %"isetrp_src_to_i1.5" = icmp ne i32 %"isetrp_src_to_i32.5", 0
  %"isetrp_cmp2.5" = and i1 %"isetrp_cmp1.5", %"isetrp_src_to_i1.5"
  %"P22_to_i32" = zext i1 %"isetrp_cmp2.5" to i32
  br label %"BB_0bb0"
BB_0bb0:
  %"cond_trunc.15" = trunc i32 %"P22_to_i32" to i1
  %"pbra_cond_to_i32.15" = zext i1 %"cond_trunc.15" to i32
  %"pbra_cond_to_i1.15" = icmp ne i32 %"pbra_cond_to_i32.15", 0
  br i1 %"pbra_cond_to_i1.15", label %"BB_0cd0_0d60", label %"BB_0bc0"
BB_0bc0:
  %"activemask" = call i32 @"llvm.nvvm.activemask"()
  %"laneid" = call i32 @"llvm.nvvm.read.ptx.sreg.laneid"()
  %".313" = xor i32 0, -1
  %".314" = xor i32 %"shf_result.8", -1
  %".315" = xor i32 0, -1
  %".316" = and i32 %".313", %".314"
  %".317" = and i32 %".316", %".315"
  %".318" = and i32 %".313", %".314"
  %".319" = and i32 %".318", 0
  %".320" = or i32 %".317", %".319"
  %".321" = and i32 0, %".314"
  %".322" = and i32 %".321", %".315"
  %".323" = or i32 %".320", %".322"
  %".324" = and i32 0, %".314"
  %".325" = and i32 %".324", 0
  %".326" = or i32 %".323", %".325"
  %"flo_clz" = call i32 @"llvm.ctlz.i32"(i32 %"activemask", i1 0)
  %"flo" = sub i32 31, %"flo_clz"
  %"redux_mask" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %".326", i32 %"redux_mask")
  %".327" = xor i32 0, -1
  %".328" = xor i32 %"shf_result.7", -1
  %".329" = xor i32 0, -1
  %".330" = and i32 %".327", %".328"
  %".331" = and i32 %".330", %".329"
  %".332" = and i32 %".327", %".328"
  %".333" = and i32 %".332", 0
  %".334" = or i32 %".331", %".333"
  %".335" = and i32 0, %".328"
  %".336" = and i32 %".335", %".329"
  %".337" = or i32 %".334", %".336"
  %".338" = and i32 0, %".328"
  %".339" = and i32 %".338", 0
  %".340" = or i32 %".337", %".339"
  %"imad_tmp.13" = mul i32 0, 0
  %"imad.16" = add i32 %"imad_tmp.13", %".340"
  %"redux_mask.1" = call i32 @"llvm.nvvm.activemask"()
  %"redux_sync_and.1" = call i32 @"llvm.nvvm.redux.sync.and"(i32 %"imad.16", i32 %"redux_mask.1")
  %".341" = xor i32 %".340", -1
  %".342" = call i32 @"llvm.cttz.i32"(i32 %".341", i1 0)
  %".343" = shl i32 %".342", 5
  call void asm sideeffect "tcgen05.dealloc.cta_group::1.sync.aligned.b32 $0, 64;", "r,~{memory}"(i32 %".343") convergent
  %"imad_tmp.14" = mul i32 0, 0
  %"imad.17" = add i32 %"imad_tmp.14", %"redux_sync_and"
  %"isetrp_cmp1.6" = icmp eq i32 %"laneid", %"flo"
  %"isetrp_src_to_i32.6" = zext i1 1 to i32
  %"isetrp_src_to_i1.6" = icmp ne i32 %"isetrp_src_to_i32.6", 0
  %"isetrp_cmp2.6" = and i1 %"isetrp_cmp1.6", %"isetrp_src_to_i1.6"
  %"P24_to_i32" = zext i1 %"isetrp_cmp2.6" to i32
  %"imad_tmp.15" = mul i32 0, 0
  %"imad.18" = add i32 %"imad_tmp.15", %"redux_sync_and.1"
  br label %"BB_0c90"
BB_0c90:
  %"cond_trunc.16" = trunc i32 %"P24_to_i32" to i1
  %"pbra_cond_to_i32.16" = zext i1 %"cond_trunc.16" to i32
  %"pbra_cond_to_i1.16" = icmp ne i32 %"pbra_cond_to_i32.16", 0
  br i1 %"pbra_cond_to_i1.16", label %"BB_80000c90", label %"BB_0d10"
BB_80000c90:
  %"atoms_addr_memaddr_offset_add.2" = add i32 %".270", 20
  %"atoms_shared_addr_winoff.2" = and i32 %"atoms_addr_memaddr_offset_add.2", 16777215
  %".347" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.2"
  %"atoms_ptr.2" = bitcast i8 addrspace(3)* %".347" to i32 addrspace(3)*
  %"atoms_and" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.2", i32 %"imad.18" monotonic
  %"atoms_addr_memaddr_offset_add.3" = add i32 %".270", 24
  %"atoms_shared_addr_winoff.3" = and i32 %"atoms_addr_memaddr_offset_add.3", 16777215
  %".348" = getelementptr inbounds [2064 x i8], [2064 x i8] addrspace(3)* @"shared_mem", i32 0, i32 %"atoms_shared_addr_winoff.3"
  %"atoms_ptr.3" = bitcast i8 addrspace(3)* %".348" to i32 addrspace(3)*
  %"atoms_and.1" = atomicrmw and i32 addrspace(3)* %"atoms_ptr.3", i32 %"imad.17" monotonic
  br label %"BB_0d10"
BB_0cd0_0d60:
  call void @"llvm.trap"()
  br label %"BB_0d10"
BB_0d00_0d90:
  call void @"llvm.trap"()
  br label %"BB_0d10"
BB_0d10:
  ret void
BB_80000a90:
  ret void
}

@"const_mem" = global [5 x [912 x i8]] [[912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0], [912 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0]], align 16
declare i32 @"llvm.nvvm.read.ptx.sreg.tid.x"()

declare i32 @"llvm.nvvm.read.ptx.sreg.cluster.ctarank"()

declare i1 @"llvm.nvvm.vote.all.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.activemask"()

declare {i32, i1} @"llvm.nvvm.elect.sync"(i32 %".1")

declare void @"llvm.nvvm.barrier0"()

declare void @"llvm.nvvm.membar.cta"()

declare i1 @"llvm.nvvm.vote.any.sync"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.read.ptx.sreg.laneid"()

declare i32 @"llvm.ctlz.i32"(i32 %".1", i1 %".2")

declare i32 @"llvm.nvvm.redux.sync.and"(i32 %".1", i32 %".2")

declare i32 @"llvm.cttz.i32"(i32 %".1", i1 %".2")

declare void @"llvm.trap"()

!nvvmir.version = !{ !0 }
!nvvm.annotations = !{ !1, !2, !3, !4, !5 }
!0 = !{ i32 2, i32 0 }
!1 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case11EEvPKjPj", !"kernel", i32 1 }
!2 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case10EEvPKjPj", !"kernel", i32 1 }
!3 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case9EEvPKjPj", !"kernel", i32 1 }
!4 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case8EEvPKjPj", !"kernel", i32 1 }
!5 = !{ void (i64, i64)* @"_Z13column_scaledIL4Case7EEvPKjPj", !"kernel", i32 1 }
